"use strict";

function _slicedToArray(e, t) {
    return _arrayWithHoles(e) || _iterableToArrayLimit(e, t) || _nonIterableRest()
}

function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function _iterableToArrayLimit(e, t) {
    if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) {
        var n = [],
            i = !0,
            a = !1,
            o = void 0;
        try {
            for (var s, r = e[Symbol.iterator](); !(i = (s = r.next()).done) && (n.push(s.value), !t || n.length !== t); i = !0);
        } catch (e) {
            a = !0, o = e
        } finally {
            try {
                i || null == r.return || r.return()
            } finally {
                if (a) throw o
            }
        }
        return n
    }
}

function _arrayWithHoles(e) {
    if (Array.isArray(e)) return e
}

function set(e, t, n, i) {
    return (set = "undefined" != typeof Reflect && Reflect.set ? Reflect.set : function (e, t, n, i) {
        var a, o = _superPropBase(e, t);
        if (o) {
            if ((a = Object.getOwnPropertyDescriptor(o, t)).set) return a.set.call(i, n), !0;
            if (!a.writable) return !1
        }
        if (a = Object.getOwnPropertyDescriptor(i, t)) {
            if (!a.writable) return !1;
            a.value = n, Object.defineProperty(i, t, a)
        } else _defineProperty(i, t, n);
        return !0
    })(e, t, n, i)
}

function _set(e, t, n, i, a) {
    if (!set(e, t, n, i || e) && a) throw new Error("failed to set property");
    return n
}

function _defineProperty(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function _toConsumableArray(e) {
    return _arrayWithoutHoles(e) || _iterableToArray(e) || _nonIterableSpread()
}

function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function _iterableToArray(e) {
    if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
}

function _arrayWithoutHoles(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function _wrapNativeSuper(e) {
    var t = "function" == typeof Map ? new Map : void 0;
    return (_wrapNativeSuper = function (e) {
        if (null === e || !_isNativeFunction(e)) return e;
        if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
        if (void 0 !== t) {
            if (t.has(e)) return t.get(e);
            t.set(e, Wrapper)
        }

        function Wrapper() {
            return _construct(e, arguments, _getPrototypeOf(this).constructor)
        }
        return Wrapper.prototype = Object.create(e.prototype, {
            constructor: {
                value: Wrapper,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), _setPrototypeOf(Wrapper, e)
    })(e)
}

function isNativeReflectConstruct() {
    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
    if (Reflect.construct.sham) return !1;
    if ("function" == typeof Proxy) return !0;
    try {
        return Date.prototype.toString.call(Reflect.construct(Date, [], function () {})), !0
    } catch (e) {
        return !1
    }
}

function _construct(e, t, n) {
    return (_construct = isNativeReflectConstruct() ? Reflect.construct : function (e, t, n) {
        var i = [null];
        i.push.apply(i, t);
        var a = new(Function.bind.apply(e, i));
        return n && _setPrototypeOf(a, n.prototype), a
    }).apply(null, arguments)
}

function _isNativeFunction(e) {
    return -1 !== Function.toString.call(e).indexOf("[native code]")
}

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
        return typeof e
    } : function (e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}

function _possibleConstructorReturn(e, t) {
    return !t || "object" !== _typeof(t) && "function" != typeof t ? _assertThisInitialized(e) : t
}

function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function _get(e, t, n) {
    return (_get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function (e, t, n) {
        var i = _superPropBase(e, t);
        if (i) {
            var a = Object.getOwnPropertyDescriptor(i, t);
            return a.get ? a.get.call(n) : a.value
        }
    })(e, t, n || e)
}

function _superPropBase(e, t) {
    for (; !Object.prototype.hasOwnProperty.call(e, t) && null !== (e = _getPrototypeOf(e)););
    return e
}

function _getPrototypeOf(e) {
    return (_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function (e) {
        return e.__proto__ || Object.getPrototypeOf(e)
    })(e)
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            writable: !0,
            configurable: !0
        }
    }), t && _setPrototypeOf(e, t)
}

function _setPrototypeOf(e, t) {
    return (_setPrototypeOf = Object.setPrototypeOf || function (e, t) {
        return e.__proto__ = t, e
    })(e, t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _defineProperties(e, t) {
    for (var n = 0; n < t.length; n++) {
        var i = t[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
    }
}

function _createClass(e, t, n) {
    return t && _defineProperties(e.prototype, t), n && _defineProperties(e, n), e
}
!function () {
    var e, t = function () {
        function GameConfig() {
            _classCallCheck(this, GameConfig)
        }
        return _createClass(GameConfig, null, [{
            key: "init",
            value: function () {
                Laya.ClassUtils.regClass
            }
        }]), GameConfig
    }();
    t.width = 750, t.height = 1334, t.scaleMode = "fixedwidth", t.screenMode = "none", t.alignV = "middle", t.alignH = "center", t.startScene = "", t.sceneRoot = "", t.debug = !1, t.stat = !1, t.physicsDebug = !1, t.exportSceneToJson = !0, t.init(),
        function (e) {
            e[e.base = 1] = "base", e[e.lowMid = 2] = "lowMid", e[e.mid = 3] = "mid", e[e.top = 4] = "top", e[e.adTop = 5] = "adTop", e[e.overlay = 6] = "overlay", e[e.yinSi = 98] = "yinSi", e[e.wendang = 99] = "wendang", e[e.nativeBannerAd = 100] = "nativeBannerAd", e[e.insertAd = 101] = "insertAd", e[e.cover = 102] = "cover", e[e.login = 105] = "login", e[e.loging = 104] = "loging"
        }(e || (e = {}));
    var n = function (e) {
            function ViewBase() {
                var e;
                return _classCallCheck(this, ViewBase), (e = _possibleConstructorReturn(this, _getPrototypeOf(ViewBase).apply(this, arguments))).ServerConfigKey = "", e
            }
            return _inherits(ViewBase, fgui.GComponent), _createClass(ViewBase, [{
                key: "constructFromXML",
                value: function () {
                    _get(_getPrototypeOf(ViewBase.prototype), "constructFromXML", this).call(this, void 0), this.displayObject.onAwake = this._onAwake.bind(this), this.displayObject.onDestroy = this._onDestroy.bind(this), this.onClickByView && this.onClick(this, this.onClickByView), this.onCreate && this.onCreate()
                }
            }, {
                key: "_onAwake",
                value: function () {
                    this.ServerConfigKey && !ViewBase.find_parent_component_once_node(this, ViewBase) && (mt.isConfigUIModel(this.ServerConfigKey) || (this.visible = !1)), this.onLoaded && this.onLoaded()
                }
            }, {
                key: "_onDestroy",
                value: function () {
                    Laya.timer.clearAll(this), this.onDestroyed && this.onDestroyed()
                }
            }, {
                key: "random",
                value: function (e, t) {
                    return Math.round(Math.random() * (t - e) + e)
                }
            }, {
                key: "randomItem",
                value: function (e) {
                    return e && e.length > 0 ? e[this.random(0, e.length - 1)] : null
                }
            }], [{
                key: "find_parent_component_once_node",
                value: function (e, t) {
                    if (!(e instanceof fairygui.GComponent)) return null;
                    for (var n = e.parent; n && !(n instanceof t);) n = n.parent;
                    return n
                }
            }]), ViewBase
        }(),
        i = function (e) {
            function AvdCell() {
                return _classCallCheck(this, AvdCell), _possibleConstructorReturn(this, _getPrototypeOf(AvdCell).apply(this, arguments))
            }
            return _inherits(AvdCell, n), _createClass(AvdCell, [{
                key: "onCreate",
                value: function () {
                    this._icon = this.getChildByPath("img").asLoader, this._nameLab = this.getChildByPath("name").asTextField
                }
            }, {
                key: "onClickByView",
                value: function () {
                    this._data && mt.navigateToMiniGame(this._data)
                }
            }, {
                key: "updataData",
                value: function (e) {
                    if (this._data != e && (this._data = e, e)) {
                        for (var t = [], n = 1; n <= 6; ++n) {
                            var i = this.getChild("bg" + n);
                            i && t.push(i.asImage)
                        }
                        var a = this.random(0, t.length - 1);
                        t.map(function (e, t) {
                            e.visible = t == a
                        }), this._icon.url = this.randomItem(e.iconPath), this._nameLab.text = e.name
                    }
                }
            }]), AvdCell
        }(),
        a = function (e) {
            function AvdFloat() {
                var e;
                return _classCallCheck(this, AvdFloat), (e = _possibleConstructorReturn(this, _getPrototypeOf(AvdFloat).apply(this, arguments))).ServerConfigKey = "is_AvdFloat", e
            }
            return _inherits(AvdFloat, n), _createClass(AvdFloat, [{
                key: "onCreate",
                value: function () {
                    this._icon = this.getChildByPath("icon.img").asLoader, this._nameLab = this.getChildByPath("name").asTextField;
                    this.data && parseFloat(this.data.toString()), this._Listata = mt.getNavigateList(), this._Listata.length <= 0 || (Laya.timer.clear(this, this._freamtimeHandler), Laya.timer.loop(3e3, this, this._freamtimeHandler), this._freamtimeHandler())
                }
            }, {
                key: "onClickByView",
                value: function (e) {
                    e._stoped = !0, this._data && mt.navigateToMiniGame(this._data)
                }
            }, {
                key: "_freamtimeHandler",
                value: function () {
                    var e = Math.floor(Math.random() * this._Listata.length),
                        t = this._Listata[e];
                    this._icon.url = this.randomItem(t.iconPath), this._nameLab.text = t.name, this._data = t
                }
            }]), AvdFloat
        }(),
        o = function (e) {
            function AvdList() {
                var e;
                return _classCallCheck(this, AvdList), (e = _possibleConstructorReturn(this, _getPrototypeOf(AvdList).apply(this, arguments))).ServerConfigKey = "is_AvdList", e._data = [], e
            }
            return _inherits(AvdList, n), _createClass(AvdList, [{
                key: "onCreate",
                value: function () {
                    this._list = this.getChildByPath("leftBoxList").asList, this._list.itemRenderer = Laya.Handler.create(this, this.updataCellHandler, null, !1), this.changeAll(), Laya.timer.loop(3e3, this, this.changeAll)
                }
            }, {
                key: "changeAll",
                value: function () {
                    var e = this;
                    this._data = [];
                    var t = mt.getNavigateList(),
                        n = this.random(0, t.length - 5);
                    if (!(n < 0)) {
                        for (var i = n; i < n + 4; ++i) t[i] && this._data.push(t[i]);
                        this._list.numItems = this._data.length;
                        var a = this._list._children,
                            o = a[Math.floor(Math.random() * a.length)];
                        this.aniro(o, 10, function () {
                            e.aniro(o, -10, function () {
                                e.aniro(o, 10, function () {
                                    e.aniro(o, -10, function () {
                                        e.aniro(o, 0, function () {})
                                    })
                                })
                            })
                        })
                    }
                }
            }, {
                key: "aniro",
                value: function (e, t, n) {
                    Laya.Tween.to(e, {
                        rotation: t
                    }, 300, null, Laya.Handler.create(this, function () {
                        n()
                    }, null, !1))
                }
            }, {
                key: "updataCellHandler",
                value: function (e, t) {
                    t.updataData(this._data[e])
                }
            }]), AvdList
        }(),
        s = function () {
            function IntervalDisplayAD(e) {
                _classCallCheck(this, IntervalDisplayAD), this.ServerConfigKey = "", this.last_display_time = 0, this.is_check = !0, this.ServerConfigKey = e, this.last_display_time = 0
            }
            return _createClass(IntervalDisplayAD, [{
                key: "has",
                value: function () {
                    return false
                }
            }]), IntervalDisplayAD
        }();
    s.last_display_time = 0, s.ServerConfigKey = "ad_all_interval";
    var r = function (e) {
        function MoreGameBtn() {
            return _classCallCheck(this, MoreGameBtn), _possibleConstructorReturn(this, _getPrototypeOf(MoreGameBtn).apply(this, arguments))
        }
        return _inherits(MoreGameBtn, n), _createClass(MoreGameBtn, [{
            key: "onCreate",
            value: function () {
                
            }
        }, {
            key: "onClickByView",
            value: function () {
            }
        }]), MoreGameBtn
    }();
    r.ServerConfigKey = "is_MoreGameBtn", r.IntervalDisplayAD = new s(r.ServerConfigKey);
    var l = function (e) {
        function PropSceneUI() {
            var e;
            return _classCallCheck(this, PropSceneUI), (e = _possibleConstructorReturn(this, _getPrototypeOf(PropSceneUI).apply(this, arguments))).ServerConfigKey = PropSceneUI.ServerConfigKey, e.navigatedata = [], e.pasue_end_time = 0, e.index = 0, e._dirction = 1, e.maxPosY = 10, e.posY = 0, e._list_speed = 3, e.level = Number.MAX_SAFE_INTEGER, e.bclick = !1, e
        }
        return _inherits(PropSceneUI, n), _createClass(PropSceneUI, [{
            key: "moveDownHandler",
            value: function (e) {
                this.pasue_end_time = Date.now() + 300, Laya.stage.once(Laya.Event.MOUSE_UP, this, this.moveUpHandler)
            }
        }, {
            key: "moveUpHandler",
            value: function (e) {
                Laya.stage.off(Laya.Event.MOUSE_UP, this, this.moveUpHandler), this.posY = this._list.scrollPane.posY
            }
        }, {
            key: "randomOpenView",
            value: function () {
                if (mt.isOffCitys()) console.log("城市屏蔽");
                else if (mt.isCurrentVersion) console.log("版本屏蔽");
                else {
                    var e = this._list._children;
                    e[Math.floor(Math.random() * e.length)].onClickByView()
                }
            }
        }, {
            key: "enterframe",
            value: function () {
                Date.now() < this.pasue_end_time || (this.posY = this._list.scrollPane.posY, this.posY += this._list_speed, this.posY >= this.maxPosY ? (this.posY = this.maxPosY, this._list_speed *= -1) : this.posY <= 0 && (this.posY = 0, this._list_speed *= -1), this._list.scrollPane.setPosY(this.posY))
            }
        }, {
            key: "onCreate",
            value: function () {
                var e = this;
                It.Int.on(yt.PLAT_TOUCH_BANNER_AD, this.touch_banner_close, this), mt.hideBanner(), this.on(Laya.Event.MOUSE_DOWN, this, this.moveDownHandler), this.getChild("btn_continue").onClick(this, this.click_continue), this.navigatedata = mt.getNavigateList(), this._list = this.getChild("list").asList, this._list.itemRenderer = Laya.Handler.create(this, this.updataCellHandler, null, !1), this._list.numItems = this.navigatedata.length, Laya.timer.frameLoop(1, this, this.enterframe), Laya.timer.frameOnce(1, this, function () {
                    e.maxPosY = e._list.scrollPane._overlapSize.y
                }), this.randomOpenView()
            }
        }, {
            key: "touch_banner_close",
            value: function () {
                PropSceneUI.lastbannertime = Date.now(), It.Int.off(yt.PLAT_TOUCH_BANNER_AD, this.touch_banner_close, this), mt.hideBanner(), mt.updateErrorCount(_t.BANNER), this._completeHandler && (this._completeHandler(), this._completeHandler = null), console.log("PropSceneUI----销毁"), this.dispose()
            }
        }, {
            key: "onDestroyed",
            value: function () {
                console.log("-------------onDestroyed"), It.Int.off(yt.PLAT_TOUCH_BANNER_AD, this.touch_banner_close, this)
            }
        }, {
            key: "updataCellHandler",
            value: function (e, t) {
                t.updataData(this.navigatedata[e])
            }
        }, {
            key: "setCallback",
            value: function (e, t) {
                mt.hideBanner(), this.level = e, this._completeHandler = t
            }
        }, {
            key: "click_continue",
            value: function () {
                var e = this;
                !this.bclick && Date.now() - PropSceneUI.lastbannertime > 1e4 && mt.canClick({
                    level: this.level
                }, dt.WaterFall) ? (this.getChild("btn_continue").offClick(this, this.click_continue), this.bclick = !0, console.log("banner"), Laya.timer.once(800, this, function () {
                    mt.showBanner(), Laya.timer.once(1800, e, function () {
                        mt.hideBanner(), e.getChild("btn_continue").onClick(e, e.click_continue)
                    })
                })) : (mt.hideBanner(), this._completeHandler && (this._completeHandler(), this._completeHandler = null), It.Int.off(yt.PLAT_TOUCH_BANNER_AD, this.touch_banner_close.bind(this), this), this.dispose())
            }
        }]), PropSceneUI
    }();
    l.ServerConfigKey = "is_PropSceneUI", l.IntervalDisplayAD = new s(l.ServerConfigKey), l.lastbannertime = 0;
    var u = function (e) {
            function NativeBanner() {
                var e;
                return _classCallCheck(this, NativeBanner), (e = _possibleConstructorReturn(this, _getPrototypeOf(NativeBanner).apply(this, arguments)))._info = {
                    NativeType: 0
                }, e
            }
            return _inherits(NativeBanner, n), _createClass(NativeBanner, [{
                key: "onCreate",
                value: function () {
                    if (this._iconLoader = this.getChildByPath("icon").asLoader, this.getChild("n3").asCom.onClick(this, this.clickViewHandler), this.data) try {
                        this._info = JSON.parse(this.data.toString())
                    } catch (e) {
                        this._info = {
                            NativeType: 0
                        }
                    }
                    this._info || (this._info = {
                        NativeType: 0
                    }), this.createNative()
                }
            }, {
                key: "showView",
                value: function () {
                    mt.isShowTime() ? this._nativeNode && this._nativeNode.load() : Laya.timer.callLater(this, this.removeView)
                }
            }, {
                key: "clickNativeBannerView",
                value: function () {
                    this.removeView(), this.reportAdClick()
                }
            }, {
                key: "clickViewHandler",
                value: function (e) {
                    e._stoped = !0, this.removeView()
                }
            }, {
                key: "createNative",
                value: function () {
                    var e = this,
                        t = mt.data.NativeAd;
                    this._nativeNode = mt.createNative(t), this._nativeNode && (this._nativeNode.onError(function (t) {
                        console.log("=========>oppo 原生广告加载失败", t), e.displayObject.event("LoadFailNativeBanner")
                    }), this._nativeNode.onLoad(function (t) {
                        if (console.log("=========>oppo 原生广告加载成功", t), t && t.adList) {
                            var n = t.adList[t.adList.length - 1];
                            console.log("原生广告数据：", n), e.initNatveView(n), e.displayObject.event("LoadSuccessNativeBanner")
                        }
                    }))
                }
            }, {
                key: "initNatveView",
                value: function (e) {
                    if (e.imgUrlList && e.imgUrlList.length > 0) this._iconLoader.url = e.imgUrlList[0];
                    else {
                        if (!(e.iconUrlList && e.iconUrlList.length > 0)) return void this.removeView();
                        this._iconLoader.url = e.iconUrlList[0]
                    }
                    this._useNtAdId = e.adId, this.reportAdShow()
                }
            }, {
                key: "reportAdClick",
                value: function () {
                    null != this._useNtAdId && this._nativeNode && this._nativeNode.reportAdClick({
                        adId: this._useNtAdId.toString()
                    })
                }
            }, {
                key: "reportAdShow",
                value: function () {
                    null != this._useNtAdId && this._nativeNode && this._nativeNode.reportAdShow({
                        adId: this._useNtAdId.toString()
                    })
                }
            }, {
                key: "removeView",
                value: function () {
                    this.displayObject.event("CloseNativeBanner")
                }
            }]), NativeBanner
        }(),
        h = function (e) {
            function AddDesk() {
                var e;
                return _classCallCheck(this, AddDesk), (e = _possibleConstructorReturn(this, _getPrototypeOf(AddDesk).apply(this, arguments))).ServerConfigKey = "is_AddDesk", e
            }
            return _inherits(AddDesk, n), _createClass(AddDesk, [{
                key: "onCreate",
                value: function () {
                    mt.isShortCutInstalled && (this.visible = !1)
                }
            }, {
                key: "onClickByView",
                value: function () {
                    mt.shortCutInstalled(function (e) {
                        console.log("添加到桌面:", e)
                    })
                }
            }]), AddDesk
        }(),
        c = function (e) {
            function GameNative() {
                var e;
                return _classCallCheck(this, GameNative), (e = _possibleConstructorReturn(this, _getPrototypeOf(GameNative).apply(this, arguments))).ServerConfigKey = GameNative.ServerConfigKey, e
            }
            return _inherits(GameNative, n), _createClass(GameNative, [{
                key: "onCreate",
                value: function () {
                    this._showNative = this.getChild("n0")
                }
            }, {
                key: "showNativeView",
                value: function (e, t, n, i, a, o) {
                    this._showNativeBtn = e, this._continueBtn = t, this._showNativeBtn.onClick(this, this.onShowNativeBannerHandler), this._continueBtn && this._continueBtn.onClick(this, this.onContinueHandler), this._cometeHandler = n, this._loadFail = a, this._loadSucces = i, this._showNative.displayObject.on("CloseNativeBanner", this, this.onCloseHandler), this._showNative.displayObject.on("LoadFailNativeBanner", this, this.onLoadFailHandler), this._showNative.displayObject.on("LoadSuccessNativeBanner", this, this.onLoadSuccessHandler), this._level = o, this._showNative.showView()
                }
            }, {
                key: "onShowNativeBannerHandler",
                value: function () {
                    this._showNative.clickNativeBannerView()
                }
            }, {
                key: "onContinueHandler",
                value: function () {
                    mt.canClick({
                        level: this._level
                    }, dt.NativeAd) ? this._showNative.clickNativeBannerView() : this.onCloseHandler()
                }
            }, {
                key: "onCloseHandler",
                value: function () {
                    this._showNative.displayObject.off("LoadFailNativeBanner", this, this.onLoadFailHandler), this._showNative.displayObject.off("CloseNativeBanner", this, this.onCloseHandler), this._showNative.displayObject.off("LoadSuccessNativeBanner", this, this.onCloseHandler), this._cometeHandler && this._cometeHandler()
                }
            }, {
                key: "onLoadFailHandler",
                value: function () {
                    console.log("原生广告成功回调===> 失败 : ", this._loadFail), this._showNative.displayObject.off("LoadFailNativeBanner", this, this.onLoadFailHandler), this._showNative.displayObject.off("CloseNativeBanner", this, this.onCloseHandler), this._showNative.displayObject.off("LoadSuccessNativeBanner", this, this.onCloseHandler), this._loadFail && this._loadFail()
                }
            }, {
                key: "onLoadSuccessHandler",
                value: function () {
                    console.log("原生广告成功回调：", this._loadSucces), this._showNative.displayObject.off("LoadFailNativeBanner", this, this.onLoadFailHandler), this._showNative.displayObject.off("LoadSuccessNativeBanner", this, this.onCloseHandler), this._loadSucces && this._loadSucces()
                }
            }]), GameNative
        }();
    c.ServerConfigKey = "is_GameNative", c.IntervalDisplayAD = new s(c.ServerConfigKey);
    var d = function (e) {
            function ButtonEffect() {
                return _classCallCheck(this, ButtonEffect), _possibleConstructorReturn(this, _getPrototypeOf(ButtonEffect).apply(this, arguments))
            }
            return _inherits(ButtonEffect, Laya.Script), _createClass(ButtonEffect, [{
                key: "onAwake",
                value: function () {
                    this.node = fgui.GObject.cast(this.owner)
                }
            }, {
                key: "onEnable",
                value: function () {
                    var e = this;
                    this._tween && this._tween.clear(), mt.isCurrentVersion || Laya.timer.once(1300, this, function () {
                        e.showBtnMaxEffect()
                    })
                }
            }, {
                key: "showBtnMaxEffect",
                value: function () {
                    var e = this;
                    this._tween && this._tween.clear(), this._tween = Laya.Tween.to(this.node, {
                        scaleX: 1.2,
                        scaleY: 1.1
                    }, 600, null, Laya.Handler.create(this, function () {
                        e._tween.clear(), e.showBtnMinEffect()
                    }))
                }
            }, {
                key: "showBtnMinEffect",
                value: function () {
                    var e = this;
                    this._tween && this._tween.clear(), this._tween = Laya.Tween.to(this.node, {
                        scaleX: 1,
                        scaleY: 1
                    }, 600, null, Laya.Handler.create(this, function () {
                        e._tween.clear(), e.showBtnMaxEffect()
                    }))
                }
            }, {
                key: "onDestroy",
                value: function () {
                    this._tween && this._tween.clear()
                }
            }]), ButtonEffect
        }(),
        f = function (e) {
            function ClickGift() {
                var e;
                return _classCallCheck(this, ClickGift), (e = _possibleConstructorReturn(this, _getPrototypeOf(ClickGift).apply(this, arguments))).progress = null, e.tip1 = null, e.tip2 = null, e.callback = null, e.n9 = null, e.n3 = null, e.showBannerRatio = 50, e.pause = !1, e.target_value = 0, e
            }
            return _inherits(ClickGift, n), _createClass(ClickGift, [{
                key: "onCreate",
                value: function () {
                    var e = this;
                    It.Int.on(yt.PLAT_TOUCH_BANNER_AD, this.touch_banner_close, this), this.progress = this.getChildInGroup("progress", this.getChild("group1").asGroup).asProgress, this.n3 = this.getChildInGroup("n3", this.getChild("group1").asGroup).asImage, this.n9 = this.getChildInGroup("n9", this.getChild("group1").asGroup).asImage;
                    var t = this.random(0, 3);
                    [this.getChildInGroup("chest1", this.getChild("group1").asGroup), this.getChildInGroup("chest2", this.getChild("group1").asGroup)].map(function (e, n) {
                        e.visible = n == t
                    }), this.progress.value = 0, this.getChild("btn_click").onClick(this, this.btn_click), this.tip1 = this.getChild("tip1").asImage, this.tip2 = this.getChild("tip2").asImage, this.tip2.visible = !1, this.getChild("btn_click").displayObject.addComponent(d), Laya.timer.frameLoop(1, this, this.enterframe), Laya.timer.loop(500, this, function () {
                        e.pause ? (e.tip1.visible = !1, e.tip2.visible = !1) : (e.tip1.visible = !e.tip1.visible, e.tip2.visible = !e.tip1.visible)
                    })
                }
            }, {
                key: "enterframe",
                value: function () {
                    this.n3.rotation++, this.n9.rotation += .8, this.pause || (this.target_value -= .8, this.target_value < 0 && (this.target_value = 0), this.progress.value += .2 * (this.target_value - this.progress.value))
                }
            }, {
                key: "touch_banner_close",
                value: function () {
                    It.Int.off(yt.PLAT_TOUCH_BANNER_AD, this.touch_banner_close, this), mt.updateErrorCount(_t.BANNER), this.dispose(), this.callback && (this.callback(), this.callback = null)
                }
            }, {
                key: "btn_click",
                value: function () {
                    var e = this;
                    this.pause || (this.target_value += 20, this.target_value >= this.showBannerRatio && (mt.showBanner(), Laya.timer.once(300, this, function () {
                        mt.hideBanner()
                    }), 50 == this.showBannerRatio ? this.showBannerRatio = 75 : 75 == this.showBannerRatio ? this.showBannerRatio = 90 : this.target_value >= 100 && (this.pause = !0, this.progress.value = 100, mt.showRwdVideo("点击开宝箱").then(function (t) {
                        e.touch_banner_close()
                    }))), console.log("btn_click"))
                }
            }]), ClickGift
        }(),
        _ = function (e) {
            function MoreGameTT() {
                var e;
                return _classCallCheck(this, MoreGameTT), (e = _possibleConstructorReturn(this, _getPrototypeOf(MoreGameTT).apply(this, arguments))).callback = null, e._list = null, e.navigatedata = [], e
            }
            return _inherits(MoreGameTT, n), _createClass(MoreGameTT, [{
                key: "onCreate",
                value: function () {
                    mt.hideBanner(), this.getChild("btn_close").onClick(this, this.onClickCloseHandler), this._hotItem = this.getChild("btn_zuire"), this._newItem = this.getChild("btn_zuixin"), this.navigatedata = mt.getNavigateList(), this._list = this.getChild("list_icon").asList, this._list.itemRenderer = Laya.Handler.create(this, this.updataCellHandler, null, !1), this._list.numItems = this.navigatedata.length, this.initHotItem(), this.initNewItem()
                }
            }, {
                key: "initHotItem",
                value: function () {
                    for (var e = 0; e < this.navigatedata.length; e += 1) {
                        var t = this.navigatedata[e];
                        if (99 == t.weight) {
                            this._hotItem.updataData(t);
                            break
                        }
                        e == this.navigatedata.length - 1 && this._hotItem.updataData(this.navigatedata[0])
                    }
                }
            }, {
                key: "initNewItem",
                value: function () {
                    for (var e = 0; e < this.navigatedata.length; e += 1) {
                        var t = this.navigatedata[e];
                        if (88 == t.weight) {
                            this._newItem.updataData(t);
                            break
                        }
                        e == this.navigatedata.length - 1 && this._newItem.updataData(this.navigatedata[0])
                    }
                }
            }, {
                key: "updataCellHandler",
                value: function (e, t) {
                    t.updataData(this.navigatedata[e])
                }
            }, {
                key: "onClickCloseHandler",
                value: function () {
                    mt.showBanner(), this.dispose(), this.callback && (this.callback(), this.callback = null)
                }
            }]), MoreGameTT
        }();
    _.ServerConfigKey = "is_MoreGameBtn", _.IntervalDisplayAD = new s(_.ServerConfigKey);
    var y, p = function (e) {
            function AvdCellTTSmall() {
                return _classCallCheck(this, AvdCellTTSmall), _possibleConstructorReturn(this, _getPrototypeOf(AvdCellTTSmall).apply(this, arguments))
            }
            return _inherits(AvdCellTTSmall, n), _createClass(AvdCellTTSmall, [{
                key: "onCreate",
                value: function () {
                    this._icon = this.getChildByPath("comp_icon.loader_icon").asLoader, this._nameLab = this.getChildByPath("text_name").asTextField
                }
            }, {
                key: "onClickByView",
                value: function () {
                    var e = this;
                    this._data && (mt.navigateToMiniGame(this._data), this.touchable = !1, Laya.timer.once(100, this, function () {
                        e.touchable = !0
                    }))
                }
            }, {
                key: "updataData",
                value: function (e) {
                    this._data != e && (this._data = e, e && (this._icon.url = this.randomItem(e.iconPath), this._nameLab.text = e.name))
                }
            }]), AvdCellTTSmall
        }(),
        g = function (e) {
            function AvdCellTTItem() {
                return _classCallCheck(this, AvdCellTTItem), _possibleConstructorReturn(this, _getPrototypeOf(AvdCellTTItem).apply(this, arguments))
            }
            return _inherits(AvdCellTTItem, n), _createClass(AvdCellTTItem, [{
                key: "onCreate",
                value: function () {
                    this._icon = this.getChildByPath("btn_icon.loader_icon").asLoader, this._nameLab = this.getChildByPath("text_name").asTextField, this._controller = this.getController("c1")
                }
            }, {
                key: "onClickByView",
                value: function () {
                    var e = this;
                    this._data && (mt.navigateToMiniGame(this._data), this.touchable = !1, Laya.timer.once(100, this, function () {
                        e.touchable = !0
                    }))
                }
            }, {
                key: "updataData",
                value: function (e) {
                    this._data != e && (this._data = e, e && (this._icon.url = this.randomItem(e.iconPath), this._nameLab.text = e.name, 99 == this._data.weight ? this._controller.setSelectedIndex(1) : 88 == this._data.weight ? this._controller.setSelectedIndex(2) : this._controller.setSelectedIndex(0)))
                }
            }]), AvdCellTTItem
        }(),
        v = function (e) {
            function JumpGameBase() {
                return _classCallCheck(this, JumpGameBase), _possibleConstructorReturn(this, _getPrototypeOf(JumpGameBase).call(this))
            }
            return _inherits(JumpGameBase, fgui.GComponent), _createClass(JumpGameBase, [{
                key: "show",
                value: function (e) {
                    this._gameData = e, this.visible = !0
                }
            }, {
                key: "hide",
                value: function () {
                    this.visible = !1
                }
            }]), JumpGameBase
        }(),
        C = function (e) {
            function JumpGameList() {
                var e;
                return _classCallCheck(this, JumpGameList), (e = _possibleConstructorReturn(this, _getPrototypeOf(JumpGameList).apply(this, arguments))).isLoop = !0, e.isVirtual = !0, e.speed = 50, e._playerTouch = !1, e
            }
            return _inherits(JumpGameList, v), _createClass(JumpGameList, [{
                key: "addEvent",
                value: function () {
                    this.on(Laya.Event.MOUSE_DOWN, this, this._onMouseDown), this.on(Laya.Event.MOUSE_OVER, this, this._onMouseUp), this.on(Laya.Event.MOUSE_UP, this, this._onMouseUp), this.btn_close.onClick(this, this.hide)
                }
            }, {
                key: "removeEvent",
                value: function () {
                    this.off(Laya.Event.MOUSE_DOWN, this, this._onMouseDown), this.off(Laya.Event.MOUSE_OVER, this, this._onMouseUp), this.off(Laya.Event.MOUSE_UP, this, this._onMouseUp), this.btn_close.offClick(this, this.hide)
                }
            }, {
                key: "_onMouseDown",
                value: function () {
                    this._playerTouch = !0
                }
            }, {
                key: "_onMouseUp",
                value: function () {
                    this._playerTouch = !1
                }
            }, {
                key: "_onUpdate",
                value: function () {
                    if (!this._playerTouch && 0 != this.speed) {
                        var e = Laya.timer.delta;
                        this.direction == y.H ? this.list_game.scrollPane.posX += this.speed * e / 1e3 : this.direction == y.V && (this.list_game.scrollPane.posY += this.speed * e / 1e3)
                    }
                }
            }, {
                key: "_startTimer",
                value: function () {
                    Laya.timer.frameLoop(1, this, this._onUpdate)
                }
            }, {
                key: "_stopTimer",
                value: function () {
                    this.list_game.numItems && this.list_game.scrollToView(0, !1), Laya.timer.clear(this, this._onUpdate)
                }
            }, {
                key: "show",
                value: function (e) {
                    _get(_getPrototypeOf(JumpGameList.prototype), "show", this).call(this, e), this.list_game = this.getChild("list_game"), this.btn_close = this.getChild("btn_close"), this.isLoop ? this.list_game.setVirtualAndLoop() : this.isVirtual && this.list_game.setVirtual(), this.list_game.defaultItem = "ui://".concat(P.fguiJumpGame, "/JumpGameItem"), this.list_game.itemRenderer = Laya.Handler.create(this, this._itemRender, null, !1), this.list_game.numItems = this._gameData.length || 0, this.list_game.numItems > 0 && (this._stopTimer(), this._startTimer()), this.addEvent()
                }
            }, {
                key: "hide",
                value: function () {
                    this._stopTimer(), this.removeEvent(), _get(_getPrototypeOf(JumpGameList.prototype), "hide", this).call(this)
                }
            }, {
                key: "_itemRender",
                value: function (e, t) {
                    t.setData(this._gameData[e], !0)
                }
            }]), JumpGameList
        }();
    ! function (e) {
        e[e.H = 0] = "H", e[e.V = 1] = "V"
    }(y || (y = {}));
    var L, P = function () {
        function SDKViewMgr() {
            _classCallCheck(this, SDKViewMgr)
        }
        return _createClass(SDKViewMgr, null, [{
            key: "init",
            value: function () {
                for (var e = this, t = arguments.length, n = new Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                return new Promise(function (t, i) {
                    if (n && n.length) {
                        var a = 0,
                            o = function () {
                                a <= 0 && t()
                            };
                        o.bind(e), n.indexOf(e.pkgGameSDK) >= 0 && (a++, e._registGameSDK().then(function () {
                            a--, o()
                        })), n.indexOf(e.pkgJumpGame) >= 0 && (a++, e._registJumpGame().then(function () {
                            a--, o()
                        })), o()
                    } else t()
                })
            }
        }, {
            key: "_registJumpGame",
            value: function () {
                var e = this;
                return new Promise(function (t, n) {
						fgui.UIPackage.loadPackage(e.fguiUrl + e.fguiJumpGame, Laya.Handler.create(e, function () {
                        t()
                    }))
                })
            }
        }, {
            key: "_registGameSDK",
            value: function () {
                var e = this;
                return new Promise(function (t, n) {
                    e._registfguiClass(e.pkgGameSDK + "moreBtn", r), e._registfguiClass(e.pkgGameSDK + "FloatAd", a), e._registfguiClass(e.pkgGameSDK + "EndListAd", o), e._registfguiClass(e.pkgGameSDK + "boxItemBig", i), e._registfguiClass(e.pkgGameSDK + "boxItemSmall", i), e._registfguiClass(e.pkgGameSDK + "btn_small", p), e._registfguiClass(e.pkgGameSDK + "comp_iconzhanshi", g), e._registfguiClass(e.pkgGameSDK + "com_screen_big", l), e._registfguiClass(e.pkgGameSDK + "com_screen_small", l), e._registfguiClass(e.pkgGameSDK + "com_clickgift", f), e._registfguiClass(e.pkgGameSDK + "comp_douyinhudao", _), e._registfguiClass(e.pkgGameSDK + "NativeAdBanner", u), e._registfguiClass(e.pkgGameSDK + "Native", c), e._registfguiClass(e.pkgGameSDK + "addDesk", h), fgui.UIPackage.loadPackage(e.fguiUrl + e.fguiGameSDK, Laya.Handler.create(e, function () {
                        t()
                    }))
                })
            }
        }, {
            key: "_registfguiClass",
            value: function (e, t) {
                fgui.UIObjectFactory.setExtension(e, t)
            }
        }, {
            key: "createObject",
            value: function (e, t) {
                return fairygui.UIPackage.createObject(e, t)
            }
        }, {
            key: "createNavigateCustom",
            value: function (e) {
                var t;
                switch (e) {
                    case Ct.Left_Grid:
                    case Ct.Right_Grid:
                        (t = this.createObject(this.fguiJumpGame, "JumpGameSingle")).x = e == Ct.Left_Grid ? 0 : Laya.stage.width - t.width;
                        break;
                    case Ct.Bottom_Roll:
                        (t = this.createObject(this.fguiJumpGame, "JumpGameRows")).x = (Laya.stage.width - t.width) / 2, t.y = Laya.stage.height - t.height;
                        break;
                    case Ct.Grid9:
                        (t = this.createObject(this.fguiJumpGame, "JumpGameRect")).x = (Laya.stage.width - t.width) / 2
                }
                return t
            }
        }, {
            key: "popUpView",
            value: function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Number.MAX_SAFE_INTEGER;
                if (e != ct.BigItem || l.IntervalDisplayAD.has()) {
                    var i = this.createObject(this.fguiGameSDK, e == ct.BigItem ? "com_screen_big" : "com_screen_small");
                    i.setCallback(n, t), i.makeFullScreen(), fairygui.GRoot.inst.addChild(i)
                } else t && t()
            }
        }, {
            key: "flowView",
            value: function () {}
        }, {
            key: "clickgift",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                    t = this.createObject(this.fguiGameSDK, "com_clickgift");
                t.makeFullScreen(), t.callback = e, fairygui.GRoot.inst.addChild(t)
            }
        }, {
            key: "moreView",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0;
                 e && e()
            }
        }, {
            key: "showNativeUI",
            value: function (e, t, n, i, a, o, s, r) {
                var l = e.getChild(t);
                console.log("注册原生广告事件成功 level:", a), l.showNativeView ? l.showNativeView(e.getChild(n).asButton, e.getChild(i).asButton, function () {
                    console.log("广告-点击继续"), o && o()
                }, function () {
                    s && s()
                }, function () {
                    r && r()
                }, a) : (console.log("没有注册原生广告 直接回调"), o && o())
            }
        }, {
            key: "inst",
            get: function () {
                return this._inst || (this._inst = new SDKViewMgr), this._inst
            }
        }]), SDKViewMgr
    }();

    function __decorate(e, t, n, i) {
        var a, o = arguments.length,
            s = o < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
        if ("object" === ("undefined" == typeof Reflect ? "undefined" : _typeof(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, n, i);
        else
            for (var r = e.length - 1; r >= 0; r--)(a = e[r]) && (s = (o < 3 ? a(s) : o > 3 ? a(t, n, s) : a(t, n)) || s);
        return o > 3 && s && Object.defineProperty(t, n, s), s
    }
    P.fguiUrl = "fui/", P.fguiGameSDK = "gamesdk", P.fguiJumpGame = "jumpgame", P.pkgGameSDK = "ui://".concat(P.fguiGameSDK, "/"), P.pkgJumpGame = "ui://".concat(P.fguiJumpGame, "/"),
        function (e) {
            e[e.Web = 0] = "Web", e[e.WX = 1] = "WX", e[e.QQ = 2] = "QQ", e[e.OPPO = 3] = "OPPO", e[e.VIVO = 4] = "VIVO", e[e.Ali = 5] = "Ali", e[e.XM = 6] = "XM", e[e.TT = 7] = "TT"
        }(L || (L = {}));
    var A = function () {
        function Global() {
            _classCallCheck(this, Global)
        }
        return _createClass(Global, null, [{
            key: "AddMapItem",
            value: function (e) {
                this.MapNode.addChild(e)
            }
        }, {
            key: "ClearNode",
            value: function () {
                for (var e = this.MapNode.numChildren - 1; e >= 0; e--) {
                    var t = this.MapNode.getChildAt(e);
                    this.MapNode.removeChildAt(e), t.destroy(!0)
                }
            }
        }, {
            key: "setAddNum",
            value: function (e, t) {
                for (var n = e.getChildByName("number"), i = 0; i < n.numChildren; i++) n.getChildAt(i).active = i == t
            }
        }, {
            key: "Platform",
            get: function () {
                var e = window.navigator.userAgent;
                return e.indexOf("AlipayMiniGame") > -1 && "my" in window && (this._platform = L.Ali), -1 == e.indexOf("OPPO") && e.indexOf("MiniGame") > -1 && "wx" in window && ("qq" in window ? this._platform = L.QQ : this._platform = L.WX), e.indexOf("MiniGame") > -1 && "qq" in window && (this._platform = L.QQ), e.indexOf("QuickGame") > -1 && (this._platform = L.XM), e.indexOf("OPPO") > -1 && e.indexOf("MiniGame") > -1 && (this._platform = L.OPPO), e.indexOf("VVGame") > -1 && (this._platform = L.VIVO), null != window.tt && (this._platform = L.TT), this._platform
            }
        }, {
            key: "PlatformInst",
            get: function () {
                switch (this.Platform) {
                    case L.WX:
                        return window.wx;
                    case L.QQ:
                        return window.qq;
                    case L.TT:
                        return window.tt;
                    case L.OPPO:
                    case L.VIVO:
                        return window.qg;
                    default:
                        return window.wx
                }
            }
        }, {
            key: "deltaTime",
            get: function () {
                return this._recordFrame != Laya.timer.currFrame && (this._deltaTime = Math.min(Laya.timer.delta, 100)), this._deltaTime
            }
        }, {
            key: "speed",
            get: function () {
                return this._speed
            },
            set: function (e) {
                this._speed = e
            }
        }]), Global
    }();
    A.openLevelLock = !0, A._platform = L.Web, A.IOS = !1, A.soundDir = "audio/", A.texturePathDir = "texture/", A.prefabPathDir = "prefab/LayaScene_Prefab/Conventional/", A.DominoCarDistance = 1.4, A.up = new Laya.Vector3(0, 1, 0), A._recordFrame = 0, A._deltaTime = 30, A.Playing = !1, A.CatchSlaveSqrDis = .9, A.initSpeed = 6, A._speed = A.initSpeed, A.CollectCoin = 0, A.PlugGroup = Laya.Physics3DUtils.COLLISIONFILTERGROUP_CUSTOMFILTER1, A.PlaneGroup = Laya.Physics3DUtils.COLLISIONFILTERGROUP_CUSTOMFILTER2, A.SocketHoleRes = "dogface_socket", A.PlugModelRes = "dogface_plug", A.LevelEndSlaveCount = 0, A.FakeLevel = null, A.CollectProgress = 25, A.playerPos = new Laya.Vector3;
    var w = function () {
        function ProgressPromise(e) {
            var t = this;
            _classCallCheck(this, ProgressPromise), this.state = 0, this.callbacks = [], this.resolve = function (e) {
                0 == t.state && (t.state = 1, t.result = e, t.callbacks.forEach(function (e) {
                    e.onResolve(t.result)
                }))
            }, this._progress = function (e) {
                t.progressCall && t.progressCall(e)
            }, this.reject = function (e) {
                if (0 == t.state) {
                    if (t.state = 2, t.reason = e, 0 == t.callbacks.length) throw t.reason;
                    t.callbacks.forEach(function (t) {
                        t.onReject(e)
                    })
                }
            }, this.catch = function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ProgressPromise.defaultOnReject;
                return t.then(void 0, e)
            }, e(this.resolve, this._progress, this.reject)
        }
        return _createClass(ProgressPromise, [{
            key: "progress",
            value: function (e) {
                return this.progressCall = e, this
            }
        }, {
            key: "then",
            value: function () {
                var e = this,
                    t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ProgressPromise.defaultOnResolve,
                    n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ProgressPromise.defaultOnReject;
                return new ProgressPromise(function (i, a, o) {
                    setTimeout(function () {
                        if (1 === e.state) try {
                            var a = t(e.result);
                            a instanceof ProgressPromise ? a.then(i, o) : i(a)
                        } catch (e) {
                            o(e)
                        } else if (2 === e.state) try {
                            var s = n(e.result);
                            s instanceof ProgressPromise ? s.then(i, o) : i(s)
                        } catch (e) {
                            o(e)
                        } else 0 === e.state && e.callbacks.push({
                            onResolve: function () {
                                try {
                                    var n = t(e.result);
                                    n instanceof ProgressPromise ? n.then(i, o) : i(n)
                                } catch (e) {
                                    o(e)
                                }
                            },
                            onReject: function () {
                                try {
                                    var t = n(e.reason);
                                    t instanceof ProgressPromise ? t.then(i, o) : i(t)
                                } catch (e) {
                                    o(e)
                                }
                            }
                        })
                    })
                })
            }
        }]), ProgressPromise
    }();
    w.defaultOnResolve = function (e) {
        return e
    }, w.defaultOnReject = function (e) {
        throw e
    };
    var U = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        D = function (e) {
            function InvalidCharacterError() {
                var e;
                return _classCallCheck(this, InvalidCharacterError), (e = _possibleConstructorReturn(this, _getPrototypeOf(InvalidCharacterError).apply(this, arguments))).name = "InvalidCharacterError", e
            }
            return _inherits(InvalidCharacterError, _wrapNativeSuper(Error)), InvalidCharacterError
        }(),
        M = function () {
            function Utils() {
                _classCallCheck(this, Utils)
            }
            return _createClass(Utils, null, [{
                key: "Shuffle",
                value: function (e) {
                    for (var t = e.length; t; t--) {
                        var n = Math.floor(Math.random() * t),
                            i = [e[n], e[t - 1]];
                        e[t - 1] = i[0], e[n] = i[1]
                    }
                    return e
                }
            }, {
                key: "GetDate",
                value: function () {
                    var e = new Date;
                    return e.getFullYear() + "年" + (e.getMonth() + 1) + "月" + e.getDate() + "日"
                }
            }, {
                key: "TimeToString",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = Math.floor(e / 1e3),
                        i = n % 60,
                        a = Math.floor(n / 60) % 60,
                        o = Math.floor(n / 3600) % 24;
                    return 0 == t ? Utils.formatNumber(a) + ":" + Utils.formatNumber(i) : Utils.formatNumber(o) + "小时" + Utils.formatNumber(a) + "分钟" + Utils.formatNumber(i) + "秒"
                }
            }, {
                key: "formatNumber",
                value: function (e) {
                    var t = e.toString();
                    return t[1] ? t : "0" + t
                }
            }, {
                key: "rand",
                value: function (e) {
                    return null == e || 0 == e.length ? null : e[Math.floor(Math.random() * e.length)]
                }
            }, {
                key: "randByWeight",
                value: function () {
                    for (var e = 0, t = 0; t < arguments.length; t++) e += Number(t < 0 || arguments.length <= t ? void 0 : arguments[t]);
                    var n = Math.random() * e,
                        i = 0;
                    for (t = 0; t < arguments.length; t++) {
                        var a = i;
                        if (i += Number(t < 0 || arguments.length <= t ? void 0 : arguments[t]), n >= a && n <= i) return t
                    }
                    return 0
                }
            }, {
                key: "randIntRange",
                value: function (e, t) {
                    return Math.round(e + Math.random() * (t - e))
                }
            }, {
                key: "hexToRgba01",
                value: function (e) {
                    return new Laya.Vector4(parseInt("0x" + e.slice(1, 3)) / 255, parseInt("0x" + e.slice(3, 5)) / 255, parseInt("0x" + e.slice(5, 7)) / 255, 1)
                }
            }, {
                key: "rgb01ToHex",
                value: function (e, t, n) {
                    return "#" + ((e = Math.min(255, Math.round(255 * e))) << 16 | (t = Math.min(255, Math.round(255 * t))) << 8 | (n = Math.min(255, Math.round(255 * n)))).toString(16)
                }
            }, {
                key: "rgb255ToHex",
                value: function (e, t, n) {
                    return "#" + (e << 16 | t << 8 | n).toString(16)
                }
            }, {
                key: "hexToRgb01",
                value: function (e) {
                    return new Laya.Vector3(parseInt("0x" + e.slice(1, 3)) / 255, parseInt("0x" + e.slice(3, 5)) / 255, parseInt("0x" + e.slice(5, 7)) / 255)
                }
            }, {
                key: "rgb255Torgb01",
                value: function (e) {
                    return e.x /= 255, e.y /= 255, e.z /= 255, e
                }
            }, {
                key: "Angle2",
                value: function (e, t) {
                    var n = (e.x * t.x + e.y * t.y + e.z * t.z) / (Math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z) * Math.sqrt(t.x * t.x + t.y * t.y + t.z * t.z));
                    return n < -1 && (n = -1), n > 1 && (n = 1), 180 * Math.acos(n) / Math.PI
                }
            }, {
                key: "Save",
                value: function (e, t) {
                    var n = Laya.Browser.document.createElement("a");
                    n.download = t, n.style.display = "none";
                    var i = new Blob([JSON.stringify(e)]);
                    n.href = URL.createObjectURL(i), document.body.appendChild(n), n.click(), document.body.removeChild(n)
                }
            }, {
                key: "SaveArray",
                value: function (e, t) {
                    var n = Laya.Browser.document.createElement("a");
                    n.download = t, n.style.display = "none", new ArrayBuffer(4 * e.length);
                    var i = new Blob([e]);
                    n.href = URL.createObjectURL(i), document.body.appendChild(n), n.click(), document.body.removeChild(n)
                }
            }, {
                key: "vibrateShort",
                value: function () {
                    var e = window.wx;
                    e = null == e ? e = window.qq : e, window.qg && (e = window.qg), e && null != e.vibrateShort && Laya.timer.callLater(e, e.vibrateShort)
                }
            }, {
                key: "vibrateLong",
                value: function () {
                    var e = window.wx;
                    e = null == e ? e = window.qq : e, window.qg && (e = window.qg), e && null != e.vibrateLong && Laya.timer.callLater(e, e.vibrateLong)
                }
            }, {
                key: "LoadPrefab",
                value: function (e) {
                    var t = this;
                    return new Promise(function (n) {
                        Laya.Sprite3D.load("".concat(A.prefabPathDir).concat(e, ".lh"), Laya.Handler.create(t, function (e) {
                            e = Laya.Sprite3D.instantiate(e);
                            n(e)
                        }))
                    })
                }
            }, {
                key: "getTodayMS",
                value: function () {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                        i = new Date;
                    return i.setHours(e, t, n, 0), i.getTime()
                }
            }, {
                key: "WaitFrame",
                value: function (e) {
                    return new Promise(function (t) {
                        Laya.timer.frameOnce(e, null, t)
                    })
                }
            }, {
                key: "WaitTime",
                value: function (e) {
                    return new Promise(function (t) {
                        e <= 0 ? t() : setTimeout(t, e)
                    })
                }
            }, {
                key: "WaitWithBlock",
                value: function (e) {
                    return new Promise(function (t) {
                        Laya.timer.frameLoop(1, null, function frameLoop() {
                            Laya.timer.delta, e() && (Laya.timer.clear(null, frameLoop), t())
                        })
                    })
                }
            }, {
                key: "WaitTimeWithBlock",
                value: function (e, t) {
                    return new Promise(function (n) {
                        var i = 0;
                        Laya.timer.frameLoop(1, null, function frameLoop() {
                            var a = Math.min(100, Laya.timer.delta);
                            ((i += a) >= e || t()) && (Laya.timer.clear(null, frameLoop), n())
                        })
                    })
                }
            }, {
                key: "WaitTimeWithDuartionCall",
                value: function (e, t, n) {
                    return new Promise(function (i) {
                        var a = 0,
                            o = 0;
                        n();
                        Laya.timer.frameLoop(1, null, function frameLoop() {
                            var s = Math.min(100, Laya.timer.delta);
                            a += s, (o += s) >= t && (o -= t, 0 == n() && (Laya.timer.clear(null, frameLoop), i()));
                            e > 0 && a >= e && (Laya.timer.clear(null, frameLoop), i())
                        })
                    })
                }
            }, {
                key: "WaitAnimation",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                    return new Promise(function (n) {
                        null != e ? e.play(Laya.Handler.create(null, n), t) : n()
                    })
                }
            }, {
                key: "LoadSubPKG",
                value: function (e, t) {
                    return new w(function (t, n, i) {
                        var a = window.wx;
                        (a = null == a ? a = window.qq : a, window.qg && (a = window.qg), null != a && null != a.loadSubpackage) ? a.loadSubpackage({
                            name: e,
                            success: function (n) {
                                console.log(e, "加载成功" + n), t()
                            },
                            fail: function (t) {
                                console.log(e, "加载失败" + t), i(t)
                            }
                        }).onProgressUpdate(function (e) {
                            n(e.totalBytesWritten / e.totalBytesExpectedToWrite)
                        }): t()
                    })
                }
            }, {
                key: "LoadSubPKGs",
                value: function (e) {
                    return new w(function (e, t, n) {})
                }
            }, {
                key: "PromiseQueue",
                value: function (e) {
                    for (var t = Promise.resolve(e), n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                    return i && i.forEach(function (e) {
                        t = t.then(e)
                    }), t
                }
            }, {
                key: "SaveImgToTempPath",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                    return new Promise(function (n) {
                        var i = window.wx;
                        if (null != i) {
                            var a = (t = null == t ? e.toBase64("image/png", 1) : t).indexOf("base64,") + 7,
                                o = i.getFileSystemManager(),
                                s = Utils.CurrentTime,
                                r = i.env.USER_DATA_PATH + "/pic" + s + ".png";
                            o.writeFile({
                                filePath: r,
                                data: t.slice(a),
                                encoding: "base64",
                                success: function (e) {
                                    n(r)
                                },
                                fail: function (e) {
                                    console.log(e), n(null)
                                }
                            })
                        } else n(null)
                    })
                }
            }, {
                key: "OppoSaveImgToTempPath",
                value: function (e) {
                    return new Promise(function (t) {
                        var n = window.wx;
                        if (null != n) {
                            var i = n.getFileSystemManager(),
                                a = Utils.CurrentTime,
                                o = n.env.USER_DATA_PATH + "/pic" + a + ".png";
                            i.writeFile({
                                filePath: o,
                                data: e,
                                encoding: "binary",
                                success: function (e) {
                                    t(o)
                                },
                                fail: function (e) {
                                    console.log(e), t(null)
                                }
                            })
                        } else t(null)
                    })
                }
            }, {
                key: "SaveImgToPhotosAlbum",
                value: function (e) {
                    return new Promise(function (t) {
                        var n = A.PlatformInst;
                        null != n ? n.saveImageToPhotosAlbum({
                            filePath: e,
                            success: function (e) {
                                n.showToast({
                                    title: "保存成功"
                                }), n.showToast({
                                    title: "保存成功"
                                }), t(!0)
                            },
                            fail: function (e) {
                                t(!1), console.log(e)
                            }
                        }) : t(!1)
                    })
                }
            }, {
                key: "btoa",
                value: function (e) {
                    for (var t, n, i = String(e), a = 0, o = U, s = ""; i.charAt(0 | a) || (o = "=", a % 1); s += o.charAt(63 & t >> 8 - a % 1 * 8)) {
                        if ((n = i.charCodeAt(a += .75)) > 255) throw new D("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
                        t = t << 8 | n
                    }
                    return s
                }
            }, {
                key: "atob",
                value: function (e) {
                    var t = String(e).replace(/[=]+$/, "");
                    if (t.length % 4 == 1) throw new D("'atob' failed: The string to be decoded is not correctly encoded.");
                    for (var n, i, a = 0, o = 0, s = ""; i = t.charAt(o++); ~i && (n = a % 4 ? 64 * n + i : i, a++ % 4) ? s += String.fromCharCode(255 & n >> (-2 * a & 6)) : 0) i = U.indexOf(i);
                    return s
                }
            }, {
                key: "DistancePointWithLine",
                value: function (e, t, n) {
                    return Math.abs(this.SignDistancePointWithLine(e, t, n))
                }
            }, {
                key: "PointToSegmentDist",
                value: function (e, t, n) {
                    var i = (n.x - t.x) * (e.x - t.x) + (n.y - t.y) * (e.y - t.y);
                    if (i <= 0) return Math.sqrt((e.x - t.x) * (e.x - t.x) + (e.y - t.y) * (e.y - t.y));
                    var a = (n.x - t.x) * (n.x - t.x) + (n.y - t.y) * (n.y - t.y);
                    if (i >= a) return Math.sqrt((e.x - n.x) * (e.x - n.x) + (e.y - n.y) * (e.y - n.y));
                    var o = i / a,
                        s = t.x + (n.x - t.x) * o,
                        r = t.y + (n.y - t.y) * o;
                    return Math.sqrt((e.x - s) * (e.x - s) + (r - e.y) * (r - e.y))
                }
            }, {
                key: "PointToSegmentDist2",
                value: function (e, t, n, i, a, o) {
                    var s = (a - n) * (e - n) + (o - i) * (t - i);
                    if (s <= 0) return Math.sqrt((e - n) * (e - n) + (t - i) * (t - i));
                    var r = (a - n) * (a - n) + (o - i) * (o - i);
                    if (s >= r) return Math.sqrt((e - a) * (e - a) + (t - o) * (t - o));
                    var l = s / r,
                        u = n + (a - n) * l,
                        h = i + (o - i) * l;
                    return Math.sqrt((e - u) * (e - u) + (h - t) * (h - t))
                }
            }, {
                key: "SignDistancePointWithLine",
                value: function (e, t, n) {
                    var i = new Laya.Vector3;
                    Laya.Vector3.subtract(e, t, i);
                    var a = new Laya.Vector3(-n.z, 0, n.x);
                    return Laya.Vector3.cross(new Laya.Vector3(0, 0, 1), n, a), Laya.Vector3.normalize(a, a), Laya.Vector3.dot(i, a)
                }
            }, {
                key: "CheckSegmentLineIntersect",
                value: function (e, t, n, i) {
                    var a = this.SignDistancePointWithLine(e, n, i),
                        o = this.SignDistancePointWithLine(t, n, i);
                    return !(!Laya.MathUtils3D.isZero(a) && !Laya.MathUtils3D.isZero(o)) || Math.sign(a) != Math.sign(o)
                }
            }, {
                key: "SegmentLineIntersectPos",
                value: function (e, t, n, i) {
                    var a = this.DistancePointWithLine(e, n, i),
                        o = new Laya.Vector3;
                    Laya.Vector3.add(e, t, o);
                    var s = a / (a + this.DistancePointWithLine(o, n, i)),
                        r = new Laya.Vector3;
                    return Laya.Vector3.scale(t, s, r), Laya.Vector3.add(e, r, r), r
                }
            }, {
                key: "LineIntersectPos",
                value: function (e, t, n, i) {
                    var a = new Laya.Vector3;
                    Laya.Vector3.subtract(n, e, a);
                    var o = t.x * i.y - t.y * i.x,
                        s = (a.x * i.y - a.y * i.x) / o;
                    return Laya.Vector3.scale(t, s, t), Laya.Vector3.add(e, t, a), a
                }
            }, {
                key: "AngleLerpWithSpeed",
                value: function (e, t, n, i) {
                    var a = t - e;
                    a < -180 ? a += 360 : a > 180 && (a -= 360);
                    var o = n;
                    return a < 0 && (o = -n), (e += o * i) > 360 && (e -= 360), e < 0 && (e += 360), e
                }
            }, {
                key: "AngleLerp",
                value: function (e, t, n) {
                    var i = t - e;
                    return i < -180 ? i += 360 : i > 180 && (i -= 360), (e += i * n) > 360 && (e -= 360), e < 0 && (e += 360), e
                }
            }, {
                key: "GetAllSKinMeshRender",
                value: function (e, t) {
                    if (e instanceof Laya.SkinnedMeshSprite3D) {
                        var n = e.skinnedMeshRenderer;
                        t.push(n)
                    }
                    if (e instanceof Laya.SimpleSkinnedMeshSprite3D) {
                        var i = e.simpleSkinnedMeshRenderer;
                        t.push(i)
                    }
                    for (var a = 0; a < e.numChildren; a++) {
                        var o = e.getChildAt(a);
                        this.GetAllSKinMeshRender(o, t)
                    }
                }
            }, {
                key: "GetAllMeshRenderer",
                value: function (e, t) {
                    if (e instanceof Laya.MeshSprite3D) {
                        var n = e.meshRenderer;
                        t.push(n)
                    }
                    for (var i = 0; i < e.numChildren; i++) {
                        var a = e.getChildAt(i);
                        this.GetAllMeshRenderer(a, t)
                    }
                }
            }, {
                key: "SetAllMeshRendererMat",
                value: function (e, t) {
                    e instanceof Laya.MeshSprite3D && (e.meshRenderer.sharedMaterial = t);
                    for (var n = 0; n < e.numChildren; n++) {
                        var i = e.getChildAt(n);
                        this.SetAllMeshRendererMat(i, t)
                    }
                }
            }, {
                key: "SetUnlitColor",
                value: function (e, t) {
                    if (e instanceof Laya.MeshSprite3D) e.meshRenderer.material.albedoColor = t;
                    else if (e instanceof Laya.SkinnedMeshSprite3D) {
                        e.skinnedMeshRenderer.material.albedoColor = t
                    }
                    for (var n = 0; n < e.numChildren; n++) {
                        var i = e.getChildAt(n);
                        this.SetUnlitColor(i, t)
                    }
                }
            }, {
                key: "GetAllPlugMeshRenderer",
                value: function (e, t) {
                    if ("model" != e.name && e instanceof Laya.MeshSprite3D) {
                        var n = e.meshRenderer;
                        t.push(n)
                    }
                    for (var i = 0; i < e.numChildren; i++) {
                        var a = e.getChildAt(i);
                        "model" != a.name && this.GetAllPlugMeshRenderer(a, t)
                    }
                }
            }, {
                key: "GetAllModelMeshRenderer",
                value: function (e, t) {
                    if ("model" == e.name && e instanceof Laya.MeshSprite3D) {
                        var n = e.meshRenderer;
                        t.push(n)
                    }
                    for (var i = 0; i < e.numChildren; i++) {
                        var a = e.getChildAt(i);
                        "model" == a.name && this.GetAllPlugMeshRenderer(a, t)
                    }
                }
            }, {
                key: "SetPhysicEnabled",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        n = e.getComponent(Laya.PhysicsCollider);
                    null != n && (n.enabled = t);
                    var i = e.getComponent(Laya.Rigidbody3D);
                    null != i && (i.enabled = t);
                    for (var a = 0; a < e.numChildren; a++) this.SetPhysicEnabled(e.getChildAt(a), t)
                }
            }, {
                key: "SetPhysicGroup",
                value: function (e, t) {
                    var n = e.getComponent(Laya.PhysicsCollider);
                    null != n && (n.collisionGroup = t);
                    var i = e.getComponent(Laya.Rigidbody3D);
                    null != i && (i.collisionGroup = t);
                    for (var a = 0; a < e.numChildren; a++) this.SetPhysicGroup(e.getChildAt(a), t)
                }
            }, {
                key: "SetPhysicCanWithGroup",
                value: function (e, t) {
                    var n = e.getComponent(Laya.PhysicsCollider);
                    null != n && (n.canCollideWith = t);
                    var i = e.getComponent(Laya.Rigidbody3D);
                    null != i && (i.canCollideWith = t);
                    for (var a = 0; a < e.numChildren; a++) this.SetPhysicCanWithGroup(e.getChildAt(a), t)
                }
            }, {
                key: "ParseVector3",
                value: function (e) {
                    var t = e.split(",");
                    return new Laya.Vector3(Number(t[0]), Number(t[1]), Number(t[2]))
                }
            }, {
                key: "GetNode",
                value: function (e, t) {
                    if (e.name == t) return e;
                    if (0 == e.numChildren) return null;
                    var n = e.getChildByName(t);
                    if (null != n) return n;
                    for (var i = 0; i < e.numChildren; i++) {
                        var a = this.GetNode(e.getChildAt(i), t);
                        if (null != a) return a
                    }
                }
            }, {
                key: "TimeToStringMS",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = Math.floor(e / 1e3),
                        i = n % 60,
                        a = Math.round(e % 1e3 / 1e3 * 100),
                        o = Math.floor(n / 60) % 60;
                    return 0 == t ? Utils.formatNumber(o) + ":" + Utils.formatNumber(i) + ":" + Utils.formatNumber(a) : Utils.formatNumber(o) + "小时" + Utils.formatNumber(i) + "分钟" + Utils.formatNumber(a) + "秒"
                }
            }, {
                key: "TimeToStringMS2",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                        n = Math.floor(e / 1e3),
                        i = n % 60,
                        a = Math.round(e % 1e3 / 1e3 * 100),
                        o = Math.floor(n / 60) % 60,
                        s = Math.floor(n / 3600) % 24;
                    return 0 == t ? Utils.formatNumber(s) + ":" + Utils.formatNumber(o) + ":" + Utils.formatNumber(i) : Utils.formatNumber(o) + "小时" + Utils.formatNumber(i) + "分钟" + Utils.formatNumber(a) + "秒"
                }
            }, {
                key: "SetFXColor",
                value: function (e, t) {
                    e instanceof Laya.ShuriKenParticle3D && (e.particleRenderer.material.color = t);
                    for (var n = 0; n < e.numChildren; n++) this.SetFXColor(e.getChildAt(n), t)
                }
            }, {
                key: "AddComponent",
                value: function (e, t) {
                    return e.addComponent(t)
                }
            }, {
                key: "truncate",
                value: function (e, t, n) {
                    Laya.Vector3.scalarLengthSquared(e) > t * t ? (Laya.Vector3.normalize(e, n), Laya.Vector3.scale(n, t, n)) : e.cloneTo(n)
                }
            }, {
                key: "setScalarLen",
                value: function (e, t, n) {
                    Laya.Vector3.normalize(e, n), Laya.Vector3.scale(n, t, n)
                }
            }, {
                key: "TodayMS",
                get: function () {
                    var e = new Date;
                    return e.setHours(0, 0, 0, 0), e.getTime()
                }
            }, {
                key: "CurrentTime",
                get: function () {
                    return (new Date).getTime()
                }
            }, {
                key: "safeArea",
                get: function () {
                    if (null == this._safeArea) {
                        var e = window.wx || window.tt || window.qg || window.qq;
                        null != e && null != e.getSystemInfoSync ? this._safeArea = e.getSystemInfoSync().safeArea : (this._safeArea = new E, console.log(this._safeArea))
                    }
                    return this._safeArea
                }
            }]), Utils
        }();
    M.isNextLevel = !1;
    var E = function SafeArea() {
        _classCallCheck(this, SafeArea), this.bottom = this.height = Laya.Browser.clientHeight, this.top = 0, this.left = 0, this.right = this.width = Laya.Browser.clientWidth
    };

    function throttle() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 300;
        return function (t, n, i) {
            var a = i.value,
                o = !1;
            return i.value = function () {
                if (!o) {
                    o = !0, setTimeout(function () {
                        o = !1
                    }, e);
                    for (var t = arguments.length, n = new Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                    a.apply(this, n)
                }
            }, i
        }
    }
    var R = function () {
        function LocalStorage() {
            _classCallCheck(this, LocalStorage)
        }
        return _createClass(LocalStorage, null, [{
            key: "setItem",
            value: function (e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                (this.cache[e] != t || n) && (null == t || "" == t ? (Laya.LocalStorage.removeItem(e), delete this.cache[e]) : Laya.LocalStorage.setItem(e, JSON.stringify(t))), this.cache[e] = t, null != t && "" != t || delete this.cache[e]
            }
        }, {
            key: "getItem",
            value: function (e) {
                if (null == this.cache[e]) {
                    var t = Laya.LocalStorage.getItem(e);
                    null != t && "" != t && this.isJSON(t) ? this.cache[e] = JSON.parse(t) : this.cache[e] = t
                }
                return this.cache[e]
            }
        }, {
            key: "isJSON",
            value: function (e) {
                if ("string" == typeof e) try {
                    JSON.parse(e);
                    return !0
                } catch (e) {
                    return !1
                }
            }
        }, {
            key: "clear",
            value: function () {
                Laya.LocalStorage.clear()
            }
        }, {
            key: "removeItem",
            value: function (e) {
                delete this.cache[e], Laya.LocalStorage.removeItem(e)
            }
        }, {
            key: "Cache",
            get: function () {
                return this.cache
            },
            set: function (e) {
                var t = this;
                Object.keys(this.cache).forEach(function (n) {
                    e[n] = t.cache[n]
                }), this.cache = e, Object.keys(e).forEach(function (e) {
                    LocalStorage.setItem(e, t.cache[e], !0)
                })
            }
        }]), LocalStorage
    }();
    R.cache = {};
    var x, O = function () {
            function Singleton() {
                _classCallCheck(this, Singleton)
            }
            return _createClass(Singleton, null, [{
                key: "getInst",
                value: function () {
                    return this.instance || (this.instance = new this), this.instance
                }
            }]), Singleton
        }(),
        N = function (e) {
            function MsgManager() {
                var e;
                return _classCallCheck(this, MsgManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(MsgManager).call(this))).ed = new Laya.EventDispatcher, e
            }
            return _inherits(MsgManager, O), _createClass(MsgManager, [{
                key: "event",
                value: function (e) {
                    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                    this.ed.event(e, n)
                }
            }, {
                key: "on",
                value: function (e, t, n) {
                    this.ed.on(e, t, n)
                }
            }, {
                key: "off",
                value: function (e, t, n) {
                    this.ed.off(e, t, n)
                }
            }, {
                key: "offAll",
                value: function (e) {
                    this.ed.offAll(e)
                }
            }, {
                key: "offAllCaller",
                value: function (e) {
                    this.ed.offAllCaller(e)
                }
            }, {
                key: "HasListener",
                value: function (e) {
                    return this.ed.hasListener(e)
                }
            }]), MsgManager
        }();
    N.Setting = "Setting",
        function (e) {
            e.Setting = "Setting", e.PreBuildNodeNotice = "PreBuildNodeNotice", e.PreBuildPrefabNodeNotice = "PreBuildPrefabNodeNotice", e.BuildNodeNotice = "BuildNodeNotice", e.BuildPrefabNodeNotice = "BuildPrefabNodeNotice", e.BuildNodeCompletedNotice = "BuildNodeCompletedNotice", e.BuildPrefabNodeCompletedNotice = "buildPrefabNodeCompletedNotice", e.ZiChanUpdate = "ZiChanUpdate", e.WxShareFriend = "WxShareFriend"
        }(x || (x = {}));
    var B = function () {
            function SubPKGLoader() {
                _classCallCheck(this, SubPKGLoader), this.pkgProgress = {}, this.pkgLoadTag = {}, this._loadSub = [], this.inst = window.wx, this.inst = null == this.inst ? this.inst = window.qq : this.inst, window.qg && (this.inst = window.qg)
            }
            return _createClass(SubPKGLoader, [{
                key: "Load",
                value: function (e) {
                    return Promise.resolve()
                }
            }, {
                key: "loadSubPkg",
                value: function (e) {
                    var t = this;
                    if (null == this.inst) return this.loadSubPkgProgress(e, 1), void this.loadSubPkgSuccess(e);
                    var n = function () {
                            t.loadSubPkgSuccess(e)
                        },
                        i = function (n) {
                            t.loadSubPkgFail(e, n)
                        };
                    n.bind(this), i.bind(this), console.log("start load subpkg", e), this.inst.loadSubpackage({
                        name: e,
                        success: n,
                        fail: i
                    }).onProgressUpdate(function (n) {
                        var i = n.totalBytesWritten / n.totalBytesExpectedToWrite;
                        t.loadSubPkgProgress(e, i)
                    })
                }
            }, {
                key: "loadSubPkgProgress",
                value: function (e, t) {
                    var n = this;
                    this.pkgProgress[e] = t;
                    var i = 1 / this.pkgs.length,
                        a = 0;
                    this.pkgs.forEach(function (e) {
                        a += n.pkgProgress[e] * i
                    }), this.loadProgress && this.loadProgress(a)
                }
            }, {
                key: "loadSubPkgSuccess",
                value: function (e) {
                    console.log("loadSubPkgSuccess", e), this.pkgProgress[e] = 1, this.pkgLoadTag[e] = !0;
                    var t = !0;
                    this._loadSub.indexOf(e) < 0 && this._loadSub.push(e);
                    for (var n = 0; n < this.pkgs.length; n++) 0 == this.pkgLoadTag[this.pkgs[n]] && (t = !1);
                    console.log(this.pkgLoadTag), console.log(t), t && this.loadResolve()
                }
            }, {
                key: "loadSubPkgFail",
                value: function (e, t) {
                    console.error("load subpkg{".concat(e, "} error!, e")), this.loadFail(e)
                }
            }, {
                key: "checkSubLoaded",
                value: function (e) {
                    return !0
                }
            }], [{
                key: "instance",
                get: function () {
                    return this._inst || (this._inst = new SubPKGLoader), this._inst
                }
            }]), SubPKGLoader
        }(),
        G = function () {
            function SoundManager() {
                var e = this;
                _classCallCheck(this, SoundManager), this.bgm = null, this.stopState = !0, this.isPlayingBGM = !1, this.times = 1, this.pauseCount = 0, N.getInst().on(x.Setting, this, this.onSetting), Laya.SoundManager.musicVolume = .5, Laya.SoundManager.soundVolume = .7, Laya.SoundManager.soundMuted = !0, Laya.SoundManager.musicMuted = !0, fgui.GRoot.inst.playOneShotSound = function (t) {
                    arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    fgui.ToolSet.startsWith(t, "ui://") || e.playSound(t)
                }, this.endCB = this.onMusicEnded.bind(this), this.Refresh(), mt.registShowCaller(this, this.PlayBGM), mt.registShowCaller(this, function () {
                    Laya.timer.scale = 1, Laya.SoundManager.muted = !1, console.error("show")
                }), mt.registHideCaller(this, this.StopBGM), mt.registHideCaller(this, function () {
                    Laya.timer.scale = 0, Laya.SoundManager.muted = !0, console.error("hide")
                })
            }
            return _createClass(SoundManager, [{
                key: "Faker",
                value: function () {}
            }, {
                key: "onSetting",
                value: function (e, t, n) {
                    this.Refresh()
                }
            }, {
                key: "Refresh",
                value: function () {
                    Laya.SoundManager.soundMuted = !this.sound, Laya.SoundManager.musicMuted = !this.music, this.music && this.PlayBGM("Bgm")
                }
            }, {
                key: "PlayBGM",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                    console.error("1111111"), e = e || this.bgm || "Bgm", this.bgm = e, -1 == e.indexOf(A.soundDir) && (e = A.soundDir + e), -1 == e.indexOf(".mp3") && (e += ".mp3"), this.stopState = !0, this.isPlayingBGM = !0, this.stopState = !1;
                    var n = Laya.SoundManager.playMusic(e, 0);
                    n && (n.volume = t)
                }
            }, {
                key: "StopBGM",
                value: function () {
                    this.stopState = !0, Laya.SoundManager.stopMusic()
                }
            }, {
                key: "onBGMEnd",
                value: function () {
                    this.stopState || (this.isPlayingBGM = !1, this.PlayBGM(this.bgm))
                }
            }, {
                key: "EnemyDeathVibrate",
                value: function () {
                    this.playVibrate(!1)
                }
            }, {
                key: "playVibrate",
                value: function (e) {
                    this.vibrate && (navigator.vibrate = navigator.vibrate || navigator.webkitVibrate || navigator.mozVibrate || navigator.msVibrate, navigator.vibrate && navigator.vibrate(e ? 1e3 : 200), e ? M.vibrateLong() : M.vibrateShort())
                }
            }, {
                key: "playCreateBuilding",
                value: function () {
                    this.playSound("TentBuild")
                }
            }, {
                key: "playSound",
                value: function (e) {
                    var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                    if (this.sound && B.instance.checkSubLoaded("audio")) return -1 == e.indexOf(A.soundDir) && (e = A.soundDir + e), -1 == e.indexOf(".mp3") && (e += ".mp3"), (t = Laya.SoundManager.playSound(e)) && (t.volume = n), t
                }
            }, {
                key: "playShoot",
                value: function (e) {
                    Laya.Browser.onTTMiniGame ? this.playSound(e) : Laya.timer.callLater(this, this.playSound, [e, 1])
                }
            }, {
                key: "playMoneySpend",
                value: function () {
                    this.playSound("collectstar")
                }
            }, {
                key: "PlayMusic",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                    this.music && (A.Platform == L.Web ? SoundManager.inst.PlayBGM(e) : (null != this.curAC && this._stopMusic(this.curAC), this.curMusic = e, this.curAC = this.createAC(e), this.pauseCount <= 0 && this.curAC.play(), this.curAC.onEnded(this.endCB), this.times = t))
                }
            }, {
                key: "createAC",
                value: function (e) {
                    var t = A.PlatformInst.createInnerAudioContext();
                    return t.src = e, t
                }
            }, {
                key: "PauseMusic",
                value: function () {
                    this.pauseCount++, null != this.curAC && (this.curAC.volume = 0, this.curAC.pause())
                }
            }, {
                key: "ResumeMusic",
                value: function () {
                    this.pauseCount--, this.pauseCount = Math.max(this.pauseCount, 0), this.pauseCount <= 0 && null != this.curAC && this.music && (this.curAC.volume = 1, this.curAC.play())
                }
            }, {
                key: "_stopMusic",
                value: function (e) {
                    e.offEnded(this.endCB), e.stop(), e.destroy()
                }
            }, {
                key: "onMusicEnded",
                value: function () {
                    -1 == this.times ? this.curAC.play() : (this.times--, this.times > 0 && this.curAC.play())
                }
            }, {
                key: "vibrate",
                get: function () {
                    var e = R.getItem("vibrate");
                    return null == e || "" == e ? (this.vibrate = !0, !0) : 1 == Number(e)
                },
                set: function (e) {
                    var t = e ? 1 : 0;
                    R.setItem("vibrate", t.toString())
                }
            }, {
                key: "music",
                get: function () {
                    var e = R.getItem("music");
                    return null == e || "" == e ? (this.music = !0, !0) : 1 == Number(e)
                },
                set: function (e) {
                    var t = e ? 1 : 0;
                    R.setItem("music", t.toString())
                }
            }, {
                key: "sound",
                get: function () {
                    var e = R.getItem("sound");
                    return null == e || "" == e ? (this.sound = !0, !0) : 1 == Number(e)
                },
                set: function (e) {
                    var t = e ? 1 : 0;
                    R.setItem("sound", t.toString())
                }
            }], [{
                key: "inst",
                get: function () {
                    return SoundManager._inst || (SoundManager._inst = new SoundManager, Laya.SoundManager.autoReleaseSound = !1), SoundManager._inst
                }
            }]), SoundManager
        }();
    __decorate([throttle(1e3)], G.prototype, "EnemyDeathVibrate", null), __decorate([throttle(100)], G.prototype, "playCreateBuilding", null), __decorate([throttle(200)], G.prototype, "playMoneySpend", null);
    var V, z = function () {
        function fguiUtils() {
            _classCallCheck(this, fguiUtils)
        }
        return _createClass(fguiUtils, null, [{
            key: "LoadPackage",
            value: function (e) {
                var t = this;
                return new w(function (n, i) {
                    fgui.UIPackage.loadPackage(e, Laya.Handler.create(t, function () {
                        n()
                    }), Laya.Handler.create(t, function (e) {
                        i(e)
                    }, null, !1))
                })
            }
        }]), fguiUtils
    }();
    ! function (e) {
        e.PlayerSteerMoveStart = "PlayerSteerMoveStart", e.PlayerSteerMoveEnd = "PlayerSteerMoveEnd"
    }(V || (V = {}));
    var F = function () {
        function LayaUtils() {
            _classCallCheck(this, LayaUtils)
        }
        return _createClass(LayaUtils, null, [{
            key: "IsZeroVec2",
            value: function (e) {
                return Laya.MathUtils3D.isZero(e.x) && Laya.MathUtils3D.isZero(e.y)
            }
        }, {
            key: "IsZeroVec3",
            value: function (e) {
                return Laya.MathUtils3D.isZero(e.x) && Laya.MathUtils3D.isZero(e.y) && Laya.MathUtils3D.isZero(e.z)
            }
        }, {
            key: "addVec2",
            value: function (e, t, n) {
                n.x = e.x + t.x, n.y = e.y + t.y
            }
        }, {
            key: "subtractVec2",
            value: function (e, t, n) {
                n.x = e.x - t.x, n.y = e.y - t.y
            }
        }, {
            key: "distanceSquaredVec2",
            value: function (e, t) {
                var n = e.x - t.x,
                    i = e.y - t.y;
                return n * n + i * i
            }
        }, {
            key: "distanceVec2",
            value: function (e, t) {
                var n = e.x - t.x,
                    i = e.y - t.y;
                return Math.sqrt(n * n + i * i)
            }
        }, {
            key: "getLengthVec2",
            value: function (e) {
                return Math.sqrt(e.x * e.x + e.y * e.y)
            }
        }, {
            key: "normalizeVec2",
            value: function (e, t) {
                var n = Math.sqrt(e.x * e.x + e.y * e.y);
                n < Laya.MathUtils3D.zeroTolerance || (t.x = e.x / n, t.y = e.y / n)
            }
        }, {
            key: "AngleVec2",
            value: function (e, t) {
                var n = e.x * e.x + t.y * t.y;
                if (n < Laya.MathUtils3D.zeroTolerance) return 0;
                var i = (e.x * t.x + e.y * t.y) / Math.sqrt(n);
                return Math.acos(i) / Laya.MathUtils3D.Deg2Rad
            }
        }, {
            key: "truncateVec2",
            value: function (e, t, n) {
                var i = e.x * e.x + e.y * e.y;
                if (!(i < Laya.MathUtils3D.zeroTolerance))
                    if (i <= t * t) n.x = e.x, n.y = e.y;
                    else {
                        var a = t / Math.sqrt(i);
                        n.x = e.x * a, n.y = e.y * a
                    }
            }
        }, {
            key: "scaleVec2",
            value: function (e, t, n) {
                n.x = e.x * t, n.y = e.y * t
            }
        }, {
            key: "setLengthVec2",
            value: function (e, t, n) {
                if (this.IsZeroVec2(e)) n.x = n.y = 0;
                else {
                    var i = t / Math.sqrt(e.x * e.x + e.y * e.y);
                    n.x = e.x * i, n.y = e.y * i
                }
            }
        }, {
            key: "DotVec2",
            value: function (e, t) {
                return e.x * t.x + e.y * t.y
            }
        }, {
            key: "SetLayer",
            value: function (e, t) {
                e.layer = t;
                for (var n = 0; n < e.numChildren; n++) this.SetLayer(e.getChildAt(n), t)
            }
        }, {
            key: "GetNearstAxisXYDis",
            value: function (e, t) {
                return Math.min(Math.abs(e.x - t.x), Math.abs(e.y - t.y))
            }
        }, {
            key: "GetNearstAxisXZDis",
            value: function (e, t) {
                return Math.min(Math.abs(e.x - t.x), Math.abs(e.z - t.z))
            }
        }, {
            key: "GetFastAxisDis",
            value: function (e, t) {
                return Math.max(Math.abs(e.x - t.x), Math.abs(e.y - t.y))
            }
        }, {
            key: "GetFastAxisXZDis",
            value: function (e, t) {
                return Math.max(Math.abs(e.x - t.x), Math.abs(e.z - t.z))
            }
        }, {
            key: "randomRadius_XZ",
            value: function (e, t) {
                var n = new Laya.Vector3,
                    i = Math.random() * Math.PI,
                    a = 2 * (.5 - Math.random()),
                    o = e.x + a * Math.cos(i) * t,
                    s = e.z + a * Math.sin(i) * t;
                return n.setValue(o, e.y, s), n
            }
        }, {
            key: "RBGtoHSV",
            value: function (e, t) {
                var n = e.x,
                    i = e.y,
                    a = e.z,
                    o = 0,
                    s = 0,
                    r = Math.max(n, i, a),
                    l = r - Math.min(n, i, a),
                    u = function (e) {
                        return (r - e) / 6 / l + .5
                    };
                if (0 == l) o = s = 0;
                else {
                    s = l / r;
                    var h = u(n),
                        c = u(i),
                        d = u(a);
                    n === r ? o = d - c : i === r ? o = 1 / 3 + h - d : a === r && (o = 2 / 3 + c - h), o < 0 ? o += 1 : o > 1 && (o -= 1)
                }
                t.x = 360 * o, t.y = 100 * s, t.z = 100 * r
            }
        }, {
            key: "HSVtoRBG",
            value: function (e, t) {
                var n, i, a, o, s, r = e.x,
                    l = e.y / 100,
                    u = e.z / 100,
                    h = 0,
                    c = 0,
                    d = 0;
                switch (l < 0 && (l = 0), l > 1 && (l = 1), u < 0 && (u = 0), u > 1 && (u = 1), (r %= 360) < 0 && (r += 360), a = u * (1 - l), o = u * (1 - l * (i = (r /= 60) - (n = Math.floor(r)))), s = u * (1 - l * (1 - i)), n) {
                    case 0:
                        h = u, c = s, d = a;
                        break;
                    case 1:
                        h = o, c = u, d = a;
                        break;
                    case 2:
                        h = a, c = u, d = s;
                        break;
                    case 3:
                        h = a, c = o, d = u;
                        break;
                    case 4:
                        h = s, c = a, d = u;
                        break;
                    case 5:
                        h = u, c = a, d = o
                }
                t.x = h, t.y = c, t.z = d
            }
        }, {
            key: "playingTime",
            get: function () {
                return Laya.timer.currTimer - this._startTime
            }
        }, {
            key: "frameRate",
            get: function () {
                return 1e3 / this.deltaTime
            }
        }, {
            key: "deltaTimeScale",
            get: function () {
                return Math.min(60, Laya.timer.delta) / 60
            }
        }, {
            key: "timeScale",
            get: function () {
                return Laya.timer.scale
            }
        }, {
            key: "deltaTime",
            get: function () {
                return this._recordFrame != Laya.timer.currFrame && (this._deltaTime = Math.min(Laya.timer.delta, 100), this._deltaTimeSec = .001 * this._deltaTime, this._recordFrame = Laya.timer.currFrame), this._deltaTime * this.timeScale
            }
        }, {
            key: "deltaTimeSec",
            get: function () {
                return this._recordFrame != Laya.timer.currFrame && (this._deltaTime = Math.min(Laya.timer.delta, 100), this._deltaTimeSec = .001 * this._deltaTime, this._recordFrame = Laya.timer.currFrame), this._deltaTimeSec * this.timeScale
            }
        }]), LayaUtils
    }();
    F.UP = new Laya.Vector3(0, 1, 0), F.Vector3One = new Laya.Vector3(1, 1, 1), F.Vector3Two = new Laya.Vector3(2, 2, 2), F.Vector3Zero = new Laya.Vector3(0, 0, 0), F.Vector2Zero = new Laya.Vector2, F._startTime = Date.now(), F._recordFrame = 0, F._deltaTime = 30, F._deltaTimeSec = .016;
    var H = function (e) {
            function Fakerjoystick() {
                var e;
                return _classCallCheck(this, Fakerjoystick), (e = _possibleConstructorReturn(this, _getPrototypeOf(Fakerjoystick).apply(this, arguments))).centerPos = new Laya.Point, e.lastPos = new Laya.Point, e.currentPos = new Laya.Point, e.dir = new Laya.Vector2, e.deltaPos = new Laya.Vector2, e.tmp = new Laya.Vector2, e.p = new Laya.Vector3, e.q = new Laya.Quaternion, e
            }
            return _inherits(Fakerjoystick, Laya.Script), _createClass(Fakerjoystick, [{
                key: "onStart",
                value: function () {
                    Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.onMoveStart), console.error("move start")
                }
            }, {
                key: "onMoveStart",
                value: function () {
                    console.error("onMoveStart"), this.dir.setValue(0, 0), this.centerX = Laya.stage.mouseX, this.centerY = Laya.stage.mouseY, this.currentPos.setTo(Laya.stage.mouseX, Laya.stage.mouseY), this.lastPos.setTo(this.centerPos.x, this.centerPos.y), Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.onMove), Laya.stage.on(Laya.Event.MOUSE_UP, this, this.onMoveEnd), Laya.stage.on(Laya.Event.MOUSE_OUT, this, this.onMoveEnd)
                }
            }, {
                key: "onMove",
                value: function () {
                    this.currentPos.setTo(Laya.stage.mouseX, Laya.stage.mouseY), F.subtractVec2(this.currentPos, this.lastPos, this.deltaPos), this.lastPos.setTo(this.currentPos.x, this.currentPos.y), F.addVec2(this.deltaPos, this.dir, this.dir);
                    var e = F.getLengthVec2(this.dir);
                    if (e > 100) {
                        var t = e - 100;
                        F.normalizeVec2(this.dir, this.tmp), F.scaleVec2(this.tmp, t, this.tmp), F.truncateVec2(this.dir, 100, this.dir), F.addVec2(this.centerPos, this.tmp, this.centerPos)
                    }
                    F.normalizeVec2(this.dir, this.deltaPos), N.getInst().event(V.PlayerSteerMoveStart, this.deltaPos)
                }
            }, {
                key: "onMoveEnd",
                value: function () {
                    N.getInst().event(V.PlayerSteerMoveEnd), Laya.stage.off(Laya.Event.MOUSE_MOVE, this, this.onMove), Laya.stage.off(Laya.Event.MOUSE_UP, this, this.onMoveEnd), Laya.stage.off(Laya.Event.MOUSE_OUT, this, this.onMoveEnd)
                }
            }]), Fakerjoystick
        }(),
        j = function () {
            function UIManager() {
                _classCallCheck(this, UIManager), this.menuMap = {}, this.uiLayarMap = {}, this.uiStack = {}
            }
            return _createClass(UIManager, [{
                key: "LoadPKG",
                value: function () {
                    var e = this;
                    return this.addFakerJoystick(), new Promise(function (t) {
                        B.instance.Load(function (e) {}, "fui", "audio").then(function () {
                            G.inst.stopState || G.inst.PlayBGM("Bgm");
                            z.LoadPackage(["fui/suijishijian", "fui/lixianshouyi", "fui/setting", "fui/Main", "fui/jumpgame"]).then(function () {
                                P.init(P.pkgJumpGame).then(function () {
                                    e.removeFakerJoystick(), t()
                                })
                            })
                        })
                    })
                }
            }, {
                key: "addFakerJoystick",
                value: function () {
                    var e = new Laya.Sprite;
                    Laya.stage.addChild(e), e.name = "joystick", e.addComponent(H)
                }
            }, {
                key: "removeFakerJoystick",
                value: function () {
                    Laya.stage.removeChildByName("joystick")
                }
            }, {
                key: "RegisterMenu",
                value: function (e, t) {
                    this.menuMap[e] = t
                }
            }, {
                key: "HasUIShow",
                value: function (t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e.base,
                        i = t.oldName;
                    return !!this.HasUIInstance(n, i) && this.GetUIInstance(n, i).IsShow()
                }
            }, {
                key: "ShowUI",
                value: function (t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e.base,
                        i = t.oldName,
                        a = this.GetUIInstance(n, i),
                        o = this.GetStack(n);
                    if (o.length > 0) {
                        var s = o.pop();
                        this.HasUIInstance(n, s) && this.GetUIInstance(n, s).Hide(a.FadeInOut, !1)
                    }
                    for (var r = arguments.length, l = new Array(r > 2 ? r - 2 : 0), u = 2; u < r; u++) l[u - 2] = arguments[u];
                    return a.Show.apply(a, [n].concat(l)), o.push(a.ClassName), a
                }
            }, {
                key: "PushUI",
                value: function (t) {
                    var n, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e.base,
                        a = t.oldName,
                        o = this.GetUIInstance(i, a),
                        s = (o = this.uiLayarMap[i][a], this.GetStack(i));
                    if (s.length > 0) {
                        var r = s[s.length - 1];
                        this.HasUIInstance(i, r) && this.GetUIInstance(i, r).Hide(o.FadeInOut, !1)
                    }
                    for (var l = arguments.length, u = new Array(l > 2 ? l - 2 : 0), h = 2; h < l; h++) u[h - 2] = arguments[h];
                    return (n = o).Show.apply(n, [i].concat(u)), s.push(o.ClassName), o
                }
            }, {
                key: "PopUI",
                value: function (e, t) {
                    var n, i = this.GetStack(e);
                    if (i.length > 0) {
                        var a = i.pop();
                        this.HasUIInstance(e, a) && (n = this.GetUIInstance(e, a)).Hide(!1, t)
                    }
                    if (i.length > 0) {
                        for (var o = i[i.length - 1], s = this.GetUIInstance(e, o), r = arguments.length, l = new Array(r > 2 ? r - 2 : 0), u = 2; u < r; u++) l[u - 2] = arguments[u];
                        s.Show.apply(s, [e].concat(l))
                    }
                    return n
                }
            }, {
                key: "GetUIInstance",
                value: function (e, t) {
                    var n = this.uiLayarMap[e];
                    null == n && (n = this.uiLayarMap[e] = {});
                    var i = n[t];
                    if (null == i) {
                        if (null == this.menuMap[t]) return console.error(t + " is not register!"), null;
                        i = n[t] = this.createByClassSign(this.menuMap[t])
                    }
                    return i
                }
            }, {
                key: "HasUIInstance",
                value: function (e, t) {
                    return null != this.uiLayarMap[e] && null != this.uiLayarMap[e][t]
                }
            }, {
                key: "GetStack",
                value: function (e) {
                    return this.uiStack[e] = this.uiStack[e] || [], this.uiStack[e]
                }
            }, {
                key: "createByClassSign",
                value: function (e) {
                    return new e
                }
            }, {
                key: "getShowWinLen",
                value: function () {
                    var t, n = 0;
                    for (var i in e)
                        if (t = this.uiLayarMap[e[i]])
                            for (var a in t) "TipsUI" != t[a].ClassName && 1 == t[a].show && n++;
                    return n
                }
            }], [{
                key: "inst",
                get: function () {
                    return null == this._inst && (this._inst = new UIManager), this._inst
                }
            }]), UIManager
        }();

    function ui_register(e, t) {
        return function (n) {
            var i = n.name,
                a = function (a) {
                    function newT() {
                        var n;
                        return _classCallCheck(this, newT), (n = _possibleConstructorReturn(this, _getPrototypeOf(newT).call(this)))._className = i, n.URL = e.URL, t.bindAll(), n
                    }
                    return _inherits(newT, n), newT
                }();
            return a.oldName = i, j.inst.RegisterMenu(n.name, a), a
        }
    }
    var W = function () {
        function Handler() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            _classCallCheck(this, Handler), this.once = !1, this._id = 0, this.setTo(e, t, n, i)
        }
        return _createClass(Handler, [{
            key: "setTo",
            value: function (e, t, n) {
                var i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                return this._id = Handler._gid++, this.caller = e, this.method = t, this.args = n, this.once = i, this
            }
        }, {
            key: "run",
            value: function () {
                if (null == this.method) return null;
                var e = this._id,
                    t = this.method.apply(this.caller, this.args);
                return this._id === e && this.once && this.recover(), t
            }
        }, {
            key: "runWith",
            value: function (e) {
                if (null == this.method) return null;
                var t = this._id;
                if (null == e) var n = this.method.apply(this.caller, this.args);
                else n = this.args || e.unshift ? this.args ? this.method.apply(this.caller, this.args.concat(e)) : this.method.apply(this.caller, e) : this.method.call(this.caller, e);
                return this._id === t && this.once && this.recover(), n
            }
        }, {
            key: "clear",
            value: function () {
                return this.caller = null, this.method = null, this.args = null, this
            }
        }, {
            key: "recover",
            value: function () {
                this._id > 0 && (this._id = 0, Handler._pool.push(this.clear()))
            }
        }], [{
            key: "create",
            value: function (e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                    i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
                return Handler._pool.length ? Handler._pool.pop().setTo(e, t, n, i) : new Handler(e, t, n, i)
            }
        }]), Handler
    }();
    W._pool = [], W._gid = 1;
    var $ = function SDKConfig() {
        _classCallCheck(this, SDKConfig)
    };
    $.getLocation = !1, $.useOpenid = !1, $.GAMEID = "", $.VIVO_VERSION = "", $.OPPO_VERSION = "", $.TOUTIAO_GAME_NAME = "", $.TOUTIAO_VERSION = "1.0.0", $.SHARE_CONTENT = ["当下热门夏日露营游戏"], $.TOUTIAO_SHARECONTENT = ["当下热门夏日露营游戏"], $.TOUTIAO_SHARETEMPLATEID = [], $.WECHAT_GAME_NAME = "", $.WECHAT_VERSION = "1.0.3", $.WECHAT_SHARECONTENT = [], $.WECHAT_SHARETEMPLATEID = [], $.HBS_VERSION = "", $.GAME233_APPKEY = "", $.GAME233_POS = "", $.APP_IOS_APPID = "", $.MOMOYU_VERSION = "";
    var K = function () {
            function ToolSDK() {
                _classCallCheck(this, ToolSDK)
            }
            return _createClass(ToolSDK, null, [ {
                key: "getBridge",
                value: function (e) {
                    if (null != window.conchConfig && "Conch-android" == window.conchConfig.getOS()) return window.PlatformClass.createClass(e)
                }
            }, {
                key: "randomItem",
                value: function (e) {
                    return e && e.length > 0 ? e[this.random(0, e.length - 1)] : null
                }
            }, {
                key: "random",
                value: function (e, t) {
                    return Math.round(Math.random() * (t - e) + e)
                }
            }, {
                key: "get_cache",
                value: function (e) {
                    var t = Laya.LocalStorage.getItem(e);
                    return null == t || "null" == t || null == t || "" == t || "NaN" == t ? null : t
                }
            }, {
                key: "set_cache",
                value: function (e, t) {
                    Laya.LocalStorage.setItem(e, t)
                }
            }, {
                key: "has",
                value: function (e) {
                    return !!this.get_cache(e)
                }
            }, {
                key: "delete_cache",
                value: function (e) {
                    Laya.LocalStorage.removeItem(e)
                }
            }, {
                key: "clear_cache",
                value: function () {
                    Laya.LocalStorage.clear()
                }
            }, {
                key: "stopSound",
                value: function () {
                    Laya.SoundManager.setMusicVolume(0)
                }
            }, {
                key: "replaySound",
                value: function () {
                    Laya.SoundManager.setMusicVolume(1)
                }
            }]), ToolSDK
        }(),
        Y = function NavigateItem() {
            _classCallCheck(this, NavigateItem)
        },
        q = function () {
            function SxyGame() {
                _classCallCheck(this, SxyGame), this._hasInitPlat = !1
            }
            return _createClass(SxyGame, [{
                key: "init",
                value: function () {
                    return this.getPlatform(), SxyGame.openid = this.getOpenid(), this.getUUID(), this.setNewPlayer()
                }
            }, {
                key: "getPlatform",
                value: function () {
                    this._hasInitPlat || (this._hasInitPlat = !0,
						window.getStorageSync = Laya.LocalStorage.getItem,
						window.setStorageSync = Laya.LocalStorage.setItem,
						SxyGame.platform = window)
                }
            }, {
                key: "getUUID",
                value: function () {
                    var e = "";
                    try {
                        e = SxyGame.platform.getStorageSync("sxy_uuid")
                    } catch (t) {
                        e = "uuid_default"
                    }
                    if (!e) {
                        e = this.create_uuid();
                        try {
                            SxyGame.platform.setStorageSync("sxy_uuid", e)
                        } catch (e) {
                            SxyGame.platform.setStorageSync("sxy_uuid", "uuid_default")
                        }
                    }
                    return e
                }
            }, {
                key: "setNewPlayer",
                value: function () {
                    var e = SxyGame.platform.getStorageSync("sxy_reg_date"),
                        t = SxyGame.formatDate(new Date);
                    e ? t > e && SxyGame.platform.setStorageSync("sxy_new_player", !1) : (SxyGame.platform.setStorageSync("sxy_new_player", !0), SxyGame.platform.setStorageSync("sxy_reg_date", t))
                }
            }, {
                key: "getOpenid",
                value: function () {
                    return SxyGame.platform.getStorageSync("sxy_openid") || ""
                }
            }, {
                key: "create_uuid",
                value: function () {
                    function e() {
                        return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
                    }
                    return e() + e() + e() + e() + e() + e() + e() + e()
                }
            },
				{
                key: "sendPlayerStay",
                value: function (e, t) {
                    var n = {
                        newPlayer: e,
                        status: t >= 300
                    };
                    this.send(n, "staylong")
                }
            }, {
                key: "sendOpenid",
                value: function (e) {
                    if ("" === e || !e) return console.error("openID不能为空");
                    SxyGame.platform.setStorageSync("sxy_openid", e)
                }
            }], [{
                key: "sendVideo",
                value: function (e) {
                    SxyGame.instance.send(e, "video")
                }
            }, {
                key: "sendEvent",
                value: function (e) {
                    var t = {
                        eventName: e,
                        params: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ""
                    };
                    SxyGame.instance.send(t, "event")
                }
            }, {
                key: "formatDate",
                value: function (e) {
                    var t = e.getFullYear(),
                        n = e.getMonth() + 1,
                        i = e.getDate();
                    return n < 10 && (n = "0" + n), i < 10 && (i = "0" + i), t + "-" + n + "-" + i
                }
            }, {
                key: "paramJoin",
                value: function (e) {
                    e.newPlayer = SxyGame.platform.getStorageSync("sxy_new_player")
                }
            }, {
                key: "instance",
                get: function () {
                    return SxyGame._instance || (SxyGame._instance = new SxyGame)
                }
            }]), SxyGame
        }();
    var J = function () {
            function BaseSDK() {
                _classCallCheck(this, BaseSDK), this._sdkGameData = {}, this._version = "1.0.10", this.configURL = "", this.data = {}, this.isShortCutInstalled = !1, this._isBannerShowing = !1, this._navigateList = [], this._isInitNavigate = !1, this.cityData = {
                    code: 200,
                    loc: ["中国"],
                    ip: "",
                    env: "",
                    nowtime: ""
                }, this.defaultServerConfig = {
                    is_AddDesk: {
                        state: "1"
                    },
                    is_AvdFloat: {
                        state: "1"
                    },
                    is_AvdList: {
                        state: "1"
                    },
                    is_GameNative: {
                        state: "1",
                        interval: 5
                    },
                    is_MoreGameBtn: {
                        state: "0"
                    },
                    is_PropSceneUI: {
                        state: "1",
                        interval: 5
                    },
                    is_banner: {
                        state: "1",
                        interval: 5
                    },
                    ad_all_interval: 10
                }, this.playerFlag = ft.NOMAL_HAS_AD, this.loadingEnd = !1, this.initServerCfg = !1, this.playTime = 0, this.mousedowntime = 0, this._hasInitCfg = !1, this.onADViewComplete = null, this.mousedowntime = Date.now(), Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.onStageMouseDown), Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.onStageMouseDown), It.Int.on(vt.OpenAutoFN, this.OpenAutoFN, this), this._startTimer()
            }
            return _createClass(BaseSDK, [{
                key: "_startTimer",
                value: function () {
                    Laya.timer.frameLoop(1, this, this._clock)
                }
            }, {
                key: "_clock",
                value: function () {
                    this.initServerCfg && (this.playTime += Laya.timer.delta), this.loadingEnd && mt.serverTime - this.mousedowntime > 2e4 && (It.Int.emit(vt.OpenAutoFN), this.mousedowntime = mt.serverTime, It.Int.emit(vt.LONG_TIME_NO_OPERATION))
                }
            }, {
                key: "huaWeiLogin",
                value: function (e, t, n) {}
            }, {
                key: "login",
                value: function () {
                    return Promise.resolve({
                        code: "",
                        clue_token: "",
                        invite_uid: ""
                    })
                }
            }, {
                key: "onStageMouseDown",
                value: function () {
                    this.mousedowntime = Date.now()
                }
            }, {
                key: "avdErrorLevel",
                value: function () {
                    return mt.getPlatData("ErrorLevel", 0)
                }
            }, {
                key: "errorMaxCount",
                value: function (e) {
                    return e == _t.BANNER ? mt.getPlatData("ErrorCountB", 0) : e == _t.VIDEO ? mt.getPlatData("ErrorCountV", 0) : e == _t.NATIVE ? mt.getPlatData("ErrorCount", 0) : void 0
                }
            }, {
                key: "checkIsTody",
                value: function (e) {
                    var t = new Date(e),
                        n = new Date,
                        i = !1;
                    return t.getFullYear() == n.getFullYear() && t.getMonth() == n.getMonth() && t.getDate() == n.getDate() && (i = !0), i
                }
            }, {
                key: "errorCount",
                value: function (e) {
                    return this._sdkGameData.time || (this._sdkGameData.time = Date.now()), this.checkIsTody(this._sdkGameData.time) || (this._sdkGameData.curErrorCountB = 0, this._sdkGameData.curErrorCountV = 0, this._sdkGameData.curErrorCount = 0, mt.setLocalCache("GameData" + X.data.GAMEID, JSON.stringify(this._sdkGameData))), e == _t.BANNER ? null == this._sdkGameData.curErrorCountB ? 0 : this._sdkGameData.curErrorCountB : e == _t.VIDEO ? null == this._sdkGameData.curErrorCountV ? 0 : this._sdkGameData.curErrorCountV : e == _t.NATIVE ? null == this._sdkGameData.curErrorCount ? 0 : this._sdkGameData.curErrorCount : void 0
                }
            }, {
                key: "updataAvdErrorCount",
                value: function (e, t) {
                    return this._sdkGameData.time = Date.now(), t == _t.BANNER ? this._sdkGameData.curErrorCountB != e && (this._sdkGameData.curErrorCountB = e, mt.setLocalCache("GameData" + X.data.GAMEID, JSON.stringify(this._sdkGameData)), !0) : t == _t.VIDEO ? this._sdkGameData.curErrorCountV != e && (this._sdkGameData.curErrorCountV = e, mt.setLocalCache("GameData" + X.data.GAMEID, JSON.stringify(this._sdkGameData)), !0) : t == _t.NATIVE ? this._sdkGameData.curErrorCount != e && (this._sdkGameData.curErrorCount = e, mt.setLocalCache("GameData" + X.data.GAMEID, JSON.stringify(this._sdkGameData)), !0) : void 0
                }
            }, {
                key: "avdErrorProp",
                value: function () {
                    return mt.getPlatData("ErrorProba", 0)
                }
            }, {
                key: "playGameErrorProp",
                value: function () {
                    return mt.getPlatData("PlayGameAdProba", 0)
                }
            }, {
                key: "enterGameVideoProp",
                value: function () {
                    return mt.getPlatData("EnterAdProba", 0)
                }
            }, {
                key: "waterFallErrorProp",
                value: function () {
                    return mt.getPlatData("WaterfallProba", 0)
                }
            }, {
                key: "playGameLevel",
                value: function () {
                    return mt.getPlatData("PlayGameAd", 0)
                }
            }, {
                key: "isCurrentVersion",
                value: function () {
                    if (null == this._version) return !1;
                    var e = mt.getPlatData("Version");
                    return null != e && e == this._version
                }
            }, {
                key: "byteToString",
                value: function (e) {
                    if ("string" == typeof e) return e;
                    for (var t = "", n = e, i = 0; i < n.length; i++) {
                        var a = n[i].toString(2),
                            o = a.match(/^1+?(?=0)/);
                        if (o && 8 == a.length) {
                            for (var s = o[0].length, r = n[i].toString(2).slice(7 - s), l = 1; l < s; l++) r += n[l + i].toString(2).slice(2);
                            t += String.fromCharCode(parseInt(r, 2)), i += s - 1
                        } else t += String.fromCharCode(n[i])
                    }
                    return t
                }
            }, {
                key: "getBytes",
                value: function (e) {
                    for (var t = [], n = 0; n < e.length; n++) t.push(e.charCodeAt(n));
                    return t
                }
            }, {
                key: "decode",
                value: function (e) {
                    for (var t = this.getBytes(e), n = 0; n < t.length; n++) t[n] = 359 ^ t[n];
                    return this.byteToString(t)
                }
            }, 
				{
                key: "hasShareRecorder",
                value: function () {
                    return !1
                }
            }, {
                key: "getNavigateList",
                value: function () {
                    if (this._isInitNavigate) return this._navigateList;
                    var e = mt.getPlatData("applist") || mt.getPlatData("navigateAppList");
                    e || (e = []);
                    for (var t, n, i = e.length, a = 0; a < i; a += 1) n = e[a], (t = new Y).appId = n.appid, t.name = n.name, t.iconPath = n.iconPath.split(","), t.videoId = n.videoId, t.weight = n.weight, t.path = n.path || "", this._navigateList.push(t);
                    return this.shuffle(this._navigateList), this._isInitNavigate = !0, this._navigateList
                }
            }, {
                key: "shuffle",
                value: function (e) {
                    if (!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) return e.sort(function (e, t) {
                        return Math.random() > .5 ? 1 : -1
                    }), e;
                    var t = e.concat();
                    return t.sort(function (e, t) {
                        return Math.random() > .5 ? 1 : -1
                    }), t
                }
            }, {
                key: "OpenAutoFN",
                value: function () {}
            }, {
                key: "shortCutInstalled",
                value: function (e) {}
            }, {
                key: "checkShortcut",
                value: function (e) {}
            }, {
                key: "navigateToMiniGame",
                value: function (e) {}
            }, {
                key: "showBanner",
                value: function () {
                    this._isBannerShowing = !0
                }
            }, {
                key: "hideBanner",
                value: function () {
                    this._isBannerShowing = !1
                }
            }, {
                key: "isBannerShow",
                value: function () {
                    return this._isBannerShowing
                }
            }, {
                key: "resetBanner",
                value: function () {}
            }, {
                key: "showADVideo",
                value: function (e, t, n, i) {
                    this.noticeOpenVideo(n), t && (this.onADViewComplete = W.create(e, t, i), this.onADViewComplete.runWith(!0))
                }
            }, {
                key: "showADInsert",
                value: function () {}
            }, {
                key: "noticeOpenVideo",
                value: function (e) {
                    this.sendVideo({
                        point: e,
                        status: 0
                    })
                }
            }, {
                key: "noticeCloseVideo",
                value: function (e) {
                    this.sendVideo({
                        point: e,
                        status: 1
                    })
                }
            }, {
                key: "startVideoRecord",
                value: function (e, t) {}
            }, {
                key: "pauseVideoRecord",
                value: function () {}
            }, {
                key: "resumeVideoRecord",
                value: function () {}
            }, {
                key: "stopVideoRecord",
                value: function () {}
            }, {
                key: "shareVideoRecord",
                value: function (e) {
                    console.log("ADBase.shareVideoRecord"), e && e(!0)
                }
            }, {
                key: "isSupportShareVideo",
                value: function () {
                    return !0
                }
            }, {
                key: "isSupportErrorClick",
                value: function () {
                    return !1
                }
            }, {
                key: "vibrateShort",
                value: function (e) {}
            }, {
                key: "vibrateLong",
                value: function () {}
            }, {
                key: "createNative",
                value: function (e) {}
            }, {
                key: "isShortScreen",
                value: function () {
                    return !1
                }
            }, {
                key: "showToast",
                value: function (e, t) {}
            }, {
                key: "onConfigLoad",
                value: function () {}
            }, {
                key: "sendVideo",
                value: function (e) {
                    q.sendVideo(e)
                }
            }, {
                key: "stageOnStart",
                value: function (e) {
                    q.stage.onStart(e)
                }
            }, {
                key: "statgeOnRunning",
                value: function (e) {
                    q.stage.onRunning(e)
                }
            }, {
                key: "stageOnEnd",
                value: function (e) {
                    q.stage.onEnd(e)
                }
            }, {
                key: "sendEvent",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                    q.sendEvent(e, t)
                }
            }, {
                key: "request",
                value: function (e) {
                    var t;
                    console.log("PlatformVirtual.request", e), (t = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP")).onreadystatechange = function () {
                        if (4 == t.readyState && e.success && "function" == typeof e.success) {
                            var n = null;
                            t.responseText && "" != t.responseText && (n = t.responseText), e.success({
                                code: t.status,
                                data: n
                            })
                        }
                    };
                    var n = e.url;
                    e.data && (n += "?" + Object.keys(e.data).map(function (t) {
                        return encodeURIComponent(t) + "=" + encodeURIComponent(e.data[t])
                    }).join("&"));
                    t.open("GET", n, !0), t.send()
                }
            }, {
                key: "loadSubpackage",
                value: function (e, t, n, i, a) {}
            }, {
                key: "shareMsg",
                value: function (e, t, n, i) {}
            }, {
                key: "showGameBanner",
                value: function () {}
            }, {
                key: "hideGameBanner",
                value: function () {}
            }, {
                key: "showGamePortal",
                value: function () {}
            }, {
                key: "checkSessionKey",
                value: function () {
                    return Promise.resolve()
                }
            },  {
                key: "sdkGameData",
                get: function () {
                    return this._sdkGameData
                }
            }, {
                key: "version",
                get: function () {
                    return this._version
                }
            }, {
                key: "sessionKey",
                set: function (e) {
                    this._sessionKey = e
                },
                get: function () {
                    return this._sessionKey
                }
            }]), BaseSDK
        }(),
        Z = function (e) {
            function baseUI$10() {
                return _classCallCheck(this, baseUI$10), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$10).apply(this, arguments))
            }
            return _inherits(baseUI$10, fgui.GComponent), baseUI$10
        }(),
        Q = function (e) {
            function UI_GameNativeParser() {
                return _classCallCheck(this, UI_GameNativeParser), _possibleConstructorReturn(this, _getPrototypeOf(UI_GameNativeParser).apply(this, arguments))
            }
            return _inherits(UI_GameNativeParser, Z), _createClass(UI_GameNativeParser, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "GameNativeParser")
                }
            }]), UI_GameNativeParser
        }();
    Q.URL = "ui://6mbv2rpwekr80";
    var ee = function (e) {
            function baseUI$$() {
                return _classCallCheck(this, baseUI$$), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$$).apply(this, arguments))
            }
            return _inherits(baseUI$$, fgui.GComponent), baseUI$$
        }(),
        te = function (e) {
            function UI_NativeParserAd() {
                return _classCallCheck(this, UI_NativeParserAd), _possibleConstructorReturn(this, _getPrototypeOf(UI_NativeParserAd).apply(this, arguments))
            }
            return _inherits(UI_NativeParserAd, ee), _createClass(UI_NativeParserAd, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_icon = this.getChildAt(1), this.m_logo = this.getChildAt(5), this.m_btn_qukankan = this.getChildAt(6)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "NativeParserAd")
                }
            }]), UI_NativeParserAd
        }();
    te.URL = "ui://6mbv2rpwekr81";
    var ne = function (e) {
            function baseUI$_() {
                return _classCallCheck(this, baseUI$_), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$_).apply(this, arguments))
            }
            return _inherits(baseUI$_, fgui.GComponent), baseUI$_
        }(),
        ie = function (e) {
            function UI_ui_login() {
                return _classCallCheck(this, UI_ui_login), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_login).apply(this, arguments))
            }
            return _inherits(UI_ui_login, ne), _createClass(UI_ui_login, [{
                key: "onConstruct",
                value: function () {
                    this.m_bg = this.getChildAt(0), this.m_content = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_login")
                }
            }]), UI_ui_login
        }();
    ie.URL = "ui://6mbv2rpwekr8a";
    var ae = function (e) {
            function baseUI$Z() {
                return _classCallCheck(this, baseUI$Z), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$Z).apply(this, arguments))
            }
            return _inherits(baseUI$Z, fgui.GComponent), baseUI$Z
        }(),
        oe = function (e) {
            function UI_ui_logining() {
                return _classCallCheck(this, UI_ui_logining), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_logining).apply(this, arguments))
            }
            return _inherits(UI_ui_logining, ae), _createClass(UI_ui_logining, [{
                key: "onConstruct",
                value: function () {
                    this.m_bg = this.getChildAt(0), this.m_img_logo = this.getChildAt(1), this.m_t1 = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_logining")
                }
            }]), UI_ui_logining
        }();
    oe.URL = "ui://6mbv2rpwekr8b";
    var se = function (e) {
            function baseUI$Y() {
                return _classCallCheck(this, baseUI$Y), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$Y).apply(this, arguments))
            }
            return _inherits(baseUI$Y, fgui.GComponent), baseUI$Y
        }(),
        re = function (e) {
            function UI_NativeInsertAd() {
                return _classCallCheck(this, UI_NativeInsertAd), _possibleConstructorReturn(this, _getPrototypeOf(UI_NativeInsertAd).apply(this, arguments))
            }
            return _inherits(UI_NativeInsertAd, se), _createClass(UI_NativeInsertAd, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_icon = this.getChildAt(1), this.m_text_miaoshu = this.getChildAt(2), this.m_btn_close = this.getChildAt(3), this.m_btn_dakai = this.getChildAt(4), this.m_btn_qukankan = this.getChildAt(5), this.m_logo = this.getChildAt(7), this.m_t0 = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "NativeInsertAd")
                }
            }]), UI_NativeInsertAd
        }();
    re.URL = "ui://6mbv2rpwja108";
    var le = function (e) {
            function baseUI$X() {
                return _classCallCheck(this, baseUI$X), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$X).apply(this, arguments))
            }
            return _inherits(baseUI$X, fgui.GComponent), baseUI$X
        }(),
        ue = function (e) {
            function UI_ui_yinsi2() {
                return _classCallCheck(this, UI_ui_yinsi2), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_yinsi2).apply(this, arguments))
            }
            return _inherits(UI_ui_yinsi2, le), _createClass(UI_ui_yinsi2, [{
                key: "onConstruct",
                value: function () {
                    this.m_com_mengban = this.getChildAt(0), this.m_comp_yinsi2 = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_yinsi2")
                }
            }]), UI_ui_yinsi2
        }();
    ue.URL = "ui://6mbv2rpwkhdm1b";
    var he = function (e) {
            function baseUI$W() {
                return _classCallCheck(this, baseUI$W), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$W).apply(this, arguments))
            }
            return _inherits(baseUI$W, fgui.GComponent), baseUI$W
        }(),
        ce = function (e) {
            function UI_comp_yinsi2() {
                return _classCallCheck(this, UI_comp_yinsi2), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_yinsi2).apply(this, arguments))
            }
            return _inherits(UI_comp_yinsi2, he), _createClass(UI_comp_yinsi2, [{
                key: "onConstruct",
                value: function () {
                    this.m_btn_agree = this.getChildAt(4), this.m_btn_reject = this.getChildAt(5), this.m_btn_fuwuxieyi = this.getChildAt(6), this.m_btn_yinsizhengce = this.getChildAt(7)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "comp_yinsi2")
                }
            }]), UI_comp_yinsi2
        }();
    ce.URL = "ui://6mbv2rpwkhdm1c";
    var de = function (e) {
            function baseUI$V() {
                return _classCallCheck(this, baseUI$V), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$V).apply(this, arguments))
            }
            return _inherits(baseUI$V, fgui.GComponent), baseUI$V
        }(),
        fe = function (e) {
            function UI_ui_wendang() {
                return _classCallCheck(this, UI_ui_wendang), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_wendang).apply(this, arguments))
            }
            return _inherits(UI_ui_wendang, de), _createClass(UI_ui_wendang, [{
                key: "onConstruct",
                value: function () {
                    this.m_bg = this.getChildAt(1), this.m_loader_biaoti = this.getChildAt(2), this.m_btn_fanhui = this.getChildAt(3), this.m_wenAn = this.getChildAt(5)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_wendang")
                }
            }]), UI_ui_wendang
        }();
    fe.URL = "ui://6mbv2rpwkhdmn";
    var _e = function (e) {
            function baseUI$U() {
                return _classCallCheck(this, baseUI$U), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$U).apply(this, arguments))
            }
            return _inherits(baseUI$U, fgui.GComponent), baseUI$U
        }(),
        ye = function (e) {
            function UI_Component1() {
                return _classCallCheck(this, UI_Component1), _possibleConstructorReturn(this, _getPrototypeOf(UI_Component1).apply(this, arguments))
            }
            return _inherits(UI_Component1, _e), _createClass(UI_Component1, [{
                key: "onConstruct",
                value: function () {
                    this.m_text_wenan = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "Component1")
                }
            }]), UI_Component1
        }();
    ye.URL = "ui://6mbv2rpwkhdmt";
    var pe = function (e) {
            function baseUI$T() {
                return _classCallCheck(this, baseUI$T), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$T).apply(this, arguments))
            }
            return _inherits(baseUI$T, fgui.GComponent), baseUI$T
        }(),
        ge = function (e) {
            function UI_ui_yinsi1() {
                return _classCallCheck(this, UI_ui_yinsi1), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_yinsi1).apply(this, arguments))
            }
            return _inherits(UI_ui_yinsi1, pe), _createClass(UI_ui_yinsi1, [{
                key: "onConstruct",
                value: function () {
                    this.m_com_mengban = this.getChildAt(0), this.m_comp_yinsi1 = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_yinsi1")
                }
            }]), UI_ui_yinsi1
        }();
    ge.URL = "ui://6mbv2rpwkhdmu";
    var ve = function (e) {
            function baseUI$S() {
                return _classCallCheck(this, baseUI$S), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$S).apply(this, arguments))
            }
            return _inherits(baseUI$S, fgui.GComponent), baseUI$S
        }(),
        me = function (e) {
            function UI_comp_mengban$1() {
                return _classCallCheck(this, UI_comp_mengban$1), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_mengban$1).apply(this, arguments))
            }
            return _inherits(UI_comp_mengban$1, ve), _createClass(UI_comp_mengban$1, [{
                key: "onConstruct",
                value: function () {
                    this.m_graph_mengban = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "comp_mengban")
                }
            }]), UI_comp_mengban$1
        }();
    me.URL = "ui://6mbv2rpwxpdp1";
    var Ce = function (e) {
            function baseUI$R() {
                return _classCallCheck(this, baseUI$R), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$R).apply(this, arguments))
            }
            return _inherits(baseUI$R, fgui.GComponent), baseUI$R
        }(),
        ke = function (e) {
            function UI_comp_yinsi1() {
                return _classCallCheck(this, UI_comp_yinsi1), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_yinsi1).apply(this, arguments))
            }
            return _inherits(UI_comp_yinsi1, Ce), _createClass(UI_comp_yinsi1, [{
                key: "onConstruct",
                value: function () {
                    this.m_btn_close = this.getChildAt(3), this.m_btn_agree = this.getChildAt(5), this.m_btn_reject = this.getChildAt(6), this.m_btn_yonghuxieyi = this.getChildAt(7), this.m_btn_chanpinyinsishuoming = this.getChildAt(8)
                    this.m_btn_yonghuxieyi.visible = false;
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "comp_yinsi1")
                }
            }]), UI_comp_yinsi1
        }();
    ke.URL = "ui://6mbv2rpwkhdmw";
    var Se = function (e) {
            function baseUI$Q() {
                return _classCallCheck(this, baseUI$Q), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$Q).apply(this, arguments))
            }
            return _inherits(baseUI$Q, fgui.GComponent), baseUI$Q
        }(),
        Ie = function (e) {
            function UI_ui_nativebannerAd() {
                return _classCallCheck(this, UI_ui_nativebannerAd), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_nativebannerAd).apply(this, arguments))
            }
            return _inherits(UI_ui_nativebannerAd, Se), _createClass(UI_ui_nativebannerAd, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_comp_native = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_nativebannerAd")
                }
            }]), UI_ui_nativebannerAd
        }();
    Ie.URL = "ui://6mbv2rpwom3r2c";
    var be = function (e) {
            function baseUI$P() {
                return _classCallCheck(this, baseUI$P), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$P).apply(this, arguments))
            }
            return _inherits(baseUI$P, fgui.GComponent), baseUI$P
        }(),
        Le = function (e) {
            function UI_comp_mengban2() {
                return _classCallCheck(this, UI_comp_mengban2), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_mengban2).apply(this, arguments))
            }
            return _inherits(UI_comp_mengban2, be), _createClass(UI_comp_mengban2, [{
                key: "onConstruct",
                value: function () {
                    this.m_graph_mengban = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "comp_mengban2")
                }
            }]), UI_comp_mengban2
        }();
    Le.URL = "ui://6mbv2rpwom3r2d";
    var Pe = function (e) {
            function baseUI$O() {
                return _classCallCheck(this, baseUI$O), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$O).apply(this, arguments))
            }
            return _inherits(baseUI$O, fgui.GComponent), baseUI$O
        }(),
        Te = function (e) {
            function UI_GameNativeBanner() {
                return _classCallCheck(this, UI_GameNativeBanner), _possibleConstructorReturn(this, _getPrototypeOf(UI_GameNativeBanner).apply(this, arguments))
            }
            return _inherits(UI_GameNativeBanner, Pe), _createClass(UI_GameNativeBanner, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_content = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "GameNativeBanner")
                }
            }]), UI_GameNativeBanner
        }();
    Te.URL = "ui://6mbv2rpwom3r2e";
    var Ae = function (e) {
            function baseUI$N() {
                return _classCallCheck(this, baseUI$N), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$N).apply(this, arguments))
            }
            return _inherits(baseUI$N, fgui.GComponent), baseUI$N
        }(),
        we = function (e) {
            function UI_NativeAdBanner() {
                return _classCallCheck(this, UI_NativeAdBanner), _possibleConstructorReturn(this, _getPrototypeOf(UI_NativeAdBanner).apply(this, arguments))
            }
            return _inherits(UI_NativeAdBanner, Ae), _createClass(UI_NativeAdBanner, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_bg = this.getChildAt(0), this.m_icon = this.getChildAt(1), this.m_close = this.getChildAt(2), this.m_title = this.getChildAt(3), this.m_logo = this.getChildAt(4), this.m_btn_qukankan = this.getChildAt(5), this.m_describle = this.getChildAt(6)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "NativeAdBanner")
                }
            }]), UI_NativeAdBanner
        }();
    we.URL = "ui://6mbv2rpwom3r2f";
    var Ue = function (e) {
            function baseUI$M() {
                return _classCallCheck(this, baseUI$M), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$M).apply(this, arguments))
            }
            return _inherits(baseUI$M, fgui.GComponent), baseUI$M
        }(),
        De = function (e) {
            function UI_GameNativeInsert() {
                return _classCallCheck(this, UI_GameNativeInsert), _possibleConstructorReturn(this, _getPrototypeOf(UI_GameNativeInsert).apply(this, arguments))
            }
            return _inherits(UI_GameNativeInsert, Ue), _createClass(UI_GameNativeInsert, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "GameNativeInsert")
                }
            }]), UI_GameNativeInsert
        }();
    De.URL = "ui://6mbv2rpwreif28";
    var Me = function (e) {
            function baseUI$L() {
                return _classCallCheck(this, baseUI$L), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$L).apply(this, arguments))
            }
            return _inherits(baseUI$L, fgui.GComponent), baseUI$L
        }(),
        Ee = function (e) {
            function UI_ui_nativeInsertAd() {
                return _classCallCheck(this, UI_ui_nativeInsertAd), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_nativeInsertAd).apply(this, arguments))
            }
            return _inherits(UI_ui_nativeInsertAd, Me), _createClass(UI_ui_nativeInsertAd, [{
                key: "onConstruct",
                value: function () {
                    this.m_bg = this.getChildAt(0), this.m_comp_native = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_nativeInsertAd")
                }
            }]), UI_ui_nativeInsertAd
        }();
    Ee.URL = "ui://6mbv2rpwrpiw1";
    var Re = function (e) {
            function baseUI$K() {
                return _classCallCheck(this, baseUI$K), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$K).apply(this, arguments))
            }
            return _inherits(baseUI$K, fgui.GComponent), baseUI$K
        }(),
        xe = function (e) {
            function UI_ui_nativeParserAd() {
                return _classCallCheck(this, UI_ui_nativeParserAd), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_nativeParserAd).apply(this, arguments))
            }
            return _inherits(UI_ui_nativeParserAd, Re), _createClass(UI_ui_nativeParserAd, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_bg = this.getChildAt(0), this.m_comp_native = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "ui_nativeParserAd")
                }
            }]), UI_ui_nativeParserAd
        }();
    xe.URL = "ui://6mbv2rpwxpdp0";
    var Oe = function (e) {
            function baseUI$J() {
                return _classCallCheck(this, baseUI$J), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$J).apply(this, arguments))
            }
            return _inherits(baseUI$J, fgui.GComponent), baseUI$J
        }(),
        Ne = function (e) {
            function UI_comp_login() {
                return _classCallCheck(this, UI_comp_login), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_login).apply(this, arguments))
            }
            return _inherits(UI_comp_login, Oe), _createClass(UI_comp_login, [{
                key: "onConstruct",
                value: function () {
                    this.m_btn_login = this.getChildAt(3), this.m_descripe = this.getChildAt(4), this.m_btn_tuichu = this.getChildAt(5)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("huawei", "comp_login")
                }
            }]), UI_comp_login
        }();
    Ne.URL = "ui://6mbv2rpwxpdp2";
    var Be, Ge, Ve = function () {
        function huaweiBinder() {
            _classCallCheck(this, huaweiBinder)
        }
        return _createClass(huaweiBinder, null, [{
            key: "bindAll",
            value: function () {
                fgui.UIObjectFactory.setExtension(Q.URL, Q), fgui.UIObjectFactory.setExtension(te.URL, te), fgui.UIObjectFactory.setExtension(ie.URL, ie), fgui.UIObjectFactory.setExtension(oe.URL, oe), fgui.UIObjectFactory.setExtension(re.URL, re), fgui.UIObjectFactory.setExtension(ue.URL, ue), fgui.UIObjectFactory.setExtension(ce.URL, ce), fgui.UIObjectFactory.setExtension(fe.URL, fe), fgui.UIObjectFactory.setExtension(ye.URL, ye), fgui.UIObjectFactory.setExtension(ge.URL, ge), fgui.UIObjectFactory.setExtension(me.URL, me), fgui.UIObjectFactory.setExtension(ke.URL, ke), fgui.UIObjectFactory.setExtension(Ie.URL, Ie), fgui.UIObjectFactory.setExtension(Le.URL, Le), fgui.UIObjectFactory.setExtension(Te.URL, Te), fgui.UIObjectFactory.setExtension(we.URL, we), fgui.UIObjectFactory.setExtension(De.URL, De), fgui.UIObjectFactory.setExtension(Ee.URL, Ee), fgui.UIObjectFactory.setExtension(xe.URL, xe), fgui.UIObjectFactory.setExtension(me.URL, me), fgui.UIObjectFactory.setExtension(Ne.URL, Ne)
            }
        }]), huaweiBinder
    }();
    ! function (e) {
        e.left = "left", e.center = "center", e.right = "right"
    }(Be || (Be = {})),
    function (e) {
        e.top = "top", e.middle = "middle", e.bottom = "bottom"
    }(Ge || (Ge = {}));
    var ze = function IUI() {
            _classCallCheck(this, IUI)
        },
        Fe = function (e) {
            function BaseUI(e) {
                var t;
                return _classCallCheck(this, BaseUI), (t = _possibleConstructorReturn(this, _getPrototypeOf(BaseUI).call(this))).show = !1, e && (t.wrapCom = e, t.ui = e, e._cls = _assertThisInitialized(t), t.OnCreate()), t
            }
            return _inherits(BaseUI, ze), _createClass(BaseUI, [{
                key: "IsShow",
                value: function () {
                    return this.show
                }
            }, {
                key: "Create",
                value: function () {
                    if (null == this.wrapCom) {
                        if (this.checkBind(), this.UseLoaderWarp) {
                            this.wrapCom = new fgui.GComponent, this.wrapCom.makeFullScreen(), this.wrapCom.addRelation(fgui.GRoot.inst, fgui.RelationType.Size);
                            var e = new fgui.GLoader;
                            e.makeFullScreen(), e.displayObject.hitArea = null, e.displayObject.mouseThrough = !0, e.url = this.URL, e.fill = this.LoaderFillType, e.align = this.Align, e.verticalAlign = this.VerticalAlign, this.ui = e.component, this.wrapCom.addChild(e), e.addRelation(this.wrapCom, fgui.RelationType.Size), this.wrapCom.on(fgui.Events.SIZE_CHANGED, this, this.updateFullItems), this.updateFullItems()
                        } else this.wrapCom = this.ui = fgui.UIPackage.createObjectFromURL(this.URL).asCom, this.wrapCom.makeFullScreen(), this.wrapCom.addRelation(fgui.GRoot.inst, fgui.RelationType.Size);
                        this.OnCreate()
                    }
                }
            }, {
                key: "checkBind",
                value: function () {
                    null == fgui.UIObjectFactory.extensions[this.URL] && console.error(this.ClassName, "is not bind")
                }
            }, {
                key: "updateFullItems",
                value: function () {
                    var e = this.FullScreenItems,
                        t = 1 / this.ui.scaleX,
                        n = 1 / this.ui.scaleY;
                    if (null != e)
                        for (var i = 0; i < e.length; i++) {
                            var a = e[i];
                            a.makeFullScreen(), a.scaleX = t, a.scaleY = n, a.x = -this.ui.x * t, a.y = -this.ui.y * n
                        }
                }
            }, {
                key: "Show",
                value: function (e) {
                    var t = this;
                    this.Create(), null == this.wrapCom.parent && (fgui.GRoot.inst.addChild(this.wrapCom), this.wrapCom.visible = !0), null != e && (this.layer = e, this.wrapCom.sortingOrder = e);
                    for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                    this.OnShow.apply(this, i), this.show = !0, this.FadeInOut ? (this.ui.alpha = 0, this.fadeTween = fgui.GTween.to(0, 1, this.FadeInDuration).onUpdate(function (e) {
                        t.ui.alpha = e.value.x
                    })) : this.ui.alpha = 1
                }
            }, {
                key: "Hide",
                value: function (e, t) {
                    var n = this;
                    e || this.FadeInOut ? this.fadeTween = fgui.GTween.to(1, 0, this.FadeOutDuration).onUpdate(function (e) {
                        n.ui.alpha = e.value.x
                    }).onComplete(function () {
                        n._Hide(t)
                    }, this) : this._Hide(t)
                }
            }, {
                key: "_Hide",
                value: function (e) {
                    null != this.fadeTween && (0 == this.fadeTween._killed && this.fadeTween.kill(!1), this.fadeTween = null), fgui.GRoot.inst.removeChild(this.wrapCom), this.OnHide(), this.show = !1
                }
            }, {
                key: "Dispose",
                value: function () {
                    this.OnDispose(), this.wrapCom.dispose(), this.wrapCom = null
                }
            }, {
                key: "AnchorLeft",
                value: function (e) {}
            }, {
                key: "AnchorRight",
                value: function (e) {}
            }, {
                key: "AnchorTop",
                value: function (e) {}
            }, {
                key: "AnchorBottom",
                value: function (e) {}
            }, {
                key: "FadeInOut",
                get: function () {
                    return !1
                }
            }, {
                key: "FadeInDuration",
                get: function () {
                    return .2
                }
            }, {
                key: "FadeOutDuration",
                get: function () {
                    return .1
                }
            }, {
                key: "FullScreenItems",
                get: function () {
                    return null
                }
            }, {
                key: "Align",
                get: function () {
                    return Be.center
                }
            }, {
                key: "VerticalAlign",
                get: function () {
                    return Ge.middle
                }
            }, {
                key: "LoaderFillType",
                get: function () {
                    return fgui.LoaderFillType.Scale
                }
            }, {
                key: "UseLoaderWarp",
                get: function () {
                    return !0
                }
            }, {
                key: "ClassName",
                get: function () {
                    return this._className || this.constructor.name
                }
            }, {
                key: "ComName",
                get: function () {
                    return fgui.UIPackage.getItemByURL(this.URL).name
                }
            }]), BaseUI
        }(),
        We = function (e) {
            function LoginUI() {
                return _classCallCheck(this, LoginUI), _possibleConstructorReturn(this, _getPrototypeOf(LoginUI).apply(this, arguments))
            }
            return _inherits(LoginUI, Fe), _createClass(LoginUI, [{
                key: "OnCreate",
                value: function () {
                    this.ui.m_content.m_btn_tuichu.onClick(this, this.onClickClose), this.ui.m_content.m_btn_login.onClick(this, this.onLogin)
                }
            }, {
                key: "OnShow",
                value: function () {
                    this.ui.m_content.m_descripe.text = arguments.length <= 0 ? void 0 : arguments[0]
                }
            }, {
                key: "OnHide",
                value: function () {}
            }, {
                key: "OnDispose",
                value: function () {}
            }, {
                key: "loginHuaWei",
                value: function () {}
            }, {
                key: "onLogin",
                value: function () {
                    mt.huaWeiLogin(function () {}, function () {})
                }
            }, {
                key: "onClickClose",
                value: function () {
                    qg.exitApplication({}), j.inst.PopUI(this.layer, !1)
                }
            }, {
                key: "FullScreenItems",
                get: function () {
                    return [this.ui.m_bg]
                }
            }]), LoginUI
        }();
    We = __decorate([ui_register(ie, Ve)], We);
    var $e = function (e) {
        function UIwendang() {
            var e;
            return _classCallCheck(this, UIwendang), (e = _possibleConstructorReturn(this, _getPrototypeOf(UIwendang).apply(this, arguments))).text = "",e
        }
        return _inherits(UIwendang, Fe), _createClass(UIwendang, [{
            key: "OnCreate",
            value: function () {
                this.ui.m_btn_fanhui.onClick(this, this.fanhuiFun)
            }
        }, {
            key: "fanhuiFun",
            value: function () {
                j.inst.PopUI(this.layer, !1)
            }
        }, {
            key: "OnShow",
            value: function () {
                console.log(" UIwendang OnShow==>>", arguments.length <= 0 ? void 0 : arguments[0]), 0 == (arguments.length <= 0 ? void 0 : arguments[0]) ? (this.ui.m_loader_biaoti.url = "ui://jyvm79orfkj2s", this.ui.m_wenAn.m_text_wenan.text = this.text_yinsi) : (this.ui.m_loader_biaoti.url = "ui://jyvm79orfkj2t", this.ui.m_wenAn.m_text_wenan.text = this.text_canping)
            }
        }, {
            key: "OnHide",
            value: function () {}
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "onSwitch",
            value: function () {}
        }, {
            key: "onAniEnd",
            value: function () {}
        }, {
            key: "updateScene",
            value: function () {
                arguments.length > 0 && void 0 !== arguments[0] && arguments[0]
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_bg]
            }
        }]), UIwendang
    }();
    $e = __decorate([ui_register(fe, Ve)], $e);
    var Ke = function (t) {
        function UIYinSi2() {
            return _classCallCheck(this, UIYinSi2), _possibleConstructorReturn(this, _getPrototypeOf(UIYinSi2).apply(this, arguments))
        }
        return _inherits(UIYinSi2, Fe), _createClass(UIYinSi2, [{
            key: "OnCreate",
            value: function () {}
        }, {
            key: "OnShow",
            value: function () {
                0 == (arguments.length <= 0 ? void 0 : arguments[0]) ? (this.ui.m_comp_yinsi2.m_btn_agree.visible = !1, this.ui.m_comp_yinsi2.m_btn_reject.visible = !1) : (this.ui.m_comp_yinsi2.m_btn_agree.visible = !0, this.ui.m_comp_yinsi2.m_btn_reject.visible = !0), this.ui.m_comp_yinsi2.m_btn_agree.onClick(this, this.AgreeFun), this.ui.m_comp_yinsi2.m_btn_reject.onClick(this, this.RejectFun), this.ui.m_comp_yinsi2.m_btn_fuwuxieyi.onClick(this, this.yonghuxieyi), this.ui.m_comp_yinsi2.m_btn_yinsizhengce.onClick(this, this.chanpinyinsishuoming)
            }
        }, {
            key: "AgreeFun",
            value: function () {
                j.inst.PopUI(this.layer, !1), Laya.LocalStorage.getItem("HadAgreeFirst") || Laya.LocalStorage.setItem("HadAgreeFirst", "1"), mt.hasAgreeXieYi = !0
            }
        }, {
            key: "RejectFun",
            value: function () {
                qg.exitApplication({}), mt.hasAgreeXieYi = !1
            }
        }, {
            key: "chanpinyinsishuoming",
            value: function () {
                j.inst.PushUI($e, e.wendang, 0)
            }
        }, {
            key: "yonghuxieyi",
            value: function () {
                j.inst.PushUI($e, e.wendang, 1)
            }
        }, {
            key: "OnHide",
            value: function () {}
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "onSwitch",
            value: function () {}
        }, {
            key: "onAniEnd",
            value: function () {}
        }, {
            key: "updateScene",
            value: function () {
                arguments.length > 0 && void 0 !== arguments[0] && arguments[0]
            }
        }]), UIYinSi2
    }();
    Ke = __decorate([ui_register(ue, Ve)], Ke);
    var Ye = function (t) {
        function UIYinSi() {
            return _classCallCheck(this, UIYinSi), _possibleConstructorReturn(this, _getPrototypeOf(UIYinSi).apply(this, arguments))
        }
        return _inherits(UIYinSi, Fe), _createClass(UIYinSi, [{
            key: "OnCreate",
            value: function () {}
        }, {
            key: "OnShow",
            value: function () {
                0 == (arguments.length <= 0 ? void 0 : arguments[0]) ? (this.ui.m_comp_yinsi1.m_btn_agree.visible = !1, this.ui.m_comp_yinsi1.m_btn_reject.visible = !1, this.ui.m_comp_yinsi1.m_btn_close.visible = !0) : (this.ui.m_comp_yinsi1.m_btn_agree.visible = !0, this.ui.m_comp_yinsi1.m_btn_reject.visible = !0), this.ui.m_comp_yinsi1.m_btn_agree.onClick(this, this.AgreeFun), this.ui.m_comp_yinsi1.m_btn_reject.onClick(this, this.RejectFun), this.ui.m_comp_yinsi1.m_btn_yonghuxieyi.onClick(this, this.yonghuxieyi), this.ui.m_comp_yinsi1.m_btn_chanpinyinsishuoming.onClick(this, this.chanpinyinsishuoming), this.ui.m_comp_yinsi1.m_btn_close.onClick(this, function () {
                    j.inst.PopUI(e.yinSi, !0)
                })
                this.ui.m_comp_yinsi1.m_btn_yonghuxieyi.visible = false
            }
        }, {
            key: "AgreeFun",
            value: function () {
                j.inst.PopUI(this.layer, !0), Laya.LocalStorage.getItem("HadAgreeFirst") || Laya.LocalStorage.setItem("HadAgreeFirst", "1"), mt.hasAgreeXieYi = !0
            }
        }, {
            key: "RejectFun",
            value: function () {
                j.inst.PopUI(e.yinSi, !0), j.inst.PushUI(Ke, e.yinSi, 2), mt.hasAgreeXieYi = !1
            }
        }, {
            key: "chanpinyinsishuoming",
            value: function () {
                j.inst.PushUI($e, e.wendang, 0)
            }
        }, {
            key: "yonghuxieyi",
            value: function () {
                j.inst.PushUI($e, e.wendang, 1)
            }
        }, {
            key: "OnHide",
            value: function () {}
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "onSwitch",
            value: function () {}
        }, {
            key: "onAniEnd",
            value: function () {}
        }, {
            key: "updateScene",
            value: function () {
                arguments.length > 0 && void 0 !== arguments[0] && arguments[0]
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_com_mengban]
            }
        }]), UIYinSi
    }();
    Ye = __decorate([ui_register(ge, Ve)], Ye);
    var qe = Math.PI,
        Je = qe / 180,
        Ze = 180 / qe,
        Qe = function () {
            function Maths() {
                _classCallCheck(this, Maths)
            }
            return _createClass(Maths, null, [{
                key: "formula2",
                value: function (e, t, n) {
                    return (e + t % n) % n
                }
            }, {
                key: "formula",
                value: function (e, t) {
                    for (var n = t * e; e--;) n += e;
                    return n
                }
            }, {
                key: "isEven",
                value: function (e) {
                    return e % 2 == 0
                }
            }, {
                key: "toRadian",
                value: function (e) {
                    return e * Je
                }
            }, {
                key: "converGold",
                value: function (e) {
                    return ""
                }
            }, {
                key: "equallyNum",
                value: function (e, t, n, i) {
                    var a = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                        o = Math.floor(e / t);
                    a && (i = o - 1);
                    for (var s = [], r = 0, l = !0, u = 0; u < t; u++) l ? (l = !1, r = this.minToMax(n, i), s.push(o + r)) : (l = !0, s.push(o - r));
                    return s
                }
            }, {
                key: "decimal",
                value: function (e) {
                    return e -= Math.floor(e)
                }
            }, {
                key: "toDegree",
                value: function (e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    return null == e ? 0 : (t && (e = this.normalizeAngle(e)), e * Ze)
                }
            }, {
                key: "normalizeAngle",
                value: function (e) {
                    return (e %= 2 * qe) < 0 && (e += 2 * qe), e
                }
            }, {
                key: "checkRange",
                value: function (e, t, n) {
                    return Math.abs(e - t) <= n
                }
            }, {
                key: "isTargetRange",
                value: function (e, t, n) {
                    return e >= t - n || e <= t + n
                }
            }, {
                key: "zeroEqually",
                value: function (e, t, n) {
                    return (t - (n - 1) / 2) * e
                }
            }, {
                key: "equally",
                value: function () {
                    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, t = arguments.length > 1 ? arguments[1] : void 0, n = [], i = ((arguments.length > 2 ? arguments[2] : void 0) - t) / ++e, a = 1; a < e; a++) n.push(~~(t + i * a));
                    return n
                }
            }, {
                key: "abs_sub_length",
                value: function (e, t) {
                    return Math.abs(e - t)
                }
            }, {
                key: "add_arrs",
                value: function (e) {
                    var t = 0,
                        n = !0,
                        i = !1,
                        a = void 0;
                    try {
                        for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done); n = !0) {
                            t += o.value
                        }
                    } catch (e) {
                        i = !0, a = e
                    } finally {
                        try {
                            n || null == s.return || s.return()
                        } finally {
                            if (i) throw a
                        }
                    }
                    return t
                }
            }, {
                key: "lerp",
                value: function (e, t, n) {
                    return e + (t - e) * n
                }
            }, {
                key: "clamp01",
                value: function (e) {
                    return e < 0 ? 0 : e < 1 ? e : 1
                }
            }, {
                key: "clampf",
                value: function (e, t, n) {
                    if (t > n) {
                        var i = t;
                        t = n, n = i
                    }
                    return e < t ? t : e < n ? e : n
                }
            }, {
                key: "isClampf",
                value: function (e, t, n) {
                    if (t > n) {
                        var i = t;
                        t = n, n = i
                    }
                    return e <= n && e >= t
                }
            }, {
                key: "create_arr_num",
                value: function (e) {
                    for (var t = [], n = 0; n < e; n++) t.push(n);
                    return t
                }
            }, {
                key: "isRandom",
                value: function (e) {
                    return !!e && (e >= 1 || !(e <= 0) && e > Math.random())
                }
            }, {
                key: "zeroToMax",
                value: function (e) {
                    if (e <= 1) return 0;
                    var t = Math.random();
                    return ~~((1 == t ? .5 : t) * e)
                }
            }, {
                key: "minToMax",
                value: function (e, t) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    return e == t ? e : e < 0 ? n ? Math.round(Math.random() * (Math.abs(e) + t)) + e : Math.random() * (Math.abs(e) + t) + e : n ? Math.round(Math.random() * (t - e)) + e : Math.random() * (t - e) + e
                }
            }, {
                key: "converNumber",
                value: function (e) {
                    if ("string" == typeof e) return Number(e)
                }
            }, {
                key: "find_num_section",
                value: function (e, t, n) {
                    var i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                    n || (n = {
                        i: 0,
                        count: 0
                    }), n.i = e.length, n.count = 0;
                    for (var a = 0; a < e.length; a++)
                        if (n.count += e[a], i) {
                            if (t <= n.count) return n.i = a, n
                        } else if (t < n.count) return n.i = a, n;
                    return n
                }
            }, {
                key: "find_num_section_random",
                value: function (e) {
                    for (var t = this.add_arrs(e), n = 0, i = this.zeroToMax(t - 1), a = 0; a < e.length; a++) {
                        var o = e[a];
                        if (i >= n && i < n + o) return a;
                        n += o
                    }
                    return e.length
                }
            }]), Maths
        }();
    new Laya.Vector3, new Laya.Vector3, new Laya.Vector3(1, 1, 1), new Laya.Vector3(0, 1, 0), new Laya.Vector3(0, 0, 1), new Laya.Vector3(0, 180, 0), new Laya.Point, new Laya.Quaternion;
    var et, tt = function (e) {
            return null != e && null != e && !1 !== e
        },
        nt = function (e) {
            if (null == e || 0 === e || "" === e) return e;
            var t = function (e, t, n) {
                var i = function (e, t) {
                    for (; e;) {
                        var n = Object.getOwnPropertyDescriptor(e, t);
                        if (n) return n;
                        e = Object.getPrototypeOf(e)
                    }
                    return null
                }(t, e);
                Object.defineProperty(n, e, i)
            };
            return "object" === _typeof(e) ? function (e) {
                for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                e = e || {};
                for (var o = 1, s = arguments.length; o < s; o++) {
                    var r = arguments[o];
                    if (r) {
                        if ("object" !== _typeof(r)) continue;
                        for (var l in r) t(l, r, e)
                    }
                }
                return e
            }(Array.isArray(e) ? [] : {}, e) : e
        },
        it = function () {
            function Sets() {
                var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                _classCallCheck(this, Sets), this.sets = [], this.isRepeat = !0, this.isRepeat = e;
                for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                this.add.apply(this, n)
            }
            return _createClass(Sets, [{
                key: "add",
                value: function () {
                    for (var e = 0; e < arguments.length; e++) {
                        var t = e < 0 || arguments.length <= e ? void 0 : arguments[e];
                        this.has(t) && this.isRepeat || this.sets.push(t)
                    }
                    return this
                }
            }, {
                key: "delete",
                value: function (e) {
                    return Sets.delete(this.sets, e)
                }
            }, {
                key: "indexOf",
                value: function (e) {
                    return this.sets.indexOf(e)
                }
            }, {
                key: "has",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    return Sets.has(this.sets, e, t)
                }
            }, {
                key: "hasOf",
                value: function (e) {
                    return tt(this.sets[e])
                }
            }, {
                key: "clear",
                value: function () {
                    this.sets.length = 0
                }
            }, {
                key: "shift",
                value: function () {
                    return !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0] ? this.sets.shift() : this.sets.concat()[0]
                }
            }, {
                key: "toString",
                value: function () {
                    return this.sets.toString()
                }
            }, {
                key: "forEach",
                value: function (e) {
                    return this.sets.forEach(e), this
                }
            }, {
                key: "map",
                value: function (e) {
                    return Sets.map(this.sets, e)
                }
            }, {
                key: "findContinueIndexs",
                value: function (e) {
                    for (var t = this.map(e), n = [], i = 0; i < t.length; i++) {
                        for (var a = [], o = 0; o < t.length - i; o++) {
                            var s = t[i + o];
                            if (s != t[i] + o) break;
                            a.push(t.indexOf(s))
                        }
                        a.length > 1 && n.push(a)
                    }
                    for (var r = [], l = 0; l < n.length; l++) {
                        var u = n[l],
                            h = this._findContinueIndexs(r, u); - 1 == h ? r.push(u) : r[h].length < u.length && (r[h] = u)
                    }
                    return r
                }
            }, {
                key: "_findContinueIndexs",
                value: function (e, t) {
                    for (var n = 0; n < e.length; n++)
                        for (var i = 0; i < e[n].length; i++)
                            if (-1 != t.indexOf(e[n][i])) return n;
                    return -1
                }
            }, {
                key: "findEquallyIndexs",
                value: function () {
                    for (var e = new Sets, t = 0; t < this.sets.length; t++) {
                        for (var n = this.sets[t], i = [], a = 0; a < this.sets.length; a++) {
                            n == this.sets[a] && i.push(a)
                        }
                        i.length > 1 && (e.has(i, !0) || e.add(i))
                    }
                    return e
                }
            }, {
                key: "sort",
                value: function (e) {
                    return Sets.sort(this.sets, e), this
                }
            }, {
                key: "deleteFilterOf",
                value: function (e) {
                    var t = this.filterOf(e);
                    return -1 != t && (this.splice(t), !0)
                }
            }, {
                key: "filterOf",
                value: function (e) {
                    return Sets.filterOf(this.sets, e)
                }
            }, {
                key: "filterValue",
                value: function (e) {
                    return Sets.filterValue(this.sets, e)
                }
            }, {
                key: "filter",
                value: function (e) {
                    for (var t = new Sets(this.isRepeat), n = 0; n < this.sets.length; n++) {
                        var i = this.sets[n];
                        e(i, n, this.sets) && t.add(i)
                    }
                    return t
                }
            }, {
                key: "deletePops",
                value: function () {
                    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, t = arguments.length > 1 ? arguments[1] : void 0, n = 0; n < e; n++) {
                        var i = this.pop();
                        i && t && t(i)
                    }
                }
            }, {
                key: "splice",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                    return this.sets.splice(e, t)
                }
            }, {
                key: "unShift",
                value: function () {}
            }, {
                key: "pop",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    return Sets.pop(this.sets, e)
                }
            }, {
                key: "lastValueOf",
                value: function (e) {
                    return this.sets[this.sets.length - e - 1] || null
                }
            }, {
                key: "valuesOf",
                value: function (e) {
                    return this.sets[e] || null
                }
            }, {
                key: "randomOf",
                value: function () {
                    return 0 == this.size ? null : this.sets[Qe.zeroToMax(this.sets.length)]
                }
            }, {
                key: "addRandomSelf",
                value: function () {
                    if (0 == this.size) return !1;
                    var e = this.sets[Qe.zeroToMax(this.sets.length)];
                    return this.add(e), !0
                }
            }, {
                key: "shuffle",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    return Sets.shuffle(this.sets, e)
                }
            }, {
                key: "deep",
                value: function () {
                    var e = JSON.parse(JSON.stringify(this.sets));
                    return _construct(Sets, [this.isRepeat].concat(_toConsumableArray(e)))
                }
            }, {
                key: "concat",
                value: function () {
                    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return _construct(Sets, [this.isRepeat].concat(_toConsumableArray(this.sets.concat(t))))
                }
            }, {
                key: "size",
                get: function () {
                    return this.sets.length
                }
            }], [{
                key: "delete",
                value: function (e, t) {
                    if (0 == e.length) return !1;
                    var n = e.indexOf(t);
                    return -1 != n && (e.splice(n, 1), !0)
                }
            }, {
                key: "map",
                value: function (e, t) {
                    for (var n = [], i = 0; i < e.length; i++) {
                        var a = t(e[i], i, e);
                        n.push(a)
                    }
                    return n
                }
            }, {
                key: "has",
                value: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                    return 0 != e.length && -1 != (n ? this.map(e, function (e) {
                        return e.toString()
                    }).indexOf(t.toString()) : e.indexOf(t))
                }
            }, {
                key: "add",
                value: function (e) {
                    for (var t = 0; t < (arguments.length <= 1 ? 0 : arguments.length - 1); t++) {
                        var n = t + 1 < 1 || arguments.length <= t + 1 ? void 0 : arguments[t + 1];
                        this.has(e, n) || e.push(n)
                    }
                }
            }, {
                key: "random",
                value: function (e, t) {
                    if (0 == e.length) return null;
                    if (t) {
                        for (var n = [], i = 0, a = e.length; i < a; i++) t(e[i], i) || n.push(n[i]);
                        return this.random(n)
                    }
                    return e[Qe.zeroToMax(e.length)]
                }
            }, {
                key: "getAt",
                value: function (e, t) {
                    return e[t = Qe.clampf(t, 0, e.length - 1)]
                }
            }, {
                key: "filterValue",
                value: function (e, t) {
                    var n = this.filterOf(e, t);
                    return -1 == n ? null : e[n]
                }
            }, {
                key: "filterOf",
                value: function (e, t) {
                    for (var n = 0; n < e.length; n++)
                        if (e[n] && t(e[n], n)) return n;
                    return -1
                }
            }, {
                key: "filter",
                value: function (e, t, n) {
                    n || (n = []);
                    for (var i = 0; i < e.length; i++) e[i] && t(e[i], i) && n.push(e[i]);
                    return n
                }
            }, {
                key: "push",
                value: function (e, t) {
                    var n = !0,
                        i = !1,
                        a = void 0;
                    try {
                        for (var o, s = t[Symbol.iterator](); !(n = (o = s.next()).done); n = !0) {
                            var r = o.value;
                            e.push(r)
                        }
                    } catch (e) {
                        i = !0, a = e
                    } finally {
                        try {
                            n || null == s.return || s.return()
                        } finally {
                            if (i) throw a
                        }
                    }
                    return e
                }
            }, {
                key: "sort",
                value: function (e, t) {
                    return e.sort(t)
                }
            }, {
                key: "shuffle",
                value: function (e) {
                    if (!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) return e.sort(function (e, t) {
                        return Math.random() > .5 ? 1 : -1
                    }), e;
                    var t = e.concat();
                    return t.sort(function (e, t) {
                        return Math.random() > .5 ? 1 : -1
                    }), t
                }
            }, {
                key: "random_arr",
                value: function (e) {
                    for (var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, n = this.shuffle(e, !1), i = [], a = 0; a < t; a++) tt(n[a]) && i.push(n[a]);
                    return i
                }
            }, {
                key: "pop",
                value: function (e) {
                    return !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1] ? e.pop() : e[e.length - 1] || null
                }
            }]), Sets
        }(),
        at = null,
        ot = null,
        st = 0,
        rt = function () {
            function LocalCache() {
                _classCallCheck(this, LocalCache)
            }
            return _createClass(LocalCache, null, [{
                key: "converKey",
                value: function (e) {
                    return -1 == e.indexOf(this.setCatchKeyPrefix) ? this.setCatchKeyPrefix + e : e
                }
            }, {
                key: "set",
                value: function (e, t) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    e = this.converKey(e), this.checkCacheValue(t) && (this.cache[e] = t, it.add(this.updateCache, e), n ? Laya.timer.once(this.delayCache, this, this.onSet, null, !0) : this.onSet())
                }
            }, {
                key: "get",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                    if (e = this.converKey(e), at = this.cache[e], !this.checkCacheValue(at))
                        if (at = Laya.LocalStorage.getItem(e), this.checkCacheValue(at)) switch (st = at.indexOf("-"), ot = at.substring(0, st), at = at.substring(st + 1), ot) {
                            case "boolean":
                                this.cache[e] = "true" == at;
                                break;
                            case "number":
                                this.cache[e] = Number(at);
                                break;
                            case "object":
                                this.cache[e] = JSON.parse(at);
                                break;
                            case "string":
                                this.cache[e] = at;
                                break;
                            default:
                                at = nt(t), this.cache[e] = at
                        } else at = nt(t), this.cache[e] = at, this.set(e, this.cache[e], !1);
                    return this.cache[e]
                }
            }, {
                key: "checkCacheValue",
                value: function (e) {
                    return null != e && "null" != e && null != e
                }
            }, {
                key: "onSet",
                value: function () {
                    var e = !0,
                        t = !1,
                        n = void 0;
                    try {
                        for (var i, a = this.updateCache[Symbol.iterator](); !(e = (i = a.next()).done); e = !0) {
                            var o = i.value;
                            switch (at = this.cache[o], ot = _typeof(at)) {
                                case "boolean":
                                case "number":
                                    at += "";
                                    break;
                                case "object":
                                    at = JSON.stringify(at);
                                    break;
                                case "string":
                                    break;
                                default:
                                    at = null
                            }
                            null != at && Laya.LocalStorage.setItem(o, ot + "-" + at)
                        }
                    } catch (e) {
                        t = !0, n = e
                    } finally {
                        try {
                            e || null == a.return || a.return()
                        } finally {
                            if (t) throw n
                        }
                    }
                    this.updateCache.length = 0
                }
            }, {
                key: "has",
                value: function (e) {
                    return e = this.converKey(e), !!this.get(e)
                }
            }, {
                key: "delete",
                value: function (e) {
                    e = this.converKey(e), delete this.cache[e], Laya.LocalStorage.removeItem(e)
                }
            }, {
                key: "clear",
                value: function () {
                    this.cache = {}, Laya.LocalStorage.clear()
                }
            }, {
                key: "setCatchKeyPrefix",
                get: function () {
                    return this._setCatchKeyPrefix
                }
            }]), LocalCache
        }();
    rt.cache = {}, rt.updateCache = [], rt._setCatchKeyPrefix = "", rt.delayCache = 200,
        function (e) {
            e.LOADING_START = "加载开始", e.LOADING_END = "加载结束", e.GUIDE_COLLECT_TAG = "新手引导收集铭牌", e.GUIDE_BUILD_ENEMY = "新手引导建造兵营", e.GUIDE_LEVEL_UP = "新手引导升级军衔", e.GUIDE_BATTLE_START = "新手引导出兵", e.WIN_NUKEALERT = "核弹请求弹窗", e.WIN_NUKEALERT_VIDEO = "核弹请求弹窗视频", e.NUKE_YUYUE_WIN = "核弹预约弹窗", e.NUKE_CLICK_YUYUE = "点击核弹预约", e.NUKE_CLICK_YUYUE_N = "点击预约取消", e.NUKE_FALL_FREE_START = "免费核弹掉落开始", e.NUKE_FALL_FREE_END = "免费核弹掉落完毕", e.NUKE_GET_FREE = "拾取免费核弹", e.NUKE_USE_FREE = "使用免费核弹", e.WIN_PLANE = "下局轰炸机弹窗", e.WIN_PLANE_VIDEO = "下局轰炸机弹窗视频", e.GET_CAERRIER = "获得永久战马", e.TRY_CAERRIER_VIDEO = "视频试用战马", e.LEVEL_UP = "升级军衔", e.ENTER_GAME = "进入关卡", e.GAME_END = "关卡结算", e.COLLECT_TAG = "收集铭牌", e.WIN_REBORN = "复活弹窗", e.WIN_REBORN_VIDEO = "复活弹窗视频", e.WIN_TAG = "额外铭牌弹窗", e.WIN_TAG_VIDEO = "额外铭牌弹窗视频", e.WIN_AIRTAG = "空投双倍铭牌弹窗", e.WIN_AIRTAG_VIDEO = "空投双倍铭牌弹窗视频", e.WIN_SHARE = "视频失败分享弹窗", e.WIN_SHARE_OK = "点击分享弹窗分享", e.WIN_SHARE_CLOSE = "点击分享弹窗关闭", e.BUILD_ENEMY1 = "建造兵营1", e.BUILD_ENEMY2 = "建造兵营2", e.BUILD_ENEMY3 = "建造兵营3", e.BUILD_ENEMY4 = "建造兵营4", e.BUILD_TANK = "建造坦克营", e.BUILD_WEAPON = "建造武器生产设备", e.CLICK_HANGMU = "点击航母图标", e.CLICK_DUANZAO = "点击航母锻造", e.GET_HANGMU = "获得航母", e.CLICK_ROBOT_BTN = "未解锁点击机甲", e.CLICK_ROBOT_UNLOCK = "点击按钮解锁机甲", e.CLICK_ROBOT = "机甲弹窗", e.TRY_ROBOT = "机甲试用", e.SHARE_ROBOT = "机甲分享按钮", e.SHARE_OPENDATA_ROBOT = "机甲开放域分享按钮", e.GET_ROBOT = "获得机甲"
        }(et || (et = {}));
    var lt = function () {
            function ReportMgr() {
                _classCallCheck(this, ReportMgr), this._reportNoSave = [et.LEVEL_UP, et.ENTER_GAME, et.GAME_END, et.COLLECT_TAG, et.WIN_REBORN, et.WIN_REBORN_VIDEO, et.WIN_TAG, et.WIN_TAG_VIDEO, et.WIN_AIRTAG, et.WIN_AIRTAG_VIDEO, et.BUILD_ENEMY1, et.BUILD_ENEMY2, et.BUILD_ENEMY3, et.BUILD_ENEMY4, et.BUILD_TANK, et.WIN_SHARE, et.WIN_SHARE_CLOSE, et.WIN_SHARE_OK, et.BUILD_WEAPON, et.CLICK_ROBOT_BTN, et.CLICK_ROBOT, et.SHARE_ROBOT, et.SHARE_OPENDATA_ROBOT], this._reportNoSuf = [et.LOADING_START, et.LOADING_END], this._sp = {}
            }
            return _createClass(ReportMgr, [{
                key: "sendReport",
                value: function (e) {
                }
            }, {
                key: "_hasLocal",
                value: function (e) {
                    return this._local.indexOf(e) >= 0
                }
            }, {
                key: "_addLocal",
                value: function (e) {
                    var t = this._local + e + ",";
                    rt.set("LogickData._reportGuide", t)
                }
            }, {
                key: "_getVersionStr",
                value: function (e) {
                    return e || (e = ""), e.replace(/\./g, "")
                }
            }, {
                key: "getNextUnlockId",
                value: function (e) {
                    var t = rt.get("解锁类型" + e, 0);
                    return t++, rt.set("解锁类型" + e, t), t
                }
            }, {
                key: "_local",
                get: function () {
                    return rt.get("LogickData._reportGuide", "")
                }
            }], [{
                key: "inst",
                get: function () {
                    return this._inst || (this._inst = new ReportMgr), this._inst
                }
            }]), ReportMgr
        }(),
        ut = function () {
            function DesMg() {
                _classCallCheck(this, DesMg)
            }
            return _createClass(DesMg, null, [{
                key: "encode",
                value: function (e) {
                    for (var t = this.utf8Encode(e), n = t.slice(0, 2), i = 0; i < t.length; i++) {
                        var a = t[i];
                        a ^= n[i % 2], n[i + 2] = a
                    }
                    return this.encode_base(n, !0)
                }
            }, {
                key: "decode",
                value: function (e) {
                    for (var t = this.decode_base(e, !0), n = t.slice(0, 2), i = t.slice(2, t.length), a = 0, o = i.length; a < o; a++) {
                        var s = i[a];
                        s ^= n[a % 2], i[a] = s
                    }
                    return this.utf8Decode(i)
                }
            }, {
                key: "encode_base",
                value: function (e, t) {
                    for (var n, i, a, o, s, r, l, u = "", h = 0, c = t ? e : this.utf8Encode(e); h < c.length;) o = (n = c[h++]) >> 2, s = (3 & n) << 4 | (i = c[h++]) >> 4, r = (15 & i) << 2 | (a = c[h++]) >> 6, l = 63 & a, isNaN(i) ? r = l = 64 : isNaN(a) && (l = 64), u = u + this._keyStr.charAt(o) + this._keyStr.charAt(s) + this._keyStr.charAt(r) + this._keyStr.charAt(l);
                    return u
                }
            }, {
                key: "decode_base",
                value: function (e, t) {
                    var n, i, a, o, s, r, l = 0;
                    e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
                    for (var u = []; l < e.length;) n = this._keyStr.indexOf(e.charAt(l++)) << 2 | (o = this._keyStr.indexOf(e.charAt(l++))) >> 4, i = (15 & o) << 4 | (s = this._keyStr.indexOf(e.charAt(l++))) >> 2, a = (3 & s) << 6 | (r = this._keyStr.indexOf(e.charAt(l++))), u.push(n), 64 != s && u.push(i), 64 != r && u.push(a);
                    return !0 === t ? u : this.utf8Decode(u)
                }
            }, {
                key: "utf8Encode",
                value: function (e) {
                    e = e.replace(/\r\n/g, "\n");
                    for (var t = [], n = 0; n < e.length; n++) {
                        var i = e.charCodeAt(n);
                        i < 128 ? t.push(i) : i > 127 && i < 2048 ? (t.push(192 | i(i >> 6)), t.push(63 & i | 128)) : (t.push(i >> 12 | 224), t.push(i >> 6 & 63 | 128), t.push(63 & i | 128))
                    }
                    return t
                }
            }, {
                key: "utf8Decode",
                value: function (e) {
                    for (var t, n, i = "", a = 0, o = 0; a < e.length;)(t = e[a]) < 128 ? (i += String.fromCharCode(t), a++) : t > 191 && t < 224 ? (n = e[a + 1], i += String.fromCharCode((31 & t) << 6 | 63 & n), a += 2) : (n = e[a + 1], o = e[a + 2], i += String.fromCharCode((15 & t) << 12 | (63 & n) << 6 | 63 & o), a += 3);
                    return i
                }
            }]), DesMg
        }();
    ut._keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var gt = function (e) {
            function FlowView() {
                var e;
                return _classCallCheck(this, FlowView), (e = _possibleConstructorReturn(this, _getPrototypeOf(FlowView).call(this))).designW = 750, e.designH = 1334, e.width = Laya.stage.width, e.height = Laya.stage.height, e._initBg(), e._initBtn(), e._initLabel(), e
            }
            return _inherits(FlowView, fgui.GComponent), _createClass(FlowView, [{
                key: "_initBg",
                value: function () {
                    this._bg = new fgui.GGraph, this._bg.setSize(this.width, this.height), this._bg.drawRect(0, "", "#000000ff"), this.addChild(this._bg)
                }
            }, {
                key: "_initLabel",
                value: function () {
                    this._title = new fairygui.GBasicTextField, this._title.setSize(484, 104), this._title.fontSize = 80, this._title.color = "#ffffff", this._title.stroke = 2, this._title.strokeColor = "#E08C2B", this._title.font = "SimHei", this._title.text = "热门游戏推荐", this._title.setPivot(.5, .5), this.addChild(this._title), this._title.x = this.width - this._title.width >> 1, this._title.y = this.height / this.designH * 130, this._title.touchable = !1
                }
            }, {
                key: "_initBtn",
                value: function () {
                    this._btnClose = new fgui.GButton, this._btnClose.setSize(395, 112);
                    var e = new fgui.GGraph;
                    e.setSize(this._btnClose.width, this._btnClose.height), e.drawRect(2, "#FFFF00", "#E08E32", [20, 20, 20, 20]), this._btnClose.addChild(e), e.touchable = !1;
                    var t = new fgui.GGraph;
                    t.setSize(this._btnClose.width - 4, 98), t.drawRect(0, "", "#FDC314", [18, 18, 18, 18]), this._btnClose.addChild(t), t.x = t.y = 2, t.touchable = !1;
                    var n = new fairygui.GBasicTextField;
                    n.setSize(228, 74), n.fontSize = 56, n.color = "#ffffff", n.font = "SimHei", n.text = "点击关闭", this._btnClose.addChild(n), n.x = 83, n.y = 15, n.touchable = !1, this._btnClose.onClick(this, this._onClickBtn), this._btnClose.on(Laya.Event.MOUSE_DOWN, this, this._onMouseDownBtn), this._btnClose.on(Laya.Event.MOUSE_UP, this, this._onMouseUpBtn), this._btnClose.on(Laya.Event.MOUSE_OVER, this, this._onMouseUpBtn), this._btnClose.displayObject.mouseThrough = !1, this.addChild(this._btnClose), this._btnClose.setPivot(.5, .5), this._btnClose.x = this.width - this._btnClose.width >> 1, this._btnClose.y = this.height / this.designH * 1077
                }
            }, {
                key: "_onMouseDownBtn",
                value: function () {
                    this._btnClose.setScale(1.1, 1.1)
                }
            }, {
                key: "_onMouseUpBtn",
                value: function () {
                    this._btnClose.setScale(1, 1)
                }
            }, {
                key: "_onClickBtn",
                value: function () {
                    var e = this,
                        t = "";
                    switch (this._type) {
                        case kt.Loading:
                            t = "登录界面";
                            break;
                        case kt.Click_Start:
                            t = "点击开始";
                            break;
                        case kt.End_Game:
                            t = "结算界面";
                            break;
                        case kt.Back_Main:
                            t = "回到主界面";
                            break;
                        default:
                            t = "未知界面" + this._type
                    }
                    t += "瀑布流视频", mt.showRwdVideo(t).then(function () {
                        e._cb && e._cb.run()
                    })
                }
            }, {
                key: "showFlow",
                value: function (e, t) {
                    this._type = e, this._cb = t
                }
            }]), FlowView
        }();
    var vt = {
            LONG_TIME_NO_OPERATION: "LONG_TIME_NO_OPERATION",
            OpenAutoFN: "OpenAutoFN"
        },
        mt = function () {
            function GameSDK$1() {
                _classCallCheck(this, GameSDK$1)
            }
            return _createClass(GameSDK$1, null, [
				  {
                key: "getPlayTime",
                value: function () {
                    return null == this._todayOL && (this._todayOL = this.getDataByTimeLimit(this.KeyTodayOnline, 0)), 0 != this.startGameTime ? this._todayOL + Math.floor((this.serverTime - this.startGameTime - this.getLeaveGameTime()) / 1e3) : this._todayOL
                }
            }, {
                key: "savePlayTime",
                value: function () {
                    this._isSameDay(this.serverTime, this.getTimeData(this.KeyTodayOnline).time) || (this._todayOL = 0, this.startGameTime = this.serverTime, this.sdk instanceof pt && this.sdk.resetLeaveGameTime()), this.setDataByTimeLimit(this.KeyTodayOnline, this.getPlayTime())
                }
            }, {
                key: "getLeaveGameTime",
                value: function () {
                    return this.sdk instanceof pt ? this.sdk.getLeaveGameTime() : 0
                }
            }, {
                key: "getDataByTimeLimit",
                value: function (e, t) {
                    return null == this._timeData[e + "_time_" + this.data.gameId] && (this._timeData[e + "_time_" + this.data.gameId] = this.getLocalCache(e + "_time_" + this.data.gameId, this.serverTime)), null == this._timeData[e + "_val_" + this.data.gameId] && (this._timeData[e + "_val_" + this.data.gameId] = this.getLocalCache(e + "_val_" + this.data.gameId, t)), this._isSameDay(this.serverTime, this._timeData[e + "_time_" + this.data.gameId]) || this.setDataByTimeLimit(e, t), this._timeData[e + "_val_" + this.data.gameId]
                }
            }, {
                key: "getTimeData",
                value: function (e) {
                    return {
                        val: this._timeData[e + "_val_" + this.data.gameId],
                        time: this._timeData[e + "_time_" + this.data.gameId]
                    }
                }
            }, {
                key: "setDataByTimeLimit",
                value: function (e, t) {
                    this._timeData[e + "_time_" + this.data.gameId] = this.serverTime, this._timeData[e + "_val_" + this.data.gameId] = t, this.setLocalCache(e + "_time_" + this.data.gameId, this._timeData[e + "_time_" + this.data.gameId]), this.setLocalCache(e + "_val_" + this.data.gameId, this._timeData[e + "_val_" + this.data.gameId])
                }
            }, {
                key: "_isSameDay",
                value: function (e, t) {
                    return new Date(e).toLocaleDateString() === new Date(t).toLocaleDateString()
                }
            },  {
                key: "CloseType",
                value: function () {
                    return console.log("----------------CloseType"), null == this.sdk.data.CloseType || this.isOffCitys() ? 1 : (console.log("----------------CLOSETYPE : " + this.sdk.data.CloseType), Number(this.sdk.data.CloseType))
                }
            }, {
                key: "initConfig",
                value: function (e) {
                    this.sdk.initConfig(e)
                }
            }, {
                key: "initCfg",
                value: function () {
                }
            }, {
                key: "isLimit",
                value: function () {
                    return this.isCurrentVersion || this.isOffCitys()
                }
            }, {
                key: "OpenAutoFN",
                value: function () {
                    this.sdk.OpenAutoFN()
                }
            }, {
                key: "showAlertAdLimit",
                value: function () {
                    return this.getPlayTime() >= this.getPlatData("ShowAlertAdLimit", 0)
                }
            }, {
                key: "isAdUser",
                value: function () {
                    return null == this._adUser && (this._adUser = this._isAdUser()), this._adUser
                }
            }, {
                key: "_isAdUser",
                value: function () {
                    return !0
                }
            }, {
                key: "isWhiteScene",
                value: function (e) {
                    if (1 == this.getPlatData("OpenWhiteScene")) {
                        if (null != this.getPlatData("WhiteScene")) {
                            var t = this.getPlatData("WhiteScene", "").split(","),
                                n = !0,
                                i = !1,
                                a = void 0;
                            try {
                                for (var o, s = t[Symbol.iterator](); !(n = (o = s.next()).done); n = !0) {
                                    if (+o.value == e) return !0
                                }
                            } catch (e) {
                                i = !0, a = e
                            } finally {
                                try {
                                    n || null == s.return || s.return()
                                } finally {
                                    if (i) throw a
                                }
                            }
                            return !1
                        }
                        return !1
                    }
                    return !0
                }
            }, {
                key: "isBlackScene",
                value: function (e) {
                    if (1 == this.getPlatData("OpenBlackScene")) {
                        if (null != this.getPlatData("BlackScene")) {
                            var t = this.getPlatData("BlackScene", "").split(","),
                                n = !0,
                                i = !1,
                                a = void 0;
                            try {
                                for (var o, s = t[Symbol.iterator](); !(n = (o = s.next()).done); n = !0) {
                                    if (+o.value == e) return !0
                                }
                            } catch (e) {
                                i = !0, a = e
                            } finally {
                                try {
                                    n || null == s.return || s.return()
                                } finally {
                                    if (i) throw a
                                }
                            }
                            return !1
                        }
                        return !0
                    }
                    return !1
                }
            }, {
                key: "showOpenInsert",
                value: function () {
                    this.sdk.loadingEnd = !0, 1 == this.getPlatData("ShowMainInsert") && this.showADInsert()
                }
            }, {
                key: "autoShowGrid9",
                value: function () {
                }
            }, {
                key: "showTriggerVideo",
                value: function (e, t, n) {
                    var i = this;
                    return new Promise(function (a, o) {
                        i.showRwdVideo(e, n).then(function (e) {
                            e || t && (t.active = !1, Laya.timer.once(2e3, i, function () {
                                t.active = !0
                            })), a(e)
                        })
                    })
                }
            }, {
                key: "changeNavigateTouchable",
                value: function (e) {
                    for (var t in this._navigateCustom) this._navigateCustom[t].touchable = e
                }
            }, {
                key: "showNavigateCustom",
                value: function (e, t) {
                    
                }
            }, {
                key: "checkEnterFromSub",
                value: function () {
                    if (this.sdk instanceof pt && 1014 == this.getLaunchOption().scene) {
                        var e = this.getLocalCache(this.SubMsgKey, ""),
                            t = this.getPlatData(this.SubMsgKey, "");
                        if (e && t.indexOf(e) >= 0) return lt.inst.sendReport("从订阅进入" + e, !1), !0
                    }
                    return !1
                }
            }, {
                key: "getTodaySub",
                value: function () {
                    return null == this._lastSubTime && (this._lastSubTime = this.getLocalCache(this.SubTimeKey, 0)), this._isSameDay(GameSDK$1.serverTime, this._lastSubTime)
                }
            }, {
                key: "setTodaySub",
                value: function () {
                    this._lastSubTime = GameSDK$1.serverTime, this.setLocalCache(this.SubTimeKey, this._lastSubTime)
                }
            },  {
                key: "stageOnStart",
                value: function (e) {
                    this.sdk.stageOnStart(e)
                }
            }, {
                key: "statgeOnRunning",
                value: function (e) {
                    this.sdk.statgeOnRunning(e)
                }
            }, {
                key: "stageOnEnd",
                value: function (e) {
                    this.sdk.stageOnEnd(e)
                }
            }, {
                key: "sendEvent",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                    q.sendEvent(e, t)
                }
            }, {
                key: "isOffCitys",
                value: function () {
                    if (!this.sdk.cityData.loc) return !1;
                    for (var e = this.sdk.cityData.loc.length, t = this.getPlatData("Offcitys", []), n = 0; n < e; n += 1)
                        if (t.indexOf(this.sdk.cityData.loc[n]) >= 0) return !0;
                    return !1
                }
            }, {
                key: "isOpenCitys",
                value: function () {
                    if (!this.sdk.cityData.loc) return !1;
                    for (var e = this.sdk.cityData.loc.length, t = this.getPlatData("OPLISTS", []), n = 0; n < e; n += 1)
                        if (t.indexOf(this.sdk.cityData.loc[n]) >= 0) return !0;
                    return !1
                }
            }, {
                key: "getNavigateList",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                        t = this.sdk.getNavigateList();
                    return e && this.sdk.shuffle(t, !1), t
                }
            }, {
                key: "navigateToMiniGame",
                value: function (e) {
                    this.sdk.navigateToMiniGame(e)
                }
            }, {
                key: "showBanner",
                value: function () {
                    return this.sdk instanceof pt ? this.sdk.showBanner() : (this.sdk.showBanner(), Promise.resolve(!0))
                }
            }, {
                key: "hideBanner",
                value: function () {
                    return this.sdk instanceof pt ? this.sdk.hideBanner() : (this.sdk.hideBanner(), Promise.resolve(!0))
                }
            }, {
                key: "isBannerShow",
                value: function () {
                    return this.sdk._isBannerShowing
                }
            }, {
                key: "resetBanner",
                value: function () {
                    this.sdk instanceof pt && this.sdk.resetBanner()
                }
            }, {
                key: "showADVideo",
                value: function (e, t, n, i) {
                    Plat.I.ShowVideo(n, ()=>{t.apply(e, [true])})
                }
            }, {
                key: "_checkTodayVideoCount",
                value: function () {
                    return null == this._lastVideoTime && (this._lastVideoTime = GameSDK$1.getLocalCache(this._lastVideoKey + X.data.GAMEID, "")), null == !this._todayVideoCount && (this._todayVideoCount = GameSDK$1.getLocalCache(this._todayVideoKey + X.data.GAMEID, 0)), this._resetLastVideoTime(), this._todayVideoCount < GameSDK$1.getPlatData("TodayVideoMax", 10)
                }
            }, {
                key: "_resetLastVideoTime",
                value: function () {
                    var e = (new Date).toLocaleDateString();
                    this._lastVideoTime != e && (this._todayVideoCount = 0, GameSDK$1.setLocalCache(this._todayVideoKey, this._todayVideoCount)), this._lastVideoTime = e, GameSDK$1.setLocalCache(this._lastVideoKey, this._lastVideoTime)
                }
            }, {
                key: "_addTodayVideoCount",
                value: function () {
                    this._resetLastVideoTime(), this._todayVideoCount++, GameSDK$1.setLocalCache(this._todayVideoKey, this._todayVideoCount)
                }
            }, {
                key: "showRwdVideo",
                value: function (e, t) {
                    var n = this;
                    return new Promise(function (i) {
                        if (n.sdk instanceof pt) {
                            if (!n._checkTodayVideoCount()) return n.showToast("播放过于频繁，建议明日进行尝试", 1500), void i(!1);
                            n._showVideo(e, t).then(function (e) {
                                n._addTodayVideoCount(), i(e)
                            })
                        } else i(!0)
                    })
                }
            }, {
                key: "_showVideo",
                value: function (e, t) {
                    var n = this;
                    return new Promise(function (i) {
                        n.sdk instanceof pt ? (n.callHideFunc(), n._autoVideoPtc = 1 / 0, n.sdk.showRwdVideo(e, t).then(function (e) {
                            e && q.instance.sendPlayerStay(n.isNewPlayer, n.getPlayTime()), n.callShowFunc(), n._autoVideoPtc = n.getPlatData("AutoVideoPtc", 30), i(e)
                        })) : i(!0)
                    })
                }
            }, {
                key: "clickAdButton",
                value: function (e, t, n) {
                    var i = this;
                    return new Promise(function (a, o) {
                        var s = function (t) {
                            e && (null != e.mouseEnabled ? e.mouseEnabled = t : null != e.touchable && (e.touchable = t))
                        };
                        s.bind(i), s(!1), i.showRwdVideo(t, n).then(function (e) {
                            s(!0), a(e)
                        })
                    })
                }
            }, {
                key: "registShowCaller",
                value: function (e, t, n) {
                    for (var i = 0; i < this._showFuncArr.length; ++i)
                        if (this._showFuncArr[i].caller == e && this._showFuncArr[i].func == t) return;
                    this._showFuncArr.push({
                        func: t,
                        caller: e,
                        args: n
                    })
                }
            }, {
                key: "removeShowCaller",
                value: function (e, t) {
                    for (var n = 0; n < this._showFuncArr.length; ++n) this._showFuncArr[n].caller == e && this._showFuncArr[n].func == t && this._showFuncArr.splice(n, 0)
                }
            }, {
                key: "registHideCaller",
                value: function (e, t, n) {
                    for (var i = 0; i < this._hideFuncArr.length; ++i)
                        if (this._hideFuncArr[i].caller == e && this._hideFuncArr[i].func == t) return;
                    this._hideFuncArr.push({
                        func: t,
                        caller: e,
                        args: n
                    })
                }
            }, {
                key: "removeHideCaller",
                value: function (e, t) {
                    for (var n = 0; n < this._hideFuncArr.length; ++n) this._hideFuncArr[n].caller == e && this._hideFuncArr[n].func == t && this._hideFuncArr.splice(n, 0)
                }
            }, {
                key: "callShowFunc",
                value: function (e) {
                    if (this._showFuncArr && this._showFuncArr.length) {
                        var t = !0,
                            n = !1,
                            i = void 0;
                        try {
                            for (var a, o = this._showFuncArr[Symbol.iterator](); !(t = (a = o.next()).done); t = !0) {
                                var s = a.value;
                                e ? s.func.call(s.caller, e, s.args) : s.func.call(s.caller, s.args)
                            }
                        } catch (e) {
                            n = !0, i = e
                        } finally {
                            try {
                                t || null == o.return || o.return()
                            } finally {
                                if (n) throw i
                            }
                        }
                    }
                }
            }, {
                key: "callHideFunc",
                value: function (e) {
                    if (this._hideFuncArr && this._hideFuncArr.length) {
                        var t = !0,
                            n = !1,
                            i = void 0;
                        try {
                            for (var a, o = this._hideFuncArr[Symbol.iterator](); !(t = (a = o.next()).done); t = !0) {
                                var s = a.value;
                                e ? s.func.call(s.caller, e, s.args) : s.func.call(s.caller, s.args)
                            }
                        } catch (e) {
                            n = !0, i = e
                        } finally {
                            try {
                                t || null == o.return || o.return()
                            } finally {
                                if (n) throw i
                            }
                        }
                    }
                }
            }, {
                key: "exchangeBtnAble",
                value: function () {
                    return Math.floor(100 * Math.random() + 1) < this.getPlatData("ExchangeBtn", 0)
                }
            }, {
                key: "exchangeBtn",
                value: function (e, t) {
                    if (e.parent == t.parent) {
                        var n = new Laya.Point(e.x, e.y);
                        e.setXY(t.x, t.y), t.setXY(n.x, n.y);
                        var i = e.parent,
                            a = i.getChildIndex(t),
                            o = e;
                        i._children[i.getChildIndex(e)] = t, i._children[a] = o
                    }
                }
            }, {
                key: "startVideoRecord",
                value: function () {
                    this.sdk.startVideoRecord()
                }
            }, {
                key: "pauseVideoRecord",
                value: function () {
                    this.sdk.pauseVideoRecord()
                }
            }, {
                key: "resumeVideoRecord",
                value: function () {
                    this.sdk.resumeVideoRecord()
                }
            }, {
                key: "stopVideoRecord",
                value: function () {
                    this.sdk.stopVideoRecord()
                }
            }, {
                key: "shareVideoRecord",
                value: function (e) {
                    this.sdk.shareVideoRecord(e)
                }
            }, {
                key: "isSupportShareVideo",
                value: function () {
                    return this.sdk.isSupportShareVideo()
                }
            }, {
                key: "vibrateShort",
                value: function (e) {
                    this.sdk.vibrateShort(e)
                }
            }, {
                key: "vibrateLong",
                value: function () {
                    this.sdk.vibrateLong()
                }
            }, {
                key: "isConfigUIModel",
                value: function (e) {
                    if (!e) return !0;
                    if (!this.sdk.data) return !0;
                    var t = this.sdk.data[e];
                    return !t || !t.state || ("1" == t.state || "0" != t.state)
                }
            }, {
                key: "getConfigUIModelInterval",
                value: function (e) {
                    if (!e) return 0;
                    if (!this.sdk.data) return 0;
                    var t = this.sdk.data[e];
                    return t && t.interval ? "string" == typeof t.interval ? Number(t.interval) : t.interval : 0
                }
            }, {
                key: "shortCutInstalled",
                value: function (e) {
                    this.sdk.shortCutInstalled(e)
                }
            }, {
                key: "checkShortcut",
                value: function (e) {
                    this.sdk.checkShortcut(e)
                }
            }, {
                key: "createNative",
                value: function (e) {
                    return this.sdk.createNative(e)
                }
            }, {
                key: "showToast",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1500;
                    this.sdk.showToast(e, t)
                }
            }, {
                key: "loadSubpackage",
                value: function (e, t, n, i, a) {
                    this.sdk instanceof pt ? this.loadSubpkg(e, t, a).then(function () {
                        i && i()
                    }) : this.sdk.loadSubpackage(e, t, n, a, i)
                }
            }, {
                key: "loadSubpkg",
                value: function (e, t, n) {
                    return this.sdk instanceof pt ? this.sdk.loadSubpkg(e, t, n) : Promise.resolve()
                }
            }, {
                key: "loadSubpkgs",
                value: function (e, t, n) {
                    var i = this;
                    return new Promise(function (a, o) {
                        e.length > 0 ? function () {
                            var s, r = e.length;
                            if (n) {
                                var l = {},
                                    u = !0,
                                    h = !1,
                                    c = void 0;
                                try {
                                    for (var d, f = e[Symbol.iterator](); !(u = (d = f.next()).done); u = !0) {
                                        var _ = d.value;
                                        l[_] = 0
                                    }
                                } catch (e) {
                                    h = !0, c = e
                                } finally {
                                    try {
                                        u || null == f.return || f.return()
                                    } finally {
                                        if (h) throw c
                                    }
                                }(s = function (e, t) {
                                    if (l[t] = e, r > 0) {
                                        var i = 0,
                                            a = 0;
                                        for (var o in l) i++, a += +l[o];
                                        n(a / i)
                                    } else n(1)
                                }).bind(i)
                            }
                            for (var y = 0; y < e.length; ++y) i.loadSubpkg(e[y], t ? t[y] : "", s).then(function () {
                                --r <= 0 && (n && n(1), a())
                            }).catch(function () {
                                o()
                            })
                        }() : a()
                    })
                }
            }, {
                key: "isShowTime",
                value: function () {
                    var e = this.serverTime,
                        t = this.getPlatData("IntervalAdTime");
                    return null != t && e / 1e3 - this.getPlayTime() > t
                }
            }, {
                key: "isOpenBanner",
                value: function () {
                    return !!this.isShowTime()
                }
            }, {
                key: "showADInsert",
                value: function () {
                    this.sdk.showADInsert()
                }
            }, {
                key: "shareMsg",
                value: function (e, t, n, i) {
                    this.sdk.shareMsg(e, t, n, i)
                }
            },  {
                key: "isShortScreen",
                value: function () {
                    return !(this.sdk instanceof pt) || this.sdk.isShortScreen()
                }
            },  {
                key: "onBackToGame",
                value: function (e) {
                    e == yt.PLAT_JUMP_GAME && this.hideSDKFlow()
                }
            }, {
                key: "initAd",
                value: function () {
                    this.sdk instanceof pt && this.sdk.initAd()
                }
            }, {
                key: "startBannerMove",
                value: function (e, t) {
                    var n = this;
                    return new Promise(function (i, a) {
                        if (Laya.stage.mouseEnabled = fgui.GRoot.inst.touchable = !1, !n.showAlertAdLimit()) return e.run(), Laya.stage.mouseEnabled = fgui.GRoot.inst.touchable = !0, void i();
                        var o = !1,
                            s = n.serverTime;
                        s / 1e3 - n.getPlayTime() >= n.getPlatData("BannerMoveLimit", 300) ? (n.isAdUser() && (n._firstBannerMove ? o = !0 : s - n._lastBannerMoveTime >= 1e3 * n.getPlatData("BannerMoveInterval", 30) && Math.floor(100 * Math.random() + 1) <= n.getPlatData("BannerMove", 0) && (o = !0)), o ? (n._firstBannerMove = !1, n._lastBannerMoveTime = s, t.run(), n._bannerMoveResolve = i, Laya.timer.once(1e3 * n.getPlatData("BannerMoveShow", 0), n, n._bannerMoveStep1, [e])) : (e.run(), n.showBanner(), Laya.stage.mouseEnabled = fgui.GRoot.inst.touchable = !0, i())) : (e.run(), Laya.stage.mouseEnabled = fgui.GRoot.inst.touchable = !0, i())
                    })
                }
            }, {
                key: "_bannerMoveStep1",
                value: function (e) {
                    var t = this;
                    this.showBanner().then(function () {
                        Laya.timer.once(1e3 * t.getPlatData("BannerMoveChange", 0), t, t._bannerMoveStep2, [e])
                    })
                }
            }, {
                key: "_bannerMoveStep2",
                value: function (e) {
                    e.run(), this._bannerMoveResolve && this._bannerMoveResolve(), Laya.stage.mouseEnabled = fgui.GRoot.inst.touchable = !0
                }
            }, {
                key: "stopBannerMove",
                value: function () {
                    Laya.timer.clear(this, this._bannerMoveStep1), Laya.timer.clear(this, this._bannerMoveStep2), this.hideBanner(), Laya.stage.mouseEnabled = fgui.GRoot.inst.touchable = !0
                }
            }, {
                key: "canClick",
                value: function (e, t) {
                    return this.sdk.playerFlag == ft.CHANNEL0 || !!this.isSupportErrorClick(e, t) && (t == dt.NativeAd ? Math.random() <= this.sdk.avdErrorProp() && (this.updateErrorCount(_t.NATIVE), !0) : t == dt.PlayGame ? Math.random() <= this.sdk.playGameErrorProp() && (this.updateErrorCount(_t.VIDEO), !0) : t == dt.WaterFall ? Math.random() <= this.sdk.waterFallErrorProp() : t == dt.EnterGame ? Math.random() <= this.sdk.enterGameVideoProp() && (this.updateErrorCount(_t.VIDEO), !0) : void 0)
                }
            }, {
                key: "updateErrorCount",
                value: function (e) {
                    var t = this.sdk.errorCount(e);
                    this.sdk.updataAvdErrorCount(t + 1, e), console.log("更新最大次数", t + 1)
                }
            }, {
                key: "showNativeUI",
                value: function (e, t, n, i, a, o, s, r) {
                    P.showNativeUI(e, t, n, i, a, o, s, r)
                }
            }, {
                key: "baseChek",
                value: function () {
                    return this.sdk.playerFlag == ft.CHANNEL0 || (this.sdk.playerFlag == ft.NO_AD ? (console.log("标记未无广告用户-屏蔽"), !1) : !this.isOffCitys() && !this.isCurrentVersion)
                }
            }, {
                key: "isSupportErrorClick",
                value: function (e, t) {
                    if (this.sdk.playerFlag == ft.CHANNEL0) return !0;
                    if (!this.baseChek()) return !1;
                    if (t == dt.NativeAd) {
                        if (0 == this.sdk.errorMaxCount(_t.NATIVE)) return console.warn("isSupportErrorClick-误点未配置-屏蔽"), !1;
                        var n = this.sdk.errorCount(_t.NATIVE);
                        if (this.sdk.errorMaxCount(_t.NATIVE) <= n) return console.warn("isSupportErrorClick-误点上限-屏蔽"), !1;
                        if (0 == this.sdk.avdErrorLevel()) return console.warn("isSupportErrorClick-avdErrorLevel误点未配置-屏蔽"), !1;
                        if (0 == this.sdk.avdErrorProp()) return !1;
                        if (e.level < this.sdk.avdErrorLevel()) return console.warn("isSupportErrorClick-误点等级-屏蔽"), !1
                    } else if (t == dt.PlayGame) {
                        if (0 == this.sdk.errorMaxCount(_t.VIDEO)) return console.warn("isSupportErrorClick-误点未配置-屏蔽"), !1;
                        var i = this.sdk.errorCount(_t.VIDEO);
                        if (this.sdk.errorMaxCount(_t.VIDEO) <= i) return console.warn("isSupportErrorClick-误点上限-屏蔽"), !1;
                        if (0 == this.sdk.playGameLevel()) return console.warn("isSupportErrorClick-playGameLevel误点未配置-屏蔽"), !1;
                        if (0 == this.sdk.playGameErrorProp()) return !1;
                        if (e.level < this.sdk.playGameLevel()) return console.warn("isSupportErrorClick-误点等级-屏蔽"), !1
                    } else if (t == dt.WaterFall) {
                        if (0 == this.sdk.errorMaxCount(_t.BANNER)) return console.warn("isSupportErrorClick-误点未配置-屏蔽"), !1;
                        var a = this.sdk.errorCount(_t.BANNER);
                        if (this.sdk.errorMaxCount(_t.BANNER) <= a) return console.warn("isSupportErrorClick-误点上限-屏蔽"), !1;
                        if (0 == this.sdk.waterFallErrorProp()) return !1
                    } else if (t == dt.EnterGame) {
                        if (0 == this.sdk.errorMaxCount(_t.VIDEO)) return console.warn("isSupportErrorClick-误点未配置-屏蔽"), !1;
                        var o = this.sdk.errorCount(_t.VIDEO);
                        if (this.sdk.errorMaxCount(_t.VIDEO) <= o) return console.warn("isSupportErrorClick-误点上限-屏蔽"), !1;
                        if (0 == this.sdk.enterGameVideoProp()) return !1
                    }
                    return !0
                }
            }, {
                key: "openMoreGameView",
                value: function (e) {
                    if (this.isCurrentVersion) return !1;
                    if (!this.data) return !1;
                    var t = this.getPlatData("VideoJumpStartLevel"),
                        n = this.getPlatData("VideoJumpInterval");
                    return null != t && (null != n && (!(e < t) && (e % n == 0 && (P.moreView(null), !0))))
                }
            }, {
                key: "EnterGame",
                value: function (e, t) {
                    var n = this;
                    if (!this.baseChek()) return !1;
                    if (!this.newenter) return t && t(), !1;
                    if (this.newenter = !1, !this.canClick({
                            level: e
                        }, dt.EnterGame)) return t && t(), !1;
                    var i = this.getPlatData("Channel0Rule", 1);
                    if (this.sdk.playerFlag == ft.CHANNEL0) console.log("渠道0用户", "渠道规则", i), 1 == i ? this.showRwdVideo("主动弹出广告").then(function (i) {
                        n.popUpClickGift(e, t)
                    }) : this.popUpClickGift(e, function () {
                        n.showRwdVideo("主动弹出广告").then(function (e) {
                            t && t(e)
                        })
                    });
                    else {
                        if (this.sdk.playerFlag == ft.NOMAL_HAS_AD) return console.warn("EnterAd show"), this.showRwdVideo("主动弹出广告").then(function (e) {
                            t && t(e)
                        }), !0;
                        t && t()
                    }
                }
            }, {
                key: "PlayGameAd",
                value: function (e, t) {
                    if (!this.baseChek()) return t && t(), !1;
                    var n = this.getPlatData("PlayGameAd");
                    return null == n ? (console.warn("PlayGameAd-PlayGameAd-屏蔽"), t && t(), !1) : n <= 0 ? (console.warn("PlayGameAd-limitLevel-屏蔽"), t && t(), !1) : e < n ? (console.warn("PlayGameAd-limitLevel-屏蔽"), t && t(), !1) : this.canClick({
                        level: e
                    }, dt.PlayGame) ? (console.warn("EnterAd show"), this.showRwdVideo("点击开始游戏").then(function (e) {
                        t && t(e)
                    }), !0) : (t && t(), !1)
                }
            }, {
                key: "popUpClickGift",
                value: function (e, t) {
                    if (this.sdk.playerFlag == ft.CHANNEL0) return P.clickgift(t), !0;
                    if (!this.baseChek()) return t && t(), !1;
                    var n = this.sdk.errorCount(_t.BANNER);
                    if (this.sdk.errorMaxCount(_t.BANNER) <= n) return console.warn("isSupportErrorClick-误点上限-屏蔽"), t && t(), !1;
                    var i = this.getPlatData("ClickGift");
                    return null == i ? (console.warn("popUpClickGift-ClickGift-屏蔽"), t && t(), !1) : i <= 0 ? (console.warn("popUpClickGift-limitLevel-屏蔽"), t && t(), !1) : e < i ? (console.warn("popUpClickGift-limitLevel-屏蔽"), t && t(), !1) : (P.clickgift(t), !0)
                }
            }, {
                key: "popUPFullScreen",
                value: function (e, t) {
                    if (console.log("popUPFullScreen"), this.sdk.playerFlag == ft.CHANNEL0) return e.proptype == ct.BigItem ? (console.log("创建大界面"), P.popUpView(ct.BigItem, function () {
                        console.log("大界面关闭创建小界面"), P.popUpView(ct.SmallItem, t, e.level)
                    }, e.level)) : (console.log("创建小界面"), P.popUpView(ct.SmallItem, t, e.level)), !0;
                    if (this.sdk.playerFlag == ft.NO_AD) return console.log("标记未无广告用户-屏蔽"), t && t(), !1;
                    if (this.isOffCitys()) return console.warn("popUPFullScreen-城市屏蔽"), t && t(), !1;
                    if (this.isCurrentVersion) return console.warn("popUPFullScreen-版本屏蔽"), t && t(), !1;
                    var n = this.getPlatData("WaterfallAd");
                    return null == n ? (console.warn("popUPFullScreen-WaterfallAd-屏蔽"), t && t(), !1) : n <= 0 ? (console.warn("popUPFullScreen-limitLevel-屏蔽"), t && t(), !1) : e.level < n ? (console.warn("popUPFullScreen-limitLevel-屏蔽"), t && t(), !1) : (e.proptype == ct.BigItem ? (console.log("创建大界面"), P.popUpView(ct.BigItem, function () {
                        console.log("大界面关闭创建小界面"), P.popUpView(ct.SmallItem, t, e.level)
                    }, e.level)) : (console.log("创建小界面"), P.popUpView(ct.SmallItem, t, e.level)), !0)
                }
            }, {
                key: "addelay",
                value: function () {
                    var e = 0;
                    return this.sdk.data && this.sdk.data.BtnTime && (e = 1e3 * this.sdk.data.BtnTime), this.isCurrentVersion && (e = 0), e
                }
            }, {
                key: "checkEnterFromInvate",
                value: function () {
                    var e = this.getLaunchOption();
                    e && e.query && e.query.shareMessageToFriendScene == St.Invate && this._sendFromInvate()
                }
            },   {
                key: "getAth",
                value: function (e) {
                    var t = this;
                    return new Promise(function (n, i) {
                        t.athObj.get(e) ? n() : t.getSetting().then(function (a) {
                            a.authSetting[e] ? (t.athObj.set(e, !0), n()) : t.authorize(e).then(function () {
                                t.athObj.set(e, !0), n()
                            }).catch(function (n) {
                                t.athObj.set(e, !1), i(n)
                            })
                        }).catch(function (n) {
                            t.athObj.set(e, !1), i(n)
                        })
                    })
                }
            }, {
                key: "getUserInfo",
                value: function (e) {
                    !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
                    e.call(t)
                }
            }, {
                key: "_drawShareCanvas",
                value: function (e) {
                    this.getShareCanvas() && (this._openDataView || (this._openDataView = new Lt, Laya.stage.addChild(this._openDataView)), this._openDataView.zOrder = fgui.GRoot.inst.displayObject.zOrder + 1, this._openDataView.x = e.x, this._openDataView.y = e.y, this._openDataView.width = e.width, this._openDataView.height = e.height, this._openDataView.visible = !0)
                }
            }, {
                key: "postMessage",
                value: function (e, t) {
                    this.sdk instanceof pt && this.sdk.postMessage(e, t)
                }
            }, {
                key: "sendCloseOpenData",
                value: function () {
                    this._openDataView && (this._openDataView.visible = !1), this.postMessage(bt.destroyScene)
                }
            }, {
                key: "hideOpenData",
                value: function () {
                    this._openDataView && (this._openDataView.visible = !1), this.postMessage(bt.hideOpenData)
                }
            }, {
                key: "showOpenData",
                value: function () {
                    this._openDataView && (this._openDataView.visible = !0), this.postMessage(bt.showOpenData)
                }
            }, {
                key: "sendShowInvate",
                value: function (e, t) {
                    this._sendSetSelfOpenid(), this._sendResetOpenDataSize(e), this._sendShowOpenDataUI(bt.invateFriend, {
                        count: t
                    }), this._drawShareCanvas(e), this.setShareFriendQuery(St.Invate)
                }
            }, {
                key: "sendShowRank",
                value: function (e) {
                    this._sendSetSelfOpenid(), this._sendResetOpenDataSize(e), this._sendShowOpenDataUI(bt.rank), this._drawShareCanvas(e)
                }
            }, {
                key: "sendScoreToOpenData",
                value: function (e) {
                    this.setUserCloudStorage(bt.setScore, e + "")
                }
            }, {
                key: "sendClickOpenBtn",
                value: function (e) {
                    var t = this.getRandomShareInfo();
                    t ? this.postMessage(bt.clickBtn, {
                        clickIndex: e,
                        curScene: this._curOpenUI,
                        shareUrl: t.iconPath,
                        shareTitle: t.title
                    }) : this.postMessage(bt.clickBtn, {
                        clickIndex: e,
                        curScene: this._curOpenUI
                    })
                }
            }, {
                key: "getRandomShareInfo",
                value: function () {
                    return this.sdk instanceof pt ? this.sdk.getRandomShareInfo() : null
                }
            }, {
                key: "_sendSetSelfOpenid",
                value: function () {
                    this.postMessage(bt.setSelfOpenId, {
                        openid: this._openid
                    })
                }
            }, {
                key: "_sendResetOpenDataSize",
                value: function (e) {
                    this.postMessage(bt.viewport, {
                        fromEngine: !0,
                        x: e.x,
                        y: e.y,
                        width: e.width,
                        height: e.height
                    })
                }
            }, {
                key: "_sendShowOpenDataUI",
                value: function (e, t) {
                    this._curOpenUI = e, this.postMessage(e, t)
                }
            }, {
                key: "_sendFromInvate",
                value: function () {
                    this.postMessage(bt.fromInvate, {
                        fromInvate: St.Invate
                    })
                }
            }, {
                key: "setShareFriendQuery",
                value: function (e) {
                    this.sdk instanceof pt && this.sdk.setShareFriendQuery(e)
                }
            }, {
                key: "getShareCanvas",
                value: function () {
                    return this.sdk instanceof pt ? this.sdk.getShareCanvas() : null
                }
            }, {
                key: "getLaunchOption",
                value: function () {
                    return this.sdk instanceof pt ? this.sdk.getLaunchOptionsSync() : null
                }
            }, {
                key: "setUserCloudStorage",
                value: function (e, t) {
                    this.sdk instanceof pt && this.sdk.setUserCloudStorage(e, t)
                }
            }, {
                key: "getSessionKey",
                value: function () {
                    var e = this;
                    return this.sdk instanceof pt ? new Promise(function (t, n) {
                        e.sdk.checkSessionKey().then(function () {
                            t(e.sdk.sessionKey)
                        }).catch(function () {
                            e.login().then(function () {
                                e.sdk.checkSessionKey().then(function () {
                                    t(e.sdk.sessionKey)
                                }).catch(function () {
                                    n()
                                })
                            }).catch(function () {
                                n()
                            })
                        })
                    }) : Promise.resolve("")
                }
            }, {
                key: "getSetting",
                value: function () {
                    return this.sdk instanceof pt ? this.sdk.getSetting() : Promise.resolve(null)
                }
            }, {
                key: "authorize",
                value: function (e) {
                    return this.sdk instanceof pt ? this.sdk.authorize(e) : Promise.resolve(!0)
                }
            }, {
                key: "sendHttpByPost",
                value: function (e, t) {
                    var n = this;
                    return new Promise(function (i, a) {
                        var o = new Laya.HttpRequest;
                        o.http.timeout = 1e4, o.once(Laya.Event.COMPLETE, n, function (e) {
                            e && 0 == e.code ? i(e) : a(e)
                        }), o.once(Laya.Event.ERROR, n, function (e) {
                            a(e)
                        }), o.send(e, JSON.stringify(t), "POST", "json", ["Content-type", "application/json"])
                    })
                }
            }, {
                key: "compareVersion",
                value: function (e, t) {
                    var n = e.split("."),
                        i = t.split(".");
                    if (0 == n.length || n.length != i.length) return 0;
                    for (var a = 0; a < n.length; ++a) {
                        if (+n[a] > +i[a]) return 1;
                        if (+n[a] < +i[a]) return -1
                    }
                    return 0
                }
            }, {
                key: "runPromises",
                value: function () {
                    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return new Promise(function (e, n) {
                        for (var i = t.length, a = 0; a < t.length; ++a) t[a].then(function () {
                            --i <= 0 && e()
                        }).catch(function () {
                            n()
                        })
                    })
                }
            }, {
                key: "getPlatData",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                    return this.data && null != this.data[e] ? this.data[e] : t
                }
            }, {
                key: "getLocalCache",
                value: function (e, t) {
                    var n = K.get_cache(e);
                    return null == n ? null != t ? t : null : JSON.parse(n)
                }
            }, {
                key: "setLocalCache",
                value: function (e, t) {
                    K.set_cache(e, JSON.stringify(t))
                }
            }, {
                key: "Nativecache",
                get: function () {
                    return this.sdk.data.Nativecache ? this.sdk.data.Nativecache : 2
                }
            }, {
                key: "_autoVideoArr",
                get: function () {
                    if (!this._atVDArr) {
                        this._atVDArr = [];
                        var e = this.getPlatData("AutoVideoTime", "");
                        if (e)
                            for (var t = e.split(","), n = 0; n < t.length; ++n) t[n] && this._atVDArr.push(+t[n])
                    }
                    return this._atVDArr
                }
            }, {
                key: "token",
                get: function () {
                    return this._token
                }
            }, {
                key: "data",
                get: function () {
                    return this.sdk.data
                }
            }, {
                key: "isCurrentVersion",
                get: function () {
                    return this.sdk.isCurrentVersion()
                }
            }, {
                key: "serverTime",
                get: function () {
                    return Date.now()
                }
            }, {
                key: "isShortCutInstalled",
                get: function () {
                    return this.sdk.isShortCutInstalled
                }
            }, {
                key: "isNewPlayer",
                get: function () {
                    var e = this.getLocalCache("LogickData._isNewPlayer" + X.data.GAMEID, !0);
                    if (e) {
                        var t = this.serverTime;
                        this._createTime || (this._createTime = this.getLocalCache("LogicData._createTime" + X.data.GAMEID, t), this._createTime == t && this.setLocalCache("LogicData._createTime" + X.data.GAMEID, t + "")), t > new Date(new Date(this._createTime).toLocaleDateString()).getTime() + 864e5 - 1 && (e = !1, this.setLocalCache("LogickData._isNewPlayer" + X.data.GAMEID, e + ""))
                    }
                    return e
                }
            }, {
                key: "isFirstPlay",
                get: function () {
                    return null == this._isFirst && (this._isFirst = this.getLocalCache("LogickData._isFirstPlay" + X.data.GAMEID, !0), this.setLocalCache("LogickData._isFirstPlay" + X.data.GAMEID, !1)), this._isFirst
                }
            }]), GameSDK$1
        }();
    mt.type = "", mt.startGameTime = 0, mt.ctorData = null, mt.isDebug = !1, mt.isDecode = !0, mt.hasAgreeXieYi = !1, mt._autoVideoIdx = 0, mt._lastAutoVideoTime = 0, mt._autoVideoPtc = 0, mt._playTimeCount = 0, mt.KeyTodayOnline = "KeyTodayOnline", mt._timeData = {}, mt._token = "", mt._openid = "", mt._showGrid9Int = 500, mt._lastShowTriggerTime = 0, mt._showTriggerInt = 500, mt._navigateCustom = {}, mt.SubTimeKey = "SubTimeKey", mt.SubMsgKey = "SubMsgKey", mt._todayVideoKey = "LocalCache._todayVideoKey", mt._lastVideoKey = "LocalCache._lastVideoKey", mt._showFuncArr = [], mt._hideFuncArr = [], mt._lastBannerMoveTime = 0, mt._firstBannerMove = !0, mt.newenter = !0, mt.athObj = new Map;
    var Ct, kt, St, It = function () {
        function SDKEventMgr() {
            _classCallCheck(this, SDKEventMgr), this._eventMap = [], this.m_events = new Map
        }
        return _createClass(SDKEventMgr, [{
            key: "on",
            value: function (e, t, n) {
                if (t && n) {
                    var i = this.m_events.get(e);
                    i || (i = [], this.m_events.set(e, i)), i.push({
                        callBack: t,
                        caller: n
                    })
                }
            }
        }, {
            key: "emit",
            value: function (e) {
                var t = this.m_events.get(e);
                if (t) {
                    for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                    for (var o = 0; o < t.length; o++) {
                        var s, r = t[o];
                        r && (s = r.callBack).call.apply(s, [r.caller].concat(i))
                    }
                }
            }
        }, {
            key: "off",
            value: function (e, t, n) {
                var i = this.m_events.get(e);
                if (i)
                    for (var a = 0; a < i.length; a++) {
                        var o = i[a];
                        if (o && o.callBack == t && o.caller == n) return void i.splice(a, 1)
                    }
            }
        }, {
            key: "offAll",
            value: function (e) {
                var t = this.m_events.get(e);
                t && (t.length = 0)
            }
        }], [{
            key: "Int",
            get: function () {
                return this._Int || (this._Int = new SDKEventMgr), this._Int
            }
        }]), SDKEventMgr
    }();
    ! function (e) {
        e[e.Left_Grid = 0] = "Left_Grid", e[e.Right_Grid = 1] = "Right_Grid", e[e.Bottom_Roll = 2] = "Bottom_Roll", e[e.Grid9 = 3] = "Grid9"
    }(Ct || (Ct = {})),
    function (e) {
        e[e.Loading = 0] = "Loading", e[e.Click_Start = 1] = "Click_Start", e[e.End_Game = 2] = "End_Game", e[e.Back_Main = 3] = "Back_Main"
    }(kt || (kt = {})),
    function (e) {
        e[e.Invate = 1] = "Invate"
    }(St || (St = {}));
    var bt, Lt = function (e) {
        function WXOpenDataViewer() {
            var e;
            _classCallCheck(this, WXOpenDataViewer), (e = _possibleConstructorReturn(this, _getPrototypeOf(WXOpenDataViewer).call(this))).width = e.height = 200;
            var t = new Laya.Texture;
            return t.bitmap = new Laya.Texture2D, e.texture = t, e
        }
        return _inherits(WXOpenDataViewer, Laya.Sprite), _createClass(WXOpenDataViewer, [{
            key: "onEnable",
            value: function () {
                window.wx && window.sharedCanvas && Laya.timer.frameLoop(1, this, this._onLoop)
            }
        }, {
            key: "onDisable",
            value: function () {
                Laya.timer.clear(this, this._onLoop)
            }
        }, {
            key: "_onLoop",
            value: function () {
                var e = window.sharedCanvas;
                this.texture.sourceWidth = e.width, this.texture.sourceHeight = e.height, this.texture.bitmap.loadImageSource(e, !0)
            }
        }, {
            key: "width",
            set: function (e) {
                _set(_getPrototypeOf(WXOpenDataViewer.prototype), "width", e, this, !0), window.sharedCanvas && (window.sharedCanvas.width = e)
            },
            get: function () {
                return _get(_getPrototypeOf(WXOpenDataViewer.prototype), "width", this)
            }
        }, {
            key: "height",
            set: function (e) {
                _set(_getPrototypeOf(WXOpenDataViewer.prototype), "height", e, this, !0), window.sharedCanvas && (window.sharedCanvas.height = e)
            },
            get: function () {
                return _get(_getPrototypeOf(WXOpenDataViewer.prototype), "height", this)
            }
        }, {
            key: "x",
            set: function (e) {
                _set(_getPrototypeOf(WXOpenDataViewer.prototype), "x", e, this, !0)
            },
            get: function () {
                return _get(_getPrototypeOf(WXOpenDataViewer.prototype), "x", this)
            }
        }, {
            key: "y",
            set: function (e) {
                _set(_getPrototypeOf(WXOpenDataViewer.prototype), "y", e, this, !0)
            },
            get: function () {
                return _get(_getPrototypeOf(WXOpenDataViewer.prototype), "y", this)
            }
        }]), WXOpenDataViewer
    }();
    ! function (e) {
        e.setSelfOpenId = "setSelfOpenId", e.viewport = "viewport", e.destroyScene = "DestroyScene", e.invateFriend = "invateFriend", e.setScore = "setScore", e.rank = "rank", e.fromInvate = "fromInvate", e.clickBtn = "clickBtn", e.hideOpenData = "hideOpenData", e.showOpenData = "showOpenData"
    }(bt || (bt = {}));
    var Pt = function () {
        function FsmStatenNameMap() {
            _classCallCheck(this, FsmStatenNameMap)
        }
        return _createClass(FsmStatenNameMap, null, [{
            key: "RegisterState",
            value: function (e, t) {
                var n = this.stateNames.indexOf(e);
                n > -1 && this.stateTypes[n] !== t && console.error(e, " 注册重复", t), this.stateNames.push(e), this.stateTypes.push(t)
            }
        }, {
            key: "IsStateInstance",
            value: function (e, t) {
                return this.stateNames.indexOf[e.name] == this.stateTypes.indexOf(t)
            }
        }, {
            key: "GetStateNameByType",
            value: function (e) {
                return this.stateNames[this.stateTypes.indexOf(e)]
            }
        }]), FsmStatenNameMap
    }();
    Pt.stateNames = [], Pt.stateTypes = [];
    var Tt = function () {
            function Fsm() {
                _classCallCheck(this, Fsm), this.currentStateTime = 0, this.states = {}, this.data = {}
            }
            return _createClass(Fsm, [{
                key: "Start",
                value: function (e) {
                    var t = this.GetState(e);
                    if (null == t) throw console.log(e), new Error("".concat(Pt.GetStateNameByType(e), " is not in Fsm{").concat(this.name, "}"));
                    this.currentState = t, this.currentStateTime = 0, t.OnEnter(this), this.debug && console.log("fsm<".concat(this.name, "> start %c").concat(this.name), "color: green;")
                }
            }, {
                key: "HasState",
                value: function (e) {
                    var t = Pt.GetStateNameByType(e);
                    return null != t && null != this.states[t]
                }
            }, {
                key: "GetState",
                value: function (e) {
                    var t = Pt.GetStateNameByType(e);
                    return null == t ? null : this.states[t]
                }
            }, {
                key: "ChangeState",
                value: function (e) {
                    var t = this.GetState(e);
                    if (null == t) throw new Error("".concat(t.constructor.name, " is not in Fsm{").concat(this.name, "}"));
                    null != this.currentState && (this.currentState.actived = !1, this.currentState.OnLeave()), this.currentStateTime = 0, this.currentState = t, t.actived = !0;
                    for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                    t.OnEnter.apply(t, i), this.debug && console.log("fsm<".concat(this.name, "> enter %c").concat(this.currentState.name), "color: green;")
                }
            }, {
                key: "ExiteCurrentState",
                value: function () {
                    null != this.currentState && this.currentState.OnLeave()
                }
            }, {
                key: "GetAllStates",
                value: function () {
                    var e = this,
                        t = [];
                    return Object.keys(this.states).forEach(function (n) {
                        t.push(e.states[n])
                    }), t
                }
            }, {
                key: "OnUpdate",
                value: function (e) {
                    null != this.currentState && (this.currentStateTime += e, this.currentState.OnUpdate(e))
                }
            }, {
                key: "HasData",
                value: function (e) {
                    return null != this.data[e]
                }
            }, {
                key: "GetData",
                value: function (e) {
                    return this.data[e]
                }
            }, {
                key: "SetData",
                value: function (e, t) {
                    this.data[e] = t
                }
            }, {
                key: "RemoveData",
                value: function (e) {
                    delete this.data[e]
                }
            }, {
                key: "Name",
                get: function () {
                    return this.name
                }
            }, {
                key: "Owner",
                get: function () {
                    return this.owner
                }
            }, {
                key: "CurrentState",
                get: function () {
                    return this.currentState
                }
            }, {
                key: "CurrentStateName",
                get: function () {
                    return this.currentState.constructor.name
                }
            }, {
                key: "CurrentStateTime",
                get: function () {
                    return this.currentStateTime
                }
            }], [{
                key: "Create",
                value: function (e, t, n, i) {
                    var a = new Fsm;
                    return a.name = e, a.owner = t, a.debug = i, n.forEach(function (e) {
                        var t = e.name;
                        a.states[t] = e, e._OnInit(a)
                    }), a
                }
            }]), Fsm
        }(),
        At = function (e) {
            function FsmManager() {
                var e;
                return _classCallCheck(this, FsmManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(FsmManager).apply(this, arguments))).fsms = {}, e
            }
            return _inherits(FsmManager, O), _createClass(FsmManager, [{
                key: "Update",
                value: function (e) {
                    for (var t = Object.keys(this.fsms), n = 0; n < t.length; n++) this.fsms[t[n]].OnUpdate(e)
                }
            }, {
                key: "CreateFsm",
                value: function (e, t, n, i) {
                    var a = t.constructor.name + "_" + e;
                    if (null != this.fsms[a]) throw new Error("Already exist FSM:".concat(a));
                    var o = Tt.Create(e, t, n);
                    return o.debug = i, this.fsms[a] = o, o
                }
            }]), FsmManager
        }(),
        wt = function IFsmState() {
            _classCallCheck(this, IFsmState)
        },
        Ut = function (e) {
            function FsmState() {
                var e;
                return _classCallCheck(this, FsmState), (e = _possibleConstructorReturn(this, _getPrototypeOf(FsmState).call(this))).actived = !1, e
            }
            return _inherits(FsmState, wt), _createClass(FsmState, [{
                key: "_OnInit",
                value: function (e) {
                    this.fsm = e, this.OnInit()
                }
            }, {
                key: "ChangeState",
                value: function (e) {
                    for (var t, n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                    (t = this.fsm).ChangeState.apply(t, [e].concat(i))
                }
            }, {
                key: "Owner",
                get: function () {
                    return this.fsm.Owner
                }
            }]), FsmState
        }();

    function add_state_map() {
        return function (e) {
            var t = function (n) {
                function T() {
                    var e, n;
                    _classCallCheck(this, T);
                    for (var i = arguments.length, a = new Array(i), o = 0; o < i; o++) a[o] = arguments[o];
                    return n = _possibleConstructorReturn(this, (e = _getPrototypeOf(T)).call.apply(e, [this].concat(a))), Pt.RegisterState(n.name, t), n
                }
                return _inherits(T, e), T
            }();
            return t
        }
    }
    var Dt = function (e) {
        function DebugDataState() {
            var e;
            return _classCallCheck(this, DebugDataState), (e = _possibleConstructorReturn(this, _getPrototypeOf(DebugDataState).apply(this, arguments))).name = "DebugDataState", e
        }
        return _inherits(DebugDataState, Ut), _createClass(DebugDataState, [{
            key: "OnInit",
            value: function () {}
        }, {
            key: "OnEnter",
            value: function () {
                for (var e = [], t = [], n = 1; n <= 31; n++)
                    if (3 != n && 12 != n && 6 != n) {
                        var i = n < 10 ? "0" + n : "" + n;
                        e.push("unity/level/Conventional/Assets/Images/Pixels/xiangshu_".concat(i, "_gray.png")), t.push("unity/level/Conventional/Assets/Images/Pixels/xiangshu_".concat(i, ".png"))
                    } Laya.loader.load(e.concat(t), Laya.Handler.create(this, this.onTextLoad, [e, t]))
            }
        }, {
            key: "onTextLoad",
            value: function (e, t) {
                for (var n = 0; n < e.length; n++) {
                    for (var i = e[n], a = new Laya.Texture(Laya.loader.getRes(i)), o = a.getPixels(0, 0, a.width, a.height), s = e[n], r = new Laya.Texture(Laya.loader.getRes(s)), l = r.getPixels(0, 0, r.width, r.height), u = [], h = [], c = 0; c < a.height; c++)
                        for (var d = 0; d < a.width; d++) {
                            var f = 4 * (c * a.width + d),
                                _ = o[f];
                            if (!(o[f + 3] < 100)) {
                                var y = "".concat(l[f], "_").concat(l[f + 1], "_").concat(l[f + 2]);
                                h.includes(y) || h.push(y), u.includes(_) || u.push(_)
                            }
                        }
                    console.log(i, "灰度梯度:", u.length, "颜色数:", h.length)
                }
            }
        }, {
            key: "OnUpdate",
            value: function (e) {}
        }, {
            key: "OnLeave",
            value: function () {}
        }, {
            key: "OnDestroy",
            value: function () {}
        }]), DebugDataState
    }();

    function auto_bind_node() {
        return function (e) {
            return function (t) {
                function _class3() {
                    var e;
                    if (_classCallCheck(this, _class3), null == (e = _possibleConstructorReturn(this, _getPrototypeOf(_class3).call(this))).bindNodes) return _possibleConstructorReturn(e);
                    var t = e.onAwake;
                    return e.onAwake = function () {
                        e.bindNodes.forEach(function (t, n) {
                            e[n] = e.Find(t), null == e[n] && console.warn("".concat(e.sp.name, " 没有找到节点").concat(t))
                        }), t && t.call(_assertThisInitialized(e))
                    }, e
                }
                return _inherits(_class3, e), _class3
            }()
        }
    }

    function bind_node(e) {
        return function (t, n) {
            t.bindNodes = t.bindNodes || new Map, e = e || n, t.bindNodes.set(n, e)
        }
    }
    Dt = __decorate([add_state_map()], Dt);
    var Mt, Et, Rt = function (e) {
            function BaseScript3D() {
                return _classCallCheck(this, BaseScript3D), _possibleConstructorReturn(this, _getPrototypeOf(BaseScript3D).apply(this, arguments))
            }
            return _inherits(BaseScript3D, Laya.Script3D), _createClass(BaseScript3D, [{
                key: "PlayAni",
                value: function (e, t) {
                    if (this.ani) {
                        if (this.currentAni === e) return;
                        this.currentAni = e, null == t ? this.ani.play(e) : this.ani.crossFade(e, t)
                    }
                }
            }, {
                key: "SwitchParent",
                value: function (e) {
                    var t = this.sp.transform.worldMatrix.clone();
                    e.addChild(this.sp), this.sp.transform.worldMatrix = t
                }
            }, {
                key: "Find",
                value: function (e) {
                    return M.GetNode(this.sp, e)
                }
            }, {
                key: "FindStrict",
                value: function (e) {
                    for (var t = e.split("/"), n = this.sp, i = 0; i < t.length; i++) {
                        var a = t[i];
                        if (null == (n = n.getChildByName(a))) return null
                    }
                    return n
                }
            }, {
                key: "UpdatePosition",
                value: function () {
                    null == this.sp || this.sp.destroyed || (this.sp.transform.position = this.sp.transform.position)
                }
            }, {
                key: "UpdateRotation",
                value: function () {
                    this.sp.transform.rotation = this.sp.transform.rotation
                }
            }, {
                key: "ClearAsycFunc",
                value: function () {
                    N.getInst().offAllCaller(this), Laya.Tween.clearAll(this), Laya.Tween.clearAll(this.transform), Laya.timer.clearAll(this), this.transform && Laya.Tween.clearAll(this.transform.position)
                }
            }, {
                key: "sp",
                get: function () {
                    return this.owner
                }
            }, {
                key: "transform",
                get: function () {
                    return this.sp.transform
                }
            }, {
                key: "ani",
                get: function () {
                    if (null == this._ani && (this._ani = this.sp.getComponent(Laya.Animator), null == this._ani)) {
                        var e = this.Find("Animator");
                        null != e && (this._ani = e.getComponent(Laya.Animator))
                    }
                    return this._ani
                }
            }, {
                key: "Invalid",
                get: function () {
                    return null == this.sp || this.sp.destroyed
                }
            }]), BaseScript3D
        }(),
        xt = function (e) {
            function ScaleYoYo() {
                var e;
                return _classCallCheck(this, ScaleYoYo), (e = _possibleConstructorReturn(this, _getPrototypeOf(ScaleYoYo).apply(this, arguments))).fromScale = new Laya.Vector3(1, 1, 1), e.fn_toTime = 1e3, e.toScale = new Laya.Vector3(1.15, 1.15, 1.15), e.fn_backTime = 1e3, e
            }
            return _inherits(ScaleYoYo, Rt), _createClass(ScaleYoYo, [{
                key: "onEnable",
                value: function () {
                    this.transform.localScale.cloneTo(this.fromScale), Laya.Vector3.scale(this.fromScale, 1.1, this.toScale), this.ToTween()
                }
            }, {
                key: "onDisable",
                value: function () {
                    Laya.Tween.clearAll(this.transform)
                }
            }, {
                key: "ToTween",
                value: function () {
                    this.transform.localScale = this.fromScale, Laya.Tween.to(this.transform, {
                        localScaleX: this.toScale.x,
                        localScaleY: this.toScale.y,
                        localScaleZ: this.toScale.z
                    }, this.fn_toTime, Laya.Ease.linearIn, Laya.Handler.create(this, this._onToTweenEnd))
                }
            }, {
                key: "_onToTweenEnd",
                value: function () {
                    this.BackTween()
                }
            }, {
                key: "BackTween",
                value: function () {
                    Laya.Tween.to(this.transform, {
                        localScaleX: this.fromScale.x,
                        localScaleY: this.fromScale.y,
                        localScaleZ: this.fromScale.z
                    }, this.fn_backTime, Laya.Ease.linearIn, Laya.Handler.create(this, this._onBackTween))
                }
            }, {
                key: "_onBackTween",
                value: function () {
                    this.ToTween()
                }
            }, {
                key: "_parse",
                value: function (e) {
                    this.fn_toTime = Number(e.fn_toTime), this.fn_backTime = Number(e.fn_backTime)
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.fn_toTime = this.fn_toTime, e.fn_backTime = this.fn_backTime
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("ScaleYoYo", ScaleYoYo)
                }
            }]), ScaleYoYo
        }(),
        Ot = function _AllPrefabsNames() {
            _classCallCheck(this, _AllPrefabsNames)
        };
    Ot.CameraNode = "CameraNode", Ot.UpgradeTable = "UpgradeTable", Ot.HRTable = "HRTable", Ot.BoxMaker = "BoxMaker", Ot.PakerPos = "PakerPos", Ot.PizzaMaker = "PizzaMaker", Ot.PizzaPos = "PizzaPos", Ot.QuadTable = "QuadTable", Ot.QuadTablePos = "QuadTablePos", Ot.SideMenuCounter = "SideMenuCounter", Ot.SidePos = "SidePos", Ot.SingleTable = "SingleTable", Ot.SingleTableBig = "SingleTableBig", Ot.SingleTablePos = "SingleTablePos", Ot.TileLocked = "TileLocked", Ot.TileLevel4 = "TileLevel4", Ot.TileLevel3 = "TileLevel3", Ot.TileLevel2 = "TileLevel2", Ot.TileLevel1 = "TileLevel1", Ot.yun = "yun", Ot.box = "box", Ot.Clock = "Clock", Ot.DirectionalLight = "DirectionalLight", Ot.Fence = "Fence", Ot.FireBrake = "FireBrake", Ot.flowerpot = "flowerpot", Ot.GuestStation = "GuestStation", Ot.HR = "HR", Ot.Menu = "Menu", Ot.rail = "rail", Ot.UnlockTips = "UnlockTips", Ot.Upgrade = "Upgrade", Ot.Wall_DoorLevel1 = "Wall_DoorLevel1", Ot.Wall_DoorLevel2 = "Wall_DoorLevel2", Ot.Wall_DoorLevel3 = "Wall_DoorLevel3", Ot.Wall_DoorLevel4 = "Wall_DoorLevel4", Ot.Wall_FlatLevel1 = "Wall_FlatLevel1", Ot.Wall_FlatLevel2 = "Wall_FlatLevel2", Ot.Wall_FlatLevel3 = "Wall_FlatLevel3", Ot.Wall_FlatLevel4 = "Wall_FlatLevel4", Ot.MoneyAD = "MoneyAD", Ot.MoneyUnlockTag = "MoneyUnlockTag", Ot.AdUnlockTag = "AdUnlockTag", Ot.ArrowHeart = "ArrowHeart", Ot.pinghengche = "pinghengche", Ot.Pizza = "Pizza", Ot.Money = "Money", Ot.PizzaBox = "PizzaBox", Ot.UpgradeAD = "UpgradeAD", Ot.Customer = "Customer", Ot.laobanliang = "laobanliang", Ot.rider = "rider", Ot.Player = "Player", Ot.Supporter = "Supporter", Ot.Feiji = "Feiji", Ot.Wurenji = "Wurenji",
        function (e) {
            e[e["新玩家1"] = 0] = "新玩家1", e[e["去捡钱2"] = 1] = "去捡钱2", e[e["解锁披萨机3"] = 2] = "解锁披萨机3", e[e["解锁单人桌4"] = 3] = "解锁单人桌4", e[e["拿披萨5"] = 4] = "拿披萨5", e[e["放披萨6"] = 5] = "放披萨6", e[e["捡钱7"] = 6] = "捡钱7", e[e["等待HR解锁8"] = 7] = "等待HR解锁8", e[e["HR提示9"] = 8] = "HR提示9", e[e["等待外卖解锁10"] = 9] = "等待外卖解锁10", e[e["外卖提示11"] = 10] = "外卖提示11", e[e["完成新手"] = 11] = "完成新手"
        }(Mt || (Mt = {})),
        function (e) {
            e.CoinUpdate = "Pix.CoinUpdate", e.WoodUpdate = "Pix.WoodUpdate", e.MoneyAni = "MoneyAni", e.UnlockCampRoom = "UnlockCampRoom", e.RebuildNavMesh = "RebuildNavMesh", e.ReFindPath = "ReFindPath", e.SwitchDuLun = "SwitchDuLun", e.SwitchFoot = "SwitchFoot", e.UnlcokCampWorker = "UnlcokCampWorker", e.GuideStepChange = "GuideStepChange", e.StartSwitchDayNight = "StartSwitchDayNight", e.PrepareSwitchDayNight = "PrepareSwitchDayNight", e.SwitchDayNightInScene = "SwitchDayNight", e.PizzaAttouchBigGuy = "PizzaAttouchBigGuy", e.UpdateSupport = "UpdateSupport", e.UnlockChange = "UnlockChange", e.StartCrazyMode = "StartCrazyMode", e.UpdateAirplanePos = "UpdateAirplanePos", e.ShowCircleAD = "ShowCircleAD", e.UpdateCircleAD = "UpdateCircleAD", e.HideCircleAD = "HideCircleAD", e.HideCircleADUI = "HideCircleADUI", e.UpgradeSkillNotice = "UpgradeSkillNotice", e.ShowUnlockTips = "ShowUnlockTips", e.CloseUnlockUI = "CloseUnlockUI"
        }(Et || (Et = {}));
    var Nt = function (e) {
        function PizzaGameConfig() {
            var e;
            return _classCallCheck(this, PizzaGameConfig), (e = _possibleConstructorReturn(this, _getPrototypeOf(PizzaGameConfig).call(this))).shopPrice = [0, 1e4, 3e4, 5e4], e.levels = ["level1", "level2", "level3", "level4"], e.boxMakerMaxSize = 30, e.playerSpeed = [PS(1500, 6), PS(4e3, 7), PS(7500, 8), PS(12e3, 9), PS(0, 10)], e.playerStackCapacity = [PC(1e3, 10), PC(2500, 15), PC(5e3, 20), PC(7500, 25), PC(0, 30)], e.playerPrice = [RP(500, 5), RP(1500, 7), RP(3e3, 9), RP(6e3, 11), RP(0, 13)], e.workerSpeed = [PS(1e3, 6), PS(3500, 7), PS(7e3, 8), PS(1e4, 9), PS(0, 10)], e.workerStackCapacity = [PC(2e3, 5), PC(4e3, 8), PC(6e3, 11), PC(8e3, 14), PC(0, 17)],
				e.workertCount = [SC(2e3, 1), SC(3e3, 2), SC(5e3, 3), SC(7e3, 4), SC(0, 5), SC(0, 6), SC(0, 7)], 
				e.pizzaMakers = [
                [PM(1, 100), PM(5, 200), PM(6, -1), PM(8, 1500)],
                [PM(1, 500), PM(5, 1e3), PM(6, -1), PM(8, 3e3)],
                [PM(1, 1e3), PM(5, 2e3), PM(6, -1), PM(8, 7e3)],
                [PM(1, 2e3), PM(5, 4e3), PM(6, -1), PM(8, 1e4)]
            ], e.singleTables = [
                [PM(2, 100), PM(3, 100), PM(9, 2e3), PM(9, -1), PM(9, 2500), PM(10, 4500), PM(10, 5500), PM(10, 6500)],
                [PM(2, 500), PM(3, 500), PM(9, 4e3), PM(9, -1), PM(9, 5e3), PM(10, 5e3), PM(10, 6e3), PM(10, 7e3)],
                [PM(2, 1e3), PM(3, 1e3), PM(9, 12e3), PM(9, -1), PM(9, 1e4), PM(10, 15e3), PM(10, 18e3), PM(10, 21e3)],
                [PM(2, 2e3), PM(3, 2e3), PM(9, 2e4), PM(9, -1), PM(9, 12e3), PM(10, 2e4), PM(10, 25e3), PM(10, 3e4)]
            ], e.bigTable = [PM(7, 1e3), PM(7, 2e3), PM(7, 7500), PM(7, 8e3)], e.quadTables = [
                [PM(8, 3e3), PM(8, 3e3)],
                [PM(8, 6e3), PM(8, 6e3)],
                [PM(8, 13e3), PM(8, 13e3)],
                [PM(8, 3e4), PM(8, 3e4)]
            ], e.hrRoom = [PM(4, 500), PM(4, 1500), PM(4, 5e3), PM(4, 7500)], e.upgradeRoom = [PM(7, 500), PM(7, 1500), PM(7, 5e3), PM(7, 7500)], e.packer = [
                [PM(6, 1e3), PM(9, 3500)],
                [PM(6, 2e3), PM(9, 7e3)],
                [PM(6, 5e3), PM(9, 13500)],
                [PM(6, 1e4), PM(9, 35e3)]
            ], e
        }
        return _inherits(PizzaGameConfig, O), _createClass(PizzaGameConfig, [{
            key: "GetSceneName",
            value: function (e) {
                return this.levels[e]
            }
        }]), PizzaGameConfig
    }();

    function PS(e, t) {
        return {
            unlockCoin: e,
            speed: t
        }
    }

    function PC(e, t) {
        return {
            unlockCoin: e,
            capacity: t
        }
    }

    function SC(e, t) {
        return {
            unlockCoin: e,
            count: t
        }
    }

    function RP(e, t) {
        return {
            unlockCoin: e,
            price: t
        }
    }

    function PM(e, t) {
        return {
            unlockCoin: t,
            unlockLevel: e
        }
    }
    var Bt = function () {
        function DataManager() {
            _classCallCheck(this, DataManager), this.dataMap = {}, this.recordTime = !1, Laya.timer.frameLoop(5, this, this.Save)
        }
        return _createClass(DataManager, [{
            key: "GetDataRecorder",
            value: function (e, t) {
                var n = e;
                if (null != this.dataMap[n]) return this.dataMap[n];
                var i, a = null;
                if (this.storageGet) a = this.storageGet(n);
                else {
                    var o = R.getItem(n);
                    null == o || "" == o ? a = {} : (a = o, "string" == typeof o && (a = JSON.parse(o)))
                }
                return i = null != t ? new t(n, a) : new DataManager.storageName2ctorMap[n](n, a), this.dataMap[n] = i.proxy, i.proxy
            }
        }, {
            key: "Clear",
            value: function (e) {
                delete this.dataMap[e], R.removeItem(e)
            }
        }, {
            key: "Save",
            value: function () {
                for (var e = Object.keys(this.dataMap), t = 0; t < e.length; t++) {
                    var n = e[t],
                        i = this.dataMap[n];
                    i.dirty && (this.storageSet ? this.storageSet(i.storageName, i) : R.setItem(i.storageName, i, !0), i.ClearDirty())
                }
            }
        }, {
            key: "setTime",
            value: function () {
                R.setItem("record_time", M.CurrentTime)
            }
        }, {
            key: "GetLastTime",
            get: function () {
                0 == this.recordTime && (this.recordTime = !0, Laya.timer.loop(1e3, this, this.setTime));
                var e = R.getItem("record_time");
                return null == e || "" == e ? -1 : Number(e)
            }
        }], [{
            key: "RegisterCtor",
            value: function (e, t) {
                this.storageName2ctorMap[e] = t, this.ctorName2storageNameMap[t.name] = e
            }
        }, {
            key: "inst",
            get: function () {
                return null == DataManager._inst && (DataManager._inst = new DataManager), DataManager._inst
            }
        }]), DataManager
    }();
    Bt.storageName2ctorMap = {}, Bt.ctorName2storageNameMap = {};
    var Gt = function () {
            function DataProxy(e, t) {
                var n = this;
                _classCallCheck(this, DataProxy), this.storageName = e, this._data = t, this._proxy = new Proxy(this, {
                    set: function (i, a, o) {
                        switch (a) {
                            case "_dirty":
                            case "_proxy":
                            case "_data":
                                return i[a] = o, !0
                        }
                        if (i._data[a] != o) {
                            if (null == i._data[a] && o instanceof Object) {
                                var s = new Vt(a, o);
                                i._data[a] = s.proxy, s.__dirtyInvoker = n.dirtyInvoker.bind(n), n._dirty = !0;
                                try {
                                    n.dirtyInvoker(a)
                                } catch (n) {
                                    console.error(n), console.error(e, t)
                                }
                                return !0
                            }
                            i._data[a] = o, null == i._data[a] && delete i._data[a], n._dirty = !0, n.dirtyInvoker(a)
                        }
                        return !0
                    },
                    get: function (e, t) {
                        if (null != e[t]) return e[t];
                        if (null != e._data[t]) return e._data[t];
                        if (null != e._data.prototype) {
                            var i = e._data.prototype.p;
                            if (i instanceof Object) {
                                var a = new Vt(t, i);
                                e._data[t] = a.proxy, a.__dirtyInvoker = n.dirtyInvoker.bind(n)
                            }
                            return e._data[t]
                        }
                        return "string" == typeof t && null != e["_dft_" + t] ? e["_dft_" + t] : null
                    },
                    ownKeys: function (e) {
                        for (var t = Object.keys(e._data), n = 0; n < t.length; n++) e[t[n]] = null;
                        return t
                    },
                    has: function (e, t) {
                        return t in e._data
                    }
                });
                for (var i = Object.keys(this._data), a = 0; a < i.length; a++) {
                    var o = this._data[i[a]];
                    if (o instanceof Object) {
                        var s = new Vt(i[a], o);
                        s.__dirtyInvoker = this.dirtyInvoker.bind(this), this._data[i[a]] = s.proxy
                    }
                }
            }
            return _createClass(DataProxy, [{
                key: "ClearDirty",
                value: function () {
                    this._dirty = !1
                }
            }, {
                key: "toJSON",
                value: function () {
                    return this._data
                }
            }, {
                key: "dirtyInvoker",
                value: function (e) {
                    this._dirty = !0, this.__dirtyInvoker ? this.__dirtyInvoker(this.storageName + "/" + e) : Bt.ctorName2storageNameMap[this._proxy.constructor.name]
                }
            }, {
                key: "proxy",
                get: function () {
                    return this._proxy
                }
            }, {
                key: "data",
                get: function () {
                    return this._data
                }
            }, {
                key: "dirty",
                get: function () {
                    return null != this._dirty && this._dirty
                }
            }]), DataProxy
        }(),
        Vt = function (e) {
            function BaseData() {
                return _classCallCheck(this, BaseData), _possibleConstructorReturn(this, _getPrototypeOf(BaseData).apply(this, arguments))
            }
            return _inherits(BaseData, Gt), BaseData
        }();

    function data_default(e) {
        return function (t, n) {
            t["_dft_" + n] = e
        }
    }
    var zt = function (e) {
        function GameBaseDataRecorder() {
            return _classCallCheck(this, GameBaseDataRecorder), _possibleConstructorReturn(this, _getPrototypeOf(GameBaseDataRecorder).apply(this, arguments))
        }
        return _inherits(GameBaseDataRecorder, Gt), GameBaseDataRecorder
    }();
    __decorate([data_default(200)], zt.prototype, "money", void 0), __decorate([data_default(0)], zt.prototype, "speedLevel", void 0), __decorate([data_default(0)], zt.prototype, "stackLevel", void 0), __decorate([data_default(0)], zt.prototype, "priceLevel", void 0), __decorate([data_default(Mt[Mt.新玩家1])], zt.prototype, "guideStep", void 0), __decorate([data_default(!1)], zt.prototype, "unlockDunlun", void 0), __decorate([data_default(0)], zt.prototype, "shopIndex", void 0), __decorate([data_default(0)], zt.prototype, "moneyTimes", void 0), __decorate([data_default(0)], zt.prototype, "shareCount", void 0), __decorate([data_default(0)], zt.prototype, "shareTime", void 0);
    var Ft = function (e) {
        function BuildingNodeDataRecorder() {
            return _classCallCheck(this, BuildingNodeDataRecorder), _possibleConstructorReturn(this, _getPrototypeOf(BuildingNodeDataRecorder).apply(this, arguments))
        }
        return _inherits(BuildingNodeDataRecorder, Gt), BuildingNodeDataRecorder
    }();
    __decorate([data_default(0)], Ft.prototype, "money", void 0);
    var Ht = function (e) {
            function ShopTimeDataRecorder() {
                return _classCallCheck(this, ShopTimeDataRecorder), _possibleConstructorReturn(this, _getPrototypeOf(ShopTimeDataRecorder).apply(this, arguments))
            }
            return _inherits(ShopTimeDataRecorder, Gt), ShopTimeDataRecorder
        }(),
        jt = function (e) {
            function ShopDataRecorder() {
                return _classCallCheck(this, ShopDataRecorder), _possibleConstructorReturn(this, _getPrototypeOf(ShopDataRecorder).apply(this, arguments))
            }
            return _inherits(ShopDataRecorder, Gt), ShopDataRecorder
        }();
    __decorate([data_default(1)], jt.prototype, "unlockLevel", void 0), __decorate([data_default(0)], jt.prototype, "hr", void 0), __decorate([data_default(0)], jt.prototype, "pu", void 0), __decorate([data_default(0)], jt.prototype, "big", void 0), __decorate([data_default(!0)], jt.prototype, "crazyMode", void 0), __decorate([data_default(-1)], jt.prototype, "countLevel", void 0), __decorate([data_default(0)], jt.prototype, "speedLevel", void 0), __decorate([data_default(0)], jt.prototype, "stackLevel", void 0), __decorate([data_default(!1)], jt.prototype, "wrj", void 0), __decorate([data_default(!1)], jt.prototype, "lbl", void 0), __decorate([data_default(0)], jt.prototype, "t", void 0), __decorate([data_default(!1)], jt.prototype, "adYG", void 0), __decorate([data_default(!1)], jt.prototype, "showYG", void 0), __decorate([data_default(!1)], jt.prototype, "adWRJ", void 0), __decorate([data_default(!1)], jt.prototype, "showWRJ", void 0);
    var Wt = function () {
            function PizzaGameData() {
                _classCallCheck(this, PizzaGameData), this.recorder = Bt.inst.GetDataRecorder("game_pizza_base", zt)
            }
            return _createClass(PizzaGameData, [{
                key: "GetSopTime",
                value: function () {
                    return Bt.inst.GetDataRecorder("game_pizza_shop_t", Ht)
                }
            }, {
                key: "GetShop",
                value: function (e) {
                    return Bt.inst.GetDataRecorder("game_pizza_shop_" + e, jt)
                }
            }, {
                key: "Money",
                get: function () {
                    return this.recorder.money
                },
                set: function (e) {
                    e < 0 && (e = 0), e < this.recorder.money && G.inst.playMoneySpend(), this.recorder.money = e, N.getInst().event(Et.CoinUpdate)
                }
            }, {
                key: "ShareTime",
                get: function () {
                    return this.recorder.shareTime
                },
                set: function (e) {
                    this.recorder.shareTime = e
                }
            }, {
                key: "ShareCount",
                get: function () {
                    return this.recorder.shareCount
                },
                set: function (e) {
                    this.recorder.shareCount = e
                }
            }, {
                key: "ShopUnlockIndex",
                get: function () {
                    return this.recorder.shopIndex
                },
                set: function (e) {
                    this.recorder.shopIndex = e
                }
            }, {
                key: "MoneyTimes",
                get: function () {
                    return this.recorder.moneyTimes
                },
                set: function (e) {
                    this.recorder.moneyTimes = e
                }
            }, {
                key: "SpeedLevel",
                get: function () {
                    return null == this.recorder.speedLevel && (this.recorder.speedLevel = 0), this.recorder.speedLevel
                },
                set: function (e) {
                    e >= Nt.getInst().playerSpeed.length && (e = Nt.getInst().playerSpeed.length - 1), this.recorder.speedLevel = e
                }
            }, {
                key: "IsMaxSpeedLevel",
                get: function () {
                    return this.SpeedLevel === Nt.getInst().playerSpeed.length - 1
                }
            }, {
                key: "MoveSpeed",
                get: function () {
                    return Nt.getInst().playerSpeed[this.SpeedLevel].speed
                }
            }, {
                key: "SpecailMoveSpeed",
                get: function () {
                    return 8
                }
            }, {
                key: "NextSpeedLevelCost",
                get: function () {
                    return Nt.getInst().playerSpeed[this.SpeedLevel].unlockCoin
                }
            }, {
                key: "StackLevel",
                get: function () {
                    return null == this.recorder.stackLevel && (this.recorder.stackLevel = 0), this.recorder.stackLevel
                },
                set: function (e) {
                    e >= Nt.getInst().playerStackCapacity.length && (e = Nt.getInst().playerStackCapacity.length - 1), this.recorder.stackLevel = e
                }
            }, {
                key: "IsMaxStackLevel",
                get: function () {
                    return this.StackLevel === Nt.getInst().playerStackCapacity.length - 1
                }
            }, {
                key: "NextStackLevelCost",
                get: function () {
                    return Nt.getInst().playerStackCapacity[this.StackLevel].unlockCoin
                }
            }, {
                key: "StackSize",
                get: function () {
                    return Nt.getInst().playerStackCapacity[this.StackLevel].capacity
                }
            }, {
                key: "PriceLevel",
                set: function (e) {
                    e >= Nt.getInst().playerPrice.length && (e = Nt.getInst().playerPrice.length - 1), this.recorder.priceLevel = e
                },
                get: function () {
                    return this.recorder.priceLevel
                }
            }, {
                key: "IsMaxPriceLevel",
                get: function () {
                    return this.PriceLevel === Nt.getInst().playerPrice.length - 1
                }
            }, {
                key: "NextPriceLevelCost",
                get: function () {
                    return Nt.getInst().playerPrice[this.PriceLevel].unlockCoin
                }
            }, {
                key: "Price",
                get: function () {
                    return Nt.getInst().playerPrice[this.PriceLevel].price
                }
            }, {
                key: "UnlockDunLun",
                get: function () {
                    return this.recorder.unlockDunlun
                },
                set: function (e) {
                    this.recorder.unlockDunlun = e
                }
            }, {
                key: "CurrentShopPlayTime",
                get: function () {
                    var e = this.GetSopTime();
                    return e.playTime = e.playTime || [], null == e.playTime[Wo.getInst().gameBlackBoard.currentShopIndex] && (e.playTime[Wo.getInst().gameBlackBoard.currentShopIndex] = 0), e.playTime[Wo.getInst().gameBlackBoard.currentShopIndex]
                },
                set: function (e) {
                    var t = this.GetSopTime();
                    t.playTime = t.playTime || [], t.playTime[Wo.getInst().gameBlackBoard.currentShopIndex] = e
                }
            }, {
                key: "CurrentShop",
                get: function () {
                    return this.GetShop(Wo.getInst().gameBlackBoard.currentShopIndex)
                }
            }, {
                key: "ShopCrazyMode",
                get: function () {
                    return this.CurrentShop.crazyMode
                },
                set: function (e) {
                    this.CurrentShop.crazyMode = e
                }
            }, {
                key: "HasADSupport",
                get: function () {
                    return this.CurrentShop.adYG
                },
                set: function (e) {
                    this.CurrentShop.adYG = e
                }
            }, {
                key: "ShowADSupport",
                get: function () {
                    return this.CurrentShop.showYG
                },
                set: function (e) {
                    this.CurrentShop.showYG = e
                }
            }, {
                key: "HasADWRJ",
                get: function () {
                    return this.CurrentShop.adWRJ
                },
                set: function (e) {
                    this.CurrentShop.adWRJ = e
                }
            }, {
                key: "ShowADWRJ",
                get: function () {
                    return this.CurrentShop.showWRJ
                },
                set: function (e) {
                    this.CurrentShop.showWRJ = e
                }
            }, {
                key: "ShopUnlockLevel",
                get: function () {
                    return this.CurrentShop.unlockLevel
                },
                set: function (e) {
                    this.CurrentShop.unlockLevel = e
                }
            }, {
                key: "ShopPizzaMakerProgress",
                get: function () {
                    return this.CurrentShop.pm = this.CurrentShop.pm || [], this.CurrentShop.pm
                }
            }, {
                key: "ShopSingleTableProgress",
                get: function () {
                    return this.CurrentShop.st = this.CurrentShop.st || [], this.CurrentShop.st
                }
            }, {
                key: "ShopQuadTableProgress",
                get: function () {
                    return this.CurrentShop.qt = this.CurrentShop.qt || [], this.CurrentShop.qt
                }
            }, {
                key: "ShopPackerProgress",
                get: function () {
                    return this.CurrentShop.pkr = this.CurrentShop.pkr || [], this.CurrentShop.pkr
                }
            }, {
                key: "ShopHrProgress",
                get: function () {
                    return this.CurrentShop.hr
                },
                set: function (e) {
                    this.CurrentShop.hr = e
                }
            }, {
                key: "ShopUpgradeRoomProgress",
                get: function () {
                    return this.CurrentShop.pu
                },
                set: function (e) {
                    this.CurrentShop.pu = e
                }
            }, {
                key: "ShopBigTableProgress",
                get: function () {
                    return this.CurrentShop.big
                },
                set: function (e) {
                    this.CurrentShop.big = e
                }
            }, {
                key: "ShopSupportCountLevel",
                get: function () {
                    return this.CurrentShop.countLevel
                },
                set: function (e) {
                    e > this.CurrentShop.countLevel && N.getInst().event(Et.UpdateSupport), this.CurrentShop.countLevel = e
                }
            }, {
                key: "ShopSupportIsMaxCountLevel",
                get: function () {
                    return this.ShopSupportCountLevel == Nt.getInst().workertCount.length - 1
                }
            }, {
                key: "ShopSupportNextCountLevelCost",
                get: function () {
                    return -1 == this.ShopSupportCountLevel ? 0 : Nt.getInst().workertCount[this.ShopSupportCountLevel].unlockCoin
                }
            }, {
                key: "ShopSupportCount",
                get: function () {
                    return -1 == this.ShopSupportCountLevel ? 0 : Nt.getInst().workertCount[this.ShopSupportCountLevel].count
                }
            }, {
                key: "ShopSupportSpeedLevel",
                get: function () {
                    return this.CurrentShop.speedLevel
                },
                set: function (e) {
                    this.CurrentShop.speedLevel = e
                }
            }, {
                key: "ShopSupportIsMaxSpeedLevel",
                get: function () {
                    return this.ShopSupportSpeedLevel == Nt.getInst().workerSpeed.length - 1
                }
            }, {
                key: "ShopSupportSpeed",
                get: function () {
                    return Nt.getInst().workerSpeed[this.ShopSupportSpeedLevel].speed
                }
            }, {
                key: "ShopSupportNextSpeedLevelCost",
                get: function () {
                    return Nt.getInst().workerSpeed[this.ShopSupportSpeedLevel].unlockCoin
                }
            }, {
                key: "ShopSupportMaxSpeed",
                get: function () {
                    return Nt.getInst().workerSpeed[Nt.getInst().workerSpeed.length - 1].speed
                }
            }, {
                key: "ShopSupportStackLevel",
                get: function () {
                    return this.CurrentShop.stackLevel
                },
                set: function (e) {
                    this.CurrentShop.stackLevel = e
                }
            }, {
                key: "ShopSupportIsMaxStackLevel",
                get: function () {
                    return this.ShopSupportStackLevel == Nt.getInst().workerStackCapacity.length - 1
                }
            }, {
                key: "ShopSupportNextStackLevelCost",
                get: function () {
                    return Nt.getInst().workerStackCapacity[this.ShopSupportSpeedLevel].unlockCoin
                }
            }, {
                key: "ShopSupprotStackSize",
                get: function () {
                    return Nt.getInst().workerStackCapacity[this.ShopSupportSpeedLevel].capacity
                }
            }, {
                key: "UnlockedGirlSupport",
                get: function () {
                    return this.CurrentShop.lbl
                },
                set: function (e) {
                    this.CurrentShop.lbl = e
                }
            }, {
                key: "UnlockedGirlUAV",
                get: function () {
                    return this.CurrentShop.wrj
                },
                set: function (e) {
                    this.CurrentShop.wrj = e
                }
            }, {
                key: "GuideStep",
                get: function () {
                    return Mt[this.recorder.guideStep]
                },
                set: function (e) {
                    this.recorder.guideStep = Mt[e], N.getInst().event(Et.GuideStepChange), lt.inst.sendReport("新手引导:" + this.recorder.guideStep)
                }
            }], [{
                key: "inst",
                get: function () {
                    return null == PizzaGameData._inst && (PizzaGameData._inst = new PizzaGameData), PizzaGameData._inst
                }
            }]), PizzaGameData
        }(),
        $t = function () {
            function ResLoadManager() {
                _classCallCheck(this, ResLoadManager)
            }
            return _createClass(ResLoadManager, null, [{
                key: "PushUrls",
                value: function (e) {
                    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                    if (e)
                        for (var a = 0; a < n.length; a++) {
                            ResLoadManager.urlsCreate.indexOf(n[a]) >= 0 || ResLoadManager.urlsCreate.push(n[a])
                        } else
                            for (a = 0; a < n.length; a++) {
                                if (null != n[a]) ResLoadManager.urlsLoad.indexOf(n[a]) >= 0 || ResLoadManager.urlsLoad.push(n[a])
                            }
                }
            }, {
                key: "LoadCreateRes",
                value: function (e, t) {
                    console.log("load create urls:", ResLoadManager.urlsCreate), 0 == ResLoadManager.urlsCreate.length ? e(!0) : Laya.loader.create(ResLoadManager.urlsCreate, Laya.Handler.create(null, e), t ? Laya.Handler.create(null, t, null, !1) : null)
                }
            }, {
                key: "LoadZipAsset",
                value: function (e) {
                    var t = this,
                        n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "assets/unity.bin";
                    return new w(function (i, a) {
                        e ? i() : Laya.loader.load([{
                            url: n,
                            type: "plfb"
                        }], Laya.Handler.create(t, i), Laya.Handler.create(null, a, null, !1))
                    })
                }
            }, {
                key: "LoadCreateResP",
                value: function () {
                    return console.log("load create urls:", ResLoadManager.urlsCreate), new w(function (e, t, n) {
                        if (null == ResLoadManager.urlsCreate || 0 == ResLoadManager.urlsCreate.length) return t(1), void e();
                        Laya.loader.create(ResLoadManager.urlsCreate, Laya.Handler.create(null, e), Laya.Handler.create(null, t, null, !1))
                    })
                }
            }, {
                key: "LoadCacheRes",
                value: function (e, t) {
                    if (console.log("load urls:", ResLoadManager.urlsLoad), 0 == ResLoadManager.urlsLoad.length) e(!0);
                    else {
                        var n = [];
                        ResLoadManager.urlsLoad.forEach(function (e) {
                            -1 != e.indexOf(".bin") ? n.push({
                                url: e,
                                type: Laya.Loader.BUFFER
                            }) : -1 == e.indexOf(".png") && -1 == e.indexOf(".jpg") || n.push({
                                url: e,
                                type: Laya.Loader.IMAGE
                            })
                        }), Laya.loader.create(n, Laya.Handler.create(null, e), t ? Laya.Handler.create(null, t, null, !1) : null, null, null, null, 1, !0)
                    }
                }
            }, {
                key: "LoadPrefabRes",
                value: function (e, t, n, i) {
                    0 != e.length ? Laya.loader.create(e, Laya.Handler.create(i, t), n ? Laya.Handler.create(null, n, null, !1) : null) : t(!0)
                }
            }, {
                key: "ClearRes",
                value: function (e) {
                    e.forEach(function (e) {
                        Laya.loader.clearRes(e)
                    })
                }
            }]), ResLoadManager
        }();

    function res_auto_bind() {
        return function (e) {
            return function (t) {
                function T() {
                    var e, t;
                    _classCallCheck(this, T);
                    for (var n = arguments.length, i = new Array(n), a = 0; a < n; a++) i[a] = arguments[a];
                    var o = (t = _possibleConstructorReturn(this, (e = _getPrototypeOf(T)).call.apply(e, [this].concat(i))))._res_prefab_clone;
                    if (o) {
                        for (var s = 0; s < o.length; s++) {
                            var r = o[s];
                            t[r.key] = Laya.Sprite3D.instantiate(Laya.loader.getRes(r.url))
                        }
                        t._res_prefab_clone = null
                    }
                    var l = t._res_assign;
                    if (l) {
                        for (s = 0; s < l.length; s++) {
                            var u = l[s];
                            t[u.key] = Laya.loader.getRes(u.url)
                        }
                        t._res_assign = null
                    }
                    var h = t._res_array_assign;
                    if (h) {
                        for (s = 0; s < h.length; s++)
                            for (var c = h[s], d = t[c.key] = [], f = 0; f < c.urls.length; f++) {
                                var _ = c.urls[f];
                                d.push(Laya.loader.getRes(_))
                            }
                        t._res_array_assign = null
                    }
                    return t._init_ && t._init_(), t
                }
                return _inherits(T, e), T
            }()
        }
    }

    function res_assign(e) {
        return $t.PushUrls(!0, e),
            function (t, n) {
                t._res_assign = t._res_assign || [], t._res_assign.push({
                    key: n,
                    url: e
                })
            }
    }
    $t.urlsCreate = [], $t.urlsLoad = [];
    var Kt, Yt = function (e) {
            function CameraFollow() {
                var e;
                return _classCallCheck(this, CameraFollow), (e = _possibleConstructorReturn(this, _getPrototypeOf(CameraFollow).apply(this, arguments))).ray = new Laya.Ray(new Laya.Vector3, new Laya.Vector3), e.point = new Laya.Vector2(Laya.stage.width / 2, Laya.stage.height / 2), e.deltaR = 3, e.lookTarget = new Laya.Vector3, e.tmp = new Laya.Vector3, e
            }
            return _inherits(CameraFollow, Rt), _createClass(CameraFollow, [{
                key: "onAwake",
                value: function () {
                    CameraFollow.inst = this
                }
            }, {
                key: "onStart",
                value: function () {
                    this.camera = this.Find("Main Camera"), this.camera.clearFlag = Laya.CameraClearFlags.Sky, this.camera.orthographic = !0, this.camera.orthographicVerticalSize = 32.476, this.camera.farPlane = 1e3, pi.getInst().mainCamera = this.camera, this.rotateNode = this.Find("RotateNode")
                }
            }, {
                key: "onUpdate",
                value: function () {
                    this.camera.viewportPointToRay(this.point, this.ray);
                    var e = -this.ray.origin.y / this.ray.direction.y;
                    Laya.Vector3.scale(this.ray.direction, e, this.tmp), Laya.Vector3.add(this.ray.origin, this.tmp, this.tmp), Laya.Browser.onPC && (Laya.KeyBoardManager.hasKeyDown(Laya.Keyboard.A) && (this.transform.localRotationEulerY += 90 * F.deltaTimeSec), Laya.KeyBoardManager.hasKeyDown(Laya.Keyboard.D) && (this.transform.localRotationEulerY -= 90 * F.deltaTimeSec))
                }
            }, {
                key: "onLateUpdate",
                value: function () {
                    var e = this.target || pi.getInst().player;
                    if (null != e && null != e.transform) {
                        var t = Math.min(1, this.target ? F.deltaTimeSec * this.deltaR : .1);
                        this.transform.position.z = Laya.MathUtil.lerp(this.transform.position.z, e.transform.position.z, t), this.transform.position.y = Math.min(4, e.transform.position.y), this.transform.position.x = Laya.MathUtil.lerp(this.transform.position.x, e.transform.position.x, t), this.UpdatePosition()
                    }
                }
            }, {
                key: "onDestroy",
                value: function () {
                    N.getInst().offAllCaller(this), CameraFollow.inst = null
                }
            }, {
                key: "debugView",
                value: function () {
                    Laya.Tween.to(this.rotateNode.transform, {
                        localRotationEulerX: 90
                    }, 200, Laya.Ease.expoOut, null, 0, !0), Laya.Tween.to(this.camera.transform, {
                        localPositionZ: -60
                    }, 200, Laya.Ease.expoOut, null, 0, !0)
                }
            }, {
                key: "SwitchToGamePlayView",
                value: function () {
                    Laya.Tween.to(this.camera.transform, {
                        localPositionZ: -18
                    }, 200, Laya.Ease.linearInOut, null, 0, !0), Laya.Tween.to(this.rotateNode.transform, {
                        localRotationEulerX: 40.53,
                        localPositionX: 0,
                        localPositionZ: 0
                    }, 200, Laya.Ease.linearInOut, null, 0, !0)
                }
            }]), CameraFollow
        }(),
        Xt = function () {
            function MathUtils() {
                _classCallCheck(this, MathUtils)
            }
            return _createClass(MathUtils, null, [{
                key: "SegmentIntersect",
                value: function (e, t, n, i) {
                    if (!(n.length < 3))
                        for (var a = 0; a < n.length; a++) {
                            var o = n[a],
                                s = n[a == n.length - 1 ? 0 : a + 1];
                            if (Math.max(e.x, t.x) > Math.min(o.x, s.x) && Math.max(o.x, s.x) > Math.min(e.x, t.x) && Math.max(e.y, t.y) > Math.min(o.y, s.y) && Math.max(o.y, s.y) > Math.min(e.y, t.y)) {
                                var r = e.x - o.x,
                                    l = e.y - o.y,
                                    u = t.x - o.x,
                                    h = t.y - o.y,
                                    c = s.x - o.x,
                                    d = s.y - o.y;
                                if ((r * d - l * c) * (c * h - d * u) >= 0) return void i.push(o, s)
                            }
                        }
                }
            }, {
                key: "PointInPolygon",
                value: function (e, t, n) {
                    if (t.length < 3) return !0;
                    for (var i = 0, a = 0; a < t.length; a++) {
                        var o = t[a],
                            s = t[a == t.length - 1 ? 0 : a + 1],
                            r = Math.min(o.y, s.y),
                            l = Math.max(o.y, s.y),
                            u = Math.max(o.x, s.x);
                        if (Math.min(o.x, s.x) - 1 <= e.x && u + 1 >= e.x && r - 1 <= e.y && l + 1 >= e.y && n.push(o, s), r <= e.y && l >= e.y && u >= e.x) {
                            var h = e.x - o.x,
                                c = e.y - o.y,
                                d = 1e3 - o.x,
                                f = e.y - o.y,
                                _ = s.x - o.x,
                                y = s.y - o.y;
                            (h * y - c * _) * (_ * f - y * d) >= 0 && i++
                        }
                    }
                    return i % 2 == 1
                }
            }, {
                key: "PointInPolygon2",
                value: function (e, t) {
                    if (t.length < 3) return !0;
                    for (var n = 0, i = 0; i < t.length; i++) {
                        var a = t[i],
                            o = t[i == t.length - 1 ? 0 : i + 1],
                            s = Math.min(a.y, o.y),
                            r = Math.max(a.y, o.y),
                            l = Math.max(a.x, o.x);
                        if (s <= e.y && r >= e.y && l >= e.x) {
                            var u = e.x - a.x,
                                h = e.y - a.y,
                                c = 1e3 - a.x,
                                d = e.y - a.y,
                                f = o.x - a.x,
                                _ = o.y - a.y;
                            (u * _ - h * f) * (f * d - _ * c) >= 0 && n++
                        }
                    }
                    return n % 2 == 1
                }
            }, {
                key: "multiply",
                value: function (e, t, n) {
                    return (t.x - e.x) * (n.y - e.y) - (n.x - e.x) * (t.y - e.y)
                }
            }, {
                key: "ScalePath",
                value: function (e, t) {
                    var n = new Laya.Vector2;
                    e.forEach(function (e) {
                        F.addVec2(e, n, n)
                    }), F.scaleVec2(n, 1 / e.length, n);
                    var i = new Laya.Vector2;
                    e.forEach(function (e) {
                        F.subtractVec2(e, n, i);
                        var a = F.getLengthVec2(i);
                        F.setLengthVec2(i, a + t, i), F.addVec2(i, n, e)
                    })
                }
            }, {
                key: "Graham_scan",
                value: function (e, t, n) {
                    var i, a, o = 0,
                        s = 2;
                    for (i = 1; i < n; i++)(e[i].y < e[o].y || e[i].y == e[o].y && e[i].x < e[o].x) && (o = i);
                    var r = e[0];
                    e[0] = e[o], e[o] = r;
                    var l = n;
                    for (i = 1; i < l - 1; i++) {
                        for (o = i, a = i + 1; a < l; a++) {
                            var u = this.multiply(e[0], e[o], e[a]);
                            if (u > 0) o = a;
                            else if (0 == u) {
                                l--, F.distanceSquaredVec2(e[0], e[a]) - F.distanceSquaredVec2(e[0], e[o]) > 0 ? (e[o] = e[a], e[a] = e[l], a--) : (r = e[l], e[l] = e[a], e[a] = r)
                            }
                        }
                        r = e[i], e[i] = e[o], e[o] = r
                    }
                    for (t.push(e[0]), t.push(e[1]), t.push(e[2]), i = 3; i < l; i++) {
                        for (; !(this.multiply(e[i], t[s - 1], t[s]) < 0);) s--, t.pop();
                        s++, t.push(e[i])
                    }
                }
            }, {
                key: "GetPathLen",
                value: function (e) {
                    for (var t = 0, n = 0; n < e.length; n++) {
                        var i = void 0,
                            a = void 0;
                        0 == n ? (i = e[e.length - 1], a = e[n]) : n == e.length - 1 ? (i = e[n], a = e[0]) : (i = e[n], a = e[n + 1]), t += F.distanceVec2(i, a)
                    }
                    return t
                }
            }, {
                key: "Clamp",
                value: function (e, t, n) {
                    return e < t && (e = t), e > n && (e = n), e
                }
            }, {
                key: "PushCircleGridPos",
                value: function (e, t, n, i, a) {
                    for (var o = t - 1; o <= t + 1; o++)
                        for (var s = n - 1; s <= n + 1; s++) this.PushCirclePos(e, o, s, i, a)
                }
            }, {
                key: "PushCirclePos",
                value: function (e, t, n, i, a) {
                    Math.abs(t) > i || Math.abs(n) > i ? console.log(t, n) : (this.pushPos(e, t, n, a), this.pushPos(e, -t, n, a), this.pushPos(e, t, -n, a), this.pushPos(e, -t, -n, a), this.pushPos(e, n, t, a), this.pushPos(e, -n, t, a), this.pushPos(e, n, -t, a), this.pushPos(e, -n, -t, a))
                }
            }, {
                key: "pushPos",
                value: function (e, t, n, i) {
                    if (null != i) {
                        var a = t + "" + n;
                        if (i.includes(a)) return
                    }
                    e.push(new Laya.Vector2(n, t))
                }
            }, {
                key: "GetCirclrPath_Bresenham",
                value: function (e, t, n) {
                    for (var i = [], a = n, o = 0, s = -2 * n + 3, r = s, l = 0, u = 0; a >= o;) s >= 0 ? (r = s - 4 * a + 4 * o + 10, l = a - 1, u = o + 1) : (r = s + 4 * o + 6, l = a, u = o + 1), this.PushCircleGridPos(i, a, o, n), a = Math.round(l), o = Math.round(u), s = r;
                    return i.forEach(function (n) {
                        n.x += e, n.y += t
                    }), i
                }
            }, {
                key: "GetCirclrPath",
                value: function (e, t, n) {
                    var i = [],
                        a = [],
                        o = 0,
                        s = n,
                        r = 1 - n;
                    for (this.PushCircleGridPos(i, o, s, n, a); o <= s;) r < 0 ? r += 2 * o + 3 : (r += 2 * (o - s) + 5, s--), o++, this.PushCircleGridPos(i, o, s, n, a);
                    return i.forEach(function (n) {
                        n.x += e, n.y += t
                    }), i
                }
            }, {
                key: "RandomFloat",
                value: function (e, t) {
                    return e + Math.random() * (t - e)
                }
            }, {
                key: "RandomInt",
                value: function (e, t) {
                    return e + Math.round(Math.random() * (t - e))
                }
            }]), MathUtils
        }();
    ! function (e) {
        e.prefab = "@CameraNode@@UpgradeTable@@HRTable@@BoxMaker@@PakerPos@@PizzaMaker@@PizzaPos@@QuadTable@@QuadTablePos@@SideMenuCounter@@SidePos@@SingleTable@@SingleTableBig@@SingleTablePos@@TileLocked@@TileLevel4@@TileLevel3@@TileLevel2@@TileLevel1@@yun@@box@@Clock@@DirectionalLight@@Fence@@FireBrake@@flowerpot@@GuestStation@@HR@@Menu@@rail@@UnlockTips@@Upgrade@@Wall_DoorLevel1@@Wall_DoorLevel2@@Wall_DoorLevel3@@Wall_DoorLevel4@@Wall_FlatLevel1@@Wall_FlatLevel2@@Wall_FlatLevel3@@Wall_FlatLevel4@@MoneyAD@@MoneyUnlockTag@@AdUnlockTag@@ArrowHeart@@pinghengche@@Pizza@@Money@@PizzaBox@@UpgradeAD@@Customer@@laobanliang@@rider@@Player@@Supporter@@Feiji@@Wurenji@"
    }(Kt || (Kt = {}));
    var qt = function (e) {
            function PrefabManager() {
                var e;
                return _classCallCheck(this, PrefabManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(PrefabManager).call(this))).prefabMap = {}, e.PrepareData(), e
            }
            return _inherits(PrefabManager, O), _createClass(PrefabManager, [{
                key: "PrepareData",
                value: function () {
                    var e = this;
                    for (var t in Kt) {
                        var n = Kt[t];
                        if ("" != n && null != n) n.split("@").forEach(function (n) {
                            if ("" != n) {
                                var i = e.prefabMap[n] = new Jt;
                                i.isCache = !1, i.name = n, i.pkg = t
                            }
                        })
                    }
                }
            }, {
                key: "LoadPrefab",
                value: function (e, t, n, i) {
                    var a = [];
                    for (var o in e) null == e[o] && console.error(o, " 没有导出到prefab表"), a.push(e[o].GetUrl());
                    $t.LoadPrefabRes(a, t, n, i)
                }
            }, {
                key: "LoadPrefabByNameCB",
                value: function (e, t) {
                    var n = this.prefabMap[e];
                    if (null != n) {
                        var i = this.GetPrefab(e);
                        if (null != i) return t.runWith(i), void t.recover();
                        $t.LoadPrefabRes([n.GetUrl()], function (e) {
                            if (e) {
                                var i = Laya.loader.getRes(n.GetUrl());
                                i ? t.runWith(i) : t.runWith(null)
                            } else t.runWith(null);
                            t.recover()
                        }, null, this)
                    } else t.runWith(null), t.recover()
                }
            }, {
                key: "LoadPrefabByName",
                value: function (e) {
                    var t = this;
                    return new w(function (n, i, a) {
                        var o = t.prefabMap[e];
                        if (null != o) {
                            var s = t.GetPrefab(e);
                            if (null != s) return i(1), void n(s);
                            $t.LoadPrefabRes([o.GetUrl()], function (e) {
                                if (e) {
                                    var t = Laya.loader.getRes(o.GetUrl());
                                    t ? n(t) : a(o.GetUrl() + " not has res!")
                                } else a(o.GetUrl() + " load failed!")
                            }, i, t)
                        } else a("prefab " + e + " not in prefabMap! or not exported!")
                    })
                }
            }, {
                key: "LoadPrefabByNames",
                value: function () {
                    for (var e = this, t = arguments.length, n = new Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                    return new w(function (t, i, a) {
                        var o = [];
                        n.forEach(function (t) {
                            var n = e.prefabMap[t];
                            o.push(n.GetUrl())
                        }), $t.LoadPrefabRes(o, function (e) {
                            t()
                        }, i, e)
                    })
                }
            }, {
                key: "GetPrefab",
                value: function (e) {
                    if (null != this.prefabMap[e]) return Laya.loader.getRes(this.prefabMap[e].GetUrl());
                    console.error("not find ", e)
                }
            }, {
                key: "UnLoadPrefab",
                value: function (e) {
                    var t = [];
                    e.forEach(function (e) {
                        t.push(e.GetUrl())
                    }), $t.ClearRes(t)
                }
            }]), PrefabManager
        }(),
        Jt = function () {
            function PrefabItem() {
                _classCallCheck(this, PrefabItem)
            }
            return _createClass(PrefabItem, [{
                key: "GetUrl",
                value: function () {
                    return "unity/level/Conventional/".concat(this.name, ".lh")
                }
            }]), PrefabItem
        }(),
        Zt = new Laya.Vector3,
        Qt = new Laya.Vector3,
        en = function (e) {
            function CamperCtrl() {
                var e;
                return _classCallCheck(this, CamperCtrl), (e = _possibleConstructorReturn(this, _getPrototypeOf(CamperCtrl).apply(this, arguments))).speed = 10, e.velocity = new Laya.Vector3, e.moveDis = 0, e.stepTargetDis = 0, e.sitting = !1, e.targetY = 0, e
            }
            return _inherits(CamperCtrl, Rt), _createClass(CamperCtrl, [{
                key: "onStart",
                value: function () {
                    this._ani = this.sp.getComponent(Laya.Animator), this.PlayAni("Idle")
                }
            }, {
                key: "onUpdate",
                value: function () {
                    if (!this.sitting)
                        if (null != this.targets) {
                            this.PlayAni("Slow Run", .1);
                            var e = Qt;
                            this.transform.localRotationEulerY = Laya.MathUtil.lerp(this.transform.localRotationEulerY, this.targetY, 10 * F.deltaTimeSec), this.transform.rotation = this.transform.rotation, Math.abs(this.targetY - this.transform.localRotationEulerY), Laya.Vector3.scale(this.velocity, F.deltaTimeSec, e);
                            var t = Laya.Vector3.scalarLength(e),
                                n = !1,
                                i = 0;
                            0 == this.targets.length && (i = .05), this.moveDis + t + i > this.stepTargetDis ? (t = this.stepTargetDis - this.moveDis, Laya.Vector3.normalize(e, e), Laya.Vector3.scale(e, t, e), n = !0, this.moveDis = 0) : this.moveDis += t, Laya.Vector3.add(this.transform.position, e, e), this.transform.position = e, n && this.setTarget()
                        } else this.PlayAni("Idle", .1)
                }
            }, {
                key: "SetPath",
                value: function (e, t) {
                    this.targets = null == e ? [] : _toConsumableArray(e), this.sitting = !1, this.arriveCB = t, this.setTarget()
                }
            }, {
                key: "SetBackState",
                value: function () {
                    this.speed = 5, this.currentAni = ""
                }
            }, {
                key: "setTarget",
                value: function () {
                    if (null != this.targets) {
                        if (0 == this.targets.length) return this.arriveCB && this.arriveCB(), void(this.targets = null);
                        for (var e = this.targets.shift(); Laya.Vector3.distanceSquared(e, this.transform.position) < .1;) {
                            if (0 == this.targets.length) return this.arriveCB && this.arriveCB(), void(this.targets = null);
                            e = this.targets.shift()
                        }
                        this.moveDis = 0, this.stepTargetDis = Laya.Vector3.distance(this.transform.position, e), Laya.Vector3.subtract(e, this.transform.position, this.velocity), this.velocity.y = 0, Laya.Vector3.normalize(this.velocity, this.velocity), Laya.Vector3.scale(this.velocity, this.speed, this.velocity), Laya.Vector3.subtract(e, this.transform.position, Zt), Laya.Vector3.scale(Zt, -1, Zt), Laya.Vector3.add(this.transform.position, Zt, Zt);
                        var t = this.transform.localRotationEulerY;
                        this.transform.lookAt(Zt, F.UP), this.transform.localRotationEulerX = this.transform.localRotationEulerZ = 0, this.targetY = this.transform.localRotationEulerY, this.transform.localRotationEulerY = t
                    }
                }
            }, {
                key: "Sit",
                value: function (e) {
                    Laya.Tween.to(this.transform.position, e.transform.position, 100), Laya.Tween.to(this.transform.rotation, e.transform.rotation, 100).update = Laya.Handler.create(this, this._updatePos, null, !1), this.sitting = !0
                }
            }, {
                key: "_updatePos",
                value: function () {
                    null == this.sp || this.sp.destroyed || null == this.transform || (this.transform.position = this.transform.position, this.transform.rotation = this.transform.rotation)
                }
            }, {
                key: "Eat",
                value: function () {
                    this._ani.speed = 2, this.PlayAni("Sitting_Yell", .1)
                }
            }, {
                key: "Leave",
                value: function () {
                    this.sitting = !1, this._ani.speed = 1, this.PlayAni("Slow Run", .1)
                }
            }, {
                key: "onReset",
                value: function () {
                    this.sitting = !1, this.speed = 6
                }
            }]), CamperCtrl
        }(),
        tn = function (e) {
            function baseUI$I() {
                return _classCallCheck(this, baseUI$I), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$I).apply(this, arguments))
            }
            return _inherits(baseUI$I, fgui.GComponent), baseUI$I
        }(),
        nn = function (e) {
            function UI_ui_fendian() {
                return _classCallCheck(this, UI_ui_fendian), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_fendian).apply(this, arguments))
            }
            return _inherits(UI_ui_fendian, tn), _createClass(UI_ui_fendian, [{
                key: "onConstruct",
                value: function () {
                    this.m_com_mengban = this.getChildAt(0), this.m_comp_fendian = this.getChildAt(1), this.m_comp_jinbi = this.getChildAt(2)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "ui_fendian")
                }
            }]), UI_ui_fendian
        }();
    nn.URL = "ui://pr6skzjagq2mgw";
    var an = function (e) {
            function baseUI$H() {
                return _classCallCheck(this, baseUI$H), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$H).apply(this, arguments))
            }
            return _inherits(baseUI$H, fgui.GComponent), baseUI$H
        }(),
        on = function (e) {
            function UI_ui_qiche() {
                return _classCallCheck(this, UI_ui_qiche), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_qiche).apply(this, arguments))
            }
            return _inherits(UI_ui_qiche, an), _createClass(UI_ui_qiche, [{
                key: "onConstruct",
                value: function () {
                    this.m_close = this.getControllerAt(0), this.m_switch = this.getControllerAt(1), this.m_com_mengban = this.getChildAt(0), this.m_btn_ad = this.getChildAt(2), this.m_btn_ad1 = this.getChildAt(3), this.m_btn_close0 = this.getChildAt(4), this.m_btn_close2 = this.getChildAt(5), this.m_btn_close1 = this.getChildAt(6)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "ui_qiche")
                }
            }]), UI_ui_qiche
        }();
    on.URL = "ui://pr6skzjagq2mgx";
    var sn = function (e) {
            function baseUI$G() {
                return _classCallCheck(this, baseUI$G), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$G).apply(this, arguments))
            }
            return _inherits(baseUI$G, fgui.GComponent), baseUI$G
        }(),
        rn = function (e) {
            function UI_ui_zhaopin() {
                return _classCallCheck(this, UI_ui_zhaopin), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_zhaopin).apply(this, arguments))
            }
            return _inherits(UI_ui_zhaopin, sn), _createClass(UI_ui_zhaopin, [{
                key: "onConstruct",
                value: function () {
                    this.m_close = this.getControllerAt(0), this.m_switch = this.getControllerAt(1), this.m_com_mengban = this.getChildAt(0), this.m_comp_zhaopin = this.getChildAt(1), this.m_btn_close1 = this.getChildAt(2), this.m_btn_close0 = this.getChildAt(3), this.m_btn_close2 = this.getChildAt(4), this.m_btn_ad = this.getChildAt(6), this.m_btn_ad1 = this.getChildAt(7)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "ui_zhaopin")
                }
            }]), UI_ui_zhaopin
        }();
    rn.URL = "ui://pr6skzjagq2mgy";
    var ln = function (e) {
            function baseUI$F() {
                return _classCallCheck(this, baseUI$F), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$F).apply(this, arguments))
            }
            return _inherits(baseUI$F, fgui.GComponent), baseUI$F
        }(),
        un = function (e) {
            function UI_comp_fendian() {
                return _classCallCheck(this, UI_comp_fendian), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_fendian).apply(this, arguments))
            }
            return _inherits(UI_comp_fendian, ln), _createClass(UI_comp_fendian, [{
                key: "onConstruct",
                value: function () {
                    this.m_btn_fanhui = this.getChildAt(1), this.m_list = this.getChildAt(3)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "comp_fendian")
                }
            }]), UI_comp_fendian
        }();
    un.URL = "ui://pr6skzjagq2mgz";
    var hn = function (e) {
            function baseUI$E() {
                return _classCallCheck(this, baseUI$E), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$E).apply(this, arguments))
            }
            return _inherits(baseUI$E, fgui.GButton), baseUI$E
        }(),
        cn = function (e) {
            function UI_comp_jiesuo() {
                return _classCallCheck(this, UI_comp_jiesuo), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_jiesuo).apply(this, arguments))
            }
            return _inherits(UI_comp_jiesuo, hn), _createClass(UI_comp_jiesuo, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_btn_dangqian = this.getChildAt(5), this.m_btn_jiesuo = this.getChildAt(6), this.m_btn_qianwang = this.getChildAt(7)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "comp_jiesuo")
                }
            }]), UI_comp_jiesuo
        }();
    cn.URL = "ui://pr6skzjagq2mh1";
    var dn = function (e) {
            function baseUI$D() {
                return _classCallCheck(this, baseUI$D), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$D).apply(this, arguments))
            }
            return _inherits(baseUI$D, fgui.GButton), baseUI$D
        }(),
        fn = function (e) {
            function UI_btn_jiesuo() {
                return _classCallCheck(this, UI_btn_jiesuo), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_jiesuo).apply(this, arguments))
            }
            return _inherits(UI_btn_jiesuo, dn), _createClass(UI_btn_jiesuo, [{
                key: "onConstruct",
                value: function () {
                    this.m_text_jinbi = this.getChildAt(2)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "btn_jiesuo")
                }
            }]), UI_btn_jiesuo
        }();
    fn.URL = "ui://pr6skzjagq2mh5";
    var _n = function (e) {
            function baseUI$C() {
                return _classCallCheck(this, baseUI$C), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$C).apply(this, arguments))
            }
            return _inherits(baseUI$C, fgui.GComponent), baseUI$C
        }(),
        yn = function (e) {
            function UI_com_qiche() {
                return _classCallCheck(this, UI_com_qiche), _possibleConstructorReturn(this, _getPrototypeOf(UI_com_qiche).apply(this, arguments))
            }
            return _inherits(UI_com_qiche, _n), _createClass(UI_com_qiche, [{
                key: "onConstruct",
                value: function () {
                    this.m_btn_fanhui = this.getChildAt(3), this.m_loader_tubiao = this.getChildAt(4)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "com_qiche")
                }
            }]), UI_com_qiche
        }();
    yn.URL = "ui://pr6skzjagq2mh6";
    var pn = function (e) {
            function baseUI$B() {
                return _classCallCheck(this, baseUI$B), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$B).apply(this, arguments))
            }
            return _inherits(baseUI$B, fgui.GComponent), baseUI$B
        }(),
        gn = function (e) {
            function UI_comp_shijian() {
                return _classCallCheck(this, UI_comp_shijian), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_shijian).apply(this, arguments))
            }
            return _inherits(UI_comp_shijian, pn), _createClass(UI_comp_shijian, [{
                key: "onConstruct",
                value: function () {
                    this.m_type = this.getControllerAt(0), this.m_text_miaoshu = this.getChildAt(1), this.m_loader_tubiao = this.getChildAt(2)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "comp_shijian")
                }
            }]), UI_comp_shijian
        }();
    gn.URL = "ui://pr6skzjagq2mh7";
    var vn = function (e) {
            function baseUI$A() {
                return _classCallCheck(this, baseUI$A), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$A).apply(this, arguments))
            }
            return _inherits(baseUI$A, fgui.GComponent), baseUI$A
        }(),
        mn = function (e) {
            function UI_ui_fenxiang() {
                return _classCallCheck(this, UI_ui_fenxiang), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_fenxiang).apply(this, arguments))
            }
            return _inherits(UI_ui_fenxiang, vn), _createClass(UI_ui_fenxiang, [{
                key: "onConstruct",
                value: function () {
                    this.m_com_mengban = this.getChildAt(0), this.m_comp_jinbi = this.getChildAt(1), this.m_comp_win = this.getChildAt(2), this.m_btn_share = this.getChildAt(3)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "ui_fenxiang")
                }
            }]), UI_ui_fenxiang
        }();
    mn.URL = "ui://pr6skzjav45fhg";
    var Cn = function (e) {
            function baseUI$z() {
                return _classCallCheck(this, baseUI$z), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$z).apply(this, arguments))
            }
            return _inherits(baseUI$z, fgui.GComponent), baseUI$z
        }(),
        kn = function (e) {
            function UI_comp_fenxiang() {
                return _classCallCheck(this, UI_comp_fenxiang), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_fenxiang).apply(this, arguments))
            }
            return _inherits(UI_comp_fenxiang, Cn), _createClass(UI_comp_fenxiang, [{
                key: "onConstruct",
                value: function () {
                    this.m_text_jaingli = this.getChildAt(4), this.m_btn_fanhui = this.getChildAt(5)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "comp_fenxiang")
                }
            }]), UI_comp_fenxiang
        }();
    kn.URL = "ui://pr6skzjav45fhl";
    var Sn = function (e) {
            function baseUI$y() {
                return _classCallCheck(this, baseUI$y), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$y).apply(this, arguments))
            }
            return _inherits(baseUI$y, fgui.GButton), baseUI$y
        }(),
        In = function (e) {
            function UI_btn_fenxiang$1() {
                return _classCallCheck(this, UI_btn_fenxiang$1), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_fenxiang$1).apply(this, arguments))
            }
            return _inherits(UI_btn_fenxiang$1, Sn), _createClass(UI_btn_fenxiang$1, [{
                key: "onConstruct",
                value: function () {
                    this.m_label_count = this.getChildAt(2)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("suijishijian", "btn_fenxiang")
                }
            }]), UI_btn_fenxiang$1
        }();
    In.URL = "ui://pr6skzjav45fhm";
    var bn, Ln = function () {
            function suijishijianBinder() {
                _classCallCheck(this, suijishijianBinder)
            }
            return _createClass(suijishijianBinder, null, [{
                key: "bindAll",
                value: function () {
                    fgui.UIObjectFactory.setExtension(nn.URL, nn), fgui.UIObjectFactory.setExtension(on.URL, on), fgui.UIObjectFactory.setExtension(rn.URL, rn), fgui.UIObjectFactory.setExtension(un.URL, un), fgui.UIObjectFactory.setExtension(cn.URL, cn), fgui.UIObjectFactory.setExtension(fn.URL, fn), fgui.UIObjectFactory.setExtension(yn.URL, yn), fgui.UIObjectFactory.setExtension(gn.URL, gn), fgui.UIObjectFactory.setExtension(mn.URL, mn), fgui.UIObjectFactory.setExtension(kn.URL, kn), fgui.UIObjectFactory.setExtension(In.URL, In)
                }
            }]), suijishijianBinder
        }(),
        Pn = function () {
            function GameSDKHelper() {
                _classCallCheck(this, GameSDKHelper)
            }
            return _createClass(GameSDKHelper, null, [{
                key: "switch",
                get: function () {
                    var e = this._switch;
                    return mt.ActiveExchangeBtn && (this._switch = 1 == this._switch ? 0 : 1), e
                }
            }, {
                key: "OpenJoker",
                get: function () {
                    if (!Laya.Browser.onMiniGame) return !!Laya.Browser.onTTMiniGame && !this.TTShengHe;
                    var e = 0,
                        t = mt.sdk;
                    if (t && t.getLaunchOptionsSync) {
                        var n = t.getLaunchOptionsSync();
                        console.log("getLaunchOptionsSync", n), n && (e = +n.scene)
                    }
                    return mt.isBlackScene(e)
                }
            }, {
                key: "ShowInterst",
                get: function () {
                    if (!this.OpenJoker) return !1;
                    var e = Number(mt.sdk.data.inerst);
                    return !Number.isNaN(e) && 100 * Math.random() <= e
                }
            }, {
                key: "MPbannerTime",
                get: function () {
                    var e = Number(mt.sdk.data.BannerMoveChange);
                    return Number.isNaN(e) ? e = 1500 : e *= 1e3, e
                }
            }, {
                key: "OpenMPbanner",
                get: function () {
                    if (!this.OpenJoker) return !1;
                    var e = Number(mt.sdk.data.MPbanner);
                    return !Number.isNaN(e) && 100 * Math.random() <= e
                }
            }, {
                key: "TTShengHe",
                get: function () {
                    return !!Laya.Browser.onTTMiniGame && mt.isCurrentVersion
                }
            }, {
                key: "CloseType",
                get: function () {
                    if (null == mt.sdk.data) return 0;
                    var e = mt.sdk.data.closeType,
                        t = Number.parseInt(e);
                    return Number.isNaN(t) ? 0 : t > 2 ? 0 : t
                }
            }]), GameSDKHelper
        }();
    Pn._switch = 0,
        function (e) {
            e.normal = "General employee", e.lbn = "Landlady", e.wrj = "UAV"
        }(bn || (bn = {}));
    var Tn = function (e) {
        function UnlockSupportAD() {//todo:员工解锁界面
            return _classCallCheck(this, UnlockSupportAD), _possibleConstructorReturn(this, _getPrototypeOf(UnlockSupportAD).apply(this, arguments))
        }
        return _inherits(UnlockSupportAD, Fe), _createClass(UnlockSupportAD, [{
            key: "_refreshAdVisible",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0] || !mt.isAdUser();
                this.ui.m_btn_ad1.visible = e, this.ui.m_btn_ad.visible = !e, e || this._addTimer()
            }
        }, {
            key: "_addTimer",
            value: function () {
                this._btnCD = 3, this._refreshBtnCD(), Laya.timer.loop(1e3, this, this._btnTimer)
            }
        }, {
            key: "_removeTimer",
            value: function () {
                Laya.timer.clear(this, this._btnTimer), this._refreshAdVisible(!0), this._refreshBtnCD()
            }
        }, {
            key: "_btnTimer",
            value: function () {
                this._btnCD--, this._refreshBtnCD(), 0 == this._btnCD && this.onClickGet()
            }
        }, {
            key: "_refreshBtnCD",
            value: function () {
                this.ui.m_btn_ad.getChild("text_shijian").text = this._btnCD + ""
            }
        }, {
            key: "OnCreate",
            value: function () {
                this.ui.m_btn_ad.onClick(this, this.onClickGet), this.ui.m_btn_ad1.onClick(this, this.onClickGet), this.ui.m_btn_close0.onClick(this, this.onClickClose), this.ui.m_btn_close1.onClick(this, this.onClickClose), this.ui.m_btn_close2.onClick(this, this.onClickClose)
            }
        }, {
            key: "OnShow",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : bn.normal;
                switch (this.sType = e, this.sType) {
                    case bn.normal:
                        this.ui.m_comp_zhaopin.m_type.selectedIndex = 0;
                        break;
                    case bn.lbn:
                        this.ui.m_comp_zhaopin.m_type.selectedIndex = 1, G.inst.playSound("aha");
                        break;
                    case bn.wrj:
                        this.ui.m_comp_zhaopin.m_type.selectedIndex = 2, G.inst.playSound("wurenji")
                }
                G.inst.playSound("SFX_Upgrade_Building"), this.ui.m_switch.selectedIndex = Pn.switch
            }
        }, {
            key: "OnHide",
            value: function () {
                this._removeTimer(), N.getInst().event(Et.CloseUnlockUI)
            }
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "onClickClose",
            value: function () {
                switch (this.sType) {
                    case bn.normal:
                        Wt.inst.ShowADSupport = !0;
                        break;
                    case bn.wrj:
                        Wt.inst.ShowADWRJ = !1
                }
				Plat.I.ShowInter()
                j.inst.PopUI(this.layer, !0)
            }
        }, {
            key: "onClickGet",
            value: function () {
                var e = this;
                this._removeTimer(), mt.showADVideo(this, function (t) {
                    if (t) {
                        switch (e.sType) {
                            case bn.normal:
                                Wt.inst.ShopSupportCountLevel++, Wt.inst.HasADSupport = !0;
                                break;
                            case bn.lbn:
                                Wt.inst.UnlockedGirlSupport = !0;
                                break;
                            case bn.wrj:
                                Wt.inst.UnlockedGirlUAV = !0, Wt.inst.HasADWRJ = !1
                        }
                        console.log(e.sType), N.getInst().event(Et.UpdateSupport), e.onClickClose()
                    }
                }, "Unlock " + this.sType)
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_com_mengban]
            }
        }]), UnlockSupportAD
    }();
    __decorate([throttle(1e3)], Tn.prototype, "onClickGet", null), Tn = __decorate([ui_register(rn, Ln)], Tn);
    var An = new Laya.Vector2,
        wn = function (e) {
            function RadiusTrigger() {
                var e;
                return _classCallCheck(this, RadiusTrigger), (e = _possibleConstructorReturn(this, _getPrototypeOf(RadiusTrigger).apply(this, arguments))).maxX = -1 / 0, e.minX = 1 / 0, e.maxY = -1 / 0, e.minY = 1 / 0, e.center = new Laya.Vector2, e.radius = 2, e.stayDelay = 0, e.stayDelayDuration = 100, e.stayCD = 0, e.stayCallDurationOrigin = 100, e.StayCallDurationMin = 10, e.stayCallDuration = 100, e.tweenFade = !0, e.tweenFadeDuration = 1e3, e.checkMove = !0, e.isEnter = !1, e.stayTime = 0, e
            }
            return _inherits(RadiusTrigger, Rt), _createClass(RadiusTrigger, [{
                key: "_parse",
                value: function (e) {
                    this.radius = Number(e.fn_radius)
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.radius = this.radius
                }
            }, {
                key: "onStart",
                value: function () {
                    this.center = new Laya.Vector2(this.transform.position.x, this.transform.position.z), this.maxX = this.center.x + this.radius, this.minX = this.center.x - this.radius, this.maxY = this.center.y + this.radius, this.minY = this.center.y - this.radius, this.stayCallDurationOrigin = this.stayCallDuration, this.ease = this.ease || Laya.Ease.sineIn
                }
            }, {
                key: "FastTest",
                value: function (e) {
                    return e.x >= this.minX && e.x <= this.maxX && e.y >= this.minY && e.y <= this.maxY
                }
            }, {
                key: "onUpdate",
                value: function () {
                    var e = pi.getInst().player;
                    if (null != e) {
                        this.center = new Laya.Vector2(this.transform.position.x, this.transform.position.z), this.maxX = this.center.x + this.radius, this.minX = this.center.x - this.radius, this.maxY = this.center.y + this.radius, this.minY = this.center.y - this.radius, An.setValue(e.transform.position.x, e.transform.position.z);
                        var t = this.FastTest(An);
                        return t && (t = F.distanceVec2(An, this.center) <= this.radius), !this.isEnter && t ? (this.isEnter = t, void this._onTriggerEner()) : this.isEnter && t ? (this.isEnter = t, void this._onTriggerStay()) : this.isEnter && !t ? (this.isEnter = t, void this._onTriggerExit()) : void 0
                    }
                }
            }, {
                key: "_onTriggerEner",
                value: function () {
                    this.stayTime = 0, this.onEnterCB && this.onEnterCB()
                }
            }, {
                key: "_onTriggerStay",
                value: function () {
                    if (!(this.checkMove && pi.getInst().player.isMove || (this.stayDelay += F.deltaTime, this.stayDelay < this.stayDelayDuration || (this.stayTime += F.deltaTime, this.tweenFade && (this.stayCallDuration = this.ease(Math.min(this.stayTime, this.tweenFadeDuration), this.stayCallDurationOrigin, this.StayCallDurationMin - this.stayCallDurationOrigin, this.tweenFadeDuration)), this.stayCD += F.deltaTime, this.stayCD < this.stayCallDuration))))
                        for (this.stayCallDuration = Math.max(1, this.stayCallDuration); this.stayCD >= this.stayCallDuration;) this.stayCD -= this.stayCallDuration, this.onStayCB && this.onStayCB()
                }
            }, {
                key: "_onTriggerExit",
                value: function () {
                    this.stayCallDuration = 100, this.onExitCB && this.onExitCB()
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("RadiusTrigger", RadiusTrigger)
                }
            }]), RadiusTrigger
        }(),
        Un = function (e) {
            function AdUnlockTag() {//todo:地面触发型广告
                var e;
                return _classCallCheck(this, AdUnlockTag),
					(e = _possibleConstructorReturn(this, _getPrototypeOf(AdUnlockTag).apply(this, arguments))).max = 1, 
					e.progress = 0, e.useAD = !0, e.triggerTime = 1000, e.triggerRadius = 2, e.ad = !1, e
            }
            return _inherits(AdUnlockTag, Rt), _createClass(AdUnlockTag, [
				{
                key: "onAwake",
                value: function () {
                    var e = (this.sp.getChildByName("Progress") || this.sp.getChildAt(0)).meshRenderer;
                    this.mat = e.material, this.rt = this.sp.addComponent(wn), this.rt.radius = this.triggerRadius, this.rt.onEnterCB = this._onTriggerEnter.bind(this), this.rt.onExitCB = this._onTriggerExit.bind(this), this.rt.tweenFade = !0, this.rt.stayDelayDuration = 0, this.rt.stayCallDuration = 60
                }
            },
				{
                key: "OnDestroy",
                value: function () {
                    this.ClearAsycFunc(), Laya.Tween.clearAll(this)
                }
            },
				{
                key: "onStart",
                value: function () {
                    this.Max = 1, this.Progress = 0, this.updateMat()
                }
            },
				{
                key: "updateMat",
                value: function () {
                    if (!this.sp.destroyed && null != this.mat) {
                        var e = this.progress / this.max;
                        this.mat._Value = e
                    }
                }
            }, {
                key: "_onTriggerEnter",
                value: function () {
                    this.ad = !1, Laya.Tween.to(this, {
                        Progress: 1
                    }, this.triggerTime, null, Laya.Handler.create(this, this._onTweenEnd), null, !0)
                }
            }, {
                key: "_onTriggerExit",
                value: function () {
                    Laya.Tween.to(this, {
                        Progress: 0
                    }, 200, null, null, null, !0)
                }
            }, {
                key: "_onTweenEnd",
                value: function () {
                    this._onFull()
                }
            }, {
                key: "_onFull",
                value: function () {
                    var e = this;
                    1 != this.ad && (this.ad = !0, this.useAD ? mt.showADVideo(this, function (t) {
                        t && (e.FullCB && e.FullCB(), e.sp.destroy(!0))
                    }, "Unlock desk") : (this.FullCB && this.FullCB(), this.sp.destroy(!0)))
                }
            }, {
                key: "_parse",
                value: function (e) {
                    this.triggerRadius = Number(e.fn_radius), Number.isNaN(this.triggerRadius) && (this.triggerRadius = 2)
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.triggerRadius = this.triggerRadius
                }
            }, {
                key: "Max",
                get: function () {
                    return this.max
                },
                set: function (e) {
                    this.max = e, Laya.timer.callLater(this, this.updateMat)
                }
            }, {
                key: "Progress",
                get: function () {
                    return this.progress
                },
                set: function (e) {
                    this.progress = e, Laya.timer.callLater(this, this.updateMat)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("AdUnlockTag", AdUnlockTag)
                }
            }]), AdUnlockTag
        }(),
        Dn = function (e) {
            function FontDataHelper() {
                var e;
                return _classCallCheck(this, FontDataHelper), (e = _possibleConstructorReturn(this, _getPrototypeOf(FontDataHelper).apply(this, arguments))).fontData = {
                    47: {
                        x: 318,
                        y: 168,
                        xoffset: 3,
                        yoffset: 0,
                        xadvance: 112,
                        width: 106,
                        height: 84,
                        chnl: 15
                    },
                    46: {
                        x: 251,
                        y: 197,
                        xoffset: 4,
                        yoffset: 59,
                        xadvance: 36,
                        width: 28,
                        height: 25,
                        chnl: 15
                    },
                    48: {
                        x: 18,
                        y: 0,
                        xoffset: 8,
                        yoffset: 0,
                        xadvance: 86,
                        width: 70,
                        height: 84,
                        chnl: 15
                    },
                    49: {
                        x: 142,
                        y: 0,
                        xoffset: 18,
                        yoffset: 0,
                        xadvance: 86,
                        width: 33,
                        height: 83,
                        chnl: 15
                    },
                    50: {
                        x: 229,
                        y: 1,
                        xoffset: 7,
                        yoffset: 0,
                        xadvance: 86,
                        width: 71,
                        height: 81,
                        chnl: 15
                    },
                    51: {
                        x: 334,
                        y: 0,
                        xoffset: 6,
                        yoffset: 0,
                        xadvance: 86,
                        width: 74,
                        height: 84,
                        chnl: 15
                    },
                    52: {
                        x: 14,
                        y: 84,
                        xoffset: 4,
                        yoffset: 0,
                        xadvance: 86,
                        width: 77,
                        height: 84,
                        chnl: 15
                    },
                    53: {
                        x: 123,
                        y: 85,
                        xoffset: 7,
                        yoffset: 2,
                        xadvance: 86,
                        width: 72,
                        height: 82,
                        chnl: 15
                    },
                    54: {
                        x: 229,
                        y: 84,
                        xoffset: 7,
                        yoffset: 0,
                        xadvance: 86,
                        width: 72,
                        height: 84,
                        chnl: 15
                    },
                    55: {
                        x: 334,
                        y: 85,
                        xoffset: 6,
                        yoffset: 2,
                        xadvance: 86,
                        width: 74,
                        height: 82,
                        chnl: 15
                    },
                    56: {
                        x: 15,
                        y: 168,
                        xoffset: 6,
                        yoffset: 0,
                        xadvance: 86,
                        width: 75,
                        height: 84,
                        chnl: 15
                    },
                    57: {
                        x: 123,
                        y: 168,
                        xoffset: 7,
                        yoffset: 0,
                        xadvance: 86,
                        width: 72,
                        height: 84,
                        chnl: 15
                    }
                }, e
            }
            return _inherits(FontDataHelper, O), _createClass(FontDataHelper, [{
                key: "getFontData",
                value: function (e) {
                    return this.fontData[e]
                }
            }]), FontDataHelper
        }();
    __decorate([res_assign("res/font3D/font.png")], Dn.prototype, "font3D", void 0), Dn = __decorate([res_auto_bind()], Dn);
    var Mn = function Vertexo() {
            _classCallCheck(this, Vertexo), this.x = 0, this.y = 0, this.z = 0, this.nx = 0, this.ny = 0, this.nz = 0, this.u = 0, this.v = 0
        },
        En = function () {
            function MeshData() {
                _classCallCheck(this, MeshData), this.vbArray = [], this.width = 0, this.vertexs = [], this.triangle = []
            }
            return _createClass(MeshData, [{
                key: "addVertex",
                value: function (e, t, n, i, a, o, s, r) {
                    var l = new Mn;
                    l.x = e, l.y = t, l.z = n, l.nx = i, l.ny = a, l.nz = o, l.u = s, l.v = r, this.vertexs.push(l)
                }
            }, {
                key: "combineMesh",
                value: function (e) {
                    for (var t = 0; t < e.length; t++) {
                        for (var n = e[t], i = this.vertexs.length, a = 0; a < n.vertexs.length; a++) this.vertexs.push(n.vertexs[a]);
                        for (a = 0; a < n.triangle.length; a++) this.triangle.push(n.triangle[a] + i)
                    }
                    return this
                }
            }, {
                key: "createMesh",
                value: function () {
                    for (var e = Laya.VertexMesh.getVertexDeclaration("POSITION,NORMAL,UV"), t = 0; t < this.vertexs.length; t++) {
                        var n = this.vertexs[t];
                        this.vbArray.push(n.x, n.y, n.z, n.nx, n.ny, n.nz, n.u, n.v)
                    }
                    var i = new Float32Array(this.vbArray),
                        a = new Uint16Array(this.triangle);
                    return Laya.PrimitiveMesh._createMesh(e, i, a)
                }
            }, {
                key: "destroy",
                value: function () {
                    this.vbArray = null, this.vertexs = null, this.triangle = null
                }
            }, {
                key: "mesh",
                get: function () {
                    return this.createMesh()
                }
            }]), MeshData
        }(),
        Rn = function (e) {
            function TextFieldScript3D2() {
                var e;
                return _classCallCheck(this, TextFieldScript3D2), (e = _possibleConstructorReturn(this, _getPrototypeOf(TextFieldScript3D2).apply(this, arguments))).isStart = !1, e.isLoadComplete = !0, e.fontName = "", e.align = "left", e.localScale = null, e.localPosition = null, e.mat = null, e._mesh = null, e._text = "", e.textWidth = 1024, e.textHeight = 113, e
            }
            return _inherits(TextFieldScript3D2, Rt), _createClass(TextFieldScript3D2, [{
                key: "onAwake",
                value: function () {
                    this.localScale = this.transform.localScale.clone(), this.localPosition = this.transform.localPosition.clone(), this.mat = this.owner.meshRenderer.material, this.originX = this.transform.localPositionX, this.originY = this.transform.localPositionY, this.originZ = this.transform.localPositionZ
                }
            }, {
                key: "initFonts",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "center";
                    this.fontName = e, this.align = t, this.fontName;
                    var n = Dn.getInst().font3D;
                    this.mat = this.owner.meshRenderer.material, this.loadComplete(n)
                }
            }, {
                key: "onStart",
                value: function () {
                    this.isLoadComplete && this.showFonts(), this.isStart = !0
                }
            }, {
                key: "showFonts",
                value: function () {
                    if ("" != this._text) {
                        var e = this._text,
                            t = [];
                        this.getFontDatasAndWidth(e, t);
                        for (var n = [], i = 0; i < t.length; i++) n.push(this.createMesh(t[i]));
                        var a = 0;
                        for (i = 0; i < n.length; i++) {
                            for (var o = 0; o < n[i].vertexs.length; o++) n[i].vertexs[o].x += a;
                            a -= n[i].width + .02
                        }
                        n[0].combineMesh(n.slice(1, n.length)), this._mesh = n[0].mesh;
                        var s = this._mesh.bounds;
                        this.transform.localPositionX = (this.originX - s.getCenter().x) * this.transform.localScaleX, this.transform.localPositionZ = this.originZ - s.getCenter().z, this.transform.localPositionY = this.originY, this.owner.meshFilter.sharedMesh = this._mesh, null != this.oldMesh && this.oldMesh.destroy(), this.oldMesh = this._mesh
                    }
                }
            }, {
                key: "createMesh",
                value: function (e) {
                    var t = new En,
                        n = .5 - e.width / 60,
                        i = (e.height + e.yoffset) / 60 - .5,
                        a = e.yoffset / 60 - .5,
                        o = 1 / this.textWidth * .5;
                    return t.addVertex(.5, i, 0, 0, 0, 0, e.x / this.textWidth + o, e.y / this.textHeight + o), t.addVertex(n, i, 0, 0, 0, 0, (e.x + e.width) / this.textWidth + o, e.y / this.textHeight + o), t.addVertex(n, a, 0, 0, 0, 0, (e.x + e.width) / this.textWidth + o, (e.y + e.height) / this.textHeight + o), t.addVertex(.5, a, 0, 0, 0, 0, e.x / this.textWidth + o, (e.y + e.height) / this.textHeight + o), t.triangle.push(0, 1, 2), t.triangle.push(2, 3, 0), t.width = Math.abs(.5 - n), t
                }
            }, {
                key: "loadComplete",
                value: function (e) {
                    this.isLoadComplete = !0, this.mat.albedoTexture = e, this.textHeight = e.height, this.textWidth = e.width, this.isStart && this.showFonts()
                }
            }, {
                key: "getBLine",
                value: function (e, t) {
                    var n = 1;
                    switch (this.align) {
                        case "left":
                            break;
                        case "center":
                            n = Math.floor((t - e) / 2);
                            break;
                        case "right":
                            n = t - e
                    }
                    return n
                }
            }, {
                key: "getTextPosition",
                value: function () {
                    var e = this.localPosition.clone();
                    switch (this.align) {
                        case "left":
                            e.x = (this.transform.localScale.x - this.localScale.x) / 2 + e.x;
                            break;
                        case "center":
                            break;
                        case "right":
                            e.x = e.x - (this.transform.localScale.x - this.localScale.x) / 2
                    }
                    return e
                }
            }, {
                key: "getFontDatasAndWidth",
                value: function (e, t) {
                    for (var n = 0, i = 0; i < e.length; i++) {
                        var a = Dn.getInst().getFontData("" + e.charAt(i).charCodeAt(0));
                        a && (t.push(a), n += a.width)
                    }
                    return n
                }
            }, {
                key: "onDestroy",
                value: function () {
                    this._mesh && (this._mesh.destroy(), this._mesh = null)
                }
            }, {
                key: "text",
                set: function (e) {
                    this._text !== e && (this._text = e, this.isLoadComplete && this.isStart && this.showFonts())
                },
                get: function () {
                    return this._text
                }
            }]), TextFieldScript3D2
        }(),
        xn = function (e) {
            function MoneyUnlockTag() {
                var e;
                return _classCallCheck(this, MoneyUnlockTag), (e = _possibleConstructorReturn(this, _getPrototypeOf(MoneyUnlockTag).apply(this, arguments))).max = 1, e.progress = 0, e.triggerRadius = 2, e
            }
            return _inherits(MoneyUnlockTag, Rt), _createClass(MoneyUnlockTag, [{
                key: "onAwake",
                value: function () {
                    var e = (this.sp.getChildByName("Progress") || this.sp.getChildAt(0)).meshRenderer;
                    this.mat = e.material;
                    var t = this.sp.getChildByName("Text") || this.sp.getChildAt(2);
                    this.text = t.addComponent(Rn), this.text.initFonts("font"), this.rt = this.sp.addComponent(wn), this.rt.radius = this.triggerRadius, this.rt.onEnterCB = this._onTriggerEnter.bind(this), this.rt.onStayCB = this._onTriggerStay.bind(this), this.rt.tweenFade = !0, this.rt.stayDelayDuration = 0, this.rt.stayCallDurationOrigin = 400, this.rt.checkMove = !1
                }
            }, {
                key: "OnDestroy",
                value: function () {
                    Laya.timer.clearAll(this)
                }
            }, {
                key: "onStart",
                value: function () {
                    this.updateMat()
                }
            }, {
                key: "updateMat",
                value: function () {
                    if (!this.sp.destroyed && null != this.mat) {
                        var e = this.progress / this.max;
                        this.mat._Value = e, this.text.text = (this.max - this.progress).toString()
                    }
                }
            }, {
                key: "_onTriggerEnter",
                value: function () {}
            }, {
                key: "_onTriggerStay",
                value: function () {
                    this.Progress < this.Max ? Wt.inst.Money > 0 && (ki.inst.CreateMoney(null != pi.getInst().player ? pi.getInst().player.transform.position : this.transform.position, !0).FlyToZone(this.transform.position, 100, 0, !0), Wt.inst.Money -= Wt.inst.Price, this.Progress += Wt.inst.Price, this.Progress >= this.Max && Laya.timer.once(100, this, this._onFull, null, !0)) : this.enabled = !1
                }
            }, {
                key: "_onTriggerExit",
                value: function () {}
            }, {
                key: "_onFull",
                value: function () {
                    N.getInst().event(Et.UnlockChange), this.FullCB && this.FullCB(), this.sp.destroy(!0), G.inst.playSound("SFX_Upgrade"), G.inst.playVibrate(!0)
                }
            }, {
                key: "_parse",
                value: function (e) {
                    this.triggerRadius = Number(e.fn_radius), Number.isNaN(this.triggerRadius) && (this.triggerRadius = 2)
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.triggerRadius = this.triggerRadius
                }
            }, {
                key: "Max",
                get: function () {
                    return this.max
                },
                set: function (e) {
                    this.max = e, Laya.timer.callLater(this, this.updateMat)
                }
            }, {
                key: "Progress",
                get: function () {
                    return this.progress
                },
                set: function (e) {
                    this.progress = e, this.ProgressCB && this.ProgressCB(e), Laya.timer.callLater(this, this.updateMat)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("MoneyUnlockTag", MoneyUnlockTag)
                }
            }]), MoneyUnlockTag
        }(),
        On = function Face(e, t, n) {
            _classCallCheck(this, Face), this.a = 0, this.b = 0, this.c = 0, this.a = e, this.b = t, this.c = n
        },
        Nn = function () {
            function Geometry() {
                _classCallCheck(this, Geometry), this.faces = [], this.vertices = []
            }
            return _createClass(Geometry, [{
                key: "mergeVertices",
                value: function () {
                    var e, t, n, i, a, o, s = {},
                        r = new Array,
                        l = [],
                        u = Math.pow(10, 4);
                    for (n = 0, i = this.vertices.length; n < i; n++) e = this.vertices[n], null == s[t = Math.round(e.x * u) + "_" + Math.round(e.y * u) + "_" + Math.round(e.z * u)] ? (s[t] = n, r.push(e), l[n] = r.length - 1) : l[n] = l[s[t]];
                    var h = [];
                    for (n = 0, i = this.faces.length; n < i; n++) {
                        (a = this.faces[n]).a = l[a.a], a.b = l[a.b], a.c = l[a.c], o = [a.a, a.b, a.c];
                        for (var c = 0; c < 3; c++)
                            if (o[c] == o[(c + 1) % 3]) {
                                h.push(n);
                                break
                            }
                    }
                    for (n = h.length - 1; n >= 0; n--) {
                        var d = h[n];
                        this.faces.splice(d, 1)
                    }
                    var f = this.vertices.length - r.length;
                    return this.vertices = r, f
                }
            }]), Geometry
        }(),
        Bn = function () {
            function BinaryHeap(e) {
                _classCallCheck(this, BinaryHeap), this.content = [], this.scoreFunction = e
            }
            return _createClass(BinaryHeap, [{
                key: "push",
                value: function (e) {
                    this.content.push(e), this.sinkDown(this.content.length - 1)
                }
            }, {
                key: "pop",
                value: function () {
                    var e = this.content[0],
                        t = this.content.pop();
                    return this.content.length > 0 && (this.content[0] = t, this.bubbleUp(0)), e
                }
            }, {
                key: "remove",
                value: function (e) {
                    var t = this.content.indexOf(e),
                        n = this.content.pop();
                    t !== this.content.length - 1 && (this.content[t] = n, this.scoreFunction(n) < this.scoreFunction(e) ? this.sinkDown(t) : this.bubbleUp(t))
                }
            }, {
                key: "size",
                value: function () {
                    return this.content.length
                }
            }, {
                key: "rescoreElement",
                value: function (e) {
                    this.sinkDown(this.content.indexOf(e))
                }
            }, {
                key: "sinkDown",
                value: function (e) {
                    for (var t = this.content[e]; e > 0;) {
                        var n = (e + 1 >> 1) - 1,
                            i = this.content[n];
                        if (!(this.scoreFunction(t) < this.scoreFunction(i))) break;
                        this.content[n] = t, this.content[e] = i, e = n
                    }
                }
            }, {
                key: "bubbleUp",
                value: function (e) {
                    for (var t = this.content.length, n = this.content[e], i = this.scoreFunction(n);;) {
                        var a = e + 1 << 1,
                            o = a - 1,
                            s = null,
                            r = void 0;
                        if (o < t) {
                            var l = this.content[o];
                            (r = this.scoreFunction(l)) < i && (s = o)
                        }
                        if (a < t) {
                            var u = this.content[a];
                            this.scoreFunction(u) < (null === s ? i : r) && (s = a)
                        }
                        if (null === s) break;
                        this.content[e] = this.content[s], this.content[s] = n, e = s
                    }
                }
            }]), BinaryHeap
        }(),
        Gn = function () {
            function AStar() {
                _classCallCheck(this, AStar)
            }
            return _createClass(AStar, null, [{
                key: "init",
                value: function (e, t) {
                    for (var n = 0; n < e.length; n++) {
                        var i = e[n];
                        i.f = 0, i.g = 0, i.h = 0, i.cost = Laya.Vector3.distanceSquared(t, i.centroid), i.visited = !1, i.closed = !1, i.parent = null
                    }
                }
            }, {
                key: "cleanUp",
                value: function (e) {
                    for (var t = 0; t < e.length; t++) {
                        var n = e[t];
                        delete n.f, delete n.g, delete n.h, delete n.cost, delete n.visited, delete n.closed, delete n.parent
                    }
                }
            }, {
                key: "heap",
                value: function () {
                    return new Bn(function (e) {
                        return e.f
                    })
                }
            }, {
                key: "heuristic",
                value: function (e, t) {
                    return Laya.Vector3.distanceSquared(e, t)
                }
            }, {
                key: "neighbours",
                value: function (e, t) {
                    for (var n = [], i = 0; i < t.neighbours.length; i++) n.push(e[t.neighbours[i]]);
                    return n
                }
            }, {
                key: "search",
                value: function (e, t, n, i) {
                    AStar.init(e, i);
                    var a = AStar.heap();
                    for (a.push(t); a.size() > 0;) {
                        var o = a.pop();
                        if (o === n) {
                            for (var s = o, r = []; s.parent;) r.push(s), s = s.parent;
                            return this.cleanUp(r), r.reverse()
                        }
                        o.closed = !0;
                        for (var l = AStar.neighbours(e, o), u = 0, h = l.length; u < h; u++) {
                            var c = l[u];
                            if (!c.closed) {
                                var d = o.g + c.cost,
                                    f = c.visited;
                                (!f || d < c.g) && (c.visited = !0, c.parent = o, !c.centroid || n.centroid, c.h = c.h || AStar.heuristic(c.centroid, n.centroid), c.g = d, c.f = c.g + c.h, f ? a.rescoreElement(c) : a.push(c))
                            }
                        }
                    }
                    return []
                }
            }]), AStar
        }(),
        Vn = Laya.Vector3,
        zn = function () {
            function Channel() {
                _classCallCheck(this, Channel), this.portals = [], this.path = []
            }
            return _createClass(Channel, [{
                key: "push",
                value: function (e, t) {
                    void 0 === t && (t = e), this.portals.push({
                        left: e,
                        right: t
                    })
                }
            }, {
                key: "triarea2",
                value: function (e, t, n) {
                    var i = t.x - e.x,
                        a = t.z - e.z;
                    return (n.x - e.x) * a - i * (n.z - e.z)
                }
            }, {
                key: "vequal",
                value: function (e, t) {
                    return Vn.distanceSquared(e, t) < 1e-5
                }
            }, {
                key: "stringPull",
                value: function () {
                    var e, t, n, i = this.portals,
                        a = [],
                        o = 0,
                        s = 0,
                        r = 0;
                    e = i[0].left, t = i[0].left, n = i[0].right, a.push(e);
                    for (var l = 1; l < i.length; l++) {
                        var u = i[l].left,
                            h = i[l].right;
                        if (this.triarea2(e, n, h) <= 0) {
                            if (!(this.vequal(e, n) || this.triarea2(e, t, h) > 0)) {
                                a.push(t), t = e = t, n = e, s = o = s, r = o, l = o;
                                continue
                            }
                            n = h, r = l
                        }
                        if (this.triarea2(e, t, u) >= 0) {
                            if (!(this.vequal(e, t) || this.triarea2(e, n, u) < 0)) {
                                a.push(n), t = e = n, n = e, s = o = r, r = o, l = o;
                                continue
                            }
                            t = u, s = l
                        }
                    }
                    return 0 !== a.length && this.vequal(a[a.length - 1], i[i.length - 1].left) || a.push(i[i.length - 1].left), this.path = a, a
                }
            }]), Channel
        }(),
        Fn = Laya.Vector3,
        Hn = function () {
            function Patroll() {
                _classCallCheck(this, Patroll)
            }
            return _createClass(Patroll, null, [{
                key: "computeCentroids",
                value: function (e) {
                    for (var t = 0, n = e.faces.length; t < n; t++) {
                        var i = e.faces[t];
                        i.centroid = new Fn(0, 0, 0), Fn.add(i.centroid, e.vertices[i.a], i.centroid), Fn.add(i.centroid, e.vertices[i.b], i.centroid), Fn.add(i.centroid, e.vertices[i.c], i.centroid), Fn.scale(i.centroid, 1 / 3, i.centroid)
                    }
                }
            }, {
                key: "buildNavigationMesh",
                value: function (e) {
                    return Patroll.computeCentroids(e), e.mergeVertices(), Patroll.buildPolygonsFromGeometry(e)
                }
            }, {
                key: "buildPolygonsFromGeometry",
                value: function (e) {
                    for (var t = [], n = e.vertices, i = 0, a = e.faces.length; i < a; i++) {
                        var o = e.faces[i];
                        t.push({
                            id: Patroll.polygonId++,
                            vertexIds: [o.a, o.b, o.c],
                            centroid: o.centroid,
                            normal: o.normal,
                            neighbours: []
                        })
                    }
                    for (var s = {
                            polygons: t,
                            vertices: n
                        }, r = 0, l = t.length; r < l; r++) {
                        var u = t[r];
                        Patroll.buildPolygonNeighbours(u, s)
                    }
                    return s
                }
            }, {
                key: "buildPolygonNeighbours",
                value: function (e, t) {
                    e.neighbours = [];
                    for (var n = 0, i = t.polygons.length; n < i; n++) {
                        if (e !== t.polygons[n])
                            if (!(Fn.distanceSquared(e.centroid, t.polygons[n].centroid) > 1e4)) Patroll.arrayIntersect(e.vertexIds, t.polygons[n].vertexIds).length >= 2 && e.neighbours.push(t.polygons[n])
                    }
                }
            }, {
                key: "arrayIntersect",
                value: function () {
                    for (var e, t, n, i, a, o, s = [], r = {}, l = arguments.length, u = new Array(l), h = 0; h < l; h++) u[h] = arguments[h];
                    for (o = u.length - 1, n = u[0].length, t = 0, e = 0; e <= o; e++)(i = u[e].length) < n && (t = e, n = i);
                    for (e = 0; e <= o; e++) {
                        a = u[i = e === t ? 0 : e || t].length;
                        for (var c = 0; c < a; c++) {
                            var d = u[i][c];
                            r[d] === e - 1 ? e === o ? (s.push(d), r[d] = 0) : r[d] = e : 0 === e && (r[d] = 0)
                        }
                    }
                    return s
                }
            }, {
                key: "groupNavMesh",
                value: function (e) {
                    for (var t = {
                            vertices: null,
                            groups: null
                        }, n = 0, i = e.vertices.length; n < i; n++) {
                        var a = e.vertices[n];
                        a.x = Patroll.roundNumber(a.x, 2), a.y = Patroll.roundNumber(a.y, 2), a.z = Patroll.roundNumber(a.z, 2)
                    }
                    t.vertices = e.vertices;
                    var o = Patroll.buildPolygonGroups(e);
                    t.groups = [];
                    for (var s = function (e, t) {
                            for (var n = 0; n < e.length; n++)
                                if (t === e[n]) return n
                        }, r = 0, l = o.length; r < l; r++) {
                        for (var u = o[r], h = [], c = 0, d = u.length; c < d; c++) {
                            for (var f = u[c], _ = [], y = [], p = 0, g = f.neighbours.length; p < g; p++) {
                                var v = f.neighbours[p];
                                _.push(s(u, v)), y.push(Patroll.getSharedVerticesInOrder(f, v))
                            }
                            f.centroid.x = Patroll.roundNumber(f.centroid.x, 2), f.centroid.y = Patroll.roundNumber(f.centroid.y, 2), f.centroid.z = Patroll.roundNumber(f.centroid.z, 2), h.push({
                                id: s(u, f),
                                neighbours: _,
                                vertexIds: f.vertexIds,
                                centroid: f.centroid,
                                portals: y
                            })
                        }
                        t.groups.push(h)
                    }
                    return t
                }
            }, {
                key: "getSharedVerticesInOrder",
                value: function (e, t) {
                    for (var n = e.vertexIds, i = t.vertexIds, a = [], o = 0, s = n.length; o < s; o++) {
                        var r = n[o];
                        i.indexOf(r) > -1 && a.push(r)
                    }
                    if (a.length < 2) return [];
                    a.indexOf(n[0]) > -1 && a.indexOf(n[n.length - 1]) > -1 && n.push(n.shift()), a.indexOf(i[0]) > -1 && a.indexOf(i[i.length - 1]) > -1 && i.push(i.shift()), a = [];
                    for (var l = 0, u = n.length; l < u; l++) {
                        var h = n[l];
                        i.indexOf(h) > -1 && a.push(h)
                    }
                    return a
                }
            }, {
                key: "buildPolygonGroups",
                value: function (e) {
                    var t = e.polygons;
                    e.vertices;
                    var n = [],
                        i = 0;

                    function spreadGroupId(e) {
                        for (var t = 0, n = e.neighbours.length; t < n; t++) {
                            var i = e.neighbours[t];
                            null == i.group && (i.group = e.group, spreadGroupId(i))
                        }
                    }
                    for (var a = 0, o = t.length; a < o; a++) {
                        var s = t[a];
                        null == s.group && (s.group = i++, spreadGroupId(s)), n[s.group] || (n[s.group] = []), n[s.group].push(s)
                    }
                    return n
                }
            }, {
                key: "roundNumber",
                value: function (e, t) {
                    var n = new Number(e + "").toFixed(t);
                    return parseFloat(n)
                }
            }]), Patroll
        }();
    Hn.polygonId = 0;
    var jn = Laya.Vector3,
        Wn = function () {
            function NavMesh() {
                _classCallCheck(this, NavMesh)
            }
            return _createClass(NavMesh, [{
                key: "buildNodes",
                value: function (e) {
                    var t = Hn.buildNavigationMesh(e);
                    return Hn.groupNavMesh(t)
                }
            }, {
                key: "setZoneData",
                value: function (e, t) {
                    NavMesh.zoneNodes[e] = t
                }
            }, {
                key: "getGroup",
                value: function (e, t) {
                    if (!NavMesh.zoneNodes[e]) return null;
                    for (var n = null, i = Math.pow(50, 2), a = 0, o = NavMesh.zoneNodes[e].groups.length; a < o; a++)
                        for (var s = NavMesh.zoneNodes[e].groups[a], r = 0, l = s.length; r < l; r++) {
                            var u = s[r],
                                h = jn.distanceSquared(u.centroid, t);
                            h < i && (n = a, i = h)
                        }
                    return n
                }
            }, {
                key: "findPath",
                value: function (e, t, n, i) {
                    for (var a = NavMesh.zoneNodes[n].groups[i], o = NavMesh.zoneNodes[n].vertices, s = null, r = 0, l = a.length; r < l; r++) {
                        var u = a[r];
                        if (NavMesh.isVectorInPolygon(e, u, o)) {
                            s = u;
                            break
                        }
                    }
                    for (var h = null, c = 0, d = a.length; c < d; c++) {
                        var f = a[c];
                        if (NavMesh.isVectorInPolygon(t, f, o)) {
                            h = f;
                            break
                        }
                    }
                    if (!s || !h) return [e, t];
                    var _ = Gn.search(a, s, h, e),
                        y = function (e, t) {
                            for (var n = 0; n < e.neighbours.length; n++)
                                if (e.neighbours[n] === t.id) return e.portals[n]
                        },
                        p = new zn;
                    p.push(e);
                    for (var g = 0; g < _.length; g++) {
                        var v = _[g],
                            m = _[g + 1];
                        if (m) {
                            var C = y(v, m);
                            p.push(o[C[0]], o[C[1]])
                        }
                    }
                    p.push(t), p.stringPull();
                    for (var k = [], S = 0, I = p.path.length; S < I; S++) {
                        var b = p.path[S],
                            L = new jn(b.x, b.y, b.z);
                        k.push(L)
                    }
                    return k
                }
            }], [{
                key: "isVectorInPolygon",
                value: function (e, t, n) {
                    t.centroid;
                    for (var i = 1e5, a = -1e5, o = [], s = 0, r = t.vertexIds.length; s < r; s++) {
                        var l = t.vertexIds[s];
                        i = Math.min(n[l].y, i), a = Math.max(n[l].y, a), o.push(n[l])
                    }
                    return !!(e.y < a + .5 && e.y > i - .5 && this.isPointInPoly(o, e))
                }
            }, {
                key: "isPointInPoly",
                value: function (e, t) {
                    for (var n = !1, i = -1, a = e.length, o = a - 1; ++i < a; o = i)(e[i].z <= t.z && t.z < e[o].z || e[o].z <= t.z && t.z < e[i].z) && t.x < (e[o].x - e[i].x) * (t.z - e[i].z) / (e[o].z - e[i].z) + e[i].x && (n = !n);
                    return n
                }
            }]), NavMesh
        }();
    Wn.zoneNodes = {};
    var $n = function () {
        function ObstaclePolygonWrap(e) {
            _classCallCheck(this, ObstaclePolygonWrap), this.maxX = -1e6, this.minX = 1e5, this.maxY = -1e6, this.minY = 1e6, this.debug = !1, this.id = ObstaclePolygonWrap.index++, this.points = e;
            for (var t = 0; t < e.length; t++) {
                var n = e[t];
                this.maxX = Math.max(n.x, this.maxX), this.minX = Math.min(n.x, this.minX), this.maxY = Math.max(n.y, this.maxY), this.minY = Math.min(n.y, this.minY)
            }
        }
        return _createClass(ObstaclePolygonWrap, [{
            key: "FastTest",
            value: function (e) {
                var t = e.x >= this.minX && e.x <= this.maxX && e.y >= this.minY && e.y <= this.maxY;
                return this.debug && console.log(this.minX, e.x, this.maxX, "", this.minY, e.y, this.maxY, t), t
            }
        }]), ObstaclePolygonWrap
    }();
    $n.index = 0;
    var Kn, Yn = function (e) {
            function ObstaclePolygonManager() {
                var e;
                return _classCallCheck(this, ObstaclePolygonManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(ObstaclePolygonManager).apply(this, arguments))).mapPolygon = [], e.campsPolygon = [], e.polygons = new Map, e.polygonsByGroup = new Map, e
            }
            return _inherits(ObstaclePolygonManager, Rt), _createClass(ObstaclePolygonManager, [{
                key: "onAwake",
                value: function () {
                    ObstaclePolygonManager._inst = this;
                    var e = this.Find("Edge");
                    if (e)
                        for (var t = 0; t < e.numChildren; t++) {
                            var n = e.getChildAt(t);
                            this.mapPolygon.push(new Laya.Vector2(n.transform.position.x, n.transform.position.z))
                        }
                    if (e = this.Find("Nav"))
                        for (t = 0; t < e.numChildren; t++) {
                            n = e.getChildAt(t);
                            this.campsPolygon.push(new Laya.Vector2(n.transform.position.x, n.transform.position.z))
                        }
                    N.getInst().on(Et.RebuildNavMesh, this, this.ResetNavMesh), this.resetNavMesh()
                }
            }, {
                key: "onStart",
                value: function () {
                    this.resetNavMesh()
                }
            }, {
                key: "ResetNavMesh",
                value: function () {
                    Laya.timer.frameOnce(2, this, this.resetNavMesh, null, !0)
                }
            }, {
                key: "resetNavMesh",
                value: function () {
                    if (0 != this.campsPolygon.length) {
                        var e, t = new poly2tri.SweepContext(this.campsPolygon, {
                                cloneArrays: !0
                            }),
                            n = this.polygonsByGroup.get("camps");
                        n && n.forEach(function (n, i) {
                            e = [], n.points.forEach(function (t) {
                                e.push(t)
                            }), t.addHole(e)
                        });
                        var i = t.points_,
                            a = t.triangulate().getTriangles(),
                            o = new Nn;
                        i.forEach(function (e) {
                            o.vertices.push(new Laya.Vector3(e.x, 0, e.y))
                        }), a.forEach(function (e) {
                            var t = e.getPoints(),
                                n = new On(i.indexOf(t[2]), i.indexOf(t[1]), i.indexOf(t[0]));
                            o.faces.push(n)
                        }), this.navMesh_camps = this.navMesh_camps || new Wn;
                        var s = this.navMesh_camps.buildNodes(o);
                        this.navMesh_camps.setZoneData("camps", s), N.getInst().event(Et.ReFindPath)
                    }
                }
            }, {
                key: "FindPath",
                value: function (e, t) {
                    return null == this.navMesh_camps ? [e, t] : this.navMesh_camps.findPath(e, t, "camps", 0) || []
                }
            }, {
                key: "AddPolygon",
                value: function (e, t) {
                    this.polygons.set(e.id, e), this.polygonsByGroup.has(t) || this.polygonsByGroup.set(t, new Set), this.polygonsByGroup.get(t).add(e), this.ResetNavMesh()
                }
            }, {
                key: "RemovePolygon",
                value: function (e) {
                    e instanceof $n ? this.polygons.delete(e.id) : this.polygons.delete(e);
                    var t = !0,
                        n = !1,
                        i = void 0;
                    try {
                        for (var a, o = this.polygonsByGroup[Symbol.iterator](); !(t = (a = o.next()).done); t = !0) {
                            var s = _slicedToArray(a.value, 2);
                            s[0];
                            s[1].delete(e)
                        }
                    } catch (e) {
                        n = !0, i = e
                    } finally {
                        try {
                            t || null == o.return || o.return()
                        } finally {
                            if (n) throw i
                        }
                    }
                    this.ResetNavMesh()
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("ObstaclePolygonManager", ObstaclePolygonManager)
                }
            }, {
                key: "inst",
                get: function () {
                    return this._inst
                }
            }]), ObstaclePolygonManager
        }(),
        Xn = function () {
            function CubicCurve(e, t, n, i) {
                _classCallCheck(this, CubicCurve), this.p1 = e, this.p2 = t, this.p3 = n, this.p4 = i
            }
            return _createClass(CubicCurve, [{
                key: "SetPos",
                value: function (e, t, n, i) {
                    this.p1 = e, this.p2 = t, this.p3 = n, this.p4 = i
                }
            }, {
                key: "GetPos",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                        n = Math.pow(1 - e, 3),
                        i = e * (1 - e) * (1 - e) * 3,
                        a = (1 - e) * e * e * 3,
                        o = Math.pow(e, 3),
                        s = n * this.p1.x + this.p2.x * i + this.p3.x * a + this.p4.x * o,
                        r = n * this.p1.y + this.p2.y * i + this.p3.y * a + this.p4.y * o,
                        l = n * this.p1.z + this.p2.z * i + this.p3.z * a + this.p4.z * o;
                    return (t = t || new Laya.Vector3).setValue(s, r, l), t
                }
            }]), CubicCurve
        }(),
        qn = new Laya.Vector3,
        Jn = new Laya.Vector3,
        Zn = function (e) {
            function Pizza() {
                var e;
                return _classCallCheck(this, Pizza), (e = _possibleConstructorReturn(this, _getPrototypeOf(Pizza).apply(this, arguments))).Index = 0, e.audio = !1, e.targetR = new Laya.Quaternion, e.startCtrl = new Laya.Vector3, e.flyTime = 0, e.flyTotalTime = 400, e.attachPlayer = !1, e
            }
            return _inherits(Pizza, Rt), _createClass(Pizza, [{
                key: "SpwanMove",
                value: function (e) {
                    Laya.Tween.to(this.transform.position, e, 100, Laya.Ease.linearInOut).update = Laya.Handler.create(this, this.UpdatePosition, null, !1)
                }
            }, {
                key: "SpwanToBigGuy",
                value: function (e) {
                    Laya.Tween.to(this.transform.position, e, 300, Laya.Ease.linearInOut, Laya.Handler.create(this, this._onSpwanToBigGuyEnd)).update = Laya.Handler.create(this, this.UpdatePosition, null, !1)
                }
            }, {
                key: "_onSpwanToBigGuyEnd",
                value: function () {
                    null == this.sp || this.sp.destroyed || (this.sp.destroy(!0), N.getInst().event(Et.PizzaAttouchBigGuy))
                }
            }, {
                key: "FlyToZone",
                value: function (e, t) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    this.attachPlayer = !1, Laya.Tween.clearAll(this.transform.position);
                    var i = e.clone();
                    i.y += 2, this._flyToZone(i, e, t, n)
                }
            }, {
                key: "_flyToZone",
                value: function (e, t, n, i) {
                    this.flyTotalTime = n, this.flyTime = 0, this.startCtrl.setValue(this.transform.position.x, this.transform.position.y + 2, this.transform.position.z), null == this.curve ? this.curve = new Xn(this.transform.position, this.startCtrl, e, t) : this.curve.SetPos(this.transform.position, this.startCtrl, e, t), Laya.timer.frameOnce(1, this, this.updateFlyToZone, [i])
                }
            }, {
                key: "updateFlyToZone",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    if (this.sp.destroyed) Laya.timer.clearAll(this);
                    else {
                        this.flyTime += F.deltaTime;
                        var t = Math.min(1, this.flyTime / this.flyTotalTime);
                        this.curve.GetPos(t, qn), this.transform.position = qn, Laya.Quaternion.lerp(this.transform.rotation, this.targetR, .2, this.transform.rotation), this.transform.rotation = this.transform.rotation, this.flyTime >= this.flyTotalTime ? (this.transform.rotation = this.targetR, e && this.sp.destroy(!0), this.audio && G.inst.playSound("popsounds"), this.audio = !1) : Laya.timer.frameOnce(1, this, this.updateFlyToZone, [e])
                    }
                }
            }, {
                key: "FlyToPlayer",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    this.Index = pi.getInst().player.pizzaCount, pi.getInst().player.pizzas.push(this), this.attachPlayer = !1, Laya.Tween.clearAll(this.transform.position);
                    var t = this.sp.transform.position.clone();
                    t.y += 2, this._flyToPlayer(this.transform.position.clone(), t, 200, e)
                }
            }, {
                key: "_flyToPlayer",
                value: function (e, t, n, i) {
                    this.flyTotalTime = n, this.flyTime = 0, pi.getInst().player.GetPizzaTargetPos(this.Index, Jn, qn), null == this.curve ? this.curve = new Xn(e, t, qn, Jn) : this.curve.SetPos(e, t, qn, Jn), Laya.timer.frameOnce(1, this, this.updateFly, [i])
                }
            }, {
                key: "updateFly",
                value: function (e) {
                    if (this.sp.destroyed) Laya.timer.clearAll(this);
                    else {
                        this.flyTime += F.deltaTime;
                        var t = Math.min(1, this.flyTime / this.flyTotalTime);
                        pi.getInst().player.GetPizzaTargetPos(this.Index, Jn, qn), this.curve.p3 = qn, this.curve.p4 = Jn, this.curve.GetPos(t, qn), this.transform.position = qn, Laya.Vector3.lerp(this.transform.localRotationEuler, F.Vector3Zero, .2, qn), this.transform.localRotationEuler = qn, this.flyTime >= this.flyTotalTime ? (this.transform.localRotationEuler = F.Vector3Zero, this.attachPlayer = !0, e && this.sp.destroy(!0), this.audio && G.inst.playSound("popsounds"), this.audio = !1) : Laya.timer.frameOnce(1, this, this.updateFly, [e])
                    }
                }
            }, {
                key: "FlyToWorker",
                value: function (e) {
                    this.attachPlayer = !1, Laya.Tween.clearAll(this.transform.position);
                    var t = this.sp.transform.position.clone();
                    t.y += 2, this.SwitchParent(e.sp), this._flyToWorker(this.transform.position.clone(), t, 200, !1, e)
                }
            }, {
                key: "_flyToWorker",
                value: function (e, t, n, i, a) {
                    this.flyTotalTime = n, this.flyTime = 0, a.GetWoodTargetPos(this.Index, Jn, qn), null == this.curve ? this.curve = new Xn(e, t, qn, Jn) : this.curve.SetPos(e, t, qn, Jn), Laya.timer.frameOnce(1, this, this.updateFly2Worker, [i, a])
                }
            }, {
                key: "updateFly2Worker",
                value: function (e, t) {
                    if (this.sp.destroyed) Laya.timer.clearAll(this);
                    else {
                        this.flyTime += F.deltaTime;
                        var n = Math.min(1, this.flyTime / this.flyTotalTime);
                        t.GetWoodTargetPos(this.Index, Jn, qn), this.curve.p3 = qn, this.curve.p4 = Jn, this.curve.GetPos(n, qn), this.transform.position = qn, Laya.Vector3.lerp(this.transform.localRotationEuler, F.Vector3Zero, .2, qn), this.transform.localRotationEuler = qn, this.flyTime >= this.flyTotalTime ? (this.transform.localRotationEuler = F.Vector3Zero, e && this.sp.destroy(!0), this.audio && G.inst.playSound("popsounds"), this.audio = !1) : Laya.timer.frameOnce(1, this, this.updateFly2Worker, [e, t])
                    }
                }
            }, {
                key: "onUpdate",
                value: function () {
                    if (this.attachPlayer) {
                        pi.getInst().player.GetPizzaTargetPos(this.Index, Jn, qn);
                        var e = Laya.Ease.circOut(this.Index, .9, -.85, 35);
                        Laya.Vector3.lerp(this.transform.position, Jn, e, qn), this.transform.position = qn, this.transform.rotationEuler.y = pi.getInst().player.pizza.transform.rotationEuler.y, this.transform.rotationEuler = this.transform.rotationEuler
                    }
                }
            }, {
                key: "onReset",
                value: function () {
                    this.attachPlayer = !1
                }
            }, {
                key: "onDestroy",
                value: function () {
                    this.ClearAsycFunc()
                }
            }]), Pizza
        }(),
        Qn = function (e) {
            function PizzaManager() {
                return _classCallCheck(this, PizzaManager), _possibleConstructorReturn(this, _getPrototypeOf(PizzaManager).apply(this, arguments))
            }
            return _inherits(PizzaManager, Rt), _createClass(PizzaManager, [{
                key: "onAwake",
                value: function () {
                    PizzaManager.inst = this
                }
            }, {
                key: "onDestroy",
                value: function () {
                    PizzaManager.inst = null
                }
            }, {
                key: "CreatePizza",
                value: function () {
                    var e = qt.getInst().GetPrefab(Ot.Pizza),
                        t = Laya.Sprite3D.instantiate(e).addComponent(Zn);
                    return this.sp.addChild(t.sp), t
                }
            }]), PizzaManager
        }(),
        ei = new Laya.Vector3,
        ti = new Laya.Vector3;
    ! function (e) {
        e[e.TakePizza = 0] = "TakePizza", e[e.CostPizza = 1] = "CostPizza"
    }(Kn || (Kn = {}));
    var ni, ii = function (e) {
            function Supporter() {
                var e;
                return _classCallCheck(this, Supporter), (e = _possibleConstructorReturn(this, _getPrototypeOf(Supporter).apply(this, arguments))).state = Kn.TakePizza, e.velocity = new Laya.Vector3, e.moveDis = 0, e.stepTargetDis = 0, e.pizzas = [], e.useNav = !0, e.targetY = 0, e.takeWaitTime = 0, e
            }
            return _inherits(Supporter, Rt), _createClass(Supporter, [{
                key: "onStart",
                value: function () {
                    this._ani = this.sp.getComponent(Laya.Animator), this.pizzaNode = this.Find("pizzaNode"), this.viewNode = this.Find("View"), Laya.timer.once(1e3, this, this.GoToTakePizza)
                }
            }, {
                key: "onDestroy",
                value: function () {
                    this.ClearAsycFunc()
                }
            }, {
                key: "onUpdate",
                value: function () {
                    if (null != this.targets) {
                        0 == this.pizzas.length ? this.PlayAni("Slow Run") : this.PlayAni("Running");
                        var e = ti,
                            t = 1;
                        if (this.useNav) {
                            this.transform.localRotationEulerY = Laya.MathUtil.lerp(this.transform.localRotationEulerY, this.targetY, 4 * F.deltaTimeSec);
                            var n = Math.abs(this.targetY - this.transform.localRotationEulerY);
                            n > 90 ? t = 0 : n > 20 && (t = (n - 20) / 70, t = 1 - Math.pow(t, 2))
                        }
                        Laya.Vector3.scale(this.velocity, F.deltaTimeSec * t, e);
                        var i = Laya.Vector3.scalarLength(e),
                            a = !1,
                            o = 0;
                        0 == this.targets.length && (o = .5), this.moveDis + i + o > this.stepTargetDis ? (i = this.stepTargetDis - this.moveDis, Laya.Vector3.normalize(e, e), Laya.Vector3.scale(e, i, e), a = !0, this.moveDis = 0) : this.moveDis += i, Laya.Vector3.add(this.transform.position, e, e), this.transform.position = e, a && this.setTarget()
                    } else 0 == this.pizzas.length ? this.PlayAni("Idle") : this.PlayAni("Carrying")
                }
            }, {
                key: "SetPath",
                value: function (e) {
                    this.targets = null == e ? [] : _toConsumableArray(e), this.setTarget()
                }
            }, {
                key: "setTarget",
                value: function () {
                    if (null != this.targets) {
                        if (0 == this.targets.length) return this.targets = null, void this.onMoveEnd();
                        for (var e = this.targets.shift(); Laya.Vector3.distanceSquared(e, this.transform.position) < .5;) {
                            if (0 == this.targets.length) return this.targets = null, void this.onMoveEnd();
                            e = this.targets.shift()
                        }
                        if (this.moveDis = 0, this.stepTargetDis = Laya.Vector3.distance(this.transform.position, e), Laya.Vector3.subtract(e, this.transform.position, this.velocity), this.velocity.y = 0, Laya.Vector3.normalize(this.velocity, this.velocity), Laya.Vector3.scale(this.velocity, Wt.inst.ShopSupportSpeed, this.velocity), this.useNav) {
                            Laya.Vector3.subtract(e, this.transform.position, ei), Laya.Vector3.scale(ei, -1, ei), Laya.Vector3.add(this.transform.position, ei, ei);
                            var t = this.transform.localRotationEulerY;
                            this.transform.lookAt(ei, F.UP), this.transform.localRotationEulerX = this.transform.localRotationEulerZ = 0, this.targetY = this.transform.localRotationEulerY, this.transform.localRotationEulerY = t
                        }
                    }
                }
            }, {
                key: "onMoveEnd",
                value: function () {
                    switch (this.state) {
                        case Kn.TakePizza:
                            this.TakePizza();
                            break;
                        case Kn.CostPizza:
                            this.CostPizza()
                    }
                }
            }, {
                key: "GoToTakePizza",
                value: function () {
                    if (this.state = Kn.TakePizza, null != ai.inst && 0 != ai.inst.pizzaMakers.length) {
                        var e = ai.inst.pizzaMakers.filter(function (e) {
                                return !e.crazyMode
                            }),
                            t = this.pm = M.rand(e);
                        if (this.takeWaitTime = 0, this.useNav) {
                            var n = Yn.inst.FindPath(this.transform.position, t.WorkerPoint.transform.position);
                            n[n.length - 1].z += Xt.RandomFloat(-1, 1), this.SetPath(n)
                        } else this.SetPath([this.transform.position, t.WorkerPoint.transform.position])
                    } else Laya.timer.once(1e3, this, this.GoToTakePizza)
                }
            }, {
                key: "TakePizza",
                value: function () {
                    if (this.pm.Count > 0) {
                        var e = this.pm.RespwanPizza();
                        if (e.Index = this.pizzas.length, e.FlyToWorker(this), this.pizzas.push(e), this.pizzas.length >= Wt.inst.ShopSupprotStackSize) return void this.GoToCostPizza()
                    }
                    this.takeWaitTime += F.deltaTime, this.takeWaitTime > 500 ? 0 == this.pizzas.length ? this.GoToTakePizza() : this.GoToCostPizza() : Laya.timer.once(100, this, this.TakePizza)
                }
            }, {
                key: "GoToCostPizza",
                value: function () {
                    if (this.state = Kn.CostPizza, null != ai.inst && 0 != ai.inst.pizzaCosters.length) {
                        var e = ai.inst.pizzaCosters.filter(function (e) {
                            return e.pizzas.length < 50
                        });
                        if (this.coster = M.rand(e), null != this.coster)
                            if (this.useNav) {
                                var t = Yn.inst.FindPath(this.transform.position, this.coster.WorkerPoint.transform.position);
                                t[t.length - 1].z += Xt.RandomFloat(-1, 1), this.SetPath(t)
                            } else this.SetPath([this.transform.position, this.coster.WorkerPoint.transform.position]);
                        else Laya.timer.once(1e3, this, this.GoToCostPizza)
                    } else Laya.timer.once(1e3, this, this.GoToCostPizza)
                }
            }, {
                key: "CostPizza",
                value: function () {
                    this.pizzas.length > 0 ? (this.coster.GetPizzaFromX(this).SwitchParent(Qn.inst.sp), Laya.timer.once(100, this, this.CostPizza)) : Laya.timer.once(Xt.RandomInt(1e3, 2e3), this, this.GoToTakePizza)
                }
            }, {
                key: "GetWoodTargetPos",
                value: function (e, t, n) {
                    this.pizzaNode.transform.getUp(t), t.cloneTo(n), Laya.Vector3.normalize(n, n), this.useNav ? Laya.Vector3.scale(n, .2 * e, n) : Laya.Vector3.scale(n, .2 * -e, n), Laya.Vector3.add(this.pizzaNode.transform.position, n, t), t.cloneTo(n), this.useNav ? n.y += 2 : n.y -= 2
                }
            }, {
                key: "_parse",
                value: function (e) {
                    this.useNav = "1" == e.fn_nav
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.useNav = this.useNav
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("Supporter", Supporter)
                }
            }]), Supporter
        }(),
        ai = ni = function (t) {
            function MapNode() {
                var e;
                return _classCallCheck(this, MapNode), (e = _possibleConstructorReturn(this, _getPrototypeOf(MapNode).apply(this, arguments))).pizzaMakers = [], e.boxMakers = [], e.singleTables = [], e.pizzaCosters = [], e.supporters = [], e.unlockTiles = [], e.unlockTags = [], e
            }
            return _inherits(MapNode, Rt), _createClass(MapNode, [{
                key: "onAwake",
                value: function () {
                    var e = this;
                    ni.inst = this, N.getInst().on(Et.UpdateSupport, this, this.loadSupporter), N.getInst().on(Et.UnlockChange, this, this.onUnlockChange), N.getInst().on(Et.StartCrazyMode, this, this.CrazyMode);
                    var t = this.Find("LockTile");
                    this.unlockTiles.push(t.getChildAt(0), t.getChildAt(2)), this.unlockTags.push(t.getChildAt(1), t.getChildAt(3)), this.ArrowHeart = new Laya.Sprite3D("heart"), this.sp.addChild(this.ArrowHeart), this.ArrowHeart.active = !1, qt.getInst().LoadPrefabByName(Ot.ArrowHeart).then(function (t) {
                        if (null != e.sp && !e.sp.destroyed) {
                            var n = Laya.Sprite3D.instantiate(t);
                            e.ArrowHeart.addChild(n), n.transform.localPosition = F.Vector3Zero
                        }
                    })
                }
            }, {
                key: "onStart",
                value: function () {
                    this.loadSupporter(), this.loadPizzaMakers(!0), this.loadSingleTable(!0), this.loadQuadTable(!0), this.loadPackers(!0), this.loadHR(!0), this.loadUP(!0), this.loadBig(!0), this.updateUnlock(), this.checkSupport(), this.onUnlockChange()
                }
            }, {
                key: "onDestroy",
                value: function () {
                    ni.inst = null, this.ClearAsycFunc()
                }
            }, {
                key: "startMoneyStackAD",
                value: function () {
                    var e = this;
                    Wt.inst.MoneyTimes >= 2 || (Wt.inst.MoneyTimes++, qt.getInst().LoadPrefabByName(Ot.MoneyAD).then(function (t) {
                        if (!e.Invalid) {
                            var n = Laya.Sprite3D.instantiate(t);
                            e.sp.addChild(n), n.transform.position = e.MoneyADPos.transform.position
                        }
                    }), Laya.timer.once(6e4, this, this.startMoneyStackAD))
                }
            }, {
                key: "onUnlockChange",
                value: function () {
                    var e = this;
                    if (!(this.PizzzMakers.filter(function (t, n) {
                            return t.unlockLevel == e.UnlockLevel && (-1 != t.unlockCoin && t.unlockCoin > Wt.inst.ShopPizzaMakerProgress[n])
                        }).length > 0) && !(this.SingleTables.filter(function (t, n) {
                            if (t.unlockLevel == e.UnlockLevel) {
                                if (-1 == t.unlockCoin) return !1;
                                if (t.unlockCoin > Wt.inst.ShopSingleTableProgress[n]) return !0
                            }
                            return !1
                        }).length > 0 || this.QuadTables.filter(function (t, n) {
                            if (t.unlockLevel == e.UnlockLevel) {
                                if (-1 == t.unlockCoin) return !1;
                                if (t.unlockCoin > Wt.inst.ShopQuadTableProgress[n]) return !0
                            }
                            return !1
                        }).length > 0)) {
                        var t = this.HRRoom;
                        if (!(t.unlockLevel == this.UnlockLevel && t.unlockCoin > Wt.inst.ShopHrProgress)) {
                            var n = Nt.getInst().upgradeRoom[this.ShopIndex];
                            if (!(n.unlockLevel == this.UnlockLevel && n.unlockCoin > Wt.inst.ShopUpgradeRoomProgress)) {
                                var i = Nt.getInst().bigTable[this.ShopIndex];
                                if (!(i.unlockLevel == this.UnlockLevel && i.unlockCoin > Wt.inst.ShopBigTableProgress)) this.Packers.filter(function (t, n) {
                                    if (t.unlockLevel == e.UnlockLevel) return -1 != t.unlockCoin && t.unlockCoin > Wt.inst.ShopPackerProgress[n]
                                }).length > 0 || (Wt.inst.ShopUnlockLevel++, this.loadPizzaMakers(), this.loadSingleTable(), this.loadQuadTable(), this.loadPackers(), this.loadHR(), this.loadUP(), this.loadBig(), this.updateUnlock(), this.checkSupport())
                            }
                        }
                    }
                }
            }, {
                key: "loadPizzaMakers",
                value: function () {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    qt.getInst().LoadPrefabByName(Ot.PizzaMaker).then(function (n) {
                        if (!e.Invalid)
                            for (var i = e.Find("PizzaMaker"), a = 0; a < i.numChildren; a++) {
                                var o = i.getChildAt(a),
                                    s = e.PizzzMakers[a];
                                Wt.inst.ShopPizzaMakerProgress[a] = Wt.inst.ShopPizzaMakerProgress[a] || 0;
                                var r = Wt.inst.ShopPizzaMakerProgress[a];
                                s.unlockLevel < e.UnlockLevel || s.unlockLevel === e.UnlockLevel && -1 !== s.unlockCoin && s.unlockCoin <= r ? t && e._loadModel(o, Ot.PizzaMaker) : s.unlockLevel == e.UnlockLevel && (-1 == s.unlockCoin ? function () {
                                    var t = e._loadADTag(o),
                                        n = o,
                                        i = a;
                                    t.FullCB = function () {
                                        lt.inst.sendReport("视频解锁披萨机" + lt.inst.getNextUnlockId(0)), Wt.inst.ShopPizzaMakerProgress[i] = -1, e._loadModel(n, Ot.PizzaMaker)
                                    }
                                }() : function () {
                                    var t = e._loadMoneyTag(o);
                                    t.Max = s.unlockCoin, t.Progress = r;
                                    var n = o,
                                        i = a;
                                    t.ProgressCB = function (e) {
                                        Wt.inst.ShopPizzaMakerProgress[i] = e
                                    }, t.FullCB = function () {
                                        lt.inst.sendReport("解锁披萨机" + lt.inst.getNextUnlockId(0)), e._loadModel(n, Ot.PizzaMaker), Wt.inst.GuideStep == Mt.解锁披萨机3 && (Wt.inst.GuideStep = Mt.解锁单人桌4, pi.getInst().player.arrow.target = e.Find("SingleTable").getChildAt(0))
                                    }
                                }())
                            }
                    })
                }
            }, {
                key: "loadSingleTable",
                value: function () {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    qt.getInst().LoadPrefabByName(Ot.SingleTable).then(function (n) {
                        if (!e.Invalid)
                            for (var i = e.Find("SingleTable"), a = 0; a < i.numChildren; a++) {
                                var o = i.getChildAt(a),
                                    s = e.SingleTables[a];
                                Wt.inst.ShopSingleTableProgress[a] = Wt.inst.ShopSingleTableProgress[a] || 0;
                                var r = Wt.inst.ShopSingleTableProgress[a];
                                s.unlockLevel < e.UnlockLevel || s.unlockLevel === e.UnlockLevel && -1 !== s.unlockCoin && s.unlockCoin <= r ? t && (0 == a && Laya.timer.once(1e4, e, e.startMoneyStackAD), e._loadModel(o, Ot.SingleTable)) : s.unlockLevel == e.UnlockLevel && (-1 == s.unlockCoin ? function () {
                                    var t = e._loadADTag(o),
                                        n = o,
                                        i = a;
                                    t.FullCB = function () {
                                        lt.inst.sendReport("视频解锁单人桌" + lt.inst.getNextUnlockId(1)), Wt.inst.ShopSingleTableProgress[i] = -1, e._loadModel(n, Ot.SingleTable)
                                    }
                                }() : function () {
                                    var t = e._loadMoneyTag(o);
                                    t.Max = s.unlockCoin, t.Progress = r;
                                    var n = o,
                                        i = a;
                                    t.ProgressCB = function (e) {
                                        Wt.inst.ShopSingleTableProgress[i] = e
                                    }, t.FullCB = function () {
                                        1 == i && (Laya.timer.once(1e4, e, e.showUnlockTips), Laya.timer.once(3e4, e, e.showUnlockSupporter)), e._loadModel(n, Ot.SingleTable), lt.inst.sendReport("解锁单人桌" + lt.inst.getNextUnlockId(1)), Wt.inst.GuideStep == Mt.解锁单人桌4 && (Laya.timer.once(1e4, e, e.startMoneyStackAD), Wt.inst.GuideStep = Mt.拿披萨5, pi.getInst().player.arrow.target = e.pizzaMakers[0].WorkerPoint)
                                    }
                                }())
                            }
                    })
                }
            }, {
                key: "showUnlockTips",
                value: function () {
                    N.getInst().event(Et.ShowUnlockTips)
                }
            }, {
                key: "loadQuadTable",
                value: function () {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    qt.getInst().LoadPrefabByName(Ot.QuadTable).then(function (n) {
                        if (!e.Invalid)
                            for (var i = e.Find("QuadTable"), a = 0; a < i.numChildren; a++) {
                                var o = i.getChildAt(a),
                                    s = e.QuadTables[a];
                                Wt.inst.ShopQuadTableProgress[a] = Wt.inst.ShopQuadTableProgress[a] || 0;
                                var r = Wt.inst.ShopQuadTableProgress[a];
                                s.unlockLevel < e.UnlockLevel || s.unlockLevel === e.UnlockLevel && s.unlockCoin <= r ? t && e._loadModel(o, Ot.QuadTable) : s.unlockLevel == e.UnlockLevel && (-1 == s.unlockCoin ? function () {
                                    var t = e._loadADTag(o),
                                        n = o,
                                        i = a;
                                    t.FullCB = function () {
                                        Wt.inst.ShopQuadTableProgress[i] = -1, e._loadModel(n, Ot.QuadTable)
                                    }
                                }() : function () {
                                    var t = e._loadMoneyTag(o);
                                    t.Max = s.unlockCoin, t.Progress = r;
                                    var n = o,
                                        i = a;
                                    t.ProgressCB = function (e) {
                                        Wt.inst.ShopQuadTableProgress[i] = e
                                    }, t.FullCB = function () {
                                        e._loadModel(n, Ot.QuadTable)
                                    }
                                }())
                            }
                    })
                }
            }, {
                key: "loadPackers",
                value: function () {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    qt.getInst().LoadPrefabByName(Ot.BoxMaker).then(function (n) {
                        if (!e.Invalid)
                            for (var i = e.Find("Paker"), a = 0; a < i.numChildren; a++) {
                                var o = i.getChildAt(a),
                                    s = e.Packers[a];
                                Wt.inst.ShopPackerProgress[a] = Wt.inst.ShopPackerProgress[a] || 0;
                                var r = Wt.inst.ShopPackerProgress[a];
                                s.unlockLevel < e.UnlockLevel || s.unlockLevel === e.UnlockLevel && s.unlockCoin <= r ? t && e._loadModel(o, Ot.BoxMaker) : s.unlockLevel == e.UnlockLevel && (-1 == s.unlockCoin ? function () {
                                    var t = e._loadADTag(o),
                                        n = o,
                                        i = a;
                                    t.FullCB = function () {
                                        Wt.inst.ShopPackerProgress[i] = -1, e._loadModel(n, Ot.BoxMaker)
                                    }
                                }() : function () {
                                    var t = e._loadMoneyTag(o);
                                    t.Max = s.unlockCoin, t.Progress = r;
                                    var n = o,
                                        i = a;
                                    t.ProgressCB = function (e) {
                                        Wt.inst.ShopPackerProgress[i] = e
                                    }, t.FullCB = function () {
                                        Wt.inst.GuideStep == Mt.外卖提示11 && (ni.inst.TipsArrow = null, Wt.inst.GuideStep = Mt.完成新手), e._loadModel(n, Ot.BoxMaker)
                                    }, Wt.inst.GuideStep == Mt.等待外卖解锁10 && (Wt.inst.GuideStep = Mt.外卖提示11, ni.inst.TipsArrow = n, Yt.inst.target = n, M.WaitTime(2e3).then(function () {
                                        Yt.inst.target == n && (Yt.inst.target = null)
                                    }))
                                }())
                            }
                    })
                }
            }, {
                key: "loadHR",
                value: function () {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    qt.getInst().LoadPrefabByNames(Ot.HRTable, Ot.UpgradeAD).then(function (n) {
                        if (!e.Invalid) {
                            var i = e.Find("HRTablePos"),
                                a = e.Find("UpgradeADPos"),
                                o = e.HRRoom;
                            Wt.inst.ShopHrProgress = Wt.inst.ShopHrProgress || 0;
                            var s = Wt.inst.ShopHrProgress;
                            if (o.unlockLevel < e.UnlockLevel || o.unlockLevel === e.UnlockLevel && o.unlockCoin <= s) t && (e._loadModel(i, Ot.HRTable), e._loadModel(a, Ot.UpgradeAD));
                            else if (o.unlockLevel == e.UnlockLevel)
                                if (-1 == o.unlockCoin) {
                                    var r = e._loadADTag(i),
                                        l = i;
                                    r.FullCB = function () {
                                        lt.inst.sendReport("视频解锁HR" + lt.inst.getNextUnlockId(4)), Wt.inst.ShopHrProgress = -1, e._loadModel(l, Ot.HRTable)
                                    }
                                } else {
                                    var u = e._loadMoneyTag(i);
                                    u.Max = o.unlockCoin, u.Progress = s;
                                    var h = i,
                                        c = a;
                                    u.ProgressCB = function (e) {
                                        Wt.inst.ShopHrProgress = e
                                    }, Wt.inst.GuideStep == Mt.等待HR解锁8 && (Wt.inst.GuideStep = Mt.HR提示9, ni.inst.TipsArrow = h, Yt.inst.target = h, M.WaitTime(2e3).then(function () {
                                        Yt.inst.target == h && (Yt.inst.target = null)
                                    })), u.FullCB = function () {
                                        lt.inst.sendReport("解锁HR" + lt.inst.getNextUnlockId(4)), Wt.inst.GuideStep == Mt.HR提示9 && (Wt.inst.GuideStep = Mt.等待外卖解锁10, Yt.inst.target = null), e._loadModel(h, Ot.HRTable), e._loadModel(c, Ot.UpgradeAD), 0 == Wt.inst.ShopSupportCount && Laya.timer.once(3e4, e, e.showUnlockSupporter), Laya.timer.once(18e4, e, e.showUnlockWRJ)
                                    }
                                }
                        }
                    })
                }
            }, {
                key: "showUnlockSupporter",
                value: function () {
                    Wt.inst.HasADSupport || j.inst.PushUI(Tn, e.lowMid, bn.normal)
                }
            }, {
                key: "showUnlockWRJ",
                value: function () {
                    Wt.inst.UnlockedGirlUAV || j.inst.PushUI(Tn, e.lowMid, bn.wrj)
                }
            }, {
                key: "checkSupport",
                value: function () {
                    this.UnlockLevel > this.HRRoom.unlockLevel && (Wt.inst.ShopSupportCountLevel = Math.max(0, Wt.inst.ShopSupportCountLevel), this.loadSupporter())
                }
            }, {
                key: "loadUP",
                value: function () {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    qt.getInst().LoadPrefabByName(Ot.UpgradeTable).then(function (n) {
                        if (!e.Invalid) {
                            var i = e.Find("UPTablePos"),
                                a = Nt.getInst().upgradeRoom[e.ShopIndex];
                            Wt.inst.ShopUpgradeRoomProgress = Wt.inst.ShopUpgradeRoomProgress || 0;
                            var o = Wt.inst.ShopUpgradeRoomProgress;
                            if (a.unlockLevel < e.UnlockLevel || a.unlockLevel === e.UnlockLevel && a.unlockCoin <= o) t && e._loadModel(i, Ot.UpgradeTable);
                            else if (a.unlockLevel == e.UnlockLevel)
                                if (-1 == a.unlockCoin) {
                                    var s = e._loadADTag(i),
                                        r = i;
                                    s.FullCB = function () {
                                        Wt.inst.ShopUpgradeRoomProgress = -1, e._loadModel(r, Ot.UpgradeTable)
                                    }
                                } else {
                                    var l = e._loadMoneyTag(i);
                                    l.Max = a.unlockCoin, l.Progress = o;
                                    var u = i;
                                    l.ProgressCB = function (e) {
                                        Wt.inst.ShopUpgradeRoomProgress = e
                                    }, l.FullCB = function () {
                                        e._loadModel(u, Ot.UpgradeTable)
                                    }
                                }
                        }
                    })
                }
            }, {
                key: "loadBig",
                value: function () {
                    var e = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    qt.getInst().LoadPrefabByName(Ot.SingleTableBig).then(function (n) {
                        if (!e.Invalid) {
                            var i = e.Find("SingleTablePos_Big"),
                                a = Nt.getInst().bigTable[e.ShopIndex];
                            Wt.inst.ShopBigTableProgress = Wt.inst.ShopBigTableProgress || 0;
                            var o = Wt.inst.ShopBigTableProgress;
                            if (a.unlockLevel < e.UnlockLevel || a.unlockLevel === e.UnlockLevel && a.unlockCoin <= o) t && e._loadModel(i, Ot.SingleTableBig);
                            else if (a.unlockLevel == e.UnlockLevel)
                                if (-1 == a.unlockCoin) {
                                    var s = e._loadADTag(i),
                                        r = i;
                                    s.FullCB = function () {
                                        lt.inst.sendReport("视频解锁大单人桌" + lt.inst.getNextUnlockId(6)), Wt.inst.ShopBigTableProgress = -1, e._loadModel(r, Ot.SingleTableBig)
                                    }
                                } else {
                                    var l = e._loadMoneyTag(i);
                                    l.Max = a.unlockCoin, l.Progress = o;
                                    var u = i;
                                    l.ProgressCB = function (e) {
                                        Wt.inst.ShopBigTableProgress = e
                                    }, l.FullCB = function () {
                                        lt.inst.sendReport("解锁大单人桌" + lt.inst.getNextUnlockId(6)), e._loadModel(u, Ot.SingleTableBig)
                                    }
                                }
                        }
                    })
                }
            }, {
                key: "updateUnlock",
                value: function () {
                    this.UnlockLevel >= 6 && (this.unlockTags[0].active = !1, this.unlockTiles[0].active = !1), this.UnlockLevel >= 9 && (this.unlockTags[1].active = !1, this.unlockTiles[1].active = !1)
                }
            }, {
                key: "_loadModel",
                value: function (e, t) {
                    var n = qt.getInst().GetPrefab(t),
                        i = Laya.Sprite3D.instantiate(n);
                    e.addChild(i), i.transform.localPosition = F.Vector3Zero, i.transform.localRotationEuler = F.Vector3Zero
                }
            }, {
                key: "_loadMoneyTag",
                value: function (e) {
                    var t = Laya.Sprite3D.instantiate(qt.getInst().GetPrefab(Ot.MoneyUnlockTag));
                    return e.addChild(t), t.transform.localPosition = F.Vector3Zero, t.transform.rotationEuler = new Laya.Vector3(0, 90, 0), t.getComponent(xn)
                }
            }, {
                key: "_loadADTag",
                value: function (e) {
                    var t = Laya.Sprite3D.instantiate(qt.getInst().GetPrefab(Ot.AdUnlockTag));
                    return e.addChild(t), t.transform.localPosition = F.Vector3Zero, t.transform.rotationEuler = new Laya.Vector3(0, 90, 0), t.getComponent(Un)
                }
            }, {
                key: "loadSupporter",
                value: function () {
                    var e = this;
                    Wt.inst.ShopSupportCount > this.supporters.length && qt.getInst().LoadPrefabByName(Ot.Supporter).then(function (t) {
                        for (var n = e.supporters.length; n < Wt.inst.ShopSupportCount; n++) {
                            if (null == e.sp || e.sp.destroyed) return;
                            var i = Laya.Sprite3D.instantiate(t);
                            e.sp.addChild(i), i.transform.localPositionX += Xt.RandomFloat(-1, 1), i.transform.localPositionZ += Xt.RandomFloat(-1, 1), e.supporters.push(i.getComponent(ii))
                        }
                    }), Wt.inst.UnlockedGirlSupport && null == this.lbn && qt.getInst().LoadPrefabByName(Ot.laobanliang).then(function (t) {
                        if (null != e.sp && !e.sp.destroyed) {
                            var n = Laya.Sprite3D.instantiate(t);
                            e.sp.addChild(n), e.lbn = n.getComponent(ii)
                        }
                    }), Wt.inst.UnlockedGirlUAV && null == this.wrj && qt.getInst().LoadPrefabByName(Ot.Wurenji).then(function (t) {
                        if (null != e.sp && !e.sp.destroyed) {
                            var n = Laya.Sprite3D.instantiate(t);
                            e.sp.addChild(n), e.wrj = n.getComponent(ii)
                        }
                    })
                }
            }, {
                key: "CrazyMode",
                value: function () {
                    M.rand(this.pizzaMakers).crazySpwan()
                }
            }, {
                key: "TipsArrow",
                set: function (e) {
                    null == e ? this.ArrowHeart.active = !1 : (this.ArrowHeart.active = !0, this.ArrowHeart.transform.position = e.transform.position)
                }
            }, {
                key: "ShopIndex",
                get: function () {
                    return Wo.getInst().gameBlackBoard.currentShopIndex
                }
            }, {
                key: "UnlockLevel",
                get: function () {
                    return Wt.inst.ShopUnlockLevel
                }
            }, {
                key: "PizzzMakers",
                get: function () {
                    return Nt.getInst().pizzaMakers[this.ShopIndex]
                }
            }, {
                key: "SingleTables",
                get: function () {
                    return Nt.getInst().singleTables[this.ShopIndex]
                }
            }, {
                key: "QuadTables",
                get: function () {
                    return Nt.getInst().quadTables[this.ShopIndex]
                }
            }, {
                key: "HRRoom",
                get: function () {
                    return Nt.getInst().hrRoom[this.ShopIndex]
                }
            }, {
                key: "Packers",
                get: function () {
                    return Nt.getInst().packer[this.ShopIndex]
                }
            }]), MapNode
        }();
    __decorate([bind_node()], ai.prototype, "RiderPos", void 0), __decorate([bind_node()], ai.prototype, "RiderEnterPos", void 0), __decorate([bind_node()], ai.prototype, "RiderExitPos", void 0), __decorate([bind_node()], ai.prototype, "RiderMoneyPos", void 0), __decorate([bind_node()], ai.prototype, "MoneyADPos", void 0), ai = ni = __decorate([auto_bind_node()], ai);
    var oi = function (e) {
            function EntranceManager() {
                var e;
                return _classCallCheck(this, EntranceManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(EntranceManager).apply(this, arguments))).QueuePoints = [], e.campers = [], e.delay = 0, e
            }
            return _inherits(EntranceManager, Rt), _createClass(EntranceManager, [{
                key: "onAwake",
                value: function () {
                    EntranceManager.inst = this
                }
            }, {
                key: "onStart",
                value: function () {
                    this.BornPoint = this.Find("BornPoint"), this.ExitPoint = this.Find("ExitPoint"), this.StartPoint = this.Find("StartPoint");
                    for (var e = this.Find("QueuePoints"), t = 0; t < e.numChildren; t++) this.QueuePoints.push(e.getChildAt(t));
                    this.loadRoles()
                }
            }, {
                key: "onDestroy",
                value: function () {
                    EntranceManager.inst = null
                }
            }, {
                key: "loadRoles",
                value: function () {
                    var e = this;
                    qt.getInst().LoadPrefabByName(Ot.Customer).then(function () {
                        e.setRolePrefabMap()
                    })
                }
            }, {
                key: "setRolePrefabMap",
                value: function () {
                    this.rolePrefabMap = new Map, this.rolePrefabMap.set(Ot.Customer, qt.getInst().GetPrefab(Ot.Customer))
                }
            }, {
                key: "onUpdate",
                value: function () {
                    null != this.rolePrefabMap && (this.campers.length >= this.QueuePoints.length || (this.delay -= F.deltaTime, this.delay > 0 || (this.delay = Xt.RandomInt(1e3, 1500), this.spwanCamper())))
                }
            }, {
                key: "spwanCamper",
                value: function () {
                    var e = Ot.Customer,
                        t = Laya.Sprite3D.instantiate(this.rolePrefabMap.get(e));
                    ai.inst.sp.addChild(t);
                    var n = t.addComponent(en);
                    this.campers.push(n), t.transform.position = this.BornPoint.transform.position, n.SetPath([this.QueuePoints[this.campers.length - 1].transform.position])
                }
            }, {
                key: "setQueueTarget",
                value: function () {
                    for (var e = 0; e < this.campers.length; e++) {
                        this.campers[e].SetPath([this.QueuePoints[e].transform.position])
                    }
                }
            }, {
                key: "DequeueOneCamper",
                value: function () {
                    var e = this.campers.shift();
                    return this.setQueueTarget(), e
                }
            }, {
                key: "FindPathStartPoint2",
                get: function () {
                    return this.StartPoint.transform.position
                }
            }, {
                key: "FindPathStartPoint",
                get: function () {
                    return this.QueuePoints[0].transform.position
                }
            }, {
                key: "HasCamper",
                get: function () {
                    return this.campers.length > 0
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("EntranceManager", EntranceManager)
                }
            }]), EntranceManager
        }(),
        si = function (e) {
            function AccessibleBuildingManager() {
                var e;
                return _classCallCheck(this, AccessibleBuildingManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(AccessibleBuildingManager).apply(this, arguments))).buildings = [], e.delay = 0, e
            }
            return _inherits(AccessibleBuildingManager, Rt), _createClass(AccessibleBuildingManager, [{
                key: "onAwake",
                value: function () {
                    AccessibleBuildingManager.inst = this
                }
            }, {
                key: "Register",
                value: function (e) {
                    this.buildings.push(e)
                }
            }, {
                key: "UnRegister",
                value: function (e) {
                    var t = this.buildings.indexOf(e);
                    this.buildings.splice(t, 1)
                }
            }, {
                key: "onUpdate",
                value: function () {
                    if (0 != oi.inst.HasCamper && (this.delay -= F.deltaTime, !(this.delay > 0))) {
                        this.delay = Xt.RandomInt(300, 1500), this.shuffleBuildings();
                        var e = this.buildings.find(function (e) {
                            return e.IsOpen
                        });
                        if (null != e) {
                            var t = oi.inst.DequeueOneCamper();
                            e.AddWaitCamper(t)
                        }
                    }
                }
            }, {
                key: "shuffleBuildings",
                value: function () {
                    M.Shuffle(this.buildings)
                }
            }]), AccessibleBuildingManager
        }();
    __decorate([throttle(5e3)], si.prototype, "shuffleBuildings", null);
    var ri = function (e) {
            function ArrowTips() {
                var e;
                return _classCallCheck(this, ArrowTips), (e = _possibleConstructorReturn(this, _getPrototypeOf(ArrowTips).apply(this, arguments))).disVec = new Laya.Vector3, e.show = !0, e
            }
            return _inherits(ArrowTips, Rt), _createClass(ArrowTips, [{
                key: "onAwake",
                value: function () {
                    ArrowTips.inst = this;
                    var e = this.view = this.sp.getChildAt(0);
                    this.mat = e.meshRenderer.sharedMaterial
                }
            }, {
                key: "onDestroy",
                value: function () {
                    ArrowTips.inst = null
                }
            }, {
                key: "Show",
                value: function () {
                    this.show = !0, this.view.active = !0
                }
            }, {
                key: "Hide",
                value: function () {
                    this.show = !1, this.view.active = !1
                }
            }, {
                key: "onLateUpdate",
                value: function () {
                    if (this.view.active = !1, this.show && null != this.target) {
                        var e = pi.getInst().player;
                        if (null != e) {
                            this.view.active = !0, this.transform.position = e.transform.position, this.transform.position.y = .3, this.UpdatePosition(), Laya.Vector3.subtract(this.target.transform.position, this.transform.position, this.disVec);
                            var t = Laya.Vector3.scalarLength(this.disVec);
                            t < 1 ? this.view.active = !1 : (this.view.active = !0, this.transform.localScaleZ = t, this.mat.tilingOffsetY = t, this.transform.lookAt(this.target.transform.position, F.UP), this.transform.localRotationEulerY += 180, this.transform.localRotationEulerX = this.transform.localRotationEulerZ = 0, this.mat.tilingOffsetW -= 5 * F.deltaTimeSec)
                        }
                    }
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("ArrowTips", ArrowTips)
                }
            }]), ArrowTips
        }(),
        li = new Laya.Vector3,
        ui = new Laya.Vector3,
        hi = function (e) {
            function PizzaBox() {
                var e;
                return _classCallCheck(this, PizzaBox), (e = _possibleConstructorReturn(this, _getPrototypeOf(PizzaBox).apply(this, arguments))).Index = 0, e.targetR = new Laya.Quaternion, e.startCtrl = new Laya.Vector3, e.flyTime = 0, e.flyTotalTime = 400, e.attachPlayer = !1, e
            }
            return _inherits(PizzaBox, Rt), _createClass(PizzaBox, [{
                key: "onAwake",
                value: function () {}
            }, {
                key: "Open",
                value: function () {
                    Laya.Tween.to(this.Camp.transform, {
                        localRotationEulerX: -60
                    }, 100, null, null, 0, !0)
                }
            }, {
                key: "Close",
                value: function () {
                    Laya.Tween.to(this.Camp.transform, {
                        localRotationEulerX: 0
                    }, 100, null, null, 0, !0)
                }
            }, {
                key: "SpwanMove",
                value: function (e) {
                    Laya.Tween.to(this.transform.position, e, 100, Laya.Ease.linearInOut, Laya.Handler.create(this, this._onSpwanStepOneMoveEnd)).update = Laya.Handler.create(this, this.UpdatePosition, null, !1)
                }
            }, {
                key: "_onSpwanStepOneMoveEnd",
                value: function () {}
            }, {
                key: "FlyToZone",
                value: function (e, t) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    this.attachPlayer = !1, Laya.Tween.clearAll(this.transform.position);
                    var i = e.clone();
                    i.y += 2, this._flyToZone(i, e, t, n)
                }
            }, {
                key: "_flyToZone",
                value: function (e, t, n, i) {
                    this.flyTotalTime = n, this.flyTime = 0, this.startCtrl.setValue(this.transform.position.x, this.transform.position.y + 2, this.transform.position.z), null == this.curve ? this.curve = new Xn(this.transform.position, this.startCtrl, e, t) : this.curve.SetPos(this.transform.position, this.startCtrl, e, t), Laya.timer.frameOnce(1, this, this.updateFlyToZone, [i])
                }
            }, {
                key: "updateFlyToZone",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    if (this.sp.destroyed) Laya.timer.clearAll(this);
                    else {
                        this.flyTime += F.deltaTime;
                        var t = Math.min(1, this.flyTime / this.flyTotalTime);
                        this.curve.GetPos(t, li), this.transform.position = li, Laya.Quaternion.lerp(this.transform.rotation, this.targetR, .2, this.transform.rotation), this.transform.rotation = this.transform.rotation, this.flyTime >= this.flyTotalTime ? (this.transform.rotation = this.targetR, e && this.sp.destroy(!0), this.audio && G.inst.playSound("popsounds"), this.audio = !1) : Laya.timer.frameOnce(1, this, this.updateFlyToZone, [e])
                    }
                }
            }, {
                key: "FlyToPlayer",
                value: function () {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    this.Index = pi.getInst().player.pizzaBoxCount, pi.getInst().player.pizzaBoxes.push(this), this.attachPlayer = !1, Laya.Tween.clearAll(this.transform.position);
                    var t = this.sp.transform.position.clone();
                    t.y += 2, this._flyToPlayer(this.transform.position.clone(), t, 200, e)
                }
            }, {
                key: "_flyToPlayer",
                value: function (e, t, n, i) {
                    this.flyTotalTime = n, this.flyTime = 0, pi.getInst().player.GetPizzaTargetPos(this.Index, ui, li), null == this.curve ? this.curve = new Xn(e, t, li, ui) : this.curve.SetPos(e, t, li, ui), Laya.timer.frameOnce(1, this, this.updateFly, [i])
                }
            }, {
                key: "updateFly",
                value: function (e) {
                    if (this.sp.destroyed) Laya.timer.clearAll(this);
                    else {
                        this.flyTime += F.deltaTime;
                        var t = Math.min(1, this.flyTime / this.flyTotalTime);
                        pi.getInst().player.GetPizzaTargetPos(this.Index, ui, li), this.curve.p3 = li, this.curve.p4 = ui, this.curve.GetPos(t, li), this.transform.position = li, Laya.Vector3.lerp(this.transform.localRotationEuler, F.Vector3Zero, .2, li), this.transform.localRotationEuler = li, this.flyTime >= this.flyTotalTime ? (this.transform.localRotationEuler = F.Vector3Zero, this.attachPlayer = !0, e && this.sp.destroy(!0), this.audio && G.inst.playSound("popsounds"), this.audio = !1) : Laya.timer.frameOnce(1, this, this.updateFly, [e])
                    }
                }
            }, {
                key: "FlyToWorker",
                value: function (e) {
                    this.attachPlayer = !1, Laya.Tween.clearAll(this.transform.position);
                    var t = this.sp.transform.position.clone();
                    t.y += 2, this._flyToWorker(this.transform.position.clone(), t, 200, !1, e)
                }
            }, {
                key: "_flyToWorker",
                value: function (e, t, n, i, a) {
                    this.flyTotalTime = n, this.flyTime = 0, a.GetWoodTargetPos(this.Index, ui, li), null == this.curve ? this.curve = new Xn(e, t, li, ui) : this.curve.SetPos(e, t, li, ui), Laya.timer.frameOnce(1, this, this.updateFly2Worker, [i, a])
                }
            }, {
                key: "updateFly2Worker",
                value: function (e, t) {
                    if (this.sp.destroyed) Laya.timer.clearAll(this);
                    else {
                        this.flyTime += F.deltaTime;
                        var n = Math.min(1, this.flyTime / this.flyTotalTime);
                        t.GetWoodTargetPos(this.Index, ui, li), this.curve.p3 = li, this.curve.p4 = ui, this.curve.GetPos(n, li), this.transform.position = li, Laya.Vector3.lerp(this.transform.localRotationEuler, F.Vector3Zero, .2, li), this.transform.localRotationEuler = li, this.flyTime >= this.flyTotalTime ? (this.transform.localRotationEuler = F.Vector3Zero, e && this.sp.destroy(!0)) : Laya.timer.frameOnce(1, this, this.updateFly2Worker, [e, t])
                    }
                }
            }, {
                key: "onUpdate",
                value: function () {
                    if (this.attachPlayer) {
                        pi.getInst().player.GetPizzaTargetPos(this.Index, ui, li);
                        var e = Laya.Ease.quadOut(this.Index, 1, -.8, 30);
                        Laya.Vector3.lerp(this.transform.position, ui, e, li), this.transform.position = li, this.transform.rotationEuler.y = pi.getInst().player.pizza.transform.rotationEuler.y, this.transform.rotationEuler = this.transform.rotationEuler
                    }
                }
            }, {
                key: "onReset",
                value: function () {
                    this.attachPlayer = !1
                }
            }, {
                key: "onDestroy",
                value: function () {
                    this.ClearAsycFunc()
                }
            }]), PizzaBox
        }();
    __decorate([bind_node("Camp")], hi.prototype, "Camp", void 0), hi = __decorate([auto_bind_node()], hi);
    var ci = function (e) {
            function PizzaBoxManager() {
                return _classCallCheck(this, PizzaBoxManager), _possibleConstructorReturn(this, _getPrototypeOf(PizzaBoxManager).apply(this, arguments))
            }
            return _inherits(PizzaBoxManager, Rt), _createClass(PizzaBoxManager, [{
                key: "onAwake",
                value: function () {
                    PizzaBoxManager.inst = this
                }
            }, {
                key: "onDestroy",
                value: function () {
                    PizzaBoxManager.inst = null
                }
            }, {
                key: "CreatePizzaBox",
                value: function () {
                    var e = qt.getInst().GetPrefab(Ot.PizzaBox),
                        t = Laya.Sprite3D.instantiate(e).addComponent(hi);
                    return this.sp.addChild(t.sp), t
                }
            }]), PizzaBoxManager
        }(),
        di = new Laya.Vector2,
        fi = new Laya.Vector2,
        _i = function (e) {
            function PlayerCtrl() {
                var e;
                return _classCallCheck(this, PlayerCtrl), (e = _possibleConstructorReturn(this, _getPrototypeOf(PlayerCtrl).apply(this, arguments))).isMove = !1, e.canMove = !0, e.IsDuLun = !1, e.pizzas = [], e.pizzaBoxes = [], e.velocity = new Laya.Vector3, e.targetPos = new Laya.Vector3, e.pos2d = new Laya.Vector2, e.lastPos2D = new Laya.Vector2, e.crossSegmentLine = [], e
            }
            return _inherits(PlayerCtrl, Rt), _createClass(PlayerCtrl, [{
                key: "onAwake",
                value: function () {
                    pi.getInst().player = this, this.pizza = this.Find("pizzaNode"), this.dulunche = this.Find("pinghengche"), this.touying = this.Find("touying"), this.arrow = this.Find("Arrow").getComponent(ri), this.dulunche.active = !1
                }
            }, {
                key: "onEnable",
                value: function () {
                    N.getInst().on(V.PlayerSteerMoveStart, this, this.onSteerStart), N.getInst().on(V.PlayerSteerMoveEnd, this, this.onSteerEnd), N.getInst().on(Et.SwitchDuLun, this, this.SwitchDuLun), N.getInst().on(Et.SwitchFoot, this, this.SwitchFoot)
                }
            }, {
                key: "onStart",
                value: function () {
                    this.PlayAni(this.IsCarrying ? "Carrying" : "Idle"), this.pos2d.setValue(this.transform.position.x, this.transform.position.z), this.lastPos2D.setValue(this.pos2d.x, this.pos2d.y)
                }
            }, {
                key: "onDisable",
                value: function () {}
            }, {
                key: "onSteerStart",
                value: function (e) {
                    var t = -Yt.inst.transform.localRotationEulerY * Laya.MathUtils3D.Deg2Rad,
                        n = Math.cos(t),
                        i = Math.sin(t);
                    this.velocity.setValue(-e.x * this.speed, 0, -e.y * this.speed);
                    var a = this.velocity.x,
                        o = this.velocity.z;
                    this.velocity.setValue(a * n - o * i, 0, a * i + o * n)
                }
            }, {
                key: "onSteerEnd",
                value: function () {
                    this.velocity.setValue(0, 0, 0)
                }
            }, {
                key: "onUpdate",
                value: function () {
                    if (0 != Laya.timer.scale && this.canMove) {
                        if (this.targetPos.x = this.transform.position.x + this.velocity.x * F.deltaTimeSec, this.targetPos.z = this.transform.position.z + this.velocity.z * F.deltaTimeSec, this.targetPos.y = this.sp.transform.position.y, F.IsZeroVec3(this.velocity)) this.PlayAni(this.IsCarrying ? "Carrying" : "Idle", .1), this.isMove = !1;
                        else {
                            var e = this.transform.localRotationEulerY;
                            this.transform.lookAt(this.targetPos, F.UP), this.transform.localRotationEulerY = M.AngleLerp(e, this.transform.localRotationEulerY + 180, .3), this.IsDuLun ? this.PlayAni(this.IsCarrying ? "Carrying" : "Idle", .1) : this.PlayAni(this.IsCarrying ? "Running" : "Slow Run", .01), this.isMove = !0
                        }
                        var t = this.pos2d;
                        if (t.setValue(this.targetPos.x, this.targetPos.z), Yn.inst) {
                            var n = !0,
                                i = !1,
                                a = void 0;
                            try {
                                for (var o, s = Yn.inst.polygons.values()[Symbol.iterator](); !(n = (o = s.next()).done); n = !0) {
                                    var r = o.value;
                                    if (r.FastTest(t))
                                        if (Xt.PointInPolygon2(t, r.points)) {
                                            for (var l = Number.MAX_VALUE, u = void 0, h = void 0, c = 0; c < r.points.length; c++) {
                                                var d = r.points[c],
                                                    f = r.points[c == r.points.length - 1 ? 0 : c + 1],
                                                    _ = M.PointToSegmentDist2(t.x, t.y, d.x, d.y, f.x, f.y);
                                                _ < l && (l = _, u = d, h = f)
                                            }
                                            if (null != u && null != h) {
                                                var y = di;
                                                F.subtractVec2(u, h, y), F.normalizeVec2(y, y);
                                                var p = fi;
                                                F.subtractVec2(t, h, p);
                                                var g = F.DotVec2(p, y);
                                                y.x = h.x + y.x * g, y.y = h.y + y.y * g, F.subtractVec2(y, t, y), F.setLengthVec2(y, l, y), F.addVec2(t, y, t)
                                            }
                                        } else;
                                }
                            } catch (e) {
                                i = !0, a = e
                            } finally {
                                try {
                                    n || null == s.return || s.return()
                                } finally {
                                    if (i) throw a
                                }
                            }
                            if (this.crossSegmentLine = [], !Xt.PointInPolygon(t, Yn.inst.mapPolygon, this.crossSegmentLine)) {
                                for (var v, m, C = Number.MAX_VALUE, k = t.clone(), S = 0; S < this.crossSegmentLine.length; S += 2) {
                                    var I = this.crossSegmentLine[S],
                                        b = this.crossSegmentLine[S + 1],
                                        L = M.PointToSegmentDist2(t.x, t.y, I.x, I.y, b.x, b.y);
                                    L < C && (C = L, v = I, m = b)
                                }
                                if (null != v && null != m) {
                                    y = di;
                                    F.subtractVec2(v, m, y), F.normalizeVec2(y, y);
                                    p = fi;
                                    F.subtractVec2(k, m, p);
                                    g = F.DotVec2(p, y);
                                    y.x = m.x + y.x * g, y.y = m.y + y.y * g, F.subtractVec2(y, k, y), F.setLengthVec2(y, C, y), F.addVec2(t, y, t)
                                }
                            }
                        }
                        this.lastPos2D.setValue(t.x, t.y), this.transform.position.x = t.x, this.transform.position.z = t.y, this.IsDuLun ? (this.transform.position.y = Laya.MathUtil.lerp(this.transform.position.y, .5, .2), this.touying && (this.touying.transform.localPositionY = -.4)) : (this.transform.position.y = Laya.MathUtil.lerp(this.transform.position.y, .05, .2), this.touying && (this.touying.transform.localPositionY = .1)), this.UpdatePosition()
                    }
                }
            }, {
                key: "SwitchDuLun",
                value: function () {
                    this.dulunche.active = !0, this.IsDuLun = !0
                }
            }, {
                key: "SwitchFoot",
                value: function () {
                    this.dulunche.active = !1, this.IsDuLun = !1
                }
            }, {
                key: "step",
                value: function () {
                    G.inst.playSound("Footstep")
                }
            }, {
                key: "GetPizzaTargetPos",
                value: function (e, t, n) {
                    this.pizza.transform.getUp(t), t.cloneTo(n), Laya.Vector3.normalize(n, n), Laya.Vector3.scale(n, .2 * e, n), Laya.Vector3.add(this.pizza.transform.position, n, t), t.cloneTo(n), n.y += 2
                }
            }, {
                key: "ReaspwanPizza",
                value: function (e) {
                    var t;
                    if (e = Qn.inst.sp, this.pizzas.length <= 0) t = Laya.Sprite3D.instantiate(qt.getInst().GetPrefab(Ot.Pizza)).addComponent(Zn), e.addChild(t.sp), t.transform.position = this.pizza.transform.position, t.transform.rotation = this.pizza.transform.rotation;
                    else {
                        var n = (t = this.pizzas.pop()).transform.position.clone(),
                            i = t.transform.rotation.clone();
                        e.addChild(t.sp), t.transform.position = n, t.transform.rotation = i
                    }
                    return t
                }
            }, {
                key: "ReaspwanPizzaBox",
                value: function (e) {
                    var t;
                    if (e = e || ci.inst.sp, this.pizzaBoxes.length <= 0) t = Laya.Sprite3D.instantiate(qt.getInst().GetPrefab(Ot.PizzaBox)).addComponent(hi), e.addChild(t.sp), t.transform.position = this.pizza.transform.position, t.transform.rotation = this.pizza.transform.rotation;
                    else {
                        var n = (t = this.pizzaBoxes.pop()).transform.position.clone(),
                            i = t.transform.rotation.clone();
                        e.addChild(t.sp), t.transform.position = n, t.transform.rotation = i
                    }
                    return t
                }
            }, {
                key: "pizzaCount",
                get: function () {
                    return this.pizzas.length
                }
            }, {
                key: "pizzaBoxCount",
                get: function () {
                    return this.pizzaBoxes.length
                }
            }, {
                key: "IsCarrying",
                get: function () {
                    return this.pizzaBoxCount > 0 || this.pizzaCount > 0
                }
            }, {
                key: "speed",
                get: function () {
                    return this.IsDuLun ? Wt.inst.SpecailMoveSpeed : Wt.inst.MoveSpeed
                }
            }]), PlayerCtrl
        }(),
        yi = function (e) {
            function GameItemAttachMgr() {
                return _classCallCheck(this, GameItemAttachMgr), _possibleConstructorReturn(this, _getPrototypeOf(GameItemAttachMgr).apply(this, arguments))
            }
            return _inherits(GameItemAttachMgr, O), _createClass(GameItemAttachMgr, [{
                key: "Register",
                value: function () {
                    N.getInst().on(gi.PreBuildNodeNotice, this, this.onPreCreateNode), N.getInst().on(gi.BuildNodeNotice, this, this.onBuildNode), N.getInst().on(gi.BuildPrefabNodeNotice, this, this.onBuildPrefabNode), N.getInst().on(gi.BuildNodeCompletedNotice, this, this.onBuildNodeCompleted), N.getInst().on(gi.BuildPrefabNodeCompletedNotice, this, this.onBuildPrefabCompleted)
                }
            }, {
                key: "Reset",
                value: function () {}
            }, {
                key: "onPreCreatePrefab",
                value: function (e, t) {
                    return e
                }
            }, {
                key: "onPreCreateNode",
                value: function (e, t) {}
            }, {
                key: "onBuildNode",
                value: function (e, t, n) {
                    switch (e) {
                        case "Buildings":
                            break;
                        case "SetMap":
                            t.addComponent(si);
                            break;
                        case "delay":
                            n.break = !0
                    }
                }
            }, {
                key: "onBuildPrefabNode",
                value: function (e, t) {}
            }, {
                key: "onBuildNodeCompleted",
                value: function (e, t) {
                    switch (e) {
                        case "EdgePolygon":
                            t.addComponent(Yn);
                            break;
                        case "SetMap":
                            t.addComponent(ai)
                    }
                }
            }, {
                key: "onBuildPrefabCompleted",
                value: function (e, t) {
                    switch (e) {
                        case Ot.DirectionalLight:
                            pi.getInst().light = t;
                            break;
                        case Ot.Player:
                            t.addComponent(_i);
                            break;
                        case Ot.CameraNode:
                            t.addComponent(Yt), pi.getInst().mainCameraRotRoot = t
                    }
                }
            }]), GameItemAttachMgr
        }(),
        pi = function (e) {
            function LevelManager() {
                var e;
                return _classCallCheck(this, LevelManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(LevelManager).call(this))).lastLevelPrefabs = {}, e.currentLevelPrefabs = {}, e.breakLoadConfig = {}, e.buildHook = new vi, e
            }
            return _inherits(LevelManager, O), _createClass(LevelManager, [{
                key: "_init_",
                value: function () {
                    this.ResetScene()
                }
            }, {
                key: "ResetScene",
                value: function () {
                    var e = this;
                    if (this.sceneConfig = {}, this.sceneRawConfig.forEach(function (t) {
                            e.sceneConfig[t.n] = t
                        }), null == this.scene) {
                        this.scene = new Laya.Scene3D, Laya.stage.addChild(this.scene), this.scene.zOrder = -1;
                        var t = this.sceneConfig.ambientColor;
                        null != t && null != t.ad && (this.scene.ambientColor = this.parseColor3(t.ad.c));
                        var n = this.sceneConfig.Fog;
                        null != n && null != n.fd && (this.scene.enableFog = !0, this.scene.fogColor = this.parseColor3(n.fd.c), this.scene.fogStart = n.fd.start, this.scene.fogRange = n.fd.end - n.fd.start)
                    }
                }
            }, {
                key: "LoadCachePrefab",
                value: function (e) {
                    var t = this;
                    return new Promise(function (n) {
                        var i = t.sceneConfig.cache;
                        if (null != i) {
                            var a = {};
                            t.CollectPrefabs(i, a), Object.keys(a).forEach(function (e) {
                                null == a[e] && console.log(e, " is null"), a[e].isCache = !0
                            }), qt.getInst().LoadPrefab(a, function () {
                                n()
                            }, e, t)
                        } else n()
                    })
                }
            }, {
                key: "LoadStatic",
                value: function () {
                    var e = this;
                    return new w(function (t, n) {
                        var i = e.sceneConfig.static;
                        if (null != i) {
                            null != e.staticEnvNode && e.staticEnvNode.destroy(), e.staticEnvNode = new Laya.Sprite3D("staticEnvNode"), e.scene.addChild(e.staticEnvNode);
                            var a = {};
                            e.CollectPrefabs(i, a);
                            try {
                                qt.getInst().LoadPrefab(a, function () {
                                    try {
                                        e.BuildNode(i, e.staticEnvNode);
                                        var n = Object.keys(a).map(function (e) {
                                            return a[e]
                                        });
                                        qt.getInst().UnLoadPrefab(n), t()
                                    } catch (e) {}
                                }, n, e)
                            } catch (e) {
                                console.error(e)
                            }
                        } else t()
                    })
                }
            }, {
                key: "LoadLevel",
                value: function (e) {
                    try {
                        if (null == this.sceneConfig[e]) throw new Error("not has level{".concat(e, "} config!"));
                        console.log("load level:", e), this.lastLevelPrefabs = this.currentLevelPrefabs, this.currentLevelPrefabs = {};
                        var t = this.currentSceneConfg = this.sceneConfig[e];
                        return this.CollectPrefabs(t, this.currentLevelPrefabs), this.UnLoadLastScene(), this.unLoadNotUsedPrafab(), yi.getInst().Reset(), this.LoadDynamicScene()
                    } catch (e) {
                        console.error(e)
                    }
                }
            }, {
                key: "GameStartLoad",
                value: function () {
                    var e = this;
                    return new w(function (t, n) {
                        e.LoadCachePrefab(function (e) {
                            n(.5 * e)
                        }).then(function () {
                            console.log("动态资源加载完成"), e.LoadStatic().progress(function (e) {
                                n(.5 + .5 * e)
                            }).then(function () {
                                n(1), console.log("静态资源加载完成"), t()
                            }).catch(function (e) {
                                console.error(e)
                            })
                        }).catch(function (e) {
                            console.error(e)
                        })
                    })
                }
            }, {
                key: "CollectPrefab",
                value: function (e, t) {
                    e[t] = qt.getInst().prefabMap[t]
                }
            }, {
                key: "CollectPrefabs",
                value: function (e, t) {
                    if (null != e) {
                        var n = e.pn;
                        if (null != n && null == t[n] && (t[e.pn] = qt.getInst().prefabMap[n], this.CollectPrefab(t, n)), null != e.c && 0 != e.c.length)
                            for (var i = 0; i < e.c.length; i++) this.CollectPrefabs(e.c[i], t)
                    }
                }
            }, {
                key: "UnLoadLastScene",
                value: function () {
                    null != this.currentSceneNode && (this.currentSceneNode.destroy(!0), this.currentSceneNode = null)
                }
            }, {
                key: "unLoadNotUsedPrafab",
                value: function () {
                    for (var e = [], t = Object.keys(this.lastLevelPrefabs), n = 0; n < t.length; n++) {
                        var i = t[n];
                        null != this.currentLevelPrefabs[i] || this.lastLevelPrefabs[i].isCache || e.push(this.lastLevelPrefabs[i])
                    }
                    qt.getInst().UnLoadPrefab(e)
                }
            }, {
                key: "LoadDynamicScene",
                value: function () {
                    var e = this;
                    return this.breakLoadConfig = {}, new w(function (t, n) {
                        if (null == e.currentLevelPrefabs) throw new Error("场景配置为空,是否导出场景?");
                        e.LoadPrefabs(e.currentLevelPrefabs, function (e) {
                            n(e)
                        }).then(function () {
                            e.currentSceneNode = new Laya.Sprite3D("currentSceneNode"), e.scene.addChild(e.currentSceneNode), e.BuildNode(e.currentSceneConfg, e.currentSceneNode), t()
                        })
                    })
                }
            }, {
                key: "AppendBlock",
                value: function (e) {
                    var t = this,
                        n = this.sceneConfig[e];
                    if (null == n) throw new Error(e + "节点不存在");
                    var i = {};
                    return this.CollectPrefabs(n, i), new w(function (e, a) {
                        t.LoadPrefabs(i, function (e) {
                            a(e)
                        }).then(function () {
                            t.BuildNode(n, t.scene), e()
                        })
                    })
                }
            }, {
                key: "LoadPrefabs",
                value: function (e) {
                    var t = this,
                        n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                    return new Promise(function (i) {
                        qt.getInst().LoadPrefab(e, function () {
                            i()
                        }, n, t)
                    })
                }
            }, {
                key: "BuildNode",
                value: function (e, t) {
                    var n, i, a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    if (null != e.pn) {
                        if (i = e.pn, N.getInst().HasListener(gi.PreBuildPrefabNodeNotice) && (this.buildHook.build = !0, N.getInst().event(gi.PreBuildPrefabNodeNotice, i, e.n, this.buildHook), !this.buildHook.build)) return;
                        null != this.onPreCreatePrefab && (i = this.onPreCreatePrefab(i, e.n));
                        var o = qt.getInst().GetPrefab(i);
                        o || console.error(i, "not load!"), (n = Laya.Sprite3D.instantiate(o)).name = e.n
                    }
                    if (null == n) {
                        if (N.getInst().HasListener(gi.PreBuildNodeNotice) && (this.buildHook.build = !0, N.getInst().event(gi.PreBuildNodeNotice, e.n, this.buildHook), !this.buildHook.build)) return;
                        (n = new Laya.Sprite3D(e.n)).name = e.n
                    }
                    if (n.transform.localPosition = new Laya.Vector3, n.transform.localRotationEulerY = n.transform.localRotationEulerY, n.transform.localScale = n.transform.localScale, t.addChild(n), null != e.t && (null != e.t.p && (n.transform.localPosition = this.parseVector3(e.t.p)), null != e.t.e && (n.transform.localRotationEuler = this.parseVector3(e.t.e)), null != e.t.s && (n.transform.localScale = this.parseVector3(e.t.s)), n instanceof Laya.Camera || e.n.toLocaleLowerCase().includes("camera"), "light" == e.n && Laya.DirectionLight), null != i && N.getInst().event(gi.BuildPrefabNodeNotice, i, n, e.n), N.getInst().event(gi.BuildNodeNotice, e.n, n, e), null != e.pd && this.SetPrefabDiff(e.pd, n), null != e.c)
                        if (a && 1 == e.break) this.breakLoadConfig[e.n] = e;
                        else
                            for (var s = 0; s < e.c.length; s++) this.BuildNode(e.c[s], n);
                    null != i && N.getInst().event(gi.BuildPrefabNodeCompletedNotice, i, n, e.n), N.getInst().event(gi.BuildNodeCompletedNotice, e.n, n)
                }
            }, {
                key: "SetPrefabDiff",
                value: function (e, t) {
                    if (null != e.child)
                        for (var n = 0; n < e.child.length; n++) {
                            var i = e.child[n],
                                a = t.getChildAt(i.index);
                            if (i.transform) {
                                if (null != i.transform.p) {
                                    var o = this.parseVector3(i._transform.p);
                                    Laya.Vector3.add(o, this.parseVector3(i.transform.p), o), a.transform.localPosition = o
                                }
                                if (null != i.transform.e) {
                                    var s = this.parseVector3(i._transform.e);
                                    Laya.Vector3.add(s, this.parseVector3(i.transform.e), s), a.transform.localRotationEuler = s
                                }
                                if (null != i.transform.s) {
                                    var r = this.parseVector3(i._transform.s);
                                    Laya.Vector3.add(r, this.parseVector3(i.transform.s), r), a.transform.localScale = r
                                }
                            }
                            a.active = i.active, null != i.child && this.SetPrefabDiff(i, a)
                        }
                    if (null != e.unknownChild)
                        for (n = 0; n < e.unknownChild.length; n++) {
                            var l = e.unknownChild[n];
                            this.BuildNode(l, t)
                        }
                }
            }, {
                key: "parseVector3",
                value: function (e, t) {
                    var n = e.split(",");
                    return (t = t || new Laya.Vector3).setValue(Number(n[0]), Number(n[1]), Number(n[2])), t
                }
            }, {
                key: "parseColor",
                value: function (e) {
                    var t = e.split(",");
                    return new Laya.Vector4(Number(t[0]), Number(t[1]), Number(t[2]), Number(t[3]))
                }
            }, {
                key: "parseColor3",
                value: function (e) {
                    var t = e.split(",");
                    return new Laya.Vector3(Number(t[0]), Number(t[1]), Number(t[2]))
                }
            }]), LevelManager
        }();
    __decorate([res_assign("res/scene/level.json")], pi.prototype, "sceneRawConfig", void 0), pi = __decorate([res_auto_bind()], pi);
    var gi, vi = function BuildeHookNotice() {
        _classCallCheck(this, BuildeHookNotice), this.build = !0
    };
    ! function (e) {
        e.Scene3DAddNotice = "Scene3DAddNotice", e.PreBuildNodeNotice = "PreBuildNodeNotice", e.PreBuildPrefabNodeNotice = "PreBuildPrefabNodeNotice", e.BuildNodeNotice = "BuildNodeNotice", e.BuildPrefabNodeNotice = "BuildPrefabNodeNotice", e.BuildNodeCompletedNotice = "BuildNodeCompletedNotice", e.BuildPrefabNodeCompletedNotice = "buildPrefabNodeCompletedNotice"
    }(gi || (gi = {}));
    var mi = new Laya.Vector3,
        Ci = function (e) {
            function Money() {
                var e;
                return _classCallCheck(this, Money), (e = _possibleConstructorReturn(this, _getPrototypeOf(Money).apply(this, arguments))).startCtrl = new Laya.Vector3, e.delay = 0, e.moving = !1, e.moveTime = 0, e.flyTime = 0, e.flyTotalTime = 400, e
            }
            return _inherits(Money, Rt), _createClass(Money, [{
                key: "onStart",
                value: function () {
                    this.cube = this.Find("Cube"), this.cube.active = !1, this.moving = !1
                }
            }, {
                key: "onUpdate",
                value: function () {
                    this.moving && (this.moveTime += F.deltaTime, this.moveTime > 2e3 && (this.moving = !1, Laya.timer.clear(this, this.updateFly2)))
                }
            }, {
                key: "FlyToZone",
                value: function (e, t, n) {
                    var i = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
                    this.moving = !0, this.moveTime = 0;
                    var a = e.clone();
                    a.y += 2, this.delay = n, this._flyToZone(a, e, t, i)
                }
            }, {
                key: "_flyToZone",
                value: function (e, t, n, i) {
                    this.flyTotalTime = n, this.flyTime = 0, this.startCtrl.setValue(this.transform.position.x, this.transform.position.y + 2, this.transform.position.z), null == this.curve ? this.curve = new Xn(this.transform.position, this.startCtrl, e, t) : this.curve.SetPos(this.transform.position, this.startCtrl, e, t), Laya.timer.frameOnce(1, this, this.updateFly2, [i])
                }
            }, {
                key: "updateFly2",
                value: function (e) {
                    if (this.delay -= F.deltaTime, this.delay > 0) Laya.timer.frameOnce(1, this, this.updateFly2, [e]);
                    else if (this.sp.destroyed) Laya.timer.clearAll(this);
                    else {
                        this.flyTime += F.deltaTime;
                        var t = Math.min(1, this.flyTime / this.flyTotalTime);
                        this.curve.GetPos(t, mi), this.transform.position = mi, this.targetR ? (Laya.Quaternion.slerp(this.transform.rotation, this.targetR, .2, this.transform.rotation), this.transform.rotation = this.transform.rotation) : (Laya.Vector3.lerp(this.transform.rotationEuler, F.Vector3Zero, .2, mi), this.transform.rotationEuler = this.transform.rotationEuler), this.transform.rotationEuler = mi, this.flyTime >= this.flyTotalTime ? (e && (this.sp.destroy(!0), this.playSound()), this.moving = !1) : Laya.timer.frameOnce(1, this, this.updateFly2, [e])
                    }
                }
            }, {
                key: "playSound",
                value: function () {
                    G.inst.playSound("coins")
                }
            }, {
                key: "onReset",
                value: function () {
                    this.moving = !1
                }
            }, {
                key: "onDestroy",
                value: function () {
                    this.moving = !1, Laya.timer.clearAll(this)
                }
            }]), Money
        }(),
        ki = function (e) {
            function MoneyManager() {
                var e;
                return _classCallCheck(this, MoneyManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(MoneyManager).apply(this, arguments))).money = [], e.cache = new Map, e
            }
            return _inherits(MoneyManager, Rt), _createClass(MoneyManager, [{
                key: "onAwake",
                value: function () {
                    MoneyManager.inst = this
                }
            }, {
                key: "onStart",
                value: function () {
                    Laya.timer.frameOnce(5, this, this.checkPlayer)
                }
            }, {
                key: "checkPlayer",
                value: function () {
                    if (null != pi.getInst().player && 0 != this.money.length) {
                        var e = this.getNearstMoneys(pi.getInst().player.transform.position, 3);
                        if (0 !== e.length) {
                            for (var t = this.getDelayTimes(e), n = 0; n < e.length; n++) {
                                var i = e[n];
                                if (!i.moving) {
                                    var a = Math.floor(100 * i.transform.position.y),
                                        o = this.getNearstDis(i.transform.position, pi.getInst().player.transform.position),
                                        s = t.get(a) || 0 + o / 3 * 100;
                                    i.FlyToZone(pi.getInst().player.transform.position, 300, s, !0), Wt.inst.Money += Wt.inst.Price
                                }
                            }
                            Wt.inst.GuideStep == Mt.捡钱7 && (pi.getInst().player.arrow.target = null, Wt.inst.GuideStep = Mt.等待HR解锁8), Laya.timer.once(300, this, this.checkPlayer)
                        } else Laya.timer.frameOnce(5, this, this.checkPlayer)
                    } else Laya.timer.frameOnce(5, this, this.checkPlayer)
                }
            }, {
                key: "CreateMoney",
                value: function (e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        n = qt.getInst().GetPrefab(Ot.Money),
                        i = Laya.Sprite3D.instantiate(n);
                    this.sp.addChild(i), i.transform.position = e;
                    var a = i.addComponent(Ci);
                    return t || this.money.push(a), a
                }
            }, {
                key: "sort",
                value: function (e) {
                    var t = this;
                    this.cache.clear(), this.money.sort(function (n, i) {
                        return t.getNearstDis(n.transform.position, e) - t.getNearstDis(i.transform.position, e)
                    })
                }
            }, {
                key: "getNearstMoneys",
                value: function (e, t) {
                    var n = this;
                    this.sort(e);
                    for (var i = [], a = Math.pow(t, 2), o = 0; o < this.money.length && o < 30; o++) {
                        var s = this.money[o];
                        if (!(this.getNearstDis(s.transform.position, e) < a)) break;
                        i.push(this.money.shift()), o--
                    }
                    return i.sort(function (t, i) {
                        return t.transform.position.y > i.transform.position.y ? -1 : t.transform.position.y < i.transform.position.y ? 1 : n.getNearstDis(t.transform.position, e) - n.getNearstDis(i.transform.position, e)
                    }), i
                }
            }, {
                key: "getDelayTimes",
                value: function (e) {
                    var t = [];
                    e.forEach(function (e) {
                        var n = Math.floor(100 * e.transform.position.y);
                        t.indexOf(n) < 0 && t.push(n)
                    }), t.sort(function (e, t) {
                        return t - e
                    });
                    for (var n = new Map, i = 0; i < t.length; i++) n.set(t[i], 100 * i);
                    return n
                }
            }, {
                key: "getNearstDis",
                value: function (e, t) {
                    if (this.cache.has(e)) return this.cache.get(e);
                    var n = this.getXZDisSq(e, t);
                    return this.cache.set(e, n), n
                }
            }, {
                key: "getXZDisSq",
                value: function (e, t) {
                    return Math.pow(e.x - t.x, 2) + Math.pow(e.z - t.z, 2)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("MoneyManager", MoneyManager)
                }
            }]), MoneyManager
        }(),
        Si = new Laya.Vector2,
        Ii = function (e) {
            function PolygonTrigger() {
                var e;
                return _classCallCheck(this, PolygonTrigger), (e = _possibleConstructorReturn(this, _getPrototypeOf(PolygonTrigger).apply(this, arguments))).maxX = -1e6, e.minX = 1e5, e.maxY = -1e6, e.minY = 1e6, e.fade = !0, e.checkMove = !0, e.isEnter = !1, e.stayDelay = 0, e.stayDelayDuration = 100, e.stayCD = 0, e.stayCallDuration = 100, e.stayCallCount = 0, e
            }
            return _inherits(PolygonTrigger, Rt), _createClass(PolygonTrigger, [{
                key: "onStart",
                value: function () {
                    var e = this.Find("polygon") || this.sp;
                    if (e) {
                        this.polygon = [], this.maxX = -1 / 0, this.minX = 1 / 0, this.maxY = -1 / 0, this.minY = 1 / 0;
                        for (var t = 0; t < e.numChildren; t++) {
                            var n = e.getChildAt(t);
                            this.polygon.push(new Laya.Vector2(n.transform.position.x, n.transform.position.z))
                        }
                        for (var i = 0; i < this.polygon.length; i++) {
                            var a = this.polygon[i];
                            this.maxX = Math.max(a.x, this.maxX), this.minX = Math.min(a.x, this.minX), this.maxY = Math.max(a.y, this.maxY), this.minY = Math.min(a.y, this.minY)
                        }
                    } else console.warn("".concat(this.sp.name, " not has polygon node!")), this.destroy()
                }
            }, {
                key: "FastTest",
                value: function (e) {
                    return e.x >= this.minX && e.x <= this.maxX && e.y >= this.minY && e.y <= this.maxY
                }
            }, {
                key: "onUpdate",
                value: function () {
                    if (null != this.onExitCB || null != this.onEnterCB || null != this.onStayCB) {
                        var e = pi.getInst().player;
                        if (null != e) {
                            Si.setValue(e.transform.position.x, e.transform.position.z);
                            var t = this.FastTest(Si);
                            return t && (t = Xt.PointInPolygon2(Si, this.polygon)), !this.isEnter && t ? (this.isEnter = t, void this._onTriggerEner()) : this.isEnter && t ? (this.isEnter = t, void this._onTriggerStay()) : this.isEnter && !t ? (this.isEnter = t, void this._onTriggerExit()) : void 0
                        }
                    }
                }
            }, {
                key: "_onTriggerEner",
                value: function () {
                    this.stayCallCount = 0, this.onEnterCB && this.onEnterCB()
                }
            }, {
                key: "_onTriggerStay",
                value: function () {
                    this.checkMove && pi.getInst().player.isMove || (this.stayDelay += F.deltaTime, this.stayDelay < this.stayDelayDuration || (this.stayCD += F.deltaTime, this.stayCD < this.stayCallDuration || (this.fade && (this.stayCallDuration -= 10, this.stayCallDuration = Xt.Clamp(this.stayCallDuration, 20, 1e3)), this.stayCD -= this.stayCallDuration, this.stayCallCount++, this.onStayCB && this.onStayCB(this.stayCallCount))))
                }
            }, {
                key: "_onTriggerExit",
                value: function () {
                    this.stayCallCount = 0, this.stayCallDuration = 100, this.onExitCB && this.onExitCB()
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("PolygonTrigger", PolygonTrigger)
                }
            }]), PolygonTrigger
        }(),
        bi = function (e) {
            function ObstaclePolygon() {
                var e;
                return _classCallCheck(this, ObstaclePolygon), (e = _possibleConstructorReturn(this, _getPrototypeOf(ObstaclePolygon).apply(this, arguments))).group = "default", e
            }
            return _inherits(ObstaclePolygon, Rt), _createClass(ObstaclePolygon, [{
                key: "initPolygon",
                value: function () {
                    for (var e = [], t = 0; t < this.sp.numChildren; t++) {
                        var n = this.sp.getChildAt(t);
                        e.push(new Laya.Vector2(n.transform.position.x, n.transform.position.z))
                    }
                    this.polygon = new $n(e)
                }
            }, {
                key: "_updatePolygon",
                value: function () {
                    for (var e = 0; e < this.sp.numChildren; e++) {
                        var t = this.sp.getChildAt(e);
                        this.polygon.points[e].setValue(t.transform.position.x, t.transform.position.z)
                    }
                }
            }, {
                key: "onEnable",
                value: function () {
                    Laya.timer.callLater(this, this.addPolygon)
                }
            }, {
                key: "onDisable",
                value: function () {
                    Laya.timer.clear(this, this.addPolygon), null != this.polygon && Yn.inst.RemovePolygon(this.polygon)
                }
            }, {
                key: "addPolygon",
                value: function () {
                    null == this.polygon && this.initPolygon(), Yn.inst.AddPolygon(this.polygon, this.group)
                }
            }, {
                key: "_parse",
                value: function (e) {
                    this.group = e.fn_froup
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.group = this.group
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("ObstaclePolygon", ObstaclePolygon)
                }
            }]), ObstaclePolygon
        }(),
        Li = function (e) {
            function RotateSelf() {
                var e;
                return _classCallCheck(this, RotateSelf), (e = _possibleConstructorReturn(this, _getPrototypeOf(RotateSelf).call(this))).angleSpeed = new Laya.Vector3(0, 0, 0), e
            }
            return _inherits(RotateSelf, Rt), _createClass(RotateSelf, [{
                key: "onAwake",
                value: function () {}
            }, {
                key: "onUpdate",
                value: function () {
                    var e = this.owner.transform;
                    0 != this.angleSpeed.y && (e.localRotationEulerY += this.angleSpeed.y * F.deltaTimeSec), 0 != this.angleSpeed.z && (e.localRotationEulerZ += this.angleSpeed.z * F.deltaTimeSec), 0 != this.angleSpeed.x && (e.localRotationEulerX += this.angleSpeed.x * F.deltaTimeSec)
                }
            }, {
                key: "_parse",
                value: function (e) {
                    this.angleSpeed.setValue(Number.parseInt(e.fn_x), Number.parseInt(e.fn_y), Number.parseInt(e.fn_z))
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    this.angleSpeed.cloneTo(e.angleSpeed)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("RotateSelf", RotateSelf)
                }
            }]), RotateSelf
        }(),
        Pi = function (e) {
            function UVMove() {
                var e;
                return _classCallCheck(this, UVMove), (e = _possibleConstructorReturn(this, _getPrototypeOf(UVMove).apply(this, arguments))).fn_speed_z = 0, e.fn_speed_w = 0, e.index = 0, e
            }
            return _inherits(UVMove, Rt), _createClass(UVMove, [{
                key: "onStart",
                value: function () {
                    this.sp instanceof Laya.MeshSprite3D && (this.mat = this.sp.meshRenderer.materials[this.index])
                }
            }, {
                key: "onUpdate",
                value: function () {
                    var e = F.deltaTimeSec;
                    0 != this.fn_speed_z && (this.mat.tilingOffsetZ += this.fn_speed_z * e), 0 != this.fn_speed_w && (this.mat.tilingOffsetW += this.fn_speed_w * e)
                }
            }, {
                key: "_parse",
                value: function (e) {
                    this.fn_speed_z = Number.parseFloat(e.fn_speed_z), this.fn_speed_w = Number.parseFloat(e.fn_speed_w), this.index = Number.parseInt(e.fn_index)
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.fn_speed_z = this.fn_speed_z, e.fn_speed_w = this.fn_speed_w, e.index = this.index
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("UVMove", UVMove)
                }
            }]), UVMove
        }(),
        Ti = '#if defined(GL_FRAGMENT_PRECISION_HIGH)\nprecision highp float;precision highp int;\n#else\nprecision mediump float;precision mediump int;\n#endif\n#include "Lighting.glsl";\n#include "LayaUtile.glsl"\n#include "Shadow.glsl";\nattribute vec4 a_Position;\n#ifdef GPU_INSTANCE\nuniform mat4 u_ViewProjection;\n#else\nuniform mat4 u_MvpMatrix;\n#endif\nattribute vec2 a_Texcoord0;varying vec2 v_Texcoord0;varying vec2 v_ThresholdUV;attribute vec2 a_Texcoord1;varying vec2 v_Texcoord1;\n#ifdef LIGHTMAP\nuniform vec4 u_LightmapScaleOffset;varying vec2 v_LightMapUV;\n#endif\n#ifdef COLOR\nattribute vec4 a_Color;varying vec4 v_Color;\n#endif\n#ifdef BONE\nconst int c_MaxBoneCount=24;attribute vec4 a_BoneIndices;attribute vec4 a_BoneWeights;uniform mat4 u_Bones[c_MaxBoneCount];\n#endif\nattribute vec3 a_Normal;varying vec3 v_Normal;\n#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)\nuniform vec3 u_CameraPos;varying vec3 v_ViewDir;\n#endif\n#if defined(NORMALMAP)\nattribute vec4 a_Tangent0;varying vec3 v_Tangent;varying vec3 v_Binormal;\n#endif\n#ifdef GPU_INSTANCE\nattribute mat4 a_WorldMat;\n#else\nuniform mat4 u_WorldMat;\n#endif\nvarying vec3 v_PositionWorld;\n#if defined(CALCULATE_SHADOWS)&&!defined(SHADOW_CASCADE)\nvarying vec4 v_ShadowCoord;\n#endif\n#if defined(CALCULATE_SPOTSHADOWS)\nvarying vec4 v_SpotShadowCoord;\n#endif\nuniform vec4 u_TilingOffset;uniform vec4 u_ThresholdTilingOffset;void main(){vec4 position;\n#ifdef BONE\nmat4 skinTransform;\n#ifdef SIMPLEBONE\nfloat currentPixelPos;\n#ifdef GPU_INSTANCE\ncurrentPixelPos=a_SimpleTextureParams.x+a_SimpleTextureParams.y;\n#else\ncurrentPixelPos=u_SimpleAnimatorParams.x+u_SimpleAnimatorParams.y;\n#endif\nfloat offset=1.0/u_SimpleAnimatorTextureSize;skinTransform=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.x),offset)*a_BoneWeights.x;skinTransform+=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.y),offset)*a_BoneWeights.y;skinTransform+=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.z),offset)*a_BoneWeights.z;skinTransform+=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.w),offset)*a_BoneWeights.w;\n#else\nskinTransform=u_Bones[int(a_BoneIndices.x)]*a_BoneWeights.x;skinTransform+=u_Bones[int(a_BoneIndices.y)]*a_BoneWeights.y;skinTransform+=u_Bones[int(a_BoneIndices.z)]*a_BoneWeights.z;skinTransform+=u_Bones[int(a_BoneIndices.w)]*a_BoneWeights.w;\n#endif\nposition=skinTransform*a_Position;\n#else\nposition=a_Position;\n#endif\nmat4 worldMat;\n#ifdef GPU_INSTANCE\nworldMat=a_WorldMat;\n#else\nworldMat=u_WorldMat;\n#endif\n#ifdef GPU_INSTANCE\ngl_Position=u_ViewProjection*worldMat*position;\n#else\ngl_Position=u_MvpMatrix*position;\n#endif\nmat3 worldInvMat;\n#ifdef BONE\nworldInvMat=INVERSE_MAT(mat3(worldMat*skinTransform));\n#else\nworldInvMat=INVERSE_MAT(mat3(worldMat));\n#endif\nv_Normal=normalize(a_Normal*worldInvMat);\n#if defined(NORMALMAP)\nv_Tangent=normalize(a_Tangent0.xyz*worldInvMat);v_Binormal=cross(v_Normal,v_Tangent)*a_Tangent0.w;\n#endif\nvec3 positionWS=(worldMat*position).xyz;\n#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)||(defined(CALCULATE_SHADOWS)&&defined(SHADOW_CASCADE))||defined(CALCULATE_SPOTSHADOWS)\n#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)\nv_ViewDir=u_CameraPos-positionWS;\n#endif\n#endif\nv_PositionWorld=positionWS;v_Texcoord0=TransformUV(a_Texcoord0,u_TilingOffset);v_ThresholdUV=TransformUV(a_Texcoord0,u_ThresholdTilingOffset);\n#ifdef LIGHTMAP\n#ifdef UV1\nv_LightMapUV=vec2(a_Texcoord1.x,1.0-a_Texcoord1.y)*u_LightmapScaleOffset.xy+u_LightmapScaleOffset.zw;\n#else\nv_LightMapUV=vec2(a_Texcoord0.x,1.0-a_Texcoord0.y)*u_LightmapScaleOffset.xy+u_LightmapScaleOffset.zw;\n#endif\nv_LightMapUV.y=1.0-v_LightMapUV.y;\n#endif\nv_Texcoord1=a_Texcoord1;\n#if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)\nv_Color=a_Color;\n#endif\n#if defined(CALCULATE_SHADOWS)&&!defined(SHADOW_CASCADE)\nv_ShadowCoord=getShadowCoord(vec4(positionWS,1.0));\n#endif\n#if defined(CALCULATE_SPOTSHADOWS)\nv_SpotShadowCoord=u_SpotViewProjectMatrix*vec4(positionWS,1.0);\n#endif\ngl_Position=remapGLPositionZ(gl_Position);}',
        Ai = '#if defined(GL_FRAGMENT_PRECISION_HIGH)\nprecision highp float;precision highp int;\n#else\nprecision mediump float;precision mediump int;\n#endif\n#include "Lighting.glsl";\n#include "Shadow.glsl"\nuniform vec4 u_DiffuseColor;uniform float u_AlbedoIntensity;\n#if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)\nvarying vec4 v_Color;\n#endif\n#ifdef ALPHATEST\nuniform float u_AlphaTestValue;\n#endif\n#ifdef DIFFUSEMAP\nuniform sampler2D u_DiffuseTexture;\n#endif\nvarying vec2 v_Texcoord0;varying vec2 v_Texcoord1;\n#ifdef LIGHTMAP\nvarying vec2 v_LightMapUV;uniform sampler2D u_LightMap;\n#ifdef LIGHTMAP_DIRECTIONAL\nuniform sampler2D u_LightMapDirection;\n#endif\n#endif\nvarying vec3 v_Normal;\n#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)\nvarying vec3 v_ViewDir;uniform vec3 u_MaterialSpecular;uniform float u_Shininess;\n#ifdef LEGACYSINGLELIGHTING\n#ifdef DIRECTIONLIGHT\nuniform DirectionLight u_DirectionLight;\n#endif\n#ifdef POINTLIGHT\nuniform PointLight u_PointLight;\n#endif\n#ifdef SPOTLIGHT\nuniform SpotLight u_SpotLight;\n#endif\n#else\nuniform mat4 u_View;uniform vec4 u_ProjectionParams;uniform vec4 u_Viewport;uniform int u_DirationLightCount;uniform sampler2D u_LightBuffer;uniform sampler2D u_LightClusterBuffer;\n#endif\n#ifdef SPECULARMAP\nuniform sampler2D u_SpecularTexture;\n#endif\n#endif\n#ifdef NORMALMAP\nuniform sampler2D u_NormalTexture;varying vec3 v_Tangent;varying vec3 v_Binormal;\n#endif\n#ifdef FOG\nuniform float u_FogStart;uniform float u_FogRange;uniform vec3 u_FogColor;\n#endif\nvarying vec3 v_PositionWorld;\n#include "GlobalIllumination.glsl";\n#if defined(CALCULATE_SHADOWS)&&!defined(SHADOW_CASCADE)\nvarying vec4 v_ShadowCoord;\n#endif\n#if defined(CALCULATE_SPOTSHADOWS)\nvarying vec4 v_SpotShadowCoord;\n#endif\n#ifdef RAMPTEXTURE\nuniform sampler2D u_RampTexture;\n#endif\nuniform float u_RampThreshold;uniform float u_RampSmooth;uniform vec4 u_HColor;uniform vec4 u_SColor;\n#ifdef THRESHOLDTEXTURE\nuniform sampler2D u_ThresholdTex;\n#endif\nvarying vec2 v_ThresholdUV;\n#ifdef ENABLEHSV\nuniform float u_Shadow_HSV_H;uniform float u_Shadow_HSV_S;uniform float u_Shadow_HSV_V;vec3 rgb2hsv(vec3 c){vec4 K=vec4(0.0,-1.0/3.0,2.0/3.0,-1.0);vec4 p=mix(vec4(c.bg,K.wz),vec4(c.gb,K.xy),step(c.b,c.g));vec4 q=mix(vec4(p.xyw,c.r),vec4(c.r,p.yzx),step(p.x,c.r));float d=q.x-min(q.w,q.y);float e=0.0000000001;return vec3(abs(q.z+(q.w-q.y)/(6.0*d+e)),d/(q.x+e),q.x);}vec3 hsv2rgb(vec3 c){c.g=max(c.g,0.0);vec4 K=vec4(1.0,2.0/3.0,1.0/3.0,3.0);vec3 p=abs(fract(c.xxx+K.xyz)*6.0-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.0,1.0),c.y);}\n#endif\n#ifdef ENABLERIMLIGHT\nuniform vec4 u_RimColor;uniform float u_RimMin;uniform float u_RimMax;\n#endif\nvoid main(){vec3 normal;\n#if defined(NORMALMAP)\nvec3 normalMapSample=texture2D(u_NormalTexture,v_Texcoord0).rgb;normal=normalize(NormalSampleToWorldSpace(normalMapSample,v_Normal,v_Tangent,v_Binormal));\n#else\nnormal=normalize(v_Normal);\n#endif\n#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)\nvec3 viewDir=normalize(v_ViewDir);\n#endif\nLayaGIInput giInput;\n#ifdef LIGHTMAP\ngiInput.lightmapUV=v_LightMapUV;\n#endif\nvec3 globalDiffuse=layaGIBase(giInput,1.0,normal);vec4 mainColor=u_DiffuseColor*u_AlbedoIntensity;\n#ifdef DIFFUSEMAP\nvec4 difTexColor=texture2D(u_DiffuseTexture,v_Texcoord0);mainColor=mainColor*difTexColor;\n#endif\n#if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)\nmainColor=mainColor*v_Color;\n#endif\nvec3 diffuse=vec3(0.0);vec3 specular=vec3(0.0);vec3 transmissionDiffuse=vec3(0.0);\n#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)\nvec3 dif,spe,transmis;float transmissionFactor;\n#ifdef SPECULARMAP\nvec3 gloss=texture2D(u_SpecularTexture,v_Texcoord0).rgb;\n#else\n#ifdef DIFFUSEMAP\nvec3 gloss=vec3(difTexColor.a);\n#else\nvec3 gloss=vec3(1.0);\n#endif\n#endif\n#ifdef THICKNESSMAP\ntransmissionFactor=texture2D(u_ThinknessTexture,v_Texcoord0).r;\n#endif\n#endif\nDirectionLight directionLight;\n#ifdef LEGACYSINGLELIGHTING\n#ifdef DIRECTIONLIGHT\ndirectionLight=u_DirectionLight;\n#endif\n#else\n#ifdef DIRECTIONLIGHT\ndirectionLight=getDirectionLight(u_LightBuffer,0);\n#endif\n#endif\n#ifdef HALFLAMERT\nfloat NdotL=max(0.0,dot(normal,directionLight.direction*-1.0)*0.5+0.5);\n#else\nfloat NdotL=max(0.0,dot(normal,directionLight.direction*-1.0));\n#endif\nvec3 ramp=vec3(0.0);\n#ifdef RAMPTEXTURE\nNdotL=max(0.01,NdotL);ramp=texture2D(u_RampTexture,vec2(NdotL,NdotL)).rgb;\n#else\n#ifdef THRESHOLDTEXTURE\nvec4 TexThresholdColor=texture2D(u_ThresholdTex,v_ThresholdUV);NdotL+=TexThresholdColor.r-0.5;\n#endif\nramp=smoothstep(vec3(u_RampThreshold-u_RampSmooth*0.5),vec3(u_RampThreshold+u_RampSmooth*0.5),vec3(NdotL));\n#endif\n#ifdef ENABLEHSV\nvec3 albedoHsv=rgb2hsv(mainColor.rgb);albedoHsv+=vec3(u_Shadow_HSV_H/360.0,u_Shadow_HSV_S,u_Shadow_HSV_V);mainColor.rgb=mix(hsv2rgb(albedoHsv),mainColor.rgb,ramp);\n#endif\nvec4 sColor=mix(u_HColor,u_SColor,u_SColor.a);ramp=mix(sColor.rgb,u_HColor.rgb,ramp);ramp+=(globalDiffuse*directionLight.color*gloss);mainColor.rgb=mainColor.rgb*ramp;vec3 h=normalize(viewDir-directionLight.direction);float nh=max(0.0,dot(h,normal));vec3 specularColor=directionLight.color*u_MaterialSpecular*pow(nh,u_Shininess*128.0)*gloss*2.0;mainColor.rgb+=specularColor;\n#ifdef ENABLERIMLIGHT\nfloat NdotV=clamp(dot(normal,viewDir),0.0,1.0);float rim=1.0-NdotV;rim=smoothstep(u_RimMin,u_RimMax,rim);NdotL=max(0.0,dot(normal,directionLight.direction*-1.0));vec3 rimColor=NdotL*directionLight.color*rim*u_RimColor.rgb*u_RimColor.a;mainColor.rgb+=rimColor;\n#endif\ngl_FragColor=mainColor;/*\n#ifdef LEGACYSINGLELIGHTING\n#ifdef DIRECTIONLIGHT\nLayaAirBlinnPhongDiectionLight(u_MaterialSpecular,u_Shininess,normal,gloss,viewDir,u_DirectionLight,transmissionFactor,dif,spe,transmis);\n#if defined(CALCULATE_SHADOWS)\n#ifdef SHADOW_CASCADE\nvec4 shadowCoord=getShadowCoord(vec4(v_PositionWorld,1.0));\n#else\nvec4 shadowCoord=v_ShadowCoord;\n#endif\nfloat shadowAttenuation=sampleShadowmap(shadowCoord);dif*=shadowAttenuation;spe*=shadowAttenuation;transmis*=shadowAttenuation;\n#endif\ndiffuse+=dif;specular+=spe;transmissionDiffuse+=transmis;\n#endif\n#ifdef POINTLIGHT\nLayaAirBlinnPhongPointLight(v_PositionWorld,u_MaterialSpecular,u_Shininess,normal,gloss,viewDir,u_PointLight,transmissionFactor,dif,spe,transmis);diffuse+=dif;specular+=spe;transmissionDiffuse+=transmis;\n#endif\n#ifdef SPOTLIGHT\nLayaAirBlinnPhongSpotLight(v_PositionWorld,u_MaterialSpecular,u_Shininess,normal,gloss,viewDir,u_SpotLight,transmissionFactor,dif,spe,transmis);\n#if defined(CALCULATE_SPOTSHADOWS)\nvec4 spotShadowcoord=v_SpotShadowCoord;float spotShadowAttenuation=sampleSpotShadowmap(spotShadowcoord);dif*=spotShadowAttenuation;spe*=spotShadowAttenuation;transmis*=spotShadowAttenuation;\n#endif\ndiffuse+=dif;specular+=spe;transmissionDiffuse+=transmis;\n#endif\n#else\n#ifdef DIRECTIONLIGHT\nfor(int i=0;i<MAX_LIGHT_COUNT;i++){if(i>=u_DirationLightCount)break;DirectionLight directionLight=getDirectionLight(u_LightBuffer,i);\n#if defined(CALCULATE_SHADOWS)\nif(i==0){\n#ifdef SHADOW_CASCADE\nvec4 shadowCoord=getShadowCoord(vec4(v_PositionWorld,1.0));\n#else\nvec4 shadowCoord=v_ShadowCoord;\n#endif\ndirectionLight.color*=sampleShadowmap(shadowCoord);}\n#endif\nLayaAirBlinnPhongDiectionLight(u_MaterialSpecular,u_Shininess,normal,gloss,viewDir,directionLight,transmissionFactor,dif,spe,transmis);diffuse+=dif;specular+=spe;transmissionDiffuse+=transmis;}\n#endif\n#if defined(POINTLIGHT)||defined(SPOTLIGHT)\nivec4 clusterInfo=getClusterInfo(u_LightClusterBuffer,u_View,u_Viewport,v_PositionWorld,gl_FragCoord,u_ProjectionParams);\n#ifdef POINTLIGHT\nfor(int i=0;i<MAX_LIGHT_COUNT;i++){if(i>=clusterInfo.x)break;PointLight pointLight=getPointLight(u_LightBuffer,u_LightClusterBuffer,clusterInfo,i);LayaAirBlinnPhongPointLight(v_PositionWorld,u_MaterialSpecular,u_Shininess,normal,gloss,viewDir,pointLight,transmissionFactor,dif,spe,transmis);diffuse+=dif;specular+=spe;transmissionDiffuse+=transmis;}\n#endif\n#ifdef SPOTLIGHT\nfor(int i=0;i<MAX_LIGHT_COUNT;i++){if(i>=clusterInfo.y)break;SpotLight spotLight=getSpotLight(u_LightBuffer,u_LightClusterBuffer,clusterInfo,i);\n#if defined(CALCULATE_SPOTSHADOWS)\nif(i==0){vec4 spotShadowcoord=v_SpotShadowCoord;spotLight.color*=sampleSpotShadowmap(spotShadowcoord);}\n#endif\nLayaAirBlinnPhongSpotLight(v_PositionWorld,u_MaterialSpecular,u_Shininess,normal,gloss,viewDir,spotLight,transmissionFactor,dif,spe,transmis);diffuse+=dif;specular+=spe;transmissionDiffuse+=transmis;}\n#endif\n#endif\n#endif\n*/\n#ifdef FOG\nfloat lerpFact=clamp((1.0/gl_FragCoord.w-u_FogStart)/u_FogRange,0.0,1.0);gl_FragColor.rgb=mix(gl_FragColor.rgb,u_FogColor,lerpFact);\n#endif\n}',
        wi = function (e) {
            function ToonyColorMaterial() {
                var e;
                return _classCallCheck(this, ToonyColorMaterial), (e = _possibleConstructorReturn(this, _getPrototypeOf(ToonyColorMaterial).call(this))).IsHalfLambert = 0, e.IsHSV = 0, e.IsRimLight = 0, e.setShaderName("ToonyColor"), e._RampThreshold = .8, e._RampSmooth = .25, e._HColor = new Laya.Vector4(222 / 255, 222 / 255, 222 / 255, 1), e._SColor = new Laya.Vector4(130 / 255, 130 / 255, 130 / 255, 1), e
            }
            return _inherits(ToonyColorMaterial, Laya.BlinnPhongMaterial), _createClass(ToonyColorMaterial, [{
                key: "clone",
                value: function () {
                    var e = new ToonyColorMaterial;
                    return e._Color = this._Color, e._MainTex = this._MainTex, e._SColor = this._SColor, e._HColor = this._HColor, e._RampSmooth = this._RampSmooth, e._RampThreshold = this._RampThreshold, e._IsHalfLambert = this._IsHalfLambert, e._RampTex = this._RampTex, e._IsHSV = this._IsHSV, e._Shadow_HSV_H = this._Shadow_HSV_H, e._Shadow_HSV_S = this._Shadow_HSV_S, e._Shadow_HSV_V = this._Shadow_HSV_V, e._SpecGlossMap = this._SpecGlossMap, e._Shininess = this._Shininess, e._SpecColor = this._SpecColor, e._IsRimLight = this._IsRimLight, e._RimColor = this._RimColor, e._RimMin = this._RimMin, e._RimMax = this._RimMax, e._TilingOffset = this._TilingOffset, e._ThresholdTex = this._ThresholdTex, e._ThresholdTilingOffset = this._ThresholdTilingOffset, e._AlbedoIntensity = this._AlbedoIntensity, e._BumpMap = this._BumpMap, e
                }
            }, {
                key: "_Color",
                set: function (e) {
                    this._shaderValues.setVector(ToonyColorMaterial.u_DiffuseColor, e)
                },
                get: function () {
                    return this._shaderValues.getVector(ToonyColorMaterial.u_DiffuseColor)
                }
            }, {
                key: "_AlbedoIntensity",
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.AlbedoIntensity)
                },
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.AlbedoIntensity, e)
                }
            }, {
                key: "_MainTex",
                get: function () {
                    return this._shaderValues.getTexture(ToonyColorMaterial.ALBEDOTEXTURE)
                },
                set: function (e) {
                    e ? this._shaderValues.addDefine(ToonyColorMaterial.SHADERDEFINE_DIFFUSEMAP) : this._shaderValues.removeDefine(ToonyColorMaterial.SHADERDEFINE_DIFFUSEMAP), this._shaderValues.setTexture(ToonyColorMaterial.ALBEDOTEXTURE, e)
                }
            }, {
                key: "_TilingOffset",
                get: function () {
                    return this._shaderValues.getVector(ToonyColorMaterial.TILINGOFFSET)
                },
                set: function (e) {
                    e ? this._shaderValues.setVector(ToonyColorMaterial.TILINGOFFSET, e) : this._shaderValues.getVector(ToonyColorMaterial.TILINGOFFSET).setValue(1, 1, 0, 0)
                }
            }, {
                key: "_RampTex",
                set: function (e) {
                    e ? this._shaderValues.addDefine(ToonyColorMaterial.RAMPTEXTURE) : this._shaderValues.removeDefine(ToonyColorMaterial.RAMPTEXTURE), this._shaderValues.setTexture(ToonyColorMaterial.u_RampTexture, e)
                },
                get: function () {
                    return this._shaderValues.getTexture(ToonyColorMaterial.u_RampTexture)
                }
            }, {
                key: "_SColor",
                set: function (e) {
                    this._shaderValues.setVector(ToonyColorMaterial.u_SColor, e)
                },
                get: function () {
                    return this._shaderValues.getVector(ToonyColorMaterial.u_SColor)
                }
            }, {
                key: "_HColor",
                set: function (e) {
                    this._shaderValues.setVector(ToonyColorMaterial.u_HColor, e)
                },
                get: function () {
                    return this._shaderValues.getVector(ToonyColorMaterial.u_HColor)
                }
            }, {
                key: "_IsHalfLambert",
                set: function (e) {
                    this.IsHalfLambert = e, 1 == this.IsHalfLambert ? this._shaderValues.addDefine(ToonyColorMaterial.HALFLAMERT) : this._shaderValues.removeDefine(ToonyColorMaterial.HALFLAMERT)
                },
                get: function () {
                    return this.IsHalfLambert
                }
            }, {
                key: "_RampSmooth",
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.u_RampSmooth, e)
                },
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.u_RampSmooth)
                }
            }, {
                key: "_RampThreshold",
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.u_RampThreshold, e)
                },
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.u_RampThreshold)
                }
            }, {
                key: "_IsHSV",
                set: function (e) {
                    this.IsHSV = e, 1 == this.IsHSV ? this._shaderValues.addDefine(ToonyColorMaterial.ENABLEHSV) : this._shaderValues.removeDefine(ToonyColorMaterial.ENABLEHSV)
                },
                get: function () {
                    return this.IsHSV
                }
            }, {
                key: "_Shadow_HSV_H",
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.u_Shadow_HSV_H, e)
                },
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.u_Shadow_HSV_H)
                }
            }, {
                key: "_Shadow_HSV_S",
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.u_Shadow_HSV_S, e)
                },
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.u_Shadow_HSV_S)
                }
            }, {
                key: "_Shadow_HSV_V",
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.u_Shadow_HSV_V, e)
                },
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.u_Shadow_HSV_V)
                }
            }, {
                key: "_SpecGlossMap",
                get: function () {
                    return this._shaderValues.getTexture(ToonyColorMaterial.SPECULARTEXTURE)
                },
                set: function (e) {
                    e ? this._shaderValues.addDefine(ToonyColorMaterial.SHADERDEFINE_SPECULARMAP) : this._shaderValues.removeDefine(ToonyColorMaterial.SHADERDEFINE_SPECULARMAP), this._shaderValues.setTexture(ToonyColorMaterial.SPECULARTEXTURE, e)
                }
            }, {
                key: "_Shininess",
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.SHININESS)
                },
                set: function (e) {
                    e = Math.max(0, Math.min(1, e)), this._shaderValues.setNumber(ToonyColorMaterial.SHININESS, e)
                }
            }, {
                key: "_SpecColor",
                get: function () {
                    return this._shaderValues.getVector(ToonyColorMaterial.MATERIALSPECULAR)
                },
                set: function (e) {
                    this._shaderValues.setVector(ToonyColorMaterial.MATERIALSPECULAR, e)
                }
            }, {
                key: "_IsRimLight",
                set: function (e) {
                    this.IsRimLight = e, 1 == this.IsRimLight ? this._shaderValues.addDefine(ToonyColorMaterial.ENABLERIMLIGHT) : this._shaderValues.removeDefine(ToonyColorMaterial.ENABLERIMLIGHT)
                },
                get: function () {
                    return this.IsRimLight
                }
            }, {
                key: "_RimColor",
                set: function (e) {
                    this._shaderValues.setVector(ToonyColorMaterial.u_RimColor, e)
                },
                get: function () {
                    return this._shaderValues.getVector(ToonyColorMaterial.u_RimColor)
                }
            }, {
                key: "_RimMin",
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.u_RimMin, e)
                },
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.u_RimMin)
                }
            }, {
                key: "_RimMax",
                set: function (e) {
                    this._shaderValues.setNumber(ToonyColorMaterial.u_RimMax, e)
                },
                get: function () {
                    return this._shaderValues.getNumber(ToonyColorMaterial.u_RimMax)
                }
            }, {
                key: "_ThresholdTex",
                set: function (e) {
                    e ? this._shaderValues.addDefine(ToonyColorMaterial.THRESHOLDTEXTURE) : this._shaderValues.removeDefine(ToonyColorMaterial.THRESHOLDTEXTURE), this._shaderValues.setTexture(ToonyColorMaterial.u_ThresholdTex, e)
                },
                get: function () {
                    return this._shaderValues.getTexture(ToonyColorMaterial.u_ThresholdTex)
                }
            }, {
                key: "_ThresholdTilingOffset",
                get: function () {
                    return this._shaderValues.getVector(ToonyColorMaterial.u_ThresholdTilingOffset)
                },
                set: function (e) {
                    e ? this._shaderValues.setVector(ToonyColorMaterial.u_ThresholdTilingOffset, e) : this._shaderValues.getVector(ToonyColorMaterial.u_ThresholdTilingOffset).setValue(1, 1, 0, 0)
                }
            }, {
                key: "_BumpMap",
                get: function () {
                    return this._shaderValues.getTexture(ToonyColorMaterial.NORMALTEXTURE)
                },
                set: function (e) {
                    e ? this._shaderValues.addDefine(ToonyColorMaterial.SHADERDEFINE_NORMALMAP) : this._shaderValues.removeDefine(ToonyColorMaterial.SHADERDEFINE_NORMALMAP), this._shaderValues.setTexture(ToonyColorMaterial.NORMALTEXTURE, e)
                }
            }], [{
                key: "init",
                value: function () {
                    Laya.ClassUtils.regClass("Laya.ToonyMobile", ToonyColorMaterial);
                    var e = {
                            a_Position: Laya.VertexMesh.MESH_POSITION0,
                            a_Color: Laya.VertexMesh.MESH_COLOR0,
                            a_Normal: Laya.VertexMesh.MESH_NORMAL0,
                            a_Texcoord0: Laya.VertexMesh.MESH_TEXTURECOORDINATE0,
                            a_Texcoord1: Laya.VertexMesh.MESH_TEXTURECOORDINATE1,
                            a_BoneWeights: Laya.VertexMesh.MESH_BLENDWEIGHT0,
                            a_BoneIndices: Laya.VertexMesh.MESH_BLENDINDICES0,
                            a_Tangent0: Laya.VertexMesh.MESH_TANGENT0,
                            a_WorldMat: Laya.VertexMesh.MESH_WORLDMATRIX_ROW0,
                            a_SimpleTextureParams: Laya.VertexMesh.MESH_SIMPLEANIMATOR
                        },
                        t = {
                            u_Bones: Laya.Shader3D.PERIOD_CUSTOM,
                            u_DiffuseTexture: Laya.Shader3D.PERIOD_MATERIAL,
                            u_SpecularTexture: Laya.Shader3D.PERIOD_MATERIAL,
                            u_NormalTexture: Laya.Shader3D.PERIOD_MATERIAL,
                            u_AlphaTestValue: Laya.Shader3D.PERIOD_MATERIAL,
                            u_DiffuseColor: Laya.Shader3D.PERIOD_MATERIAL,
                            u_AlbedoIntensity: Laya.Shader3D.PERIOD_MATERIAL,
                            u_MaterialSpecular: Laya.Shader3D.PERIOD_MATERIAL,
                            u_Shininess: Laya.Shader3D.PERIOD_MATERIAL,
                            u_TilingOffset: Laya.Shader3D.PERIOD_MATERIAL,
                            u_TransmissionRate: Laya.Shader3D.PERIOD_MATERIAL,
                            u_BackDiffuse: Laya.Shader3D.PERIOD_MATERIAL,
                            u_BackScale: Laya.Shader3D.PERIOD_MATERIAL,
                            u_ThinknessTexture: Laya.Shader3D.PERIOD_MATERIAL,
                            u_TransmissionColor: Laya.Shader3D.PERIOD_MATERIAL,
                            u_WorldMat: Laya.Shader3D.PERIOD_SPRITE,
                            u_MvpMatrix: Laya.Shader3D.PERIOD_SPRITE,
                            u_LightmapScaleOffset: Laya.Shader3D.PERIOD_SPRITE,
                            u_LightMap: Laya.Shader3D.PERIOD_SPRITE,
                            u_LightMapDirection: Laya.Shader3D.PERIOD_SPRITE,
                            u_SimpleAnimatorTexture: Laya.Shader3D.PERIOD_SPRITE,
                            u_SimpleAnimatorParams: Laya.Shader3D.PERIOD_SPRITE,
                            u_SimpleAnimatorTextureSize: Laya.Shader3D.PERIOD_SPRITE,
                            u_CameraPos: Laya.Shader3D.PERIOD_CAMERA,
                            u_Viewport: Laya.Shader3D.PERIOD_CAMERA,
                            u_ProjectionParams: Laya.Shader3D.PERIOD_CAMERA,
                            u_View: Laya.Shader3D.PERIOD_CAMERA,
                            u_ViewProjection: Laya.Shader3D.PERIOD_CAMERA,
                            u_ReflectTexture: Laya.Shader3D.PERIOD_SCENE,
                            u_FogStart: Laya.Shader3D.PERIOD_SCENE,
                            u_FogRange: Laya.Shader3D.PERIOD_SCENE,
                            u_FogColor: Laya.Shader3D.PERIOD_SCENE,
                            u_DirationLightCount: Laya.Shader3D.PERIOD_SCENE,
                            u_LightBuffer: Laya.Shader3D.PERIOD_SCENE,
                            u_LightClusterBuffer: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientColor: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowBias: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowLightDirection: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowMap: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowParams: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowSplitSpheres: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowMatrices: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowMapSize: Laya.Shader3D.PERIOD_SCENE,
                            u_SpotShadowMap: Laya.Shader3D.PERIOD_SCENE,
                            u_SpotViewProjectMatrix: Laya.Shader3D.PERIOD_SCENE,
                            u_ShadowLightPosition: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientSHAr: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientSHAg: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientSHAb: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientSHBr: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientSHBg: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientSHBb: Laya.Shader3D.PERIOD_SCENE,
                            u_AmbientSHC: Laya.Shader3D.PERIOD_SCENE,
                            "u_DirectionLight.color": Laya.Shader3D.PERIOD_SCENE,
                            "u_DirectionLight.direction": Laya.Shader3D.PERIOD_SCENE,
                            "u_PointLight.position": Laya.Shader3D.PERIOD_SCENE,
                            "u_PointLight.range": Laya.Shader3D.PERIOD_SCENE,
                            "u_PointLight.color": Laya.Shader3D.PERIOD_SCENE,
                            "u_SpotLight.position": Laya.Shader3D.PERIOD_SCENE,
                            "u_SpotLight.direction": Laya.Shader3D.PERIOD_SCENE,
                            "u_SpotLight.range": Laya.Shader3D.PERIOD_SCENE,
                            "u_SpotLight.spot": Laya.Shader3D.PERIOD_SCENE,
                            "u_SpotLight.color": Laya.Shader3D.PERIOD_SCENE,
                            u_RampTexture: Laya.Shader3D.PERIOD_MATERIAL,
                            u_RampThreshold: Laya.Shader3D.PERIOD_MATERIAL,
                            u_RampSmooth: Laya.Shader3D.PERIOD_MATERIAL,
                            u_HColor: Laya.Shader3D.PERIOD_MATERIAL,
                            u_SColor: Laya.Shader3D.PERIOD_MATERIAL,
                            u_Shadow_HSV_H: Laya.Shader3D.PERIOD_MATERIAL,
                            u_Shadow_HSV_S: Laya.Shader3D.PERIOD_MATERIAL,
                            u_Shadow_HSV_V: Laya.Shader3D.PERIOD_MATERIAL,
                            u_RimColor: Laya.Shader3D.PERIOD_MATERIAL,
                            u_RimMin: Laya.Shader3D.PERIOD_MATERIAL,
                            u_RimMax: Laya.Shader3D.PERIOD_MATERIAL,
                            u_ThresholdTex: Laya.Shader3D.PERIOD_MATERIAL,
                            u_ThresholdTilingOffset: Laya.Shader3D.PERIOD_MATERIAL
                        },
                        n = {
                            s_Cull: Laya.Shader3D.RENDER_STATE_CULL,
                            s_Blend: Laya.Shader3D.RENDER_STATE_BLEND,
                            s_BlendSrc: Laya.Shader3D.RENDER_STATE_BLEND_SRC,
                            s_BlendDst: Laya.Shader3D.RENDER_STATE_BLEND_DST,
                            s_DepthTest: Laya.Shader3D.RENDER_STATE_DEPTH_TEST,
                            s_DepthWrite: Laya.Shader3D.RENDER_STATE_DEPTH_WRITE
                        },
                        i = Laya.Shader3D.add("ToonyColor", null, null, !0),
                        a = new Laya.SubShader(e, t);
                    i.addSubShader(a), a.addShaderPass(Ti, Ai, n, "Forward")
                }
            }]), ToonyColorMaterial
        }();
    wi.u_RampTexture = Laya.Shader3D.propertyNameToID("u_RampTexture"), wi.u_RampThreshold = Laya.Shader3D.propertyNameToID("u_RampThreshold"), wi.u_RampSmooth = Laya.Shader3D.propertyNameToID("u_RampSmooth"), wi.u_HColor = Laya.Shader3D.propertyNameToID("u_HColor"), wi.u_SColor = Laya.Shader3D.propertyNameToID("u_SColor"), wi.u_Shadow_HSV_H = Laya.Shader3D.propertyNameToID("u_Shadow_HSV_H"), wi.u_Shadow_HSV_S = Laya.Shader3D.propertyNameToID("u_Shadow_HSV_S"), wi.u_Shadow_HSV_V = Laya.Shader3D.propertyNameToID("u_Shadow_HSV_V"), wi.u_RimColor = Laya.Shader3D.propertyNameToID("u_RimColor"), wi.u_RimMin = Laya.Shader3D.propertyNameToID("u_RimMin"), wi.u_RimMax = Laya.Shader3D.propertyNameToID("u_RimMax"), wi.u_ThresholdTex = Laya.Shader3D.propertyNameToID("u_ThresholdTex"), wi.u_ThresholdTilingOffset = Laya.Shader3D.propertyNameToID("u_ThresholdTilingOffset"), wi.u_DiffuseColor = Laya.Shader3D.propertyNameToID("u_DiffuseColor"), wi.ALBEDOTEXTURE = Laya.Shader3D.propertyNameToID("u_DiffuseTexture"), wi.SPECULARTEXTURE = Laya.Shader3D.propertyNameToID("u_SpecularTexture"), wi.SHININESS = Laya.Shader3D.propertyNameToID("u_Shininess"), wi.MATERIALSPECULAR = Laya.Shader3D.propertyNameToID("u_MaterialSpecular"), wi.TILINGOFFSET = Laya.Shader3D.propertyNameToID("u_TilingOffset"), wi.AlbedoIntensity = Laya.Shader3D.propertyNameToID("u_AlbedoIntensity"), wi.NORMALTEXTURE = Laya.Shader3D.propertyNameToID("u_NormalTexture"), wi.RAMPTEXTURE = Laya.Shader3D.getDefineByName("RAMPTEXTURE"), wi.SHADERDEFINE_DIFFUSEMAP = Laya.Shader3D.getDefineByName("DIFFUSEMAP"), wi.HALFLAMERT = Laya.Shader3D.getDefineByName("HALFLAMERT"), wi.ENABLEHSV = Laya.Shader3D.getDefineByName("ENABLEHSV"), wi.SHADERDEFINE_NORMALMAP = Laya.Shader3D.getDefineByName("NORMALMAP"), wi.SHADERDEFINE_SPECULARMAP = Laya.Shader3D.getDefineByName("SPECULARMAP"), wi.ENABLERIMLIGHT = Laya.Shader3D.getDefineByName("ENABLERIMLIGHT"), wi.THRESHOLDTEXTURE = Laya.Shader3D.getDefineByName("THRESHOLDTEXTURE");
    var Ui = function (e) {
        function ToonyOutLineMaterial() {
            var e;
            return _classCallCheck(this, ToonyOutLineMaterial), (e = _possibleConstructorReturn(this, _getPrototypeOf(ToonyOutLineMaterial).call(this)))._outLineWidth = 0, e.setShaderName("ToonyOutLine"), e._RampThreshold = .5, e._RampSmooth = .1, e._HColor = new Laya.Vector4(222 / 255, 222 / 255, 222 / 255, 1), e._SColor = new Laya.Vector4(130 / 255, 130 / 255, 130 / 255, 1), e.outlineWidth = 0, e
        }
        return _inherits(ToonyOutLineMaterial, wi), _createClass(ToonyOutLineMaterial, [{
            key: "showOutLine",
            value: function () {
                this.outlineWidth = this._outLineWidth
            }
        }, {
            key: "hideOutLine",
            value: function () {
                this.outlineWidth = 0
            }
        }, {
            key: "clone",
            value: function () {
                var e = new ToonyOutLineMaterial;
                return e._Color = this._Color, e._MainTex = this._MainTex, e._SColor = this._SColor, e._HColor = this._HColor, e._RampSmooth = this._RampSmooth, e._RampThreshold = this._RampThreshold, e._IsHalfLambert = this._IsHalfLambert, e._RampTex = this._RampTex, e._IsHSV = this._IsHSV, e._Shadow_HSV_H = this._Shadow_HSV_H, e._Shadow_HSV_S = this._Shadow_HSV_S, e._Shadow_HSV_V = this._Shadow_HSV_V, e._SpecGlossMap = this._SpecGlossMap, e._Shininess = this._Shininess, e._SpecColor = this._SpecColor, e._IsRimLight = this._IsRimLight, e._RimColor = this._RimColor, e._RimMin = this._RimMin, e._RimMax = this._RimMax, e._TilingOffset = this._TilingOffset, e._ThresholdTex = this._ThresholdTex, e._ThresholdTilingOffset = this._ThresholdTilingOffset, e._AlbedoIntensity = this._AlbedoIntensity, e._BumpMap = this._BumpMap, e._Outline = this._Outline, e._OutlineColor = this._OutlineColor, e
            }
        }, {
            key: "_OutlineColor",
            set: function (e) {
                this._shaderValues.setVector(ToonyOutLineMaterial.OUTLINECOLOR, e)
            },
            get: function () {
                return this._shaderValues.getVector(ToonyOutLineMaterial.OUTLINECOLOR)
            }
        }, {
            key: "_Outline",
            set: function (e) {
                this._outLineWidth = e, this.outlineWidth = this._outLineWidth
            },
            get: function () {
                return this._outLineWidth
            }
        }, {
            key: "outlineWidth",
            set: function (e) {
                this._shaderValues.setNumber(ToonyOutLineMaterial.OUTLINEWIDTH, e)
            },
            get: function () {
                return this._shaderValues.getNumber(ToonyOutLineMaterial.OUTLINEWIDTH)
            }
        }], [{
            key: "init",
            value: function () {
                Laya.ClassUtils.regClass("Laya.ToonyOutline", ToonyOutLineMaterial);
                var e = {
                        a_Position: Laya.VertexMesh.MESH_POSITION0,
                        a_Color: Laya.VertexMesh.MESH_COLOR0,
                        a_Normal: Laya.VertexMesh.MESH_NORMAL0,
                        a_Texcoord0: Laya.VertexMesh.MESH_TEXTURECOORDINATE0,
                        a_Texcoord1: Laya.VertexMesh.MESH_TEXTURECOORDINATE1,
                        a_BoneWeights: Laya.VertexMesh.MESH_BLENDWEIGHT0,
                        a_BoneIndices: Laya.VertexMesh.MESH_BLENDINDICES0,
                        a_Tangent0: Laya.VertexMesh.MESH_TANGENT0,
                        a_WorldMat: Laya.VertexMesh.MESH_WORLDMATRIX_ROW0,
                        a_SimpleTextureParams: Laya.VertexMesh.MESH_SIMPLEANIMATOR
                    },
                    t = {
                        u_Bones: Laya.Shader3D.PERIOD_CUSTOM,
                        u_DiffuseTexture: Laya.Shader3D.PERIOD_MATERIAL,
                        u_SpecularTexture: Laya.Shader3D.PERIOD_MATERIAL,
                        u_NormalTexture: Laya.Shader3D.PERIOD_MATERIAL,
                        u_AlphaTestValue: Laya.Shader3D.PERIOD_MATERIAL,
                        u_DiffuseColor: Laya.Shader3D.PERIOD_MATERIAL,
                        u_AlbedoIntensity: Laya.Shader3D.PERIOD_MATERIAL,
                        u_MaterialSpecular: Laya.Shader3D.PERIOD_MATERIAL,
                        u_Shininess: Laya.Shader3D.PERIOD_MATERIAL,
                        u_TilingOffset: Laya.Shader3D.PERIOD_MATERIAL,
                        u_TransmissionRate: Laya.Shader3D.PERIOD_MATERIAL,
                        u_BackDiffuse: Laya.Shader3D.PERIOD_MATERIAL,
                        u_BackScale: Laya.Shader3D.PERIOD_MATERIAL,
                        u_ThinknessTexture: Laya.Shader3D.PERIOD_MATERIAL,
                        u_TransmissionColor: Laya.Shader3D.PERIOD_MATERIAL,
                        u_WorldMat: Laya.Shader3D.PERIOD_SPRITE,
                        u_MvpMatrix: Laya.Shader3D.PERIOD_SPRITE,
                        u_LightmapScaleOffset: Laya.Shader3D.PERIOD_SPRITE,
                        u_LightMap: Laya.Shader3D.PERIOD_SPRITE,
                        u_LightMapDirection: Laya.Shader3D.PERIOD_SPRITE,
                        u_SimpleAnimatorTexture: Laya.Shader3D.PERIOD_SPRITE,
                        u_SimpleAnimatorParams: Laya.Shader3D.PERIOD_SPRITE,
                        u_SimpleAnimatorTextureSize: Laya.Shader3D.PERIOD_SPRITE,
                        u_CameraPos: Laya.Shader3D.PERIOD_CAMERA,
                        u_Viewport: Laya.Shader3D.PERIOD_CAMERA,
                        u_ProjectionParams: Laya.Shader3D.PERIOD_CAMERA,
                        u_View: Laya.Shader3D.PERIOD_CAMERA,
                        u_ViewProjection: Laya.Shader3D.PERIOD_CAMERA,
                        u_ReflectTexture: Laya.Shader3D.PERIOD_SCENE,
                        u_FogStart: Laya.Shader3D.PERIOD_SCENE,
                        u_FogRange: Laya.Shader3D.PERIOD_SCENE,
                        u_FogColor: Laya.Shader3D.PERIOD_SCENE,
                        u_DirationLightCount: Laya.Shader3D.PERIOD_SCENE,
                        u_LightBuffer: Laya.Shader3D.PERIOD_SCENE,
                        u_LightClusterBuffer: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientColor: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowBias: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowLightDirection: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowMap: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowParams: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowSplitSpheres: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowMatrices: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowMapSize: Laya.Shader3D.PERIOD_SCENE,
                        u_SpotShadowMap: Laya.Shader3D.PERIOD_SCENE,
                        u_SpotViewProjectMatrix: Laya.Shader3D.PERIOD_SCENE,
                        u_ShadowLightPosition: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientSHAr: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientSHAg: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientSHAb: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientSHBr: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientSHBg: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientSHBb: Laya.Shader3D.PERIOD_SCENE,
                        u_AmbientSHC: Laya.Shader3D.PERIOD_SCENE,
                        "u_DirectionLight.color": Laya.Shader3D.PERIOD_SCENE,
                        "u_DirectionLight.direction": Laya.Shader3D.PERIOD_SCENE,
                        "u_PointLight.position": Laya.Shader3D.PERIOD_SCENE,
                        "u_PointLight.range": Laya.Shader3D.PERIOD_SCENE,
                        "u_PointLight.color": Laya.Shader3D.PERIOD_SCENE,
                        "u_SpotLight.position": Laya.Shader3D.PERIOD_SCENE,
                        "u_SpotLight.direction": Laya.Shader3D.PERIOD_SCENE,
                        "u_SpotLight.range": Laya.Shader3D.PERIOD_SCENE,
                        "u_SpotLight.spot": Laya.Shader3D.PERIOD_SCENE,
                        "u_SpotLight.color": Laya.Shader3D.PERIOD_SCENE,
                        u_RampTexture: Laya.Shader3D.PERIOD_MATERIAL,
                        u_RampThreshold: Laya.Shader3D.PERIOD_MATERIAL,
                        u_RampSmooth: Laya.Shader3D.PERIOD_MATERIAL,
                        u_HColor: Laya.Shader3D.PERIOD_MATERIAL,
                        u_SColor: Laya.Shader3D.PERIOD_MATERIAL,
                        u_Shadow_HSV_H: Laya.Shader3D.PERIOD_MATERIAL,
                        u_Shadow_HSV_S: Laya.Shader3D.PERIOD_MATERIAL,
                        u_Shadow_HSV_V: Laya.Shader3D.PERIOD_MATERIAL,
                        u_RimColor: Laya.Shader3D.PERIOD_MATERIAL,
                        u_RimMin: Laya.Shader3D.PERIOD_MATERIAL,
                        u_RimMax: Laya.Shader3D.PERIOD_MATERIAL,
                        u_ThresholdTex: Laya.Shader3D.PERIOD_MATERIAL,
                        u_ThresholdTilingOffset: Laya.Shader3D.PERIOD_MATERIAL,
                        u_OutlineWidth: Laya.Shader3D.PERIOD_MATERIAL,
                        u_OutlineColor: Laya.Shader3D.PERIOD_MATERIAL
                    },
                    n = {
                        s_Cull: Laya.Shader3D.RENDER_STATE_CULL,
                        s_Blend: Laya.Shader3D.RENDER_STATE_BLEND,
                        s_BlendSrc: Laya.Shader3D.RENDER_STATE_BLEND_SRC,
                        s_BlendDst: Laya.Shader3D.RENDER_STATE_BLEND_DST,
                        s_DepthTest: Laya.Shader3D.RENDER_STATE_DEPTH_TEST,
                        s_DepthWrite: Laya.Shader3D.RENDER_STATE_DEPTH_WRITE
                    },
                    i = Laya.Shader3D.add("ToonyOutLine", null, null, !0),
                    a = new Laya.SubShader(e, t);
                i.addSubShader(a), a.addShaderPass('#if defined(GL_FRAGMENT_PRECISION_HIGH)\nprecision highp float;precision highp int;\n#else\nprecision mediump float;precision mediump int;\n#endif\n#include "Lighting.glsl";\n#include "LayaUtile.glsl"\n#include "Shadow.glsl";\nattribute vec4 a_Position;attribute vec3 a_Normal;\n#ifdef GPU_INSTANCE\nattribute mat4 a_WorldMat;\n#else\nuniform mat4 u_MvpMatrix;uniform mat4 u_WorldMat;\n#endif\nuniform mat4 u_ViewProjection;\n#ifdef BONE\nconst int c_MaxBoneCount=24;attribute vec4 a_BoneIndices;attribute vec4 a_BoneWeights;uniform mat4 u_Bones[c_MaxBoneCount];\n#endif\nuniform float u_OutlineWidth;void main(){mat4 worldMat;mat3 worldInvMat;\n#ifdef GPU_INSTANCE\nworldMat=a_WorldMat;\n#else\nworldMat=u_WorldMat;\n#endif\n#ifdef BONE\nmat4 skinTransform;\n#ifdef SIMPLEBONE\nfloat currentPixelPos;\n#ifdef GPU_INSTANCE\ncurrentPixelPos=a_SimpleTextureParams.x+a_SimpleTextureParams.y;\n#else\ncurrentPixelPos=u_SimpleAnimatorParams.x+u_SimpleAnimatorParams.y;\n#endif\nfloat offset=1.0/u_SimpleAnimatorTextureSize;skinTransform=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.x),offset)*a_BoneWeights.x;skinTransform+=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.y),offset)*a_BoneWeights.y;skinTransform+=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.z),offset)*a_BoneWeights.z;skinTransform+=loadMatFromTexture(currentPixelPos,int(a_BoneIndices.w),offset)*a_BoneWeights.w;\n#else\nskinTransform=u_Bones[int(a_BoneIndices.x)]*a_BoneWeights.x;skinTransform+=u_Bones[int(a_BoneIndices.y)]*a_BoneWeights.y;skinTransform+=u_Bones[int(a_BoneIndices.z)]*a_BoneWeights.z;skinTransform+=u_Bones[int(a_BoneIndices.w)]*a_BoneWeights.w;\n#endif\nworldMat=worldMat*skinTransform;worldInvMat=INVERSE_MAT(mat3(worldMat));\n#else\nworldInvMat=INVERSE_MAT(mat3(worldMat));\n#endif\nvec4 positionWS=worldMat*a_Position;vec3 normalWS=normalize(a_Normal*worldInvMat);positionWS.xyz=positionWS.xyz+normalWS*u_OutlineWidth*0.01;gl_Position=u_ViewProjection*positionWS;gl_Position=remapGLPositionZ(gl_Position);}', "#if defined(GL_FRAGMENT_PRECISION_HIGH)\nprecision highp float;precision highp int;\n#else\nprecision mediump float;precision mediump int;\n#endif\nuniform vec4 u_OutlineColor;void main(){gl_FragColor=vec4(u_OutlineColor.rgb,1.0);}").renderState.cull = Laya.RenderState.CULL_FRONT, a.addShaderPass(Ti, Ai, n, "Forward")
            }
        }]), ToonyOutLineMaterial
    }();
    Ui.OUTLINEWIDTH = Laya.Shader3D.propertyNameToID("u_OutlineWidth"), Ui.OUTLINECOLOR = Laya.Shader3D.propertyNameToID("u_OutlineColor");
    var Di = function (e) {
        function LoginCoverUI() {
            return _classCallCheck(this, LoginCoverUI), _possibleConstructorReturn(this, _getPrototypeOf(LoginCoverUI).apply(this, arguments))
        }
        return _inherits(LoginCoverUI, Fe), _createClass(LoginCoverUI, [{
            key: "OnCreate",
            value: function () {}
        }, {
            key: "OnShow",
            value: function () {}
        }, {
            key: "OnHide",
            value: function () {}
        }, {
            key: "OnDispose",
            value: function () {
                N.getInst().offAllCaller(this)
            }
        }, {
            key: "onClose",
            value: function () {
                j.inst.PopUI(this.layer, !0)
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_bg]
            }
        }]), LoginCoverUI
    }();
    Di = __decorate([ui_register(oe, Ve)], Di);
    var Mi = function (e) {
            function baseUI$x() {
                return _classCallCheck(this, baseUI$x), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$x).apply(this, arguments))
            }
            return _inherits(baseUI$x, fgui.GComponent), baseUI$x
        }(),
        Ei = function (e) {
            function UI_ui_loading() {
                return _classCallCheck(this, UI_ui_loading), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_loading).apply(this, arguments))
            }
            return _inherits(UI_ui_loading, Mi), _createClass(UI_ui_loading, [{
                key: "onConstruct",
                value: function () {
                    this.m_bg = this.getChildAt(0), this.m_img_logo = this.getChildAt(1), this.m_bottom = this.getChildAt(5), this.m_img_jiazaizhong = this.getChildAt(6), this.m_progress_ratio2 = this.getChildAt(7), this.m_progress_ratio = this.getChildAt(8), this.m_t1 = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("Loading", "ui_loading")
                }
            }]), UI_ui_loading
        }();
    Ei.URL = "ui://ibgwcr5zfof24";
    var Ri = function (e) {
            function baseUI$w() {
                return _classCallCheck(this, baseUI$w), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$w).apply(this, arguments))
            }
            return _inherits(baseUI$w, fgui.GComponent), baseUI$w
        }(),
        xi = function (e) {
            function UI_Tips() {
                return _classCallCheck(this, UI_Tips), _possibleConstructorReturn(this, _getPrototypeOf(UI_Tips).apply(this, arguments))
            }
            return _inherits(UI_Tips, Ri), _createClass(UI_Tips, [{
                key: "onConstruct",
                value: function () {
                    this.m_holder = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("Loading", "Tips")
                }
            }]), UI_Tips
        }();
    xi.URL = "ui://ibgwcr5zuv053k";
    var Oi = function (e) {
            function baseUI$v() {
                return _classCallCheck(this, baseUI$v), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$v).apply(this, arguments))
            }
            return _inherits(baseUI$v, fgui.GLabel), baseUI$v
        }(),
        Ni = function (e) {
            function UI_TipsItem() {
                return _classCallCheck(this, UI_TipsItem), _possibleConstructorReturn(this, _getPrototypeOf(UI_TipsItem).apply(this, arguments))
            }
            return _inherits(UI_TipsItem, Oi), _createClass(UI_TipsItem, [{
                key: "onConstruct",
                value: function () {
                    this.m_bg = this.getChildAt(0), this.m_fade = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("Loading", "TipsItem")
                }
            }]), UI_TipsItem
        }();
    Ni.URL = "ui://ibgwcr5zuv053m";
    var Bi = function () {
            function LoadingBinder() {
                _classCallCheck(this, LoadingBinder)
            }
            return _createClass(LoadingBinder, null, [{
                key: "bindAll",
                value: function () {
                    fgui.UIObjectFactory.setExtension(Ei.URL, Ei), fgui.UIObjectFactory.setExtension(xi.URL, xi), fgui.UIObjectFactory.setExtension(Ni.URL, Ni)
                }
            }]), LoadingBinder
        }(),
        Gi = function (e) {
            function LoadingUI() {
                return _classCallCheck(this, LoadingUI), _possibleConstructorReturn(this, _getPrototypeOf(LoadingUI).apply(this, arguments))
            }
            return _inherits(LoadingUI, Fe), _createClass(LoadingUI, [{
                key: "OnCreate",
                value: function () {
                    this.ui.m_progress_ratio.max = 100, this.ui.m_progress_ratio2.max = 100;
                    var e = this.ui.localToGlobalRect(0, this.ui.m_bottom.y, this.ui.width, this.ui.height),
                        t = this.ui.globalToLocal(0, Laya.stage.height - this.ui.m_bottom.height * e.height / this.ui.height);
                    this.ui._children[4].text = "";
                    this.ui.m_bottom.y = t.y, Laya.Browser.onWeiXin
                }
            }, {
                key: "OnShow",
                value: function () {}
            }, {
                key: "OnHide",
                value: function () {
                    var e = Laya.stage.getChildByName("holderImg");
                    e && e.destroy(!0)
                }
            }, {
                key: "OnDispose",
                value: function () {
                    N.getInst().offAllCaller(this)
                }
            }, {
                key: "onClose",
                value: function () {
                    j.inst.PopUI(this.layer, !0)
                }
            }, {
                key: "FullScreenItems",
                get: function () {
                    return [this.ui.m_bg]
                }
            }, {
                key: "subProgressValue",
                set: function (e) {
                    0 == e ? this.ui.m_progress_ratio.value = 100 * e : this.ui.m_progress_ratio.tweenValue(100 * e, .1)
                }
            }, {
                key: "mainProgressValue",
                set: function (e) {
                    0 == e ? this.ui.m_progress_ratio2.value = 100 * e : this.ui.m_progress_ratio2.tweenValue(100 * e, .1)
                }
            }]), LoadingUI
        }();
    Gi = __decorate([ui_register(Ei, Bi)], Gi);
    var Vi = function (e) {
            function baseUI$u() {
                return _classCallCheck(this, baseUI$u), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$u).apply(this, arguments))
            }
            return _inherits(baseUI$u, fgui.GComponent), baseUI$u
        }(),
        zi = function (e) {
            function UI_comp_zhongji() {
                return _classCallCheck(this, UI_comp_zhongji), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_zhongji).apply(this, arguments))
            }
            return _inherits(UI_comp_zhongji, Vi), _createClass(UI_comp_zhongji, [{
                key: "onConstruct",
                value: function () {
                    this.m_full = this.getControllerAt(0), this.m_progress_jindu = this.getChildAt(1), this.m_text_shuliang = this.getChildAt(2), this.m_loader_tubiao = this.getChildAt(3)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_zhongji")
                }
            }]), UI_comp_zhongji
        }();
    zi.URL = "ui://ixnra5xg9pa82q7";
    var Fi = function (e) {
            function baseUI$t() {
                return _classCallCheck(this, baseUI$t), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$t).apply(this, arguments))
            }
            return _inherits(baseUI$t, fgui.GComponent), baseUI$t
        }(),
        Hi = function (e) {
            function UI_comp_headTimer() {
                return _classCallCheck(this, UI_comp_headTimer), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_headTimer).apply(this, arguments))
            }
            return _inherits(UI_comp_headTimer, Fi), _createClass(UI_comp_headTimer, [{
                key: "onConstruct",
                value: function () {
                    this.m_img_timerValue = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_headTimer")
                }
            }]), UI_comp_headTimer
        }();
    Hi.URL = "ui://ixnra5xgaeor10l";
    var ji = function (e) {
            function baseUI$s() {
                return _classCallCheck(this, baseUI$s), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$s).apply(this, arguments))
            }
            return _inherits(baseUI$s, fgui.GButton), baseUI$s
        }(),
        Wi = function (e) {
            function UI_btn_jineng() {
                return _classCallCheck(this, UI_btn_jineng), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_jineng).apply(this, arguments))
            }
            return _inherits(UI_btn_jineng, ji), _createClass(UI_btn_jineng, [{
                key: "onConstruct",
                value: function () {
                    this.m_qiche = this.getControllerAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_jineng")
                }
            }]), UI_btn_jineng
        }();
    Wi.URL = "ui://ixnra5xgd80owu";
    var $i = function (e) {
            function baseUI$r() {
                return _classCallCheck(this, baseUI$r), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$r).apply(this, arguments))
            }
            return _inherits(baseUI$r, fgui.GComponent), baseUI$r
        }(),
        Ki = function (e) {
            function UI_comp_shengji() {
                return _classCallCheck(this, UI_comp_shengji), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_shengji).apply(this, arguments))
            }
            return _inherits(UI_comp_shengji, $i), _createClass(UI_comp_shengji, [{
                key: "onConstruct",
                value: function () {
                    this.m_type = this.getControllerAt(0), this.m_btn_shengji1 = this.getChildAt(1), this.m_btn_shengji2 = this.getChildAt(2), this.m_btn_shengji3 = this.getChildAt(3), this.m_text_biaoti = this.getChildAt(5)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_shengji")
                }
            }]), UI_comp_shengji
        }();
    Ki.URL = "ui://ixnra5xgeml52qh";
    var Yi = function (e) {
            function baseUI$q() {
                return _classCallCheck(this, baseUI$q), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$q).apply(this, arguments))
            }
            return _inherits(baseUI$q, fgui.GButton), baseUI$q
        }(),
        Xi = function (e) {
            function UI_btn_dengji() {
                return _classCallCheck(this, UI_btn_dengji), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_dengji).apply(this, arguments))
            }
            return _inherits(UI_btn_dengji, Yi), _createClass(UI_btn_dengji, [{
                key: "onConstruct",
                value: function () {
                    this.m_type = this.getControllerAt(0), this.m_max = this.getControllerAt(1), this.m_loader_tubiao = this.getChildAt(1), this.m_text_miaoshu = this.getChildAt(2), this.m_list_dengji = this.getChildAt(3), this.m_btn_ = this.getChildAt(4), this.m_btn_get = this.getChildAt(5)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_dengji")
                }
            }]), UI_btn_dengji
        }();
    Xi.URL = "ui://ixnra5xgeml52qi";
    var qi = function (e) {
            function baseUI$p() {
                return _classCallCheck(this, baseUI$p), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$p).apply(this, arguments))
            }
            return _inherits(baseUI$p, fgui.GComponent), baseUI$p
        }(),
        Ji = function (e) {
            function UI_comp_dengji() {
                return _classCallCheck(this, UI_comp_dengji), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_dengji).apply(this, arguments))
            }
            return _inherits(UI_comp_dengji, qi), _createClass(UI_comp_dengji, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_dengji")
                }
            }]), UI_comp_dengji
        }();
    Ji.URL = "ui://ixnra5xgeml52qj";
    var Zi = function (e) {
            function baseUI$o() {
                return _classCallCheck(this, baseUI$o), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$o).apply(this, arguments))
            }
            return _inherits(baseUI$o, fgui.GButton), baseUI$o
        }(),
        Qi = function (e) {
            function UI_btn_shengji() {
                return _classCallCheck(this, UI_btn_shengji), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_shengji).apply(this, arguments))
            }
            return _inherits(UI_btn_shengji, Zi), _createClass(UI_btn_shengji, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(1), this.m_text_chaopiao = this.getChildAt(5)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_shengji")
                }
            }]), UI_btn_shengji
        }();
    Qi.URL = "ui://ixnra5xgeml52qk";
    var ea = function (e) {
            function baseUI$n() {
                return _classCallCheck(this, baseUI$n), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$n).apply(this, arguments))
            }
            return _inherits(baseUI$n, fgui.GButton), baseUI$n
        }(),
        ta = function (e) {
            function UI_btn_xiaotanchaung() {
                return _classCallCheck(this, UI_btn_xiaotanchaung), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_xiaotanchaung).apply(this, arguments))
            }
            return _inherits(UI_btn_xiaotanchaung, ea), _createClass(UI_btn_xiaotanchaung, [{
                key: "onConstruct",
                value: function () {
                    this.m_type = this.getControllerAt(0), this.m_loader_tubiao = this.getChildAt(1), this.m_text_miaoshu = this.getChildAt(3)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_xiaotanchaung")
                }
            }]), UI_btn_xiaotanchaung
        }();
    ta.URL = "ui://ixnra5xgeml52qv";
    var na = function (e) {
            function baseUI$m() {
                return _classCallCheck(this, baseUI$m), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$m).apply(this, arguments))
            }
            return _inherits(baseUI$m, fgui.GComponent), baseUI$m
        }(),
        ia = function (e) {
            function UI_comp_xinshouzhiyin1() {
                return _classCallCheck(this, UI_comp_xinshouzhiyin1), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_xinshouzhiyin1).apply(this, arguments))
            }
            return _inherits(UI_comp_xinshouzhiyin1, na), _createClass(UI_comp_xinshouzhiyin1, [{
                key: "onConstruct",
                value: function () {
                    this.m_t0 = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_xinshouzhiyin1")
                }
            }]), UI_comp_xinshouzhiyin1
        }();
    ia.URL = "ui://ixnra5xgeu6ssh";
    var aa = function (e) {
            function baseUI$l() {
                return _classCallCheck(this, baseUI$l), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$l).apply(this, arguments))
            }
            return _inherits(baseUI$l, fgui.GComponent), baseUI$l
        }(),
        oa = function (e) {
            function UI_comp_flytext() {
                return _classCallCheck(this, UI_comp_flytext), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_flytext).apply(this, arguments))
            }
            return _inherits(UI_comp_flytext, aa), _createClass(UI_comp_flytext, [{
                key: "onConstruct",
                value: function () {
                    this.m_text_value = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_flytext")
                }
            }]), UI_comp_flytext
        }();
    oa.URL = "ui://ixnra5xgfw24104";
    var sa = function (e) {
            function baseUI$k() {
                return _classCallCheck(this, baseUI$k), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$k).apply(this, arguments))
            }
            return _inherits(baseUI$k, fgui.GButton), baseUI$k
        }(),
        ra = function (e) {
            function UI_btn_close1() {
                return _classCallCheck(this, UI_btn_close1), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_close1).apply(this, arguments))
            }
            return _inherits(UI_btn_close1, sa), _createClass(UI_btn_close1, [{
                key: "onConstruct",
                value: function () {
                    this.m_loader_wenzi = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_close1")
                }
            }]), UI_btn_close1
        }();
    ra.URL = "ui://ixnra5xggq2m11j";
    var la = function (e) {
            function baseUI$j() {
                return _classCallCheck(this, baseUI$j), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$j).apply(this, arguments))
            }
            return _inherits(baseUI$j, fgui.GComponent), baseUI$j
        }(),
        ua = function (e) {
            function UI_comp_tips() {
                return _classCallCheck(this, UI_comp_tips), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_tips).apply(this, arguments))
            }
            return _inherits(UI_comp_tips, la), _createClass(UI_comp_tips, [{
                key: "onConstruct",
                value: function () {
                    this.m_text_str = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_tips")
                }
            }]), UI_comp_tips
        }();
    ua.URL = "ui://ixnra5xghp2hd6";
    var ha = function (e) {
            function baseUI$i() {
                return _classCallCheck(this, baseUI$i), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$i).apply(this, arguments))
            }
            return _inherits(baseUI$i, fgui.GButton), baseUI$i
        }(),
        ca = function (e) {
            function UI_btn_fenxiang() {
                return _classCallCheck(this, UI_btn_fenxiang), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_fenxiang).apply(this, arguments))
            }
            return _inherits(UI_btn_fenxiang, ha), _createClass(UI_btn_fenxiang, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_fenxiang")
                }
            }]), UI_btn_fenxiang
        }();
    ca.URL = "ui://ixnra5xghzfqui";
    var da = function (e) {
            function baseUI$h() {
                return _classCallCheck(this, baseUI$h), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$h).apply(this, arguments))
            }
            return _inherits(baseUI$h, fgui.GComponent), baseUI$h
        }(),
        fa = function (e) {
            function UI_comp_jinbidonghua_kekong() {
                return _classCallCheck(this, UI_comp_jinbidonghua_kekong), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_jinbidonghua_kekong).apply(this, arguments))
            }
            return _inherits(UI_comp_jinbidonghua_kekong, da), _createClass(UI_comp_jinbidonghua_kekong, [{
                key: "onConstruct",
                value: function () {
                    this.m_t0 = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_jinbidonghua_kekong")
                }
            }]), UI_comp_jinbidonghua_kekong
        }();
    fa.URL = "ui://ixnra5xgijcn8p";
    var _a = function (e) {
            function baseUI$g() {
                return _classCallCheck(this, baseUI$g), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$g).apply(this, arguments))
            }
            return _inherits(baseUI$g, fgui.GButton), baseUI$g
        }(),
        ya = function (e) {
            function UI_btn_ad1() {
                return _classCallCheck(this, UI_btn_ad1), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_ad1).apply(this, arguments))
            }
            return _inherits(UI_btn_ad1, _a), _createClass(UI_btn_ad1, [{
                key: "onConstruct",
                value: function () {
                    this.m_loader_wenzi = this.getChildAt(1), this.m_text_shijian = this.getChildAt(2)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_ad1")
                }
            }]), UI_btn_ad1
        }();
    ya.URL = "ui://ixnra5xgky3h2rb";
    var pa = function (e) {
            function baseUI$f() {
                return _classCallCheck(this, baseUI$f), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$f).apply(this, arguments))
            }
            return _inherits(baseUI$f, fgui.GButton), baseUI$f
        }(),
        ga = function (e) {
            function UI_btn_laobanniang() {
                return _classCallCheck(this, UI_btn_laobanniang), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_laobanniang).apply(this, arguments))
            }
            return _inherits(UI_btn_laobanniang, pa), _createClass(UI_btn_laobanniang, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(1), this.m_cd = this.getChildAt(2)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_laobanniang")
                }
            }]), UI_btn_laobanniang
        }();
    ga.URL = "ui://ixnra5xgmvoo2r2";
    var va = function (e) {
            function baseUI$e() {
                return _classCallCheck(this, baseUI$e), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$e).apply(this, arguments))
            }
            return _inherits(baseUI$e, fgui.GButton), baseUI$e
        }(),
        ma = function (e) {
            function UI_btn_close() {
                return _classCallCheck(this, UI_btn_close), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_close).apply(this, arguments))
            }
            return _inherits(UI_btn_close, va), _createClass(UI_btn_close, [{
                key: "onConstruct",
                value: function () {
                    this.m_adbg = this.getControllerAt(0), this.m_loader_wenzi = this.getChildAt(2)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_close")
                }
            }]), UI_btn_close
        }();
    ma.URL = "ui://ixnra5xgn8gl70";
    var Ca = function (e) {
            function baseUI$d() {
                return _classCallCheck(this, baseUI$d), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$d).apply(this, arguments))
            }
            return _inherits(baseUI$d, fgui.GButton), baseUI$d
        }(),
        ka = function (e) {
            function UI_btn_ad() {
                return _classCallCheck(this, UI_btn_ad), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_ad).apply(this, arguments))
            }
            return _inherits(UI_btn_ad, Ca), _createClass(UI_btn_ad, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(0), this.m_c2 = this.getControllerAt(1), this.m_adbg = this.getControllerAt(2), this.m_text_shuzi = this.getChildAt(4), this.m_loader_wenzi = this.getChildAt(5), this.m_group_wenzi = this.getChildAt(6)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_ad")
                }
            }]), UI_btn_ad
        }();
    ka.URL = "ui://ixnra5xgn8gl74";
    var Sa = function (e) {
            function baseUI$c() {
                return _classCallCheck(this, baseUI$c), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$c).apply(this, arguments))
            }
            return _inherits(baseUI$c, fgui.GComponent), baseUI$c
        }(),
        Ia = function (e) {
            function UI_comp_mengban() {
                return _classCallCheck(this, UI_comp_mengban), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_mengban).apply(this, arguments))
            }
            return _inherits(UI_comp_mengban, Sa), _createClass(UI_comp_mengban, [{
                key: "onConstruct",
                value: function () {
                    this.m_graph_mengban = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_mengban")
                }
            }]), UI_comp_mengban
        }();
    Ia.URL = "ui://ixnra5xgn8gl8m";
    var ba = function (e) {
            function baseUI$b() {
                return _classCallCheck(this, baseUI$b), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$b).apply(this, arguments))
            }
            return _inherits(baseUI$b, fgui.GComponent), baseUI$b
        }(),
        La = function (e) {
            function UI_comp_upgradeTip() {
                return _classCallCheck(this, UI_comp_upgradeTip), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_upgradeTip).apply(this, arguments))
            }
            return _inherits(UI_comp_upgradeTip, ba), _createClass(UI_comp_upgradeTip, [{
                key: "onConstruct",
                value: function () {
                    this.m_loader_tubiao = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_upgradeTip")
                }
            }]), UI_comp_upgradeTip
        }();
    La.URL = "ui://ixnra5xgq28rzo";
    var Pa = function (e) {
            function baseUI$a() {
                return _classCallCheck(this, baseUI$a), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$a).apply(this, arguments))
            }
            return _inherits(baseUI$a, fgui.GComponent), baseUI$a
        }(),
        Ta = function (e) {
            function UI_PlayerUP() {
                return _classCallCheck(this, UI_PlayerUP), _possibleConstructorReturn(this, _getPrototypeOf(UI_PlayerUP).apply(this, arguments))
            }
            return _inherits(UI_PlayerUP, Pa), _createClass(UI_PlayerUP, [{
                key: "onConstruct",
                value: function () {
                    this.m_close = this.getControllerAt(0), this.m_bg = this.getChildAt(0), this.m_view = this.getChildAt(1), this.m_btn_close0 = this.getChildAt(2), this.m_btn_close1 = this.getChildAt(3), this.m_btn_close2 = this.getChildAt(4)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "PlayerUP")
                }
            }]), UI_PlayerUP
        }();
    Ta.URL = "ui://ixnra5xgqbia2qw";
    var Aa = function (e) {
            function baseUI$9() {
                return _classCallCheck(this, baseUI$9), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$9).apply(this, arguments))
            }
            return _inherits(baseUI$9, fgui.GComponent), baseUI$9
        }(),
        wa = function (e) {
            function UI_SupporterUP() {
                return _classCallCheck(this, UI_SupporterUP), _possibleConstructorReturn(this, _getPrototypeOf(UI_SupporterUP).apply(this, arguments))
            }
            return _inherits(UI_SupporterUP, Aa), _createClass(UI_SupporterUP, [{
                key: "onConstruct",
                value: function () {
                    this.m_close = this.getControllerAt(0), this.m_bg = this.getChildAt(0), this.m_view = this.getChildAt(1), this.m_btn_close0 = this.getChildAt(2), this.m_btn_close1 = this.getChildAt(3), this.m_btn_close2 = this.getChildAt(4)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "SupporterUP")
                }
            }]), UI_SupporterUP
        }();
    wa.URL = "ui://ixnra5xgqbia2qy";
    var Ua = function (e) {
            function baseUI$8() {
                return _classCallCheck(this, baseUI$8), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$8).apply(this, arguments))
            }
            return _inherits(baseUI$8, fgui.GButton), baseUI$8
        }(),
        Da = function (e) {
            function UI_btn_tanchu() {
                return _classCallCheck(this, UI_btn_tanchu), _possibleConstructorReturn(this, _getPrototypeOf(UI_btn_tanchu).apply(this, arguments))
            }
            return _inherits(UI_btn_tanchu, Ua), _createClass(UI_btn_tanchu, [{
                key: "onConstruct",
                value: function () {
                    this.m_c1 = this.getControllerAt(1), this.m_loader_tubiao = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "btn_tanchu")
                }
            }]), UI_btn_tanchu
        }();
    Da.URL = "ui://ixnra5xgrngq2r6";
    var Ma = function (e) {
            function baseUI$7() {
                return _classCallCheck(this, baseUI$7), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$7).apply(this, arguments))
            }
            return _inherits(baseUI$7, fgui.GComponent), baseUI$7
        }(),
        Ea = function (e) {
            function UI_ADPanel$1() {
                return _classCallCheck(this, UI_ADPanel$1), _possibleConstructorReturn(this, _getPrototypeOf(UI_ADPanel$1).apply(this, arguments))
            }
            return _inherits(UI_ADPanel$1, Ma), _createClass(UI_ADPanel$1, [{
                key: "onConstruct",
                value: function () {
                    this.m_mask = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "ADPanel")
                }
            }]), UI_ADPanel$1
        }();
    Ea.URL = "ui://ixnra5xguv052q9";
    var Ra = function (e) {
            function baseUI$6() {
                return _classCallCheck(this, baseUI$6), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$6).apply(this, arguments))
            }
            return _inherits(baseUI$6, fgui.GComponent), baseUI$6
        }(),
        xa = function (e) {
            function UI_Holder() {
                return _classCallCheck(this, UI_Holder), _possibleConstructorReturn(this, _getPrototypeOf(UI_Holder).apply(this, arguments))
            }
            return _inherits(UI_Holder, Ra), _createClass(UI_Holder, [{
                key: "onConstruct",
                value: function () {
                    this.m_test = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "Holder")
                }
            }]), UI_Holder
        }();
    xa.URL = "ui://ixnra5xguv052qa";
    var Oa = function (e) {
            function baseUI$5() {
                return _classCallCheck(this, baseUI$5), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$5).apply(this, arguments))
            }
            return _inherits(baseUI$5, fgui.GComponent), baseUI$5
        }(),
        Na = function (e) {
            function UI_JoyStick() {
                return _classCallCheck(this, UI_JoyStick), _possibleConstructorReturn(this, _getPrototypeOf(UI_JoyStick).apply(this, arguments))
            }
            return _inherits(UI_JoyStick, Oa), _createClass(UI_JoyStick, [{
                key: "onConstruct",
                value: function () {
                    this.m_holder = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "JoyStick")
                }
            }]), UI_JoyStick
        }();
    Na.URL = "ui://ixnra5xguv052qb";
    var Ba = function (e) {
            function baseUI$4() {
                return _classCallCheck(this, baseUI$4), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$4).apply(this, arguments))
            }
            return _inherits(baseUI$4, fgui.GLabel), baseUI$4
        }(),
        Ga = function (e) {
            function UI_comp_jinbi() {
                return _classCallCheck(this, UI_comp_jinbi), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_jinbi).apply(this, arguments))
            }
            return _inherits(UI_comp_jinbi, Ba), _createClass(UI_comp_jinbi, [{
                key: "onConstruct",
                value: function () {
                    this.m_tag = this.getChildAt(1)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "comp_jinbi")
                }
            }]), UI_comp_jinbi
        }();
    Ga.URL = "ui://ixnra5xgyyz11l";
    var Va = function (e) {
            function baseUI$3() {
                return _classCallCheck(this, baseUI$3), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$3).apply(this, arguments))
            }
            return _inherits(baseUI$3, fgui.GComponent), baseUI$3
        }(),
        za = function (e) {
            function UI_ui_main() {
                return _classCallCheck(this, UI_ui_main), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_main).apply(this, arguments))
            }
            return _inherits(UI_ui_main, Va), _createClass(UI_ui_main, [{
                key: "onConstruct",
                value: function () {
                    this.m_tt = this.getControllerAt(0), this.m_bg = this.getChildAt(0), this.m_joyStick = this.getChildAt(1), this.m_comp_finger = this.getChildAt(2), this.m_comp_zhongjimubiao = this.getChildAt(3), this.m_comp_chaopiao = this.getChildAt(4), this.m_btn_fenxiang = this.getChildAt(5), this.m_btn_more = this.getChildAt(6), this.m_btn_yuangong = this.getChildAt(7), this.m_btn_wurenji = this.getChildAt(8), this.m_btn_jineng = this.getChildAt(9), this.m_ad = this.getChildAt(10), this.m_right = this.getChildAt(11), this.m_btn_setting = this.getChildAt(12), this.m_btn_ditu = this.getChildAt(13), this.m_btn_lbn = this.getChildAt(14), this.m_btn_share = this.getChildAt(15), this.m_left = this.getChildAt(16), this.m_btn_xiaotanchuang = this.getChildAt(17), this.m_unlockTips = this.getChildAt(18), this.m_t0 = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "ui_main")
                }
            }]), UI_ui_main
        }();
    za.URL = "ui://ixnra5xgyyz1u";
    var Fa = function () {
            function mainBinder() {
                _classCallCheck(this, mainBinder)
            }
            return _createClass(mainBinder, null, [{
                key: "bindAll",
                value: function () {
                    fgui.UIObjectFactory.setExtension(zi.URL, zi), fgui.UIObjectFactory.setExtension(Hi.URL, Hi), fgui.UIObjectFactory.setExtension(Wi.URL, Wi), fgui.UIObjectFactory.setExtension(Ki.URL, Ki), fgui.UIObjectFactory.setExtension(Xi.URL, Xi), fgui.UIObjectFactory.setExtension(Ji.URL, Ji), fgui.UIObjectFactory.setExtension(Qi.URL, Qi), fgui.UIObjectFactory.setExtension(ta.URL, ta), fgui.UIObjectFactory.setExtension(ia.URL, ia), fgui.UIObjectFactory.setExtension(oa.URL, oa), fgui.UIObjectFactory.setExtension(ra.URL, ra), fgui.UIObjectFactory.setExtension(ua.URL, ua), fgui.UIObjectFactory.setExtension(ca.URL, ca), fgui.UIObjectFactory.setExtension(fa.URL, fa), fgui.UIObjectFactory.setExtension(ya.URL, ya), fgui.UIObjectFactory.setExtension(ga.URL, ga), fgui.UIObjectFactory.setExtension(ma.URL, ma), fgui.UIObjectFactory.setExtension(ka.URL, ka), fgui.UIObjectFactory.setExtension(Ia.URL, Ia), fgui.UIObjectFactory.setExtension(La.URL, La), fgui.UIObjectFactory.setExtension(Ta.URL, Ta), fgui.UIObjectFactory.setExtension(wa.URL, wa), fgui.UIObjectFactory.setExtension(Da.URL, Da), fgui.UIObjectFactory.setExtension(Ea.URL, Ea), fgui.UIObjectFactory.setExtension(xa.URL, xa), fgui.UIObjectFactory.setExtension(Na.URL, Na), fgui.UIObjectFactory.setExtension(Ga.URL, Ga), fgui.UIObjectFactory.setExtension(za.URL, za)
                }
            }]), mainBinder
        }(),
        Ha = function (e) {
            function baseUI$2() {
                return _classCallCheck(this, baseUI$2), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$2).apply(this, arguments))
            }
            return _inherits(baseUI$2, fgui.GComponent), baseUI$2
        }(),
        ja = function (e) {
            function UI_ADPanel() {
                return _classCallCheck(this, UI_ADPanel), _possibleConstructorReturn(this, _getPrototypeOf(UI_ADPanel).apply(this, arguments))
            }
            return _inherits(UI_ADPanel, Ha), _createClass(UI_ADPanel, [{
                key: "onConstruct",
                value: function () {
                    this.m_mask = this.getChildAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("main", "ADPanel")
                }
            }]), UI_ADPanel
        }();
    ja.URL = "ui://ixnra5xguv052q9";
    var Wa, $a, Ka = function (e) {
        function ADPanel() {
            return _classCallCheck(this, ADPanel), _possibleConstructorReturn(this, _getPrototypeOf(ADPanel).apply(this, arguments))
        }
        return _inherits(ADPanel, Fe), _createClass(ADPanel, [{
            key: "OnCreate",
            value: function () {
                Laya.Browser.onTTMiniGame && !Pn.TTShengHe && mt.showBanner()
            }
        }, {
            key: "OnShow",
            value: function () {
                Laya.Browser.onMiniGame
            }
        }, {
            key: "OnHide",
            value: function () {
                Laya.Browser.onMiniGame
            }
        }, {
            key: "OnDispose",
            value: function () {}
        }]), ADPanel
    }();
    Ka = __decorate([ui_register(ja, Fa)], Ka),
        function (e) {
            e[e["角色移动速度"] = 0] = "角色移动速度", e[e["角色容量"] = 1] = "角色容量", e[e["货币价值"] = 2] = "货币价值", e[e["员工移动速度"] = 3] = "员工移动速度", e[e["员工容量"] = 4] = "员工容量"
        }($a || ($a = {}));
    var Ya = Wa = function (e) {
        function UpgradeAD() {
            var e;
            return _classCallCheck(this, UpgradeAD), (e = _possibleConstructorReturn(this, _getPrototypeOf(UpgradeAD).apply(this, arguments))).isShow = !1, e
        }
        return _inherits(UpgradeAD, Rt), _createClass(UpgradeAD, [{
            key: "onStart",
            value: function () {
                this.showAD(), N.getInst().on(Et.HideCircleADUI, this, this.onHideCircleADUI), N.getInst().on(Et.UpgradeSkillNotice, this, this.switchAD)
            }
        }, {
            key: "onDestroy",
            value: function () {
                N.getInst().event(Et.HideCircleAD), this.ClearAsycFunc()
            }
        }, {
            key: "onUpdate",
            value: function () {
                this.isShow && N.getInst().event(Et.UpdateCircleAD, this.TipsPos.transform.position, this.sType)
            }
        }, {
            key: "showAD",
            value: function () {
                if (this.sType = this.getShowType(), null != this.sType) {
                    var e = Laya.Sprite3D.instantiate(qt.getInst().GetPrefab(Ot.AdUnlockTag)).getComponent(Un);
                    this.sp.addChild(e.sp), this.tag = e.sp, e.transform.rotationEuler = new Laya.Vector3(0, 90, 0), e.transform.localScale = new Laya.Vector3(.7, .7, .7), e.useAD = !1, e.FullCB = this.onTrigger.bind(this), this.switchAD(this.sType), this.isShow = !0
                } else this.sp.destroy(!0)
            }
        }, {
            key: "switchAD",
            value: function (e) {
                0 != this.isShow && (this.sType = e || this.getShowType(), null == this.sType ? this.sp.destroy(!0) : (N.getInst().event(Et.ShowCircleAD, this.sType), Laya.timer.once(15e3, this, this.switchAD)))
            }
        }, {
            key: "onTrigger",
            value: function () {
                var e = this;
                this.isShow = !1, Laya.timer.clear(this, this.switchAD), N.getInst().event(Et.HideCircleAD), mt.showADVideo(this, function (t) {
                    var n = 18e4;
                    t ? e.onClickAD(e.sType) : n = 12e4, Laya.timer.once(n, e, e.showAD)
                }, "Floor AD")
            }
        }, {
            key: "onClickAD",
            value: function (e) {
                switch (e) {
                    case $a.角色移动速度:
                        Wt.inst.SpeedLevel++;
                        break;
                    case $a.角色容量:
                        Wt.inst.StackLevel++;
                        break;
                    case $a.货币价值:
                        Wt.inst.PriceLevel++;
                        break;
                    case $a.员工移动速度:
                        Wt.inst.ShopSupportSpeedLevel++;
                        break;
                    case $a.员工容量:
                        Wt.inst.ShopSupportStackLevel++
                }
            }
        }, {
            key: "onHideCircleADUI",
            value: function () {
                this.isShow = !1, this.tag && !this.tag.destroyed && (this.tag.destroy(!0), this.tag = null), N.getInst().event(Et.HideCircleAD)
            }
        }, {
            key: "getShowType",
            value: function () {
                var e = [];
                return Wt.inst.ShopSupportIsMaxSpeedLevel || e.push($a.员工移动速度), Wt.inst.ShopSupportIsMaxStackLevel || e.push($a.员工容量), Wt.inst.ShopUnlockLevel >= 8 && (Wt.inst.IsMaxSpeedLevel || e.push($a.角色移动速度), Wt.inst.IsMaxStackLevel || e.push($a.角色容量), Wt.inst.IsMaxPriceLevel || e.push($a.货币价值)), 0 == e.length ? null : M.rand(e)
            }
        }], [{
            key: "Init",
            value: function () {
                Laya.ClassUtils.regClass("UpgradeAD", Wa)
            }
        }]), UpgradeAD
    }();
    __decorate([bind_node()], Ya.prototype, "TipsPos", void 0), Ya = Wa = __decorate([auto_bind_node()], Ya);
    var Xa = function (e) {
        function QiCheUI() {
            return _classCallCheck(this, QiCheUI), _possibleConstructorReturn(this, _getPrototypeOf(QiCheUI).apply(this, arguments))
        }//todo:载具就界面
        return _inherits(QiCheUI, Fe), _createClass(QiCheUI, [{
            key: "_refreshAdVisible",
            value: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0] || !mt.isAdUser();
                this.ui.m_btn_ad1.visible = e, this.ui.m_btn_ad.visible = !e, e || this._addTimer()
            }
        }, {
            key: "_addTimer",
            value: function () {
                this._btnCD = 3, this._refreshBtnCD(), Laya.timer.loop(1e3, this, this._btnTimer)
            }
        }, {
            key: "_removeTimer",
            value: function () {
                Laya.timer.clear(this, this._btnTimer), this._refreshAdVisible(!0), this._refreshBtnCD()
            }
        }, {
            key: "_btnTimer",
            value: function () {
                this._btnCD--, this._refreshBtnCD(), 0 == this._btnCD && this.onClickGet()
            }
        }, {
            key: "_refreshBtnCD",
            value: function () {
                this.ui.m_btn_ad.getChild("text_shijian").text = this._btnCD + ""
            }
        }, {
            key: "OnCreate",
            value: function () {
                this.ui.m_btn_ad.onClick(this, this.onClickGet), this.ui.m_btn_ad1.onClick(this, this.onClickGet), this.ui.m_btn_close0.onClick(this, this.onClickClose), this.ui.m_btn_close1.onClick(this, this.onClickClose), this.ui.m_btn_close2.onClick(this, this.onClickClose)
            }
        }, {
            key: "OnShow",
            value: function () {
                this.ui.m_switch.selectedIndex = Pn.switch
            }
        }, {
            key: "OnHide",
            value: function () {
                this._removeTimer()
            }
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "onClickGet",
            value: function () {
                var e = this;
                this._removeTimer(), mt.showADVideo(this, function (t) {
                    t && (Wt.inst.UnlockDunLun = !0, N.getInst().event(Et.SwitchDuLun), e.onClickClose())
                }, "Vehicles")
            }
        }, {
            key: "onClickClose",
            value: function () {
				Plat.I.ShowInter()
                j.inst.PopUI(this.layer, !0)
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_com_mengban]
            }
        }]), QiCheUI
    }();
    __decorate([throttle(1e3)], Xa.prototype, "onClickGet", null), Xa = __decorate([ui_register(on, Ln)], Xa);
    var qa = function (e) {
            function baseUI$1() {
                return _classCallCheck(this, baseUI$1), _possibleConstructorReturn(this, _getPrototypeOf(baseUI$1).apply(this, arguments))
            }
            return _inherits(baseUI$1, fgui.GComponent), baseUI$1
        }(),
        Ja = function (e) {
            function UI_ui_setting() {
                return _classCallCheck(this, UI_ui_setting), _possibleConstructorReturn(this, _getPrototypeOf(UI_ui_setting).apply(this, arguments))
            }
            return _inherits(UI_ui_setting, qa), _createClass(UI_ui_setting, [{
                key: "onConstruct",
                value: function () {
                    this.m_comp_mengban = this.getChildAt(0), this.m_comp_shezhineirong = this.getChildAt(1), this.m_btn_fanhui = this.getChildAt(2), this.m_t0 = this.getTransitionAt(0)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("setting", "ui_setting")
                }
            }]), UI_ui_setting
        }();
    Ja.URL = "ui://lzkirqqhc75x0";
    var Za = function (e) {
            function baseUI() {
                return _classCallCheck(this, baseUI), _possibleConstructorReturn(this, _getPrototypeOf(baseUI).apply(this, arguments))
            }
            return _inherits(baseUI, fgui.GComponent), baseUI
        }(),
        Qa = function (e) {
            function UI_comp_shezhi() {
                return _classCallCheck(this, UI_comp_shezhi), _possibleConstructorReturn(this, _getPrototypeOf(UI_comp_shezhi).apply(this, arguments))
            }
            return _inherits(UI_comp_shezhi, Za), _createClass(UI_comp_shezhi, [{
                key: "onConstruct",
                value: function () {
                    this.m_img_bg = this.getChildAt(0), this.m_img_biaoti = this.getChildAt(1), this.m_btn_yinxiao = this.getChildAt(2), this.m_btn_yinyue = this.getChildAt(3), this.m_btn_shock = this.getChildAt(4), this.m_btn_yinsi = this.getChildAt(8)
                }
            }], [{
                key: "createInstance",
                value: function () {
                    return fgui.UIPackage.createObject("setting", "comp_shezhi")
                }
            }]), UI_comp_shezhi
        }();
    Qa.URL = "ui://lzkirqqhn8glj";
    var eo = function () {
            function settingBinder() {
                _classCallCheck(this, settingBinder)
            }
            return _createClass(settingBinder, null, [{
                key: "bindAll",
                value: function () {
                    fgui.UIObjectFactory.setExtension(Ja.URL, Ja), fgui.UIObjectFactory.setExtension(Qa.URL, Qa)
                }
            }]), settingBinder
        }(),
        to = function (t) {
            function SettingUI() {//todo:设置界面
                return _classCallCheck(this, SettingUI), _possibleConstructorReturn(this, _getPrototypeOf(SettingUI).apply(this, arguments))
            }
            return _inherits(SettingUI, Fe), _createClass(SettingUI, [{
                key: "OnCreate",
                value: function () {
                    var e = this,
                        t = this.ui.localToGlobal(this.ui.m_btn_fanhui.x, this.ui.m_btn_fanhui.y);
                    t.x = 0, t = this.ui.globalToLocal(t.x, t.y, t), this.ui.m_btn_fanhui.x = t.x, this.ui.m_btn_fanhui.onClick(this, function () {
                        j.inst.PopUI(e.layer, !1)
                    }), this.ui.m_comp_shezhineirong.m_btn_shock.onClick(this, this.onSettingChange), this.ui.m_comp_shezhineirong.m_btn_yinxiao.onClick(this, this.onSettingChange), this.ui.m_comp_shezhineirong.m_btn_yinyue.onClick(this, this.onMusiceChange), this.ui.m_comp_shezhineirong.m_btn_yinsi.onClick(this, this.yinshi)
                }
            }, {
                key: "yinshi",
                value: function () {
                    j.inst.PushUI(Ye, e.yinSi, 0)
                }
            }, {
                key: "OnShow",
                value: function () {
                    this.ui.m_comp_shezhineirong.m_btn_shock.selected = !G.inst.vibrate, this.ui.m_comp_shezhineirong.m_btn_yinxiao.selected = !G.inst.sound, this.ui.m_comp_shezhineirong.m_btn_yinyue.selected = !G.inst.music
                }
            }, {
                key: "onSettingChange",
                value: function () {
                    G.inst.vibrate = !this.ui.m_comp_shezhineirong.m_btn_shock.selected, G.inst.sound = !this.ui.m_comp_shezhineirong.m_btn_yinxiao.selected, N.getInst().event(x.Setting)
                }
            }, {
                key: "onMusiceChange",
                value: function () {
                    G.inst.music = !this.ui.m_comp_shezhineirong.m_btn_yinyue.selected, N.getInst().event(x.Setting)
                }
            }, {
                key: "OnHide",
                value: function () {
                    mt.hideBanner()
                }
            }, {
                key: "OnDispose",
                value: function () {}
            }, {
                key: "FullScreenItems",
                get: function () {
                    return [this.ui.m_comp_mengban]
                }
            }]), SettingUI
        }();
    to = __decorate([ui_register(Ja, eo)], to);
    var no = function () {
            function TipsMgr() {
                _classCallCheck(this, TipsMgr)
            }
            return _createClass(TipsMgr, null, [{
                key: "Tips",
                value: function (e) {
                    platform.getInstance().prompt(e)
                }
            }, {
                key: "tips",
                get: function () {
                    return null == this._tips && (this._tips = j.inst.ShowUI(io, e.overlay)), this._tips
                }
            }]), TipsMgr
        }(),
        io = function (e) {
            function TipsUI() {
                return _classCallCheck(this, TipsUI), _possibleConstructorReturn(this, _getPrototypeOf(TipsUI).apply(this, arguments))
            }
            return _inherits(TipsUI, Fe), _createClass(TipsUI, [{
                key: "OnCreate",
                value: function () {}
            }, {
                key: "OnShow",
                value: function (e) {}
            }, {
                key: "OnHide",
                value: function () {}
            }, {
                key: "OnDispose",
                value: function () {}
            }, {
                key: "ShowTips",
                value: function (e) {
                    var t = Ni.createInstance();
                    t.title = e, t.m_fade.play(), this.ui.m_holder.addChild(t), t.sortingOrder = 1e3, Laya.timer.once(1e3, this, this.onRemoveTips, [t], !1)
                }
            }, {
                key: "onRemoveTips",
                value: function (e) {
                    e.dispose()
                }
            }]), TipsUI
        }();
    io = __decorate([ui_register(xi, Bi)], io);
    var ao = function (e) {//todo:地图界面
        function ShopMapUI() {
            return _classCallCheck(this, ShopMapUI), _possibleConstructorReturn(this, _getPrototypeOf(ShopMapUI).apply(this, arguments))
        }
        return _inherits(ShopMapUI, Fe), _createClass(ShopMapUI, [{
            key: "OnCreate",
            value: function () {
                this.ui.m_comp_fendian.m_btn_fanhui.onClick(this, this.onClickClose)
            }
        }, {
            key: "OnShow",
            value: function () {
                this.updateState()
            }
        }, {
            key: "OnHide",
            value: function () {}
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "updateState",
            value: function () {
                this.ui.m_comp_jinbi.title = Wt.inst.Money + "";
                for (var e = this.ui.m_comp_fendian.m_list, t = 0; t < e.numItems; t++) {
                    var n = e.getChildAt(t);
                    t >= 4 ? n.m_c1.selectedIndex = 3 : this.ShopIndex != t ? Wt.inst.ShopUnlockIndex >= t ? (n.m_btn_qianwang.onClick(this, this.goToShop, [t]), n.m_c1.selectedIndex = 1) : Wt.inst.ShopUnlockIndex + 1 != t ? Wt.inst.ShopUnlockIndex + 1 < t && (n.m_c1.selectedIndex = 3) : (n.m_c1.selectedIndex = 2, n.m_btn_jiesuo.onClick(this, this.unlcokShop, [t]), n.m_btn_jiesuo.m_text_jinbi.text = Nt.getInst().shopPrice[t] + "") : n.m_c1.selectedIndex = 0
                }
            }
        }, {
            key: "unlcokShop",
            value: function (e) {
                Wt.inst.Money >= Nt.getInst().shopPrice[e] ? (Wt.inst.ShopUnlockIndex++, Wt.inst.Money -= Nt.getInst().shopPrice[e], this.updateState()) : no.Tips("Money deficit!")
            }
        }, {
            key: "goToShop",
            value: function (e) {
                console.log("click goToShop", e), Wo.getInst().GoToShop(e)
            }
        }, {
            key: "onClickClose",
            value: function () {
				Plat.I.ShowInter();
                j.inst.PopUI(this.layer, !0)
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_com_mengban]
            }
        }, {
            key: "ShopIndex",
            get: function () {
                return Wo.getInst().gameBlackBoard.currentShopIndex
            }
        }]), ShopMapUI
    }();
    ao = __decorate([ui_register(nn, Ln)], ao);
    var oo = function () {
        function Times(e) {
            _classCallCheck(this, Times), this.time = 0, this.time = e || Times.now
        }
        return _createClass(Times, [{
            key: "add",
            value: function (e) {
                return this.time += e, this
            }
        }, {
            key: "sub",
            value: function (e) {
                return this.time -= e, this
            }
        }, {
            key: "converMinTen",
            value: function (e) {
                return e < 10 ? "0" + e : e.toString()
            }
        }, {
            key: "now",
            get: function () {
                return this.time
            }
        }, {
            key: "day",
            get: function () {
                return Math.floor(this.hour / 24)
            }
        }, {
            key: "hour",
            get: function () {
                return Math.floor(this.minute / 60)
            }
        }, {
            key: "minute",
            get: function () {
                return Math.floor(this.second / 60)
            }
        }, {
            key: "second",
            get: function () {
                return Math.floor(this.time / 1e3)
            }
        }, {
            key: "numHour",
            get: function () {
                var e;
                return e = this.converMinTen(this.second % 60) + "", e = this.second >= 60 ? this.converMinTen(this.minute % 60) + ":" + e : "00:" + e, e = this.minute >= 60 ? this.converMinTen(this.hour) + ":" + e : "00:" + e
            }
        }, {
            key: "numMinute",
            get: function () {
                var e;
                return e = this.converMinTen(this.second % 60) + "", e = this.second >= 60 ? this.converMinTen(this.minute) + ":" + e : "00:" + e
            }
        }, {
            key: "numSecond",
            get: function () {
                return this.converMinTen(this.second)
            }
        }, {
            key: "chinaHour",
            get: function () {
                var e;
                return e = this.converMinTen(this.second % 60) + "秒", this.second >= 60 && (e = this.converMinTen(this.minute % 60) + "分" + e), this.minute >= 60 && (e = this.converMinTen(this.hour) + "时" + e), e
            }
        }, {
            key: "chinaMinute",
            get: function () {
                var e;
                return e = this.converMinTen(this.second % 60) + "秒", this.second >= 60 && (e = this.converMinTen(this.minute) + "分" + e), e
            }
        }, {
            key: "chinaSecond",
            get: function () {
                return this.converMinTen(this.second) + "秒"
            }
        }], [{
            key: "getDate",
            value: function () {
                return (new Date).getDate()
            }
        }, {
            key: "console",
            value: function (e) {
                this._console[e] = Times.now
            }
        }, {
            key: "consoleEnd",
            value: function (e) {
                for (var t, n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) i[a - 1] = arguments[a];
                (t = console).log.apply(t, ["执行耗时 ", e, (Times.now - (this._console[e] || Times.now)) / 1e3].concat(i))
            }
        }, {
            key: "day",
            value: function (e) {
                return Math.floor(this.hour(e) / 24)
            }
        }, {
            key: "hour",
            value: function (e) {
                return Math.floor(this.minute(e) / 60)
            }
        }, {
            key: "minute",
            value: function (e) {
                return Math.floor(this.second(e) / 60)
            }
        }, {
            key: "second",
            value: function (e) {
                return null != e && null != e || (e = this.now), Math.floor(e / 1e3)
            }
        }, {
            key: "numHour",
            value: function (e) {
                var t;
                return t = this.converMinTen(this.second(e) % 60) + "", t = this.second() >= 60 ? this.converMinTen(this.minute(e) % 60) + ":" + t : "00:" + t, t = this.minute() >= 60 ? this.converMinTen(this.hour(e)) + ":" + t : "00:" + t
            }
        }, {
            key: "numMinute",
            value: function (e) {
                var t;
                return t = this.converMinTen(this.second(e) % 60) + "", t = this.second() >= 60 ? this.converMinTen(this.minute(e)) + ":" + t : "00:" + t
            }
        }, {
            key: "numSecond",
            value: function (e) {
                return this.converMinTen(this.second(e))
            }
        }, {
            key: "chinaHour",
            value: function (e) {
                var t;
                return t = this.converMinTen(this.second(e) % 60) + "秒", this.second() >= 60 && (t = this.converMinTen(this.minute(e) % 60) + "分" + t), this.minute() >= 60 && (t = this.converMinTen(this.hour(e)) + "时" + t), t
            }
        }, {
            key: "chinaMinute",
            value: function (e) {
                var t;
                return t = this.converMinTen(this.second(e) % 60) + "秒", this.second() >= 60 && (t = this.converMinTen(this.minute(e)) + "分" + t), t
            }
        }, {
            key: "chinaSecond",
            value: function (e) {
                return this.converMinTen(this.second(e)) + "秒"
            }
        }, {
            key: "converMinTen",
            value: function (e) {
                return e < 10 ? "0" + e : e.toString()
            }
        }, {
            key: "isSameDay",
            value: function (e) {
                return new Date(e).toLocaleDateString() === (new Date).toLocaleDateString()
            }
        }, {
            key: "compare_time",
            value: function (e) {
                return this.get_endtime() == e ? 1 : 0
            }
        }, {
            key: "get_endtime",
            value: function () {
                var e = new Date(new Date((new Date).toLocaleDateString()).getTime() + 864e5 - 1);
                return this.format_date(e)
            }
        }, {
            key: "format_date",
            value: function (e) {
                var t = e.getFullYear(),
                    n = e.getMonth() + 1,
                    i = e.getDate(),
                    a = e.getHours(),
                    o = e.getMinutes(),
                    s = e.getSeconds(),
                    r = t + "";
                return n < 10 && (r += "0"), r += n + "", i < 10 && (r += "0"), r += i + "", a < 10 && (r += "0"), r += a + "", o < 10 && (r += "0"), r += o, s < 10 && (r += "0"), r += s
            }
        }, {
            key: "now",
            get: function () {
                return (new Date).getTime()
            }
        }, {
            key: "Date",
            get: function () {
                return new Date
            }
        }]), Times
    }();
    oo._console = {};
    var so = function (e) {
        function UIShare() {
            return _classCallCheck(this, UIShare), _possibleConstructorReturn(this, _getPrototypeOf(UIShare).apply(this, arguments))
        }
        return _inherits(UIShare, Fe), _createClass(UIShare, [{
            key: "OnCreate",
            value: function () {
                this.ui.m_comp_win.m_btn_fanhui.onClick(this, this.onClickClose), this.ui.m_btn_share.onClick(this, this.onClickShare)
            }
        }, {
            key: "OnShow",
            value: function () {
                this._refreshShareCount(), this.udpateCoin(), N.getInst().on(Et.CoinUpdate, this, this.udpateCoin)
            }
        }, {
            key: "OnHide",
            value: function () {
                N.getInst().off(Et.CoinUpdate, this, this.udpateCoin)
            }
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "udpateCoin",
            value: function () {
                this.ui.m_comp_jinbi.title = Wt.inst.Money.toFixed()
            }
        }, {
            key: "onClickShare",
            value: function () {
                var e = this;
                mt.shareMsg(this, function (t) {
                    t ? (Wt.inst.ShareCount += 1, Wt.inst.ShareTime = mt.serverTime, Wt.inst.Money += 100, Laya.timer.once(500, e, function () {
                        no.Tips("Get money +100")
                    })) : Laya.timer.once(500, e, function () {
                        no.Tips("分享失败")
                    }), e._refreshShareCount()
                }, "")
            }
        }, {
            key: "onClickClose",
            value: function () {
                j.inst.PopUI(this.layer, !0)
            }
        }, {
            key: "_refreshShareCount",
            value: function () {
                oo.isSameDay(Wt.inst.ShareTime) || (Wt.inst.ShareCount = 0), this.ui.m_btn_share.m_label_count.text = Wt.inst.ShareCount + "/3", this.ui.m_btn_share.grayed = Wt.inst.ShareCount >= 3, this.ui.m_btn_share.touchable = Wt.inst.ShareCount < 3
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_com_mengban]
            }
        }]), UIShare
    }();
    so = __decorate([ui_register(mn, Ln)], so);
    var ro = function (t) {
        function MainUI() {//todo:主界面
            var e;
            return _classCallCheck(this, MainUI), (e = _possibleConstructorReturn(this, _getPrototypeOf(MainUI).apply(this, arguments))).moneyTagPosX = 0, e.moneyTagPosY = 0, e.p4 = new Laya.Vector4, e.pp = new Laya.Point, e.centerPos = new Laya.Point, e.lastPos = new Laya.Point, e.currentPos = new Laya.Point, e.dir = new Laya.Vector2, e.deltaPos = new Laya.Vector2, e.tmp = new Laya.Vector2, e.p = new Laya.Vector3, e.q = new Laya.Quaternion, e
        }
        return _inherits(MainUI, Fe), _createClass(MainUI, [{
            key: "OnCreate",
            value: function () {
                this.ui.m_btn_setting.onClick(this, function () {
                    j.inst.PushUI(to, e.lowMid)
                });
				this.ui.m_btn_setting.y = 200;
				this.ui.m_btn_ditu.y = 400
				this.ui.m_btn_lbn.y = 600
				
                var t = this.ui.globalToLocal(0, 0, t);
                this.ui.m_left.x = t.x;
                t = this.ui.globalToLocal(Laya.stage.width, 0, t);
                var n = this.ui.width - this.ui.m_right.x;
                this.ui.m_right.x = t.x - n,
					this.ui.m_joyStick.visible = !1,
					this.moneyTagPosX = this.ui.m_comp_chaopiao.x + this.ui.m_comp_chaopiao.m_tag.x,
					this.moneyTagPosY = this.ui.m_comp_chaopiao.y + this.ui.m_comp_chaopiao.m_tag.y,
				Laya.Browser.onTTMiniGame && (this.ui.m_tt.selectedIndex = 1),
					this.ui.m_btn_fenxiang.onClick(this, this.startRecord),
					this.ui.m_btn_jineng.onClick(this, this.onClickDuLun),
					this.ui.m_btn_ditu.onClick(this, this.onClickShopMap),
					this.ui.m_btn_xiaotanchuang.onClick(this, this.onClickCircleAD),
					this.ui.m_btn_lbn.onClick(this, this.onClickLBN),
					this.ui.m_btn_wurenji.onClick(this, this.onClickWRJ),
					this.ui.m_btn_yuangong.onClick(this, this.onClickSupport),
					this.ui.m_btn_more.onClick(this, this.onClickMore),
					this.ui.m_btn_share.onClick(this, this.onClickShare),
					this.ui.m_btn_share.visible = !1, this.ui.m_btn_more.visible = !1
            }
        }, {
            key: "OnShow",
            value: function () {
                var e = this;
                this.ui.m_bg.on(Laya.Event.MOUSE_DOWN, this, this.onMoveStart),
					this.ui.m_joyStick.visible = !1, this.udpateCoin(),
					N.getInst().on(Et.CoinUpdate, this, this.udpateCoin),
					this.updateGuide(),
					N.getInst().on(Et.GuideStepChange, this, this.updateGuide),
					N.getInst().on(Et.SwitchDuLun, this, function () {
                    e.ui.m_btn_jineng.m_qiche.selectedIndex = 0
                }),
					N.getInst().on(Et.SwitchFoot, this, function () {
                    e.ui.m_btn_jineng.m_qiche.selectedIndex = 1
                }),
					N.getInst().on(Et.UpdateAirplanePos, this, this.onAirplanePos),
					N.getInst().on(Et.ShowCircleAD, this, this.onShowCircleAD),
					N.getInst().on(Et.HideCircleAD, this, this.onHideCircleAD),
					N.getInst().on(Et.UpdateCircleAD, this, this.onUpdateCircleAD),
					N.getInst().on(Et.UpdateSupport, this, this.updateLBNState),
					N.getInst().on(Et.CloseUnlockUI, this, this.updateLBNState),
					N.getInst().on(Et.ShowUnlockTips, this, this.showUnlockTips),
					this._startRecord(), this.ui.on(Laya.Event.MOUSE_DOWN, this, this.onTouch),
					this.ui.m_comp_finger.visible = !0, this.updateQiCheUI(),
					this.ui.m_btn_xiaotanchuang.visible = !1, this.updateLBN(),
					this.ui.m_unlockTips.visible = !1, Wt.inst.HasADSupport ? this.ui.m_btn_yuangong.visible = !1
					: Wt.inst.ShowADSupport && !Wt.inst.ShopSupportIsMaxCountLevel ? this.ui.m_btn_yuangong.visible = !0
						: this.ui.m_btn_yuangong.visible = !1, Wt.inst.HasADWRJ ? this.ui.m_btn_wurenji.visible = !1 : Wt.inst.ShowADWRJ && !Wt.inst.UnlockedGirlUAV ? this.ui.m_btn_wurenji.visible = !0 : this.ui.m_btn_wurenji.visible = !1,
					Laya.timer.once(18e4, this, function () {
                })
				Plat.I.SendAnay(Plat.Game_Page);
				Plat.I.ShowFloat(0, null, 0,500);
            }
        }, {
            key: "onTouch",
            value: function () {
                this.ui.off(Laya.Event.MOUSE_DOWN, this, this.onTouch), this.ui.m_comp_finger.visible = !1;
                Plat.I.HideFloat();
                platform.getInstance().showInterstitial();
            }
        }, {
            key: "OnHide",
            value: function () {
                this.ui.m_bg.off(Laya.Event.MOUSE_MOVE, this, this.onMove), this.ui.m_bg.off(Laya.Event.MOUSE_UP, this, this.onMoveEnd), this.ui.off(Laya.Event.MOUSE_OUT, this, this.onMoveEnd), this.onMoveEnd(), N.getInst().offAllCaller(this), Laya.timer.clearAll(this)
            }
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "updateGuide",
            value: function () {}
        }, {
            key: "showUnlockTips",
            value: function () {
                this.ui.m_unlockTips.visible = !0, Laya.timer.once(4e3, this, this.hideUnlockTips)
            }
        }, {
            key: "hideUnlockTips",
            value: function () {
                this.ui.m_unlockTips.visible = !1
            }
        }, {
            key: "updateLBNState",
            value: function () {
                Wt.inst.UnlockedGirlSupport && (this.ui.m_btn_lbn.visible = !1), Wt.inst.HasADSupport ? this.ui.m_btn_yuangong.visible = !1 : Wt.inst.ShowADSupport && !Wt.inst.ShopSupportIsMaxCountLevel ? this.ui.m_btn_yuangong.visible = !0 : this.ui.m_btn_yuangong.visible = !1, Wt.inst.HasADWRJ ? this.ui.m_btn_wurenji.visible = !1 : Wt.inst.ShowADWRJ && !Wt.inst.UnlockedGirlUAV ? this.ui.m_btn_wurenji.visible = !0 : this.ui.m_btn_wurenji.visible = !1
            }
        }, {
            key: "updateLBN",
            value: function () {
                Wt.inst.UnlockedGirlSupport ? this.ui.m_btn_lbn.visible = !1 : (this.ui.m_btn_lbn.visible = !0, Wt.inst.CurrentShopPlayTime < 3e5 ? (this.ui.m_btn_lbn.m_c1.selectedIndex = 0, this.ui.m_btn_lbn.touchable = !1, this.ui.m_btn_lbn.m_cd.text = M.TimeToString(3e5 - Wt.inst.CurrentShopPlayTime), Laya.timer.once(1e3, this, this.updateLBN)) : (this.ui.m_btn_lbn.m_c1.selectedIndex = 1, this.ui.m_btn_lbn.touchable = !0))
            }
        }, {
            key: "onClickShare",
            value: function () {
                j.inst.PushUI(so, e.lowMid)
            }
        }, {
            key: "onClickMore",
            value: function () {
                mt.showNavigateCustom(Ct.Grid9)
            }
        }, {
            key: "onClickSupport",
            value: function () {
                j.inst.PushUI(Tn, e.lowMid, bn.normal)
            }
        }, {
            key: "onClickWRJ",
            value: function () {
                j.inst.PushUI(Tn, e.lowMid, bn.wrj)
            }
        }, {
            key: "onClickLBN",
            value: function () {
                j.inst.PushUI(Tn, e.lowMid, bn.lbn)
            }
        }, {
            key: "udpateCoin",
            value: function () {
                this.ui.m_comp_chaopiao.title = Wt.inst.Money.toFixed()
            }
        }, {
            key: "startRecord",
            value: function () {
                var e = this;
                if (null == this.lastRecordTime && (this.lastRecordTime = Date.now()), 0 === this.ui.m_btn_fenxiang.m_c1.selectedIndex) {
                    if (Date.now() - this.lastRecordTime < 3e3) return void no.Tips("录制时间少于3秒");
                    console.log("stop"), mt.stopVideoRecord()
                } else mt.sdk.hasShareRecorder() ? mt.shareVideoRecord(function (t) {
                    e._startRecord()
                }) : this._startRecord()
            }
        }, {
            key: "_startRecord",
            value: function () {}
        }, {
            key: "onRecodEnd",
            value: function () {
                this.IsShow() && (console.log("onRecodEnd"), this.ui.m_btn_fenxiang.m_c1.selectedIndex = 1)
            }
        }, {
            key: "updateQiCheUI",
            value: function () {
                var e = pi.getInst().player;
                this.ui.m_btn_jineng.m_qiche.selectedIndex = e && e.IsDuLun ? 0 : 1
            }
        }, {
            key: "onClickShopMap",
            value: function () {
                j.inst.PushUI(ao, e.lowMid)
            }
        }, {
            key: "onClickDuLun",
            value: function () {
                0 != Wt.inst.UnlockDunLun ? pi.getInst().player.IsDuLun ? N.getInst().event(Et.SwitchFoot) : N.getInst().event(Et.SwitchDuLun) : j.inst.PushUI(Xa, e.lowMid)
            }
        }, {
            key: "onAirplanePos",
            value: function (e) {
                Yt.inst.camera.worldToViewportPoint(e, this.p4), this.ui.globalToLocal(this.p4.x, this.p4.y, this.pp);
                var t = this.ui.m_comp_zhongjimubiao;
                t.x = this.pp.x, t.y = this.pp.y;
                var n = Wt.inst.Money;
                n >= 5e5 ? t.m_full.selectedIndex = 1 : (t.m_full.selectedIndex = 0, t.m_progress_jindu.max = 5e5, t.m_progress_jindu.value = n, t.m_text_shuliang.text = n + "/500000")
            }
        }, {
            key: "onShowCircleAD",
            value: function (e) {
                this.ui.m_btn_xiaotanchuang.m_type.selectedIndex = e, this.ui.m_btn_xiaotanchuang.visible = !0
            }
        }, {
            key: "onHideCircleAD",
            value: function () {
                this.ui.m_btn_xiaotanchuang.visible = !1
            }
        }, {
            key: "onUpdateCircleAD",
            value: function (e, t) {
                this.ui.m_btn_xiaotanchuang.m_type.selectedIndex = t, this.ui.m_btn_xiaotanchuang.visible = !0, Yt.inst.camera.worldToViewportPoint(e, this.p4), this.ui.globalToLocal(this.p4.x, this.p4.y, this.pp);
                var n = this.ui.m_btn_xiaotanchuang;
                n.x = this.pp.x, n.y = this.pp.y
            }
        }, {
            key: "onClickCircleAD",
            value: function () {
                var e = this;
                mt.showADVideo(this, function (t) {
                    t && e.onClickAD(e.ui.m_btn_xiaotanchuang.m_type.selectedIndex)
                }, "Floor AD")
            }
        }, {
            key: "onClickAD",
            value: function (e) {
                switch (e) {
                    case $a.角色移动速度:
                        Wt.inst.SpeedLevel++;
                        break;
                    case $a.角色容量:
                        Wt.inst.StackLevel++;
                        break;
                    case $a.货币价值:
                        Wt.inst.PriceLevel++;
                        break;
                    case $a.员工移动速度:
                        Wt.inst.ShopSupportSpeedLevel++;
                        break;
                    case $a.员工容量:
                        Wt.inst.ShopSupportStackLevel++
                }
                this.onHideCircleAD(), N.getInst().event(Et.HideCircleADUI)
            }
        }, {
            key: "onMoveStart",
            value: function () {
                this.dir.setValue(0, 0), this.centerX = Laya.stage.mouseX, this.centerY = Laya.stage.mouseY, this.ui.globalToLocal(Laya.stage.mouseX, Laya.stage.mouseY, this.centerPos), this.lastPos.setTo(this.centerPos.x, this.centerPos.y), this.ui.m_bg.on(Laya.Event.MOUSE_MOVE, this, this.onMove), this.ui.m_bg.on(Laya.Event.MOUSE_UP, this, this.onMoveEnd), this.ui.on(Laya.Event.MOUSE_OUT, this, this.onMoveEnd), mt.changeNavigateTouchable(!1)
            }
        }, {
            key: "onMove",
            value: function () {
                this.ui.globalToLocal(Laya.stage.mouseX, Laya.stage.mouseY, this.currentPos), F.subtractVec2(this.currentPos, this.lastPos, this.deltaPos), this.lastPos.setTo(this.currentPos.x, this.currentPos.y), F.addVec2(this.deltaPos, this.dir, this.dir);
                var e = F.getLengthVec2(this.dir);
                if (e > 100) {
                    var t = e - 100;
                    F.normalizeVec2(this.dir, this.tmp), F.scaleVec2(this.tmp, t, this.tmp), F.truncateVec2(this.dir, 100, this.dir), F.addVec2(this.centerPos, this.tmp, this.centerPos)
                }
                F.normalizeVec2(this.dir, this.deltaPos), N.getInst().event(V.PlayerSteerMoveStart, this.deltaPos)
            }
        }, {
            key: "onMoveEnd",
            value: function () {
                N.getInst().event(V.PlayerSteerMoveEnd), this.ui.m_bg.off(Laya.Event.MOUSE_MOVE, this, this.onMove), this.ui.m_bg.off(Laya.Event.MOUSE_UP, this, this.onMoveEnd), this.ui.off(Laya.Event.MOUSE_OUT, this, this.onMoveEnd), mt.changeNavigateTouchable(!0)
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_bg]
            }
        }, {
            key: "LoaderFillType",
            get: function () {
                return fgui.LoaderFillType.Scale
            }
        }, {
            key: "VerticalAlign",
            get: function () {
                return Ge.middle
            }
        }]), MainUI
    }();
    __decorate([throttle(1e3)], ro.prototype, "onClickCircleAD", null), ro = __decorate([ui_register(za, Fa)], ro);
    var lo = function (t) {
        function GameState() {
            var e;
            return _classCallCheck(this, GameState), (e = _possibleConstructorReturn(this, _getPrototypeOf(GameState).apply(this, arguments))).name = "GameState", e.day = !0, e.dayColor = new Laya.Vector3, e.nightColor = new Laya.Vector3, e
        }
        return _inherits(GameState, Ut), _createClass(GameState, [{
            key: "OnInit",
            value: function () {}
        }, {
            key: "OnEnter",
            value: function () {
				Plat.I.SendAnay(Plat.Loading_End)
				if(!window.IsFirst)
				{
					window.IsFirst = true;
					window.HUHU_gameLoadingCompleted();
				}
                arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                var t = new Laya.Sprite3D("MoneyManager");
                pi.getInst().currentSceneNode.addChild(t), t.addComponent(ki);
                var n = new Laya.Sprite3D("PizzaManager");
                pi.getInst().currentSceneNode.addChild(n), n.addComponent(Qn),
					n.addComponent(ci), j.inst.PopUI(e.base, !0),
					j.inst.LoadPKG().then(function () {
                    j.inst.PushUI(ro, e.base), j.inst.PushUI(Ka, e.lowMid)
                }),
					pi.getInst().scene.ambientColor.cloneTo(this.dayColor),
					this.nightColor.setValue(28 / 255, 62 / 255, 1), 
				Laya.Browser.onTTMiniGame && Laya.timer.once(6e4, this, this.updateInsert);
                var i = pi.getInst().breakLoadConfig.delay;
                null != i && (i.break = !1, pi.getInst().BuildNode(i, pi.getInst().currentSceneNode, !1), 
					Wt.inst.GuideStep <= Mt.解锁披萨机3 ? (Wt.inst.GuideStep = Mt.解锁披萨机3,
						pi.getInst().player.arrow.target = ai.inst.Find("PizzaMaker").getChildAt(0)) 
						: Wt.inst.GuideStep == Mt.解锁单人桌4 ? pi.getInst().player.arrow.target = ai.inst.Find("SingleTable").getChildAt(0)
							: Wt.inst.GuideStep == Mt.拿披萨5 ? pi.getInst().player.arrow.target = ai.inst.Find("PizzaMaker").getChildAt(0)
								: Wt.inst.GuideStep == Mt.放披萨6 || Wt.inst.GuideStep == Mt.捡钱7
									? (Wt.inst.GuideStep = Mt.拿披萨5, pi.getInst().player.arrow.target = ai.inst.Find("PizzaMaker").getChildAt(0))
									: Wt.inst.GuideStep == Mt.HR提示9 ? ai.inst.TipsArrow = ai.inst.Find("HRTablePos")
										: Wt.inst.GuideStep == Mt.外卖提示11 && (ai.inst.TipsArrow = ai.inst.Find("Paker").getChildAt(0)))
            }
        }, {
            key: "updateGuide",
            value: function () {}
        }, {
            key: "updateInsert",
            value: function () {
                null != mt.sdk.data && mt.showADInsert(), Laya.timer.once(6e4, this, this.updateInsert)
            }
        }, {
            key: "OnUpdate",
            value: function (e) {
                Wt.inst.CurrentShopPlayTime += Laya.timer.delta
            }
        }, {
            key: "OnLeave",
            value: function () {
                Laya.timer.clearAll(this)
            }
        }, {
            key: "OnDestroy",
            value: function () {
                N.getInst().offAllCaller(this)
            }
        }]), GameState
    }();
    lo = __decorate([add_state_map()], lo);
    var uo, ho = function (t) {
        function MainSceneLoadState() {
            var e;
            return _classCallCheck(this, MainSceneLoadState), (e = _possibleConstructorReturn(this, _getPrototypeOf(MainSceneLoadState).apply(this, arguments))).name = "MainSceneLoadState", e.loadTag = !1, e
        }
        return _inherits(MainSceneLoadState, Ut), _createClass(MainSceneLoadState, [{
            key: "OnInit",
            value: function () {}
        }, {
            key: "OnEnter",
            value: function (t, n) {
                var i = this;
                this.loadTag = !1,
					this.Owner.ClearGame(), pi.getInst().LoadLevel(n).then(function () {
                    i.loadTag = !0
                }), t || j.inst.PushUI(Gi, e.base)
            }
        }, {
            key: "OnUpdate",
            value: function (e) {
                this.loadTag && this.ChangeState(lo)
            }
        }, {
            key: "OnLeave",
            value: function () {
                j.inst.PopUI(e.base, !0)
            }
        }, {
            key: "OnDestroy",
            value: function () {}
        }]), MainSceneLoadState
    }();
    ho = __decorate([add_state_map()], ho),
        function (e) {
            e.subPkg = "subPkg", e.createRes = "createRes", e.level = "level", e.zip = "zip"
        }(uo || (uo = {}));
    var co, fo = function (t) {
        function LoadingState() {
            var e;
            return _classCallCheck(this, LoadingState), (e = _possibleConstructorReturn(this, _getPrototypeOf(LoadingState).apply(this, arguments))).name = "LoadingState", e.loadProgress = {}, e.loadTag = !1, e.hadLeave = !1, e
        }
        return _inherits(LoadingState, Ut), _createClass(LoadingState, [{
            key: "OnInit",
            value: function () {}
        }, {
            key: "OnEnter",
            value: function () {
                var t = this;
                this.loadTag = !1;
                try {
                    for (var n in this.loadingUI = j.inst.PushUI(Gi, e.base), 
						this.loadingUI.mainProgressValue = 0, uo) this.loadProgress[n] = 0;
                    M.PromiseQueue(null, function () {
                        return console.log("加载zip"), t.loadProgress[uo.subPkg] = 1, $t.LoadZipAsset(!1).progress(function (e) {
                            t.loadProgress[uo.zip] = e, t.udpateProgress()
                        })
                    }, function () {
                        return console.log("加载res"), t.loadProgress[uo.zip] = 1, t.loadingUI.subProgressValue = 0,
							$t.LoadCreateResP().progress(function (e) {
                            t.loadProgress[uo.createRes] = e, t.loadingUI.subProgressValue = e, t.udpateProgress()
                        })
                    }, function () {
                        return t.loadProgress[uo.createRes] = 1, t.loadingUI.subProgressValue = 0,
							pi.getInst().onPreCreatePrefab = yi.getInst().onPreCreatePrefab.bind(yi.getInst()),
							pi.getInst().GameStartLoad().progress(function (e) {
                            t.loadProgress[uo.level] = e, t.loadingUI.subProgressValue = e, t.udpateProgress()
                        })
                    }, function () {
                        return M.WaitTime(2e3)
                    }).then(function () {
                        t.loadTag = !0
                    }).catch(function (e) {
                        console.error(e)
                    })
                } catch (e) {
                    throw new Error(e)
                }
            }
        }, {
            key: "OnUpdate",
            value: function (e) {
                this.loadTag && this.ChangeState(ho, !0, "level1")
            }
        }, {
            key: "OnLeave",
            value: function () {
                if (!this.hadLeave) {
                    this.hadLeave = !0, lt.inst.sendReport(et.LOADING_END);
                    Laya.LocalStorage.getItem("HadAgreeFirst") || Laya.LocalStorage.setItem("HadAgreeFirst", "1")
                    var t = Laya.LocalStorage.getItem("HadAgreeFirst");
                    console.log(JSON.stringify(t) + "登录缓存数据"), 1 != Number(t) ? (console.error("push YinSi"), j.inst.PushUI(Ye, e.yinSi)) : mt.hasAgreeXieYi = !0
                }
            }
        }, {
            key: "OnDestroy",
            value: function () {}
        }, {
            key: "udpateProgress",
            value: function () {
                var e = 0,
                    t = 1 / Object.keys(this.loadProgress).length;
                for (var n in uo) e += this.loadProgress[n] * t;
                this.loadingUI.mainProgressValue = e
            }
        }]), LoadingState
    }();
    fo = __decorate([add_state_map()], fo),
        function (e) {
            e.loadingUI = "loadingUI"
        }(co || (co = {}));
    var _o = function (t) {
        function PreloadState() {
            var e;
            return _classCallCheck(this, PreloadState), (e = _possibleConstructorReturn(this, _getPrototypeOf(PreloadState).apply(this, arguments))).name = "PreloadState", e.loadFlag = {}, e.isChangedState = !1, e
        }
        return _inherits(PreloadState, Ut), _createClass(PreloadState, [{
            key: "OnInit",
            value: function () {}
        }, {
            key: "OnEnter",
            value: function () {
                var t = this;
                mt.curentState = this
				this.loadFlag[co.loadingUI] = !1
				fgui.UIConfig.packageFileExtension = "bin"
				fgui.UIConfig.buttonSound = A.soundDir + "button.mp3"
				z.LoadPackage(["fui_loading/Loading", "fui/huawei"]).then(function () {
                    Laya.stage.addChild(fgui.GRoot.inst.displayObject)
					fgui.GRoot.inst.displayObject.zOrder = 100
					t.onLoadingResLoad()
					console.log("======================>")
					j.inst.PushUI(Di, e.loging)
					mt.curentState.ChangeLoadingState(),
					j.inst.PopUI(e.loging, !0),
					j.inst.PopUI(e.login, !0);
					// this.showToast("正在登录中...", 1e3)
                })
            }
        }, {
            key: "OnUpdate",
            value: function (e) {}
        }, {
            key: "OnLeave",
            value: function () {}
        }, {
            key: "OnDestroy",
            value: function () {}
        }, {
            key: "ChangeLoadingState",
            value: function () {
                j.inst.PopUI(e.loging, !0), this.fsm.ChangeState(fo)
            }
        }, {
            key: "onLoadingResLoad",
            value: function () {
                this.loadFlag[co.loadingUI] = !0, this.checkLoadFlag()
            }
        }, {
            key: "checkLoadFlag",
            value: function () {
                for (var e in co)
                    if (console.log(e), 1 != this.loadFlag[e]) return void console.error("return")
            }
        }]), PreloadState
    }();
    _o = __decorate([add_state_map()], _o);
    var yo, po = new Laya.Vector2,
        go = function (e) {
            function TipsPolygonTrigger() {
                var e;
                return _classCallCheck(this, TipsPolygonTrigger), (e = _possibleConstructorReturn(this, _getPrototypeOf(TipsPolygonTrigger).apply(this, arguments))).maxX = -1e6, e.minX = 1e5, e.maxY = -1e6, e.minY = 1e6, e.isEnter = !1, e.msg = "", e
            }
            return _inherits(TipsPolygonTrigger, Rt), _createClass(TipsPolygonTrigger, [{
                key: "onStart",
                value: function () {
                    var e = this.Find("polygon") || this.sp;
                    if (e) {
                        this.polygon = [], this.maxX = -1e6, this.minX = 1e5, this.maxY = -1e6, this.minY = 1e6;
                        for (var t = 0; t < e.numChildren; t++) {
                            var n = e.getChildAt(t);
                            this.polygon.push(new Laya.Vector2(n.transform.position.x, n.transform.position.z))
                        }
                        for (var i = 0; i < this.polygon.length; i++) {
                            var a = this.polygon[i];
                            this.maxX = Math.max(a.x, this.maxX), this.minX = Math.min(a.x, this.minX), this.maxY = Math.max(a.y, this.maxY), this.minY = Math.min(a.y, this.minY)
                        }
                    } else console.warn("".concat(this.sp.name, " not has polygon node!")), this.destroy()
                }
            }, {
                key: "FastTest",
                value: function (e) {
                    return e.x >= this.minX && e.x <= this.maxX && e.y >= this.minY && e.y <= this.maxY
                }
            }, {
                key: "onUpdate",
                value: function () {
                    var e = pi.getInst().player;
                    if (null != e) {
                        po.setValue(e.transform.position.x, e.transform.position.z);
                        var t = this.FastTest(po);
                        return t && (t = Xt.PointInPolygon2(po, this.polygon)), !this.isEnter && t ? (this.isEnter = t, void this._onTriggerEner()) : this.isEnter && !t ? (this.isEnter = t, void this._onTriggerExit()) : void 0
                    }
                }
            }, {
                key: "_onTriggerEner",
                value: function () {
                    null != this.msg && null != this.msg && no.Tips(this.msg)
                }
            }, {
                key: "_onTriggerExit",
                value: function () {}
            }, {
                key: "_parse",
                value: function (e) {
                    this.msg = e.fn_msg
                }
            }, {
                key: "_cloneTo",
                value: function (e) {
                    e.msg = this.msg
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("TipsPolygonTrigger", TipsPolygonTrigger)
                }
            }]), TipsPolygonTrigger
        }(),
        vo = new Laya.Vector2,
        mo = yo = function (e) {
            function Door() {
                var e;
                return _classCallCheck(this, Door), (e = _possibleConstructorReturn(this, _getPrototypeOf(Door).apply(this, arguments))).maxX = -1e6, e.minX = 1e5, e.maxY = -1e6, e.minY = 1e6, e.isEnter = !1, e
            }
            return _inherits(Door, Rt), _createClass(Door, [{
                key: "onStart",
                value: function () {
                    var e = this.Find("polygon") || this.sp;
                    if (e) {
                        this.polygon = [], this.maxX = -1e6, this.minX = 1e5, this.maxY = -1e6, this.minY = 1e6;
                        for (var t = 0; t < e.numChildren; t++) {
                            var n = e.getChildAt(t);
                            this.polygon.push(new Laya.Vector2(n.transform.position.x, n.transform.position.z))
                        }
                        for (var i = 0; i < this.polygon.length; i++) {
                            var a = this.polygon[i];
                            this.maxX = Math.max(a.x, this.maxX), this.minX = Math.min(a.x, this.minX), this.maxY = Math.max(a.y, this.maxY), this.minY = Math.min(a.y, this.minY)
                        }
                    } else console.warn("".concat(this.sp.name, " not has polygon node!")), this.destroy()
                }
            }, {
                key: "FastTest",
                value: function (e) {
                    return e.x >= this.minX && e.x <= this.maxX && e.y >= this.minY && e.y <= this.maxY
                }
            }, {
                key: "onUpdate",
                value: function () {
                    var e = pi.getInst().player;
                    if (null != e) {
                        vo.setValue(e.transform.position.x, e.transform.position.z);
                        var t = this.FastTest(vo);
                        return t && (t = Xt.PointInPolygon2(vo, this.polygon)), !this.isEnter && t ? (this.isEnter = t, void this._onTriggerEner()) : this.isEnter && !t ? (this.isEnter = t, void this._onTriggerExit()) : void 0
                    }
                }
            }, {
                key: "_onTriggerEner",
                value: function () {
                    G.inst.playSound("kaimen"), Laya.Tween.to(this.door.transform, {
                        localRotationEulerY: 120
                    }, 100, Laya.Ease.bounceIn, null, null, !0)
                }
            }, {
                key: "_onTriggerExit",
                value: function () {
                    Laya.Tween.to(this.door.transform, {
                        localRotationEulerY: 0
                    }, 100, Laya.Ease.bounceIn, null, null, !0)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("Door", yo)
                }
            }]), Door
        }();
    __decorate([bind_node("Cube.018")], mo.prototype, "door", void 0), mo = yo = __decorate([auto_bind_node()], mo);
    var Co, ko, So = function (e) {
            function CircleProgressMaterial() {
                var e;
                return _classCallCheck(this, CircleProgressMaterial), (e = _possibleConstructorReturn(this, _getPrototypeOf(CircleProgressMaterial).call(this))).setShaderName("CircleProgressShader"), e.renderQueue = Laya.Material.RENDERQUEUE_TRANSPARENT, e.alphaTest = !1, e.depthWrite = !1, e.cull = Laya.RenderState.CULL_BACK, e.blend = Laya.RenderState.BLEND_ENABLE_ALL, e.blendSrc = Laya.RenderState.BLENDPARAM_SRC_ALPHA, e.blendDst = Laya.RenderState.BLENDPARAM_ONE_MINUS_SRC_ALPHA, e.depthTest = Laya.RenderState.DEPTHTEST_LESS, e
            }
            return _inherits(CircleProgressMaterial, Laya.Material), _createClass(CircleProgressMaterial, [{
                key: "clone",
                value: function () {
                    var e = new CircleProgressMaterial;
                    return this.cloneTo(e), e
                }
            }, {
                key: "_MaxRadius",
                set: function (e) {
                    this._shaderValues.setNumber(Laya.Shader3D.propertyNameToID("u_MaxRadius"), e)
                },
                get: function () {
                    return this._shaderValues.getNumber(Laya.Shader3D.propertyNameToID("u_MaxRadius"))
                }
            }, {
                key: "_MinRadius",
                set: function (e) {
                    this._shaderValues.setNumber(Laya.Shader3D.propertyNameToID("u_MinRadius"), e)
                },
                get: function () {
                    return this._shaderValues.getNumber(Laya.Shader3D.propertyNameToID("u_MinRadius"))
                }
            }, {
                key: "_Value",
                set: function (e) {
                    this._shaderValues.setNumber(Laya.Shader3D.propertyNameToID("u_Value"), e)
                },
                get: function () {
                    return this._shaderValues.getNumber(Laya.Shader3D.propertyNameToID("u_Value"))
                }
            }, {
                key: "_Color",
                set: function (e) {
                    this._shaderValues.setVector(Laya.Shader3D.propertyNameToID("u_Color"), e)
                },
                get: function () {
                    return this._shaderValues.getVector(Laya.Shader3D.propertyNameToID("u_Color"))
                }
            }, {
                key: "_ColorBG",
                set: function (e) {
                    this._shaderValues.setVector(Laya.Shader3D.propertyNameToID("u_ColorBG"), e)
                },
                get: function () {
                    return this._shaderValues.getVector(Laya.Shader3D.propertyNameToID("u_ColorBG"))
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("Laya.CircleProgress", CircleProgressMaterial);
                    var e = {
                            a_Position: Laya.VertexMesh.MESH_POSITION0,
                            a_Texcoord: Laya.VertexMesh.MESH_TEXTURECOORDINATE0
                        },
                        t = {
                            u_MvpMatrix: Laya.Shader3D.PERIOD_SPRITE,
                            u_Color: Laya.Shader3D.PERIOD_MATERIAL,
                            u_ColorBG: Laya.Shader3D.PERIOD_MATERIAL,
                            u_MaxRadius: Laya.Shader3D.PERIOD_MATERIAL,
                            u_MinRadius: Laya.Shader3D.PERIOD_MATERIAL,
                            u_Value: Laya.Shader3D.PERIOD_MATERIAL
                        },
                        n = {
                            s_Cull: Laya.Shader3D.RENDER_STATE_CULL,
                            s_Blend: Laya.Shader3D.RENDER_STATE_BLEND,
                            s_BlendSrc: Laya.Shader3D.RENDER_STATE_BLEND_SRC,
                            s_BlendDst: Laya.Shader3D.RENDER_STATE_BLEND_DST,
                            s_DepthTest: Laya.Shader3D.RENDER_STATE_DEPTH_TEST,
                            s_DepthWrite: Laya.Shader3D.RENDER_STATE_DEPTH_WRITE,
                            s_StencilTest: Laya.Shader3D.RENDER_STATE_STENCIL_TEST,
                            s_StencilWrite: Laya.Shader3D.RENDER_STATE_STENCIL_WRITE,
                            s_StencilRef: Laya.Shader3D.RENDER_STATE_STENCIL_REF,
                            s_StencilOp: Laya.Shader3D.RENDER_STATE_STENCIL_OP
                        },
                        i = Laya.Shader3D.add("CircleProgressShader"),
                        a = new Laya.SubShader(e, t);
                    i.addSubShader(a), a.addShaderPass("#if defined(GL_FRAGMENT_PRECISION_HIGH)\nprecision highp float;precision highp int;\n#else\nprecision mediump float;precision mediump int;\n#endif\n#include 'Lighting.glsl';\nattribute vec4 a_Position;attribute vec2 a_Texcoord;uniform mat4 u_MvpMatrix;varying vec2 v_Texcoord;void main(){gl_Position=u_MvpMatrix*a_Position;v_Texcoord=a_Texcoord;gl_Position=remapGLPositionZ(gl_Position);}", "#if defined(GL_FRAGMENT_PRECISION_HIGH)\nprecision highp float;precision highp int;\n#else\nprecision mediump float;precision mediump int;\n#endif\nuniform vec4 u_Color;uniform vec4 u_ColorBG;uniform float u_MaxRadius;uniform float u_MinRadius;uniform float u_Value;varying vec2 v_Texcoord;void main(){float Rote=270.0*0.0175;float sinNum=sin(Rote);float cosNum=cos(Rote);vec2 uv01=vec2(1.0-v_Texcoord.x,1.0-v_Texcoord.y);uv01=uv01-vec2(0.5,0.5);uv01=uv01*mat2(cosNum,-sinNum,sinNum,cosNum)+vec2(0.5,0.5);vec2 uv11=uv01*2.0-1.0;float angle=1.0-ceil(atan(uv11.g,uv11.r)-(6.4*u_Value-3.2));float uvR=dot(uv11,uv11);float uv_final=(1.0-floor(uvR+(1.0-u_MaxRadius)));float uv_final1=floor(uvR+(1.0-u_MinRadius));if(uv_final1<0.1){discard;}if(uv_final<0.1){discard;}if(uv_final*uv_final1*angle<0.5){gl_FragColor=u_ColorBG;}else{gl_FragColor=vec4(min(angle+1.0,1.0)*u_Color.rgb,u_Color.a);}}", n)
                }
            }]), CircleProgressMaterial
        }(),
        Io = Co = function (e) {
            function PizzaMaker() {
                var e;
                return _classCallCheck(this, PizzaMaker), (e = _possibleConstructorReturn(this, _getPrototypeOf(PizzaMaker).apply(this, arguments))).crazyMode = !1, e.leftPizzas = [], e.rightPizzas = [], e.crazyIndex = 0, e
            }
            return _inherits(PizzaMaker, Rt), _createClass(PizzaMaker, [{
                key: "onStart",
                value: function () {
                    var e = this.sp.getChildByName("trigger").getComponent(Ii);
                    e.onEnterCB = this._onTriggerEnter.bind(this), e.onStayCB = this._onTriggerStay.bind(this), e.onExitCB = this._onTriggerExit.bind(this), e.checkMove = !0, e.fade = !0, e.stayDelayDuration = 0, this.crazyFX.active = !1, Laya.timer.loop(1e3, this, this.spwanPizza), ai.inst.pizzaMakers.push(this)
                }
            }, {
                key: "onDestroy",
                value: function () {
                    this.ClearAsycFunc()
                }
            }, {
                key: "_onTriggerEnter",
                value: function () {}
            }, {
                key: "_onTriggerStay",
                value: function () {
                    if (!(this.Count <= 0 || pi.getInst().player.pizzaBoxCount > 0 || pi.getInst().player.pizzaCount >= Wt.inst.StackSize)) {
                        var e = this.RespwanPizza();
                        e.FlyToPlayer(!1), e.audio = !0, Wt.inst.GuideStep == Mt.拿披萨5 && (Wt.inst.GuideStep = Mt.放披萨6, pi.getInst().player.arrow.target = ai.inst.singleTables[0].WorkerPoint)
                    }
                }
            }, {
                key: "_onTriggerExit",
                value: function () {}
            }, {
                key: "RespwanPizza",
                value: function () {
                    return this.leftPizzas.length > this.rightPizzas.length ? this.leftPizzas.pop() : this.rightPizzas.pop()
                }
            }, {
                key: "spwanPizza",
                value: function () {
                    if (this.crazyMode) return !1;
                    if (!(this.leftPizzas.length >= 30 && this.rightPizzas.length >= 30)) {
                        var e, t = Qn.inst.CreatePizza();
                        t.transform.position = this.spwanPos.transform.position, this.leftPizzas.length > this.rightPizzas.length ? (e = this.pizzaPointR.transform.position.clone(), this.rightPizzas.push(t), e.y = .18 * this.rightPizzas.length) : (e = this.pizzaPointL.transform.position.clone(), this.leftPizzas.push(t), e.y = .18 * this.leftPizzas.length), t.SpwanMove(e)
                    }
                }
            }, {
                key: "crazySpwan",
                value: function () {
                    var e;
                    this.crazyFX.active = !0, this.crazyMode = !0, (e = this.Count > 0 ? this.RespwanPizza() : Qn.inst.CreatePizza()).transform.position = this.spwanPos.transform.position;
                    var t = ai.inst.bigTable.EatPoint.transform.position;
                    e.SpwanToBigGuy(t), this.crazyIndex++, this.crazyIndex >= 180 ? (this.crazyIndex = 0, this.crazyMode = !1, this.crazyFX.active = !1) : Laya.timer.once(200, this, this.crazySpwan)
                }
            }, {
                key: "Count",
                get: function () {
                    return this.leftPizzas.length + this.rightPizzas.length
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("PizzaMaker", Co)
                }
            }]), PizzaMaker
        }();
    __decorate([bind_node("SpwanPoint")], Io.prototype, "spwanPos", void 0), __decorate([bind_node("[StackPointL]")], Io.prototype, "pizzaPointL", void 0), __decorate([bind_node("[StackPointR]")], Io.prototype, "pizzaPointR", void 0), __decorate([bind_node("fx_KAFEIJI")], Io.prototype, "crazyFX", void 0), __decorate([bind_node()], Io.prototype, "WorkerPoint", void 0), Io = Co = __decorate([auto_bind_node()], Io);
    var bo, Lo = ko = function (e) {
        function BoxMaker() {
            var e;
            return _classCallCheck(this, BoxMaker), (e = _possibleConstructorReturn(this, _getPrototypeOf(BoxMaker).apply(this, arguments))).pizzas = [], e.pizzaBoxes = [], e
        }
        return _inherits(BoxMaker, Rt), _createClass(BoxMaker, [{
            key: "onAwake",
            value: function () {
                this.Guide = this.sp.getChildByName("Guide");
                var e = this.sp.getChildByName("pizza_trigger").getComponent(wn);
                e.stayDelayDuration = 0, e.onStayCB = this.onPizzaTrigger.bind(this);
                var t = this.sp.getChildByName("pizza_box_trigger").getComponent(wn);
                t.tweenFade = !1, t.stayDelayDuration = 0, t.onStayCB = this.onBoxTrigger.bind(this), this._ani = this.Find("Supporter").getComponent(Laya.Animator), ai.inst.boxMakers.push(this)
            }
        }, {
            key: "onEnable",
            value: function () {
                Laya.timer.loop(2e3, this, this.packBox)
            }
        }, {
            key: "onStart",
            value: function () {
                ai.inst.pizzaCosters.push(this)
            }
        }, {
            key: "onDisable",
            value: function () {
                Laya.timer.clearAll(this)
            }
        }, {
            key: "onPizzaTrigger",
            value: function () {
                var e = pi.getInst().player,
                    t = this.GetPizzaFromX(e);
                t && (t.audio = !0)
            }
        }, {
            key: "GetPizzaFromX",
            value: function (e) {
                if (0 == e.pizzas.length) return null;
                var t = e.pizzas.pop(),
                    n = this.pizzas.length;
                this.pizzas.push(t);
                var i = this.Guide.transform.position.clone();
                return i.y += .2 * n, t.FlyToZone(i, 100, !1), t
            }
        }, {
            key: "onBoxTrigger",
            value: function () {
                if (!(this.pizzaBoxes.length <= 0 || pi.getInst().player.pizzaCount > 0 || pi.getInst().player.pizzaBoxCount >= Wt.inst.StackSize)) {
                    var e = this.pizzaBoxes.pop();
                    e.FlyToPlayer(!1), e.audio = !0
                }
            }
        }, {
            key: "packBox",
            value: function () {
                if (this.pizzas.length <= 0 || this.pizzaBoxes.length >= Nt.getInst().boxMakerMaxSize) this.PlayAni("Idle");
                else {
                    this.PlayAni("Standing");
                    var e = this.pizzas.pop(),
                        t = ci.inst.CreatePizzaBox();
                    t.transform.position = this.BoxBornPoint.transform.position, t.FlyToZone(this.BoxPoint.transform.position, 200, !1), Laya.timer.once(200, this, this._onBoxFlyToDesk, [t, e])
                }
            }
        }, {
            key: "_onBoxFlyToDesk",
            value: function (e, t) {
                e.Open(), Laya.timer.once(200, this, this._onBoxOpen, [e, t])
            }
        }, {
            key: "_onBoxOpen",
            value: function (e, t) {
                t.FlyToZone(this.BoxPoint.transform.position, 200, !1), Laya.timer.once(400, this, this._onPizzaFlyInBox, [e, t])
            }
        }, {
            key: "_onPizzaFlyInBox",
            value: function (e, t) {
                e.Close(), Laya.timer.once(400, this, this._onBoxClose, [e, t])
            }
        }, {
            key: "_onBoxClose",
            value: function (e, t) {
                var n = this.PackingStackPoint.transform.position.clone();
                n.y += .2 * this.pizzaBoxes.length, this.pizzaBoxes.push(e), e.FlyToZone(n, 200, !1), t.sp.destroy(!0)
            }
        }], [{
            key: "Init",
            value: function () {
                Laya.ClassUtils.regClass("BoxMaker", ko)
            }
        }]), BoxMaker
    }();
    __decorate([bind_node()], Lo.prototype, "Guide", void 0), __decorate([bind_node()], Lo.prototype, "BoxPoint", void 0), __decorate([bind_node()], Lo.prototype, "BoxBornPoint", void 0), __decorate([bind_node()], Lo.prototype, "PackingStackPoint", void 0), __decorate([bind_node()], Lo.prototype, "MovePoint", void 0), __decorate([bind_node()], Lo.prototype, "WorkerPoint", void 0), Lo = ko = __decorate([auto_bind_node()], Lo),
        function (e) {
            e[e.Standby = 0] = "Standby", e[e.Open = 1] = "Open", e[e.WaitingWalkingAI = 2] = "WaitingWalkingAI", e[e.Running = 3] = "Running"
        }(bo || (bo = {}));
    var Po, To, Ao = function (e) {
            function AccessibleBuilding() {
                var e;
                return _classCallCheck(this, AccessibleBuilding), (e = _possibleConstructorReturn(this, _getPrototypeOf(AccessibleBuilding).apply(this, arguments))).state = bo.Standby, e
            }
            return _inherits(AccessibleBuilding, Rt), AccessibleBuilding
        }(),
        wo = Po = function (e) {
            function SingleTable() {
                var e;
                return _classCallCheck(this, SingleTable), (e = _possibleConstructorReturn(this, _getPrototypeOf(SingleTable).apply(this, arguments))).pizzas = [], e.moneys = [], e.eatCount = 0, e
            }
            return _inherits(SingleTable, Ao), _createClass(SingleTable, [{
                key: "AddWaitCamper",
                value: function (e) {
                    this.eatCount = 0, this.state = bo.WaitingWalkingAI, this.customer = e, e.SetPath(this.comePath, this._onCustomerArrive.bind(this))
                }
            }, {
                key: "onAwake",
                value: function () {
                    var e = this.StackPoint.getComponent(wn);
                    e.stayDelayDuration = 0, e.stayCallDuration = 100, e.checkMove = !0, e.onStayCB = this._onTriggerStay.bind(this), N.getInst().on(Et.ReFindPath, this, this.findPath), ai.inst.pizzaCosters.push(this), ai.inst.singleTables.push(this)
                }
            }, {
                key: "onStart",
                value: function () {
                    this.Bored.active = !1, Laya.timer.once(1e3, this, this._delayStart)
                }
            }, {
                key: "_delayStart",
                value: function () {
                    si.inst.Register(this), this.findPath(), Laya.timer.loop(1e3, this, this.Eat)
                }
            }, {
                key: "onDestroy",
                value: function () {
                    si.inst.UnRegister(this), Laya.timer.clearAll(this), N.getInst().offAllCaller(this)
                }
            }, {
                key: "findPath",
                value: function () {
                    Laya.timer.frameOnce(1, this, this._findPath)
                }
            }, {
                key: "_findPath",
                value: function () {
                    var e = Yn.inst.FindPath(oi.inst.FindPathStartPoint2, this.NpcSeatPoint.transform.position);
                    e = null == e ? [oi.inst.FindPathStartPoint, oi.inst.FindPathStartPoint2, this.NpcSeatPoint.transform.position] : [oi.inst.FindPathStartPoint].concat(_toConsumableArray(e)), this.comePath = e, null == (e = Yn.inst.FindPath(this.NpcSeatPoint.transform.position, oi.inst.ExitPoint.transform.position)) ? e = [this.NpcSeatPoint.transform.position, oi.inst.ExitPoint.transform.position] : e.push(oi.inst.BornPoint.transform.position), this.backPath = e
                }
            }, {
                key: "_onCustomerArrive",
                value: function () {
                    this.state = bo.Running, this.customer.Sit(this.NpcSeatPoint)
                }
            }, {
                key: "_onTriggerStay",
                value: function () {
                    var e = pi.getInst().player;
                    if (!(e.pizzaCount <= 0)) {
                        var t = this.GetPizzaFromX(e);
                        t && (t.audio = !0), Wt.inst.GuideStep == Mt.放披萨6 && (Wt.inst.GuideStep = Mt.捡钱7, pi.getInst().player.arrow.target = ai.inst.singleTables[0].moneyPoint)
                    }
                }
            }, {
                key: "GetPizzaFromX",
                value: function (e) {
                    if (0 == e.pizzas.length) return null;
                    var t = e.pizzas.pop(),
                        n = this.pizzas.length;
                    this.pizzas.push(t);
                    var i = this.StackPoint.transform.position.clone();
                    return i.y += .2 * n, t.FlyToZone(i, 100, !1), t
                }
            }, {
                key: "Eat",
                value: function () {
                    if (this.Bored.active = !1, this.state != bo.Standby && this.state != bo.WaitingWalkingAI)
                        if (this.eatCount > 40) this.Leave();
                        else if (this.state == bo.Running)
                        if (this.pizzas.length > 0) {
                            this.customer.Eat(), this.eatCount++;
                            var e = this.pizzas.pop();
                            e.FlyToZone(this.EatPoint.transform.position, 100, !1), Laya.timer.once(700, e.sp, e.sp.destroy, [!0]), this.SpwanMoney()
                        } else this.customer && this.customer.PlayAni("Sitting"), this.Bored.active = !0;
                    else this.customer && this.customer.sitting && this.customer.PlayAni("Sitting"), this.customer && !this.customer.sitting && this.customer.PlayAni("Slow Run"), this.Bored.active = !1
                }
            }, {
                key: "Leave",
                value: function () {
                    this.state = bo.Standby, this.customer.Leave();
                    var e = this.customer;
                    this.customer.SetPath(this.backPath, function () {
                        e.sp.destroy(!0)
                    }), this.customer = null
                }
            }, {
                key: "SpwanMoney",
                value: function () {
                    if (this.moneys = this.moneys.filter(function (e) {
                            return !e.destroyed
                        }), !(this.moneys.length >= 180)) {
                        var e = this.moneyPoint.transform.position,
                            t = this.moneys.length,
                            n = Math.floor(t / 15),
                            i = t - 15 * n,
                            a = Math.floor(i / 5),
                            o = i - 5 * a,
                            s = ki.inst.CreateMoney(this.NpcSeatPoint.transform.position);
                        this.moneys.push(s.sp);
                        var r = new Laya.Vector3(e.x - .3 * o, e.y + .2 * n, e.z + .7 * a);
                        s.FlyToZone(r, 100, 0, !1)
                    }
                }
            }, {
                key: "IsOpen",
                get: function () {
                    return this.state == bo.Standby
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("SingleTable", Po)
                }
            }]), SingleTable
        }();
    __decorate([bind_node("[MoneyStack]")], wo.prototype, "moneyPoint", void 0), __decorate([bind_node()], wo.prototype, "Bored", void 0), __decorate([bind_node()], wo.prototype, "StackPoint", void 0), __decorate([bind_node()], wo.prototype, "NpcSeatPoint", void 0), __decorate([bind_node()], wo.prototype, "EatPoint", void 0), __decorate([bind_node()], wo.prototype, "WorkerPoint", void 0), wo = Po = __decorate([auto_bind_node()], wo);
    var Uo, Do = To = function (e) {
        function QuadTable() {
            var e;
            return _classCallCheck(this, QuadTable), (e = _possibleConstructorReturn(this, _getPrototypeOf(QuadTable).apply(this, arguments))).comePath = [], e.backPath = [], e.NpcSeatPoints = [], e.pizzas = [], e.moneys = [], e.customers = [], e.eatCount = 0, e
        }
        return _inherits(QuadTable, Ao), _createClass(QuadTable, [{
            key: "AddWaitCamper",
            value: function (e) {
                var t = this;
                this.eatCount = 0, e.SetPath(this.comePath[this.customers.length], function () {
                    t._onCustomerArrive(e)
                }), this.customers.push(e), 4 == this.customers.length && (this.state = bo.WaitingWalkingAI)
            }
        }, {
            key: "onAwake",
            value: function () {
                var e = this.StackPoint.getComponent(wn);
                e.stayDelayDuration = 0, e.stayCallDuration = 100, e.checkMove = !0, e.onStayCB = this._onTriggerStay.bind(this), N.getInst().on(Et.ReFindPath, this, this.findPath);
                for (var t = this.sp.getChildByName("NpcSeatPoints"), n = 0; n < 4; n++) this.NpcSeatPoints.push(t.getChildAt(n))
            }
        }, {
            key: "onStart",
            value: function () {
                this.Bored.active = !1, Laya.timer.once(1e3, this, this._delayStart), ai.inst.pizzaCosters.push(this)
            }
        }, {
            key: "_delayStart",
            value: function () {
                si.inst.Register(this), this.findPath(), Laya.timer.loop(1e3, this, this.Eat)
            }
        }, {
            key: "onDestroy",
            value: function () {
                si.inst.UnRegister(this), Laya.timer.clearAll(this), N.getInst().offAllCaller(this)
            }
        }, {
            key: "findPath",
            value: function () {
                Laya.timer.frameOnce(1, this, this._findPath)
            }
        }, {
            key: "_findPath",
            value: function () {
                for (var e = 0; e < 4; e++) {
                    var t = Yn.inst.FindPath(oi.inst.FindPathStartPoint2, this.NpcSeatPoints[e].transform.position);
                    t = null == t ? [oi.inst.FindPathStartPoint, oi.inst.FindPathStartPoint2, this.NpcSeatPoints[e].transform.position] : [oi.inst.FindPathStartPoint].concat(_toConsumableArray(t)), this.comePath[e] = t
                }
                for (var n = 0; n < 4; n++) {
                    var i = Yn.inst.FindPath(this.NpcSeatPoints[n].transform.position, oi.inst.ExitPoint.transform.position);
                    null == i ? i = [this.NpcSeatPoints[n].transform.position, oi.inst.ExitPoint.transform.position] : i.push(oi.inst.BornPoint.transform.position), this.backPath[n] = i
                }
            }
        }, {
            key: "_onCustomerArrive",
            value: function (e) {
                e.Sit(this.NpcSeatPoints[this.customers.indexOf(e)]), e.PlayAni("Sitting");
                for (var t = 0; t < 4; t++)
                    if (null == this.customers[t] || !this.customers[t].sitting) return;
                this.state = bo.Running
            }
        }, {
            key: "_onTriggerStay",
            value: function () {
                var e = pi.getInst().player;
                if (!(e.pizzaCount <= 0)) {
                    var t = this.GetPizzaFromX(e);
                    t && (t.audio = !0)
                }
            }
        }, {
            key: "GetPizzaFromX",
            value: function (e) {
                if (0 == e.pizzas.length) return null;
                var t = e.pizzas.pop(),
                    n = this.pizzas.length;
                this.pizzas.push(t);
                var i = this.StackPoint.transform.position.clone();
                return i.y += .2 * n, t.FlyToZone(i, 100, !1), t
            }
        }, {
            key: "Eat",
            value: function () {
                if (this.state != bo.Standby && this.state != bo.WaitingWalkingAI)
                    if (this.eatCount > 40) this.Leave();
                    else if (this.state == bo.Running)
                    if (this.pizzas.length > 0) {
                        this.customers.forEach(function (e) {
                            e && e.Eat()
                        }), this.eatCount++;
                        var e = this.pizzas.pop();
                        e.FlyToZone(this.EatPoint.transform.position, 100, !1), Laya.timer.once(700, e.sp, e.sp.destroy, [!0]), this.SpwanMoney()
                    } else this.customers.forEach(function (e) {
                        e && e.PlayAni("Sitting")
                    }), this.Bored.active = !0;
                else this.customers.forEach(function (e) {
                    e && e.sitting && e.PlayAni("Sitting"), e && !e.sitting && e.PlayAni("Slow Run")
                }), this.Bored.active = !1
            }
        }, {
            key: "Leave",
            value: function () {
                var e = this;
                this.state = bo.Standby;
                var t = 0;
                this.customers.forEach(function (n) {
                    n && (n.Leave(), n.SetPath(e.backPath[t++], function () {
                        n.sp.destroy(!0)
                    }))
                }), this.customers = []
            }
        }, {
            key: "SpwanMoney",
            value: function () {
                if (this.moneys = this.moneys.filter(function (e) {
                        return !e.destroyed
                    }), !(this.moneys.length >= 180)) {
                    var e = this.moneyPoint.transform.position,
                        t = this.moneys.length,
                        n = Math.floor(t / 15),
                        i = t - 15 * n,
                        a = Math.floor(i / 5),
                        o = i - 5 * a,
                        s = ki.inst.CreateMoney(this.StackPoint.transform.position);
                    this.moneys.push(s.sp);
                    var r = new Laya.Vector3(e.x - .3 * o, e.y + .2 * n, e.z + .7 * a);
                    s.FlyToZone(r, 100, 0, !1)
                }
            }
        }, {
            key: "IsOpen",
            get: function () {
                return this.state == bo.Standby
            }
        }], [{
            key: "Init",
            value: function () {
                Laya.ClassUtils.regClass("QuadTable", To)
            }
        }]), QuadTable
    }();
    __decorate([bind_node("[MoneyStack]")], Do.prototype, "moneyPoint", void 0), __decorate([bind_node()], Do.prototype, "Bored", void 0), __decorate([bind_node()], Do.prototype, "StackPoint", void 0), __decorate([bind_node()], Do.prototype, "EatPoint", void 0), __decorate([bind_node()], Do.prototype, "WorkerPoint", void 0), Do = To = __decorate([auto_bind_node()], Do);
    var Mo, Eo = Uo = function (e) {
        function Rider() {
            var e;
            return _classCallCheck(this, Rider), (e = _possibleConstructorReturn(this, _getPrototypeOf(Rider).apply(this, arguments))).isWait = !1, e.moneys = [], e
        }
        return _inherits(Rider, Rt), _createClass(Rider, [{
            key: "onStart",
            value: function () {
                this.transform.position = ai.inst.RiderEnterPos.transform.position, this.transform.rotation = ai.inst.RiderPos.transform.rotation, this.GoToWait()
            }
        }, {
            key: "onDestroy",
            value: function () {
                this.ClearAsycFunc()
            }
        }, {
            key: "GoToWait",
            value: function () {
                Laya.Tween.to(this.transform.position, ai.inst.RiderPos.transform.position, 2e3, null, Laya.Handler.create(this, this._onTouchWaitPos)).update = Laya.Handler.create(this, this.UpdatePosition, null, !1)
            }
        }, {
            key: "GoToExit",
            value: function (e) {
                var t = ai.inst.RiderMoneyPos.transform.position;
                if (this.moneys = this.moneys.filter(function (e) {
                        return !e.destroyed
                    }), !(this.moneys.length >= 180)) {
                    for (var n = this.moneys.length, i = Math.min(180, n + e), a = n; a < i; a++) {
                        var o = Math.floor(a / 15),
                            s = a - 15 * o,
                            r = Math.floor(s / 5),
                            l = s - 5 * r,
                            u = ki.inst.CreateMoney(this.transform.position, !0);
                        this.moneys.push(u.sp), new Laya.Vector3(t.x - .3 * l, t.y + .2 * o, t.z + .7 * r), u.FlyToZone(pi.getInst().player.transform.position, 300, 10 * (a - n), !0), M.WaitTime(10 * (a - n) + 300).then(function () {
                            Wt.inst.Money += Wt.inst.Price
                        })
                    }
                    this.isWait = !1, Laya.Tween.to(this.transform.position, ai.inst.RiderExitPos.transform.position, 2e3, null, Laya.Handler.create(this, this._onExited), 400).update = Laya.Handler.create(this, this.UpdatePosition, null, !1)
                }
            }
        }, {
            key: "_onExited",
            value: function () {
                this.transform.position = ai.inst.RiderEnterPos.transform.position, this.BoxPoint.destroyChildren(), this.GoToWait()
            }
        }, {
            key: "_onTouchWaitPos",
            value: function () {
                this.isWait = !0;
                var e = this.Find("trigger").getComponent(Ii);
                e.fade = !1, e.checkMove = !1, e.stayDelayDuration = 0, e.stayCallDuration = 40, e.onStart(), e.onStayCB = this._onTriggerStay.bind(this)
            }
        }, {
            key: "_udpateRiderPos",
            value: function () {
                this.transform.position = this.transform.position
            }
        }, {
            key: "_onTriggerStay",
            value: function () {
                if (this.isWait) {
                    var e = pi.getInst().player;
                    if (!(e.pizzaBoxCount <= 0)) {
                        var t = this.BoxPoint.numChildren,
                            n = this.BoxPoint.transform.position.clone();
                        n.y += .2 * t;
                        var i = e.ReaspwanPizzaBox(this.BoxPoint);
                        i.FlyToZone(n, 60, !1), i.audio = !0, e.pizzaBoxCount <= 0 && this.GoToExit(this.BoxPoint.numChildren)
                    }
                }
            }
        }], [{
            key: "Init",
            value: function () {
                Laya.ClassUtils.regClass("Rider", Uo)
            }
        }]), Rider
    }();
    __decorate([bind_node()], Eo.prototype, "BoxPoint", void 0), Eo = Uo = __decorate([auto_bind_node()], Eo);
    var Ro = Mo = function (e) {
        function SingleTableBig() {
            var e;
            return _classCallCheck(this, SingleTableBig), (e = _possibleConstructorReturn(this, _getPrototypeOf(SingleTableBig).apply(this, arguments))).moneys = [], e
        }
        return _inherits(SingleTableBig, Rt), _createClass(SingleTableBig, [{
            key: "onAwake",
            value: function () {
                this._ani = this.Find("CustomerBig").getComponent(Laya.Animator), N.getInst().on(Et.PizzaAttouchBigGuy, this, this.onPizzaCom), this.PlayAni("Sitting02"), ai.inst.bigTable = this
            }
        }, {
            key: "onStart",
            value: function () {
                Wt.inst.ShopCrazyMode ? (Wt.inst.ShopCrazyMode = !1, N.getInst().event(Et.StartCrazyMode)) : this.addADTrigger()
            }
        }, {
            key: "onDestroy",
            value: function () {
                N.getInst().offAllCaller(this), Laya.timer.clearAll(this)
            }
        }, {
            key: "addADTrigger",
            value: function () {
                var e = this,
                    t = Laya.Sprite3D.instantiate(qt.getInst().GetPrefab(Ot.AdUnlockTag));
                this.sp.addChild(t), t.transform.position = this.AdUnlockTagPos.transform.position, t.transform.rotationEuler = new Laya.Vector3(0, 90, 0);
                var n = t.getComponent(Un);
                n.useAD = !1, n.FullCB = function () {
                    mt.showADVideo(e, function (e) {
                        e && (G.inst.playSound("SFX_Upgrade"), N.getInst().event(Et.StartCrazyMode))
                    }, "Unlock big desk")
                }
            }
        }, {
            key: "onPizzaCom",
            value: function () {
                this.ani.speed = 6, this.PlayAni("Sitting_Yell"), this.SpwanMoney(), Laya.timer.once(500, this, this.resetState, null, !0), G.inst.playSound("popsounds")
            }
        }, {
            key: "resetState",
            value: function () {
                this.ani.speed = 1, this.PlayAni("Sitting02"), this.addADTrigger()
            }
        }, {
            key: "SpwanMoney",
            value: function () {
                if (this.moneys = this.moneys.filter(function (e) {
                        return !e.destroyed
                    }), !(this.moneys.length >= 180)) {
                    var e = this.moneyPoint.transform.position,
                        t = this.moneys.length,
                        n = Math.floor(t / 15),
                        i = t - 15 * n,
                        a = Math.floor(i / 5),
                        o = i - 5 * a,
                        s = ki.inst.CreateMoney(this.EatPoint.transform.position);
                    this.moneys.push(s.sp);
                    var r = new Laya.Vector3(e.x - .3 * o, e.y + .2 * n, e.z + .7 * a);
                    s.FlyToZone(r, 100, 0, !1)
                }
            }
        }], [{
            key: "Init",
            value: function () {
                Laya.ClassUtils.regClass("SingleTableBig", Mo)
            }
        }]), SingleTableBig
    }();
    __decorate([bind_node("[MoneyStack]")], Ro.prototype, "moneyPoint", void 0), __decorate([bind_node()], Ro.prototype, "EatPoint", void 0), __decorate([bind_node()], Ro.prototype, "AdUnlockTagPos", void 0), Ro = Mo = __decorate([auto_bind_node()], Ro);
    var xo = function (e) {
        function SupporterUpUI() {//todo:升级界面
            return _classCallCheck(this, SupporterUpUI), _possibleConstructorReturn(this, _getPrototypeOf(SupporterUpUI).apply(this, arguments))
        }
        return _inherits(SupporterUpUI, Fe), _createClass(SupporterUpUI, [{
            key: "OnCreate",
            value: function () {
                this.ui.m_btn_close0.onClick(this, this.onClickClose),
					this.ui.m_btn_close1.onClick(this, this.onClickClose),
					this.ui.m_btn_close2.onClick(this, this.onClickClose),
					this.ui.m_view.m_btn_shengji1.m_btn_.onClick(this, this.onClickSpeed),
					this.ui.m_view.m_btn_shengji1.m_btn_get.onClick(this, this.onClickSpeedAD), 
					this.ui.m_view.m_btn_shengji2.m_btn_.onClick(this, this.onClickStack),
					this.ui.m_view.m_btn_shengji2.m_btn_get.onClick(this, this.onClickStackAD),
					this.ui.m_view.m_btn_shengji3.m_btn_.onClick(this, this.onClickCount),
					this.ui.m_view.m_btn_shengji3.m_btn_get.onClick(this, this.onClickCountAD)
				this.ui.m_view.m_text_biaoti.width = 500;
				this.ui.m_view.m_text_biaoti.x = 100;
	
				this.ui.m_view.m_btn_shengji1.m_text_miaoshu.width = this.ui.m_view.m_btn_shengji2.m_text_miaoshu.width = this.ui.m_view.m_btn_shengji3.m_text_miaoshu.width = 200;
				this.ui.m_view.m_btn_shengji1.m_text_miaoshu.x = this.ui.m_view.m_btn_shengji2.m_text_miaoshu.x = this.ui.m_view.m_btn_shengji3.m_text_miaoshu.x = 0;
            }
        }, {
            key: "OnShow",
            value: function () {
                this.updateSpeed(), this.updateStack(), this.updateCount()
            }
        }, {
            key: "OnHide",
            value: function () {}
        }, {
            key: "OnDispose",
            value: function () {}
        }, {
            key: "updateSpeed",
            value: function () {
                var e = this.ui.m_view.m_btn_shengji1,
                    t = e.m_btn_,
                    n = e.m_list_dengji;
                if (Wt.inst.ShopSupportIsMaxSpeedLevel) {
                    e.m_max.selectedIndex = 1;
                    for (var i = 0; i < 4; i++) {
                        (r = n.getChildAt(i)).m_c1.selectedIndex = 1
                    }
                } else {
                    e.m_max.selectedIndex = 0, t.m_c1.selectedIndex = 0;
                    var a = Nt.getInst().workerSpeed,
                        o = Wt.inst.ShopSupportSpeedLevel;
                    for (i = 0; i < 4; i++) {
                        var s = a[i],
                            r = n.getChildAt(i);
                        o > i ? r.m_c1.selectedIndex = 1 : o == i ? (r.m_c1.selectedIndex = 0, t.m_text_chaopiao.text = s.unlockCoin + "") : (i == a.length - 1 && (t.m_c1.selectedIndex = 2), r.m_c1.selectedIndex = 0)
                    }
                }
            }
        }, {
            key: "onClickSpeed",
            value: function () {
                Wt.inst.ShopSupportIsMaxSpeedLevel || (Wt.inst.Money >= Wt.inst.ShopSupportNextSpeedLevelCost ? (Wt.inst.Money -= Wt.inst.ShopSupportNextSpeedLevelCost, Wt.inst.ShopSupportSpeedLevel++, this.updateSpeed(), N.getInst().event(Et.UpgradeSkillNotice)) : no.Tips("Money deficit!"))
            }
        }, {
            key: "onClickSpeedAD",
            value: function () {
                var e = this;
                mt.showADVideo(this, function (t) {
                    t && (Wt.inst.ShopSupportSpeedLevel++, e.updateSpeed(), N.getInst().event(Et.UpgradeSkillNotice))
                }, "Upgrade")
            }
        }, {
            key: "updateStack",
            value: function () {
                var e = this.ui.m_view.m_btn_shengji2,
                    t = e.m_btn_,
                    n = e.m_list_dengji;
                if (Wt.inst.ShopSupportIsMaxStackLevel) {
                    e.m_max.selectedIndex = 1;
                    for (var i = 0; i < 4; i++) {
                        (r = n.getChildAt(i)).m_c1.selectedIndex = 1
                    }
                } else {
                    e.m_max.selectedIndex = 0, t.m_c1.selectedIndex = 0;
                    var a = Nt.getInst().workerStackCapacity,
                        o = Wt.inst.ShopSupportStackLevel;
                    for (i = 0; i < 4; i++) {
                        var s = a[i],
                            r = n.getChildAt(i);
                        o > i ? r.m_c1.selectedIndex = 1 : o == i ? (r.m_c1.selectedIndex = 0, t.m_text_chaopiao.text = s.unlockCoin + "") : (i == a.length - 1 && (t.m_c1.selectedIndex = 2), r.m_c1.selectedIndex = 0)
                    }
                }
            }
        }, {
            key: "onClickStack",
            value: function () {
                Wt.inst.ShopSupportIsMaxStackLevel || (Wt.inst.Money >= Wt.inst.ShopSupportNextStackLevelCost ? (Wt.inst.Money -= Wt.inst.ShopSupportNextStackLevelCost, Wt.inst.ShopSupportStackLevel++, this.updateStack(), N.getInst().event(Et.UpgradeSkillNotice)) : no.Tips("Money deficit!"))
            }
        }, {
            key: "onClickStackAD",
            value: function () {
                var e = this;
                mt.showADVideo(this, function (t) {
                    t && (Wt.inst.ShopSupportStackLevel++, e.updateStack(), N.getInst().event(Et.UpgradeSkillNotice))
                }, "Upgrade")
            }
        }, {
            key: "updateCount",
            value: function () {
                var e = this.ui.m_view.m_btn_shengji3,
                    t = e.m_btn_,
                    n = e.m_list_dengji;
                if (Wt.inst.ShopSupportIsMaxCountLevel) {
                    e.m_max.selectedIndex = 1;
                    for (var i = 0; i < 4; i++) {
                        (r = n.getChildAt(i)).m_c1.selectedIndex = 1
                    }
                } else {
                    e.m_max.selectedIndex = 0, t.m_c1.selectedIndex = 0;
                    var a = Nt.getInst().workertCount,
                        o = Wt.inst.ShopSupportCountLevel;
                    for (i = 0; i < 4; i++) {
                        var s = a[i],
                            r = n.getChildAt(i);
                        o > i ? r.m_c1.selectedIndex = 1 : o == i ? (r.m_c1.selectedIndex = 0, t.m_text_chaopiao.text = s.unlockCoin + "") : (i == a.length - 1 && (t.m_c1.selectedIndex = 2), r.m_c1.selectedIndex = 0)
                    }
                }
            }
        }, {
            key: "onClickCount",
            value: function () {
                Wt.inst.ShopSupportIsMaxCountLevel || (Wt.inst.Money >= Wt.inst.ShopSupportNextCountLevelCost ? (Wt.inst.Money -= Wt.inst.ShopSupportNextCountLevelCost, Wt.inst.ShopSupportCountLevel++, this.updateCount(), N.getInst().event(Et.UpdateSupport)) : no.Tips("Money deficit!"))
            }
        }, {
            key: "onClickCountAD",
            value: function () {
                var e = this;
                mt.showADVideo(this, function (t) {
                    t && (Wt.inst.ShopSupportCountLevel++, e.updateCount(), N.getInst().event(Et.UpdateSupport))
                }, "Upgrade")
            }
        }, {
            key: "onClickClose",
            value: function () {
				Plat.I.ShowInter();
                j.inst.PopUI(this.layer, !0)
            }
        }, {
            key: "FullScreenItems",
            get: function () {
                return [this.ui.m_bg]
            }
        }, {
            key: "ShopIndex",
            get: function () {
                return Wo.getInst().gameBlackBoard.currentShopIndex
            }
        }]), SupporterUpUI
    }();
    __decorate([throttle(1e3)], xo.prototype, "onClickSpeedAD", null), __decorate([throttle(1e3)], xo.prototype, "onClickStackAD", null), __decorate([throttle(1e3)], xo.prototype, "onClickCountAD", null), xo = __decorate([ui_register(wa, Fa)], xo);
    var Oo = function (t) {
            function HRTable() {
                return _classCallCheck(this, HRTable), _possibleConstructorReturn(this, _getPrototypeOf(HRTable).apply(this, arguments))
            }
            return _inherits(HRTable, Rt), _createClass(HRTable, [{
                key: "onAwake",
                value: function () {
                    var e = this.Find("trigger").getComponent(Ii);
                    e.onEnterCB = this._onTriggerEnter.bind(this), e.onExitCB = this._onTriggerExit.bind(this)
                }
            }, {
                key: "_onTriggerEnter",
                value: function () {
                    j.inst.PushUI(xo, e.mid)
                }
            }, {
                key: "_onTriggerExit",
                value: function () {
                    j.inst.PopUI(e.mid, !0)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("HRTable", HRTable)
                }
            }]), HRTable
        }(),
        No = function (e) {
            function RoleUpUI() {//todo:升级玩家界面
                return _classCallCheck(this, RoleUpUI), _possibleConstructorReturn(this, _getPrototypeOf(RoleUpUI).apply(this, arguments))
            }
            return _inherits(RoleUpUI, Fe), _createClass(RoleUpUI, [{
                key: "OnCreate",
                value: function () {
                    this.ui.m_btn_close0.onClick(this, this.onClickClose), this.ui.m_btn_close1.onClick(this, this.onClickClose), this.ui.m_btn_close2.onClick(this, this.onClickClose), this.ui.m_view.m_btn_shengji1.m_btn_.onClick(this, this.onClickSpeed), this.ui.m_view.m_btn_shengji1.m_btn_get.onClick(this, this.onClickSpeedAD), this.ui.m_view.m_btn_shengji2.m_btn_.onClick(this, this.onClickStack), this.ui.m_view.m_btn_shengji2.m_btn_get.onClick(this, this.onClickStackAD), this.ui.m_view.m_btn_shengji3.m_btn_.onClick(this, this.onClickPrice), this.ui.m_view.m_btn_shengji3.m_btn_get.onClick(this, this.onClickPriceAD)
                }
            }, {
                key: "OnShow",
                value: function () {
                    this.updateSpeed(), this.updateStack(), this.updatePrice()
                }
            }, {
                key: "OnHide",
                value: function () {}
            }, {
                key: "OnDispose",
                value: function () {}
            }, {
                key: "updateSpeed",
                value: function () {
                    var e = this.ui.m_view.m_btn_shengji1,
                        t = e.m_btn_,
                        n = e.m_list_dengji;
                    if (Wt.inst.IsMaxSpeedLevel) {
                        e.m_max.selectedIndex = 1;
                        for (var i = 0; i < 4; i++) {
                            (r = n.getChildAt(i)).m_c1.selectedIndex = 1
                        }
                    } else {
                        e.m_max.selectedIndex = 0, t.m_c1.selectedIndex = 0;
                        var a = Nt.getInst().playerSpeed,
                            o = Wt.inst.SpeedLevel;
                        for (i = 0; i < 4; i++) {
                            var s = a[i],
                                r = n.getChildAt(i);
                            o > i ? r.m_c1.selectedIndex = 1 : o == i ? (r.m_c1.selectedIndex = 0, t.m_text_chaopiao.text = s.unlockCoin + "") : (i == a.length - 1 && (t.m_c1.selectedIndex = 2), r.m_c1.selectedIndex = 0)
                        }
                    }
                }
            }, {
                key: "onClickSpeed",
                value: function () {
                    Wt.inst.IsMaxSpeedLevel || (Wt.inst.Money >= Wt.inst.NextSpeedLevelCost ? (Wt.inst.Money -= Wt.inst.NextPriceLevelCost, Wt.inst.SpeedLevel++, this.updateSpeed(), N.getInst().event(Et.UpgradeSkillNotice)) : no.Tips("Money deficit!"))
                }
            }, {
                key: "onClickSpeedAD",
                value: function () {
                    var e = this;
                    mt.showADVideo(this, function (t) {
                        t && (Wt.inst.SpeedLevel++, e.updateSpeed(), N.getInst().event(Et.UpgradeSkillNotice))
                    }, "Upgrade")
                }
            }, {
                key: "updateStack",
                value: function () {
                    var e = this.ui.m_view.m_btn_shengji2,
                        t = e.m_btn_,
                        n = e.m_list_dengji;
                    if (Wt.inst.IsMaxStackLevel) {
                        e.m_max.selectedIndex = 1;
                        for (var i = 0; i < 4; i++) {
                            (r = n.getChildAt(i)).m_c1.selectedIndex = 1
                        }
                    } else {
                        e.m_max.selectedIndex = 0, t.m_c1.selectedIndex = 0;
                        var a = Nt.getInst().playerStackCapacity,
                            o = Wt.inst.StackLevel;
                        for (i = 0; i < 4; i++) {
                            var s = a[i],
                                r = n.getChildAt(i);
                            o > i ? r.m_c1.selectedIndex = 1 : o == i ? (r.m_c1.selectedIndex = 0, t.m_text_chaopiao.text = s.unlockCoin + "") : (i == a.length - 1 && (t.m_c1.selectedIndex = 2), r.m_c1.selectedIndex = 0)
                        }
                    }
                }
            }, {
                key: "onClickStack",
                value: function () {
                    Wt.inst.IsMaxStackLevel || (Wt.inst.Money >= Wt.inst.NextStackLevelCost ? (Wt.inst.Money -= Wt.inst.NextStackLevelCost, Wt.inst.StackLevel++, this.updateStack(), N.getInst().event(Et.UpgradeSkillNotice)) : no.Tips("Money deficit!"))
                }
            }, {
                key: "onClickStackAD",
                value: function () {
                    var e = this;
                    mt.showADVideo(this, function (t) {
                        t && (Wt.inst.StackLevel++, e.updateStack(), N.getInst().event(Et.UpgradeSkillNotice))
                    }, "Upgrade")
                }
            }, {
                key: "updatePrice",
                value: function () {
                    var e = this.ui.m_view.m_btn_shengji3,
                        t = e.m_btn_,
                        n = e.m_list_dengji;
                    if (Wt.inst.IsMaxPriceLevel) {
                        e.m_max.selectedIndex = 1;
                        for (var i = 0; i < 4; i++) {
                            (r = n.getChildAt(i)).m_c1.selectedIndex = 1
                        }
                    } else {
                        e.m_max.selectedIndex = 0, t.m_c1.selectedIndex = 0;
                        var a = Nt.getInst().playerPrice,
                            o = Wt.inst.PriceLevel;
                        for (i = 0; i < 4; i++) {
                            var s = a[i],
                                r = n.getChildAt(i);
                            o > i ? r.m_c1.selectedIndex = 1 : o == i ? (r.m_c1.selectedIndex = 0, t.m_text_chaopiao.text = s.unlockCoin + "") : (i == a.length - 1 && (t.m_c1.selectedIndex = 2), r.m_c1.selectedIndex = 0)
                        }
                    }
                }
            }, {
                key: "onClickPrice",
                value: function () {
                    Wt.inst.IsMaxPriceLevel || (Wt.inst.Money >= Wt.inst.NextPriceLevelCost ? (Wt.inst.Money -= Wt.inst.NextPriceLevelCost, Wt.inst.PriceLevel++, this.updatePrice(), N.getInst().event(Et.UpgradeSkillNotice)) : no.Tips("Money deficit!"))
                }
            }, {
                key: "onClickPriceAD",
                value: function () {
                    var e = this;
                    mt.showADVideo(this, function (t) {
                        t && (Wt.inst.PriceLevel++, e.updatePrice(), N.getInst().event(Et.UpgradeSkillNotice))
                    }, "Upgrade")
                }
            }, {
                key: "onClickClose",
                value: function () {
					Plat.I.ShowInter()
                    j.inst.PopUI(this.layer, !0)
                }
            }, {
                key: "FullScreenItems",
                get: function () {
                    return [this.ui.m_bg]
                }
            }, {
                key: "ShopIndex",
                get: function () {
                    return Wo.getInst().gameBlackBoard.currentShopIndex
                }
            }]), RoleUpUI
        }();
    __decorate([throttle(1e3)], No.prototype, "onClickSpeedAD", null), __decorate([throttle(1e3)], No.prototype, "onClickStackAD", null), __decorate([throttle(1e3)], No.prototype, "onClickPriceAD", null), No = __decorate([ui_register(Ta, Fa)], No);
    var Bo, Go = function (t) {
            function UpgradeTable() {
                return _classCallCheck(this, UpgradeTable), _possibleConstructorReturn(this, _getPrototypeOf(UpgradeTable).apply(this, arguments))
            }
            return _inherits(UpgradeTable, Rt), _createClass(UpgradeTable, [{
                key: "onAwake",
                value: function () {
                    var e = this.Find("trigger").getComponent(Ii);
                    e.onEnterCB = this._onTriggerEnter.bind(this), e.onExitCB = this._onTriggerExit.bind(this)
                }
            }, {
                key: "_onTriggerEnter",
                value: function () {
                    j.inst.PushUI(No, e.mid)
                }
            }, {
                key: "_onTriggerExit",
                value: function () {
                    j.inst.PopUI(e.mid, !0)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("UpgradeTable", UpgradeTable)
                }
            }]), UpgradeTable
        }(),
        Vo = function (e) {
            function Airplane() {
                return _classCallCheck(this, Airplane), _possibleConstructorReturn(this, _getPrototypeOf(Airplane).apply(this, arguments))
            }
            return _inherits(Airplane, Rt), _createClass(Airplane, [{
                key: "onUpdate",
                value: function () {
                    N.getInst().event(Et.UpdateAirplanePos, this.transform.position)
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("Airplane", Airplane)
                }
            }]), Airplane
        }(),
        zo = function (e) {
            function MoneyAD() {
                var e;
                return _classCallCheck(this, MoneyAD), (e = _possibleConstructorReturn(this, _getPrototypeOf(MoneyAD).apply(this, arguments))).endColor = new Laya.Vector4(1, 0, 0, 1), e.cd = 30, e
            }
            return _inherits(MoneyAD, Rt), _createClass(MoneyAD, [{
                key: "onStart",
                value: function () {
                    var e = this.Find("AdUnlockTag").getComponent(Un);
                    e.useAD = !1, e.FullCB = this.onTrigger.bind(this);
                    var t = (this.sp.getChildByName("ProgressCD") || this.sp.getChildAt(0)).meshRenderer;
                    this.mat = t.material, this.startColor = this.mat._Color.clone(), Laya.timer.frameLoop(1, this, this._cd)
                }
            }, {
                key: "_cd",
                value: function () {
                    this.cd -= F.deltaTimeSec, this.cd <= 0 ? this.sp.destroy(!0) : this.mat._Value = this.cd / 30
                }
            }, {
                key: "onTrigger",
                value: function () {
                    mt.showADVideo(this, function (e) {
                        e && (Wt.inst.Money += 500, no.Tips("Get money +500"))
                    }, "Get money"), this.sp.active = !1, Laya.timer.callLater(this.sp, this.sp.destroy, [!0])
                }
            }], [{
                key: "Init",
                value: function () {
                    Laya.ClassUtils.regClass("MoneyAD", MoneyAD)
                }
            }]), MoneyAD
        }(),
        Fo = function (e) {
            function GameLauchState() {
                var e;
                return _classCallCheck(this, GameLauchState),
					(e = _possibleConstructorReturn(this, _getPrototypeOf(GameLauchState).apply(this, arguments))).name = "GameLauchState", e
            }
            return _inherits(GameLauchState, Ut), _createClass(GameLauchState, [{
                key: "OnInit",
                value: function () {}
            }, {
                key: "OnEnter",
                value: function () {
                    var e = this;
                    lt.inst.sendReport(et.LOADING_START),
						Laya.loader.load("splash.jpg", Laya.Handler.create(this, function () {
                        window.splash && window.splash.end();
                        var t = new Laya.Sprite;
                        t.name = "holderImg",
							t.loadImage("splash.jpg", Laya.Handler.create(e, function () {
                            t.height = Laya.Browser.height, t.width = Laya.Browser.width
                        })), Laya.stage.addChild(t), e.prepare()
                    }))
                }
            }, {
                key: "prepare",
                value: function () {
                    var e = this;
                    this.RegisterMaterial(), 
						this.RegisterCom(),
						yi.getInst().Register(),
						mt.registShowCaller(this, function () {
                        Laya.timer.callLater(e, function () {
                            G.inst.PlayBGM("Bgm")
                        })
                    })
                }
            }, {
                key: "RegisterMaterial",
                value: function () {
                    wi.init(), Ui.init(), So.Init()
                }
            }, {
                key: "RegisterCom",
                value: function () {
                    Yn.Init(), bi.Init(), xt.Init(), Ii.Init(), wn.Init(), ki.Init(), oi.Init(), ii.Init(),
						ri.Init(), go.Init(), mo.Init(), xn.Init(), Un.Init(), Io.Init(), Lo.Init(), wo.Init(),
						Ro.Init(), Do.Init(), Eo.Init(), Oo.Init(), Go.Init(), Vo.Init(), Ya.Init(), zo.Init(),
						Pi.Init(), Li.Init(), this.ChangeState(_o)
                }
            }, {
                key: "OnUpdate",
                value: function (e) {}
            }, {
                key: "OnLeave",
                value: function () {}
            }, {
                key: "OnDestroy",
                value: function () {}
            }]), GameLauchState
        }();
    Fo = __decorate([add_state_map()], Fo),
        function (e) {
            e.EnterBattleGame = "EnterBattleGame", e.StartBattle = "StartBattle", e.StopBattle = "StopBattle"
        }(Bo || (Bo = {}));
    var Ho = function (e) {
        function MainUIState() {
            var e;
            return _classCallCheck(this, MainUIState), (e = _possibleConstructorReturn(this, _getPrototypeOf(MainUIState).apply(this, arguments))).name = "MainUIState", e
        }
        return _inherits(MainUIState, Ut), _createClass(MainUIState, [{
            key: "OnInit",
            value: function () {}
        }, {
            key: "OnEnter",
            value: function () {
                N.getInst().on(Bo.EnterBattleGame, this, this.onEnterBattleGame), G.inst.PlayBGM("Bgm"), mt.initConfig(function () {})
            }
        }, {
            key: "OnUpdate",
            value: function (e) {}
        }, {
            key: "OnLeave",
            value: function () {
                N.getInst().off(Bo.EnterBattleGame, this, this.onEnterBattleGame)
            }
        }, {
            key: "OnDestroy",
            value: function () {}
        }, {
            key: "onEnterBattleGame",
            value: function () {}
        }]), MainUIState
    }();
    Ho = __decorate([add_state_map()], Ho);
    var jo = function () {
            function GameBlackboard() {
                _classCallCheck(this, GameBlackboard), this._currentShopIndex = 0, this.GameTime = 0
            }
            return _createClass(GameBlackboard, [{
                key: "ClearGame",
                value: function () {}
            }, {
                key: "currentShopIndex",
                get: function () {
                    return this._currentShopIndex
                },
                set: function (e) {
                    this._currentShopIndex = e, this._currentShopIndex > Nt.getInst().levels.length - 1 && (this._currentShopIndex = 0)
                }
            }]), GameBlackboard
        }(),
        Wo = function (e) {
            function GameManager() {
                var e;
                return _classCallCheck(this, GameManager), (e = _possibleConstructorReturn(this, _getPrototypeOf(GameManager).call(this))).gameBlackBoard = new jo, e
            }
            return _inherits(GameManager, O), _createClass(GameManager, [{
                key: "Run",
                value: function () {
					Plat.I.SendAnay(Plat.Loading_Begin)
                    this.gameProcedureFsm = At.getInst().CreateFsm("game_manager",
						this.gameBlackBoard, [new Fo, new _o, new fo, new ho, new Dt, new lo, new Ho], !0),
						this.gameProcedureFsm.Start(Fo),
						this.gameProcedureFsm.SetData("debug", !0),
						Laya.timer.frameLoop(1, this, this.OnUpdate),
						Laya.stage.on(Laya.Event.KEY_UP, this, this.onKey)
                }
            }, {
                key: "Pause",
                value: function () {
                    Laya.timer.clear(this, this.OnUpdate)
                }
            }, {
                key: "Resume",
                value: function () {
                    Laya.timer.frameLoop(1, this, this.OnUpdate)
                }
            }, {
                key: "Stop",
                value: function () {
                    Laya.timer.clear(this, this.OnUpdate)
                }
            }, {
                key: "Reset",
                value: function () {
                    var e = this;
                    Laya.timer.callLater(this, function () {
                        e.gameProcedureFsm.Owner.ClearGame()
                    })
                }
            }, {
                key: "OnUpdate",
                value: function () {
                    At.getInst().Update(F.deltaTimeSec * Laya.timer.scale)
                }
            }, {
                key: "GoToShop",
                value: function (e) {
                    this.gameBlackBoard.currentShopIndex = e, this.gameProcedureFsm.ChangeState(ho, !1, Nt.getInst().levels[e])
                }
            }, {
                key: "onKey",
                value: function (e) {
                    switch (e.keyCode) {
                        case Laya.Keyboard.N:
                            this.gameProcedureFsm.ChangeState(ho, !1, "level2")
                    }
                }
            }]), GameManager
        }();
    new(function () {
        function Main() {
            _classCallCheck(this, Main);
            var e = new Config3D;
            e.isAntialias = !0, e.enableMultiLight = !1, Laya3D.init(t.width, t.height, e, Laya.Handler.create(this, this.Init))
        }
        return _createClass(Main, [{
            key: "Init",
            value: function () {
                Laya.Physics && Laya.Physics.enable()
				Laya.DebugPanel && Laya.DebugPanel.enable()
				Laya.stage.scaleMode = t.scaleMode
				Laya.stage.screenMode = t.screenMode
				Laya.stage.alignV = t.alignV
				Laya.stage.alignH = t.alignH
				Laya.URL.exportSceneToJson = t.exportSceneToJson;
				(t.debug || "true" == Laya.Utils.getQueryString("debug")) && Laya.enableDebugPanel()
				t.physicsDebug && Laya.PhysicsDebugDraw && Laya.PhysicsDebugDraw.enable()
				t.stat && Laya.Stat.show(0, 100), Laya.alertGlobalError(!1)
				Laya.loader.maxLoader = 10
				Laya.ResourceVersion.enable("version.json", Laya.Handler.create(this, ()=>{
					Wo.getInst().Run()
				}), Laya.ResourceVersion.FILENAME_VERSION)
                platform.getInstance().yadstartup("",null);
            }
        }]), Main
    }())
}();