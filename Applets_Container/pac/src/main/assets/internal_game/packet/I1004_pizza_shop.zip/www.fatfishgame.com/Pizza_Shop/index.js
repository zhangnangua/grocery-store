"use strict";
window.screenOrientation="sensor_landscape";
loadLib("libs/laya.core.js")
loadLib("libs/laya.d3.js")
loadLib("libs/fairygui.js")
loadLib("libs/fnsdk.js")
loadLib("libs/poly2tri.js")
loadLib("js/bundle.js");