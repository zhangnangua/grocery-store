window.__require = function e(t, n, o) {
    function a(i, s) {
        if (!n[i]) {
            if (!t[i]) {
                var c = i.split("/");
                if (c = c[c.length - 1],
                !t[c]) {
                    var l = "function" == typeof __require && __require;
                    if (!s && l)
                        return l(c, !0);
                    if (r)
                        return r(c, !0);
                    throw new Error("Cannot find module '" + i + "'")
                }
                i = c
            }
            var u = n[i] = {
                exports: {}
            };
            t[i][0].call(u.exports, function(e) {
                return a(t[i][1][e] || e)
            }, u, u.exports, e, t, n, o)
        }
        return n[i].exports
    }
    for (var r = "function" == typeof __require && __require, i = 0; i < o.length; i++)
        a(o[i]);
    return a
}({
    Advertise: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "45511+zycBI3KxlVBlBv5Ym", "Advertise");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
        , i = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.RewardedVideoAD = n.InterstitialAD = void 0;
        var s = function(e) {
            function t(t, n) {
                void 0 === n && (n = !0);
                var o = e.call(this) || this;
                return o.ids = t,
                o._adInstance = null,
                o._isStart = !1,
                o._watch_count = 0,
                o.suportAD() && n && o.preloadAD(),
                o
            }
            return a(t, e),
            t.prototype.suportAD = function() {
                throw "should be implemented in subclass!"
            }
            ,
            t.prototype.getName = function() {
                throw "should be implemented in subclass!"
            }
            ,
            t.prototype.getADInstanceAsync = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, null]
                    })
                })
            }
            ,
            t.prototype.hasAD = function() {
                return !!this._adInstance
            }
            ,
            t.prototype.preloadAD = function() {
                return r(this, void 0, void 0, function() {
                    var e, t, n, o, a, r, s, c, l = this;
                    return i(this, function(i) {
                        switch (i.label) {
                        case 0:
                            if (this._isStart)
                                return [2];
                            this._isStart = !0,
                            e = "",
                            t = this.ids.concat(),
                            n = 0,
                            o = null,
                            i.label = 1;
                        case 1:
                            if (o)
                                return [3, 24];
                            a = n++ % t.length,
                            i.label = 2;
                        case 2:
                            return i.trys.push([2, 22, , 23]),
                            [4, this.getADInstanceAsync(t[a])];
                        case 3:
                            o = i.sent(),
                            e = "",
                            console.log(this.getName() + " create suc:" + a),
                            i.label = 4;
                        case 4:
                            if (this._adInstance || !o)
                                return [3, 21];
                            i.label = 5;
                        case 5:
                            return i.trys.push([5, 14, , 20]),
                            [4, o.loadAsync()];
                        case 6:
                            i.sent(),
                            e = "",
                            this._adInstance = o,
                            this.emit("ad_ready"),
                            console.log(this.getName() + " load suc"),
                            i.label = 7;
                        case 7:
                            return [4, new Promise(function(e) {
                                return l.once("show_ad", e)
                            }
                            )];
                        case 8:
                            i.sent(),
                            i.label = 9;
                        case 9:
                            return i.trys.push([9, 11, , 12]),
                            [4, this._adInstance.showAsync()];
                        case 10:
                            return i.sent(),
                            e = "",
                            console.log(this.getName() + " show suc"),
                            this.emit("show_result", {
                                result: !0,
                                level: a
                            }),
                            n = 0,
                            this._adInstance = null,
                            o = null,
                            [3, 13];
                        case 11:
                            return r = i.sent(),
                            console.log(this.getName() + " show failed," + r.code + "," + r.message),
                            this.emit("ad_failed", {
                                type: this.getName(),
                                phase: 2,
                                code: r.code,
                                msg: r.message,
                                lastError: e
                            }),
                            e = r.code + ":2",
                            this.emit("show_result", {
                                result: !1,
                                err: r,
                                level: a
                            }),
                            "ADS_NOT_LOADED" == r.code ? (this._adInstance = null,
                            [3, 13]) : "PENDING_REQUEST" != r.code && "UNKNOWN" != r.code && "RATE_LIMITED" != r.code ? (this._adInstance = null,
                            o = null,
                            [3, 13]) : [3, 12];
                        case 12:
                            return [3, 7];
                        case 13:
                            return [3, 20];
                        case 14:
                            return s = i.sent(),
                            console.log(this.getName() + " load failed," + s.code + "," + s.message),
                            this.emit("ad_failed", {
                                type: this.getName(),
                                phase: 1,
                                code: s.code,
                                msg: s.message,
                                lastError: e
                            }),
                            e = s.code + ":1",
                            "ADS_FREQUENT_LOAD" != s.code ? [3, 16] : [4, new Promise(function(e) {
                                return setTimeout(e, 18e5)
                            }
                            )];
                        case 15:
                            return i.sent(),
                            [3, 21];
                        case 16:
                            return "INVALID_PARAM" != s.code ? [3, 17] : (o = null,
                            [3, 21]);
                        case 17:
                            return [4, new Promise(function(e) {
                                return setTimeout(e, 31e3)
                            }
                            )];
                        case 18:
                            i.sent(),
                            i.label = 19;
                        case 19:
                            return [3, 20];
                        case 20:
                            return [3, 4];
                        case 21:
                            return [3, 23];
                        case 22:
                            return c = i.sent(),
                            console.log(this.getName() + " create failed," + c.code + "," + a),
                            this.emit("ad_failed", {
                                type: this.getName(),
                                phase: 0,
                                code: c.code,
                                msg: c.message,
                                lastError: e
                            }),
                            e = c.code + ":0",
                            "CLIENT_UNSUPPORTED_OPERATION" == c.code || "ADS_TOO_MANY_INSTANCES" == c.code ? [2] : [3, 23];
                        case 23:
                            return [3, 1];
                        case 24:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.showAD = function() {
                return r(this, void 0, void 0, function() {
                    var e = this;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            if (!this.hasAD())
                                throw "no ad ready";
                            return this.emit("show_ad") ? [4, new Promise(function(t, n) {
                                e.once("show_result", function(o) {
                                    e.emit("ad_show", {
                                        type: e.getName(),
                                        result: ++e._watch_count,
                                        level: o.level
                                    }),
                                    o.result ? t() : n(o.err)
                                })
                            }
                            )] : [2];
                        case 1:
                            return t.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t
        }(e("../core/Emiter").Emiter)
          , c = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t.prototype.getName = function() {
                return "iad"
            }
            ,
            t.prototype.suportAD = function() {
                return FBInstant.getSupportedAPIs().indexOf("getInterstitialAdAsync") > -1
            }
            ,
            t.prototype.getADInstanceAsync = function(e) {
                return r(this, void 0, void 0, function() {
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return [4, FBInstant.getInterstitialAdAsync(e)];
                        case 1:
                            return [2, t.sent()]
                        }
                    })
                })
            }
            ,
            t
        }(s);
        n.InterstitialAD = c;
        var l = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t.prototype.getName = function() {
                return "rad"
            }
            ,
            t.prototype.suportAD = function() {
                return FBInstant.getSupportedAPIs().indexOf("getRewardedVideoAsync") > -1
            }
            ,
            t.prototype.getADInstanceAsync = function(e) {
                return r(this, void 0, void 0, function() {
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return [4, FBInstant.getRewardedVideoAsync(e)];
                        case 1:
                            return [2, t.sent()]
                        }
                    })
                })
            }
            ,
            t
        }(s);
        n.RewardedVideoAD = l,
        cc._RF.pop()
    }
    , {
        "../core/Emiter": "Emiter"
    }],
    App: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "ac8b4dFeM5AbbNKEyOLE1Bq", "App"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var o = e("./Extension/Manager")
          , a = e("./core/Storager")
          , r = function() {
            function e() {}
            return e.prototype.init = function() {
                this.storager = new a.Storager
            }
            ,
            e.prototype.start = function() {
                this.init()
            }
            ,
            Object.defineProperty(e, "resManager", {
                get: function() {
                    return o.ResManager.getInstance()
                },
                enumerable: !1,
                configurable: !0
            }),
            Object.defineProperty(e, "sceneManager", {
                get: function() {
                    return o.SceneManager.getInstance()
                },
                enumerable: !1,
                configurable: !0
            }),
            Object.defineProperty(e, "connect", {
                get: function() {
                    return o.GameConnect.getInstance()
                },
                enumerable: !1,
                configurable: !0
            }),
            Object.defineProperty(e, "http", {
                get: function() {
                    return o.HttpService.getInstance()
                },
                enumerable: !1,
                configurable: !0
            }),
            e
        }();
        n.default = r,
        cc._RF.pop()
    }
    , {
        "./Extension/Manager": "Manager",
        "./core/Storager": "Storager"
    }],
    AudioManager: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "cfe65BGMWFGQbSbWHF9ZTrQ", "AudioManager");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        );
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var r = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.sound_path = "audio/",
                t.sounds = {},
                t.enabled = !0,
                t.music = "",
                t
            }
            return a(t, e),
            t.prototype.addSound = function(e, t) {
                this.sounds[e] = t
            }
            ,
            t.prototype.playSound = function(e) {
                this.enabled && cc.audioEngine.play(this.sounds[e], !1, 1)
            }
            ,
            t.prototype.playMusic = function(e) {
                this.music = e,
                this.enabled && cc.audioEngine.playMusic(this.sounds[e], !0)
            }
            ,
            t.prototype.stopMusic = function() {
                cc.audioEngine.stopMusic()
            }
            ,
            t.prototype.setEnabled = function(e) {
                this.enabled = e,
                this.enabled ? this.playMusic(this.music) : cc.audioEngine.stopAll()
            }
            ,
            t.prototype.getEnable = function() {
                return this.enabled
            }
            ,
            t
        }(e("./Singleton").default);
        n.default = r,
        cc._RF.pop()
    }
    , {
        "./Singleton": "Singleton"
    }],
    B64Images: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "0109adI5AJM2LF/MuRAh8xq", "B64Images"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.B64Images = void 0,
        (n.B64Images || (n.B64Images = {})).img_common = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACWKADAAQAAAABAAABOgAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgBOgJYAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAQEBAQEBAgEBAgMCAgIDBAMDAwMEBQQEBAQEBQUFBQUFBQUFBQUFBQUFBQcHBwcHBwgICAgICQkJCQkJCQkJCf/bAEMBAQEBAgICBAICBAkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCf/dAAQAJv/aAAwDAQACEQMRAD8A/pM2cUbB/n/9daPlj/P/AOujy1/z/wDrr+4/aH+S/szO2D/P/wCujy+OK0fLX/P/AOujy1/z/wDro9oHszO8vj/P+NHl8Vo+Wv8An/8AXR5a/wCf/wBdHtA9n5Gbs4o2cVpeWv8An/8AXR5a0e0D2fkZuzijZxWj5a0eWtHtA9n5Gds4o2cVo+Wvajy17Ue0D2fkZ2zijZWj5a9qPLXtT9oL2fkZ2w0bDWj5Yo8sUe0H7PyM7YaNhrR8sUeWKPaB7PyM7ZRsxWj5Yo8sUe0D2fkZuzFGzFaXlijyxR7QXszN2Yo2VpeWKPLFHtA9mZuyjZjitHyxR5S0e0D2ZnbMcUuztWh5S0eUtHtA9mZwSlCVoCIUCIUe0D2ZnhKAlaAiFAiFHtB+z8jPCUBK0BEKBEKPaB7PyM8JSBK0REKBEKPaB7PyM4JR5frWiIhR5Qxij2gez8jN8ujy60vKGKPKGKPaC9mZvl0eXWl5QxR5QxR7QPZmb5dHl1peUMYpPKWj2gezM7y6PLrR8oUeUKPaD9n5Gd5dHl81oeUKXyhR7QPZ+RneX60eWa0PKFHlCn7QXsjP8s0eWa0PKFHlCj2geyM/yzR5daHlCjyhR7QPZGf5dHlmtHyhR5Qpe0D2RneWaPLNaPlCjyhR7QPZGd5dJsrS8oUgiFHtA9kZ2yjZWiIhR5Qo9og9kZ3l0eXzWj5Qo8kUe0D2ZneXzR5fNaPkijyRR7QXszO8vmjy+a0fJFHkij2gezM7y+aPL5rR8kUeSKPaB7MzvLo8utHyRR5Io9oHszO8v9KPL/StHyRR5Io9oHszO8v9KNv+c/8A160fJFL5K0e0F7M//9D+mnYT1FJsz2rT8sY560eUMV/aaqH+VHsjM2Z7UbM9q0/KGKPKXFP2geyMzZntRsz2rS8paPKFHtA9kZuzPajZntWl5Qo8oUe0D2Rm7M9qNme1aXlCjyhR7QPZGbsz2o2Z7VpeUKPKFHtA9kZuzPajy/atLyhR5Qo9oHsjN8v2o8v2rR8oUeUKPasPZGd5ftR5ftWj5Qo8oUe1YvZGd5ftSbB6VpeUKPKFHtWHsjN2D0o2D0rS8oUeUKPasPZGbsHpRsHpWl5Qo8qj2rH7Ezdg9KNgHatLyhQIhR7Vh7EzdgHajYB2rSEQoEQo9qL2Rm7B6UbAO1aQiFAiFHtA9kZuwDtRsA7VpCIUCIUe0YeyM3YB2o2Adq0hEKBEKPaMPZGbsA7UbAO1aQiFAiFHtGL2Jm7BSbBWmIhSeUKPasPYmbsFGwVpeSKPJFHtQ9iZuwUbBWl5NHk0e1D2Jm7BRsFaPkijyRR7UPYmdsFGwVo+SKPJFHtQ9iZ2wUbBWj5Io8kUe0D2JnbBRsFaPkijyRR7UPZGdsFGwVpeSKPJFHtQ9kZuwUbBWl5Io8kUe1D2Rm7BRsFaXkjrSeQBR7QPZGdsFGwVo+QBR5AFP2geyM7YKNgrQ8nFHk4o9oHsjP2CjYK0PJxR5OKPaB7Iz9go2CtDycUeTij2geyM/YKNgrQ8nFHk4o9oHsjP2CgxitDycUeTij2oeyM8xigxitDycUeTij2ovZGcUH+f/wBdBQf5/wD11o+TijyeeBR7UfsjOKD/AD/+ugoP8/8A663o9Iu5BlUx9eKlOh3o5AU/Q1k8XBaNm6wFVq6iznNgpdi1rS2FxDzKhHv/APXqt9nX/P8A+urVVPVGMqDi7NH/0f6h9go2Adqu+W1HlNX9hKqj/Lr2bKWwDtRsA7Vd8pqQxkf5/wDr0e1D2bKewDtRsA7VcMZH+f8A69BjI/z/APXo9sHs2U9gHajYB2q4YyP8/wD16DGR/n/69Htg9mynsA7UbAO1XDGR/n/69BjI/wA//Xp+2F7MpbAKNgFXTGR/n/69BjI/z/8AXo9sHsymUApNgq6YyP8AP/16DGR/n/69Htg9kUtgo2CrpjIoMZFHtg9kUtgo2CrpjIoMZFHtg9kUtgo2CrvltR5bU/ah7IpbBRsFXNho2NR7UPZFPYKNgq5sajY1HtQ9kU9go2CrmxqXy2o9qHsil5Y6UeWOlXfLajy2o9qHsilsFGwVd8tqPLaj2ovZFLYKNgq75bUeW1Hth+yKWwUbBV3y2pPLNHtg9kUygoKCrnlmjyzR7YXsymUFBQVc2EdqNhHaj2wezKRQf5//AF0FB/n/APXVzYR2o2EdqPah7MplB/n/APXSlBVvYR2pdhFHtQ9mUygpDGKu7CKNhFHtQ9mUvLH+f/10eWP8/wD66u7CKNhFHtQ9mUvLHf8Az+tHljv/AJ/WruwijYRR7UPZlLyx/n/9dHlj/P8A+urmw+lHl+1HtR+zKflj/P8A+ujyx/n/APXVwx+1Bj9qftkL2ZT8sf5//XR5Y/z/APrq4Y/ak8v2o9qg9mVPLH+f/wBdHlj/AD/+urhjPpQYz6Ue1D2ZT8sf5/8A10eWP8//AK6uGM+lBjPpR7UPZlPyx/n/APXR5Y/z/wDrq4Yz6UGM+lHtQ9mU/LH+f/10eWP8/wD66uGM+lBjPpR7UPZlLyx/n/8AXR5fP+f8aumM+lBj9RR7YXsil5fP+f8AGjy+f8/41t2+mXFz82Nq+prXj0O2HMpLH8qxnjYx3Z2UcsqzV0jjfL5/z/jR5fP+f8a7Y6NYnsfzqpLoKYzA34GojmEGbTyaqtlc5Ty+f8/41bi027mG9EOPfiuh0/SPLkMt0Pu8AdvrW9sWs62Y2doG2FyVyXNU0PP20+5SURMhBbgV0Vpp0dqoOMuerf4VvbF9KNi1y1cdKasehh8pjTfNuZ3l0eWK0di0bFrl9od3sWZ2wdDSeVF/dH+fwrS2LRsWj2gOgf/S/qmCCjYtXNh9KTYfSv6y9of5j+yKmwUbBV1YnYhVGSa1otHYrmVsH0FRPEqO5vRwU6nwo5woKkitnnfZEMmt2XSJU5hO4e/FbFrbR2sYROvc+tYVMckrxOvD5TJytNWRhw6PGvM2SfQdKt/2da4x5YraxijGK4JYqb6nuQwVKKsoozNL8LLrOs2mlwEr9omSM+wYgEj3Ar5s+Mn7eX/BLD9n74nax8GvjB8ZLXRPE2gTC31CxlSVnglZEkCMY7ZkzsdTwTjPrX3X8KbEXnje0Zh8sAeU+21SB+pFfx9/8E6vhn8Lv21f2qP2nf2p/i34c07xRZ6341ng0z+0raO5jjj8+6lJjEisFPkNADjtgV8Lx7xtQyTK8XnePlN0sPGHu03FSlKpUUEryTWiu/RH9RfR58GMu4kc4Yqmm5SaTd7JKN+nfY/dew/4Ki/8Ec9VvoNL0747WL3F1IkMS+VccvIwVRzagcsQOSPrXU/Ef/goF/wSu+CXj3V/hJ8XvjZp+neJ/D9y9nqVoqTN5E6Y3RkpBIu5M4bDHByDyMV/Lx/wXs/ZR+FXwf8ABnw/+LHwd8M2HhnZd3NhdDS7dLZZGYRyws4jVQzqVO09etfqb/wTc/4JqfCjwZ+zFpXiL9p3wjpvivx74wkfxBrF1rdrHeXMUl7h0gLzK7BkjIMnrKzk1+bZv9IjhvB8F4bjGVSu1XqSpqjen7Tmg9XzctuVRs3pvOK0P6KxX0Scmp5gsK6MbcvNze9azbW197xa+TP0h8Pf8FJf+CRnjXUv7I8L/H3RopkikuHN6XgQxwqXfEk0UCb9oJC7izdACaxP+Hqn/BGcj/kvNj/36uP/AJEr8k/D/wDwS5+Bvx5/4KceJ/iXc+GtM074b/DaOwsjodpBHFa6hqxt45lWSFFVPJiEnmS5H7wlFORur9l7X9gv9ihmDN8JfCR/7hNr/wDG6/N+KvpocLZdHDqlDE1ZVKcZySlSXs3K75G3H3naz00SaV73SWO+iXkuFrShVox2i/tapxUl103s/NMqW/8AwUu/4I/XXhi78Xw/HfTfsNlcQ2spPmCQSXCytGBEbYSupEL5ZVKrgBiCRnn/APh6p/wRn/6LxY/9+rj/AORK/KP4O/8ABLb4G/C7/gs54m0vUvDWla38PvEHgm68Tado95bRz21jcz3ttbSRCJ1KKscqyNDjoj7R92v3Ktv+Cf8A+w22CfhB4P8A/BPaf/G6fHv0zOFsmq4eOHhia8a1KFVOMqUeXnTvBpwfvQaalbS+3d/Oy+jnkMb+0w6TXr8nv13PEf8Ah6p/wRn/AOi8WP8A36uP/kSu2uf+CgX/AASksPh9bfF28+PGjHw7e3j6dAyOTcfaY13sjwCNrhQE53NEq8jnkZ6P4h/sHfsMaH8NvEWvJ8IfCEbWWlXtwrrpFoCpigkYMD5XBBGQa/N7/gjR/wAEfP2bPh/+yHovxc+PXhjSPHHiv4jWltrTNqlpHdxWFjOnmWtrAsysFcRuHmcDLOdv3UGfOwH03+FauSYrN6lPFQlSnThGm5UpSqOfO3ZqCUVBQu277pJXZxYn6PnD0aarPDq17dd7ep9kf8PVP+CM/QfHix/79XH/AMiV6z4m/bY/4JkeCvhR4d+PPin4y2EHg7xjPc2ui36h3E89iQLqMqkLOrxFl3B0UgMPUZz/AI3f8Eof2FPjF8LNd+F4+Gvh/wAPvrVo9vFqeladb215ZykZjnhkRFYPE4DYzhgCpyCa/je/4JF/AjTbf/gq437HPx0gs/GOgeFJPFVs+nXsf2nTnvrSEwvdR28wZFeQWyHdt3YVQfuiv07ws+kbw/xZkGbZ3g3iKc8vpurOlJ03KdNRk7wko2T5o2d9tO+nLLwI4cc4L6utX5/5n9bH/D1T/gjP/wBF4sf+/Vx/8iV3Pw1/b+/4JWfG7xzp/wALfhL8btNvvEOru0dnbyiSJZGRGkZd8sESA+WjEZcZPAyeK2rn/gnz+xGDhfhH4Sz/ANgi1/8AjdfkV/wV9/4JO/Anxj+y5q3xh/Z/8PaX4I8U/Dy0udYB0y3SzivrKCMyXMEwhVQZFjQvC+MhgVJwxI/PuAPpo8LZ3nGHyqrDE4dVpKCqSlSlGMpaRckop8vNZO2yd9ke3X+jZw+6MpRoxenmn+Z+ksv/AAVP/wCCNMEjRSfHmxyhKkiOcjIOOCLTBH04qMf8FVP+CMxPHx5sT/2yuP8A5Er8jf8Agir/AMEyPhJoX7KNp8fPjp4c0vxPrfxESO/s4tRt4ruOy0xdwt1RZFZVln5kkI5wUX+E1+j/AMdf+CaP7IHxo+Fus/DSbwLougtqkBSHUdLsLe2u7SYcxzRSRopyjgEqTtcZU8Gve41+lzwnk3ElbIv9pqU6VTklVjKnbR2m1Hku1F3W/vWutGj28v8Aoq5HiKCq+xipNXs7/LqfUXjD9u3/AIJXeAfBPhr4leK/jdpcOieMYZptHmRzK86Wz+XMxjjieWMJIdp8xEwwI5IOOR8J/wDBSP8A4JG/ELxRp3gPwV8dNOm1jWbiOysY5VljR7idgkSs8lvGihnIGWYDnrX86X/BJ3/glr4c8G/GT4vQ/tM6Vpnim48FX8fhuztrmFbi2cyAXT3ixyAgeZEYwmRlcuDzX7JeNv8Agnf+xv4u8Mah4VuvhvoNnFqEDwGeysobe5i3jAkhlRA8cqHlWHQgV2+IP0qeFsizqeU0qlfERjyv2sHT5GpRUlaLjeXLGST1V2nt09TKfoc5RisMqlSlGEnfR81/LW/VarysfWvxb/4KAf8ABKv4B/EfVvg78X/jRaaV4n8PzfZdSs/KmkME4VWZC0dvIm5dwyAxIPB5Brzr/h69/wAEZOo+PFp/4D3X/wAiV+C/7Dv7Edl+z1+2d8Qfgz+0HZ2PjW51qybVtN1TV4Yr2S9tjOpjmP2hZGS5YtKs3cspOSMV+vV9+yj+zixJf4f+G/8AwVWg/wDaQrzuMvpYZBlWYSwWHjXxEEotVIzpxjPmindRdNtK7tZu6trZ6H12WfQTyephqVWuoQlJXtaTtq1vfy/4LPbR/wAFXv8AgjKenx4tP/Ae6/8AkSvpD4BftHfsN/tf6b4mH7JfxFi8Z6j4WtY7u+ghjkjMUcpcIzCWGIkMY2Hy5wRz1FfnRJ+yF+zJP/rPh34bb/uGWv8A8arwH/gn54c8Lfszf8F19c+EXhTTbfRtA+Lnw1ka3tLSNYLcXVjIrNsRAEB2WspIA6sT3r6fwx+kLlvFOLrYHBQr0qlOnKouedOUZKDjzRtGEX8Lb36Hxnif9DfJslyipjKcYye2ikmm07PVvZn7geWP8/8A66PLH+f/ANdaM1s9vM9vIPmjYqfqDioyntX9Tqqnsf5OOjZ2aKXlj/P/AOujyx/n/wDXVwpz0o2ZPSn7QXsin5Y/z/8Aro8sf5//AF101t4c1a7USJCQD0LYH86ivtC1KwXzbmL5f7w5H6VgsbTcuXmV/U6nllZQ9o4O3ezOe8sf5/8A10GMf5//AF1c2c5xQUz2rf2hy+yKXlijyx2q75ftR5ftS9oHsin5Y7UnljtV3y/ajy/aj2geyKXlijyxV3y/ajy/aj2gvZFLyxR5Yq75ftR5ftR7QPZFLyxR5Yq55ftR5ftR7QXsimIxQIxVzy/ajYPSn7QfsimIxQIxVzYPSjYPSj2geyKYjFAjFXNg9KNg9KPaB7IpiMUeUO9XNg9KNg9KPaB7Ip+UO9HlDFXNg9KNg9KPaB7IpeV9KPKq7sHpRsHpR7QXsil5VHlVd2D0pViLHCjJo9oP2XkUfK+lbFhpqkCecfQf1qS1095ZgJUKr1OeK6cRoOgrixWLt7sT18uy9N880Z3l+n+f1o8v/P8Ak1o+WnpR5aelef7Y9/kRneX/AJ/yaPL/AM/5NaPlp6UeWnpR7YORGd5f+f8AJo8v/P8Ak1o+WnpR5aelHtg5EZ3l/wCf8mjy/wDP+TWj5aCum0DwV4h8SndpFqXjBwZG+VPzOB+VZVsbCnHnqOy8zqweXVcRUVKhByk+iV2cR5f+f8mjy/8AP+TXuLfBPXIIRLe3drCfQs39E5rkNT8Ba3puXRVuUH8URJ/QgH9K4aHEGFqO0Jpnt4zgvM6EeerQaX3/AILU898v/P8Ak0eX/n/JrRMSgkMMEdaTy4/SvT9sfNOmj//T/rN/s68HVDSf2ddj+A12lGBX9I/2jLsf57/2TDuzndPsHiYyzrg9BWt5YFXMCjArnniXJ3Z20cOoR5YlPywKPLFXMCkwKj2zNeRlTyxR5Yq3gUYFHtmHIzjvi98SIfgX+yx8W/jpM4jPhbwnqd5Ex4/fR20rxjPbMiqPxr+TD/ghf8aj4I/ZO1PQ4dK86Q+Irqa6uZHKtPLJDb8qQDkIgUc981/TN/wUjfwHa/8ABJ/4+XHjwSSWA8OXZdIpGhZptqfZE3jnD3WwMv8AEpKng1/Lh/wTU0SPwD+x34eubkbG1H7Xqkp6ZEkrbT/36jWv4x+nXxVLLfDHEzw8nGtWxdGnHbaNOc3o91vo1u4s/wBcf2ePBVLMMSoVYc0FSnJ/OSS2e+v4M/Yj44R/CH9p/R/Dfhz4qaTNJYeH9es9cMKlJFmaz3MsTZ2/I7ld/qoI719jTftA/D+z0W71eeSaL7NBLMRJGcfu0LdVJHavy1h+IWi2PgxvHV1LssEsxelv+mezePxI4HvxVT4xeN5dI/Z58SeI7n9zKdGlYrn7rTRbdv4F8V/i3gPE/imvPD5dVkpQ9pyxUo6KU3FSslbV2jf0V+h/pTnXg5ltScbRcemj6Xb636t/efSn/BLT426X8Ufgv4l+MvjO5htNX8Y+LdTvLhApRD5HlWg2AlsIPIIGSTgV5Z+xl/wUP+Kf7QX/AAUn+J/7OWtXtsPBXg2DUJbRhHDHuMV1BBADJt8xjtdifm5PavGv+CdUC+Ev2MPArz/Ibmxl1ST3N5PNc5/FZBX59f8ABGWRvE37TXx1+K8/zNNNDbK/XPn3VxKw/wDIK1/W1HNMDOlx3meIwsZ0srSp0NZL3pYqNCDbvq+RN7W8j+fuJMkc1h61O3Pi5K94xfLD2c5tQuvdtaKTWqXXU/Sz9tL/AIKafDv9hT/go7qOueJ9JOvC98C2OnW5juRCkJN5JdSAkRTFi+UxgDoa/Uv/AIJn/tWXf7afwV1f9oGUtBp+q+JLy3020Z94tbW2ito/KV/LiLDzvMbJGck9q/ht/wCCz3iX/hIf26tdhDZFhZ2dsB6bYVz+tf0pf8EU4m8Lf8E8PBJDGM3k+p3jEcf6y9nAP/fKCv1D6RHBOS8LeB2Q+IkqMpYzGexg4c6UFGdOrVuvdbvaCXndn5VmlP65mlfIKVKCdOMb1LSc3yxguWzlypX7RT0tfc+T/jf/AMHBGseAbL4nfsz+INAi1O4h1DxHoq6nNPM0vkTT3UUJVEh8sCGJwqLuPCjNfvx4z8Ya98Cf+CPs/jDwrcyWOp+GPhVb3FpNExjeKaHSozGysOVYNjBHIr/Nb+N2pt4l+NHi3VmJZr7Wb6Qn3kuJD/Wv74f27NfudA/4JV/EDSfOcLD4FW027jjH2eGLGM9Oa+9+lr4ZcN8A1+DsvwGGlKWa1o+1TnomnQjouXa9aWl/mfO4rESzKtWhRpQpxw9Ru8U7y1esrycb2itIpLV6Hp3/AAQL/aG+LP7Tv7D9z8T/AIz6tdazqreKb+zSe8nedxDDFa7VDyEtgM7HHTmv5Efhp4217wj/AMF211vw7dy2kt38XbmylaJ2QvBd6u8MsbFSCUdHIKng9wa/of8A+DefULvRv+CeNnHDK8Yn8UatJgMQOtuvY/7Nfyz6Hqrr/wAFa7XWd53f8LZSTd3/AOQ4Oc+tfqn0bMzymfiF4kcPYHCKFDC06lNRveLinUVkraL3erZ8Fm1PFydHMas/fqyTuklr3srJfJH9+v8AwUv+EP7Sfxm/ZS1fwH+yVdpY+N5b+wmtZZLtrFRDDOGnBmRlK5jzxnnpXlPxettV+C//AASq13Rf2o9atrbWrH4fXWmaxezTmVJNQmsJINqytlpnkmcIuMs5PGayv22P2xNP/Y6+CN58cfE8NxqVna31rZtDHM0bE3UmwHdtk+6favk79pi2+H//AAUM/wCCbuoeLtft547DWvD8niTTFMpaW1u7SKWaBw2AGO5CrAjBViMA81/l74ZeNNWrhMnxeZ5W6OWTxsYfWYpSnz+45wvpzckLTUdN27u9j9Sp8MYxYCVH26lBNy5Lq97PW1+ZKW3M1Z27o+tP+CTt8viL/gmv8HL9yAy+HooW9jDJLHj8Nteaf8E/bP8AbhsdU8dWf7aMF1bW6XMI0J7u6tLkPCrzh2Rrc7gGQxnD8ivlT/gkH4hm1n/gnX8PMSt/o8V5bkAnA2Xc+B19CK9B+D37Znwy+P8A8U/FHwj8Jw3MeqeFJJ4rwymNo90E3kMAVdmB3c4IHFen4peKWOwfEfE+X4TKPawwuIqKpV5nemo15xTVlZKb0d1Lok1rf9S4Z4Xr16FTkqx5ayUmnGLa2knFt8ytrfl3TfMtj3r4F3WjeHv21Pj7oF3dQwxXkvh7VYyzqA3naf5TkEkZO+Ln618D/Gb/AIKpwfs3/wDBQHxV8F/i/eRyeAdPsLW4szbRwGZpLq2ikBRy0ZYRy7wwLHg+1eg6eq6X+3N4otsYXVvCOnXQ92gup4T+QH61/Or/AMFu/Dw0v9rnTdcVcDVfDto5PYtDNcRH8cKP0r+hfomU8s8Q+Po8K5xS5IV8FCpCcXeUaihRk7XsnoprX13PR46jPh/Lo5xBKqvdhKMkrONnC6eri04pprXpqm0/0l+O/wC3/wDAX42ft9fBr4gfBnUbl4dKRodXSaJUwguoniIZHcP+6knBUH6jkV+rP7Z/xQ8MeL/2ZfH3hPwY94uq3Oi3hspY49pS4ijMsRBJB++g7V/Cd8DdZfQfizoeoxHaRcBAfdwVH6kV/aja3sWs6LZ6tFyl3bxzDvxIgb+tfZ/T24bn4VZ3kdDJ0qtJU7tzim5ShVbs7aWaaWqfupLU+88B/q3FuUVcRiHKnKnUnGKjJ+7FxjJWe+knJ6W1ufx52X7YP7TGj4WDxVfwkdt7oR+RBFfuN/wQk8O+Lv2k/wBuPwh+1X8S/jZo+ka94B1qLTbTw9r1032/VrTULWeKWLTleX5i3msu0A5fHqK+9tf8FeCdcLR6tpNhegHBE1vFJ+e5TX59/taeFfAf7POsfDH9pjwDoVho994L8c6LqM89nbxwMYY5w5DGNRldyDg8V+9eDH08uD+LM9ocOYDh2OAxOLvSjVg6crOafuv91B2n8Omup8J4wfR14ow3D2Ix2JzmWIpUlzuE+bW3rOS0Tuf3T+LtH8MweI76CdViYys2CdrDed3TPvXAP4e0w3Q8q8QQ+5G76en413/xptoT4vTVbchor62ilVh0IwVz+QFeR7BX9qZIp1MLTqqb1SP+fLjKVKhmdfDzor3ZPbTS+m3kdkNC8LhNnnDPrvGf8Kl03StC06ZpzcJK2flLEfKPz6+9cPsHpRsHpXe8HNpp1GeFDNqUZKcaEbo9Z+3af/z3j/76H+NMe60yVGjlmjZWGCNw5H515TsGelGwZ6VyrJ4/zHoviyo1ZwR29lo3hy1GZZY5W9WYY/LNXJ7Pw3cJskMI91IB/SvPNgz0o2CuiWBk3zObOKnndOMeRUY2/ryOgHhzSvPYvep5f8IBG78e1XToXhjGPtHPrvH+FclsFHlr6Vs8PUe82csMdQjtQX4mzc6Bpik/Zb6P6P8A4iseXTPK6SxN9HH/ANak2DNPMD9dp/KtqfPHeVzjrSpT+Gnb0b/4JReDYcHB+hzTPL9qvFBmjYM10e0ZxOkr6FHy/ajy/atRbOZ+VQ082FwP4DU+3XcpYaW9jI8v2o8v2q+0RU4YEH3qxbWbXD4XgDqabrWV2KOHcnypamR5ftR5ftXUHSI8cMc1mS2ckUmwjP0rOGKjLY1q4GcNZIyvL9qPL9q0TCy8lSPwpmwVr7QwdIo+X7UeX7Ve2CjYKPaMXsij5ftSeWPSr+wUbBT9oHsih5Y9KPLHpV8RgkAVsW2lrgPcfl/jWdTERirs2o4SU3aKOY8sDtR5Y9K7pbW3UYVAPwqKWwtZRgqAfUcVzLMY9jteUStozmrLTvtPzuMIP1rfjtY4l2xqBV2OFIoxGvQU8qDXLVxbk/I9HDYONNbalLyhR5Qq6VBoKg1l7Y6uTyKXlCjyhV0qDQVBo9sHJ5FLyhR5Qq6VBoKg0e2DlKRhq5aaPqGoErYQSTEddilv5Cu6+H/hSLxVrot7rP2eBfMlx1IzgLn3P6V9cWdlaafbraWMaxRoMBVGAK+Xz3iuOEl7KEby/I/TeCvDWpmtJ4mrPkhey0u33+X9WPj/AMH+BL/V/EkOm6tBLDCoMku9SuVXsMgdSQK+rb+6ttB05IbNFQAbI0AwAB/QVau9X0+yfy7iTDeg5I+uK4vxHewXlzG1u4dAnb1zXxGYZnVzCrGVVWiunQ/aMg4aw2SYapChLmnJ76X8l8vzMO4uJrqQzTsWY+tQ0UVslbYzlJt3ZwfjDwtFqMDajZJi4Tlgv8Y/+Kry7+wNW/59ZP8Avk/4V9G0V7mDz6tRh7Na+p8Vm/A2ExdZ13eLe9ra+Z//1P7CvKFHlCru0ZpNi1+987P4Z9mU/KFHlCrmxa7/AML6DbmFdTulDM33FPIAHf61y4vGqjDnkerk+SVMbWVGn832RxNr4e1W8UPBAdp6E8D9cZq23hHWlYL5IOTjII/XmvZqK+dlxDVvokfpVPw7wajaUpN/L/JnE6f4I0+BQ1+TM/oDhR/U1snw1oRXb9mX9f8AGt2nIpdwg6k4rzKmYVpPmcmfUYbh/BUo8kKS+aT/ABZ+BX/Byd8R9L+Df/BKzVPhtpl0kWpfELX9L09LbzB5skEcovJWCZ3Mii0VWOCAWHrX4/2umf8ACp/2XrfQIR5baR4eitMD/noIFjP/AI+1d9/wXCl0L9o7/gtd4D+BWvQLfaN8P/B8U15bsTt824Nxd4bBBG4NbZ55GBUPxl1dND+FWv6k+Bss5EGemZBsH6tX8AfT+4vg6/DvCMbym28VU7P20o06Ub3buo05N3W01a+p/s5+z44CWCyrF5sklGTVOK7cvvSfo+aPzT+f5+eHvj5rPxa/Z68BfDHwejXuqateGzu44uStvZXbRgsM/cWGPzX/ANlPev0A/bIbWdT/AGXPF9l4bKCZbIsAzbcpGQ20ccsSAAK/EP8A4Jd2dz4k/aZ17W0ZlsNKsby5iiH+rSS6mjiBUdATHuH0r9XP2z/iTp3hr9nbxLb299CL17cBI1kUycMGztznA2+lfkn0ifC/D8N+LOW8LZJTT5a8K7TT0liasZqnK28acFBJ6dfI/obwz4pqZ/wvPOMW2lGMoXVtfZpqVRdnJ33vay87/c3wl0FvD3wJ0D4eQP8AZWtdBtbAMBnYwtVjLYyM4bnGa8+/Yk/ZF8M/scaP4isND1u41y48TXkd5czXESQ7DGrhURVZvl+cnk5r4U+Av/BTr4Pav8GNJ1n4l3htPENrEttqFuihQZohjzELMq7JQAwAPBJHavNfj9/wVu8CXfgDVPDfwpSZdRuojEk5bJCtwwXYCqlhxu38DOOcV+TYf6NvjNicxzXg7CYGrGni68ViPc/dylTqOUZuo1fkjJuacZJSVm76HymMzHhWeAwma1cTTjCEOaDlNJpONnaN7uVla1m73SVz4K/aJtNF+PH/AAVMk8N6kBe6XrXiyx0+UKxxLbGaNJAGUggNHkZB9xX9knwp8F+BPg94C074W/DexXTNB0mNoLS1VmcRxszORudmdss5JJJPNf5+vw2+MniHwB8adJ+NtvsvdU0bUY9QAlBKNJGQQCMjgDoM8YFfpT4h/wCC0n7UF/uXS3t7FT02JECPziY/rX+jv02voO+IvGOW8OcLcLSjPB4DDQhPmq8kHWiuTn5Hu1FaStdKTXV3/kzgTj3ht4zMc0zCsqUqtVuCcZOXI9UrxjK3mr7o81/4KteFPh14A/bx1rw/4B0m20XSbaLTpJLayjEUYdokeZwqgDc5JLHuea/tf+FfxO+HXx0+EuleLvC0kGseH9Zs42RZEWSNlwAY5EYMu5GGGU9CK/zr/jp8c/Ffx08eX/xS8eXK3OsXyxiV85L+WoRc4wPujHAH0re8A/tZ/G34aeFU8IeBPF+oaRpgdpRa28zoiu+NxwpxzivuvpI/s/M68QuAOF8knmcaWY5XSUJyqSlKE+aEFUfMryclOnHlfVXv0PjMn8Rslwmb451Yt0KkrxlGKvpdfDJx0knfe6fR30/0TvGXxR+GP7PHw31Hx94la20Lw9ocTXU/kxpDGAOcIiBQZJGwAAMkkV/FT/wTr1jwz8W/+Csnhzxbq1jHc6frfiLWdVjt7pFkCs8N7dQMQRjfE+xlPZlBHIr88/G/7TXxa+I2kvoPjnxXqGqWUjB3gnld0YqcgkHrg15b4X8faj4Z1qPxBoN3Jp97asWgniJDrkFSQR0OCQfY12/RZ/Z31/D7hPiTK8ZmsauPzWhOgqkeZQpp05xjJ395y56jk3poklrc8DjDj/KsZjcK8LCXsqclKTaSk9VdKKk1olpeSu3bRK7/ANCX/gpJ4d8PfEL9hr4n6T4itIr8WuhXd/biYbvLubSNpYpl9HjZcqexrg/+CY97Za//AME7/hdp+qRpc20mhm1mjkG5HjE00bIwPBUrkEHqK/h61L9q34za1ol14d1TxbfT2d7E0M0TyNh43GGU9OCOD7V3Xw2/bo/aK+E/h+z8KeAPGF3p+nWC7Le3jmkWNFyWwFV1A5JNfzdiv2UPFtPw3fBeGzihOosYsTF3nGKXsZUpJaNqTfK9Fst72Pu8L4mcNrMvbt1FBws24Rvzc11oqj0s3rffS3U/sR/4Jnw2fhv4A+IfBGnxLbwaB448S2EMKAKkUUd+5jRVHCqqMAB2FfmZ+wJcf8I3/wAFT/jr4a+6tzqOqsq+zXRmH/jor8YPhV/wUj/ak+Dltf2/hHxUyxanf3GqXYkw5lu7pt00rZzlnPXioPg1+3X8WvhP8f8AWv2k1FvqviPXzI93JMoVGMoIY7EAXleOMetfay/Z6cd0P9dqvPRq/wBq0v3SjUd3V9vCr73NFJLSWre7W+tvcyjxSyCOJy6o6riqakp3i/dToygnonf3mtr9T+tvxrOmk/tt+FLxiFGr+FdRs+T95ra4jmAHqcPX55/8FQv2LfiZ+098VPAHijwLYNdaXp8U1jrEkMsSzwwvMkiuiSsu/Cl+gOPSvyd+Nf8AwVQ+LXxr8deEPFt1p9ro1z4SmnkiksncSyrceTv3BiVGwwqVx7g5BNfq94B/4LF/AnX9OtrbxvBNaXnlqs0sWAjPj5mCSeXtBPbJx61/MWF+jB40+FGNyfjPJMu9tiqdCrSnGC9qqbbqwTlyS1fs5xlHWykldOzR+zYPiThPinCzyurio8sJLSUvZ86UlNOPPytpu8WklLTpdM+N/jx/wSRsfgZ4RvvjB4A8ZTaiugNFdizvLRUZ1WVAR5qS4BAOc7O3Sv2m+GEU1v8ACnw5DPKJmXTbb5xkBh5a46+2K+Cv2sf+Cjf7OOo/s9+IdG8GamNU1rWbQ2dtYlWDfvzsaVmG5AsKkv8Ae5IAFfXP7PPjDSfEnwW8Ni2u4pbiKwjikjV1LqY8qAyg5HyqDzX5J9IjibxP4i4Ky7NfEeFRzhiK0KcqlKNOTgqdJvSMYXipXtJrVtq75dP2XwoyHIcsxmLwOR2VlTlOMZOSTftEt27Npaq+1nbXX8Wf22fhx+2B4M/aB8R+NvhTbaxc+GdQkjuoJbFTOiM0SeauxNzptlDdRznIrwP4J/Dz9t7/AIKF+Mbj9lXwjqscmpraSakbHWrxNNSZbZ41wHuSqtKjSKyoME4J7V/TPfPzwcGvM/HXw78I/ETRbnSPE2m2t600TxxyTwpI8bMpUOjMCysucgggiv3HwX/aIZfkuCwOCzvhzD1amGjCEMRCMVVXs0oqpJOMuadldtThd6qx8/x99G7NszjiZ5ZnVaEazk3Sk5Sp+87uKtKNo9ErPTQ/qT0vRfGmk/s//DTTvifHHb+K7Hw9Y2msQRzJOEvI7WFZwJIyVkXzlfDqSD1Fc+InPQV8A/8ABDvx/f8Axc/4JJeENI8QTPcax8PNX1PwzeSzMXl/0O7lKKzMSxxBcRDk9hX6ZR2sMIwgx796/wBcsHNYf2mGupckpK62eraa8mndavQ/5tvF7hyrT4grc6tzWf3K36HHm0nA3bTiojGwruygrFu7NjcbYh94Zrup4y7sz8vxOV8keaOpzxjNSJbyyHEYzXTQ6ZGnzTHJ9O1XxEqgBRgUp422xVHKJPWehyy6VctycCpf7Hl/vD/P4V0vlj/P/wCujyx/n/8AXWDxkztWUUjlX0q5XlcGoEsp2lERGCfX0rsfL/z/AJNJ5Y/z/wDrqljZWIeTQvoZkNhFCPlGT696n8mrnlj/AD/+ujyx/n/9dc8qrerPQhh1FWijKm0+KYZ6H1FPisYoR8g59e9aXlj/AD/+ujyx/n/9dP20rWI+qQ5uayuU/Jo8mrnlj/P/AOujyx/n/wDXU+0Zr7MotbK4w4z9aZFZpCCI+ATmtHyx/n/9dHlj/P8A+un7V2sS8Or81tSn5P8An/IpPKNXvLH+f/10eWP8/wD66XtGV7MomHtVC50xHBaIbW/Q1u+WP8//AK6PLH+f/wBdXGtJbGdXCxmrSRxCW0rv5aDn0q1/Zd1jIArqFt0WRpB1bH+etSeWP8//AK66JY2XQ86GTRt7xxT2s0X31xUXlmu9a1cpudTt9SOKhj8NXV7+8tBhe5bgfhTWYRSvPQmeQ1W7Uld9upz+nWWR57j6VreVXTS+G7i0t9yMHCDkD0HWqEWnXc6eZFGxHqBXDLHRqe8noe1TyerRSpuGpkeVR5VaQtZi5iCncOoxzTGhZG2uCCOxH/16aqkug1q0UPKo8qrvl+v+f1o8v/P+TT9oyfZlLyjR5Rq75f8An/Jo8v8Az/k0e0Y/ZlLyjUkFnLczpbxDLyMEUe7HA/U1cjgeWRY05LEAD3P416bp3hGytPLnnZnmQhsg4AIOePxrjxmYxor3t2e1kvDtbGztTWi3ex6Z4d+GPhzR7dDexC7uMfM8nK5/2V6Y+vNdTJpnhdR5Mlvaj2KJ/hXOar4hlu41htSUUr8/qT6fQVzNfmLhiKz9pWm7/wBeZ/S9JYHCRVHC0Y2Xkv8Ah36s7g2Xh/wsJNQ0m3SOS4wpCcK2MnpyBjPasseKNS37vkx6Y/8Ar5rnNxI254FJWscKnrU9592ZyxzjaNBckey09fxJ7qf7TcvcYxvJOPrUFFFdKVtDilJt3YUUUUyQooooA//V/sj2GjYatbB3rUsNGudQOYxtTux6f/Xr9pnXUVeR/FmGwdStNU6SuzB2GvUvD1ws+lxqOsY2n8KbZ+HtPtQC6+Y3q3T8q3FVVG1Rgegr57McwhVjyxR+p8LcN18HUdarJaq1v+CLVee5igwHPJ6Cp2YKpZug5rz+bUmuJjMx6nj2FcOFwzqNn1+JxCpo7AX+e1bOhSC71aCED+LP/fPP9K83W8xXYeEL+KPUXcyxxyiJhF5pwpkPABPpWmMwvLSlJLoPLsUp1oRb6n+eh+0r+2Z8NdL/AOCxP7Q3xt8eTyToNQn8P6UUwVMemNDZt85+6CLPIGCTk+lfM37QX/BTDTPiF4Uv/A/hfS2W2u12mTnORyuWbbxuAJAT8a8//wCClf8AwSs/4KE/sU+Ote+I3xv8KvrPh3VNQub1vFWi777TpHuZXlLTOFElozMxOJ0TJ6E9a/HKa/u7n/WSEg9hwP0r7PPPoseHXEfENLjHHqeJrQhSjFc9qcfZRSjZJJ9LtN7t99P7z4M+kpn2Q8PxyDKVCME5Pn5bzfNvu3H/AMl2se9eB/i94w+FU13P4N1V7Br6MRXCo3EiqcruXPO0k4z61g+JfjH4s8Sh11nVLq7V/vIW2oc+qjAP4ivGCe5r6P8A2f8A9j/9qX9qnWl0H9nTwBrnjCcnDNptnLLDH7yT7RBEB3LuAK/ovHwyxYyWbSwtKNZ2vUcI8+mivNq+i0XkfkUeM81hgll0MTNUFf3OeXLrv7t7a9dDxOXxFMT+6jUfXn/CqMmtai/8e36ACv6b/wBnv/g08/4KK/FAQ6j8aNU8O/DeykCs8d1cnUb0KcdIbMNDuAPRp1/Cv11+AP8Awav/APBOfTdZm0T4tfFzW/HusabtF5ZaVLaadEj91ZEW7nGDwR5gOOuDXz2Y+LODjzWrudt+RN2+aVvxPkq2Y04fFI/gL86bBG84Jyee9EMc11IIrdWlcnAVQWJPsBzX+rh8Kf8Aghx/wSM+EkcMHhr4K6ZrdzF0n1pp9TdiO7C6mlj/ACQV9o6j4P8A2Iv2P/CLeLdc0HwN8MNFgX5rqW2sNNTCjON4SIM2OgySa+CxPjHSclDD4eUm9rtJ/cuZnDDOKc3anqf5CnhX4A/Hfx1KIPBPgnX9Ydui2Wm3U5OfTy4mr3/Q/wDgmr/wUL8SY/sT4IeOJ93T/iRXy/8AoUK1/oH/AB+/4Ocf+CZnwSMuifDe81b4i3kAKqugWXl2m4dvtF21tGVz3j3j+v5O+Pv+DuL4w+Jr9tO/Z9+CFohOdh1PUJryU+hMNpbxfkJD9a+jwGY8U4xc9DLuWPecuX8HZ/gd8HVlqon8zMX/AAR6/wCCpsyh4/gD42w3IzpUw/mKsH/gjj/wVSVDIfgD40wP+oZLn8utf0K/8P8AX/gux8QP9M+HnwXtlgfkfZfCus3a4PTDfaDxR/w/D/4OC/DR+2eJfgyGgTlvO8HavEuPdhOAK73HiTZxoJ9vaO5fLV7L7z+cLUv+CUf/AAUw0jP9pfAfxxFjr/xJbpv/AEGM1434l/Ym/bJ8Glv+Er+E/jDTgnU3GiX6KMe5gA/Wv6vdB/4Or/23fhzfJafH/wCCOkOiMFkERv8ASZffi4W5Xd7YFfox8Cf+Dsf9iTx3LDp3xx8I+I/Ac0pCtcRpFqlome5eApcYHtBXJjMRxZh4+0lgIzj/AHJp/grv8CJKsteU/wA7TXPBPjPwwxTxNo99pxBwRdW8sPP/AANFrmFkIOEbkehr/Yt+B37Y37F/7b+j+f8AAvxz4a8dgoS9hIYmu0Xv5lrMFnj/AOBRiqfxL/YP/Yi+JsD2fxT+Cng3UxKSWkfRrRZCT381Ig+ffdXyn/EXJ0qnssVhXGS3V7P7mkebVzmNJ2qxaP8AHiSWWOQSoxDDv3rUj1zUExuYN9R/hX+n38WP+Ddv/gj58T7QzW/w5uvCt1PkeZ4f1O7gaPn7wSWWa3H08s/Svys+M3/BoN8D9aWe9/Zz+MuqaNKcmK08Q2MN7HnsDPbtauB2z5bHvzX0mWeMOA6ynT9Vp/5K2a0M8w8naMz+GFPEE3mIXQBQfmC969c8KfHbx14UmSbw/rd3amPG0M5YDHpnOPwr9nf2h/8Ag2J/4KlfBJbjUvBWhaV8SNNgyRN4dvkM7KP+nW7FtOTjsgf86/DD4qfBf4v/AAM8Sy+DfjR4X1XwpqsJKta6taTWkuR6LKi7h7jIr7P/AFgy3OqLoV/Z4iD3jJRl+D2+4+pyTiXG4Gp7fL68qcu8JOL+9NH6J/DP/gpl8ePCXlw6xdJrFsuARIdxx/wLcfyIr9E/hf8A8FSvhZ4l8u28b2raZOcZZTgZ+jnb+T/hX8x6syHKEg+1atvrN/EQu7zOwBGT/jX8w+JH0F/CvidSnVy/6rVf26D5de7j8P3I/pHgz6X/ABhlVoYiqsRBdKiu/wDwJWl97Z/oN/8ABtp8Z/CHjq4/ab+Cvgy/F3pP/CQW/irSgAVBj1OKSOcqrYI2S2san6iv6Dwh6iv5Hf8Ag1k/ZY/bP+F/7RGu/tE+N/AeoeHvhl4l8MT6a+paoBafaJvtFvPbPbwSlZ5o/wB26mRU2AN96v7JYPh/ruoTSSWcYEAdgju2AwB4I7kEd69rOsJgcqxksFhq/tKcIUoqTabbjBQfNZJcz5byslq9kf53ePGErZrmyx+Gp3lUcm4xTaV3ey62V2ldnnmw0bDXXax4R1vQl82/i/d9N6/Mv4kdPxrnBH6/5/WsqWKhUjzQd0fzxi8vrYefs68XF9mrFTYaNhrXh0y9nXdFEzD1ApX0u+hG6aJgPXFP6xG9rgsvrcvPyO3ezE07Qr3URvhAVBxubp+HrWlN4Qvo03Qujn06H9a9Ato44rdI4fuhRj6VNXz1XOKvN7ux+p4XgfBqklUu5d7/AJHk9v4f1S4YhYiuDgluKfc+HdTtUMrR7gOu05/+vXqtFP8AturfZWIXAOE5LOTv30/I8P8AL9qPL9q9bTRbBLt7soGLdAeg9cD3qS90m1v4TDsAc8KQMEHtXd/bcLpW0PB/1Ar8jfMr9F3/AOHPIDH6ijy89q+jvDHg/wAO6XEhvTFc3Zxu3EMAfRR0/HvXbz6LpF1H5VxaxMp7FB/hXm4ji6nCfLGLa7ns4DwmxNWj7SpUUZdt/vf/AA58dGP2o8vPavY/G3gCDTYG1fRsiJf9ZGTnaPUd8eoryjy/8/5Ne7gsyhiIe0pvQ+CzvIK+X13h8Qtfwa7op7M9qNme1XPL/wA/5NHlj/P/AOuuz2h4/IU/Lz2o8vParnl8f5/xo8s/5/8A10e0DkKgjBODV+OHS8fvmkJ9lA/rUfln/P8A+ukCH/P/AOuplO/U1ptR6J+paMeiHp5v5CrVpPo9odwR3b1YDj9aywh/z/8AroCH/P8A+usnFNWbZ1QxjjLmjFX9DpZda0+eMxSIxU9Rj/69KNcsQNqowA7ACuZCH/P/AOugIf8AP/66w+qU9jr/ALcxF76fcdOdesjkFHP4D/GmjXbIDasbYHbArmgh/wA//roCH/P/AOuj6pTG89xHdfcdJ/blmGLCNs9zxmsy8udNvZfNljkDYxwRWcEP+f8A9dAQ/wCf/wBdaQoQi7oxrZtWqR5Z2a9AeOx58sP+OKqeWMnirYQ/5/8A10BD/n/9ddEZ2PNn73QrIBG24qG9j0rRTUWi4WCEf8Az/Oq/ln/P/wCujyz/AJ//AF0ptS+I1o150/gdjSXX7+P/AFaxrj0QCnnxLrPTeB/wEVleWf8AP/66PLP+f/11i8PS/lR2rOsYtqj+9mkfEWs/89f/AB0f4Uxtf1nPMx/If4VQ8s/5/wD10eWf8/8A66fsKX8q+4l5xjHvVl/4EzZt9Zun5u7uRD6KoP68fyrTTVbEf6y8uD+AH9K5Pyz/AJ//AF0eWf8AP/66ynhKcvL7v8jqw/EGJprv6uT/AFO/h8Q6TCu0yyN/vAk/yqb/AISfSf7zf98n/CvOvLP+f/10eWf8/wD665nlVF6u56seOMalZKP3P/M9F/4SfSf7zf8AfJ/wpD4n0kfxN/3yf8K878s/5/8A10eWf8//AK6X9k0fMr/XrHdo/c/8z0M+KNJH8Tf98mk/4SrSfVv++a898s/5/wD10vl/5/yaP7Jo+Yv9esd2j9z/AMz/1v7TdF0k38vmzD90vX3PpXoKIkahEAUDgAdKhtLaO0t1t4uij8/esjXPE2k+H4838nzkZWNeWP4dh7mv0CvUniKnLBX7I/Fsmyujl+HvNpPqyxrWsW+i2n2mblmOEX1P+FeYXPivUrxyTIUU9FTgD/Gua8SeL38QzRlYxFHFnaM5PPc9PSufW6NfUZfkfJBOovePBzPiFzqONJ+7+Z3H9qTt1kY/if8AGlW99641bw/5/wD11YW9xXdLB9jz1mN92dmt56VOt561xi3Y71YW8x3rB4Q6IY49Ls/FF1FZSaVdql3ZToY5ba4USROjDDKysMbWHBHQ96/Cz9t3/g3e/wCCfH7Zt7P40+FKv8FvGNy/mTTaPCsmlXDMcsZLAtHEjH1haHnqGr9QPi18Z/Cnwb8JS+KfFMvqsFupHmzydkQfzPQDmvF/hj+2h4L8f6Q+oXmnXOnyRSGN0ysoHAIOQVOCD6V35fw5mEIPH4FSir2uuvqtn9zPsOH+IMfCShh/e8v8up8x/sl/8G+X/BLb9kn7NrninRLj4t+JrfaxvfEZWW0WRTnMdigS1C56CRZiPWv2X1X4neAPg58PwLGDT/CeiaeCAkEaQW8MYACpHGiquTjgKvoAK+Gvif8Atl/DX4d+Hf7RtRPqN9MCLe1VGQMw/vyMNqqO/U+gr8jfH3xQ+L37TXje1sb/AM3ULm6mEVhplqCY0ZjgLHGOrerHJ9wK93JvDbGZtU+s5nOXIt5Sf32WyXnt6m+Z8XY9zdOp7r7Ws/8AM+xf2kf+CjvxG+JFvcfD/wCEM8+l6NOTHJefdvbkHjahHMMbeg+c+o5B6b4VfDDwN+y38Do/2hf2v/FcPw08PRMbx5rqXyr2Vn+4iLzJ5jqowqq0jE8LXzB+0T+0J+y1/wAEXfh7beM/jQlv47+OWrQedonheCRWjscghZ7hsERRoespBZjlYlOCw/GH4Qfsd/8ABQH/AILsfEB/2wP24vFsngz4TWUjtDqN0phtUgDc2+i2LEK3A2tcPkE9XkYba+xlSwSwLp4BrD4NP3qrV5VXtamre9/iaf8AdWh9nwtkOJi/ruPnbSyT6L/P+vT7Q/at/wCDlT45fGzxYP2dv+CUPge8lubxvstvr17Zte6rdnhd9pp6hliz1Dz7z3Ma185+Fv8AghZ+3T+1Vq0Xx9/4KvfF4eCYLo+b5OsXZ1bWih52xWyyC1tBzgIrZX/nn2r7O+J//BQH/gnP/wAEavAM3wf/AGMdAgtNelhCT6kyJeeINROP9ZLK/wDx7xseR5mxP7kQNfzJftIf8Fav21v2ufFk1j4bv7vSIr5iqQac0lxfyg9nuSDJ+EQQCuHK5ywtKTyejHDUktak7SqNdW29Ir70uyPs8PVnO1PBQ+f+Xf5H9KcX7P3/AAb+fsA2SXHizQ/+Fg6vbqD9u8Z6gFidh/ElkvlowJ6D7M31Nc9rX/ByD+xx8DYDon7Nvg/RdHgh+WNfDugLEuBwP3kn2RG+u2v5cvAf/BO39pL4pXQ8R+PZE0QXPzvPqkrS3TZ7lBvkz/vkV9l+Ef8AglV8LNPjV/GniHUNTkH3ltljtk/USt+or+VfEX6XnhVktWVLN83eLqreNPmrfK8b016cyP1XJPAribMoqpKnKKfWTUF9z978D9N/EX/B178R7mc/2No+sMnbI0+D9Ak386yNI/4Ot/ixBMraho2rhe+HsJf0MEefzr5N07/gnZ+ytYRhJdGuboj+Ka7lz/44UH6Vbuv+Ce37Kd0hRfD8sR9Y7ucH9WIr8Pl+0c8I4y5Fl+Ia7+ypf/Lb/gfZL6KucuN3Uhf/ABz/APkT9NvCf/B0p8JvHMC6N8adBF5aSDbJHrGjRXURB6hvs0r8f9szXqFr8XP+CAn7f5Nj43+HPhzTNXu+t54Wn/sm9Vm/i+zp9jZiPRkkHsa/CLxP/wAEuPgRqkbHw1qWqaVIemXjuEB/3WRWx/wKvkD4i/8ABLj4veHQ+ofDzVLPX0j+ZY2Jtbjj0Dkxk/R6/VeBfpneEOb1VDB5jLBVHtzqdJfOS/d/fM+Wzj6PfEuBi506bkl/K1L8NJH9CXxU/wCDcz4f+Lrw/Ej/AIJh/GsHWLQme10XxDI1lfxkcqIL+3WN1cdAWhA9Xrj/AIb/APBXf/gsJ/wSQ8Y2nwd/4KH+EL/xp4XU+VGdcx9raJTgtZaxEJIbsAdpvNPbcvb+e/4afti/tz/sS+I4NFu9Q1GGC1YFdN1pZJYcD/njIzCSP2MUgFf09fscf8F9/gV+1X4SX9m39uDQLLWNP1RVt5dM8QCOeGYnjNrdyADzBn5Fl2SA42vnmv7DlmNbGYONSvyY/DSV1L3ee3eE46P9f5j8nxixWGk6WNp3tvpZr1T1R/SV+w//AMFJf2Of+Civhj+1v2dPEax67bxCS/8ADmpYt9TtSeuYSxEiA8eZEzxn+8DxX3FNDLbyGKZSrDqDX8Sf7XH/AAQ11Lw1IP22/wDgjH4nv5ZdFk+3SeGIbho9Z01wNxNhNkSTqP8AnhISzDhWlzivvL/gkj/wcGaR8edYsf2S/wDgoOYvDPxCjk+w2HiCVBa22oTqdgt7yNgotL0tx2jkbgbGwp/O854Ep1KEswyKbqU4/FB/xKfquq8/zV2fN4/h+lWh7bCP5H9NUwmhkF3ayyQuOpRiM/UdDXLfETwR8NPjV4afwV8bvC2k+MtJkBVrXVrOG6TBGCQsqOobHcAH3rvtQ02a2fypeVPIYdGHsarrCVG1RjFfnSqRklLr0f8Awdz4GGHxFGu5UpOPf19Nj+cD9rP/AINc/wDgn38f7ibxJ+zzqepfB/WJW3tb2w/tDS2z1AtbiQSR+3lzqo/uV9ufsL/8ELv+Cc/7A32TxHpHh3/hPvG1qFY6/wCIkju5Y5R1a2tyv2W155UqhkH/AD0NfrL5bUeW1eliOIMxq0fq868nDtf83u15Nn06z/FcnK/vOyk8S6dcRm3urctEeCDgj8jxXR2OpWV+v+ityP4TwR+FeV+U3+R/9epYvOgkEsLFWXkEV8zVy+DVo6GVDNqsZXmr/meszww3MLW86h0cYZT0INeJSeHbKyvJVSEERuQCeeAeK9hsNQiurNbiRgp6NnjkVcjEDIfL2lWyTjkHNcWExlTD80TvzPJ8PjXCpNK62drnjlFdbL4auLi8laHEcW44z/Sqt54cu7SMygh1HXHUV6scXTelzw55bWSbtoc5RVryK+U/23vjXqP7OX7Lfi34s6FIkWq2NssOnGRQy/a7mRIYjtPDbS+7B6gelY5lmVLCYepiqz92Ccn6JXZeW5VVxWIp4aj8U2kvVux9GX2vaJpknlaleQ274ziSRVOD7Eisabx/4It/9dq1qP8Atqp/kTX8Wdx+3T+0r4t8X3HiXxn4suZbi8K7mRI4402gAARqgULgen419UfCn9pT4zeJr2e01TVjLHBEHDhEBJJAGflx0zX8r4z6UCWJdCjhdG/dbe687PR+R/UmC+jDfCqvWxWqXvJLZ+V1quzP6yrO8tNQtkvbGRZoZBlXQgqR7EVZr8WP2Y/2ydS8D6oPDnxFl8/TLl/9acDyye/YKfyB74PNftBomqaT4j0uHWdEmW4tp1DI6EEEH+R9q/eeBPEHB55h+ek+Wovij1Xmu68z8J448PMXkmI5KmtN/DLo/J9n5GjaWdzey+VbKWP6D616vbRNBbpCzbiqgE+uK8yhElvIJYWKsOhFekafctd2iTvwxHP1FfTZm5NLsePkkIxuupX1uWCDR7qW5wYxE+Qe/B4/GvmP+0LL/n1X8/8A61fSmvaL/btp9ieUpGTlgB97HTPI4ryLVvB8ekSATxhkb7rgnB/wNerw5iaNOLjJ6s+F8RcuxtepCpRiuSK3dnq/vsjhTqFof+XVPz/+tTft1qf+XZfzNdH/AGTYf3P1P+NIdIsD/B+pr6j63S8z8veV4zvH7l/kc4by1P8Ay7L+Zphu7cj/AI90/M10p0aw/un8z/jTf7EsPQ/n/wDXprF0vMyeUYvvH7l/kcybiA/8sV/M/wCNQPJG33UC/TP+NdX/AGNYe/5//Wo/sWwPr+f/ANarWNp+ZjLI8U97f18jj6K646JY+rfmP8KadEsv7zD8RVrHwOd8P4hdvvOTorqzoll/fb8x/hUZ0ay/56H9P8Kf12BLyLEdl95zFFdJ/Y1n/wA9j+lc7rOqeDPDrGPXdXt7RxG022WRFby1IDNtJBIBIGcdTWkMTGTtG7foyVkeJbslr6obSAgkgHkda+C/jD+05HqU76D8PJnjs1OHuvuSS4/u91T9T7V8deM9Z+JW2X4i/CrxJd6Xr1om+QmUtDcogz5c8b7o2IA+ViOOnTp9vlnB1WvFOpJQvtf9e34n22G8LcdPCuvOSUv5ev8AXkft1UF1dWtjbtd30qQxIMs8jBVA9SSQBX89F5/wVN/aHufC0ej2tnpdvqABD6gImZmHYiIv5at6nkewr5Wv/iF8cv2kfE6aP4u8Q3upeYDJIsshW3ijX7zeUm2MAZwPl5JAr6rBeEWNd5YupGEV13f6fmvQ+TwvDlapNQvq+x/SS37UXwJk8Rt4V03xDBqF5GMzCzDXCQj1kkjVo1yeAN2favWdE8Y+FfEahtD1CC5z2Vxu/FT8w/Kvwt+GOm6F8L/DqaBpsSvuYvNKMB5HPc+oA4A7CvZdP8R6XdyKbaby5ewJ2t+B/wAK8/HcGYVNxw83ZdXbX5dPvP1XDeEuGqYePNWaqddmvS2n5n7JUV+f/hH9r3wv8MrA6P8AHC8a0tFUfYNQ8t5A+BhoJdgYiRfvKx4ZcjqvOxdf8FHv2TLXONenl/652c5/9p18xPhLMeZqnRlJd0m0/mfkmbcP4nB4meGqRu4/j2fzPuiivPfhz8UPB3xT0OPX/CNwzxSIsnlyo0Uqq4ypaNgGGRXoVeDWozpycKis0eVXw9SlLkqxafZ6BRRRWRiFFFFABRRRQAUUUUAf/9f+0zx/43j8LW4s7PD3soyo7Iv94/0FfNE+qXV5O1zeOZJHOWZuSai1fVrrWtSm1S+bdLM24+g9APYDgVnZWv6OyjJ4Yaklb3nu/wCuh/I+eZ/UxdZyTtFbL+uprLeCp1vBjrWFkVyPjXx54X+HuhzeIPFN0tvBCu7bnLueyovVmJ7CvXhhXOShBXbPJp1pt2jqz1Nbw561OLzHWvi3xL+1N4cs9It9T8OQtcLeKWhaQYzjg5XqMHg5NfLPiz46eN/F0jC9vnigPSGIlFx74wT+NdkMhqSdpaH6DlnBWNqpTrNQT111f3L9Wj9R9B+LHw/8S+ILjwroGr213qFqN0sMUgZgAcHGODg9cdO9X/GnxE0LwJpD6trEnIB8uIffkb0H+PavwP1u5vdA8QxeI/D872s+7zEliYq6SdyCOeete9+KPiTrXim1026126a5umtIpJnPd3XPQcDA7D1r3sdwVRhGnXpzvCX336noZTwqpYuVLES92P3vt6X3PP8A9oXxv4t8ffECXXPE05khZf8AQ4l/1cMX9xR6g/ePU9a534W+L7fwxqU9vfyeXBdKvzdg6njPoCCeaZ43u01HTo5OC0T9fZhg/wBK8yRDK4iXqxA/Ov1TKaVKvl6otWS008v6udeMbwGYc+H6ar59P0PsjXrGDx1pw0BFM0twyi32Dc3mnhNoHUknGB1zWX+1h+1H8NP+CI37PkXiDUYrTxB+0L44tJF0XTHIkj0q3b5TczgHKxRnqeDM48tTtV2Hu3hP4hfC39hH9ljXv+Cg37QEfmWOhxfZfDGmEhZNQ1BgY4ViDdWkkG1W/gUPIeFzX4G/8E4f2XPGX/BVb9pfxh/wVP8A+Cisz3fw70C/86S3k3CHVr+LBttJtUJ/48bNSiuo+9lUPLSMPyWpj44inW+syawdJ+8lvVn0px8tubvttdn7LgsqoVaizDEx1iv6/wCAdr/wTs/4Jnan+0ZfXX/BVP8A4K0393qeh61cHUNJ0a/YreeI5/vJLMp2mLTlAxHGu1XQfwxAbvDf+Crv/BdzxV8R9Vl+B/7Ls0Gm6RpA+xx3FgqrY2McY2CGxjUCOSRFG0zEbV6RjHI85/4Lbf8ABXjxb+0D491D4A/B68+waJp4NheyWTbYoYk+X+z7XZgBFAAndfvMNgwoxXyR+xJ+wbaw21j8YfjdaCSRws2naTMvyqp5Sa4UjknqkZ9i3pX4/wCNnjXk3BWUvini6Wvw0aEbXbtpCC2va3NN6Jb6WR+k8EcCY/ibGqhQj7u+u0V3l+i6/l86/s7/ALCvxQ/aEvf+FkfFS7uNL0e+fz3urkmS+vS3JZA+Thv+ej/gDX7a/Cb4EfCr4I6Uul/DnSIrNtoElyw33Mvu8rfMc+gwvoK9dC4AVRgAYAA4AFLhq/59vpC/S+4v8Q8RKGPrOlhL+7Qg2oJdObrUl5y0v8KitD/QvgXwsyrIaadCHNV6ze/y/lXkvm2JRS4ajDV/K5+kj4YZriZLe3UvJIwVVUZLEnAAA5JJr2L4h6R+zP8Asz3dv4d/a6+In9heLbuBbmPwh4f0+417X44nAKPdWtoGFmHByPNYH6VxGkfFKT9nn4efED9pyxtI7/Vfh34audU0S2mXfHJrdzNb6bpW9T95Y9QvoZCO+yvwP/aH/aAg/Zz8a638E4tRfV/FUN5HP4g1rU5GQ61qc8hGoX93cANJKBOW8tTlYodoUZDk/wBp/R18DcrzTKpZ/nNF1+abhTpKTiny25pza1snJJJP102+Hq1MRmudSymGOjgsPSgp1a8o87TlzclOnDROclCTV+idtUk/3U8OfHb/AIJv/EfWYPBnhv4r6l4K168fyrODx/oF3oVpcSkgKgv28y2iZiQB5jKM9xWv418FeJfh54muvCPi62NpfWhAdCQysrAMjo6kq8bqQyOpKspBBIr+VX4g/tP/ABD8QTwQ6ZY6be6QCReRxTR3ttNE3DBtvmMSB821lU4zgE1+4n/BOL4s6x8avA1z+zj4nvt+seG7drzwJDLcx3bXujonnXukwzq7s8mnOWuLKJzva1aVFGIVWvrvGP6OuXVMplmGQYT2FemuZ04zc1OK+Kyk3JTiveSTaaT0vY9DMsE8lxLlQzGWNwt1GU5UHSlTcl7srq8ZU3L3HJ8rjJx+y7n0p4x8EeEPiDosnh3xvptvqllIMGK4QOB7qTyp91INfj9+0n/wTPudOguPF37PrvdRKC8mjztulA6n7PIf9ZjsjfN6Emv2q2t6UYav558D/pKcXeH2MWIyDEtU73lSleVKfrG+j/vR5ZLucXGPh/leeUvZ46n73SS0kvR/o7ryPyF/4J0f8Ffvj9+wz49svCvj++vrvQbKQW5aXc15p6g4KMr8z26/xQvyB9wgjFf0kftpfsEfs3f8Fs/g8/7VP7IcmnaH8bIrMXksNs6pY+JIkXqTwFuTjCyn5lb5JuMOv4jftefsXeGv2gdMk8VeFVi03xdboSk+Nsd2AOI58fxdlk6jocjp8Kf8E9f2+vjB/wAE5vjmmheIZby00OG+26hZnPm2E4O1riFD7f62P7sqe+DX/QP9Hb6RmTeJWX/2zw/L6vmFFL2tJu7V/u56cntK2j3UZb/58eJXhdj+GcXzL3oS+GS2l5eUvLr+J/UZ/wAENv8Agsv410jxnD/wTQ/4KFz3Gn+JNNuG0nw9rGrZjuUuYTsGlagZMN5wI2wSty/EbEttLf1n6lcXumXjWlyoUjoexHYiv5GP+Cr37EvgP/gqB+zUv/BR39ka3hHxT8K2MV14isdNP/IZ06NN6XkGz5muYY13xMPmdAYyd6JX3v8A8EGP+Cokn/BQb9nyX4CfGW/Evxa+HlqgaeUgSavpgxHFd9t0yHEdx/t7X/jwP0vi7I8Ni6DzzA0+SztWp/ySf2l/dl/we9vx/PcAsTQ+tYbdbo/eZNWb+MA1qW1/bTkKTtY+teb/AGto2KNwRwQetTLe8ZyP8/jX57Uy5Wuj81pZo09T1YQn0/SmlUX7xArgBr100SweZwPQ8/nUQv1Jyx5+tcay6fU9B5rT6I9EURvwrA+1XrSSeylEkJ+o7EV5ql8oPXFdDpOtqsy29y+VbgE9j/hWGIwMlF9TowuYwcl0PSrrWtp22qg+56VUTWLvO2VVYHqORWFcaxo9sC01wgC8k54AHXJ6DFflv+0P/wAFF/hhm6+G3wb1+1ub25Wa0kvbd0mkiZkZGkgTcMmEnduPUrhQRkj4fiTP8DlGH9vjXZdF1b8j77h7Jcbm2I9hgtX17Jef9anG/ts/8FZvhT+zjeT/AA/+E0UPjDxbC2ydUkIsbMg/Ms0qZ3yj/nmnI/iK1+DP7W3/AAUy+Ov7Wnw8T4c+OtO07T9HhvIr4w6ZHKZZJIVdUDNJK25RvLYABJA+h+a/i98BfGnwlvTdagV1TSZ3PkapbZeGXJz856xynqVfBz69a+cNc8SaZoMkNtcB5bm5JEMES75Hx1wo7DuTgCv404p8Ts7zapOjKfLTlpyR2t5vd+b2+R/W3DPhzk2VwhVjDmqR155b38lsvJfmXZ9T0+DSl1kSebBKyxxbOWkkclRGAcENkHcDjbg5xivqT9nb4peF/CHiH+x/iJJdw6VeKsRurMI0kBB+VmV1bfGM8gcj36V8EzRatpvi9PFmvW72uiglgm8OIbqRRH58iqSEDp8pbJAPJxmvZwSBvXnuK/OsRgY03GS97r6eWnVdfU/QoZg5KUVp/W/+Xoful4m+DnhrTtBb4g+EfEA8SR6Rm7m0y+VDHNEgJYbIwjF1HKqw2kjBr7a/Zf8A2oVv3s7nTJfII2vJaRkiGeEcHYp4DKOMdQR6V+aei3X2rSbS8U582CNs+u5Qf610HwU+K/hv4Ovc+HtV09Wv2uJjBNK+wGB2LKIyVK9+cHOa9TJ86lgMZCvQfJ567rb7+233s4s2yiOYYOdCuufystnv5ad9z+q/RdY0bxFYpqOi3EdxFIoYFGBxnnBx0I7g9K6yO+uoYlhgwqrx0zX872g/tUW+n3aXMNrdWR6+Zby8/oVzX27+zt+3KPF/jGPwd4tZvssi4SedVWQHOM5U4ZV/iyM4Oc8V/WfD3jbl+MnGhi48snpfdX/C34n8r574NY7CQlXwkuZLW2zt+N/wP1Us9TlZxHc454BFWdZ086pp72ikBjgqT2IP+FZsccb4ZWGDyDn9a2/t1vnGa/XZq0lKmflcYqpTlSrap6HmV/4T1GyhM6FZVXk7c5A+lcnIoddu4j6V7+JoXHDAivK1+G8ctxJNcXxVWdiqp2BPAyT2+le5l+Zpp/WHa3kfA8QcLzi4/UIcye+qVvmziWswxyJnH4j/AAqFtN3ci4k/P/8AVXfz/DS0KH7NfyK3+1gj+YrEt/htqjXDJdXqJEOjKSSfw4r2KWZ0Grqpb5Hx2J4Xx8ZKLw179pL/AD0OVOk5/wCXh/zph0Yn/l4b/P416T/wrTTtuDfSbvXj+Wa5jU/h1q1sQ2nXC3Ck4xnawz35OMfjV0c2ozdlU+9HPjOEcZShzyw1/SV39y1Oa/sVv+e5ph0Q9PP/AM/nXpGn/DSyEQbVLtmc9QhAA/E5z+leZfF+bwJ8IvC8vjDxLrUdnaRcBZmG+Rv7kYXJdz2AFb4bNadSqqNObbe2hNfgrGRo+2eH+XPr9wNojLz54/Gvh/8AaW/aM0nwj4e1PwR8MtSWfxPNC8MNxCFaK0lPALMQVZweNozjvXxx8b/2yvFPxBabQPBQk0jRzlSwOLidf9ph9xT/AHVP1PavjiTXJVBePJZcke5r9YyHhGcZxrYt3t9n/P8AyPTybgyg4qrjIW8rt/f/AJHV6L/wUv8A2lNO8Hy+BLmCzvdbLCCHUpIv36EZUholxHJJno2AB3Bqt4cuPECmfxJ441GbVde1LD3l1cOXbjlY1zwqJngDAz26V89+D/D09prt54v19P8ATLiaR41ODs3sSW4yNxzx6V6e2suO/wDOv1jNKeCpTlTwNOMb/E11fZeS7bXPb4ayajhW8Ry+89vJHrDa523Vj+KfGf8AY/w58SXCviRrLy4/96VhFx/33Xmr6w3qa8i+LGv3MmkwaTEWCzybpB6hOmf+BHP4VhlGF9rioQ6X/LU+kx+cOnRlJb2f46Hz+BgYr3/9nyQWuu6rfH+CyCA+7yx/0U14Hsb0Net/Cm/NhLqEeDmVYue2FLZ/mK/TeIHbB1PT9T88yWXLioSf9aM+uG130NVW10/3q8pfWnFVX1mTHU1+Rcp+gPMrHtGreIrHxX4YufBfiwGazuFwko5khcco6567T29Mivnr4N/Cy0vPF8+qeN3SLStGl+cvws8o5RFzyykYY+3HetN9ZfuTVZtabGMnAr1MHmlahSnSg9Jfh6Hn4qrSrVYVaqvy/j5PyR99eFv2g9I8OeI477Rp5bN4ThJtvyMO6so52H0I/Kv1Q+EXxp8NfFXS1azmjW+RcyRKwIYf3kPdfbqO9fzWNq7npmtrwz8QvFXgvV4dd8KXktjdQMHR42xyPUdCPUGvkM4yCniodpLZ/wCZ5/E9KjmdP98rTW0lv6PuvxX5/wBT9FfFf7LP7YHhv462SeGPEpj03xRCnzwZxHchRzJCT37snUdsjmvtPK1+UYvCVKFR06qs0fheLwlShN06isxaKTK0ZWuY5haKTK0ZWgBaKTK0ZWgD/9D9aP8Ahrq7z/rX/Wl/4a7uyOJW/WviX+zGz0/z+dKdMfsP8/nX+1n/ABC3If8An1/X3H/Oz/xMPnX/AD/PrfWf2rvFN/G1vp199kU8b1yX/VSB+VeC694l03xRMbrxBqFxdSscl5HLMfzU4HtXB/2Yc9KT+zG9K5oeEuRRn7SMWn6n2WWfTB4mwdL2NCpBLr7kW36tq/4neQ654ai06HSzcStFAzsnPTfgkfc6ZFKNY8JH/lrL/wB9D/43XA/2Y2en+fzpw06RGDJkEdKmp4R5FOTlJSu/7zPbh9OLjGKSVeFl/wBO4/5HaXM/gq9ULLJcfKcjDD/43V6K+8IhFTddEKAo+YdAMD/lma5FLjWouIrmVR7MRUhv/ER4N5P/AN/G/wAazn4U5S4Knyuy/vv/ACN4fTe4qU3U9vC7/wCnUDqLi68FTQtDOboA/wC0P/jder/s7/Bnwv8AHb4vaR8OdCa8zcyGS4kDL+6t4vmlc/ux0XgerECvnl59bk4kupjn1kb/ABr6r1n4wD/gnv8A8Ezfin+247CLxb4hj/4Rrwo0h+f7VcEwpInc7JS8x/2bevgvEnhnLskySpPBp+2qNQprmes56L5JXk/JM/afo++P/F3HHF+Fyf2sHD4qj9nG6px1evS7tFPo5XPyQ/4Kn/E3xp/wVr/4Ke+Df+CY/wCyxL5XgX4f3p0K3aDLWwubdcarqUgXho7GGNooyc52Ng5lr2f/AILU/tofD79hv9nfw1/wT/8A2RJF02w0OzbStO8kjeBGCl7qcpXG6eWVnWNz1kaSQdKpf8ELvhJpn7KH7EXxE/4KU/EZxB4h8ctceH/Dl5c/6yDTrUtJqV8GbnMkyNluuYBz81fykftH/HfV/wBqD9oXXvi7rTP5F3KUsIXOfIs4Ttt4/rt+ZvV2J71/OmDyeniMfTyvDv8AcYX3V/eqP45Pu07r15u5/rxVpKrVWHj8Md/Ur/s6a18NfAHiw/Ef4padPrktgRJYacMeXLcHkTXDvxsjPIXDFm5IwOftPxN/wUo+MusztH4S0rT9MRvu7le5k/MlFz/wGv0+/wCCGX/BDHQv+CiXh2+/aT/aI1S6034d6bqD6daWOnsI7vVLmAI02ZmDeRbRFwpZVLO24DbtJrR+G3/BQDwb8G/+Ci+gfsofs/8AwS8C/D3wZpXxEg8MajezacNY1q5s4dUWxlklv77e0JlRSx2KNmThuM18Hxv4I8A8RZ/Wxua5f/aGJw8bfvZv2VKK15YwvyXbu37km3o5aJL9GyjxBzPLsM8Fl1Tkju+VJNvzlv5JJ2PyS0343ft//Etx/wAIhb63eeZyo03SmcEH02QP/M12UXwv/wCCs+ukNa+EfiFLu6GPSLxR/wCO24Ff3Y/8Ft/jN4km/Yc1b4Z/sNeMjb/FKTVdMbT9K8J3qrrM8CXK/akt4LV/PdVg3PIEXhFJPANfj7/wS+/bU/aZ/wCCXXwY+Ln7Q3/BXk+OotH1WbQ7Lwra68bq71HU9Rb7e01rpttcybmbygskrDaiquXYcV4mXZJwZhMjqZtheH8FSUHZQdKnzNXSuv3a0189mcMuO87xCu8RUbbslzybforn86c3wI/4K4WxHm+C/iQMkAf8Sy/PJ/7Y19Cp8I/iP+z7bw3X7fXx6n+Her3KCS28GaNEfEfi2QMMqZtOtm8uwUjvdTRn/Zr62/aL/wCCyv8AwUO/bb8S+Io9H1T/AIUx8P8AVBCltp/h5z/b1xaEM8aXmpMW+zvscFxapGQzFd525P5s22nfD/4UWklzYwx2s17MvmzMxkurmaVgN0szlpZXZjyXYkmv5i8RPpDcMcjweVZHhXU7qhTaXpeDX4P5H9++Cn0IuPOIMNHNeI8bLL8M9fecnVaX9y6UF5zd+vK0dx46/az+Dnh74YePPhL8PdU+KnxS1PxDo9vCkl/4fstK0+zuYNRsdUsxPE1zJeOyTaeiyMny4ZigfHPxP8fYtM/bI8Up418PQHRdb1Se72Wt0fJmttRM5nFjPIQDGzq5SNzgZZWyFLY+rvCviez8X6lc6ppbh7eAG3DA5yysQwJHoQRjtXyT8SPC1zrvxw1K88PajbW51HS5Y5LK4lWBdQurArIsMUzlUj1A27u9tuI8wx+VnLrn8My7jqWPzKl7LCU6DpXko04xpxd17ycYRjFOS623SvdH7zxv9F7LOC+DsxxFbM6mKw+O9nTqylGLcFGbdKrCzbapzaU463g5SjZpJ8lL4W/YX+Ff7P1h4Q8az+JNV+M+u3ZfXb+4gk03SvBkUMrrNapbBTd61fSIuSitHGMrllKkn9Mf+CZf7A3w+8dfAC2/ab1LTPiJpN34w8bz6d4L8UeD7S41G68MxaBBHOdT1CzjWcXCT31xFBsSQOjQyFHYBgfy61n9vzU/FNrpfgDxv4H8L+NZ7tIdOm17UNPSPU761D7LeCXU/OSS2dOE80KssRA3O6oAf6IPjR+wj/wVs+CunfDH4O/B3T/F2h/Df4S+FdM0/WtV0XUJLDSri6E8+pa3qKiK4iaeBZbuRfPdS0qRbwNpAr+xOAMiy/O8Wo15KMLNvn93Xok+93ou61Vj/HfHYLH5RipYL6xor/BN8rT06aWkvk07Xep8U/tK+GP+Cnvjr9oHxt8Svhv8OPiHoXhvXNcvr7TLFtGuh9ntJp3eJCgt2VCEIyo4U8DgV856r4n/AOCmnw+Xz/FWi+KrJF6/b9GkUD677UV/dv8Atif8FQ/2Zf2mv2PfiD8D/wBgf4lQeMfi54h0C5tPDWleHZ5P7XuLkplntQm2XzIYQ8pKnIVCe1fkT/wQx8a/8FBPgb+2Nq8f/BS3xP4u8L+DpvDF1b6dF49vbiCxudTa6sjGlub5xHJcrAsp2oSwTccYzX6thuEuF8TldbEZjw7g1Kn9idGHPNWWqvTbfrbVpnZheOc4pwvDETVunPL/ADP5pdO/4KCftKeFLkWniu1s7oocOl1atBJ+O1lwfwrxP9pr40eB/wBpGxt/FdxoB0PxdaARvPA4kt7yH+7JkK6yR/wNg8ZU9sf2Mf8ABw3+3/bfs1/F74Y6P8K/CvgX4geH/EWkX93rFprmkWuqQTbLiGOHbcoVmhYr5gyj++K+f7T/AIIl/Ab/AIKc/wDBObQf27P2TfDa/Cb4i61Y314PDNtcy3mi3sllc3Fv5UXnjzrZrnyN0bBiilgpXHzVwcM+D/hzleIwfF1DJ44CrJuMalGTgtbpxqQjyxcZJO6cJJaO6aTXq4vxLzbFYN4THVXOnLpK0rPo03qmu6fqfmp/wQD/AOClfif9mv4z2PwE8ZXTyaZeO39mJK3DK53T2JzxtlAMkH92QED72K+k/wDgpt8IvEf/AAR7/wCCkPgX/gpF+x/Ht+H/AI7ujrVnbwfJbLNLhtU0l9vCwXULmSJT93cQozFx/LFe3ms+FdUtte0ySSw1XSbpJYZF+WSGaF8g+oZHX8xX94X7P17oP/BaH/gj74k/Z8vhFJ4vttPbXPDoOC1rrmnZ82BD1VJJiVx/zyuD6V+x8T4GGTZlHGS1o1FyVV0cJaXf+F6+l+5+c1Y/V8Qn9mW/r/wf63P1G+Pfx98OeJPh14K/az+EV9Nc+C/iTp8N7bSRAsIp5Iw5jcK3yORkMvZ0cdq+TZP2sdVx+5ubhvqjj+pr85/+DeT426l+0V+yN8Vv+CaPjOeSLXvCQfxJ4WSRmWWJWkxc2685UQ3u0kDoLhq9Da98UQSNE95coykqymRgQR1B56g1+v8AhDwXluIo18sxcb1cPK13b3oSV6cvhfS8XrvFn+U30zOJsx4N4hh7D3aGIi5RfvfEnaa+NLqpbfat0Ps8ftZ+IT903J/B6d/w1h4kb/n6P4PXxkNY8UjhdQuR/wBtW/xqQa94v/6CVz/39b/Gv2J+FmUdKMfv/wCAfxmvpEZj1xMv6/7ePsz/AIas8VN0F1+T1i+I/wBs3VPCmjya3rktzb28Xdg4yeyjPVj2FfCfjr4zT/DzTvtviHWrhHcfuoVlYySEf3Rnp6k8Cvg7x/8AHnxj8Vb2Ox1O5lltYnLQ2zSFlU4xuYk4LAdzwBmv5E+kz4u8JcB4KphcNShWx7Xu007qN9pVNFyxW/LdSl0sryX9pfRU8P8AizxEx1PF161Sjl6fvVWknO28KSu+aT25rOMet2lF/UXx5/b9+M/xXik8KWmqS6Jol9ugFtC5E1wuCSskg5IKgkquBjg5r5A8Oatc+Gdds9fsOJbOVZVA77TyPoRxXmUfiOPUfEazWca3FhBA8UMyOBJLOzAyPCjDDx4QRqSy7jnaTnFUE+I2hXlv9o0u5a7BztEcTg8dmLqiqR3yeK/w64ozzNs/xrxuZzlOo+60SbeiS0ivKytrof75cOZVlHD2BjgsrhGFOO9mr3t9qTd5S823c/cjS/Eeh3Xh+S81EpLo2q2hS5STGx4J0wc543rnKnqGAxX47Q/CL4g6V4x1rxfrui3qWW8Wmm3TwSCOW1j5MqErjbKxznviv1C/YQ8X/A/xD8OLeX4k3f27XdIml8vTHUyRwxbsxSbcbZScnBOVXpivsvxT+0hrjxm30qCGytWYRqZF8wgHhcg/IueB0PNeB7J0FOFeSXTu+j+V7H2FDE08bCFXDK/W/T063sfz+gbCVdAwIKsjgFWB4KsDwQRwQa8w1HxHb+Atbfwe8E90s0SXOmxwqZJPKkLL5THt5TqQGY8pjPNfoL+2f4Kh8NaLJ8f/AAhp5uIZpUh1Swt1wI7yU7Y5gB9y3uG+8Rwj5H8S18GaRdXkMTahrUizaldYe4lAwM9o0/uxxj5VHoM9SaeFy+XxtXi/xf8AwOvrbzXFjs3p0YuFR2lf/h/v/rbX9r/2frPRfiJ8NtHuk1/TLS8is4UurWWf97BIqhWV12juOCOD2r3bVv2cvDPi3TW0/VPEFhLnlNhyVb1DZBH5V/PnD4jurRzJazPExGCUYqSM9OCO9fbfwL/aPtNYeHwb47mVLo4S2u2IAk7BJD2f0Pfvz1qrly5Hz07r1ZlgeKKU6iiqnK+j0PdfHfgvxh+z7fWs41aHWtIlmML+S+8IwG7YwOdjFMlccHBr1zw94n+xNa+K9FnwI9s0cg6Y9/bsR9aW68PL428Nan4GwDLfw+Zae13Bl4sf7/zR/wDA6+YPhL4yOlXv/CL6qdsE7Hyy38Eh6qfQN/P618Y6qwmIUI6Qltrez7fl95+kql9cwzqPWcd9LXXf8/uP2G/4Xj4v1jSbfVPBEs97+7H2i0jcmWBgOy5yyHsRmvLrr9r/AMQ2U72l3PcRTREq6OWVlI6ggnINfItrrl54G1aGRJ2t7aR8W8yttMMh/wCWZP8Acb+H0+6e1eseI7vQPifEk3icLZ6zGuFvYwFS4AHCzDorej9PXjkf6a/Rj+mBlOFnQyDjbDxdGPuqsr80e3OteaPTmVmlq1J3P8tPpW/Q4zvFUsRxFwFiZKu/fdB25J/zezenLJ78rum9E4qx64P2ydYHAu5v++m/xpf+GytY/wCfuf8A76b/ABr45m8N20V09m6SxyRnBEjIv6k4I9xTf+EQmc5We3Qf7U6Z/RjX+ymD4A4WxFGOIowjKEkmmmmmmrpprdNapn+E2O8cOKMLXnhcRUlGcG4yi7pxadmmnqmno01dM+x/+GydZ7Xcw/4E3+NH/DZOskcXk3/fTf418cN4QkXrdW34Sqf61n3OgG3GRLHJ7I2TXZHwx4ck9KS/r5HHU+kFxDBXlXf3/wDBPtb/AIbI1bqbubP+83+NH/DY+qn/AJepv++m/wAa+Hv7MOelJ/ZjelbrwqyD/nyv6+Ry/wDExeef9BH4s+4G/bG1V/la5mI/3mP9ay7z9qqLUdragguCn3fNQPjPpuBxmvkG2F9ZjZAQo/3VP8wankuNWkGGcEf7iD+lZ/8AELcjT0or7/8AgHTT+kbnKV/rTT/r+8fViftG6NcNs+x25PvGg/mKsr8b9Mn6WFqc+0Y/wr43bTnZixHWm/2Y3pWkvC/JX8NNG9H6TnEEf+YqXyk0fZo+LlhL00y1P/fv/Gl/4WdaP93Sbc/TZ/8AFV8X/wBlnPSlOlnstZPwtyj+Vfd/wT0IfSr4ijtjKn/gxn2cfiPasP8AkEQfmn+NQSfEDT3GZdHtzj18s/1r47GlEnAH51LHpUsbh0Khh3yP/r1lLwwyha2X3f8A2x2Q+lhxK9sZU/8ABjPrhvHejdW0e1/KP/Go/wDhY2gxdNKtVz6eWP5GvmCN9Yj+VZ1H4If6VMbjXD0uU/75T/4msH4b5Xtyx/E7F9K3iS3+/Vf/AAP/AIJ9HyfFPwxHzJp1sPxT/Gs2T4zeCY22Pp0BPsgP8s188ypqUwKy3Ckf8BH8lrNOisP4l/Ouil4bZH9uC+V/8jlr/Sv4uf8ADx9T5zf+Z9QxfFXwncANHpNuQf8AYWpT8TfC4XJ0e2/74Q18sHRTnll/Ok/sU/wsv51b8M8j6QRk/pX8W297HVP/AANn0vN8XvA8TbJtItQfTylNQ/8AC4fh530e0P1hX/Cvmw6WVPr9P/11MmlWpHzs4+ig/wDs1bLwyyK2tM4pfSr4sk/9/n/4G/8AM+lLX41eA7G6jvbLSbWCaJtySRxBXVh0KsACCPau3i/a1uYRmKaQH3Zj/M18djR9OJ5lkH/AB/8AFVINE0sj/j4cf9s//sqiXhrkD3pfh/wDlrfST4lrL97jG/WV/wA2fZP/AA2Bf/8APeT8zR/w2BfH/lvJ+Z/xr45/sTSM5+0uP+2Z/wDiqcmiaWh3LdHPvET+mTWf/ENOH/8Anz+D/wAjjXj7nn/QQvvX+Z9h/wDDX9+ePPkA+po/4a/v9vE8n5n/ABr5IWxslOBcxn6wf/WqUW9sOksB+tv/APWrN+GuQ9KH5/5Gy8e8564n8V/8kfWf/DYF/jBnk/M03/hr++/57yfmf8a+TTHDjh7Y/W3/APrCm+Wv961/78f/AFqX/ENcj/58f19wPx8zf/oK/L/5I//R+4v7G7YpP7GGOlew/YIuwWkGnw9MLX+0f+sLP+Lf/iIlQ8f/ALGHcUf2MfSvYfsEOOi4o+wxdcLR/rAw/wCIiVDx/wDsUdAKT+xhj7texfYY/RaT7DEey/5/Gj/WFi/4iJU7HkX9jQ9wf0pf7GgPr+Q/xr1z7BDjotH2GLrhal8QPuJ+IdXzPKYfDq3M0dpahmklYIigDlmOABz3Jr48/wCDlvxnqsGt/s//APBNP4bnzZtLsItUuraI5MupalJ9gswyjq25bhh/11zX7Cfs4+DoPFnx28K6JKivG2oRTSL6pBmZv0SvxZ1ma1/bK/4OqZDr0qPo3gbxHlmkI8qODwlYb+S3yhft0GT7tnrX4V4mcSe0zWjz6xw1KpXa7y+CP4c9j/cT9kBkrxuFzjiistVKFGL7WXPNfPmp/cei/wDBfHxzo/7Gf7Efgb9g74bziKDQtGsPCw8rjzHMKXGpz4H8UwVFY+sp9a/mj/Z+/ZtPi39kvx58XJoN98GQabxyIrBlluSv++CV/wCAGvsn/gvF+0XpX7TP7XgHgzVINU0zS1u55JbeVZYlubu4bKblJBaOCKJSB06V8n+Dv21PGfw9+EGk/Bn4caLaW8Nlam3muLgNO87ylmmYRjaoDs54O7iv5K8TOE+PamRZfR4LpJ4h4ijVqynNU4qFOftZ3b9588oxi1FSbi5aWP8AdTwu/sunUq4jOG1FwnZJXblJcq+5NvW2tj+gT9l//gqv8TP+Cev/AAQQ8Eal8A9HtrzxLrPjbX/Dg1G8G+302UZ1DzXhBBmmeGceUpIX5SWyBtP7f/8ABNT4t/sC+Jf+Cbfhj9qL9oY+CfCvi3x1ZaivirXb+Owsry91P7Rc297cNK4R/MndTIVTC/N8oAwK/BD/AIIKfsyfDb9tTwN4w/YB/a603UbPR9P1zSPilpFk6PatfR28dxpl5GrMFf7NN5kCyNHyQCAQeR9Qf8Fx/wDgkH4i/aJ/a/8Ahx4D/wCCePhjRnuNP8KNZavodhcWllHpMFpc5tbqeNnTykuRcsgcjdI0R+8QTX3fEuAyetmlXKKs3RqSqSqzqrZxaclFtvbW3ZNbXZ8VVjBzcL2e9z4L/wCCYf8AwS0/4KFfs9/tj+AP21tK8BT3Xw98Kao+qvq0NzbO9/oTxTRyXFnCJjcXX2ixlLwqqFpNwCgk16Z/wWw/a3j/AG1v2/NY8P6FMZvA/wADrafw5piH/Vza/cor6xckcjfagR2Q/uskuDya/Xjwv/wUN+K//BK/9kYf8E+Pjh4auLr4ufDL4P654qtNXtJYp9HkttKhvDYIsjMk0kkYijilURbVKH5iuCf4vfEnj5/gd8H7FdTZ9Uvr+2NzeXLFnnuL6/LSyzHgl2nuZCM/3mWv5R+lbxrmWOlSwcoLnq3jCUft0lJ67v4vlo3of3F9BHgzLcXxRiOLc/aWFy2HtG3tzyuqbflG0536SjE9m/Z3+Bf7Y/7Ymt6tafsw+AbrW7LRLqPSLnVpb6103TheLbm5aI3F1NCjSR2gEkiJvZUyxAXk/ntbeCfip+0Dq8l74k1kWOn6dqEkNrHpL+ak5ikMIuFuSRvR2DeU4GCPmA71/QB+2T8SfiT/AME4f+CWfw0/4JbfDrULfwn8Xfibeap4m8d3Ksj6pFbX2nrPMilcvYrdPKdMVyVeSG1k2/JLk/kV8LfiN4P8GXV34fjMcVtFHFFbgdIlhXbGrAAsoK45x15r+fOLMnw+R0IU8BTviLJyfxWW2m6V/vVmj+kPAnxBzjxNzXE4ji/GOGUqco06aagpyu5xU5R5ZSUI8t03ytyTd7Mk8Ha1bfDzSbHw/wCGUEcGnMwEZOdwwB8x6kn5iSe5zXg3xee01K8uNTaaEi9IM1nMqyq5U5VgrBhlc4zj8a5/9ofxB4DvtUbxLomoXGk3jghoY3B81s9AqsMqSSQxxjNeS/C3xcPB2r23xK1u6khgsJQ0exUkuLqYcrBAsquhdv4nZSsa/McnCnwMsyOcKLzKN3N9GtZPe19b3fVJs+r8afHPDYNT4YnCLpU/glGfuxilyq0UlKL5fd5HvtZn3r8H/wBnTRtd074Z/BXVtNs7zXPjr400CzFn9laK4sdAgv41uLkyMqrGt5J8qmNTmKCYlsKRX9vGuf8ABbP4Df8ABS3RfFn/AATe/Y10TXbXx18QdE1nw9o+o6pBFBpcKizuFkuJpY55pkhECMVIjLElRjJ4/m+/4Ig/Ab4yf8FN/wDgoB49+IXxG1ptP1rQfA2oXaa2qiddK1XWov7H0tYbfenyWGmNdm2XcpEgMp5OT99fFH9mX4c/8Gw3xh8D/tS6Rq7fGLxR4sttU0ax0m7iXSUs4FS3a4vRKj3bOwDLCEKAESMc8Yr+sfoycH0nllWeaS58xqydSEItuPOo6LmsouEFGMU3y8yi5NJyaP8AKzxcxkMTnk42alGMVbs/it8r2l/e5rNqzOU/Zq/Yi1T/AIN6f2pPCP7a3/BQjV9OvvDtzBqOi6NB4ZMt/eNqNzb4Mjwyw2+2CO183c4YkMyDHzZH0x/wVe174l/8HAfwX8C+JP8Agmd4avvF3hb4earqS68b4R6bKuo3Fva/Z4447t4vP2W7OS0eQu8AnJr1zV/gD8UP+DoD9nLwp+0Z4q1JPgzo/gnVtW0zTNNjibV1v5HWz868aQtZmMIyGFVCt91jkZxXhP7G/wDwVR/Zt/4Ig6t4k/4Jhan4a1v4h6j4d8V3SX3iTRktokvtQu/IQxpazTh1NuAluRvbLRkjg4r+oXisViK8cxhH2ua0LqUF8EY3ktdk2k+kt3toz81u2+ZazR9w/wDBCb4I/syfBL9kDU/2Of2xV8KN8ULjxLqF5rHhDX3sbi/sxKkENvG1vMZCPMtoUlXZxtkB6mvmD/gl/wD8FifGunf8FL/EX/BPLwtoGmyfBafxD4htPCkVjEtq+gWOmm8udylMJNaOtu7sGG5S+VYqAtfA37Xf/BGX9unWv+Cg0n7Vn7Ttjpdj8O/G3j+31DWdfg1KAwaVpt5qEYRbjzGili8uBkgB27d+AG6Gv39/4Kl/sg/sh/sg/DXx7/wVA+DeiQeHfH8PhPU/DdjDpCrFa6jqHiVI9NtrgQxjb9qi+0MQ0YBcElskZrys2/smpXkq1T6xPGrTl1jTq6Wtr3du6S1upEz5L6u/N+DP4LdH+Cr/ALRGl/GD4o6VEwGny3Oo6cqjhpZLmS5aMAf9OysAPVhX6ef8G2/7WV18GP2l7r4b6hclbG7ePVYUzxhdtteqB0+e3kV/rHmvzK+En7Rnxg/ZRtbj4a6n4ejS0aZpLqx1K3lt7gsyhGBYhWHyqBhlOK80/ZE+Ill8Ef2tfCnxUklFjo0Gpsl3lifJsrsPDIGIA3COOTJ4/hzivSwXDvGGJzzPKedUovAVHTeFcZKT5VTUJxktJRblFTtZq85WbPr+LsPl1XK8N9Sb9slLn0tqpc0Wuj3t30Wh/SL8S4Iv+CVv/By/p3irSiun+EPHmtQXjYG2H+zfFgMF0MDA2W+oM7jsPLWv2U/a9+DkfgD9ojxNpNkiRWt3c/b7dewjuh5pA46K5Zfwr8Y/+DizWfBfxt+B/wCzV+238KtYtNXll0+78OXd7YzJKFuLQQ3VtuZCSrhxcMAeRmv6D/2hvFEHxt+EPwb/AGlYSrnxv4QsbyV16GR4Ibg/iDcEfhX6f4ZZ9Xw+PwGJm7Sq0p0Z/wCKi7xb87KX3n+VH7U3h2WI8MYZ/SVp4SrCTfXlm/ZNfOU4N+iPz5/4RV/7y/r/AIVyHxAnt/h54I1Lx1qUEtza6ZGHlW3Qu3zMEXtgAsQMngV9A/ZF68VjeItO1+70C6svDOoNp11KnyOoVlYjorqwZWQ9DkV/QfEed5lLA1Y5ZOMazT5XJXSfdpb27dWf8+Ph14g5Ws8wz4nc3g+Ze0VOym49k3oru13ule2tj+d34k+PNX+JHjK78W30RgNwQI4VJIjRAFVQT14GT6kmvHP7U1PxJPPo2mB4dOjbZdTAENcMOsSntGD97+9X646p40+JmkanPYajLBDcwuVcGztAQwPP/LGrlh8Tfibp8Qis7u3jTrtFnagc8ngQjrX+UvGH0Wszr4qpmGPxyqVakpSk+R6ybu29V1fy7H/RZ4ZfT44SwuChl+W4GpTpUoRhT1i1GCVlb3uiSV7vvc/KVFktgqxgx7MBccYx0x6YrItHhTXNVsrfhBcCdR6C4RZSPwdmFfr5L8RviBcHN1Hps57mTTbNj+ZgrFPj7xXvaQWOjhmxkjSbLJx0yfI7V+e4X6NmNry5oYhK3eL6/PyP1rEfTX4awtCVCrTm+ez05dHH/t7s2fmh4a8Sa94Q1qDxD4buHtLy3OUkT9QR0ZT3B4Nfq38Gvjr4e+N+gy+F9eC2WsmIrND0WUY/1kJPp1K9V9xzXJD4ieN4v9Tb6Un+7pdkP/aFXLX4tfE+xmW4tWsY2U8EafaD+UIrLNfokYnF07VcTFPvyv8AzO/hP9oZkWU1uajSqOD3T5beq97R+Z7l8OPHQNxdeBvGkSXZ2SWlxFLzHd254dG/2scg9ejDkV8n/Er9iTxNoHiiRfDGuaYmkXv7/TxqF1Hb3HkPghZEfBDJnaSODjI616tqnxs+M15GbddTjtcjk2ttBC3P+0kYYfgaxIdA1LWoI9U1aWS6uZl3PLKxd2PqWYkmvZ8NPoh08HGTzbEe2i1oknG3m3zNt9Ox8/48/tLctxyhHIsHKlNP3pSlHXe6S5Xo9+j/ABPDj+xf8VZBm31jQX+mp2//AMXUDfsT/GFv9XqOhsfbU7f/AOLr3OTwKrHPlj8qzn8FR9Ngr73D/RvyWVWcHBpLbV/5n4tifp6YpUKVRK7ktdY+X9w+gPgT4V+P/guyj0nxy1hqAsirWd3b6hbvMuwjCODINwGOGznsad8UPgT4u1vx7qGv+CbKNbC+dblUNxApiklAaVAPN6JKWAI7YrxKw+Hdjcxhp5Y4T6MjH9QCK2o/hhpip+71GHr0wV/9CxXw+M+ifw3jcS6NeM0rt6N2/L9T9lyf9pJn2AwEauDUJOyXvTp3s/VX09Lnu+o/Dz4ia54Jbw94it7SG6wo8+W9tlTKEEMf3hOSODxUXhfRNU8F2Rs/GHibQjboPkzeh5EPp8iuWHt19K8If4YWrfdnif6NH/V609D+Cd34h1SLStMQtJIeSDEQo7k4c8CvaofQ64U9tCo3O60+J6+p4OM/ah8WQw1SCw9NJ3d3Z8um6tFfqfSvhPxX8NvFV/Lolj9r1m4jT57yBPJtYR2wZSHkJPA+UZ5wO9bn/CK+rj8q9Y8F/BbSvAmgx6JpNrdNt+aSQRoWkc9WOHP4DsK6Z/CcUQJktb0Y9Yh/jX+mXhhlGX8MZXDKctm1TjtFyuo+Svtrq+71P8C/pD/SC4i474hq57mFKMJy3lGCi5+c3q27Kyu9FZHgP/CKL0Dj8qD4TXH3x+Ve4yaLpMf+tiu1+qKP/Zqgax8ODgi4H/fH+NfpC4nm9mz+fZ8VY2PxVUvn/wAA8WHhQf3x+VL/AMIovdx+VezGz8OdR9o/8c/xpjWvh/8AhE/4lKpcR1PMzfGGK/5/L+vkeOf8IonTePyo/wCETjx98flXrj2ulniISD6lapG0jLfLjFaLP6j6nJU45xUf+Xl/T/hjzH/hFIv74/Kj/hFIucyfpXpv2RevFKtpHn5yAPan/bs/5jP/AF9xW3P+R5l/wikPTf8ApTT4VgH8ec+i5r1lbCwP3pGH/AR/8VUi6fpR6zt/3wP/AIuofEM1u2bx4zxb/wCXi++J4+fDMA/iY/8AAaQ+HLcDOX/75r2Uabove5f/AL9j/wCLqUaXoGPmu3H/AGy/+zqXxI11f3P/ACOqPFuLf/Lxf+BQ/wAzxM+HrccAP/3yKT/hH7bsrn/gI/xr3IaR4cPW+cf9sf8A7OpV0Twy3/MSI+sLf0Y0nxRbq/uf+RvHibGPacf/AAZD/M8H/sC3/uP+Qo/sKD/nm/6V78vh7ww3/MXVR7wyf0BrWsfAej6kdtlq8T56fuJ/6RmsZ8Xwiryb+6X+R34bNcxrS5KUot9va0//AJI+aToMWMCN/wBP8KT+woscRN/n8K+1YP2cfEt3bLd2t5asjjI3eYpx7hlBH41xOqfC2XSdwuNW00sv8In5/LFceH8QsHVlyU6qb+Z7+ZZRxPg6SrYrDSjF7NtWfo76ny+dDT/nk35j/Cg6GP8Ank35/wD1q9cexCOUypwcZHQ/Sm/ZF9q9tZ9Lufn78QKydn+bPIzoTfwxn/P4Uz+wJCOIz+Vev/ZF9qPsi+1Us/kNeIlY8g/4R+b/AJ5n8qX+wJ/+eZ/KvXvsi+1H2Rfaj/WCQ/8AiItbY8h/4R+XGBGfyo/4R+XH+rP5V699kX2pPsin0o/1hkH/ABESueRDw9N/cP5Uv/CPz/3T+Veu/ZF68Un2Vfah8QSH/wARErn/0v0Z/tg+tH9sH1ruCIz95F/If4U3ZD3jX8hX97rxep/8+v8Ayb/gH/IJ/wAQTn/M/wDwF/5nE/2zQNZPc123lwHjy1/If4Uq20LsAsKE/wC6P8Kf/EXqXWn/AOTL/In/AIgnUvZP/wAlf+Zw/wDbODyf1o/tnvmvRotESX76W8Y/22Qf/Xom0awhHL2zn0VSf/ZcVn/xGTD3tyfidb8A8Uo870Xmrfmzzn+2R6/rSf20AMlq9Eg0A3uVsrZJ2AztQAtj6YyfyrNl0+1XKNbICMjBUdfyrWPi/Qeip/ijjreCNeEVOWiez5XZn1p4i+L/AOz/AP8ABLD9l6P9tb9p15LnXtVTyvD+jQEfaZ5p4y0cEKkgeZJH88sjfLFH156/59Wn/wDDRX7a37VvibVPgZo+qaj4v+JOrajfPp2kNI0pj1G4eeWF3Tbm3QOA7PhNq5bAr+qL/g6A+FXxG+N37PnwW/a4+Hay6h4H8M213purwQZZdOub023lTSKPuqXgaBmIwrbAfvDN/wD4NJfir+zZpOgfFH4Zahb29j8TzKmrvf3AUPcaDFHHGY4pDyiWtzueZRjPmIxzj5fmso4kqYbI8TxVKLrV5vlcb6QSk0o26KN+Z9Xf5n/Vh9HXww4e4N4NwmW8NQXseSMnJb1JSSvUk+rlo79FaKtFJL8oPFH/AASf/Ze/4J76fpGu/wDBWn4kXOl6/q1oNRsvAXgyD7Zqlxb72jzLeuv2SBfMQqSMrkHD8V/Xl+wx+wx/wT61D9iDSv2gP2EPAOk6JrfjHww97oet61BHquoWd/LA4iM0l0Z0EltdDbIqbUyhGMV+VH/BRvVv+CdP/Bc79uf4U/smfB/4mGx8UeH11ZLrX7OyNzY3lqI0nawtp3kiSa5DQtJGy7ogvmcliFPz5/wWy/Zc/ab/AOCW/wCyr8K/g/8AsX/EPxbF8ILmW80nVLKO5xcnV7qRrpXaa2iimEF2plCwq2xWQ8EvXzOaYrF53DB4HF4mdHFVW5OEk401Bc1kopK97K3M23qm1ofs05SqcsW7N/ceDf8ABKHx3/wVq+Mv/BUrwj+0T8ZtH8V+LbLTjqHhPW9Wns/JsdNsbsPFN5Z8uG1EdpeJHN5aA5MfQk16x/wSy8D/ALRH7Cv7fHxx/bu/bq8ZRaH4J8F32q+EfFmua5LI9zr2ozvHcWsdjGoZ7h/lgnUKMCNwiDnA/QT/AIJ9/wDBXzQ/2B/+CYHgSy/4KQaJ4o8O67ZT3ekeHEn0u5a41zTrQRywzRPIqp+5jnWFjK652BsnOaf+2V4M8P8A/BxZ/wAEzLT4vfsSxHR/FHhPxVc38ugai8UEl1dwQG1eG4aN2iW4ls3hlgkZiuMIWHJDzPN8RLGVqOMw0aOEqWoOpFe6kpSd09tbtXtaLtfVDnN8zUlaL0ueCfFf/gq1+wD/AMFOv2sdK+GXgT4M+IvFF9q2g6r4NvfGE9wNOGkeGdZiaDVr4wKZw0VrbyvKGuEUKfQtX5h23/BGTw98Gv2NvAH/AAUq+I+pXnjDSdHlk1d9Oa4lhuXhiS4bw/b3UZia3+zvfxWUd0IyjYdtrkkY8C+DXjb9m/8AZV+GXjb9if8Abw+GPjT4R+LvGGkp4c1rxfoju11JZRapBqStLp9z5fysbdYJHtZSssHGwnmvSf2+P+Fs/Bn9jPwZpX7NPxzs/if8F/ihqh8CWIs5ry3ubZpLVTIup2UpeNJ4raFW2+YH835wqhuPzDxg4RwmClCvCjKNClH3Kkm5prVuzTaSe6StfVtX29bK6maOqsryuUrV3GDinpNt2inrbeTS7Xfdn893jb9pWf4gLL8evipq83iXxn41v31PxLqtwS87XM0kgSNeyQ20aqEjXAUHCgBVA+ZviV490DVbwrrdm0hwfsmpafKFLxnoGB7r0Kk8HpjNXv2gfCeu/BXXh8Nm1K7u/DlxI87WRlZIvNRyGKr8ygjKsDgnnnNeM6f8OtU8Y3KwfDRZdYLpLK1qiH7TCkEbSyM8YzlEjRmMi5UKCTg8V/N+TZHg8VbMcNNz57u70er6em1u2lj9x8SPEriLJHPgzM8NTovDKEHCKi43jFXbvzJud+fmTUuZuSlq0ez/AAK/Zo+Nvx08aWejeDdGu/sNzKPP1a+jaKytLcHMlzdXD4iihhTLMxfoMDJOK+8f2k/2OfDnwA/Zf+An7Rk2oT6hqPxTsfFmpqlwQmzT9O1W3sdLaK3GBEs9vvnYjOfMPpk/LnhnwF8Yf2ePE+m/8NSeGtaj0WObSdRs9M1OO5+y6jbrfWkrrChZYbiGezEgypKlTwa/qm+GP/BST9jn/grD+1L4P+HP7T3wktfAvwm+D1zrOtaff29000qac8cNhp2mpHDBGLS0SVoppII2kj8yOMLgA0sLk2Z4jFVfayi4WUYpRtbTmbcm25cytGyUVGz+K+n4280hg44XE817+/ZO+03GzXRrlctb3TWx8/f8Ewf27/id/wAE1/2UviZ+078BfDuneItc8YeK/DHhQrfpM8SQWmi32pzviBkfeJrxF5OOfpXovxf/AODgT9qX4+39nqfxp+A3w58VXGmo8dpJq+hXV60CSEM6xmadtgYqCcdcD0r9Ofgd8Lv2OPGPw48S/Ab9kz4g+F7HTfD3xC1vUwLm/t4bjU4datdOvLOdwzQmSayjkexZQq+X5O3bnJPbeLv2QZvAV1DZ+L/F2mae1xGJYTKWCSxno8bfddT6qSK/EOPfp1UvC3Ef2NjeGpV4UuVLEuVWEZuUU2k40ZR0u42U27p3S2P3fKOB8r4yxFXOp4xU61ac5OmkpSiuZ2XxJ7W1sfmf8K/+Dnf9r34KaLZ/DPwX8IfAmi6TbMxg0vTLK70+NWmcu3lxRzFQ0jsScJyTnmvOfDf/AAV6/wCCffij41Wvxq/aK/ZG02PxXa62muTavoOr3CTtfxzi4M0ttOIoZWM43Mrtgnr6V4/+0l8P7Lwp/wAFYfg9ovhrW7LUpJ9S8NXEl7AwWGLZqWSZGb5VEUce5ieAvJ4rt/2ybj/gkn4Y/a8+IXxWk1fX/jz4h8UeJ9S1a30HwsqaT4ega7u5JY7WTUWE1xdqoYKxtYwG5CsOtf6jeCvFOR8XcMZdxNhsBOk8dQVVqnKpdXdnFy9xW3s58t+x+HcU5BSy3Mq2Ai+bkbV7Wvbyvp95+5P7f/7cHw6/4Lmf8E8PEfwW/YF1sReMtGmg8Ra74P1lGtNWvtL00PNJFZrlobkrN5ch2OwOwLkMwB/OH4u/Cz/gp1L/AMENv2f/AAf4O0bxR4t8/X7jxs13ZRSXFzoml2gUaHbELuuCpaRruMlSIxsUEbVA9o/4IN/8Epv2gfC37Vif8FI/j34fPwp8BeHYtU1DStJvGeKaVL2CeIJ5cx86OwtbeZj5k+Gk2rgEZYfsn+y5/wAHF37BPx78ZD4E+A9I1/S9eEtxYeHdMTTzLHqgtg4torM2plEZuI4x5ayiMKCAcYODG4mWVVPqPD9BYijQkqstnyycZJxclvayd1tazbSPlJPkfLTV0tTzP/gix8KviP8A8FAf2G9W8Y/8FS9JsviQ15rU+naGviPS7Yahb2Niqwys06wxXG57rzFDEhx5fXmvwW/as/ZH/wCCJXxQ/a08YfsrfA7xnrXwV8caHrb6FaPqML6p4Z1C+DJH5UUyu9za4uGaImR8Bl+UEVwn7F/xN/4Ky/Ff/gr7B4Mtte8WfDXW/iD4ouNa8RaZdJKlra6akhnu82d2jW5WG1XyY2CctsAOSK/SX9tv/glr+wd/wSa/ao+Gn/BQf4leOtbvvCc3jZLu68N3dumoX9xe7ZrxbiOdWiaSCC5RZZw6FtvALMwB9ilR/svOakZYpxlWhz0qdHWKevu2s4O9rJ2s9W7aGi9yb97fZI/m5/bu/wCCZH7af/BOm+/4Rr4+aNMPDF7c5s9Y06R7jR7uZQVVg4AWOfYThJVWTBOBiv6iP+CJH7f37Pn7bv7NvhP/AIJofGZH8OfEPwPprW/hrUGcNHqUFuGb91nbieKEASQN99F3oeDt/ZD9sr9u3/gn18av+CV/xD/aG1jWNO8dfDa+0yfTPJiw0k2pzoEtrQRuBJBeieSNlDBXj4k4AzX8En/BEj9nr4v/AB9/4KR/C5vhZFMkfg7WrPxHrOoJkR2en2EqyTtI/AH2gDyFB++ZMdM16+WcQYjPsjr4rM4vD1sK21NXj76i+j+6UXvfTy+d4u4UyziTJ6+T55QjVoVE4zjJaNfo1umtU0mmmkz+ubxn4Ut/APirUPB/iSPUY7vTZ3gl2woVJQ/eU+ZyrDBB9DXJnU/A6f62bUAf+ucX/wAcr6i/aT+Ld54w+NfiDVfCt/INN+0CGHy3+RhCixF19nZCQe+c181arLNrgA1eR7gDn52Jr08q8U5ToQliYtSaV7Nb210sf8qHiF4QZNgM2xeEyaSqU6dScYOUdHFSai+ZTd7pLW2vY8O+J/gT4beLmXWtPa/F8gCv8kQEijp/y0PzL/KvM4/hj4d8tflvcYHaP/4qvqP+wdH7wj/vo1ING0wDAiGPqf8AGscy4wwGIfM1O/y/zNOHq2b5fRVClGnyrbR/cfNh+GuhYyUusY/2P8awW+GnhwdYb0/jHX1t/Zmn42+UPzNQnRdKP/LEfmf8a+ew+ZZfTvpLXzX+Z9fU4yzx2uqb/wC3T5KPw18MZ5gvD/wKP/Coz8OvDI6Wt4f+BJ/8TX1x/YelHnyv1NMOg6SeDF+p/wAa6f7Zy7+99/8AwRLjLPP5aX/gP/APlS58CeGhL89pdE8fxrjp/umu907RvBVrp0MD2N1lFAP71f8A4ivbH8PaU5y0f6mmf8I5pOMeV+pq6GfZfBJJS+//AIJxY3P83rq1T2ff4I//ACJ5PHpHhCQEw2M4A9Zgf/ZBWNJpXhAHjTZz9Zx/8br3JfD+mxjCxj9arnwvpR/5Zj8z/jShneXqTk1LXzf+ZnHOM2UUk6f/AIBH/wCQPIbbSvDBiwmnyAZ6GbP/ALIKgubHw1EwB0xnP/Xcj/2WvaY/DunxrtEYxUM3hnTpWDNEPzP+IqKWcZfGpz2f3v8AzLqZvms48spQ/wDAI2/9IPEUs/D00ixRaRlm4AMzf/EivYvDK+EfDVmVj0iN5nwZHMr847fQVp2nhrSbY7/JG498nj9avHSNOIwYh+Zr0aPFWAhK6jL73/8AJHzmcwzXFQ9lzQ5f8ENf/JCx/wAJ3oC/6rRLYfWWb/44Kmj+JdvDzb6ZbJ/wOf8A+O1mf2Do+MeQPzP+NH9haPjHkD8z/jX0T8R8A94Sfz/+2PhIcEZlHWE6a9IQX5QOysfjv4l0ti2nRW0eRjkSSfo8jCq1/wDHPxdqQIuDaYP/AE7RH+ak1y/9h6P3gH5n/Gk/sLR+9uv5n/GudceZTzc3sHf0X+Z6c8l4jdL2CxjUeyk0vuSRi3XiKS8uGuZSoZzk7QFH4BQAKrjWfU10f9haPjHkD8z/AI0v9h6P/wA8B+Z/xr0l4q4RKyhL8P8AM+Qn4SV5ycpzTb9f8jm/7ZHr+tH9s9810n9h6P3gX8z/AI0n9h6Qf+XdfzP+NH/EV8L/ACS/D/Mj/iENX+aP4/5HOf2yPX9aBrPqa6GTRdLCZjtlJ9MkVlyabtP7vTo2/wC2pFbUvFDDT2g/m4r85GdTwmqR3kvub/Qpf2yPX9aP7Z75qR7O6H3dIjP/AG2qu1rqQ+7o8f8A38rrh4h0H0/8mh/8kc78L5Lr/wCSy/yJP7ZHr+tA1n1NUzb6wBxo0f8A33/9cVC0Wt440aP/AL6P/wAVW648pPov/Aof/JGT8NZf1GX+Rpf2yPX9aP7Z75rIZNe7aPH+Z/8Aiqib/hIO2kIPwb/4qtY8a0vL/wACj/mQ/Dhr/wDZl/kbn9sj1/Wtew8da7pkYi06+ngUdFjkZR+QOK4c/wDCQnrpKj/gLf8AxVRN/wAJD20of98N/wDFVUuLaM1aVmv8Uf8AM0w/A1ahLnoycX3Skn+B6ovxX8bp93WLsf8AbVv8ajf4o+LZP9ZqEr/7xB/mK8sY+Iv+gYB/2zb/AOKqItr/AP0D8f8AbNqmOeYTflj98T0J5RmlrfWKlvWf+Z6k3xH8Qt966z9UQ/8AstRH4g60w+eZT/2zj/8AiK8rY6/3sSP+2Zqu1v4gncKlnJk9AqGumGd4Try/ejknkGYvT2k385f5nrJ8e6sfvSRn/tlH/wDEUw+OdTPV4/8Av1H/APEV5/F4T8dXC7o9LuAP9qMr/PFTnwV4+27l0qdgP7q7v5ZpPibL1o5w+9f5nZHgDPZq8adV/KZ3B8bagf4o/wDv1H/8TTP+E0vsZLR/9+o//ia8turLxHZP5N5ZTxMOzxsD+RFRxWuvXJxb2krY9EJro/t7CWvzR/A858I5jzcj579veueq/wDCZXvcx/8AfqP/AOJpP+ExvOuY/wDv3H/8RXmb6V4oAybGYf8AbM1Vkg1yHiW1lX6of8KUeIcI9pR+9f5lVOCczjrKM1/4EeqnxfdnvH/37T/4mmf8Jbd+sf8A37T/AOJryYyamODA/wD3yf8ACjztR/54P/3yf8Kv+3sN/MvwMP8AVDHdpfif/9P9qpfhT4z0bS1v5tOe7mbO6PBPljtwuCxP1wK8/vYdZtX23dkYD6GIr/OvqGL49/FaPlp7RvrEf/iqtr8bfifqR2Pb2Vzn1gLf1NfzzT+k3wtU0VWpf/B/lI/nrE/Q6z6KSp4ekkv7/wD9qj5Pt9RETYurSOUe+5f1DD+VdJpUHh/xFexaXHFJYTTHajhvMTd2BBAYZ+tfRFz478YEB9V0zR493/PSBQfyzmqsfjrUoXEsVtosbjutuQfzBqMR9Ijh5P8AizXrBr9TTBfRJzxNKdCm111j+e55XJ8IPEStthuIXHrkj9MVetfgvrrnddXcUajk4Bb+gr1NPiX4iB/1mmJ7iBj/AFpLj4yeMLWQR2c9q64+9HbhOfxzXnVfpGcOxXNKrP5RX5cx9DS+iPjL+7hIfOen4RZ4VbeHb5tQUeF7G71B4mBWXy2RSQeoVRux+Ir0CfwB8afEdy17NoSq8nVmhRc/iwrsB8aPG7Dab94h6RRxj+YqvN8S/El0pM2s3w9kEa/qBXFP6SHDNrqVV/KMfzkwpfRKz+KcFGjGLd7Jt/8Atq/M+hf2e/gzr/jPwt4u/Z5+OOmQ3vgvxnpVxa3do/lld0q+W5CqOC0bHkdGVSMEV/B9/wAEqJfEn7Kv/BbHwJ8NbGcytYeNb7wXe5+7cW00lzp0odejK3EmDxkA9q/vR/Y11TU/EHxkd7m5ubhLawnkJnlLDJaNB8vCj71fxK/8E6dEtvjt/wAHD9l4ggI+xQ/ELxN4iZ+Nqw2D6hdI5PQDcic+9f3h9E/jzD55w3muJoKSocktJO+qjLXZb7fL7v13hbgrF8PYR5XjJqTirq2yT6bvzP1P/Y4/4IMWPjj/AIKG+Pf2iPgx8Vrbw74P+FXxHvIdLttKhM2pwXljMlw1nKshSKCKFpDASQ/mxjIXa2a+DPj5/wAFAf8AgrF8JP8Agrba+GfjfqGp+Nrz4a+KQ0XhXSrQx6bfae5ZUeC0jV9zXFjNuhlkMjo5BDZFfrX+z/8As+f8FTv2SPh9+1L/AMFG/hJJpjS/Eu71DxNovhG8V7qWa3F9LcR6ltjYKlwNOdzHFnMg2hsYUHU/4N9f2jP2zvih48+Jf7RX7cWgtJ4c8TWkN9Z+PNXtbewMUtriNrKGVkid7RoW3KFyqMhycvX7XUzuso4rMcVKliqdOEaaTaU1JpcyTtd7yvZ+9bTqe77R6zdmloYv/BeD/goP/wAE1P2qfhCv7FfizXL+z8fWes2E1vff2dKU8O3hdEnN8XCEIttNIs8aEuOuCVFeg+CP+CXf7U3/AAR+/YJ+Jnxj/YA+KUnjLxrqtlZ6tc2c2mRSafPaWQd5ZbCDzZGN4LeVmR2ZldF2eWSVI+WP+Co3xH/4N6PG/wC1jf8A7SHxb17U/HviiW0htdQ0Pwg+6yvLi2yqz3FwqiPzDFtjbEq5CAk56+G+O/8Ag6n8TeA/A2nfCb9jb4T2fh7QdCs4tP02TXryS7kitoEEcSmJC27aigfNMTxXNluQZpUyvC4LJaE/Z3UqkayioN6Oyckna66Lz3FGnPkUYLTrcvfsd/F3/gqF+2tp0/w2/wCCgHwCvPjt8MddlZ31TVbGDR9R0gTdZ9Pv2jt40WP7wTKnjAfHB/Lb/gp98FI/2e/hp8Iv2bv2Wtcj1zwj4f8AiV48v7i6TYx1LWdFGmPaR3EqZDTW2k3H2dSDt3+aQPm4534p/wDBUf8A4K0f8FDdVf4d2/irV7q3vyUOkeGYTZQlW4Ku0P74pjrulxjrU/x38BXn7HHwa+A/7GvxqvbdPiXqfjLWPiJPpVu/nvpui6lokdhbLcSrlBPeTWbyCNWJ2BSetfB+PeY4TA5Pi8BPEUaeJcPafVqcrvljdc8oNqy1SuoxTb1bdrfq3g/kDxPFeU0sQnGnUxNGF43VuapFXT2ur3XpqfjX+2nozeO9Zi8Xacuy2jfYqvxI0k2wBce2w5r6I/4JcfAXQvi78Tbr4UDxEPDesay13ZeCNTWURpF40tYFawF66Dzkt7tDPFbpkxvLhHVg1cz8U73TfiB8VAowmjaM0uo3b7dqrHaxl+frtxz1LV4n8dPAWkfsaeHPhtd2yX1x4p+IngDT/F1wTcNbLp17fahfyWE8flASs8NnBbzR5ZcSPuJIAFfyP4TYrERwkIJ8vIk7PtJvT10b+Z/RX07Mty2HE+IzKK53iJSjzJr4qUIpyS/lbnGLX9x2d7n9Cvwp/wCCvOgfsw+D/HX7B37SPhvRvGGhLfuE8IeIYGzoNz5QS8ttJk+zXdpLbXdwGuIEEkIjMm1FRflH5mftIftJ/C/4UeAbL4O69o8+l+FLC9udV8PeBIWjttdtoNSWOSe01vVbU7o9Me4QTR2bCW6XgCWNcY6bwV8ErDxl+wZpv/BWX4MXR8XfETwNcano/i7TJokH9j3UsEg07UUjAdpzEsgullkLF3EmcGLFfkJ8BfhvN8ZPGMfibxtfRXF9retW+k2T6pMUhutVvvMdXup2JIhQqDIxPLOgJAJYfSceV8wrVvq6fs8K7O8HapUlJuPJGW9NLTmkmm73i4KLb/iHIaVCMef4qmukvhikr8zX2m+i1Wmqd7H63fsYfEf9vH9tHxTa/C34EfDz4e6bocMW/bfeG7J9O0+xU4e5uri5WR4rePnMrvvkbhd7nB/qO/Zi/Zi8R/BDXbXwx8UvjP4C134XyLMdW8KaNZX8cMk7IdkulRXUzRaNOshBMltIsLrnfbsTx9A/sy/sUfBnVf2UvBvhH9l2e/tfCuuWEOo6lKYUW/1DVYsw3Y1UgjZNYXSSWy2oxHblCqrkljMn7HH7PUlze6fH8UtDN1pl4+nXkH9p2Ikt7xHRDbyAzfLNvkVdvqcV/lj4i+KGYUs3x+TcB5BN+wc6Vaaw1WopSej0TUZpbp1FPn0nypWS/qPhbJMqnhKGNzzM+SUrSglKMWkttbXi/KNrfDdu7P5R/wDgr54C0b4fftXQQeFNTGq6ZeaHaywXCEcYknR4yVJBK456Zz0r9of2dvgh8Wv2Lv2FPA/xy/4JxfBO3+LnxJ8baHDq+q/ESVYNUXQprhSzWGn6cC8kc9l9x5GC5kBJ3j5F+iP20v8AgjZ4U+L/AIT/ALAutan0XxRpodtNubqJfKJP3o5Np3NC5A5XJB5Ge/8APNHYf8FRP+CT/iiW88CaxrfhWw84t9p0yX7VpFyR/EyESW5LDruQP64r/Uj6AP0r+E+L+BMt4AlmEKWbYCKpVMPiE6Mq3JdRaj7jkmrOUYp8sk1KFrN/E+LvCOKWY1cxw/7yjUfMpLVa7p221+TP6N/+CWV//wAFav8Agpr4E+Lv7Mn7bPjHV/Dfw+Gjto95qNxpUNprZvb1gfIt5fLhXyhArifdGx2OEUqW3D5f+A3wm/YC/wCDfz/gqOIf2lfHt143v08P+ZpFxaaWQNDkv3aNpL5ElmPnyWqkR+WDhHZmC5XPinwD/wCDrD9uD4e+Rp/xt8NaF44tY8CSVFfTrpgO5ZPNjLY/2FrT+I/7W/8AwQi/4KUfFOb4sftUeHvF3wm8ca1cwz6nqdtM15ZXRjCIVk2+eUQxoEBCxhV6Cv70lkGcUMViaeNwzp4OrGzjh1F62Svspa63svLa5+J+ymm1JWi+x7d/wcAf8FRvjnr/AMVfhb4o/Ywvtb8OeDNI0sa5Y+MbCGW2j1SfUlGI45mQCW1ghXDxtlGkdtykoK+l/jz/AMEp/wBuX/grF+wB8K/2kf2pPina6R8QtC0O71CLStQsltNO+xXjefHLdSRMPIvnto4jLJ5ewDC7VwxP65/ti/HH4e/Gz/gl94r0b/gm3peh/Fq7j0eLR9F0jTfs16ljC6CDzltnLEvZW+WjQLu3heOtfiJ/wTu8Xf8ABYr/AIKa/sW/Gv8AZD8ea/DoFjpOnxaDb6/rdnJbai127IZ9MZowgKPZqySy7N0YkXruyPksnzGpDKqNfAwp4Z4apyylOzqcstG2uW+vM7rrb3djKnNqCcbKz67n5u/8FO9E8IfAD/gj3+yN8AvhDqkeqaJ4vfWPGGsX1sGSK/1RVgjL4bBdYGu5IkJHKxqRX6/f8EdvhlpH7L3/AARws/jDoCLD4n+Net3LXt8oxMun2ks9tDAH6hAls7YHeZj1r8uv+CsX7PXxO+EX/BIX9mjwZ8XtOGm+KvhH4k8Q+C9WgR1kVDclru2YOhKsktrbxSIe6uDX7g/8E17weOP+CFnwXuNOWGV9F1DUbGUSnhSl/qK+3JBU/jWPi5xDUwfBEsVQlz/v58zuveXPUabe1mlF9tEfI+JGW1cdw/icFRm4uopRutXZ3va2u3Y5dtVt0HHb0/8A1VF/bUHo36V6TqHhi9kBWWO1x6Jj/GspPCcwHNtG49if8a/jPDeNHNG9R2flK/8Akf5i4z6KVKE7Uo3XnFr/ADOL/tq39G/SlGtWx7NXYX3g+3SCOWNNkjEho+uBxg57Z9Ky/wDhFSB92up+MUf5vxOCX0W4p25F9z/yMP8Atm29Gp66tC33Q/5Vt/8ACKuf4KsReGb1MLCGH0yKP+Iwr+Z/eJfRdhfWC+4wRfqx+VJPyqRbskfLHIf+AmuyHgjxSYDdRxTtGOrLuIH1xWSdE1HlWkk9/maqfjA1vJ/eW/ot0esPwMUXDnnypP8Avk/4UG5K9Y5P++T/AIVsHQL5udz/AJn/AOvSf2Bedmb8zUf8RgX8z+8f/ErtL+T+vuMN9QgT7wcfVaj/ALWs8feP5f8A1q9R0PwlrBh+1zXaRR4yElIct/wFuOffFLq2l2l037vSIlPdgevvhTitP+IvWV3J/ebf8Sq03Hm5fw/yueXLqlkTguR+B/wqyL/TT1uAP+At/wDE10beHOebGP6fN/jWhb6fbwqN2lwPjud+f51xYnxo5FeMm/mv1NMJ9FOjKVppLztJ/kjjRfaaTgXA/EN/8TWnFZm6iMthIlxgZIjYFv8Avnr+ldtEluvTSLce+0n+tX4xJERLaQQ27DoUjAYfickV87ifpCyp6Si//Ak/yPq8F9DbB1VdzXyjJfmeQjULXoXx+FXNPZNSvEsrZhvkOBngepyfYV6LB4XubzLW1sZfdUzVn/hENXtWEos5EZeQdhBFcy+kTVlrGk/v/wCAbQ+hZhk05VFb/D/wTzy4/siDIS/SRh2Ctj88YrKF9bEfe/z+VenSaRPGT58IB90Gf6VPpOl2ltqcF3qFoLq3Rw0kOdm9e67hyM1MvpGTi/fjb1l/wDT/AIkrws5WhP7ov/NnnWnSrdTCK2i+0OxwFGT/ACrpJoL+ykEMmnRbj2wzH/0OvpHxJo3g/wCIH2WHwLNDoJjjEbWE/wC7V3yfmEoyHJzj5j2qSP8AZL+I0UAvNQ+x2UR+68syKD6Ec17FHxsxmJb+p0nVS3cXdfOy0+djtq/QvwmGVp1N+tkvz1Pm66j1SziFxeaMscZ/iMcgH55rZ0zw9q+q2ovo9C/cN0kLPGh98sccV9L6d8EPitoyhdF8QW23+4t4hU/8BYlf0rd1v4WfGHxNFFH4u0u11xYF2RukyJIq+gKPt/NTXbT8WcylDmWFqfJNr70n+R00vohZVF/vK69HGH5u/wCR8l+I/D2j6faYtiv2n0jmV0H1zg1x8Wh6lOm+BVf2DLn8s5r6X1f9n7xLEpeDw1qEP+6yyr+BCg1w8vwk1uzb/iY6Rfxgf9Mef5CvNr+N2PoO1ShNeqkvzic2J+h1llepzxnFLsuX+vwPL7Dwrqt7JKsym2SFd7PIOAPy5qj5OkCTy4ZZJz6hQg/U5/Svp3wnr138NtLvLHRdInupL3YGN8mY0C5+7GMjJzyciuQu9V03UZWk1rw1aEt1MAkgP6Er+lZT8f0krys+q10+djf/AIkqy5U48slzdbr7utvwPFX0e7kP+jRED3dSf6VYufDuu2NoNQu9PmW3P/LXadh/4FjFeopB8PEl8yXQrg452/aeP/Rea1n1uy1Pb4dhmu9E0aQ4MELeZGm7qSuFZgTyck1nLx0jWjyyqfc5L73pp8x4b6HWDoNzTTf+GMl90lb7jwJJYB/yyz+f+IroLPToJgkl1GkKPz8zbSR9Mk16LrvgjQPD2obDPcX1qcGOeFUCSA88Hcce4PIqwNQ8G2Ni0ej6M/2w4xc3LiYjHomAv55xXBV8UrtxnVcX/ik/8z28B9GmlRf7yEHb/p3BfkjjbzwVfyzj+xbWW4jIB3Bcjn3qIeBPE+3edPlCHgMEJGfwrq7eSTWMxahLf3Nw+FijXAi3E4GVXt7AVp6nofxFtrmTwhbrcSQ2rFfKtg/l5PJPHUnPOa5H4g4ietGUpryb39P+HPol4E5PFOdWko/KNvyMG28K6LpentJr88UFw33VYGRwPeNeR/wLFctdixVyLOYuB0Pkqn/sxNeraR8A/idrBBTTjbqf47hhGPrgncfyr0q0/Zx8N+Hbf+0fiR4gSJByY4CEH03vlj+C19HltfiDFLn5OSPebaX4v9Dx8x4I4eo2o0oc0u0Vd/hofOOiaDp2uXaWMuqLaySkKvmxtgk9Blciu51X4Qr4bn2anr9vBLj7qhy+D7AZr1S08U/BfwfeL/whGhyahMh4u7knYD6jfyf+ArWpffGe8mkM9lDaQSMOWEBduP8AaOM4r5zO/FTKMrTp4vHRnPtTTlb1d0vxPtcg8A6mNpqcMuceznLl/Ba/gfPT+CvDR5kvr26b1itGOfxZhWDf+D0iUtpKXjMOgltyv6qzV9AXPxg8dk5tr4L7LEq/0pLD4vePXvI1v9SdISfnYIhIH5V8K/pJ5Ip8nPU/8Ahb/wBOn10volYyrG8cPTXpKpf/ANJZ89TW/jnSMWlzHcBcAhJVLpgjI4cMMYNZzXmoxxSQyWyKshywCMuSPocCvsG++LHihW/4lt7bzoOhl27vxBVcVzk3xW8bSH98thJ/vRxkfzrvqfSGyOLt7Wp/4BF/iqhzVPonZulpFNf45frA+Sl3B8iM/QMwr0nw34V/4SpWgtku7B1Ut5zt5kPHODkKRn8a9lj+KGuxt5kunaU5HfyUB/Q1oP8AGnUBGYrrSbCRSMELkAg+wNd+G+kFkUtZ4mS9ab/Rs8+j9F3HUJfvMOpLspr82k18j5U1XTLG0ujBJqK3WwkFolZh+ZwKzfsulf8APxJ/37/+zr6W/wCE18EStvn8I2RP+y7D9MYp/wDwmXgH/oT7X/vt/wDCu+Pj5kTV1jkv+3Kn/wAieJW+jFjpSbeC/wDJ4/8AyR//1P3V0+SPT5DIsSS57SDdj6dK0rjXdUnXy1k8pfSMBR+nNZFFf4gU82xMIezhNpeWh/dcsuoSfNKCbIHt45GLyZZj3JJP9aT7LD6VYorjeIn3N/q1PsQfZofSmPDbxjkVcCOegJp3kzHoh/KrjVnfVsmWHhbRIyS1qONpo3wkfKtaptpO8Z/Ko2tv7yfpW/t11TOOeEm9mvuPsT9ii5/s/X/FWsW6/vrXSGdB15Dbv5qK/hY/4Iiabqnj79t74g6BoshTxN4g+HXji20YhsSHU7qycR7D134Zz69a/t9/ZJ8W6d4R+LcVlqhVLbWYHsXLdNzkMmfYsu38a/gP+Pvhb48/8EfP+CoGqXfhEPYa14E8Qy6poc0ysIb7S7h3eDOMb4bm0kMUgHQ7hwRX+3X7N/McPmHBmPyjDySraqz73k9fL3o/j2P538RMBUpZnPn+1FNfLT8z+p79h3/gpj4t/wCCcf8AwQz8F/Fr9suP+19ZvprvS/AOimQi/wBQ0+E7LdLneD5cVuVkBc52wCMYLEA/yRftjf8ABSP9sb/goJ4uFv8AFHXLgaO7+Vp3hfRw0Gm26Z+SKO2j/wBcVHAaTcfQAcV9Ff8ABQ79sTxD/wAFff2n/hj4U/Z+8KXGjxw6PaaBpPhmPaY4tVu55Zr0w7PlMcjsmHwDsQZAxiviD4j+GfjT/wAE0P2wtD1XdHPqXhma31SwmKH7PdxkbZVwwzjPmRN3BGeDiv7ow2TxyfCYnNaOFjPMaiqVIU5S5Upa8kOa0uRN2UpqLeraTSsfEYONCNaKrO3M9etlfXTy9dT7C/Zs/wCCLf7Xnx1t7fXfFFlD4H0WYBln1bKzsp7pbKDLz2LBR71+tPw4/wCCBHwq8ICO78WeIT4gulwSJo2ihz/uIckfVq+tvhJ+2R8dfjj8OdK+Kvw70iPUNI1mETQyxW7sAejoSGPzxuCrDsRXY+Mf2pfif8I/CzfED9oDUNG8AeHUbYL7W1eHznxny7aHcZ7qXH8ESM3T1r/l88X/AKeP0muP89rcPZViIYKSlKDw2FVpxcW1JTm+areNrSfNGOnwo/t3KvDbh7JsKswxMoSjZPnm01rtZba9NGyfwB/wTffQDF4Z+H+rWWkRSAgi3hMCKigszyMCvyooLMzHgDNfzCf8FB/if+z9+0z+2/49+Knw38RLrmheF9L8LeGtF1u1LL9pvdC02OK6uLYsA3kGfKhvuuPm5Br7w/bk/wCC8vii/wDgh4v+Fv7LGhiyj1zRdQ0y58VeIFa1u57e7t3gmGl6ZGzTRGSKRgk9wylc5KCv1Lk/4II/8E4f+Chv7Lfgz9qL9kLxVL4Anbw3YpqR0/a1v9osrSOK4F5aPkw3cbxMJh8rbwSa/qj6J30aeL8lyfG4zjTFr+0sVKN/eUuWnFqSUpJXc5SvdtyVkle9z4zDfSNyrAcU4PMauG9vhcOp2jZRvOcJQ5rO14xTulo769EfxS/H3x1qmr/DPU/tt5b2dtfywWiOsaQm7nMiMVkcAFo0QF5D06Z615p/wVL/AGhvEH7TX7VCfEbWfD0Pha0h8MeHNN0vTra5S7gTTrPSrWK2kimjVUZLhB52FA2lyvUVb/4KEfAe6+Gv7UUn7NXwu8RXvxF/4Ruyt0doLUKYbq4Xz5oVjgMgZow6B267sqfu18lfGC+1S90fwpZeJIpLbVtF019Iu4J1KSr9luJnh3qwDDEEyIM9kx2r+xcj4fxmTOGD0cJSkpWW0kvdafVWi09N5KzstfzD6QfjFS44zr+1YRlFQhGMeZ6vVylpd296WiT2V3q3b9U/+CPn7afgP9hvx1pl98Y5JLj4c/Fm+v8Awp43sWHmwjSVhszbagIu82n3Vw0gI5aLzUx81ebfFD9lLxfrvxG0Xwv8FPB+sSeAfFV5rOseBkkt2S71yyZ4zcTQg8RraWMBkR3P3EViPnr8rrZta8UQ6Z4Q0mGS5ljeQQwxgszSTMCcAdSQoH4V/XV+yF4puv8Ago7+w34m/Yf1XWDpXxS+HttPYeHNRifyHWSG2ez8hWGCtrf2Ya1nUcZyf7tfl3jL4sYngzDYLMMVSVXCRrt15Nvmo0p80I1IpfZi5R57391aK+3wfCnDUM4lXo4eXLU9muVdJuNnKPro2j8ndU/4KVfts/E74QT/ALKvww8V3eh+F9a1ixutSu9MeZbzV9egAthPZtFtuEfUljgmuIEzvug0pI3kV8pfHL9gP9qb4LeFE+L/AMTfCnibQrS81BrNdS1qzkgSXUAvmtA0+5/LuiDu2yFWJ969Z8d/sb/Hr4Vfsy6B+1pDZXegraa3d2Xh97acLcWF54cuDFqMV1GoDwai05S6hOdzRxSEDagI/q9/4Jt/tu/An9v/APYK0z9n39rXxNF4q1aSTxJq3jCxvhHFqGq6hcwRwWENtFEAZbiWdxKsiKCFRs4Oa/o2GIoSinStKL1uut+q8ux+duMk7S0Z+aH/AARI/wCCmPi39orWpP8Agnf+2d4yQJrc1xqHhjxVrt3dT6oNbaOys7LSY5ZHZRbz+WfkYqCxJGXIz/RTqP7C/ihhPpGr+I1dQTHNDNHIy5BwVZWJBwexr/PH8RP8Wv8Agnx+3VDq1uEs/G3wn8VhmFwu+Mahol8UbzVH3kke33OB1DHFf6RPxp+Mv7QcPjdNV8F2Flr2mazpum6rFqGmxSzWVy1/ZQXMsltKTmS3aaR/LJ524zzX+TP7TLw7x9CjgeK8hqQpVOf2VVy5VzXjzU5XafvLlkr32t2P62+jNxXipSrZM5e6lzxT6apSSv3unb1Z+f3xG/4Im/Bj4keZcXs9vpt2/wDy3sI2hbPqVGYz/wB8ivzb+Of/AAb9/G/wpYS6z8DvEdl4oVAW+xXANpckeisxMTH6sDX7m/8AC8f2q/8AoWv/ACVk/wAaim+PH7UttC9zc+HVjjjUs7tbSBVVRkkknAAHJNfyT4NfT48feCqlOGX55Tr0Y2/dV5Rqwa7K/vxX+CcT924i8KsszK8q9KMZfzRtF/hZP5pn8YltN+1f+wh8W47/AE6bW/hz4ssn3pJE0lq7hD7fu54vYhlNf2zf8ETP+C9WoftbalJ+yl+0jDp+m/FK+hlk0PWEQW9prlzHFxHcqgPl3m1ASRkSKp2gEBa/jv8A28f2r/in/wAFDv2rNK0Lw3tu4NOcaFoNtbKQkryS/vZ8En/Wyc57Io967f8Aab/ZC+PX/BMv4qfDn4wJcSfY9Sli1vw1rMQMfmXOlzRGdMdVaKbH+9GynoTX/WPwBXxvG/B2Ar8bYSnhc0rUlKUINtQnZtRTklL4bOUHflfMrvl5j+C+JcLgqePqYPDT5optRfdLrp0vt3Wp+iX7UGnftFH/AIJV/HTxn+1/cSN4t1z9oWGJY5mJX+0dPsLqC/NuD/ywRMRJt42xgdq/ab/ghBqn9o/8ESL221OPz003xzqEUKsSBhmtJOCPRpmr+bX/AIK8f8FWNR/4KTfEHSfDvw70FvC/w+8PXNzeafpgA+0Xup37brm+uQmVM0rEqigkgE85Ygf1+/8ABOL4e+Jf+Cdf/BMj4ZfBvxh4X/tfxR4na68S6zp0/H2Rr9/NjSQFWxIkXlIQRwyt6V8n9Ipxw3ANXD5pKNCpXnona0Pd5Vp5K10urseDik1SXMrtvZF+Se0bO20Vf+BGqDKGbcqgD0r6cH7VOltxffCeBvpt/wDjVWk/ah8Dv/x8fCRf+AhP/iBX+SM+AcPLbM6P3NHEvZ9ackfO+malotmQb/TFusesjL/IGukuNa8EX7qIdOfTMAA+WBOM+vzlTXtS/tJfDCU4k+Esmf8AZCf/AFq10+OnwzKB5PhFcAEZziP/AOKr0MNwS1HlhmFBr0f5pX/Ep0qK+zI+eJNE0G8XdZ65Auf4ZoWiP5hSP1rBvPDwg5F9azD/AGZAf5819Ur8c/hQ3X4S3P8A5C/+LqNvjx8IV+98JrofhH/8XU1uBqLXvY6gvnP9bi9hRf2ZfcfO3g/SvFMV3LqfhW6jhktE8yVvNVAEzjLBiAy545roPH2u+GtZ0ywvo7W2XW1kb7UbYfuXQD5ScYXcT1Ar2tf2hfhPHA9pF8KrpY5MF1/dgNjpn5+QKjT47fCmU4i+FEv/AAJoh/N61hwzRhh3h6eY0dd7uTV77xVtH0v6h9Wp9YS+4+Un1zVHbO5QP7ojQKPw21G+pzTDFxDE/v5YU/8Aju2vqxfjv8NJ7oWNp8KVeQjIBli/nuNUL74/+CtPlMMnwkjRh/flQf0IrzJ8I01FynmlG228rfkP6tS/kl93/APnjTNU8M25/wCJnpH2j/dmZP02n+ddK3i3wJEmLLwvHu9ZZ3b9ABmvTW/aS8NNxa/CeyH+9Mp/9kqCT9oxghltfhVpaqO7uP8A43TpZRhqcbLNMP8A+Ap/mivq0P8An3L+vkcLZzre2S6zqGlabaabI5jBferOVxuCYcuSoPUA4NVL61+EtnOz2Umo3q9QoRYx9NxyT+Vdzc/tP+KJ4Y4Ivh5oiRw5Eas24LuOTgbRjJ5NZo/aP+JEjbbDwV4eiJ6Zi3/yxTqYPKbJPMqLemri279bWaVvJpk/V3/z7l/XyPObvU/D7jy9L0YIPWWVnb9Aorn3tZJ5N0dqyj0XP9c19AXvxj+OdriNdM8L2kjDcF8hdwB+prCl+Nv7RvSO70W194bZP8TXBjMpymD/AH+ZR/7dpf5SQvq8ntSf3/8AAN28tfHuueAtMl+HttdW9lp6Nb3MUQ2ytKDu8wlQGdSrDB9ua81h8J/FzVD+7tdUmz7SkfrXVxfFb9oa9hf7T4zt7Ij7qxwRjOfTCnFYk3jD4zXRP9ofEC5weojAX8tqV15hmHDk+WdTMKj0SdoJLTTRN6ehKy/EN6Ul82y7b/A34zamPm0q6wf+ep2j/wAeIrobT9mD4hMN2qyWlgg6madOPwUk15ncS63dgrq/jDVrvPUCaQD+a1iy6ZoLtm4kubsjvcSM/wD6EzV85iuJ+EqCu/bVX/ihFfgmzelw/jqj9yMV8m/1Pomy+Cnwp0CUSePfF1rJtwWgtWBY+2Tk8/SvTvib49+GHjfwnF4V0lwxtdgtppMqI9oC9D8zZQY5FfGNudFtQEjtyoH9whf/AGWrDyaMRmMTL7HB/XNebPxwoYTC1cHk2Ep0o1FaTcpTm16uyX3abo9aj4Z4rFVI1MU5SttdKK+7cs6npmmWlw8E0rHB4Pl/Kfcc8iqMUVlCd1pezQH/AGDJH/6AwrZu/FDyWEWmWcCLFEMAyAOx/E8CudN5PncCB9FH+Ffh2Iz90a7qYOo1ftzLX/wJXP2XLOFaUcP7LFQUn5pP9DuNE8Sazp86sPE+pRxDqqSOx/DzAwFbZ+KfxPsJm/s3xXLJFk7RcQKxx2zhFNeXjVL9fuzEfgP8KX+1tRPWYn8Af6V9dl/jTn+GgoUcXNW82/zkzyMb4W5PXbc6Efw/yPWF+PXxbh/1t/p13/10tmB/Rqa37Q3xCJ/0vSdHufX5GXP5g145Ndzz8SkH8AP6VWr6Kl9I/imOjxHMvOMX+jPnq/gTks9Ywt9/6NHvsPxo1+9h8xvDOhyseqeYEb/x6IUz/haetycyeAtNf/dmT/4ivBck9aUEivYh9JvOWkqkIP8A7cj/AJHlVfo+YF/A398v8z35firrUUTwJ4E0+ON/vKZ4wD9RtqmfinqcedvhDRoT/t3CcfkleGE56jNJgHtitJfSdzX7NOC/7cj/AJGH/EumFe6b/wC3p/5nv0Xxi8QwMHt7PQ7Fh0Kb3I/75jH86ydR+NPxEkdhaanYxof+eVu+f/HjXirJk8U3Y1cGM+k3xJUhyUq3J/hSR04f6OGVp806KfrzP8zu73xv4z1fjVPEcwU9RGDGP/HEB/Wix1rRtN/f3ErX8no8YJP1d8tXCbG/z/8Aro8s/wCf/wBdfnuZeLGcYqXNia8pv+9KT/C9vwPvcn8IsBhP4NJR/wAMVH8bXH3UoubqS5CCMOxYKvQA9hUNSeX/AJ/yaXy1/wA//rr88rY7nblN3P0PB8P+yVqULEVFR3l5YabA13qE0cESjJeRgqgfU8V5/pfxS0TxbeHSvhfZ33jG7Bx5eiW0l2oP+3KgMMY92YCu7KMpxuYVfY4CjKpLtGLf5HRiqNPDw9piaigvN2PRKG+VS7cAdz0rpNH/AGfv2p/Flt/aGtW+j/D7Tcbmn1a4F7dqvr5FswgU+zXAx6V8lfHL9or/AIJOfsqPJD+1X8bJvHeuQfe0XTbkvlv7osdKzLgntLKw9a/feF/ov8T4+0sVGNCL/md5f+Axv+LR8LmniLlWHuqUnUfkrL73+lzofiZ+0l8D/hBaG68f+I7SzbO1YlbzZmYgkKsce52Y46AZr4U8d/8ABT/RBvtfhH4SvNTIyFu9UYWNv9dhD3BH/bMfWvz3/wCChf8AwWN+FH7RXw50v4LfsSfBo+E9J0vU/t51bVY4NPE+2GSEf6PAGnkz5m7MjBuPevxI13xB8bfHhP8AwnHi2eCButrpKi1j+nmfNKfzFfsuWfREnTr8spc8dPek+Vedox1++R+h8FeJvh5QytY7iN16uJbl+4pKMYpJ+7zVJb8y191XR+1Hxv8A+CjHxRkt5D8Q/H9j4StH/wCXTSQkMhH93zZDLM/1UIa+UP8Ah4X4T/6LDrH/AIGP/wDEV+culfD3wdo85vLexSW5Jy08+ZpWPqXkLNmum/s3Tf8An2i/74X/AAr9sy76NuXUqShOpr5Qil+KbDEfS+yXDz9llfDGFVJbe15qs/Vzdn8uh//V/cjcO1SRgSSCMELnuelcN/wlEn/PMfmaX/hKHxny/wBa/wAPVhpH+hry6R6imjB13C5gH1eq9zp4tVMgmifHZWya82/4Sf8A6ZfrSjxOf+eX610OkraR/EyWW1b6s9DTVbxOFc8fT/CpBrd//f8A0FedDxPn/ln+tKPE4Jx5Z/Os1TqrZ/iN5X3iei/21qH9/wDQUxtXvn4L/wAv8K8+Hidenln86B4nQnHln86bhWfX8Q/su32TtTdSeaJ9xDqQQwOCCOhFZH7XH7M/7L//AAU9+F9l8Of2o9+geM9EjMWh+MLRAZoQefKuAcCWFjyysQM/MpUk5wh4njPHln86UeJ4s48s/nX6T4U+Kuf8GZnHNcjq8s+q6SXmv63a2bPC4h4LoZnRVLER1WzW69P1WzP5Uv2kv+Cef7bf/BE34zeC/wBrfTZ7LXND0fW4ZtE8SaY/m2k0ybmEFzGcPD9phDoQwwwLBSTX7E/8FJP2XPhn/wAFZv2UvCf7Zf7LiwRXHiNhNbxuyg6drDkJfaZdN/yzSSQFlJ4DgMPlbNfsn4Yi+EP7T3wg8RfsR/tF2/n+E/GkLQW8zkbrO7PMUkTH7jrKFeM9nGDwxr+Yf9mr4r/FT/gg/wDts+Kv2I/2x7ebVfg/4ylVL+RFYxNbudtprliOcPGoAnVfmG0g/MgB/wB2vBDxyj4k5HDN6KUcwoXU4L7UeqXdrePe9tLu38m8b8J4jL8U8PP4o6xl/Mv60aPLPgR+2h8P/wDglpZeMv2PvD3jxdPvtG8US6LrGs+IrKW7e21O3Pk3baDoMJ86S23YP2q8khicqCqE5B/MX/gp7+2ZofinxZY6pY6Hr3jXVFE76d4+8Uao1wlzHOnll9OtLFo7C0gAOVjjwysBv3EV/X9/wUX/AGMfB37Rvgu4n12/8NJPfRad4k8EfEEaZC32ifTpVmjF9fWsZuJra9tGaGfO9lYJJyAa/jB+Mf7Av7Y/7KOgX/iK20KPxN8ONUkeSV7SRNd8NzbifmjvLRm+yygdGfyJB0bIyK/LXwZgcBj8Vm1LDU418TLmqVYwinN2SvJ2V3pZ395NdbnxWJzbE4qMYVZtxhootuy9O35HqXwq8Rfs7fHP9gDXm8M6Nq8nxKvbmw8OvpdhegRS6hqt5BbpLFbiMTzfaldykbyugkyuMACv7F/2sPjJ/wAEr1+Dmq/tAfC3XrvwX4iltHk8T6NbahdeHrmVbC2Jmj1LTVkgZryQIIQdm92PU1/HB/wTj+GfwN8ZftJ/s5+Ef2eNcu/Dnxg1HxxDNq1rrlq0mj266dHJeWdzCYWf7av2mJQisyMJAAVUNur9kf8AgsrqH7SOl/st/EfUtTg1HXrTVbaBNQ1jxH4ZudEumt2v7bzriweVp0lR1AVlLRusblgMCvivCjw2o8O1MfUhiJVPbVJVYqTcuVOEVye89k02t99b7v1+LeJpZksOnT5eSCg2urTfveV00rbXWnY+SP8AglP/AMFDP2TP+CdmuPpnj7wrNfeM/GQg1TxR4jESvFo8mrSCa0szO5aaOOOOaMSkfxk7idpx5F/wXv8AgtofxI+MenfGHwFp8MF74rt7y5SK3wQ9zZBZpYlYffNxaOZVHdoW2jLnPDftP/8ABNKH4dfsg6L8TvihYNpviP4keGb7xtper22pNP8AaZ9MtU1Kaz1GxMSRQrLYTu1s0Tv5bDYxya+VfAv7TOqftMfsmaV8DfGmotpXjvwfPFeeEtWmbYLqXTseXGsrceekb+WcnkFWOea/ZoRnOi8vr2Wl4+vZ+bW3m/Q+RXLze1j8z4S8D/s4Xd5reiapHqcculz2drf3t7539nwWvmSjz7d7q4CIJUgzhk3AsQADzX2b4L/aa8HfsxftOaH4z/ZjgFj4d+HtkZNSeDUm1JNSF7eQ+cwma1tP3iLLEoGwjfDwSDXYfs4fGf8AZG8I/FJfir8cPh/pl14os+Lzwt4mh1JtBe8Ukm6sX04SvAJG+ZrWaFolJwjFcAfL3xz+Jdr8bfjN8aPitp2haRoUeoWtlqSaXoVobHT4IYb7TkMcFu4DRptwW3KpYksVXOB+e8ScKYDNcFWy3HUVKlVjKMk3unF3Vt189Ue3lWa4jB4iGKw8rTg00+zv/Xqfoh+1h/wVH+IsmkfECXRNA0Kx0n4l61pWuJpEjtNLZ6jpmD/aiR58oz3SRrFcbTtIZ0bf5j4/Lnwn4e8feD59F+J/huOytNI1PUbe3C2dzEl9HO85CSxsCbi2aOUZjKkbQFyT1P8AU5/wV8/4JQ/saR/sfSftP/sN/DjV7W5nFleaPdNPLOus25t1ur2a3tZGMwsbW1JdXRQhIJyIwob+Qr4U/Dvx342+ItpaaRpM8WqaWWuJAsbb2lhDTKzKwwgTbukY4VY1ZzgA15/CWR5flGAoZXl0HGjRhGEFzOVowXKk27t2StqPM8dVxVeeJrP3ptt2VtXrstjW/a0+LPjH48/FvUPjR8Rrn7b4h8STyXWp3OAPOuwI455cKFA8yZHbp3/Gv9VnwZDfeDvgt8M/C/jUadpurWHgnw/Bd2mnsq2kMiWEKlIBhP3Qxxx61/lg/CT4FeN/2gP2nfh9+zP8OdOGu+INcvbDTYbN5RAtxcXcvnujytxCoWUq7n7gUk9K/wBMT42fsd6RrfjSOy0TVf7H0zQ9OsNHsrCIvcpaW+n20UCQi4klZ5/L2EeYxy+Nx61/nJ+1RxGVy4EwuX5liPZOeIg46OTfJTqX0TT0urvbbuj94+jbg/aZ3UqSdoxpvW3eUbH0d/b+jf8AP5D/AN/F/wAa/nE/4Lcf8FOdP8DeFr39jz4D6mJde1aLy/EV/bPkWVo45tUdT/r7hTh8H5I+OrDHzL/wUo/a6+Hv7Nt9cfBX4A+Jh4k8XDdHqF3EAbbTeMFQ4ZhJc/7I4Tq3PFfKf/BK/wD4Jh/Ej9t34qWHxA8e2FxdeHpbvzIopt3marOG3MWY8i2U8yyHr90HqR8n+zb/AGZWE+t4XxR43u8LTtUw9GpDkdSS1jVnGWvs4/FCLS53aT9xe/8AovjT4rYbCUZZbltTmk9JyXT+6u7fXt67ff8A/wAG/wD/AMEytS+IPi6L9o/4n2/2C08h5rSW4GxbLTVH7+9YtgI8y5jhzjClm6YNcj/wUJ+KXxp/4Lgf8FBLX9nT9iLR31jwb8PbSbS/DVvGwithawMiXepzSOVSOOeRUVGY8xqn8THP3d/wWA/br0b4B/D9f+CTP7DEx1Xxb4gaGw8aanpK7nLSAImjWfl87nyEkC/cT5PvO239Nv8AgnZ+xj4c/wCCQ37I/wDZHiTyX+NfxJgS41ydMM2nW2CY7ONhnCwbjkjh5iTyqrX+8fHXidhOEcoq8aZt8VmqEHu77yto/e2j5Ppzafy3w1kmJxmJjCnG9Sey7Lu/JLVnyP8AsC/8EVP2ev2CvEFj8b/2qtUs/iT8SdNZZ9O0KyG/SdNuV5WWd2H+kTRNyAQFBGQG6j9PPFvxA8WeNvENz4m127drm5bJCkhVA6Kozwqjgf415T/btiWLGXJPJJzSjXLH/nqK/wAMPHH6SHE/HuNWJzafLCPwwjpGP+b8/wANXf8Ap7J/C+lhIu/vye7a/JdP61O3XXdYT7tzJ/30amHiTXF6XL/nXB/25Yj/AJbCnDXLH/nsK/DVmOKW05fe/wDM9WXA1J704/d/wDuj4l149bqT/vrH8qozalfXHM8rP/vEn+tcp/bdl184Uo1qy/57LUzzDEv4pN/MzfAdL/n3H7jovOccipkv7qP7kjL9Ca5gaxZkf65aX+17M8ectZLGVVs2S+AKXWnH7v8AgHqS+OtSk0waVeqJIwAMqxVsD35rn3vbKQ5KSfiwP9K48atadpVpP7Vtf+ey/nXbXzvF1UlVk3buZLw7w/8Az7X4nYJeaenPlOx/3sf0qeTXGddgRsejSMR+XFcT/adqf+Wy/nS/2jan/lqv51ks0rpWT/BFLw8w/wDIvxOpGq3iNuhbZ9Kim1G9uBieRn+pJrm/7Rt8YEq/nS/brf8A56j86wlj67VnJm8eAsMvsR+430vJovukD6gH+dXF1vVIxiKUp/u4H8sVyn2236eYv5il+2QHjzF/OlHHV47Sa+bNlwPhv5F/4CjckuppXMkrlmPJJOT+tRmZvWsgXcJHDr+dH2mE/wAa/nWMq9R7s6YcH4dfZX3I1vOx0NIZ8981lm4iPVl/MUefEerL+dQ6szohwvQjsvyNLz+1HnHpWd58R7r+dL50Z7j86hzkdKyKkuhoecSfSjzT61n+ah7j86XzV9vzqeaRosnpL7Jd81s9aPMPrVLzV9vzo81fb86Tb7mqyuC2ii7vJ4Jo3k8ZqmXB9KC4PpT94pYCK2SLe4kY3Ubiepqp5g9qXdSaZawttkWtxPGf8/lRuJ4z/n8qq7vajd7VNh/VmWtxPGf8/lQGPQn/AD+VVd3tRuwCx7dTRYPqzLQY+tG49MivONd+KPgTw7drpt/qMb3shxHa2+Z7hz6JFHudj7AV3vhnwJ+0l8SNsngTwJcafav0vvEUg02LB/iEBD3jDHpD+Nfb8NeGue5w1/Z2FlNd7Wj/AOBOy/E+fzbiLLsD/vVaMX2vd/crstbieOK5Pxb4/wDBPgLTn1bxtrFnpNtGMtJdTJEo/wC+iK/OX/gq/wCO/iB+xnoPha38X/F/TdLn1/7Wby10iOKBoVgEWxVlnaWZtxduRGh44r+aTxZ+2V4M17Um1Dwno+r+OdSycX1+ZGjDeonu2JUf7gxX6zlf0aM6niHh8SveVrqC5rXSestIrfpc/R+FcmyPF5RSz7Nc2o4XD1Obl525VXyycW1Sj726drtXP6lfHf8AwUu+APh/faeAo7/xfcrkA6fDst8/9fMxjhI/3WNfDfxR/wCCl/xyv7SaTS/7G8DWGP8AXTN9suQvruk8qFG/4C4+tfz7a98av2k/G4aM39l4VtH48uyT7TcAenmSYQH6LXls/wAOtK1i7/tHxndXfiC5zu36jM0qg+0eRGo9ttf0Nwn9EiFO08VGK/xe+/u0h+DPn838evDDJLxy3C1sxqL7VR+wpeqjG9RrykfenxX/AG7vBXiy+ki8T+JdZ+I1/n/j3hZ57fPp5cYjswM+q/jX3fon/Bwh+2b4I/Z/8L/AL9mzwHoPga08PabDYf2nqrm9uJDGCGkS0h8qGIntudvevxRs7Ky0+AW1hCkEa8BY1CqPwAAq1X9RcHeF2X5Mm6DbbVuyt5JWSP5o8YPpE5lxdh6eXywlHDYenLmjCjDl1s1eUm3KTs31XoezfHH9qb9sL9qO5kn/AGj/AIreIvEkEpO7T4bk6fp+G6r9mtPKVl/3y1fPmi+GPDvh2Py9DsobXPUxoAx+rfeP4mt2iv0Snh4Q+FH8/OTe4UUUVsSFFFFAH//W/YT+wbnsy0f2Ddf3lqn/AMJFd91X9aX/AISK5/uLX+Jdqvkf6aexkWv7Buv7y0f2Ddf3lquPEdx/zzX9ad/wkc3eIfnStV7B7GRL/YV56r+dH9hXnqv50weJHHPlD86d/wAJK3/PIfnQva9g9jIP7CvPVfzo/sK89V/OlHiXnPlfrTv+EkXr5R/Oner2F7KZH/Yd57fnR/Yl76D86l/4SSPr5R/Onf8ACSQf882/P/69TzVewexkQDRtQRgyYBByCDg16R+0n+y18J/+Csf7Oifs8fHKaLSPiJ4fjeTwn4mIBkWXb/qpT1kikwBKn8QAdfmHPADxHbddjVPB4qjtZ0ubbzIpI2DI6nDKw5BBByCDX6l4Q+Lmc8G5xTzbK3ZprmV9JLt69n63um0/kuMODKOcYX2FbSS1jLqn/l3XX7rfg3+x7+2b8cP+CU3xW1D/AIJm/wDBSjw/fX/w7ku9loUVprjSJZmxHfaXIATPZSk7jGmcZJUZ3Ifp39vP4Y/sVf8ABMb456f8c/EHx01v4a6p4osLvW7XQ/CsUrReI7e3Ee2O8gEc1taz3Mk6ofNhdWCyMRlST+jP/BTb9r74L/CX9he0/bW/aL8CaT4w8d/DPXNLbwHJfyi3uL3UXucBAUV5JUhWN5ZIypRxGfusMj+Kz9gz/gmp+0t/wWI+N3i3x/4x8RJa2+jy51rxBrUs11DbXt6ZprXSbCOSVmll3B+C/lwqDk+v+0VDxpo8S5dQznKaTouvG9RNaN91F31dnd7PdX+J/wALcS5TPA4+eGq29pB2dndP+vPVPzPR/wBvv/gqr+wf8Z7r4U/tG/sYfDy5+Gvxq8LXMWp67qFtDFY280yW1uHiQ2v7qW4+2h5Y7kW8IAXDowbFaX7Qn/Bbf4q/tefs86r8IfiLrOoanqXi+wk02G0vdLXdK84Ee4Xn24WyqH5Mi26njhAenmFt+wD+yd8N9B1/9q/4ja9caz8MtIVbbwylzafYLjxDqOQJQIUldns4JAYldNpmk3bSEXcfy1/aF+PviD9rTxhp/h7TNN0/w7pWhxyW+kWCiO3EaMw/d7vlQMxGQgwM5OSSSfDw/taEOe/x7Lq1t0tZeu/ZnzU+Wb9D3Pxz+0h+0J418H2X7OfiXWheQ+HNFGk3GpzX0l3baTpj7GubSAECOHf5aRy7WkZgBEpC8D5M1JrXx/HYaNoZk03wd4WDpFcOpM00krb5JAoPz3M5UbUH3VAycKTWr8C/hJ8bv2g/iZpX7KngDTWmv7y6kM1luS1UfZ1eSee8uHwsUNtEju8kh2RqC1fsN4O/Z9/Y0/ZB1+w+IH7R3xUHi3xBpLbNH8K/C17a+jsCw2yXF7qV9E9g0mCw2qsrSHuqgV6OFw+JxzcMPTlN7Wt80m9Ekut9W+xrSw8m7RRxn/BPa/8A2d/hr8Z0b/god8NPEniL4e6rPBHY6hZ6pPINM8zakbXVtbkS3cLOwMgjkV15Cq3Sv0t/4L1fsi/BD9mL9sb4a+Pfht4VsfCPwv8AiB4XuvAfiG90mMR6bb61BLd2zFl3MyT20X2WeTfy6x7+W3EfUvw0/wCC13/BLTwPbaFNpnwV+zavoEEMdvrV7oWkXGqvNEP+PqWeCOKP7SzfNuSMBTjaBjNV/wBor/gpF/wS2/4KQfAnVf2Jfi3Dq3haLxFfy6xofia+i8q20nxIYJYre9vHV3draYyeXcEq2FYtwRkfzpV4l4vnx1hsPT4exyw6VSE6sor2G8ZRmoqTbT5XFS5U1Geq7foUeFKEMoq1Z4in7T3XGK+LrdXt53td3a+/3r/gmp/wUf8ADus/sn+Lv2Yv2vPE9t4e+MPw18Fn4daJpuozrardabMrwnU7SZyVlk+yJAZJQSSkCYG1st4R/wAFt/8AgoD+yh4IufHXhP8AZCt/D9/Z+ItG07QPE/iTSba3AnWzedxpNjexIJJri/SQQ6gyMQtqhDHdgV+F3xs+CH/BSH9kzTovhz8a/hVpPxb8N6Hp8V1onih9PfWLM6Y6NJBJbalaSIZbURqWWOVmKDghcYDPhP8A8Eyf2zv2yvEei/E/9sjf8Hvhc2lz3+narqOnSWun+SjwbLPTLG3jy1zdmdWjAXdKoLFmIr9pWV4ZYlVaEpOWtoW6vl3725dLd5bXZ8B7SbjyNfP7/wDP8ux9Kf8ABAb4Z/D/AOCni7xT/wAFhv20Lc2fgjwR59r4V1CZiPtvi6eWDC28CHzrh7a3llf5VKK2NxGMV6f+3P8A8Fv/AI1ftKvc/Cj9ma1uvCPhu9YwNcIc6rfKxxgFM/Z1f+6hLn+8OleufFT9jL48ft4+IPCnwd+B/gk/CH4F/D8XVn4T0W6aWa+lW7n8yfUbi3y0rX99tRpAcImAqkc5/XH4J/8ABL39h3/gl/4Gi+OX7YXiGz8MvEgdZ9TZJ9ZunAz5dnaLuMLN22qz+9ehjvowcGZjneB4n4tofXMXh01RpS9+nTlJ3c1TStOo7RTcuZR5Y8sU05P6jKeNMTgMJUwOBlrUfvOO7tsnLolrtrqz8av+CZf/AAQ++Kn7RPi6x8afHHTZYbEkXKaTKSjMud3m38h/1EPcqTvb2zX6w/t/f8FR/hf+w14NuP2F/wDgm1LFr3xL1CNdK1jxNpsQeHTQf3f2HTFQENcAnaNoIjPJy/A+Xvj9/wAFTv2rP+CiviE/sN/8EnvBWpeFvCOosYLiezBGr6jEflaW8ulO2ytyOW+fdjqyjK1+t3/BPj/glP8As5f8Eo9OtfjB8dprPx78cZovMtoVxJZaMzjOYQ3WUZ5nYbs58sD7x/ePEDjHLOG8E874xqKEY6woX1b6c9r/ACir383oc+S8P4rG4mMIx56j2itl69l3bPL/APgkr/wSv0r/AIJ8+FIv26v20bP+1vjBrSPN4f0K5bzZNMM4Ja4uCxYm+k3Euxz5QJGTITt+tfGviLxf8QfE934v8VM9xe3j73Y9AOyqOyKOAPSuz8b/ABE174i+IpvFHiu8+0XUx9cKi9kRf4VH/wCvmuS+1Qf3x+df4b/SM+kfmvH+bvFYi8aEX7kOy7td+y6ebbb/ALM4A4Ahk9Fzq+9Wl8T7f3V5fn91uP8A7Pvf+eTflSfYL3/nk35V2X2mE9GH51Il2kbB0YZH4/zr+dfrD6o/ROR9jiv7Pvf+eTflR/Z99/zxb8jXo0eu3KjCsn/fIqceIrwdCn/fIrZVo/1/w5i1U/l/r7jzL7Bej/lk35Gmmyux1ib8q9P/AOEhvO5T8qjbW7twclef9kUOtH+v+HElV6x/r7jzI2l1/wA82/Km/Zrkf8s2/Ku/kuDI5dzyfTApnmD1rH6w+xsovscH9muf+ebflR9nuf8Anm35V3gk560u+j6x5ByPscEbecfwGkME4/gNd7vNG80/rPkHI+xwPkzD+A0eVN/cP5V3280bzR9Z8g5H2OA8uX+4aPLk/umvQN5pPMNH1nyDkfY4Dy5P7po8uT+6fyrv9wo3L/kU/rPkHI+xwGyQdjRiT3rvtyn/ACKAU9P0FH1ldg5H2OCzL7/rSZl/2v1rvgU9P0FIPL9B+Qo+sLsHI+xwW+Qev60eZL6t+td6PL9B+QoxH6D8hR9YXYOXyOSsNQS0YtPAJ89mLDH5Gtn/AISKxx/yDY8/7zVqYj9B+QpNsPcD8hW0Me0rJfl/kYTwsZO7X4s5C8vzcy+ZBH5I9FLf1Jqp59x/eb9a7rZCeqj8hWHrniPwt4ZtGvfEV3bWUSjJaZlQD8yKmNZzlaMbt9jRxjCOuyMH7Tcf32/M/wCNH2q4H/LRvzP+NeZ/Ef8AaA03wN8NdQ+K2heF9Z8RaLppiWW9s7No7TdNIsUYFzP5cDbncD5WNfln8TP+Cjnxp1O1lfw/aaN4JsAD+/um+2XIX15MUCH8XFfc4Hw6zes17Sg6aeq5/d07pfE16I+p4K4LzHiKE62S0va04vllNNKEWkm05tqKaTTavezWh+ylxqn2KE3F5ceTGvJZ22gfiSBXy/4+/bd/Z9+HtxJp134jGqX8fBs9LVrybPoViDBPqxA96/mw+Ln7cvgTxLfyW/jPxZq3xAvsn/RLRmlgz6eVAI7UD/eB+tfOupftN/GTWLf+z/hv4asfC1l/BJfMJJAPUQQ4VT9Wr9r4W+jTj8ZaU4Sa9OSP3yu38oo6M7/1L4fv/rJndPnX/LvDp15+jatCL9W0f0NeN/8AgpF8Q9RR4/hl4ZTTIe15rdwNwHqIIN2fo0i1718Cf21v+Ce3hz4Dp8VP+Cg/xgN94mlvruNfDOmXDxAwwsqxbbKw3Xjb89Xl2n0r+Q/WtM8c+OHMnxK8Vajqqt1t4X+y2/PbZFgsPqasaH4P8LeGl26FYQWx7siDefqxyx/E1/VPh39HPB5VWWJxMKbaW3LzWfe8r6rysfyx42ePfC2Z5Z/ZPCuBq03zJutUqe+0k048kPdSd02730R/Ur47/wCDkD4NfC21n8O/8E9PgGIlbKLq+tiLSonH/PQpGst5P6/vCCfWvyN+Pv8AwVy/4Kf/ALTYms/G3xPfwhpU+QdN8IQCwXaexun8y6PHcMtfAFFf0ZRyqjBJWP4/lXk3c5qbwnpN/rD+JPEJm1nVJTmS+1OaS9uXPq0s7OxNdIAFAVeAOgpaK9CMFFWSMm7hRRRVCCiiqV3qNhYruu5kjHuQKGwsXaKbp9r4i1wA6DplxOh6SyDyY/ruk25H0zXa2Hwp8S3uH1zUY7NT1jtV8xv+/jgAfgpppN7IGzh5ZoYEMkzBFHcnFVLS/k1aQw6DbTag44/cIWUfV+FH4mvfdL+FngrTXE0tr9tlH/LS7YynP+6fkH4LXoMaJFGIYlCIvRVGAPoBxWioSe5Dmj500/4d+O9Tw14bfS4z/ePnS/8AfKkIP++62P8AhUOuf9Bxf/AUf/Ha91orVYePUn2jP//X/Uf7fbdfMFL9utzz5grB/sxv+eg/Kj+zH/56D8q/xe5Ydz/VX2CN/wC2wf8APQfn/wDWp32uD/noPzrnv7Nk7OKT+zZf76/5/Ck4R7h7BHRi5iPRx+dL9pj/AL4rmv7Nn/vrSf2bPn7y0cke4fVzp/tCdmH+fwpfPT+8K5Y6dcDoy0n9n3Q6EU/Zx7i+rnV+cp6MKXzPeuT+wXfqPzoNhd+o/Oj2S7h9XOs8z3qWESXEyQRctIwVR7k4Fcd9ivR3/X/69dp8ONBuNZ+IGi6Vcq0kdxewRsqguSC442qdzD1A5x05rpwWBVatCipfE0vvdjnxaVKlKq1sm/uP5af+Dhf4y+EviJ+2hofwC+H8EmpX/wABNDl0fU7ryZojea/eajL9ktVhchZEtWuFeN1X95uk+YqRX6zyeHvBH7Af7J9n+xx4N1+78I6J4d8NJD8dtS3BJJtalK3b6bpt2rE/bb+OWSOd0LeRYsmNssgB/CeCX4l/Gz/grRc+IvjVd2vinxTqPx0i0u9udOUW9pdP4VjkWIxLcuVitQRG2JGICL81eff8FnPEv7ZPgXVNA+BPxn8Py+FvC+nIZUuJpTNB4m1KRv8AiYautwcG9Fzds0xc/MNygqoVVH+0OR5VhsBhaOEivcpxSUdXe2iV97WSu9/mf5dZnjquLr1MRUfvTbbe2rd3obEX7ZHwd/4KF/tD+JfCnxV0qLw34Rl0x/D/AIDhgZo7LwwxikWyuvsi7RIZZ4rezWQuBbrMXIYnj8OPijpNi3xcnSZvsttqrWmoMQP9WmoQQ3RwP9kTcD2r13TfF9p4si8Raxo2m2nhuPStAGmt/Z5Zku53uoDGWZt3zHYZCVx8sZIr6i/Zu+F3h/4i/wDBW74QfBzxbp8+raY3iTwjpep2drEZ5ZIrSHT47xPLAYsFEUm/jAUEngGvRxknODqyd9V/7d9y0t8jjgknZH9A3/BMNf8Agnx+w3pXiNf28tYvPD3xU+MGi2jS40838eh+G7hFMGn320M0d7qkCR3F2pGRE0aNgs6n9B5f+Ccn/BHr9ptP7S+EPxA8CX0k/KxW+oNplzz6wl9qn2xX6SftNfssf8EoP2rPiR4g1D9oD4Z3Oi+JJdQuEutd0Od43uJEcoZW2FlYttzzFX5z+MP+Dcf/AIJ4fECR7r4M/HPUNBZ/uW+sW0M+3Pqxa3bA+lfVcCeOPh9Xoqnh81lRq/bUuWzl1dvi3Pvsf4a5ph0p1cPUjpuk2vvjdHGX3/Btd8DNdBu/CupCSE8g2mu2cq4/4EM4qvYf8GzPwotW87Vb+byl5Yza1ZIuPcgVzs3/AAa//EOFsfDr9ovQGg7bzcwHHbiJ3H60z/iGE+PEj/8AFUftFeH/ACP4iJr2Q4+j7Qfzr9ajxxkko80c9p2/wP8A+SPnnkOIT5XKf3P/ACPvL4M/sY/AP9hWyg83476d4LsdPWXZa3/iqW4gQSxmOQC0WT7MdyEjGz6c81wXxY/4KXf8EkPg9dS6r4q+IOs/FvWo3Mn2fQrZvJMuxUyLmU+UAVRVyrD5QB2r5/8ADf8AwbNfsreG5hffG39oiK5IO6SPS7OMs3sHedmyfXbX198Of+CYP/BFP9nqSO9/4RvXPijqUHIbVZnFuzD1RBbJj2O6vz/iDxm8O8sbrZhm7qS7QUYt+Wt5fcz2cu8OMfi5fusPUn8ml97sj81dd/4LmftkftA6s3wf/wCCXXwaTwm98fKjvbW1fVtYcHjdv2mGEnqclwK9B+Df/Bv/APtL/H3xEn7SH/BXL4mTaBbz4llsprv7brEyn5vK3MzQWinptQMV6bK/b60/avHwz8O/8IV+zF4H0X4d6QF2hdOtY1lIHclERS3uwY+9fM/ifx7468aak2r+Lb6fUbk/xzsXI+gPCj2AFfzDx7+0Dy7L6c8PwRglGT09pK7f3y95+lvRo/auGPo/Y+paWOaox7L3pf8AyK/H0PpXwN4t/Z7/AGP/AIeP8Ff2CvCNv4T0xlCXWruge/vCBje8jgyOx6gucD+FRXz7f6lf6peS6jqcz3FxMxeSWRizsx6kk8kmuK/tHUem39KBqWoDqv6Gv81+PfEPO+JsY8dnNd1JPu3Zei/XVvqz+kuGeCcBlNL2WCp2vu3rJ+r/AKXZHVbzS7zXK/2rff3f0pf7XvO6D8q+F9iz6X6v5HU+Y1L5r+tct/bF0OqD8jS/21cd0FL2Mhew8jqfOk9f1pfOlHQ/rXK/21P/AHBThrc3eP8Az+VHsZB7B9jqftM4/iP50v2q4/vH8zXK/wBtv3QUo1w90/Wl7Bj9h5HVfa7n++35n/GnC+ux/wAtG/M1yn9uDun607+3F/ufrS9g+wnh/I6n7fd/32/M04ajeDpIfz/+vXK/22ndDS/23F3Q0ewfYX1fyOrGpXv/AD0NKNVvx/y0Ncp/bcP900o1u37qaX1fyD6v5HWDV9Q/56GlGsagP+Wlcp/bVt6Gnf2zansaTw/kH1fyOq/tnUP+en6f/Wp41vUR/H+lcl/bFp707+17T1P5Uvq/kL6v5HWf27qP94flThr2oDuD+H/165L+17P1P5Uv9rWf979KPq3kH1fyOuHiDUB3X8v/AK9OHiG+HUL+X/165D+1LP8AvUf2paf3qTwy7B9WXY7D/hIr30X/AD+NKPEd4P4V/wA/nXGS6xp8CGWeVUQdWY4A/E8V8++O/wBrz9n34fTPYat4hgu75f8AlzsA13cZ9PLhDEfjXThMorYiXJQpuT8k2OGFcpKnGN29kt36LqfW48SXXdFpR4juj/AK/JPxl/wUM8Q3ivD8MfCnkR/w3eszCIfUQReY/wCDFK/PL40/t5asvmQfFb4lfZA2f+Jdo5Ftkf3QsRkuW9OJBX3eTeE+Y4uai428vif3Rv8Ai0ffUfCfNlQ+t46EcNR6zryVKK/8CfN90Wf0d+J/j14A8G3cGneJdVtILu7kWKC28wNPNIxwqRxLl3djwABk1674Q8H/ALTXxQCP8Pvh9eW1pJgrf6+40uDB/iEcoN24/wB2E5r+Mf4Wft93Pwj+MGgfF34J+BJtXvtA1CDUI7rWHNqkzQOHAaR/MuWBI5yM19GfH3/gs5/wVF/aRM9nrXxCi8CaTOWBsPCVuLd9h/ha8m8ycnH8S7K/qXw5+ilgqsPb5xCbd9E2oprzSu//ACY/kXx18TcJk2Kp4HhrH0sTeN5zhGTUZXtyxlLSWmt0rH9Z/wAQPhF8PfgroLeLP21fjno/gvToxuktNLkhs+B1X7VeGSZ/T5YEPpX5r+PP+C1H/BIb9nK8dP2ZPAWp/GLxHbsVTU3geeHzB/F9v1RtijPeBceg6V/Ivq2hQ+JtcbxV43ubvxHqznL32sXEt9cE+u+dnI59MVtKqooRRgDoB0Ff1bwx4V5PlMUsBh4U/NL3v/Anr+LP5EzrjHMcwd8XWlPyb0+7b8D9Z/22/wDguL+3N+258P8AUPg/a6ZoXw28I6i8LSQWgfUdRIglWWMfaJPLhTDIMhYz9a/Fq7+H1nr9z9v8eX994iuM7s387PGD/sxKVjH5V39FfbU8kwsantnBOe12le3qckeKcyjgnlka81QbcuRSahzNJN8t7N2SV7XskUrDTtP0uAWumQR28Y6LGoUfkAKu0UV6p4IUUUUAFFMkkjiXfKwUDuTiqFtqQ1GY22iQzX8g/ht0LgfVh8o/E0m7DsaVBIAya6Cw+H/jzVcNOkGlxnvK3myf98J8v5tXa2Hwd0BMPr1zcak391m8qP8A74jwfzY1cYSeyJ5keLS6zp8UwtlfzZj0jjBdz9FXJrorDwv461nDWOm/ZYz/AMtLxvL/APHBuk/8dFfR+laJo+hQ+Ro1rFap3ESBc/UgZP41p1qsP3ZDqdjxOw+D7zYfxJqksvrFaqIU+m47nP6V6Fovgfwl4fYS6XYRJKP+WrDzJP8Avt9zfrXVUVrGlFdCXNsUknk0lFFaEhRRR70AFFcxrXjTwt4fGNWvoom7Juy5+ijk/lXM/wDC3/AX/P23/fqT/Cs3WitGyuVn/9D9Rdj/ANw/rRsb+4fyrcGuWvdDTv7bs/7rf5/Gv8VLy7H+uH1ZGAVI/hP5UY/2TXQf2zYnqppf7Y0/0P5UuaXYf1ZHO8eho4x0NdD/AGtpx7H8qd/amneh/KnzS7B9VRzmR6UmV9K6X+09MPUfpS/2hpnt+VHM+wfVkc1uU9qTcp7V0327Sz6flS/bNKP938qTm+wfVkcxuU9q9H+D182n/FnwzewTraPFqloRK4yqfvVGWH93nn2rnzdaUeu39Kcl1piMJE25Ugj6iurAY90K8K6XwtP7nc5sblntqM6L+0mvvVj+OT4N+L7n9l79unV/irY6HJ4b/wCFVftDW19PpmtFg2naX4ge7tUN42XfZCsMYdsknIOckZ/qg/4Kt/8ABNLSv+CjVpbeF/iH42ur+88H6rFpo1m1jiCSeJddiYR2qxKNv2K1hSzLndhFdsfP5hP4Q/8ABZj4XaP+zl/wUGvv2gvjBez6v8If2rtCeLW5rW2KnRbiCVIbcArmN7jTZbSCdCSHkUSZHJNfZP7L37fv7avwB+B3g74J694I0j4reH/COpvq+neNtN1qC2tdVg+zy21s+pNK++NoYJ23EjfuVCfmWv8AbDCQnmeCo47Llz3j089Yva9mrK/rfof5P4rD/VcRUwuK91xdn5NOzX5nwR8VP+CTvwi/YB+AGoR/HvxDp2s+I7nxJqmlx6Xpokxb6foMjPq+sXjyNuJ/s5Vgso8bVmvozy4GPD/+Dcj4can8fP8Agp54l/be8X3FxZ23wustQ8Xy+RGClzfahOtlFZFmUoiyJeyHAw21flxjI+Zv+Ckf7ZXxC/a2+MutfDnwRdr408efEPUlTWpdCR5LJFM/m2+h6QuN8tvHOQ88xGZ5FTPyoK/rq/4J3fsR2/8AwTV/Yi079mrxBeJd+NvFl7D4q8WlYlja1nnsrZYNLZwSZRZEMWz0kY4FfAeMnG8OHchq4icl7RK0f8b0il0fLrJ/9vH2PhnwhPPM5pYSK9y95eUVv6X2Xm0fQEsrTytNKdzuxZie5JyajO3pjNdT5GmHsv8An8aPs2lnsPzr/IR176tH+nH1S2xypWP0FBWP0FdV9j009APzo+w6ce36/wD16XtkP6szlsID8opSVzXUmw08nIX9aT+zrD0/Wj2yF9VZy+R0oOOldP8A2bYHoD+dJ/ZlieRn86PbIPqhzJx0oJHQV0v9mWXv/n8aQ6XZerUe2iH1Q5vI6UZUGukOlWQ7tSHSbT+8aPbIX1U5z5KPkrojpNp/eNJ/ZFt/fNV7Zdw+qnO4j9P0o2xeg/Kuh/si2/vmk/siD++aPbLuCwpz+2L0H5UmyE9VH5V0H9jw/wDPQ/5/Ck/saL/npR7Zdw+qmB5cJ4Kj8qaIrc8bR+VdAdGT/nr+lJ/Yw/56/pR7Zdw+rGAILfptH5U37PbH+EV0H9jf9NBSHRj/AM9R+VHt13F9W8jn/s1t02Cj7Na9NgrfOjMP+Wo/KkOjSf8APQVXt/MX1UwPstoeCgpPsdoeNgrf/saX/noKP7FuD911NP2/mP6qYH2O06bBSfYbT+7XAeP/AIx/CL4XxM/jnxNYWLr/AMsvM3yn2Eabnz+FfGvjL/goL4biZ7X4XeHrzWX6Lc3eLSD6gNmRh9MV72W8O4/F60Kba7vRfe7I78p4fxePqeywNKVSXaKcvvstPmfoT9hs/wC7WFreseEPDkfma/dwWmegkcBm/wB1fvN+ANfmN8H/ANsjRfFvx90TRf2tvH2neA/AsouZNQWxkFvIEit5ZEUztum+aVVXhec4r6Z8af8ABbn/AIJQfs3zy2X7JPw11H4oa5EcDUpYNsDP2c3V5uLD3RRX794ffRux2cU/rGIxChBO1knJ9PRdd7s/G/G7j2twTjYZXjcNetKCnbmjZJuSSlyuVn7rdtHa3c+sfCPh/wCIXxPcR/CPwXq2uoxwLp4zZ2Y9zPPt4+i17vJ+xr498P6SfFf7RXj3QfhxpMY3yLE6SyhRyQ090yQ591Br+bT49f8ABwd/wUr+NscmlfDiXRvhTpDhlRNMi+2XyoeBieX5UYD+6MV+PPxI8VfEv43au+v/AB48Xa141vJDuZtWvJZo8+0O5Yh+C1/UvC30YeH8Dadam6su83p/4CrL70z+R+IPHzPsZeNOoqUe0Fr97u/uaP0Y/bp/a7+A2kftCeLvAfgTxhq3xG0XTL97fT1sZnkt5YkC8kwiKBgWzywYV8A337SPxi1SA2Pw78P2HhWzPSS5xLL9fKQBM/WuIstPsdNhFvp8KQRjosahR+lW6/RMr8F8lw8nKUOZXultFeSirKx+gYv6Z3GcMDTy/J5U8JGMYxcqUEqk7JJynUd5OUrXbTWrMXWv+FgeNUK/ELxTqGoo3WGB/skP02wbGI+pqlofgvwp4c+bRbCGB+7hcufq7ZY/nXT0V+k5fk+EwkeTDU1FeSSP5w4k4wzbOK/1nNsTOtPvOcpP75NhRRRXpHzgUUUdBk9KACisx9XsBJ5EDGeXpshBkbP/AAEH+ddHp/hfxzrODaaeLOM/8tLttpx/uL81JO+wGfVG61LT7Li6mVG/u5y35Dn9K9TsPg/5uH8R6nLP6x24ESfTPLEV6Ho3gvwroAH9lWMUbf3yNz/99Nk1oqUmS5o+drCy8S63j+wtMmkU9JZv3Mf5tyfyrt9O+FXiK6YSa5qKWy947ZNx/wC+3H8hXvVFbLDrqyXUPOrD4V+CbOQT3FqbyQfxXLtIM/7hOz/x2vQYYYbaIW9sixxr0VAFUfQDAqSitYwS2RDbYUUUVQgoorL1PW9H0aMy6tdRW4H99gD+XU0m7bgalFeTX/xe0NMx6Hbz6g3ZlXy4/wDvtv8ACuKv/H3jjVMrC8OnRntGPMkx/vNwD9KylXittS1Bn0RcXFvaRGa6kWJB1ZyFH5nFef6n8U/CGnuYLaZr6UfwWyl+frwv614PcWP2+Tz9XmlvX9Z3LD8uF/SrccccSCOJQqjsBgflWTryexSgjtb/AOKHii/BXSLOKyQ9HnbzH/75XC/nXI32oeIdXQprOpTyqeqRnyV/8h4P61HRWbbe7LWhStdOsLEk2kKox6sB8x+rdT+Jq9lqSikkB//R/TASH1pfMPrUn9n3f9yk+wXf9w1/i7zruf7GPBvsR+YfWjzD6077Fdf3DSfY7n+4f8/jT5kL6o+wnmH1o8w+tL9kuR/AaQ2twOqGjmQvqr7B5h9aPMPrTfs0/wDcP5UfZ5/7p/Ki6D6q+w7zD60vmH1qPyJum00nkzf3T+X/ANai6D6q+xL5h9aPMPrUXlS/3D+X/wBak8uT+6fyph9W8hPiL4B+C37S3wI1r9k/9qDTp9W8CeIbi2unNo4jvLC5tpVkSe1kIJjLYKyAfeUkd6/m18Wf8Gy3xfudSurT4M/GnRm8LXPiJoEsryeaGW30Ga5dIrycAiKS4jt13ywKM7uAea/pK2P6Gjy2Pav3Lw/8fs5yDCrA01GpTWyle630TTWl+jv5WPxfjrwEynPMS8bNyp1Hu42s/Npre3VfO58b/sD/APBKr9jP/gmVqi/FPwvfv8Tviva3T3Gj+I7iI21to8clqbcrFbnIknzLM289Mp3WvtvUNT1DVb+bU9Ume4ubhy8ssh3M7NySSepNZe1vSjBr4njzxHzTiKuq2YT0jtFaRXou77u7PsOCPDXLeH6Do4CGst5PWT9X2XZFjec0CRhxmq+DSV8Gfb/VvItea+etL5r+v61UyKKB/V/IuedJnr+tL9olz94/nVKigPq/kXftM394/nS/ap/75/OqNFKyD6uX/tdwP4zx7077bdf89D+dZ1FHKg9gzSF9d9pD+dOGoXg/5aGsuilyofsDVGpXnZzSjUrzpvNZNFHIuwvq5sDVb3+/SjVr3+9WNRR7OPYfsGbY1i9/vD8qX+2L09x+VYdFJ049g9gzdGs3nqPyp39t3nt+VYFYPiHxT4a8JWZ1HxTqFtp0CjJe5kWMY9txGfwqqeH5nyxjdkyp2V3od9/bd11wv5Uf23cnnatfGJ/bG+Eus+LtP8A/Df7T4o1bVLuGxt0soysHnTusaBp5NqKCzDJwa/S2L9jX4u2OlN4k+PHjHQfhvpCDdIRIlxOqjrmadktwcd1r9L4U8Gc9zhv6rQtFbuTUUvv1+5HxHHPHuW8O06c80k4+0TcVyt8yW9tLPfe543ceJPscDXN40cUS9XchVH1JOBXOaX8So/E+ojRfAdhd+Jb1jtEOlW8lzz7yACIf99V5n8VP26/+CIn7KV89v4j8T33xn8U2px9mszJqaiQdsJstoxkd9wFfBvxa/wCDlr473VhJ4X/Yw+Euj/D/AEvBWK81kpLMB0DC1twsWcf3jX9F8L/Q/jK081xF/Kmv/bpf/In81cSfSoescqw1vOb/APbV/wDJHf8AxQ/b9+I2ja3qPhbwl4Ri0ufTp5bWafV5uUkhYo/7qP0ZT941+Zvxs/b71C5Mlr8VPiS/zZ/4lujkRA/7OyDc7fiwr8wviBqfxQ+M3ifUfF/xh8V32q3Wq3Ut5cQ25+y2/mzOXfCRkHaWY8ZrJ0Xwf4X8PD/iT2MMLd3CguT6ljk5/Gv07hn6LmCw0ues1H0XNL/wKV7P0R+kZv8ATN4ewNGMMhyj21WyvPEyvG/W1KFo2vtd37nt2p/tZ3d1K5+E3g2WV26X+qv5QOe/O6U/ia8s17xn8evHmV8V+KG0+2c82ulIIRg9jIcsfrVmiv3LJvC7JcE1KNLml3l7z/HQ/n7jj6XPH2e03h6uOdGj/wA+6KVKKXb3LNr1bOG0/wCHPhKxuPts1t9sue892xnkJ+rk126IkahIwFUdAOBTqK+/pUYQXLBWR/OFevUqyc6km2+r1YUUUVoZBRRVS6v7Gy/4+5ljPYE8n6DrQ2Bboplhb69rRA0LTZ51P/LRx5Uf/fTc/pXa2Hws8T32H1q/js0PWO2Xe303tx+VCTeyB+ZxM00VunmTuEX1YgD9aqW18+oyeTolvNfP6QoSPxY4WvetK+Fng3TXE81ubyYf8tLljIfyPy/pXoMMMNvGIbdFjQdFUAAfgOK1jQb3Icz51sPh7461PDXXkaZGf7x82TH0Hyg/Wu1sPg/4eQiTXJp9RcdpG2x/98LgfrXrNFarDx66kuozO03R9K0eLyNKto7dfSNQv6jk1o0UVqlbYi4UUUUwCio5pYreMzXDrGg6sxAH5muC1T4n+D9Ncwx3Bu5R/BbKZD+Y+X9amU0txpXPQaK8Gv8A4p+IrzK6LYx2i9nuG3N9dq8fnXE395r+s5/tvUZplP8AyzQ+XH/3yv8AjWLxC6IpU2fQur+NvCmhZXUb6NXH8Cne/wCS5NcBf/F2SXKeH9Nkk9JLg+Wv/fIyxry62sbOz/49olQnuBz+fU1arN1ZMtQRo6h4n8a6xkXuofZoz/yztV2f+PnLGueTSrFZPOdPNk/vyEu35tn9MVoUVk13KQe1FFFMAooooAKKp3OoWNnxdTKh9CefyHNW9PtPEOtY/sPTZplPSSUeVH+bcn8qV0FhaK7Ww+FXiO9w+uaglov/ADztl3N+Lt/Stb/hTdp/0F7z81/wq1CT6C5l3P/S/S8atd5+/wD5/Kgatd/36/S9PAHgPH/IEsOv/PtF/wDEUJ4A8B4/5Alh1/59ov8A4iv8kv8AUxf8/Pw/4J/ra+L3/J+P/APzQGr3fTfSjV7scbhX6XJ4A8B4/wCQJYdf+faL/wCIoT4f+Asf8gSw6/8APtF/8RR/qYv+fn4f8EHxe/5Px/4B+aQ1i6/vD8qUaxddmH5V+lifD/wFj/kCWHX/AJ9ov/iKE+H/AICx/wAgSw6/8+0X/wARR/qYv5/w/wCCD4vf8n4/8A/NMazd9Aw/KlGs3I7iv0rT4f8AgLH/ACBLDr/z7Rf/ABFCfD/wFj/kCWHX/n2i/wDiKP8AUyP8/wCH/BG+MH/z7/H/AO1PzVGtXPqKBrVz7V+lSfD/AMBY/wCQJYdf+faL/wCIoT4f+Asf8gSw6/8APtF/8RS/1Lj/AM/Pw/4IPjB/8+/x/wDtT81RrM/otKNam9Fr9KU+H/gLH/IEsOv/AD7Rf/EUqfD/AMBY/wCQJYf+A0X/AMRQ+C1/z8/D/gg+MH/z7/H/AO1PzWGtTdMLR/bU3TatfpSnw/8AAWP+QJYf+A0X/wARQnw/8BY/5Alh/wCA0X/xFL/UyP8Az8/D/gg+MH/z7/H/AIB+aw1mT+4tH9sueNi1+lKfD/wFj/kCWH/gNF/8RQnw/wDAWP8AkCWH/gNF/wDEUf6mR/5+fh/wR/64v/n3+P8AwD81hrB/55rS/wBsH/nmtfpQnw/8BY/5Alh/4DRf/EUJ8P8AwFj/AJAlh/4DRf8AxFH+pkf+fn4f8EHxi/8An3+P/APzXGsD/nmtH9rJ3iWv0oT4f+Asf8gSw/8AAaL/AOIoT4f+Asf8gSw/8Bov/iKf+pq/5+fh/wAEHxi/+ff4/wDAPzX/ALUi/wCeS0f2pD/zxWv0oT4f+Asf8gSw/wDAaL/4ihPh/wCAsf8AIEsP/AaL/wCIpf6mL/n5+H/BB8Yv/n3+P/APzW/tO3zkwrS/2nbdfJWv0oT4f+Asf8gSw/8AAaL/AOIpV+H/AIC/6Alh/wCA0X/xFH+pi/5+fh/wRPjFr/l3+P8AwD81P7QtDyYR+dL9vsj/AMsRX6VL8P8AwF/0BLD/AMBov/iKF+H/AIC/6Alh/wCA0X/xFH+pi/5+fh/wQ/1yf/Pv8f8AgH5q/brH/niP0/wpPtmnnrDX6Vr8P/AX/QEsP/AaL/4ihfh/4C/6Alh/4DRf/EUf6mL/AJ+fh/wQ/wBcn/z7/H/gH5qfa9OP/LH9aPtenH/lkfzr9K1+H/gL/oCWH/gNF/8AEUL8P/AX/QEsP/AaL/4in/qb/wBPPw/4If65P/n3+P8AwD81PtOmH/lkfzpftOln/lmfzr9Kl+H/AIC/6Alh/wCA0X/xFC/D/wABf9ASw/8AAaL/AOIo/wBTf+nn4f8ABF/rj/06/H/gH5G+O/jN8HvhlF5vjzWLbTTt3COSQGUjtiNcuc9uK+RPF/8AwUD+H0StB8MfDuoa5J0WefFpb/UF8uw+gr9T/jR8Evgxq3xRutW1TwjotzdLa26iaWwt3kAAbADNGWwPrXlmofBP4NfYZv8AikdF/wBW3/Lhb+h/6Z1+qZJ4S4FUadWvNzckn2Wvknf8T9k4JyHD4/DLG4u/K/sxaT+cmpfgkfhP8Wv25/if9mkn8VeKdN8FWWCfKsiPOx6ebKTJn6LX5teLv2w/h1ql+8/h+z1bx3qJP/HxOXaIn18yY7MfRa/azTP2av2cta+JDzax4A8N3bh3w02lWchH4tCa+nF/Zv8A2eIF8qHwF4cRR0C6XaAD8BDX9bcF+BWV06SqTk7PpFKP3tXb+8/jHjz6aOLyzFVMFwzldGhKDt7SpevU9U5pRX/gJ/L1b/tMftRNr9j4i8H3Fj4MbTriO5tWt1+03EckTB42BYBFKsoNZXxT+IHxj+P2rSa9+0L4313xtdSnLDU7yRoOTniBSsQGf9mv6nP+GdP2fP8AoRPD3/grtP8A41R/wzp+z5/0Inh7/wAFdp/8ar93yThjL8up+zwdJRX5+p/GfiJ4qcRcWYqON4hxcq04q0b2tFPpFKyS9Ej+TTT9K0zSYRb6Xbx26DtGoUfpV+v6vP8AhnT9nz/oRPD3/grtP/jVH/DOn7Pn/QieHv8AwV2n/wAar6FTsfnnIfyh0V/V5/wzp+z5/wBCJ4e/8Fdp/wDGqP8AhnT9nz/oRPD3/grtP/jVHtA9mfyh0V/V5/wzp+z5/wBCJ4e/8Fdp/wDGqP8AhnT9nz/oRPD3/grtP/jVHtA9mfyh0V/V5/wzp+z5/wBCJ4e/8Fdp/wDGq5jxl+zp+z5/wjV1/wAUJ4e+7/0C7T1/65VM6tlcapn8rEur6fFJ5CyebIeAkQLt+S5re0/w5421kBrDTTbRn/lpdts/HYMsa/rd8Afs4/s82Xhi0ms/Afh2J2QZZNLtFJ47kQ123/ChPgX/ANCXoP8A4LrX/wCNU6U+ZXZnJWP5IrD4Qzz4fxHqckg7xWw8pf8Avo5Y16Do3gXwloOG06xjD/33G9z/AMCbJr+pz/hQnwL/AOhL0H/wXWv/AMao/wCFCfAv/oS9B/8ABda//Gq6YuK6ENPufzIUV/Tf/wAKE+Bf/Ql6D/4LrX/41R/woT4F/wDQl6D/AOC61/8AjVae38ifZn8yFFf03/8AChPgX/0Jeg/+C61/+NUf8KE+Bf8A0Jeg/wDgutf/AI1R7fyD2Z/MhRX9N/8AwoT4F/8AQl6D/wCC61/+NUf8KE+Bf/Ql6D/4LrX/AONUe38g9mfzIVn6hq2l6TF52p3EduvXLsB+QPJr+n//AIUJ8C/+hL0H/wAF1r/8ar5wj/Z0/Z8vvHGqG98CeHptsvG/S7RscdswmsquM5baFRpXP5ytQ+Lnh6ImPRoptRcd412p/wB9tgVxV/8AEPxrqWUtPJ06M/3R5sn5nCj8K/qW/wCGdP2fAMDwJ4e/8Fdp/wDGqP8AhnT9nz/oRPD3/grtP/jVZPESZoqKP5N7q1l1KTztZuJr1/8Aps5K/gowtWIoYoE8uBQi+ijAr+sD/hnT9nz/AKETw9/4K7T/AONUf8M6fs+f9CJ4e/8ABXaf/GqjnK9mfyh0V/V5/wAM6fs+f9CJ4e/8Fdp/8ao/4Z0/Z8/6ETw9/wCCu0/+NU/aB7M/lDor+rz/AIZ0/Z8/6ETw9/4K7T/41R/wzp+z5/0Inh7/AMFdp/8AGqPaB7M/lDor+rz/AIZ0/Z8/6ETw9/4K7T/41R/wzp+z5/0Inh7/AMFdp/8AGqPaB7M/lDrNk1ewSTyI386TpsiBdvyXNf1R+Nv2dP2fP+EauR/wgnh7oP8AmF2nr/1yr2DwR+zj+z1Y+HbaSy8B+HYWZBkppdopPHfEIqPa3lyicLI/kesPC/jfWMGz0/7LGf8Alpdtt/8AHFy1drYfCFpgG8RalLL6x248pPz5Yiv62v8AhQnwL/6EvQf/AAXWv/xqj/hQnwL/AOhL0H/wXWv/AMaroVupm7n8s2jeCPCmgYbTLGJHH8bDc599zZNdVX9N/wDwoT4F/wDQl6D/AOC61/8AjVH/AAoT4F/9CXoP/gutf/jVbRqpbIlwufzIUV/Tf/woT4F/9CXoP/gutf8A41R/woT4F/8AQl6D/wCC61/+NU/b+QvZn//Z",
        cc._RF.pop()
    }
    , {}],
    BasePlatform: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "f9235RyEdpD05sXp+4B2aOH", "BasePlatform");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
        , i = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.BasePlatform = void 0;
        var s = e("../../FBGameConfig")
          , c = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.appId = s.default.APPID,
                t.appName = s.default.APPNAME,
                t.Entry = "normal",
                t.PlayerType = "old",
                t.NewPlayer = !1,
                t.ChallengeInfo = null,
                t.switchGameInfo = null,
                t.invite_skin_data = null,
                t.$remoteData = null,
                t
            }
            return a(t, e),
            Object.defineProperty(t.prototype, "UserInfo", {
                get: function() {
                    return {
                        name: "player1",
                        id: "player1",
                        photo: "https://p3.ssl.qhimgs0.com/dr/200_200_60/t01b55e640f9ab11271.jpg",
                        friends: [],
                        lang: "en_US"
                    }
                },
                enumerable: !1,
                configurable: !0
            }),
            t.prototype.initSDK = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this.initRemoteData()];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.startGame = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.getContextId = function() {
                return ""
            }
            ,
            t.prototype.setLoading = function() {}
            ,
            t.prototype.setSessionScore = function() {}
            ,
            t.prototype.getPlatFormiOS = function() {
                return !1
            }
            ,
            t.prototype.GetFrinedsInfo = function() {
                return []
            }
            ,
            t.prototype.getEntryPointData = function() {}
            ,
            t.prototype.isTournament = function() {
                return !1
            }
            ,
            t.prototype.setTournament = function() {}
            ,
            t.prototype.getTournament = function() {
                return !0
            }
            ,
            t.prototype.postSessionScore = function(e, t) {
                void 0 === t && (t = !1)
            }
            ,
            t.prototype.postTournamentScoreAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.postSessionScoreAsync = function(e, t) {
                return void 0 === t && (t = !1),
                r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.getTournamentAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, null]
                    })
                })
            }
            ,
            t.prototype.getTournamentsAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, null]
                    })
                })
            }
            ,
            t.prototype.shareTournamentAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.joinTournamentAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.createTournamentAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.initLaeadReaty = function() {
                return !0
            }
            ,
            t.prototype.initLoeaderBoard = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.getAllTimeEntriesAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, []]
                    })
                })
            }
            ,
            t.prototype.getWeeklyEntriesAsync = function() {
                return r(this, void 0, Promise, function() {
                    return i(this, function() {
                        return [2, []]
                    })
                })
            }
            ,
            t.prototype.getAllTimeEntries = function() {
                return []
            }
            ,
            t.prototype.getWeeklyEntries = function() {
                return []
            }
            ,
            t.prototype.getWeeklyHighScore = function() {
                return 0
            }
            ,
            t.prototype.getAllTimeHighScore = function() {
                return 0
            }
            ,
            t.prototype.LoadLeaderBoard = function() {
                return !0
            }
            ,
            t.prototype.switchCtx = function(e, t) {
                return void 0 === t && (t = "default"),
                r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.chooseAsync = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.createAsync = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.MatchPlayer = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.checkMatchPlayer = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.switchGame = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.getContextPlayers = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, []]
                    })
                })
            }
            ,
            t.prototype.shareAsync = function(e) {
                return void 0 === e && (e = {}),
                r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.inviteAsync = function(e) {
                return void 0 === e && (e = {}),
                r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.shareLinkAsync = function(e) {
                return void 0 === e && (e = {}),
                r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.updateStatues = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.GetLeaderboard = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, []]
                    })
                })
            }
            ,
            t.prototype.ContextIfChanged = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.checkHomeScene = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.checkBotSubscribe = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.hasIAD = function() {
                return !0
            }
            ,
            t.prototype.hasRAD = function() {
                return !0
            }
            ,
            t.prototype.showIAD = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.showRAD = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.hideBannerAd = function() {}
            ,
            t.prototype.ShowBannerAd = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.hasPurchased = function() {
                return !0
            }
            ,
            t.prototype.purchaseAsync = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, !0]
                    })
                })
            }
            ,
            t.prototype.getPlayerId = function() {
                return "wang"
            }
            ,
            t.prototype.fetchData = function() {}
            ,
            t.prototype.LoadFBData = function() {}
            ,
            t.prototype.getHighScore = function() {
                return +localStorage.getItem("hight_score") || 0
            }
            ,
            t.prototype.setHighScore = function(e) {
                localStorage.setItem("hight_score", e + "")
            }
            ,
            t.prototype.initRemoteData = function() {
                return r(this, void 0, void 0, function() {
                    var e, t, n, o, a;
                    return i(this, function(r) {
                        switch (r.label) {
                        case 0:
                            return [4, this.getData(["user_info"])];
                        case 1:
                            e = r.sent(),
                            t = {};
                            try {
                                t = JSON.parse(e.user_info)
                            } catch (i) {}
                            n = null;
                            try {
                                n = JSON.parse(localStorage.getItem("local_user_info_" + this.getPlayerId()))
                            } catch (i) {}
                            return o = n && +n.w__tsp || -1,
                            a = t && +t.w__tsp || 0,
                            o > a && (t = n,
                            console.log("use local user_info", o, a)),
                            this.$remoteData = t || {},
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.syncRemoteData = function(e) {
                return void 0 === e && (e = !1),
                r(this, void 0, void 0, function() {
                    var t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            return this.$remoteData.w__tsp = Date.now(),
                            t = JSON.stringify(this.$remoteData),
                            [4, this.setData({
                                user_info: t
                            }, e)];
                        case 1:
                            return n.sent(),
                            localStorage.setItem("local_user_info_" + this.getPlayerId(), t),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.cr = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return this.$remoteData = {},
                            [4, this.syncRemoteData(!0)];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            Object.defineProperty(t.prototype, "remoteData", {
                get: function() {
                    return this.$remoteData
                },
                enumerable: !1,
                configurable: !0
            }),
            t.prototype.getData = function(e) {
                return r(this, void 0, void 0, function() {
                    var t, n, o, a;
                    return i(this, function() {
                        for (t = {},
                        n = 0,
                        o = e; n < o.length; n++)
                            a = o[n],
                            t[a] = localStorage.getItem(a);
                        return [2, t]
                    })
                })
            }
            ,
            t.prototype.setData = function(e, t) {
                return void 0 === t && (t = !1),
                r(this, void 0, void 0, function() {
                    var t;
                    return i(this, function() {
                        for (t in e)
                            localStorage.setItem(t, e[t]);
                        return [2]
                    })
                })
            }
            ,
            t.prototype.log = function(e, t, n) {
                void 0 === n && (n = 1),
                console.log("name", e, "data", JSON.stringify(t))
            }
            ,
            t.prototype.canAdd2HomeScreen = function() {
                return !0
            }
            ,
            t.prototype.add2HomeScreen = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, {
                            res: !0,
                            code: ""
                        }]
                    })
                })
            }
            ,
            t
        }(e("../core/Emiter").Emiter);
        n.BasePlatform = c,
        cc._RF.pop()
    }
    , {
        "../../FBGameConfig": "FBGameConfig",
        "../core/Emiter": "Emiter"
    }],
    BaseUI: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "c6e796bpy9BAaDpq8fN8Bot", "BaseUI");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        );
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var r = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t.prototype.initialize = function() {}
            ,
            t.prototype.onEnter = function(e) {
                e && e()
            }
            ,
            t.prototype.onHide = function(e) {
                e && e()
            }
            ,
            t.prototype.onExit = function() {}
            ,
            t.prototype.show = function(e) {
                this.node.active = !0,
                this.onEnter(e)
            }
            ,
            t.prototype.hide = function(e) {
                var t = this;
                this.onHide(function() {
                    t.node.active = !1,
                    e && e()
                })
            }
            ,
            t.prototype.close = function() {
                this.onExit(),
                this.node.removeFromParent(),
                this.node.destroy()
            }
            ,
            t
        }(cc.Component);
        n.default = r,
        cc._RF.pop()
    }
    , {}],
    BusyIndicator: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "6983a9kns1KwLenkQ6hp8Iy", "BusyIndicator");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        );
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.BusyIndicator = void 0;
        var r = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t
        }(cc.Sprite);
        n.BusyIndicator = r,
        cc._RF.pop()
    }
    , {}],
    ConfigPreload: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "53803L6P69Gy4H02BzXkK2I", "ConfigPreload"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.JsonUrl = n.SceneName = n.UIResourceUrl = void 0,
        n.UIResourceUrl = {
            Dailiew: "UI/DailyView",
            GameView: "UI/GameView",
            LoadingView: "UI/loading_view",
            RankingList: "UI/RankingList",
            TrophyRoom: "UI/TrophyRoom"
        },
        n.SceneName = {
            Preload: "preload",
            Game: "GameScene",
            Home: "HomeScene"
        },
        n.JsonUrl = {
            CardsData: "CardsData"
        },
        cc._RF.pop()
    }
    , {}],
    Constant: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "46f9bmrl/1HaKf3LufS04iQ", "Constant"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.Constant = void 0,
        function(e) {
            (function(e) {
                e[e.startup = 0] = "startup",
                e[e.game_ready = 1] = "game_ready",
                e[e.game_over = 2] = "game_over"
            }
            )(e.Notify || (e.Notify = {})),
            e.context_template = {
                heart: "heart",
                challenge: "challenge",
                challenge_result: "challenge_result",
                auto_choose: "auto_choose",
                share_link: "share_Link",
                invite: "invite",
                skin_invite: "skin_invite",
                home_share: "home_share"
            },
            e.LogEvent = {
                add_home_screen: "add_home_screen",
                game_loading: "game_loading",
                play_times: "play_times",
                level: "level",
                dead: "dead"
            },
            e.SAME_CONTEXT = "SAME_CONTEXT",
            e.USER_INPUT = "USER_INPUT"
        }(n.Constant || (n.Constant = {})),
        cc._RF.pop()
    }
    , {}],
    Emiter: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "0ac04R7SU5MJIzHf9ryw5eg", "Emiter"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.Emiter = void 0;
        var o = function() {
            function e() {
                this.maps = {},
                this.uid = 0,
                this._duringEmit = !1
            }
            return e.prototype.add = function(e, t, n, o, a) {
                n = n || null,
                o = o || 0;
                var r = this.uid++
                  , i = this.maps[e] || [];
                return i.push([r, t, n, o, a]),
                this.maps[e] = i,
                i.sort(function(e, t) {
                    return e[3] < t[3]
                }),
                r
            }
            ,
            e.prototype.on = function(e, t, n, o) {
                return this.add(e, t, n, o, !1)
            }
            ,
            e.prototype.once = function(e, t, n, o) {
                return this.add(e, t, n, o, !0)
            }
            ,
            e.prototype.rm = function(e, t) {
                for (var n = 0, o = t ? [t] : Object.keys(this.maps); n < o.length; n++) {
                    var a = o[n]
                      , r = this.maps[a];
                    if (r) {
                        this._duringEmit && (this.maps[a] = r = r.concat());
                        for (var i = 0; i < r.length; ) {
                            var s = r[i]
                              , c = s[0];
                            if (s[1],
                            s[2],
                            s[3],
                            s[4],
                            c == e)
                                return r.splice(i, 1),
                                !0;
                            i++
                        }
                    }
                }
                return !1
            }
            ,
            e.prototype.rmall = function(e) {
                null == e ? this.maps = {} : delete this.maps[e]
            }
            ,
            e.prototype.emit = function(t, n) {
                var o = this.maps[t];
                if (o && o.length > 0) {
                    for (var a = 0; a < o.length; ) {
                        var r = o[a]
                          , i = (r[0],
                        r[1])
                          , s = r[2];
                        r[3],
                        r[4] ? o.splice(a, 1) : a++,
                        this._duringEmit = !0;
                        var c = i.call(s, n);
                        if (this._duringEmit = !1,
                        c == e.CONST.break)
                            break
                    }
                    return !0
                }
                return !1
            }
            ,
            e.CONST = {
                break: {}
            },
            e
        }();
        n.Emiter = o,
        cc._RF.pop()
    }
    , {}],
    Event: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "680534VzEhPc58CkpiLbvNG", "Event");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        );
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var r = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.eventList = {},
                t
            }
            return a(t, e),
            t.prototype.emit = function(e) {
                for (var t = [], n = 1; n < arguments.length; n++)
                    t[n - 1] = arguments[n];
                var o = this.eventList[e];
                if (null != o)
                    for (var a, r, i = o.length, s = 0; s < i; s++) {
                        var c = o[s];
                        a = c[0],
                        r = c[1],
                        a.apply(r, t)
                    }
            }
            ,
            t.prototype.on = function(e, t, n) {
                var o = this.eventList[e];
                if (null == o)
                    o = [],
                    this.eventList[e] = o;
                else
                    for (var a = o.length, r = 0; r < a; r++)
                        if (o[r][0] == t && o[r][1] == n)
                            return;
                o.push([t, n])
            }
            ,
            t.prototype.once = function(e, t, n) {
                var o = void 0;
                o = this.on(e, function() {
                    for (var e = [], a = 0; a < arguments.length; a++)
                        e[a] = arguments[a];
                    t.apply(n, e),
                    o()
                }, n)
            }
            ,
            t.prototype.off = function(e, t, n) {
                var o = this.eventList[e];
                if (null != o)
                    for (var a = o.length - 1; a >= 0; a--)
                        o[a][0] == t && o[a][1] == n && o.splice(a, 1);
                o && 0 == o.length && (this.eventList[e] = null,
                delete this.eventList[e])
            }
            ,
            t.prototype.getEventNames = function() {
                var e = [];
                for (var t in this.eventList)
                    e.push(t);
                return e
            }
            ,
            t.prototype.eventNames = function() {
                return this.getEventNames()
            }
            ,
            t
        }(e("./Singleton").default);
        n.default = r,
        cc._RF.pop()
    }
    , {
        "./Singleton": "Singleton"
    }],
    Extension: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "160c8gCXg9Fu68fdDsaXkdf", "Extension");
        var o = this && this.__spreadArrays || function() {
            for (var e = 0, t = 0, n = arguments.length; t < n; t++)
                e += arguments[t].length;
            var o = Array(e)
              , a = 0;
            for (t = 0; t < n; t++)
                for (var r = arguments[t], i = 0, s = r.length; i < s; i++,
                a++)
                    o[a] = r[i];
            return o
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.closure = n.waitAsync = void 0,
        n.waitAsync = function(e, t) {
            return new Promise(function(n) {
                setTimeout(function() {
                    t && t(),
                    n()
                }, e)
            }
            )
        }
        ,
        n.closure = function(e) {
            for (var t = [], n = 1; n < arguments.length; n++)
                t[n - 1] = arguments[n];
            return function() {
                for (var n = [], a = 0; a < arguments.length; a++)
                    n[a] = arguments[a];
                return e.apply(null, o(t, n))
            }
        }
        ,
        Date.prototype.format = function(e) {
            var t = {
                "M+": this.getMonth() + 1,
                "d+": this.getDate(),
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                S: this.getMilliseconds()
            };
            for (var n in /(y+)/.test(e) && (e = e.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length))),
            t)
                new RegExp("(" + n + ")").test(e) && (e = e.replace(RegExp.$1, 1 == RegExp.$1.length ? t[n] : ("00" + t[n]).substr(("" + t[n]).length)));
            return e
        }
        ,
        Date.week = function(e) {
            return void 0 === e && (e = 2521),
            ~~((Date.now() + -252e5 + 864e5) / 6048e5) - e - 1
        }
        ,
        Date.days = function(e) {
            return void 0 === e && (e = 0),
            ~~((Date.now() + -252e5 + 864e5) / 864e5) - e - 1
        }
        ,
        String.prototype.substitute = function(e) {
            return this.replace(/\{(.+?)\}/gi, function(t, n) {
                return e[n]
            })
        }
        ,
        Object.defineProperty(Array.prototype, "random", {
            configurable: !0,
            writable: !0,
            value: function(e) {
                if (void 0 === e && (e = !1),
                0 == this.length)
                    return null;
                var t = Math.floor(this.length * Math.random());
                return this[t],
                e && this.splice(t, 1),
                this[t]
            }
        }),
        Object.defineProperty(Array.prototype, "choice", {
            value: function(e) {
                if (0 == this.length)
                    return null;
                null == e && (e = function(e) {
                    return e
                }
                );
                for (var t = this.reduce(function(t, n) {
                    return t + e(n)
                }, 0) * Math.random(), n = this.length, o = 0; o < n; o++) {
                    var a = e(this[o]);
                    if (t < a)
                        return this[o];
                    t -= a
                }
                return this[n - 1]
            },
            configurable: !0,
            writable: !0
        }),
        Object.defineProperty(Array.prototype, "unique", {
            value: function() {
                for (var e = [], t = 0; t < this.length; )
                    e.indexOf(this[t]) >= 0 ? this.splice(t, 1) : e.push(this[t++]);
                return this
            },
            configurable: !0,
            writable: !0
        }),
        Object.defineProperty(Array.prototype, "sorton", {
            configurable: !0,
            writable: !0,
            value: function(e, t) {
                return void 0 === t && (t = !0),
                this.sort(function(n, o) {
                    var a = n[e] || 0
                      , r = o[e] || 0
                      , i = a > r ? 1 : a < r ? -1 : 0;
                    return t || (i *= -1),
                    i
                })
            }
        }),
        Object.defineProperty(Array.prototype, "shuffle", {
            configurable: !0,
            writable: !0,
            value: function() {
                for (var e, t = this.length - 1; t > 0; t--) {
                    var n = Math.floor(Math.random() * (t + 1));
                    e = [this[n], this[t]],
                    this[t] = e[0],
                    this[n] = e[1]
                }
                return this
            }
        }),
        Object.defineProperty(Array.prototype, "rm", {
            configurable: !0,
            writable: !0,
            value: function(e) {
                for (var t = "function" == typeof e ? e : function(t) {
                    return t == e
                }
                , n = 0; n < this.length; ) {
                    if (t(this[n]))
                        return this.splice(n, 1),
                        this;
                    n++
                }
                return this
            }
        }),
        Math.randInt = function(e, t) {
            return void 0 === e && (e = 0),
            void 0 === t && (t = 10),
            Math.floor(Math.random() * (t - e + 1)) + e
        }
        ,
        Math.clamp = function(e, t, n) {
            return Math.max(t, Math.min(e, n))
        }
        ,
        "function" != typeof Object.assign && Object.defineProperty(Object, "assign", {
            value: function(e) {
                if (null == e)
                    throw new TypeError("Cannot convert undefined or null to object");
                for (var t = Object(e), n = 1; n < arguments.length; n++) {
                    var o = arguments[n];
                    if (null != o)
                        for (var a in o)
                            Object.prototype.hasOwnProperty.call(o, a) && (t[a] = o[a])
                }
                return t
            },
            writable: !0,
            configurable: !0
        }),
        n.default = {},
        cc._RF.pop()
    }
    , {}],
    FBGameConfig: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "d79d1tBKhBNyJtBuNbJr1eI", "FBGameConfig"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var o = function() {
            function e() {}
            return e.APPID = "1250485232472279",
            e.APPNAME = "Moto Race",
            e.BOT_ID = "3032",
            e.PL_HOST = "https://api.hotbloodgame.com",
            e.BOT_HOST = "https://bot.hotbloodgame.com",
            e.LarGame_ID = "3032",
            e.FB_ADCheck = "72279",
            e.FB_ADChaping = ["1250485232472279_1250490782471724"],
            e.FB_ADVideo = ["1250485232472279_1250490979138371"],
            e.FB_Banner = "",
            e.InitADTime = 600,
            e.ShowADTime = 600,
            e
        }();
        n.default = o,
        cc._RF.pop()
    }
    , {}],
    Flash: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "f84d2ibpapGiIHrqpc2XdlQ", "Flash");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = cc._decorator
          , s = i.ccclass
          , c = (i.property,
        function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.duration = 0,
                t._median = 0,
                t._time = 0,
                t._material = null,
                t.nums = -1,
                t
            }
            return a(t, e),
            t.prototype.onLoad = function() {}
            ,
            t.prototype.update = function(e) {
                if (-1 == this.nums && (.2 == this.duration ? this.nums = 0 : .5 == this.duration && (this.nums = 10)),
                this._time > 0) {
                    this._time -= e,
                    this._time = this._time < 0 ? 0 : this._time;
                    var t = 2 * Math.abs(this._time - this._median) / this.duration;
                    this._material.setProperty("u_rate", t),
                    0 == this._time && (this.nums += 1,
                    this.nums < 3 ? this.startToFlash(.2) : this.nums = -1)
                }
            }
            ,
            t.prototype.startToFlash = function(e) {
                this.duration = e,
                this._median = this.duration / 2,
                this.node.getComponent(cc.Sprite) ? this._material = this.node.getComponent(cc.Sprite).getMaterial(0) : this._material = this.node.getComponent(dragonBones.ArmatureDisplay).getMaterial(0),
                this._material && this._material.setProperty("u_rate", 1),
                this._time = this.duration
            }
            ,
            r([s], t)
        }(cc.Component));
        n.default = c,
        cc._RF.pop()
    }
    , {}],
    FriendLeaderboard: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "a3d7eEUEkpCYLAVHFa9XLIA", "FriendLeaderboard");
        var o = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
          , a = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
          , r = this && this.__spreadArrays || function() {
            for (var e = 0, t = 0, n = arguments.length; t < n; t++)
                e += arguments[t].length;
            var o = Array(e)
              , a = 0;
            for (t = 0; t < n; t++)
                for (var r = arguments[t], i = 0, s = r.length; i < s; i++,
                a++)
                    o[a] = r[i];
            return o
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.FriendLeaderboard = void 0;
        var i = e("../core/Storager")
          , s = e("./RankPlayerVO")
          , c = e("../core/Http")
          , l = function() {
            function e(e, t) {
                this.pl_host = e,
                this.game_id = t,
                this.platform = "instant",
                this.game = "web",
                this._initialized = !1,
                this.localDB = new i.Storager("selfrank_" + FBInstant.player.getID()),
                this.localData = this.localDB.json("data")
            }
            return e.prototype.setFriends = function(e) {
                this.friends = e
            }
            ,
            e.prototype.initializeAsync = function() {
                return o(this, void 0, void 0, function() {
                    var e, t, n, o, r;
                    return a(this, function(i) {
                        switch (i.label) {
                        case 0:
                            if (this._initialized)
                                return [2];
                            i.label = 1;
                        case 1:
                            return i.trys.push([1, 7, , 8]),
                            this.friends ? [3, 3] : (e = this,
                            [4, FBInstant.player.getConnectedPlayersAsync()]);
                        case 2:
                            e.friends = i.sent(),
                            i.label = 3;
                        case 3:
                            t = 2,
                            n = function() {
                                var e, t, n;
                                return a(this, function(a) {
                                    switch (a.label) {
                                    case 0:
                                        return a.trys.push([0, 2, , 3]),
                                        [4, o.fetchRank()];
                                    case 1:
                                        return e = a.sent(),
                                        o._weeklyEntries = e.frindEntries,
                                        o._allTimeEntries = e.worldEntries,
                                        o._weeklyEntries.forEach(function(e, t) {
                                            return e.rank = t + 1
                                        }),
                                        o._allTimeEntries.forEach(function(e, t) {
                                            return e.rank = t + 1
                                        }),
                                        t = FBInstant.player.getID(),
                                        o._weeklyEntry = o._weeklyEntries.find(function(e) {
                                            return e.id == t
                                        }),
                                        o._allTimeEntry = o._allTimeEntries.find(function(e) {
                                            return e.id == t
                                        }),
                                        [2, "break"];
                                    case 2:
                                        return n = a.sent(),
                                        console.log("fetch rank error", n),
                                        [3, 3];
                                    case 3:
                                        return [2]
                                    }
                                })
                            }
                            ,
                            o = this,
                            i.label = 4;
                        case 4:
                            return t-- > 0 ? [5, n()] : [3, 6];
                        case 5:
                            return "break" === i.sent() ? [3, 6] : [3, 4];
                        case 6:
                            return this._initialized = !0,
                            [3, 8];
                        case 7:
                            return r = i.sent(),
                            console.log("leaderboad initlialize failed:", r),
                            [3, 8];
                        case 8:
                            return [2]
                        }
                    })
                })
            }
            ,
            e.prototype.initLaeadReaty = function() {
                return this._initialized
            }
            ,
            e.prototype.fetchRank = function() {
                return o(this, void 0, void 0, function() {
                    var e, t, n, o, r, i, l, u, p, d, f, h, m, y;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            return this.localData && Date.now() - this.localData.timestamp < 18e5 ? (console.log("use cache"),
                            console.log(this.localData),
                            e = this.localData.result,
                            [3, 5]) : [3, 1];
                        case 1:
                            t = this.pl_host + "/fbapi/v0/get_rankInfo_" + this.game_id,
                            n = this.friends.map(function(e) {
                                return e.getID()
                            }),
                            o = FBInstant.player.getID(),
                            n.push(o),
                            r = {
                                game_id: this.game_id,
                                platform: this.platform,
                                game: this.game,
                                playerId: o,
                                token: this._token,
                                type: ["Instant_games_rankInfo_all", "Instant_games_rankInfo_week"],
                                players: n
                            },
                            a.label = 2;
                        case 2:
                            return a.trys.push([2, 4, , 5]),
                            l = (i = JSON).parse,
                            [4, (new c.Http).post(t, r)];
                        case 3:
                            if (0 != (e = l.apply(i, [a.sent()])).error)
                                throw "getRankInfo failed";
                            return this.localData = {
                                timestamp: Date.now(),
                                result: e
                            },
                            this.localDB.set("data", this.localData),
                            [3, 5];
                        case 4:
                            return a.sent(),
                            console.log("rank load failed"),
                            e = this.localData ? this.localData.result : {
                                data: {}
                            },
                            [3, 5];
                        case 5:
                            for (m in u = e.data.Instant_games_rankInfo_week || {},
                            p = e.data.Instant_games_rankInfo_all || {},
                            d = {},
                            this.friends.forEach(function(e) {
                                return d[e.getID()] = e
                            }),
                            d[FBInstant.player.getID()] = FBInstant.player,
                            f = Object.keys(u).map(function(e) {
                                var t = JSON.parse(u[e]);
                                t.id = e;
                                var n = s.RankPlayerVO.fromJSONObj(t)
                                  , o = d[t.id];
                                return o && (n.name = o.getName(),
                                n.photo = o.getPhoto(),
                                delete d[t.id]),
                                n
                            }).sorton("score", !1),
                            d)
                                y = d[m],
                                f.push(s.RankPlayerVO.createFromContextPlayer(y));
                            for (m in d = {},
                            this.friends.forEach(function(e) {
                                return d[e.getID()] = e
                            }),
                            d[FBInstant.player.getID()] = FBInstant.player,
                            h = Object.keys(p).map(function(e) {
                                var t = JSON.parse(p[e]);
                                t.id = e;
                                var n = s.RankPlayerVO.fromJSONObj(t)
                                  , o = d[t.id];
                                return o && (n.name = o.getName(),
                                n.photo = o.getPhoto(),
                                delete d[t.id]),
                                n
                            }).sorton("score", !1),
                            d)
                                y = d[m],
                                h.push(s.RankPlayerVO.createFromContextPlayer(y));
                            return [2, {
                                frindEntries: f,
                                worldEntries: h
                            }]
                        }
                    })
                })
            }
            ,
            e.prototype.setScoreAsync = function(e, t) {
                return o(this, void 0, void 0, function() {
                    var n, o, r, i, l, u, p, d;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            return a.trys.push([0, 2, , 3]),
                            n = !1,
                            o = [],
                            e > this.getAllTimeHighScore() && (o.push("Instant_games_rankInfo_all"),
                            this._allTimeEntry || (this._allTimeEntry = s.RankPlayerVO.createFromContextPlayer(FBInstant.player)),
                            this._allTimeEntry.score = e,
                            this._allTimeEntry.extraData = t,
                            this._allTimeEntries && this._allTimeEntries.sorton("score", !1),
                            this.localData && ((r = this.localData.result.data.Instant_games_rankInfo_all || {})[this._allTimeEntry.id] = JSON.stringify(this._allTimeEntry.toJSONObj()),
                            this.localData.result.data.Instant_games_rankInfo_all = r,
                            n = !0)),
                            e > this.getWeeklyHighScore() && (o.push("Instant_games_rankInfo_week"),
                            this._weeklyEntry || (this._weeklyEntry = s.RankPlayerVO.createFromContextPlayer(FBInstant.player)),
                            this._weeklyEntry.score = e,
                            this._weeklyEntry.extraData = t,
                            this._weeklyEntries && this._weeklyEntries.sorton("score", !1),
                            this.localData && ((i = this.localData.result.data.Instant_games_rankInfo_week || {})[this._weeklyEntry.id] = JSON.stringify(this._weeklyEntry.toJSONObj()),
                            this.localData.result.data.Instant_games_rankInfo_week = i,
                            n = !0)),
                            n && this.localDB.set("data", JSON.stringify(this.localData)),
                            0 == o.length ? [2] : (l = this.pl_host + "/fbapi/v0/update_rankInfo_" + this.game_id,
                            u = {
                                game_id: this.game_id,
                                platform: this.platform,
                                game: this.game,
                                token: this._token,
                                playerId: FBInstant.player.getID(),
                                type: o,
                                rankInfo: JSON.stringify({
                                    score: e,
                                    extraData: t
                                })
                            },
                            d = (p = JSON).parse,
                            [4, (new c.Http).post(l, u)]);
                        case 1:
                            if (0 != d.apply(p, [a.sent()]).error)
                                throw "update_rankInfo error";
                            return [3, 3];
                        case 2:
                            return a.sent(),
                            console.log("set core error"),
                            [3, 3];
                        case 3:
                            return [2]
                        }
                    })
                })
            }
            ,
            e.prototype.getAllTimeEntriesAsync = function() {
                return o(this, void 0, Promise, function() {
                    return a(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this.initializeAsync()];
                        case 1:
                            return e.sent(),
                            [2, this._allTimeEntries || r(this.friends, [FBInstant.player]).map(function(e) {
                                return s.RankPlayerVO.createFromContextPlayer(e)
                            })]
                        }
                    })
                })
            }
            ,
            e.prototype.getAllTimeEntries = function() {
                return this._allTimeEntries || []
            }
            ,
            e.prototype.getWeeklyEntriesAsync = function() {
                return o(this, void 0, Promise, function() {
                    return a(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this.initializeAsync()];
                        case 1:
                            return e.sent(),
                            [2, this._weeklyEntries || r(this.friends, [FBInstant.player]).map(function(e) {
                                return s.RankPlayerVO.createFromContextPlayer(e)
                            })]
                        }
                    })
                })
            }
            ,
            e.prototype.getWeeklyEntries = function() {
                return this._weeklyEntries || []
            }
            ,
            e.prototype.getAllTimeHighScore = function() {
                return this._allTimeEntry ? this._allTimeEntry.score : 0
            }
            ,
            e.prototype.getWeeklyHighScore = function() {
                return this._weeklyEntry ? this._weeklyEntry.score : 0
            }
            ,
            e
        }();
        n.FriendLeaderboard = l,
        cc._RF.pop()
    }
    , {
        "../core/Http": "Http",
        "../core/Storager": "Storager",
        "./RankPlayerVO": "RankPlayerVO"
    }],
    GameConnect: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "d868eSZ0N9AvKQYscqwU6Me", "GameConnect");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
        , i = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var s = e("./Module/Constant")
          , c = e("./Module/platform/PlatformFB")
          , l = e("./Module/share/ShareHelper")
          , u = e("./FBGameConfig")
          , p = function(e) {
            function t() {
                var t = e.call(this) || this;
                return t._deadCount = 0,
                t.pendingChallengePost = !1,
                t.InitConnect(),
                t
            }
            return a(t, e),
            t.prototype.InitConnect = function() {
                t.iPhoneH = 0,
                t.iPhoneW = 0,
                t.NowGate = 1,
                t.ADVideoState = 0
            }
            ,
            t.prototype.GetiPhoneH = function() {
                return t.iPhoneH = cc.winSize.height - 1136,
                console.log("GameConnect.iPhoneH : " + t.iPhoneH),
                t.iPhoneH
            }
            ,
            t.prototype.GetiPhoneW = function() {
                return 1
            }
            ,
            t.prototype.GetPlatForm = function() {
                return 1 == platform.getPlatFormiOS() ? 1 : 0
            }
            ,
            t.prototype.OpenMyBot = function() {
                platform.checkBotSubscribe()
            }
            ,
            t.prototype.AutoEnterGame = function() {
                return !platform.NewPlayer && !!platform.getContextId()
            }
            ,
            t.prototype.GetMoregameConfig = function() {
                return {
                    alljsonUrl: "https://hotblood.oss-us-west-1.aliyuncs.com/inducement/mesapp/gamejson/mesappjson.json",
                    jsonUrl: "https://hotblood.oss-us-west-1.aliyuncs.com/inducement/mesapp/gamejson/mesappjson" + u.default.LarGame_ID + ".json",
                    imgUrl: "https://hotblood.oss-us-west-1.aliyuncs.com/inducement/mesapp/gamebanner/"
                }
            }
            ,
            t.prototype.GetMoreGame = function() {
                return [{
                    gameid: "438262220913036",
                    id: 1,
                    name: "Shot Shot",
                    texture: ""
                }, {
                    gameid: "385207979248294",
                    id: 2,
                    name: "Axe Master",
                    texture: ""
                }, {
                    gameid: "143095279886626",
                    id: 3,
                    name: "Road Race.io",
                    texture: ""
                }, {
                    gameid: "3964208010267825",
                    id: 4,
                    name: "Rush Race",
                    texture: ""
                }]
            }
            ,
            t.prototype.OpenMoreGame = function(e) {
                return r(this, void 0, void 0, function() {
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return [4, platform.switchGame(e)];
                        case 1:
                            return [2, t.sent()]
                        }
                    })
                })
            }
            ,
            t.prototype.CheckMatchPlayer = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, platform.checkMatchPlayer()];
                        case 1:
                            return [2, e.sent()]
                        }
                    })
                })
            }
            ,
            t.prototype.MatchPlayer = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return platform instanceof c.PlatformFB ? [4, platform.MatchPlayer()] : [3, 2];
                        case 1:
                            return e = t.sent(),
                            console.log(e),
                            [2, e];
                        case 2:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.ShareGame = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, l.ShareHelper.sendGenericUpdate(s.Constant.context_template.home_share, null, !0)];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.ChallengeGame = function(e) {
                return r(this, void 0, void 0, function() {
                    var t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            return [4, platform.createAsync(e)];
                        case 1:
                            return t = n.sent(),
                            this.pendingChallengePost = !0,
                            [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.ShowADChaping = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return HUHU_showInterstitialAd(),console.log("\u5f00\u542f\u63d2\u5c4f\u5e7f\u544a"),
                            platform.hasIAD() ? [4, platform.showIAD()] : [2];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.ShowADVideo = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2, new Promise(function(e, n) {
                            console.log("\u5f00\u542f\u89c6\u9891\u5e7f\u544a"),
                            t.ADVideoState = -1,
							HUHU_showRewardedVideoAd(()=>{
								t.ADVideoState = 1,
                                e()
							},()=>{
								n(),
                                t.ADVideoState = 0
								promptTxT("No ads temporarily")
							})
                        }
                        )]
                    })
                })
            }
            ,
            t.prototype.GetADVideoState = function() {
                return t.ADVideoState
            }
            ,
            t.prototype.SignInGameCenter = function() {
                console.log("\u767b\u5f55\u6392\u884c\u699c")
            }
            ,
            t.prototype.UpLoadScore = function(e, t) {
                return r(this, void 0, void 0, function() {
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            return console.log("\u4e0a\u4f20\u5206\u6570" + e),
                            [4, platform.setHighScore(e, t)];
                        case 1:
                            return n.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.GetMyID = function() {
                return platform.UserInfo.id
            }
            ,
            t.prototype.GetMyName = function() {
                return platform.UserInfo.name
            }
            ,
            t.prototype.GetMyImage = function() {
                return platform.UserInfo.photo
            }
            ,
            t.prototype.GetWeeklyRankList = function() {
                return platform.getWeeklyEntries()
            }
            ,
            t.prototype.GetAllTimeRankList = function() {
                return platform.getAllTimeEntries()
            }
            ,
            t.prototype.GetUserName = function(e) {
                return 1 == e ? this.GetWeeklyRankList().map(function(e) {
                    return e.name
                }) : this.GetAllTimeRankList().map(function(e) {
                    return e.name
                })
            }
            ,
            t.prototype.GetUserID = function(e) {
                return 1 == e ? this.GetWeeklyRankList().map(function(e) {
                    return e.id
                }) : this.GetAllTimeRankList().map(function(e) {
                    return e.id
                })
            }
            ,
            t.prototype.GetUserImage = function(e) {
                return 1 == e ? this.GetWeeklyRankList().map(function(e) {
                    return e.photo
                }) : this.GetAllTimeRankList().map(function(e) {
                    return e.photo
                })
            }
            ,
            t.prototype.GetUserScore = function(e) {
                return 1 == e ? this.GetWeeklyRankList().map(function(e) {
                    return e.score
                }) : this.GetAllTimeRankList().map(function(e) {
                    return e.score
                })
            }
            ,
            t.prototype.GetUserSkin = function(e) {
                return 1 == e ? this.GetWeeklyRankList().map(function(e) {
                    return e.skin
                }) : this.GetAllTimeRankList().map(function(e) {
                    return e.skin
                })
            }
            ,
            t.prototype.getTournamentAsync = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, platform.getTournamentAsync()];
                        case 1:
                            return [2, e.sent()]
                        }
                    })
                })
            }
            ,
            t.prototype.TournamentPoint = function() {
                return platform.getTournament()
            }
            ,
            t.prototype.IsTournament = function() {
                return platform.isTournament()
            }
            ,
            t.prototype.CreateGame = function(e) {
                return r(this, void 0, void 0, function() {
                    var t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            return t = platform.getContextId(),
                            console.log("contextIDAA: " + t),
                            [4, platform.switchCtx(e)];
                        case 1:
                            return [2, n.sent()]
                        }
                    })
                })
            }
            ,
            t.prototype.postTournamentScoreAsync = function(e) {
                return r(this, void 0, Promise, function() {
                    var t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            if (t = !1,
                            !(platform instanceof c.PlatformFB))
                                return [3, 4];
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, platform.postTournamentScoreAsync(e)];
                        case 2:
                            return t = n.sent(),
                            [3, 4];
                        case 3:
                            return n.sent(),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.CreateTournamentAsync = function(e, t, n) {
                return r(this, void 0, Promise, function() {
                    var o;
                    return i(this, function(a) {
                        switch (a.label) {
                        case 0:
                            if (o = !1,
                            !(platform instanceof c.PlatformFB))
                                return [3, 4];
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 3, , 4]),
                            [4, platform.createTournamentAsync(e, t, n)];
                        case 2:
                            return o = a.sent(),
                            [3, 4];
                        case 3:
                            return a.sent(),
                            [3, 4];
                        case 4:
                            return [2, o]
                        }
                    })
                })
            }
            ,
            t.prototype.ShareTournamentAsync = function(e) {
                return r(this, void 0, Promise, function() {
                    var t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            if (t = !1,
                            !(platform instanceof c.PlatformFB))
                                return [3, 4];
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, platform.shareTournamentAsync(e)];
                        case 2:
                            return t = n.sent(),
                            [3, 4];
                        case 3:
                            return n.sent(),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.JointTournamentAsync = function(e) {
                return r(this, void 0, Promise, function() {
                    var t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            if (t = !1,
                            !(platform instanceof c.PlatformFB))
                                return [3, 4];
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, platform.joinTournamentAsync(e)];
                        case 2:
                            return t = n.sent(),
                            [3, 4];
                        case 3:
                            return n.sent(),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.GetFriendsTournamentsAsync = function() {
                return r(this, void 0, Promise, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            if (e = null,
                            !(platform instanceof c.PlatformFB))
                                return [3, 4];
                            t.label = 1;
                        case 1:
                            return t.trys.push([1, 3, , 4]),
                            [4, platform.getTournamentsAsync()];
                        case 2:
                            return e = t.sent(),
                            [3, 4];
                        case 3:
                            return t.sent(),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.GetTournamentAsync = function() {
                return r(this, void 0, Promise, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            if (e = null,
                            !(platform instanceof c.PlatformFB))
                                return [3, 4];
                            t.label = 1;
                        case 1:
                            return t.trys.push([1, 3, , 4]),
                            [4, platform.getTournamentAsync()];
                        case 2:
                            return e = t.sent(),
                            [3, 4];
                        case 3:
                            return t.sent(),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.UpSessionScoreAsync = function(e, t) {
                return void 0 === t && (t = !1),
                r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return console.log("\u4e0a\u4f20\u4f1a\u8bdd\u5206\u6570"),
                        platform.isTournament() ? platform.postSessionScoreAsync(e, !0) : this.CreateTournamentAsync(e),
                        [2]
                    })
                })
            }
            ,
            t.prototype.LoadContextIds = function() {
                return platform.remoteData.group_context || []
            }
            ,
            t.prototype.initLoeaderBoard = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return e.trys.push([0, 2, , 3]),
                            [4, platform.initLoeaderBoard()];
                        case 1:
                            return e.sent(),
                            [3, 3];
                        case 2:
                            return e.sent(),
                            console.log("tournament init error:"),
                            [3, 3];
                        case 3:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.initLoeadReaty = function() {
                return platform.initLaeadReaty()
            }
            ,
            t.prototype.UploadEvent = function(e, t, n) {
                void 0 === n && (n = 1),
                platform.log(e, t, n)
            }
            ,
            t.prototype.GetNewDays = function() {
                if (console.log("Day:" + platform.remoteData.loginTime),
                console.log("Day2:" + Date.days()),
                Date.days() != platform.remoteData.loginTime)
                    return platform.remoteData.loginTime = Date.days(),
                    platform.syncRemoteData(),
                    !0
            }
            ,
            t.prototype.readData = function() {
                return platform.remoteData.game_db || {}
            }
            ,
            t.prototype.setData = function(e) {
                platform.remoteData.game_db = e,
                platform.syncRemoteData()
            }
            ,
            t.prototype.onDead = function() {
                platform.log(s.Constant.LogEvent.dead, {
                    result: ++this._deadCount
                })
            }
            ,
            t.prototype.setCurentScore = function(e) {
                t.NowGate = e
            }
            ,
            t.prototype.getCurentScore = function() {
                return t.NowGate
            }
            ,
            t.prototype.getInviteCount = function() {
                return platform.remoteData.skin_invites || (platform.remoteData.skin_invites = []),
                platform.remoteData.skin_invites.length
            }
            ,
            t.prototype.pullInviteCount = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function() {
                        return [2]
                    })
                })
            }
            ,
            t.prototype.shareLink = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            if (!(platform instanceof c.PlatformFB))
                                return [3, 4];
                            e.label = 1;
                        case 1:
                            return e.trys.push([1, 3, , 4]),
                            [4, l.ShareHelper.shareLink(s.Constant.context_template.share_link)];
                        case 2:
                        case 3:
                            return e.sent(),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.shareInvite = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            if (!(platform instanceof c.PlatformFB))
                                return [3, 4];
                            e.label = 1;
                        case 1:
                            return e.trys.push([1, 3, , 4]),
                            [4, l.ShareHelper.invite(s.Constant.context_template.invite)];
                        case 2:
                        case 3:
                            return e.sent(),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.showChoose = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            if (!(platform instanceof c.PlatformFB))
                                return [3, 4];
                            e.label = 1;
                        case 1:
                            return e.trys.push([1, 3, , 4]),
                            [4, platform.chooseAsync()];
                        case 2:
                            return e.sent(),
                            l.ShareHelper.sendGenericUpdate(s.Constant.context_template.auto_choose),
                            [3, 4];
                        case 3:
                            return e.sent(),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.suportIAP = function() {
                return !1
            }
            ,
            t.prototype.purchaseRemoveAD = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, platform.purchaseAsync("1")];
                        case 1:
                            return [2, e.sent()]
                        }
                    })
                })
            }
            ,
            t.prototype.hasPurchasedRemoveAD = function() {
                return platform.hasPurchased("1")
            }
            ,
            t.prototype.getVersion = function() {
                return $T_GAME_VERSION
            }
            ,
            t.prototype.hasContext = function() {
                return !!platform.getContextId()
            }
            ,
            t.prototype.canAutoChallengePost = function() {
                var e = this.pendingChallengePost;
                return console.log("canAutoChallengePost", e),
                this.pendingChallengePost = !1,
                e
            }
            ,
            t.prototype.onRecommendGameTapped = function(e) {
                platform.switchGame(e)
            }
            ,
            t.prototype.getLoginDays = function() {
                return platform.remoteData.login_day_count || 0
            }
            ,
            t.prototype.addShortcut = function() {
                return r(this, void 0, void 0, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            return console.log("addShortcut...."),
                            console.log(platform.remoteData.add_hs_refuse_count),
                            console.log(platform.remoteData.add_hs),
                            console.log(platform.canAdd2HomeScreen()),
                            platform.remoteData.add_hs_refuse_count >= 2 ? [2] : 0 != platform.remoteData.add_hs ? [2] : platform.canAdd2HomeScreen() ? (e = platform.PlayerType,
                            platform.log(s.Constant.LogEvent.add_home_screen, {
                                user_type: e,
                                result: -1
                            }),
                            [4, platform.add2HomeScreen()]) : [2];
                        case 1:
                            return (t = n.sent()).res ? (platform.remoteData.add_hs = 1,
                            platform.log(s.Constant.LogEvent.add_home_screen, {
                                user_type: e,
                                result: 1
                            })) : (t.code == s.Constant.USER_INPUT ? platform.remoteData.add_hs_refuse_count++ : platform.remoteData.add_hs = 2,
                            platform.log(s.Constant.LogEvent.add_home_screen, {
                                user_type: e,
                                result: 0,
                                code: t.code
                            })),
                            platform.syncRemoteData(),
                            [2]
                        }
                    })
                })
            }
            ,
            t
        }(e("./Module/Extension/Singleton").default);
        n.default = p,
        cc._RF.pop()
    }
    , {
        "./FBGameConfig": "FBGameConfig",
        "./Module/Constant": "Constant",
        "./Module/Extension/Singleton": "Singleton",
        "./Module/platform/PlatformFB": "PlatformFB",
        "./Module/share/ShareHelper": "ShareHelper"
    }],
    GameMessage: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "f0f0a0L/P5MB4Q+EIZT9VG6", "GameMessage"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var o = function() {
            function e() {
                this.nodeName = [],
                this.nodeStateX = [],
                this.nodeStateY = [],
                this.nodeStateScaleX = [],
                this.nodeStateScaleY = []
            }
            return e.prototype.SetGate = function(e) {
                switch (e) {
                case 1:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_1_E", "map3", "map3", "map2_2_S", "map2", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_2_E", "map6", "map6", "map2_3_S", "map2", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2", "map2_3_E", "map6", "map7_7_S", "map7_7_E", "map6", "map2_6_S", "map2", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_6_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2200, 2600, 3e3, 3400, 3800, 4150.5, 4451.5, 4802, 5202, 5602, 6002, 6402, 6802, 6802, 7202, 7602, 8002, 8402, 8677, 8827, 9102, 9502, 9902, 10302, 10702, 11102, 11102, 11502, 11902, 12302, 12702, 13102, 13377, 13527, 13677, 13827, 14102, 14502, 14902, 15302, 15702, 16102, 16502, 16902, 17302, 17702, 18102],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 2:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2_1_E", "map6", "map6", "map6", "map7_2_S", "map7_2_E", "map6", "map6", "map6", "map6", "map7_3_S", "map7_3_E", "map6", "map2_4_S", "map2", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_4_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 2600, 3e3, 3400, 3800, 3800, 4200, 4600, 5e3, 5400, 5800, 5800, 6200, 6600, 7e3, 7400, 7800, 7800, 8200, 8600, 9e3, 9400, 9800, 9800, 10200, 10600, 11e3, 11275, 11425, 11575, 11725, 11875, 12025, 12175, 12325, 12475, 12625, 12775, 12925, 13200, 13600, 14e3, 14400, 14800, 15200, 15600, 16e3, 16400, 16800, 17200],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, -1, 1, -1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 3:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2_1_E", "map3", "map3", "map3", "map3", "map3", "map3", "map2_2_S", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_2_E", "map6", "map7_3_S", "map7", "map7_3_E", "map6", "map2_4_S", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_4_E", "map5", "map4_6_S", "map4", "map4", "map8", "map4", "map4_6_E", "map5", "map2_5_S", "map2", "map2", "map2", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_5_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 2600, 3e3, 3400, 3800, 4150.5, 4451.5, 4752.5, 5053.5, 5354.5, 5655.5, 6006, 6406, 6806, 7206, 7206, 7606, 8006, 8406, 8806, 9081, 9231, 9381, 9531, 9681, 9956, 10356, 10756, 11156, 11556, 11556, 11956, 12356, 12756, 13156, 13756, 14306, 14606, 14906, 14906, 15206, 15506, 16056, 16656, 17056, 17456, 17856, 18256, 18656, 19056, 19456, 19856, 20256, 20656, 21056, 21456],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -98, -100, -100, 71, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 4:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2_1_E", "map3", "map3", "map2_2_S", "map2", "map2", "map2", "map9", "map2", "map2", "map2_2_E", "map6", "map6", "map2_3_S", "map2", "map2", "map2", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_3_E", "map3", "map4_4_S", "map4", "map4", "map4", "map4_4_E", "map3", "map2_5_S", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_5_E", "map6", "map7_7_S", "map7_7_E", "map6", "map2_6_S", "map2", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_6_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2550.5, 2851.5, 3202, 3602, 4002, 4402, 4402, 4802, 5202, 5602, 5877, 6027, 6302, 6702, 7102, 7502, 7902, 8302, 8702, 9102, 9102, 9502, 9902, 10302, 10302, 10702, 11102, 11502, 11902, 12252.5, 12553, 12853, 13153, 13453, 13753, 14053.5, 14404, 14804, 15204, 15604, 15604, 16004, 16404, 16804, 17204, 17479, 17629, 17779, 17929, 18204, 18604, 19004, 19404, 19804, 20204, 20604, 21004, 21404, 21804, 22204],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 5:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2_1_E", "map3", "map4_2_S", "map4", "map4", "map8", "map4", "map4_2_E", "map3", "map2_3_S", "map2", "map2", "map2", "map9", "map2", "map2", "map2_3_E", "map6", "map7_4_S", "map7_4_E", "map6", "map6", "map6", "map2_5_S", "map2", "map2", "map9", "map2", "map2", "map2", "map2_5_E", "map6", "map7_6_S", "map7", "map7", "map7_6_E", "map6", "map2_7_S", "map2", "map2", "map9", "map2", "map2", "map2_7_E", "map6", "map7_8_S", "map7", "map7", "map7_8_E", "map6", "map2_9_S", "map2", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_9_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 2950.5, 3251, 3551, 3851, 3851, 4151, 4451, 4751.5, 5102, 5502, 5902, 6302, 6302, 6702, 7102, 7502, 7777, 7927, 8077, 8227, 8377, 8527, 8802, 9202, 9602, 9602, 10002, 10402, 10802, 11202, 11477, 11627, 11777, 11927, 12077, 12227, 12502, 12902, 13302, 13302, 13702, 14102, 14502, 14777, 14927, 15077, 15227, 15377, 15527, 15802, 16202, 16602, 17002, 17402, 17802, 17802, 18202, 18602, 19002, 19402, 19802, 20202, 20602, 21002, 21402, 21802, 22202],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 70, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -98, 162, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 6:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2", "map2_1_E", "map6", "map7_2_S", "map7_2_E", "map6", "map2_3_S", "map2", "map2", "map9", "map2", "map2_3_E", "map5", "map4_4_S", "map4", "map8", "map4_4_E", "map5", "map2_5_S", "map2", "map9", "map2_5_E", "map5", "map4_6_S", "map4", "map8", "map4_6_E", "map5", "map2_7_S", "map2", "map2_7_E", "map5", "map4_8_S", "map4", "map8", "map4_8_E", "map5", "map2_9_S", "map2", "map2", "map2", "map9", "map2", "map2", "map2_9_E", "map3", "map4_10_S", "map4", "map4_10_E", "map3", "map2_11_S", "map2_11_E", "map6", "map6", "map2_12_S", "map2", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_12_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 3e3, 3275, 3425, 3575, 3725, 4e3, 4400, 4800, 4800, 5200, 5600, 6200, 6750, 7050, 7050, 7350, 7900, 8500, 8900, 8900, 9300, 9900, 10450, 10750, 10750, 11050, 11600, 12200, 12600, 13e3, 13600, 14150, 14450, 14450, 14750, 15300, 15900, 16300, 16700, 17100, 17100, 17500, 17900, 18300, 18650.5, 18951, 19251, 19551, 19851.5, 20202, 20602, 20877, 21027, 21302, 21702, 22102, 22502, 22902, 23302, 23702, 24102, 24502, 24902, 25302],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, 70, -100, -100, -100, -100, 160, -100, -100, -100, -100, 70, -100, -100, -100, -100, -100, -100, -100, -100, 70, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 7:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map2", "map2", "map2_1_E", "map3", "map4_2_S", "map4", "map4", "map4", "map4", "map4", "map4", "map4", "map4", "map4", "map8", "map4", "map4", "map4_2_E", "map5", "map2_4_S", "map2", "map2", "map9", "map2", "map2_4_E", "map6", "map6", "map2_5_S", "map2_5_E", "map6", "map6", "map2_6_S", "map2", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2_6_E", "map3", "map4_7_S", "map4", "map4", "map4", "map4", "map4_7_E", "map5", "map2_8_S", "map2", "map2", "map2", "map2", "map2_8_E", "map6", "map6", "map2_9_S", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_9_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 3e3, 3e3, 3400, 3800, 4200, 4200, 4600, 5e3, 5400, 5800, 5800, 6200, 6600, 7e3, 7400, 7800, 8200, 8550.5, 8851, 9151, 9451, 9751, 10051, 10351, 10651, 10951, 11251, 11551, 11551, 11851, 12151, 12451, 13001, 13601, 14001, 14401, 14401, 14801, 15201, 15476, 15626, 15901, 16301, 16576, 16726, 17001, 17401, 17801, 18201, 18601, 19001, 19001, 19401, 19801, 20201, 20551.5, 20852, 21152, 21452, 21752, 22052, 22352, 22902, 23502, 23902, 24302, 24702, 25102, 25502, 25777, 25927, 26202, 26602, 27002, 27402, 27802, 28202, 28602, 29002, 29402, 29802],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 70, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 8:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2_1_E", "map3", "map4_2_S", "map4", "map4_2_E", "map3", "map2_3_S", "map2", "map2", "map9", "map2", "map2", "map2", "map2_3_E", "map3", "map4_4_S", "map4_4_E", "map3", "map2_5_S", "map2", "map2", "map2_5_E", "map3", "map3", "map2_6_S", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_6_E", "map6", "map6", "map2_7_S", "map2_7_E", "map6", "map6", "map2_8_S", "map2", "map2", "map2", "map2", "map9", "map2", "map2", "map2_8_E", "map6", "map6", "map2_9_S", "map2_9_E", "map3", "map3", "map2_10_S", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_10_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 2950.5, 3251, 3551, 3851, 4151.5, 4502, 4902, 5302, 5302, 5702, 6102, 6502, 6902, 7252.5, 7553, 7853, 8153.5, 8504, 8904, 9304, 9704, 10054.5, 10355.5, 10706, 11106, 11506, 11906, 11906, 12306, 12706, 13106, 13506, 13781, 13931, 14206, 14606, 14881, 15031, 15306, 15706, 16106, 16506, 16906, 16906, 17306, 17706, 18106, 18381, 18531, 18806, 19206, 19556.5, 19857.5, 20208, 20608, 21008, 21408, 21808, 22208, 22608, 23008, 23408, 23808],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 9:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2_1_E", "map3", "map4_2_S", "map4", "map4", "map4_2_E", "map3", "map2_3_S", "map2", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map2", "map2_3_E", "map6", "map6", "map3", "map3", "map2_4_S", "map2", "map2", "map2", "map2", "map2", "map2", "map2_4_E", "map6", "map6", "map2_5_S", "map2", "map2", "map2", "map2", "map2", "map2_5_E", "map6", "map7_6_S", "map7", "map7", "map7", "map7", "map7", "map7", "map7_6_E", "map6", "map2_7_S", "map2", "map2", "map2", "map2", "map2", "map2_7_E", "map6", "map6", "map3", "map3", "map2_8_S", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_8_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 2950.5, 3251, 3551, 3851, 4151, 4451.5, 4802, 5202, 5602, 6002, 6402, 6802, 6802, 7202, 7602, 8002, 8402, 8802, 9077, 9227, 9452.5, 9753.5, 10104, 10504, 10904, 11304, 11704, 12104, 12504, 12904, 13179, 13329, 13604, 14004, 14404, 14804, 15204, 15604, 16004, 16279, 16429, 16579, 16729, 16879, 17029, 17179, 17329, 17479, 17629, 17904, 18304, 18704, 19104, 19504, 19904, 20304, 20579, 20729, 20954.5, 21255.5, 21606, 22006, 22406, 22806, 23206, 23606, 24006, 24406, 24806, 25206],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                case 10:
                    this.nodeName = ["map2_1_S", "map1", "map2", "map2", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2", "map2", "map8", "map2", "map2", "map2", "map2", "map2", "map2", "map2_1_E", "map3", "map4_2_S", "map4", "map4", "map4", "map4", "map4", "map4", "map9", "map4", "map4", "map4", "map4", "map4", "map4", "map4", "map4", "map8", "map4_2_E", "map5", "map2_3_S", "map2", "map2", "map2", "map2_3_E", "map6", "map6", "map2_4_S", "map2", "map2", "map2", "map9", "map2", "map2", "map2", "map2_4_E", "map6", "map6", "map3", "map4_5_S", "map4", "map4_5_E", "map3", "map2_6_S", "map2", "map2", "map2", "map2", "map2", "map2", "map1", "map2", "map2", "map2_6_E"],
                    this.nodeStateX = [200, 600, 1e3, 1400, 1800, 2200, 2600, 3e3, 3e3, 3400, 3800, 4200, 4200, 4600, 5e3, 5400, 5800, 6200, 6200, 6600, 7e3, 7400, 7800, 8200, 8600, 9e3, 9350.5, 9651, 9951, 10251, 10551, 10851, 11151, 11451, 11451, 11751, 12051, 12351, 12651, 12951, 13251, 13551, 13851, 13851, 14151, 14701, 15301, 15701, 16101, 16501, 16901, 17176, 17326, 17601, 18001, 18401, 18801, 18801, 19201, 19601, 20001, 20401, 20676, 20826, 21051.5, 21352, 21652, 21952, 22252.5, 22603, 23003, 23403, 23803, 24203, 24603, 25003, 25403, 25803, 26203, 26603],
                    this.nodeStateY = [-100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 325, -100, -100, -100, -100, -100, -100, -100, -100, 70, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, 160, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100, -100],
                    this.nodeStateScaleX = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                    this.nodeStateScaleY = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
                    break;
                default:
                    console.log("\u65e0\u6b64\u5173\u5361\u6570\u636e\uff01")
                }
            }
            ,
            e.prototype.GetMessageName = function() {
                return this.nodeName
            }
            ,
            e.prototype.GetMessageX = function() {
                return this.nodeStateX
            }
            ,
            e.prototype.GetMessageY = function() {
                return this.nodeStateY
            }
            ,
            e.prototype.GetMessageScaleX = function() {
                return this.nodeStateScaleX
            }
            ,
            e.prototype.GetMessageScaleY = function() {
                return this.nodeStateScaleY
            }
            ,
            e
        }();
        n.default = o,
        cc._RF.pop()
    }
    , {}],
    GameModule: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "20951xmOoVFmZRgGTFceEbi", "GameModule");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = cc._decorator
          , s = i.ccclass
          , c = i.property
          , l = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.GameScene = null,
                t.nowShowGame = 0,
                t.numGamelist = [],
                t.AllGameInfo = null,
                t.MoreGameArr = [],
                t.MoreGameArr2 = [],
                t.MoregGames = 0,
                t.moregameSprite = [],
                t.MoveCanNot = 0,
                t
            }
            return a(t, e),
            t.prototype.onLoad = function() {}
            ,
            t.prototype.start = function() {}
            ,
            t.prototype.update = function() {}
            ,
            t.prototype.initMoreGame = function(e) {
                this.GameScene = e,
                this.initLoadMoreGame()
            }
            ,
            t.prototype.initLoadMoreGame = function() {
                var e = this;
                if (0 == this.GameScene.Connect.GetPlatForm()) {
                    this.node.getChildByName("othergame").active = !0,
                    this.GetAllConfig();
                    var t = 0
                      , n = setTimeout(function() {
                        if (e.GameScene && null != e.GameScene) {
                            if (null == e.MoreGameArr)
                                t = 0;
                            else
                                for (var o = 0; o < e.MoreGameArr.length; o++)
                                    e.MoreGameArr[o].texture && t++;
                            var a = 0;
                            if (t < e.MoregGames || 0 == t)
                                for (a = 1,
                                e.MoreGameArr2 = e.GameScene.Connect.GetMoreGame(),
                                o = 0; o < 4; o++)
                                    e.MoreGameArr2[o].texture = e.moregameSprite[o];
                            1 != e.GameScene.Connect.GetPlatForm() && (e.numGamelist = [],
                            e.numGamelist = 0 == a ? e.MoreGameArr : e.MoreGameArr2,
                            e.numGamelist.sort(e.randomSort),
                            e.nowShowGame = 0,
                            e.node.getChildByName("othergame").getComponent(cc.Sprite).spriteFrame = e.numGamelist[e.nowShowGame].texture,
                            e.node.getChildByName("othergame").nature = "moregame@" + e.numGamelist[e.nowShowGame].gameid + "@" + e.numGamelist[e.nowShowGame].name,
                            e.node.getChildByName("othergame").on(cc.Node.EventType.TOUCH_END, function(t) {
                                e.GameScene.playAudio("/MainResources/Audio/soundpress", !1),
                                e.moreGameToClick(t)
                            }),
                            cc.tween(e.node.getChildByName("othergame")).to(.1, {
                                angle: -5
                            }).to(.1, {
                                angle: 0
                            }).to(.1, {
                                angle: 5
                            }).to(.1, {
                                angle: 0
                            }).to(2, {}).union().repeatForever().start())
                        } else
                            clearTimeout(n)
                    }, 2e3)
                } else
                    this.node.getChildByName("othergame").active = !1
            }
            ,
            t.prototype.GetAllConfig = function() {
                var e = this;
                cc.loader.load(this.GameScene.Connect.GetMoregameConfig().alljsonUrl, function(t, n) {
                    t ? setTimeout(function() {
                        e.GetAllConfig()
                    }, 5e3) : (e.AllGameInfo = n,
                    e.GetMoreGame())
                })
            }
            ,
            t.prototype.GetMoreGame = function() {
                var e = this;
                cc.loader.load(this.GameScene.Connect.GetMoregameConfig().jsonUrl, function(t, n) {
                    if (t)
                        setTimeout(function() {
                            e.GetMoreGame()
                        }, 5e3);
                    else {
                        var o = n.games;
                        e.MoregGames = n.games.length;
                        for (var a = 0; a < o.length; a++) {
                            var r = e.GameScene.Connect.GetMoregameConfig().imgUrl + "gamebanner" + o[a].id + ".png"
                              , i = {
                                gameid: null,
                                imgurl: null,
                                texture: null,
                                weight: null,
                                id: null,
                                name: ""
                            };
                            i.imgurl = r,
                            i.id = o[a].id,
                            i.gameid = e.AllGameInfo[i.id][1],
                            i.name = e.AllGameInfo[i.id][0],
                            e.MoreGameArr.push(i)
                        }
                        for (a = 0; a < e.MoreGameArr.length; a++)
                            e.GetImgUrl(a, e.MoreGameArr[a].imgurl)
                    }
                })
            }
            ,
            t.prototype.GetImgUrl = function(e, t) {
                var n = this;
                cc.loader.load(this.MoreGameArr[e].imgurl, function(o, a) {
                    o ? setTimeout(function() {
                        n.GetImgUrl(e, t)
                    }, 1e3) : n.MoreGameArr[e].texture = new cc.SpriteFrame(a)
                })
            }
            ,
            t.prototype.moreGameToClick = function(e) {
                var t = this
                  , n = e.target.nature;
                if (-1 != n.indexOf("moregame")) {
                    this.MoveCanNot = 1;
                    var o = n.split("@");
                    this.GameScene.Connect.OpenMoreGame(o[1]).then(function(e) {
                        e && (t.GameScene.Connect.UploadEvent("moregame", {
                            score: o[2]
                        }),
                        t.MoveCanNot = 0)
                    }).catch(function() {
                        t.MoveCanNot = 0
                    }),
                    setTimeout(function() {
                        t.nowShowGame += 1,
                        t.nowShowGame >= t.numGamelist.length && (t.nowShowGame = 0),
                        t.node.getChildByName("othergame").getComponent(cc.Sprite).spriteFrame = t.numGamelist[t.nowShowGame].texture,
                        t.node.getChildByName("othergame").nature = "moregame@" + t.numGamelist[t.nowShowGame].gameid + "@" + t.numGamelist[t.nowShowGame].name
                    }, 500)
                }
            }
            ,
            t.prototype.randomSort = function() {
                return Math.random() > .5 ? -1 : 1
            }
            ,
            r([c({
                type: cc.SpriteFrame
            })], t.prototype, "moregameSprite", void 0),
            r([s], t)
        }(cc.Component);
        n.default = l,
        cc._RF.pop()
    }
    , {}],
    GameRank: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "18b74b/qLlM5pSw1HWKnaTu", "GameRank");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = e("../Module/App")
          , s = e("../Utils/GameUtils")
          , c = cc._decorator
          , l = c.ccclass
          , u = c.property
          , p = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.saveGameScene = null,
                t.rankItemNode = [],
                t.rankPrefab = [],
                t.rankSprite = [],
                t
            }
            return a(t, e),
            t.prototype.onLoad = function() {}
            ,
            t.prototype.update = function() {}
            ,
            t.prototype.initGame = function(e) {
                this.saveGameScene = e,
                this.initRankingList()
            }
            ,
            t.prototype.initRankingList = function() {
                for (var e = this, t = this.node.getChildByName("node_bg").getChildByName("node_scollview").getChildByName("view").getChildByName("content"), n = i.default.connect.GetUserName(1), o = i.default.connect.GetUserScore(1), a = (i.default.connect.GetUserSkin(1),
                i.default.connect.GetUserImage(1)), r = i.default.connect.GetUserID(1), c = i.default.connect.GetMyID(), l = function(i) {
                    if (null == n[i] || null == a[i])
                        return "continue";
                    u.rankItemNode[i] = cc.instantiate(u.rankPrefab[0]),
                    u.rankItemNode[i].parent = t,
                    0 == i ? (u.rankItemNode[i].getChildByName("node_number").active = !1,
                    u.rankItemNode[i].getChildByName("node_top").active = !0) : u.rankItemNode[i].getChildByName("node_number").getComponent(cc.Label).string = "" + (i + 1),
                    a[i] && cc.assetManager.loadRemote(a[i], {
                        ext: ".png"
                    }, function(t, n) {
                        t || (e.rankItemNode[i].getChildByName("node_headphoto").getChildByName("img").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(n),
                        e.rankItemNode[i].getChildByName("node_headphoto").getChildByName("img").width = 48,
                        e.rankItemNode[i].getChildByName("node_headphoto").getChildByName("img").height = 48)
                    }),
                    u.rankItemNode[i].getChildByName("node_name").getComponent(cc.Label).string = "" + n[i],
                    u.rankItemNode[i].getChildByName("node_score").getComponent(cc.Label).string = "" + o[i],
                    r[i] == c ? (u.rankItemNode[i].getChildByName("node_icon").getComponent(cc.Sprite).spriteFrame = u.rankSprite[0],
                    u.rankItemNode[i].getChildByName("node_icon").width = 48,
                    u.rankItemNode[i].getChildByName("node_icon").height = 48,
                    u.rankItemNode[i].getChildByName("node_icon").clickType = "share") : u.rankItemNode[i].getChildByName("node_icon").clickType = "playwith" + r[i],
                    u.rankItemNode[i].getChildByName("node_icon").on(cc.Node.EventType.TOUCH_END, function(t) {
                        e.rankItemRightBtn(t)
                    })
                }, u = this, p = 0; p < n.length; p++)
                    l(p);
                t.height = 60 * n.length + 40 + 15 * n.length - 1,
                this.saveGameScene.rankPage.getChildByName("node_bg").getChildByName("node_close").on(cc.Node.EventType.TOUCH_END, function() {
                    e.closeRankLise()
                }),
                this.saveGameScene.rankPage.getChildByName("node_invite").on(cc.Node.EventType.TOUCH_END, function() {
                    s.default.playAudio("soundpress", !1),
                    i.default.connect.shareInvite()
                })
            }
            ,
            t.prototype.rankItemRightBtn = function(e) {
                var t = this;
                if (s.default.playAudio("soundpress", !1),
                -1 != e.target.clickType.indexOf("playwith")) {
                    var n = e.target.clickType.substr("playwith".length);
                    i.default.connect.ChallengeGame(n).then(function(e) {
                        e && t.closeRankLise()
                    })
                } else
                    i.default.connect.ShareGame().then(function() {})
            }
            ,
            t.prototype.closeRankLise = function() {
                s.default.playAudio("soundpress", !1),
                this.saveGameScene.rankPage.destroy(),
                this.saveGameScene.rankPage = null
            }
            ,
            r([u({
                type: cc.Prefab,
                tooltip: "\u6392\u884c\u699c\u4f7f\u7528\u9884\u5236"
            })], t.prototype, "rankPrefab", void 0),
            r([u({
                type: cc.SpriteFrame,
                tooltip: "\u6392\u884c\u699c\u4f7f\u7528\u56fe\u7247"
            })], t.prototype, "rankSprite", void 0),
            r([l], t)
        }(cc.Component);
        n.default = p,
        cc._RF.pop()
    }
    , {
        "../Module/App": "App",
        "../Utils/GameUtils": "GameUtils"
    }],
    GameScene: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "2be4c/BqCxG7ILpV0HnjzBr", "GameScene");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.doAnimationName = n.doGameState = void 0;
        var i, s, c = e("../Function/Flash"), l = e("../Function/HeroContact"), u = e("../Function/NPCCtrl"), p = e("../GameMessage"), d = e("../Module/App"), f = e("../Utils/GameUtils"), h = e("../View/GameRank"), m = e("../View/GameSetting");
        (function(e) {
            e[e.LEADER = -1] = "LEADER",
            e[e.HOME = 0] = "HOME",
            e[e.WAIT = 1] = "WAIT",
            e[e.GAME = 2] = "GAME",
            e[e.SUCCESS = 3] = "SUCCESS",
            e[e.FAIL = 4] = "FAIL"
        }
        )(i = n.doGameState || (n.doGameState = {})),
        function(e) {
            e.WAIT = "wait",
            e.RUSH = "rush",
            e.FEIQI1 = "feiqi_1",
            e.FEIQI2 = "feiqi_2",
            e.FEIQI3 = "feiqi_3",
            e.SHACHE1 = "shache_1",
            e.SHACHE2 = "shache_2",
            e.SHACHE3 = "shache_3"
        }(s = n.doAnimationName || (n.doAnimationName = {}));
        var y = cc._decorator
          , v = y.ccclass
          , g = y.property
          , P = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.MainCamera = null,
                t.ScollMapCamera = [],
                t.RoadPrefab = [],
                t.scoreTextPre = null,
                t.coinsIcon = null,
                t.trophySP = [],
                t.motoAudio = [],
                t.GameState = 0,
                t.soundFastSpeed = null,
                t.soundSlowSpeed = null,
                t.soundMoto = null,
                t.saveFriendsImage = [],
                t.HomeLayer = null,
                t.settingPage = null,
                t.rankPage = null,
                t.homeChoseIndex = 0,
                t.GameLayer = null,
                t.GameLayerUI = null,
                t.RoadBox = null,
                t.batchBodyPos = [],
                t.saveTrackNode = [],
                t.saveTrackStart = null,
                t.saveTrackEnd = null,
                t.saveHeroNode = null,
                t.saveHeroBody = null,
                t.saveAfterBody = null,
                t.saveFrontBody = null,
                t.initRevivePoint = [],
                t.NPCGROUP = ["Robot2", "Robot3", "Robot4", "Robot5"],
                t.NPCCtrl = null,
                t.isStartApplyForce = !1,
                t.frontTestState = !0,
                t.afterTestState = !0,
                t.isFlipState = !1,
                t.isStartTimer = !1,
                t.doFilpTimer = 0,
                t.countFlipNum = 0,
                t.saveFilpNum = -1,
                t.maxFilpSpeed = -400,
                t.nowFilpSpeed = 0,
                t.addSpeed = 200,
                t.maxSpeed = 3200,
                t.nowSpeed = 0,
                t.sprintSpeed = 1e3,
                t.angleRemainder = -1,
                t.angleCircle = -1,
                t.turnUpState = !1,
                t.turnUpNumber = 2,
                t.heroAnimation = null,
                t.DragonBonesName = "",
                t.scoreTextPool = null,
                t.initMainCameraX = -1,
                t.recordScoreDis = -1,
                t.resultNode = null,
                t.totalLifes = 0,
                t.raceRanking = 0,
                t.npcRanking = [],
                t.nowRoleRace = -1,
                t.recordZoomY = -1,
                t.LeaderLayer = null,
                t.LeaderFilp = !1,
                t
            }
            return a(t, e),
            t.prototype.onLoad = function() {
                var e = this;
                this.GameData = new p.default,
                f.default.initPhysicsDeploy(3),
                f.default.autoAdapter(),
                cc.game.setFrameRate(61),
                cc.director.getPhysicsManager().enabledAccumulator = !0,
                cc.PhysicsManager.FIXED_TIME_STEP = 1 / 60,
                this.saveFriendsImage = [];
                for (var t = d.default.connect.GetUserImage(1), n = d.default.connect.GetUserID(1), o = d.default.connect.GetMyID(), a = 0; a < t.length; a++)
                    n[a] != o && cc.loader.load(t[a], function(t, n) {
                        t || e.saveFriendsImage.push(n)
                    });
                this.initHomeLayer(),
                document.addEventListener("visibilitychange", function() {
                    document.hidden ? (console.log("\u8fdb\u5165\u540e\u53f0"),
                    cc.game.pause()) : (console.log("\u8fd4\u56de\u7a0b\u5e8f"),
                    cc.game.resume())
                })
            }
            ,
            t.prototype.start = function() {
                cc.view.enableRetina(!1)
            }
            ,
            t.prototype.update = function(e) {
                this.CheckADVideo(),
                this.keepHomeWheel(e),
                this.heroToMove(e),
                this.contactTimer(e),
                this.judgeFilp(),
                this.gameProgress(2),
                this.initGameScore(1)
            }
            ,
            t.prototype.lateUpdate = function(e) {
                this.syncCamera(e)
            }
            ,
            t.prototype.initHomeLayer = function() {
                var e = this;
                null != this.HomeLayer && (this.HomeLayer.destroy(),
                this.HomeLayer = null),
                this.GameState = i.HOME,
                d.default.resManager.loadPrefab("Main/view/HomeLayer").then(function(t) {
                    if (t) {
                        e.HomeLayer = cc.instantiate(t),
                        e.HomeLayer.parent = e.node,
                        e.HomeLayer.getChildByName("node_NumGoldTT").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumGoldTT,
                        cc.tween(e.HomeLayer.getChildByName("node_title").getChildByName("white")).to(.7, {
                            x: 240
                        }).to(.5, {}).call(function() {
                            e.HomeLayer.getChildByName("node_title").getChildByName("white").x = -230
                        }).union().repeatForever().start(),
                        f.default.AudioState ? e.HomeLayer.getComponent(cc.AudioSource).play() : e.HomeLayer.getComponent(cc.AudioSource).stop(),
                        e.initMotoNature();
                        var n = e.HomeLayer.getChildByName("node_upprop").getChildByName("title");
                        cc.Tween.stopAllByTarget(n),
                        cc.tween(n).to(.7, {
                            scale: .55
                        }).to(.7, {
                            scale: .5
                        }).union().repeatForever().start();
                        var o = e.HomeLayer.getChildByName("homerole").getComponent(cc.PageView)
                          , a = o.node.getChildByName("content");
                        o.removeAllPages(),
                        o.stopAutoScroll(),
                        o.node.off(cc.Node.EventType.TOUCH_START),
                        o.node.off(cc.Node.EventType.TOUCH_MOVE),
                        o.node.off(cc.Node.EventType.TOUCH_END),
                        o.node.off(cc.Node.EventType.TOUCH_CANCEL),
                        a.getComponent(cc.Layout).enabled = !1;
                        for (var r = function(t) {
                            d.default.resManager.loadPrefab("Main/role/homerole" + (t + 1)).then(function(n) {
                                if (n) {
                                    var r = cc.instantiate(n);
                                    0 == f.default.NowHeroTT ? r.width = cc.view.getVisibleSize().width : r.width = e.HomeLayer.width,
                                    r.x = r.width / 2 + r.width * t,
                                    o.addPage(r),
                                    t == f.default.NumHeroPrice.length - 1 && (a.width = r.width * f.default.NumHeroPrice.length,
                                    e.homeChoseIndex = f.default.NowHeroTT,
                                    o.setCurrentPageIndex(e.homeChoseIndex),
                                    e.switchHomeLock(e.homeChoseIndex))
                                }
                            })
                        }, i = 0; i < f.default.NumHeroPrice.length; i++)
                            r(i);
                        o.node.on("page-turning", function() {
                            var t = a.children[e.homeChoseIndex].getChildByName("node_body").getChildByName("hero").getComponent(dragonBones.ArmatureDisplay);
                            t.playAnimation(s.RUSH, 1),
                            t.addEventListener(dragonBones.EventObject.COMPLETE, e._animationEventHandler, e)
                        }),
                        e.HomeLayer.getChildByName("node_next").on(cc.Node.EventType.TOUCH_END, function() {
                            e.doSwitchRole(1),
                            f.default.playAudio("soundshopswitch", !1)
                        }),
                        e.HomeLayer.getChildByName("node_pre").on(cc.Node.EventType.TOUCH_END, function() {
                            e.doSwitchRole(-1),
                            f.default.playAudio("soundshopswitch", !1)
                        }),
                        e.HomeLayer.getChildByName("node_start").on(cc.Node.EventType.TOUCH_END, function() {
							window.cy_Sdk && window.cy_Sdk.adHide();
							window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_BEGIN,f.default.NumGateTT);
                            f.default.playAudio("soundpress", !1),
                            f.default.NowHeroTT = e.homeChoseIndex,
                            f.default.SaveGameScore(),
                            e.startGame()
                        }),
                        e.HomeLayer.getChildByName("node_free").on(cc.Node.EventType.TOUCH_END, function() {
                            f.default.playAudio("soundpress", !1),
							window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.REWARD_CLICK,"1000 Coins"),
                            f.default.ShowADNow(0).then(function() {
                                f.default.NumGoldTT += 1e3,
                                e.HomeLayer.getChildByName("node_NumGoldTT").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumGoldTT,
                                f.default.showTipRemind("You got 1000 Coins!", 56),
                                e.initMotoNature()
                            }).catch(function() {})
                        }),
                        e.HomeLayer.getChildByName("node_setting").on(cc.Node.EventType.TOUCH_END, function() {
                            f.default.playAudio("soundpress", !1),
                            e.initSetting()
                        }),
                        e.HomeLayer.getChildByName("node_unlock").on(cc.Node.EventType.TOUCH_END, function(t) {
                            e.unlockRole(t),
                            f.default.playAudio("soundpress", !1)
                        }),
                        e.HomeLayer.getChildByName("node_upprop").getChildByName("node_maxspeed").getChildByName("node_doup").on(cc.Node.EventType.TOUCH_END, function(t) {
                            e.upMotoNature(1, t)
                        }),
                        e.HomeLayer.getChildByName("node_upprop").getChildByName("node_sprintspeed").getChildByName("node_doup").on(cc.Node.EventType.TOUCH_END, function(t) {
                            e.upMotoNature(2, t)
                        }),
                        e.HomeLayer.getChildByName("node_rank").on(cc.Node.EventType.TOUCH_END, function() {
                            f.default.playAudio("soundpress", !1),
                            e.initRank()
                        }),
						e.HomeLayer.getChildByName("node_rank").active = 0,
                        e.HomeLayer.getChildByName("node_invite").on(cc.Node.EventType.TOUCH_END, function() {
                            f.default.playAudio("soundpress", !1),
                            d.default.connect.shareInvite()
                        })
						e.HomeLayer.getChildByName("node_invite").active = 0
                    }
                })
            }
            ,
            t.prototype.keepHomeWheel = function() {
                if (this.GameState == i.HOME)
                    for (var e = this.HomeLayer.getChildByName("homerole").getComponent(cc.PageView).node.getChildByName("content"), t = 0; t < e.children.length; t++)
                        if (e.children[t].getChildByName("node_body").getChildByName("hero").getChildByName("ATTACHED_NODE_TREE")) {
                            var n = e.children[t].getChildByName("node_body").getChildByName("hero").getChildByName("ATTACHED_NODE_TREE").getChildByName("ATTACHED_NODE:root").getChildByName("ATTACHED_NODE:lunzi").getChildByName("doColor");
                            e.children[t].getChildByName("node_front").position = e.children[t].convertToNodeSpaceAR(n.parent.convertToWorldSpaceAR(n.position))
                        }
            }
            ,
            t.prototype.doSwitchRole = function(e) {
                this.homeChoseIndex += e,
                this.homeChoseIndex <= 0 ? this.homeChoseIndex = 0 : this.homeChoseIndex >= f.default.NumHeroPrice.length - 1 && (this.homeChoseIndex = f.default.NumHeroPrice.length - 1);
                var t = this.HomeLayer.getChildByName("homerole").getComponent(cc.PageView);
                t.node.getChildByName("content").getComponent(cc.Layout).enabled || (t.node.getChildByName("content").getComponent(cc.Layout).enabled = !0,
                t.node.getChildByName("content").getComponent(cc.Layout).updateLayout()),
                t.scrollToPage(this.homeChoseIndex, .5),
                this.switchHomeLock(this.homeChoseIndex)
            }
            ,
            t.prototype.switchHomeLock = function(e) {
                var t = this.HomeLayer.getChildByName("node_bg").getChildByName("gasstation");
                1 == f.default.NowHeroLockState[e] ? (t.getChildByName("unlock").active = !0,
                t.getChildByName("lock").active = !1,
                this.HomeLayer.getChildByName("node_start").active = !0,
                this.HomeLayer.getChildByName("node_unlock").active = !1) : (t.getChildByName("unlock").active = !1,
                t.getChildByName("lock").active = !0,
                this.HomeLayer.getChildByName("node_start").active = !1,
                this.HomeLayer.getChildByName("node_unlock").active = !0),
                0 == e ? (this.HomeLayer.getChildByName("node_pre").active = !1,
                this.HomeLayer.getChildByName("node_next").active = !0) : e == f.default.NowHeroLockState.length - 1 ? (this.HomeLayer.getChildByName("node_pre").active = !0,
                this.HomeLayer.getChildByName("node_next").active = !1) : (this.HomeLayer.getChildByName("node_pre").active = !0,
                this.HomeLayer.getChildByName("node_next").active = !0),
                this.HomeLayer.getChildByName("node_unlock").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumHeroPrice[e]
            }
            ,
            t.prototype.initSetting = function() {
                var e = this;
                null != this.settingPage && (this.settingPage.destroy(),
                this.settingPage = null),
                d.default.resManager.loadPrefab("Other/Public/node_setting").then(function(t) {
                    t && (e.settingPage = cc.instantiate(t),
                    e.settingPage.parent = e.node,
                    e.settingPage.getComponent(m.default).initGame(e))
                })
            }
            ,
            t.prototype.initRank = function() {
                var e = this;
                null != this.rankPage && (this.rankPage.destroy(),
                this.rankPage = null),
                d.default.resManager.loadPrefab("Other/Public/node_rank").then(function(t) {
                    t && (e.rankPage = cc.instantiate(t),
                    e.rankPage.parent = e.node,
                    e.rankPage.getComponent(h.default).initGame(e))
                })
            }
            ,
            t.prototype.unlockRole = function() {
                f.default.NumGoldTT >= f.default.NumHeroPrice[this.homeChoseIndex] ? (f.default.playAudio("upgrade_cc", !1),
                this.HomeLayer.getChildByName("node_unlock").active = !1,
                this.HomeLayer.getChildByName("node_start").active = !0,
                f.default.NowHeroTT = this.homeChoseIndex,
                f.default.NumGoldTT -= f.default.NumHeroPrice[this.homeChoseIndex],
                0 == f.default.NowHeroLockState[this.homeChoseIndex] && (f.default.NowHeroLockState[this.homeChoseIndex] = 1),
                this.HomeLayer.getChildByName("node_NumGoldTT").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumGoldTT,
                f.default.SaveGameScore(),
                this.switchHomeLock(this.homeChoseIndex),
                setTimeout(function() {
                    f.default.showTipRemind("You unlocked a new motorcycle!", 56, !1)
                }, 300)) : f.default.showTipRemind("Your coins is not enough!", 56)
            }
            ,
            t.prototype.initMotoNature = function() {
                var e = this.HomeLayer.getChildByName("node_upprop").getChildByName("node_maxspeed")
                  , t = e.getChildByName("node_doup")
                  , n = e.getChildByName("progress")
                  , o = this.HomeLayer.getChildByName("node_upprop").getChildByName("node_sprintspeed")
                  , a = o.getChildByName("node_doup")
                  , r = o.getChildByName("progress")
                  , i = [200, 500, 1e3, 1500, 2e3, 3e3, 4e3, 5e3, 6e3, 8e3];
                if (f.default.maxSpeedLV >= 10) {
                    t.getChildByName("maxtext").active = !0,
                    t.getChildByName("text").active = !1,
                    t.getComponent(cc.Button) && t.removeComponent(cc.Button),
                    t.color = new cc.Color(150,150,150,255);
                    for (var s = 0; s < 10; s++)
                        n.getChildByName("middle").children[s].active = !0,
                        n.getChildByName("top").children[s].active = !0;
                    t.getChildByName("icon").active = !0
                } else {
                    for (t.getChildByName("maxtext").active = !1,
                    t.getChildByName("text").active = !0,
                    t.getChildByName("text").getComponent(cc.Label).string = "A" + i[f.default.maxSpeedLV],
                    s = 0; s < 10; s++)
                        s < f.default.maxSpeedLV ? (n.getChildByName("top").children[s].active = !0,
                        n.getChildByName("middle").children[s].active = !0) : (n.getChildByName("top").children[s].active = !1,
                        n.getChildByName("middle").children[s].active = !1);
                    f.default.maxSpeedLV + 1 <= 10 && (n.getChildByName("middle").children[f.default.maxSpeedLV].active = !0),
                    f.default.NumGoldTT >= i[f.default.maxSpeedLV] ? t.getChildByName("icon").active = !1 : t.getChildByName("icon").active = !0
                }
                if (f.default.sprintSpeedLV >= 10) {
                    for (a.getChildByName("maxtext").active = !0,
                    a.getChildByName("text").active = !1,
                    a.getComponent(cc.Button) && a.removeComponent(cc.Button),
                    a.color = new cc.Color(150,150,150,255),
                    s = 0; s < 10; s++)
                        r.getChildByName("middle").children[s].active = !0,
                        r.getChildByName("top").children[s].active = !0;
                    a.getChildByName("icon").active = !0
                } else {
                    for (a.getChildByName("maxtext").active = !1,
                    a.getChildByName("text").active = !0,
                    a.getChildByName("text").getComponent(cc.Label).string = "A" + i[f.default.sprintSpeedLV],
                    s = 0; s < 10; s++)
                        s < f.default.sprintSpeedLV ? (r.getChildByName("top").children[s].active = !0,
                        r.getChildByName("middle").children[s].active = !0) : (r.getChildByName("top").children[s].active = !1,
                        r.getChildByName("middle").children[s].active = !1);
                    f.default.sprintSpeedLV + 1 <= 10 && (r.getChildByName("middle").children[f.default.sprintSpeedLV].active = !0),
                    f.default.NumGoldTT >= i[f.default.sprintSpeedLV] ? a.getChildByName("icon").active = !1 : a.getChildByName("icon").active = !0
                }
            }
            ,
            t.prototype.upMotoNature = function(e, t) {
                var n = t.target
                  , o = parseInt(n.getChildByName("text").getComponent(cc.Label).string.split("A")[1]);
                if (1 == e) {
                    if (f.default.maxSpeedLV >= 10)
                        return;
                    if (o > f.default.NumGoldTT)
                        return f.default.playAudio("soundpress", !1),
                        void f.default.showTipRemind("Your coins is not enough!", 56);
                    f.default.NumGoldTT -= o,
                    f.default.maxSpeedLV += 1,
                    this.initMotoNature(),
                    f.default.playAudio("soundpress", !1),
                    f.default.showTipRemind("Max speed increased!", 56, !1),
                    f.default.playAudio("upgrade_skill", !1),
                    this.HomeLayer.getChildByName("node_NumGoldTT").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumGoldTT,
                    f.default.SaveGameScore()
                } else {
                    if (f.default.sprintSpeedLV >= 10)
                        return;
                    if (o > f.default.NumGoldTT)
                        return f.default.playAudio("soundpress", !1),
                        void f.default.showTipRemind("Your coins is not enough!", 56);
                    f.default.NumGoldTT -= o,
                    f.default.sprintSpeedLV += 1,
                    this.initMotoNature(),
                    f.default.playAudio("soundpress", !1),
                    f.default.showTipRemind("Sprint speed increased!", 56, !1),
                    f.default.playAudio("upgrade_skill", !1),
                    this.HomeLayer.getChildByName("node_NumGoldTT").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumGoldTT,
                    f.default.SaveGameScore()
                }
            }
            ,
            t.prototype.startGame = function() {
                var e = this;
                null != this.HomeLayer && (this.HomeLayer.destroy(),
                this.HomeLayer = null),
                this.GameState = i.WAIT,
                null != this.GameLayer && (this.GameLayer.destroy(),
                this.GameLayer = null),
                d.default.resManager.loadPrefab("Main/view/GameLayer").then(function(t) {
                    t && (e.GameLayer = cc.instantiate(t),
                    e.GameLayer.parent = e.node,
                    e.RoadBox = e.GameLayer.getChildByName("RoadBox"),
                    e.GameLayerUI = e.GameLayer.getChildByName("UI"),
                    f.default.AudioState ? e.GameLayer.getComponent(cc.AudioSource).play() : e.GameLayer.getComponent(cc.AudioSource).stop(),
                    e.NPCCtrl = e.GameLayer.getChildByName("NPCCtrl").getComponent(u.default),
                    e.NPCCtrl.initGame(e),
                    e.GameLayerUI.getChildByName("node_level").getComponent(cc.Label).string = "B" + f.default.NumGateTT,
                    e.GameLayerUI.getChildByName("ScoreText").getComponent(cc.Label).string = "" + f.default.NumScore,
                    e.gameProgress(1),
                    e.GameLayerUI.on(cc.Node.EventType.TOUCH_START, e.GameTouchStart, e),
                    e.GameLayerUI.on(cc.Node.EventType.TOUCH_MOVE, e.GameTouchMove, e),
                    e.GameLayerUI.on(cc.Node.EventType.TOUCH_END, e.GameTouchEnd, e),
                    e.GameLayerUI.on(cc.Node.EventType.TOUCH_CANCEL, e.GameTouchEnd, e),
                    e.GameLayerUI.getChildByName("node_home").on(cc.Node.EventType.TOUCH_END, function() {
                        e.GameState == i.GAME && e.GameState == i.GAME && (e.returnHome(),window.cy_Sdk && window.cy_Sdk.adShow())
                    }),
                    e.createRoad(),
                    e.createHero(),
                    e.doGameLeader(),
                    e.initNodePool())
                })
            }
            ,
            t.prototype.gameProgress = function(e) {
                if (1 == e)
                    (t = this.GameLayerUI.getChildByName("gress")).getChildByName("roboticon1").active = !1,
                    t.getChildByName("roboticon2").active = !1,
                    t.getComponent(cc.ProgressBar).progress = 0,
                    t.getChildByName("gress").getChildByName("icon").x = -2,
                    t.getChildByName("gress").getChildByName("icon").y = 20;
                else {
                    if (this.GameState != i.GAME || !this.saveHeroNode)
                        return;
                    var t = this.GameLayerUI.getChildByName("gress")
                      , n = this.saveTrackEnd.x - 180;
                    this.MainCamera.node.x < n ? (t.getComponent(cc.ProgressBar).progress = this.MainCamera.node.x / n,
                    t.getChildByName("gress").getChildByName("icon").x = this.MainCamera.node.x / n * 240) : (this.GameState = i.SUCCESS,
                    f.default.playAudio("soundend", !1),
                    this.initMotoFastAudio(2),
                    this.initMotoSlowAudio(2),
                    this.initMotoAudio(2),
                    this.raceRanking += 1,
                    this.nowRoleRace = this.raceRanking,
                    t.getComponent(cc.ProgressBar).progress = 1,
                    t.getChildByName("gress").getChildByName("icon").x = 240,
                    this.saveHeroBody.fixedRotation = !0,
                    this.DragonBonesName != s.SHACHE1 && this.playDragonBones(s.SHACHE1, 1)),
                    this.saveHeroNode.convertToWorldSpaceAR(this.saveHeroBody.node.position).y <= -800 && this.bodyCollide()
                }
            }
            ,
            t.prototype.returnHome = function() {
                f.default.playAudio("soundpress", !1),
                this.GameState = i.HOME,
                this.releaseGame(),
                this.initHomeLayer(),
                this.initMotoFastAudio(2),
                this.initMotoSlowAudio(2),
                this.initMotoAudio(2)
            }
            ,
            t.prototype.createRoad = function() {
                f.default.NumGateTT <= 10 ? this.GameData.SetGate(f.default.NumGateTT) : this.GameData.SetGate((f.default.NumGateTT - 11) % 10 + 1);
                for (var e = [], t = 0; t < this.GameData.nodeName.length; t++) {
                    var n = Object.create(null);
                    n.name = this.GameData.GetMessageName()[t],
                    n.x = this.GameData.GetMessageX()[t] - 300,
                    n.y = this.GameData.GetMessageY()[t],
                    n.scaleX = this.GameData.GetMessageScaleX()[t],
                    n.scaleY = this.GameData.GetMessageScaleY()[t],
                    e.push(n)
                }
                for (e.sort(function(e, t) {
                    return e.x - t.x
                }),
                t = 0; t < e.length; t++) {
                    var o = -1 == e[t].name.indexOf("_") ? e[t].name : ""
                      , a = null;
                    if (-1 != ["tree"].indexOf(o))
                        ;
                    else {
                        "" == o && (o = e[t].name.split("_")[0]);
                        var r = parseInt(o.replace("map", "")) - 1;
                        a = cc.instantiate(this.RoadPrefab[r])
                    }
                    if (a.parent = this.RoadBox,
                    a.position = cc.v2(e[t].x, e[t].y),
                    a.scaleX = e[t].scaleX,
                    a.scaleY = e[t].scaleY,
                    this.saveTrackNode.push(a),
                    "map9" == o && (this.initRevivePoint.push(a.position.clone().sub(cc.v2(cc.winSize.width / 2, 0))),
                    a.active = !1),
                    -1 == a.scaleX)
                        if ("map3" == o)
                            for (var i = 0; i < a.children.length; i++)
                                "node_road" == a.children[i].name && (a.children[i].angle = -30);
                        else if ("map5" == o)
                            for (i = 0; i < a.children.length; i++)
                                "node_road" == a.children[i].name && (a.children[i].angle = -12);
                        else if ("map6" == o)
                            for (i = 0; i < a.children.length; i++)
                                "node_road" == a.children[i].name && (a.children[i].angle = -45);
                    if ("map8" == o && (a.zIndex = 1),
                    -1 != e[t].name.indexOf("_S")) {
                        var s = a.x - a.width / 2
                          , c = 0
                          , l = e[t].name.split("_")[1];
                        for (i = 0; i < e.length; i++)
                            if (-1 != e[i].name.indexOf("_" + l + "_E")) {
                                c = e[i].x + a.width / 2;
                                break
                            }
                        var u = new cc.Node;
                        for (u.x = -a.width / 2,
                        u.y = "map4" == o ? -57 : "map7" == o ? -66.5 : -225,
                        u.width = c - s,
                        u.parent = a,
                        u.name = "node_road",
                        u.addComponent(cc.Widget),
                        u.getComponent(cc.Widget).bottom = "map4" == o ? 280.5 : "map7" == o ? 271 : 112.5,
                        u.getComponent(cc.Widget).updateAlignment(),
                        u.addComponent(cc.RigidBody),
                        u.getComponent(cc.RigidBody).type = cc.RigidBodyType.Static,
                        u.addComponent(cc.PhysicsBoxCollider),
                        u.getComponent(cc.PhysicsBoxCollider).friction = 1,
                        u.getComponent(cc.PhysicsBoxCollider).size.width = c - s,
                        u.getComponent(cc.PhysicsBoxCollider).size.height = 25,
                        u.getComponent(cc.PhysicsBoxCollider).offset = cc.v2((c - s) / 2, 0),
                        u.getComponent(cc.PhysicsBoxCollider).apply(),
                        this.batchBodyPos.push([s, c]),
                        i = 0; i < this.NPCGROUP.length; i++) {
                            var p = cc.instantiate(u);
                            p.parent = a,
                            p.y += 80 * (i + 1),
                            p.group = this.NPCGROUP[i],
                            p.active = !1,
                            p.active = !0
                        }
                    } else if (a.children.length > 1)
                        for (i = 0; i < a.children.length; i++)
                            -1 != a.children[i].name.indexOf("node_road") && a.children[i].getComponent(cc.RigidBody).syncPosition(!0)
                }
                var d = [];
                for (t = 0; t < this.saveTrackNode.length; t++)
                    "map1" == this.saveTrackNode[t].name && d.push(this.saveTrackNode[t]);
                d.sort(function(e, t) {
                    return e.x - t.x
                }),
                this.saveTrackStart = d[0],
                this.saveTrackEnd = d[1]
            }
            ,
            t.prototype.createHero = function(e) {
                var t = this;
                void 0 === e && (e = cc.v2(-180, -265)),
                null != this.saveHeroNode && (this.saveHeroNode.destroy(),
                this.saveHeroNode = null),
                d.default.resManager.loadPrefab("Main/role/role" + (f.default.NowHeroTT + 1)).then(function(n) {
                    n && (t.saveHeroNode = cc.instantiate(n),
                    t.saveHeroNode.parent = t.GameLayer,
                    t.saveHeroNode.position = e,
                    t.saveHeroNode.zIndex = 5,
                    t.saveHeroBody = t.saveHeroNode.getChildByName("node_body").getComponent(cc.RigidBody),
                    t.saveAfterBody = t.saveHeroNode.getChildByName("node_after").getComponent(cc.RigidBody),
                    t.saveFrontBody = t.saveHeroNode.getChildByName("node_front").getComponent(cc.RigidBody),
                    t.saveHeroBody.node.getChildByName("test").getComponent(l.default).initGame(t),
                    t.saveAfterBody.node.getComponent(l.default).initGame(t),
                    t.saveFrontBody.node.getComponent(l.default).initGame(t),
                    t.heroAnimation = t.saveHeroBody.node.getChildByName("hero").getComponent(dragonBones.ArmatureDisplay),
                    t.playDragonBones(s.WAIT, -1),
                    t.heroAnimation.addEventListener(dragonBones.EventObject.COMPLETE, t._animationEventHandler, t),
                    t.saveHeroBody.syncPosition(!0),
                    t.saveAfterBody.syncPosition(!0),
                    t.saveFrontBody.syncPosition(!0),
                    t.saveHeroBody.node.getChildByName("test").getComponent(cc.RigidBody).syncPosition(!0),
                    t.maxSpeed += 50 * f.default.maxSpeedLV,
                    t.sprintSpeed += 20 * f.default.sprintSpeedLV,
                    t.initMotoSlowAudio(1),
                    t.saveHeroNode.getChildByName("node_box").position = t.saveHeroBody.node.position,
                    t.saveHeroNode.getChildByName("node_box").getChildByName("name").getComponent(cc.Label).string = d.default.connect.GetMyName() ? d.default.connect.GetMyName() : "Player",
                    t.saveHeroNode.boxKeepSite = !1,
                    t.saveHeroNode.getChildByName("node_particle").getChildByName("shimmer").active = !1)
                })
            }
            ,
            t.prototype.startTimeDown = function() {
                var e = this
                  , t = this.GameLayerUI.getChildByName("TimeDown");
                if (t) {
                    f.default.playAudio("countdown", !1),
                    this.GameState = i.WAIT;
                    for (var n = function(n) {
                        setTimeout(function() {
                            n < 3 ? t.children[n] && cc.tween(t.children[n]).to(.1, {
                                y: 100,
                                opacity: 255
                            }, {
                                easing: "quadOut"
                            }).to(.8, {}).to(.1, {
                                opacity: 0
                            }).call(function() {
                                t.children[n].y = 200,
                                t.children[n].opacity = 0
                            }).start() : (t.children[n].scale = 5,
                            cc.tween(t.children[n]).to(.3, {
                                scale: 1,
                                opacity: 255
                            }).to(.5, {}).to(.2, {
                                opacity: 0
                            }).call(function() {
                                t.children[n].opacity = 0,
                                e.GameState = i.GAME,
                                e.saveHeroNode.boxKeepSite || (e.saveHeroNode.boxKeepSite = !0,
                                cc.tween(e.saveHeroNode.getChildByName("node_box")).to(1, {
                                    opacity: 255
                                }).start());
                                for (var o = 0; o < e.NPCCtrl.saveNPCNode.length; o++)
                                    e.NPCCtrl.saveNPCNode[o] && (e.NPCCtrl.saveNPCNode[o].boxKeepSite = !0,
                                    cc.tween(e.NPCCtrl.saveNPCNode[o].getChildByName("node_box")).to(1, {
                                        opacity: 255
                                    }).start());
                                e.isStartApplyForce && (e.initMotoFastAudio(2),
                                e.initMotoFastAudio(1),
                                e.initMotoSlowAudio(2),
                                e.initMotoAudio(2),
                                e.initMotoAudio(1))
                            }).start())
                        }, 1e3 * n)
                    }, o = 0; o < t.childrenCount; o++)
                        n(o)
                }
            }
            ,
            t.prototype.initNodePool = function() {
                this.scoreTextPool = new cc.NodePool;
                for (var e = 0; e < 30; e++) {
                    var t = cc.instantiate(this.scoreTextPre);
                    this.scoreTextPool.put(t)
                }
            }
            ,
            t.prototype.GameTouchStart = function() {
                this.isStartApplyForce = !0,
                this.turnUpState = !1,
                this.destoryLeader(),
                this.GameState == i.GAME && (this.isFlipState || this.DragonBonesName != s.RUSH && this.playDragonBones(s.RUSH, 1),
                this.initMotoFastAudio(1),
                this.initMotoSlowAudio(2),
                this.initMotoAudio(1))
            }
            ,
            t.prototype.GameTouchMove = function() {}
            ,
            t.prototype.GameTouchEnd = function() {
                this.isStartApplyForce = !1,
                this.GameState == i.GAME && (this.isFlipState || this.DragonBonesName != s.SHACHE1 && this.playDragonBones(s.SHACHE1, 1))
            }
            ,
            t.prototype.releaseGame = function() {
                this.NPCCtrl.releaseNPC(),
                f.default.NumScore = 0,
                f.default.NumGold = 0,
                this.GameState = i.WAIT,
                null != this.GameLayer && this.GameLayer.destroy(),
                this.GameLayer = null,
                null != this.resultNode && this.resultNode.destroy(),
                this.resultNode = null,
                this.homeChoseIndex = 0,
                this.GameLayerUI = null,
                this.RoadBox = null,
                this.batchBodyPos = [],
                this.saveTrackNode = [],
                this.saveTrackStart = null,
                this.saveTrackEnd = null,
                this.saveHeroNode = null,
                this.saveHeroBody = null,
                this.saveAfterBody = null,
                this.saveFrontBody = null,
                this.initRevivePoint = [],
                this.isStartApplyForce = !1,
                this.frontTestState = !0,
                this.afterTestState = !0,
                this.isFlipState = !1,
                this.isStartTimer = !1,
                this.doFilpTimer = 0,
                this.countFlipNum = 0,
                this.saveFilpNum = -1,
                this.maxSpeed = 3200,
                this.sprintSpeed = 500,
                this.nowFilpSpeed = 0,
                this.nowSpeed = 0,
                this.angleRemainder = -1,
                this.angleCircle = -1,
                this.turnUpState = !1,
                this.heroAnimation = null,
                this.DragonBonesName = "",
                this.initMainCameraX = -1,
                this.recordScoreDis = -1,
                this.totalLifes = 0,
                this.recordZoomY = -1,
                this.raceRanking = 0;
                for (var e = 0; e < this.ScollMapCamera.length; e++)
                    this.ScollMapCamera[e].zoomRatio = 1,
                    this.ScollMapCamera[e].node.x = 0;
                this.MainCamera.zoomRatio = 1,
                this.MainCamera.node.x = 0,
                this.npcRanking = [],
                this.nowRoleRace = -1,
                this.LeaderFilp = !1
            }
            ,
            t.prototype.heroToMove = function() {
                this.saveHeroBody && (this.saveHeroBody && null != this.saveHeroBody.node && (this.saveHeroBody.linearVelocity.x <= 30 || !this.frontTestState && !this.afterTestState ? (this.saveHeroNode.getChildByName("node_particle").getChildByName("Ffloor").active && (this.saveHeroNode.getChildByName("node_particle").getChildByName("Ffloor").active = !1),
                this.saveHeroNode.getChildByName("node_particle").getChildByName("Afloor").active && (this.saveHeroNode.getChildByName("node_particle").getChildByName("Afloor").active = !1)) : (this.saveHeroNode.getChildByName("node_particle").getChildByName("Ffloor").active || (this.saveHeroNode.getChildByName("node_particle").getChildByName("Ffloor").active = !0),
                this.saveHeroNode.getChildByName("node_particle").getChildByName("Afloor").active || (this.saveHeroNode.getChildByName("node_particle").getChildByName("Afloor").active = !0))),
                this.GameState != i.GAME && this.GameState != i.SUCCESS || (this.GameState == i.GAME ? (this.isStartApplyForce ? (this.saveHeroBody.angularDamping = 0,
                this.saveFrontBody.angularDamping = 0,
                this.saveAfterBody.angularDamping = 0,
                this.isFlipState ? (this.nowFilpSpeed -= 50,
                this.nowFilpSpeed < this.maxFilpSpeed && (this.nowFilpSpeed = this.maxFilpSpeed),
                this.saveHeroBody.angularVelocity = this.nowFilpSpeed) : this.saveHeroBody.angularVelocity = 0,
                this.nowSpeed += this.addSpeed,
                this.nowSpeed >= this.maxSpeed && (this.nowSpeed = this.maxSpeed),
                this.saveAfterBody.angularVelocity = this.nowSpeed,
                this.saveFrontBody.angularVelocity = this.nowSpeed) : this.isFlipState ? (this.saveHeroBody.angularVelocity = 0,
                this.nowFilpSpeed += 100,
                this.nowFilpSpeed > 0 && (this.nowFilpSpeed = 0),
                this.turnUpState || (this.turnUpState = !0,
                this.angleRemainder = this.saveHeroBody.node.angle % 360,
                this.angleCircle = Math.floor(this.saveHeroBody.node.angle / 360),
                this.angleCircle <= 0 && (this.angleCircle = 0),
                this.angleRemainder >= 240 ? (this.angleCircle += 1,
                this.turnUpNumber = 1) : this.angleRemainder <= 120 ? this.turnUpNumber = -1 : this.turnUpNumber = 0),
                this.saveHeroBody.node.angle += this.turnUpNumber,
                this.turnUpNumber < 0 ? this.saveHeroBody.node.angle <= 360 * this.angleCircle && (this.saveHeroBody.node.angle = 360 * this.angleCircle) : this.turnUpNumber > 0 && this.saveHeroBody.node.angle >= 360 * this.angleCircle && (this.saveHeroBody.node.angle = 360 * this.angleCircle),
                this.nowSpeed += this.addSpeed,
                this.nowSpeed >= this.maxSpeed && (this.nowSpeed = this.maxSpeed),
                this.saveAfterBody.angularVelocity = this.nowSpeed,
                this.saveFrontBody.angularVelocity = this.nowSpeed) : (this.nowSpeed -= this.addSpeed,
                this.nowSpeed <= 0 && (this.nowSpeed = 0),
                this.saveAfterBody.angularVelocity = this.nowSpeed,
                this.saveFrontBody.angularVelocity = this.nowSpeed),
                this.doLeaderFilp()) : (this.saveAfterBody.angularVelocity = 0,
                this.saveFrontBody.angularVelocity = 0,
                this.saveAfterBody.linearDamping = 3,
                this.saveFrontBody.linearDamping = 3,
                this.saveAfterBody.angularDamping = 5e3,
                this.saveFrontBody.angularDamping = 5e3)))
            }
            ,
            t.prototype.wheelTestFloor = function(e) {
                this.GameState == i.GAME && (this.isStartTimer = !1,
                this.isFlipState = !1,
                this.doFilpTimer = 0,
                this.turnUpState = !1,
                1 == e ? this.frontTestState = !0 : this.afterTestState = !0,
                this.extraUpSpeed(),
                this.isStartApplyForce ? this.DragonBonesName != s.RUSH && this.playDragonBones(s.RUSH, 1) : this.DragonBonesName != s.SHACHE1 && this.playDragonBones(s.SHACHE1, 1),
                this.frontTestState && this.afterTestState && (this.saveHeroNode.getChildByName("node_particle").getChildByName("shadow").active = !0))
            }
            ,
            t.prototype.contactTimer = function() {
                this.GameState == i.GAME && this.isStartTimer && (this.doFilpTimer += 1,
                this.doFilpTimer >= 30 && (this.doFilpTimer = 0,
                this.frontTestState || this.afterTestState || this.isFlipState || (this.isFlipState = !0,
                this.playDragonBones(s.FEIQI1, 1))))
            }
            ,
            t.prototype.judgeFilp = function() {
                var e = this;
                if (this.GameState == i.GAME) {
                    var t = Math.round(Math.abs(this.saveHeroBody.getWorldRotation() / 360));
                    if (t > 0 && t != this.saveFilpNum) {
                        this.saveFilpNum = t,
                        this.countFlipNum += 1,
                        d.default.resManager.loadPrefab("Other/Public/perfect").then(function(t) {
                            if (t) {
                                var n = cc.instantiate(t);
                                n.parent = e.saveHeroNode.getChildByName("node_box");
                                for (var o = 0; o < n.childrenCount; o++)
                                    n.children[o].active = !1;
                                var a = Math.randInt(1, 3);
                                if (n.getChildByName("p" + a).active = !0,
                                e.saveFriendsImage.length > 0) {
                                    n.getChildByName("head").active = !0;
                                    var r = Math.randInt(0, e.saveFriendsImage.length - 1);
                                    n.getChildByName("head").getChildByName("img").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(e.saveFriendsImage[r]),
                                    n.getChildByName("head").getChildByName("img").width = 78,
                                    n.getChildByName("head").getChildByName("img").height = 78,
                                    n.getChildByName("head").x = n.getChildByName("p" + a).x - n.getChildByName("p" + a).width / 2 - 50
                                } else
                                    n.getChildByName("head").active = !1;
                                n.x = 200,
                                n.y = 100,
                                n.scale = 0,
                                cc.tween(n).to(.4, {
                                    scale: .8
                                }, {
                                    easing: "elasticOut"
                                }).to(.5, {}).to(.5, {
                                    opacity: 50,
                                    y: 300
                                }).call(function() {
                                    n.destroy()
                                }).start()
                            }
                        }),
                        f.default.playAudio("soundshimmer", !1),
                        this.initGameScore(2),
                        this.rewardGold();
                        var n = this.saveHeroNode.getChildByName("node_particle").getChildByName("shimmer");
                        n.opacity = 0,
                        n.active = !0,
                        cc.tween(n).to(.15, {
                            opacity: 255,
                            scale: .6
                        }).to(.3, {}).to(.15, {
                            opacity: 0,
                            scale: .5
                        }).call(function() {
                            n.active = !1
                        }).start()
                    }
                }
            }
            ,
            t.prototype.extraUpSpeed = function() {
                if (this.saveHeroNode && null != this.saveHeroNode && this.afterTestState && this.frontTestState && 0 != this.countFlipNum) {
                    this.countFlipNum = 0,
                    this.saveAfterBody.linearVelocity = this.saveAfterBody.linearVelocity.clone().addSelf(cc.v2(this.sprintSpeed, 0)),
                    this.saveFrontBody.linearVelocity = this.saveFrontBody.linearVelocity.clone().addSelf(cc.v2(this.sprintSpeed, 0)),
                    this.saveHeroBody.linearVelocity = this.saveHeroBody.linearVelocity.clone().addSelf(cc.v2(this.sprintSpeed, 0));
                    for (var e = [], t = 0; t < this.saveHeroBody.node.children.length; t++) {
                        var n = this.saveHeroBody.node.children[t];
                        -1 != n.name.indexOf("shadow") && e.push(n)
                    }
                    var o = function(t) {
                        e[t].opacity = 40 + 30 * t,
                        e[t].active = !0,
                        cc.tween(e[t]).to(.05 * (7 - t) + .15, {
                            x: .956
                        }).call(function() {
                            e[t].active = !1,
                            e[t].x = -50 * (8 - t)
                        }).start()
                    };
                    for (t = 0; t < e.length; t++)
                        o(t)
                }
            }
            ,
            t.prototype.playDragonBones = function(e, t) {
                this.DragonBonesName = e,
                this.heroAnimation && this.heroAnimation.playAnimation(this.DragonBonesName, t)
            }
            ,
            t.prototype._animationEventHandler = function(e) {
                var t = this;
                e.type === dragonBones.EventObject.COMPLETE && (this.GameState == i.HOME && e.animationState.name == s.RUSH ? this.HomeLayer.getChildByName("homerole").getChildByName("content").children[this.homeChoseIndex].getChildByName("node_body").getChildByName("hero").getComponent(dragonBones.ArmatureDisplay).playAnimation(s.WAIT, -1) : e.animationState.name == s.FEIQI1 ? this.playDragonBones(s.FEIQI2, 1) : e.animationState.name == s.FEIQI2 ? this.playDragonBones(s.FEIQI3, 1) : e.animationState.name == s.SHACHE1 ? this.playDragonBones(s.SHACHE2, 1) : e.animationState.name == s.SHACHE2 ? this.playDragonBones(s.SHACHE3, 1) : e.animationState.name == s.SHACHE3 && (this.initMotoAudio(2),
                this.playDragonBones(s.WAIT, -1),
                this.GameState == i.SUCCESS ? f.default.ShowADNow(1).then(function() {
                    t.showResult()
                }).catch(function() {
                    t.showResult()
                }) : this.initMotoSlowAudio(1)))
            }
            ,
            t.prototype.initGameScore = function(e) {
                if (this.GameState == i.GAME)
                    if (1 == e) {
                        -1 == this.initMainCameraX && (this.initMainCameraX = this.MainCamera.node.x);
                        var t = this.MainCamera.node.x - this.initMainCameraX;
                        this.recordScoreDis != Math.floor(t / 100) && this.recordScoreDis < Math.floor(t / 100) && (this.recordScoreDis = Math.floor(t / 100),
                        this.recordScoreDis > 0 && this.recordScoreDis % 5 == 0 && (f.default.NumScore += 2))
                    } else
                        f.default.NumScore += 10
            }
            ,
            t.prototype.rewardGold = function() {
                var e = this;
                f.default.NumGold += 10,
                d.default.resManager.loadPrefab("Other/Public/node_rewardText").then(function(t) {
                    var n = cc.instantiate(t);
                    n.parent = e.saveHeroNode.getChildByName("node_box"),
                    n.y = 150,
                    n.getComponent(cc.Label).string = "AE10",
                    cc.tween(n).to(.8, {
                        y: 350,
                        opacity: 50
                    }).call(function() {
                        n.destroy()
                    }).start()
                })
            }
            ,
            t.prototype.bodyCollide = function() {
                var e = this;
                if (this.GameState == i.GAME) {
                    this.GameState = i.FAIL,
                    f.default.playAudio("soundboom", !1),
                    this.initMotoFastAudio(2),
                    this.initMotoSlowAudio(2),
                    this.initMotoAudio(2),
                    this.saveHeroNode.getChildByName("node_particle").active = !1,
                    this.isStartApplyForce = !1,
                    this.isFlipState = !1,
                    this.turnUpState = !1,
                    this.nowFilpSpeed = 0,
                    this.nowSpeed = 0,
                    this.isStartTimer = !1;
                    var t = this.GameLayer.convertToNodeSpaceAR(this.saveHeroNode.convertToWorldSpaceAR(this.saveHeroBody.node.position));
                    if (d.default.resManager.loadPrefab("Other/Particle/boom").then(function(n) {
                        if (n) {
                            f.default.playVibrate(80);
                            var o = cc.instantiate(n);
                            o.parent = e.GameLayer,
                            o.zIndex = 3,
                            o.position = t
                        }
                    }),
                    this.saveHeroBody.node.destroy(),
                    this.saveHeroNode.getChildByName("node_particle").destroy(),
                    this.saveHeroNode.getChildByName("node_box").destroy(),
                    this.totalLifes > 0) {
                        this.totalLifes -= 1,
                        this.countFlipNum = 0,
                        this.initRevivePoint.sort(function(e, t) {
                            return e.x - t.x
                        });
                        for (var n = 0, o = 0; o < this.initRevivePoint.length; o++)
                            t.x >= this.initRevivePoint[o].x && (n += 1);
                        if (0 == n || 0 == this.initRevivePoint.length) {
                            var a = cc.v2(this.saveTrackStart.x, -265);
                            this.takeoffLifeGoon(a)
                        } else
                            n > 0 && (a = cc.v2(this.initRevivePoint[n - 1].x, -265),
                            this.takeoffLifeGoon(a))
                    } else
                        f.default.ShowADNow(1).then(function() {
                            e.showFail()
                        }).catch(function() {
                            e.showFail()
                        })
                }
            }
            ,
            t.prototype.takeoffLifeGoon = function(e) {
                var t = this;
                cc.tween(this.GameLayerUI.getChildByName("node_life").getChildByName("life2_" + (this.totalLifes + 1))).to(1, {
                    scale: 0,
                    angle: -1440
                }).call(function() {
                    t.createHero(e),
                    cc.tween(t.MainCamera.node).to(.8, {
                        x: e.x + 180
                    }).call(function() {
                        t.GameState = i.GAME,
                        t.saveHeroNode && (t.saveHeroBody.node.getChildByName("hero").getComponent(c.default).startToFlash(.2),
                        t.saveAfterBody.node.getComponent(c.default).startToFlash(.2),
                        t.saveFrontBody.node.getComponent(c.default).startToFlash(.2))
                    }).start()
                }).start()
            }
            ,
            t.prototype.showResult = function() {
                var e = this;
				window.cy_Sdk && window.cy_Sdk.adShow();
				window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_END,"Pass");
				window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_REWARD,1);
                null != this.resultNode && (this.resultNode.destroy(),
                this.resultNode = null),
                d.default.resManager.loadPrefab("Other/Public/node_result").then(function(t) {
                    if (t) {
                        e.resultNode = cc.instantiate(t),
                        e.resultNode.parent = e.node,
                        e.resultNode.opacity = 0;
                        for (var n = e.resultNode.getChildByName("node_bg"), o = 1; o < 4; o++)
                            n.getChildByName("item" + o).x = -cc.winSize.width / 2 - n.getChildByName("item" + o).width;
                        for (o = 0; o < e.npcRanking.length; o++)
                            e.npcRanking[o].npc && (n.getChildByName("item" + e.npcRanking[o].ranking).getChildByName("headmask").getChildByName("img").getComponent(cc.Sprite).spriteFrame = e.npcRanking[o].npc.getChildByName("node_box").getChildByName("flag").getChildByName("circle").getComponent(cc.Sprite).spriteFrame,
                            n.getChildByName("item" + e.npcRanking[o].ranking).getChildByName("headmask").getChildByName("img").width = 46,
                            n.getChildByName("item" + e.npcRanking[o].ranking).getChildByName("headmask").getChildByName("img").height = 46,
                            n.getChildByName("item" + e.npcRanking[o].ranking).getChildByName("text").getComponent(cc.Label).string = e.npcRanking[o].npc.getChildByName("node_box").getChildByName("name").getComponent(cc.Label).string,
                            cc.tween(n.getChildByName("item" + e.npcRanking[o].ranking)).to(.25 * e.npcRanking[o].ranking, {}).to(1, {
                                x: 0
                            }, {
                                easing: "elasticOut"
                            }).start());
                        e.nowRoleRace <= 3 ? (n.getChildByName("item" + e.nowRoleRace).getChildByName("text").getComponent(cc.Label).string = e.saveHeroNode.getChildByName("node_box").getChildByName("name").getComponent(cc.Label).string,
                        cc.tween(n.getChildByName("item" + e.nowRoleRace)).to(.25 * e.nowRoleRace, {}).to(1, {
                            x: 0
                        }, {
                            easing: "elasticOut"
                        }).start(),
                        cc.assetManager.loadRemote(d.default.connect.GetMyImage(), {
                            ext: ".png"
                        }, function(t, o) {
                            if (!t) {
                                var a = n.getChildByName("item" + e.nowRoleRace).getChildByName("headmask").getChildByName("img");
                                a.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(o),
                                a.width = 50,
                                a.height = 50
                            }
                        }),
                        n.getChildByName("item" + e.nowRoleRace).getChildByName("lightmask").active = !0,
                        cc.tween(n.getChildByName("item" + e.nowRoleRace).getChildByName("lightmask").getChildByName("light")).to(.8, {
                            x: 280
                        }).call(function() {
                            n.getChildByName("item" + e.nowRoleRace) && (n.getChildByName("item" + e.nowRoleRace).getChildByName("lightmask").getChildByName("light").x = -280)
                        }).to(.5, {}).union().repeatForever().start(),
                        n.getChildByName("node_icon").getComponent(cc.Sprite).spriteFrame = e.trophySP[e.nowRoleRace - 1]) : n.getChildByName("node_icon").getComponent(cc.Sprite).spriteFrame = e.trophySP[3];
                        var a = 0;
                        1 == e.nowRoleRace ? a = 3 : 2 == e.nowRoleRace ? a = 2 : 3 == e.nowRoleRace && (a = 1),
                        f.default.NumGold += 50 * a,
                        n.getChildByName("GoldText").getComponent(cc.Label).string = "AE" + f.default.NumGold,
                        e.resultNode.getChildByName("node_NumGoldTT").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumGoldTT,
						e.resultNode.getChildByName("node_invite").active =0,
                        cc.tween(e.resultNode.getChildByName("node_light")).tag(2).by(2, {
                            angle: -90
                        }).repeatForever().start(),
                        cc.tween(e.resultNode).to(.5, {
                            opacity: 255
                        }).call(function() {
                            f.default.playAudio("soundsuccess", !1),
                            a > 0 && e.rotateStar(a),
                            e.nowRoleRace <= 3 && (f.default.NumGateTT += 1),
                            f.default.NumGoldTT += f.default.NumGold,
                            f.default.NumStarTT += a,
                            f.default.SaveGameScore(),
                            d.default.connect.UpLoadScore(f.default.NumStarTT, {
                                skin: f.default.NowHeroTT
                            }),
                            d.default.connect.setCurentScore(f.default.NumStarTT),
                            e.resultNode.getChildByName("node_home").on(cc.Node.EventType.TOUCH_END, function() {
                                e.returnHome()
                            }),
                            e.resultNode.getChildByName("node_resultad").on(cc.Node.EventType.TOUCH_END, function() {
                                f.default.playAudio("soundpress", !1),
								window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.REWARD_CLICK,"More Claim"),
                                f.default.ShowADNow(0).then(function() {
                                    e.resultClaimCoins()
                                }).catch(function() {})
                            }),
                            e.resultNode.getChildByName("node_invite").on(cc.Node.EventType.TOUCH_END, function() {
                                f.default.playAudio("soundpress", !1),
                                d.default.connect.shareInvite()
                            }),
                            n.getChildByName("close").on(cc.Node.EventType.TOUCH_END, function() {
                                f.default.playAudio("soundpress", !1),
                                e.GameState != i.GAME && (f.default.playAudio("soundpress", !1),
                                e.resultNode.destroy(),
                                e.resultNode = null,
                                e.releaseGame(),
                                e.startGame(),window.cy_Sdk && window.cy_Sdk.adHide())
                            })
                        }).start()
                    }
                })
            }
            ,
            t.prototype.rotateStar = function(e) {
                for (var t = this, n = this, o = function(e) {
                    setTimeout(function() {
                        null != n.resultNode && d.default.resManager.loadPrefab("Other/Public/star").then(function(o) {
                            if (o) {
                                var a = cc.instantiate(o);
                                a.parent = n.resultNode.getChildByName("node_bg").getChildByName("node_star" + (e + 1)),
                                a.scale = 0,
                                a.zIndex = 2,
                                cc.tween(a).tag(-2).to(1, {
                                    angle: -720,
                                    scale: 1
                                }).call(function() {
                                    f.default.playAudio("soundStar" + (e + 1), !1),
                                    "" != t.resultNode.name && d.default.resManager.loadPrefab("Other/Particle/node_star").then(function(t) {
                                        var o = cc.instantiate(t);
                                        o.parent = n.resultNode.getChildByName("node_bg").getChildByName("node_star" + (e + 1)),
                                        o.x = a.x,
                                        o.y = a.y,
                                        o.zIndex = 0
                                    })
                                }).start()
                            }
                        })
                    }, 500 * e)
                }, a = 0; a < e; a++)
                    o(a)
            }
            ,
            t.prototype.resultClaimCoins = function() {
                f.default.NumGoldTT -= f.default.NumGold,
                f.default.NumGoldTT += 3 * f.default.NumGold,
                f.default.SaveGameScore(),
                this.resultNode.getChildByName("node_resultad").active = !1,
                f.default.showTipRemind("You got " + 3 * f.default.NumGold + " Coins!", 56);
                var e = this.resultNode.convertToNodeSpaceAR(this.resultNode.getChildByName("node_bg").convertToWorldSpaceAR(this.resultNode.getChildByName("node_bg").getChildByName("GoldText").position))
                  , t = this.resultNode.getChildByName("node_NumGoldTT").position;
                t.x -= 58,
                this.playCoinFlyAnim(this.resultNode, 10, e, t)
            }
            ,
            t.prototype.showFail = function() {
                var e = this;
				window.cy_Sdk && window.cy_Sdk.adShow();
				window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_END,"Fail");
				window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_REWARD,1);
                null != this.resultNode && (this.resultNode.destroy(),
                this.resultNode = null),
                d.default.resManager.loadPrefab("Other/Public/node_fail").then(function(t) {
                    t && (e.resultNode = cc.instantiate(t),
                    e.resultNode.parent = e.node,
                    e.resultNode.opacity = 0,
					e.resultNode.getChildByName("node_invite").active = 0,
                    cc.tween(e.resultNode).to(.2, {}).to(.5, {
                        opacity: 255
                    }).call(function() {
                        e.resultNode.getChildByName("node_home").on(cc.Node.EventType.TOUCH_END, function() {
                            e.returnHome()
                        }),
                        e.resultNode.getChildByName("node_goon").on(cc.Node.EventType.TOUCH_END, function() {
                            e.GameState != i.GAME && (f.default.playAudio("soundpress", !1),
                            e.resultNode.destroy(),
                            e.resultNode = null,
                            e.releaseGame(),
                            e.startGame(),window.cy_Sdk && window.cy_Sdk.adHide())
                        }),
                        e.resultNode.getChildByName("node_invite").on(cc.Node.EventType.TOUCH_END, function() {
                            f.default.playAudio("soundpress", !1),
                            d.default.connect.shareInvite()
                        })
                    }).start())
                })
            }
            ,
            t.prototype.syncCamera = function(e) {
                if (this.NPCCtrl && this.NPCCtrl.keepSite(e),
                this.GameState == i.GAME || this.GameState == i.WAIT || this.GameState == i.SUCCESS) {
                    var t = this.node.convertToNodeSpaceAR(this.saveHeroBody.node.convertToWorldSpaceAR(cc.Vec2.ZERO));
                    t.x += 180,
                    t.y = 0;
                    var n = cc.v2(t.x, 0);
                    this.MainCamera.node.setPosition(n);
                    for (var o = [0, 80, 60, 20, 90], a = 0; a < this.ScollMapCamera.length; a++)
                        0 != o[a] && (this.ScollMapCamera[a].node.x += e * (this.saveHeroBody.linearVelocity.x / o[a]),
                        this.ScollMapCamera[a].node.x > 1600 && (this.ScollMapCamera[a].node.x = 0));
                    if (-1 != this.recordZoomY) {
                        var r = (this.saveHeroBody.node.convertToWorldSpaceAR(cc.Vec2.ZERO).y - this.recordZoomY) / cc.winSize.height
                          , s = 1 - r;
                        s >= 1 && (s = 1),
                        s = s <= .6 ? .6 : s,
                        this.MainCamera.zoomRatio = s;
                        var c = [0, .2, .2, .2, .2];
                        for (a = 0; a < this.ScollMapCamera.length; a++)
                            if (0 != o[a]) {
                                var l = 1 - r * c[a];
                                l = l > 1 ? 1 : l,
                                this.ScollMapCamera[a].zoomRatio = l
                            }
                    }
                    this.saveHeroNode.boxKeepSite && (this.saveHeroNode.getChildByName("node_box").position = this.saveHeroBody.node.position),
                    this.saveHeroNode.getChildByName("node_particle").position = this.saveHeroBody.node.position,
                    this.saveHeroNode.getChildByName("node_particle").angle = this.saveHeroBody.node.angle,
                    this.saveHeroBody.node.getChildByName("test").position = cc.v2(10, 60)
                }
            }
            ,
            t.prototype.doGameLeader = function() {
                var e = this;
                1 == f.default.NumGateTT ? (this.GameState = i.WAIT,
                d.default.resManager.loadPrefab("Main/view/Leader").then(function(t) {
                    if (t) {
                        e.LeaderLayer = cc.instantiate(t),
                        e.LeaderLayer.parent = e.GameLayerUI,
                        e.LeaderLayer.opacity = 0,
                        cc.tween(e.LeaderLayer).to(.4, {
                            opacity: 255
                        }).call(function() {
                            e.LeaderLayer.on(cc.Node.EventType.TOUCH_END, function() {
                                null != e.LeaderLayer && (e.LeaderLayer.destroy(),
                                e.LeaderLayer = null,
                                e.startTimeDown())
                            })
                        }).start();
                        for (var n = 0; n < 3; n++)
                            cc.tween(e.LeaderLayer.getChildByName("leadcircle" + (n + 1))).delay(.5 + .5 * n).repeat(9e4, cc.tween().set({
                                opacity: 255,
                                scale: .5
                            }).parallel(cc.tween().to(1.5, {
                                opacity: 0,
                                scale: 2.5
                            }), cc.tween().to(1.5, {})).delay(1)).start()
                    }
                })) : this.startTimeDown()
            }
            ,
            t.prototype.doLeaderFilp = function() {
                var e = this;
                1 == f.default.NumGateTT && !this.LeaderFilp && this.MainCamera.node.x >= 3600 && (this.LeaderFilp = !0,
                this.GameState = i.WAIT,
                d.default.resManager.loadPrefab("Main/view/Leader").then(function(t) {
                    t && (e.LeaderLayer = cc.instantiate(t),
                    e.LeaderLayer.parent = e.GameLayerUI,
                    e.LeaderLayer.getChildByName("icon1").active = !1,
                    e.LeaderLayer.getChildByName("icon2").active = !0,
                    e.LeaderLayer.getComponent(cc.BlockInputEvents).destroy(),
                    e.LeaderLayer.getChildByName("leadhand").active = !1,
                    e.LeaderLayer.getChildByName("leadcircle1").active = !1,
                    e.LeaderLayer.getChildByName("leadcircle2").active = !1,
                    e.LeaderLayer.getChildByName("leadcircle3").active = !1,
                    e.LeaderLayer.opacity = 0,
                    cc.tween(e.LeaderLayer).to(.2, {
                        opacity: 255
                    }).call(function() {
                        cc.director.pause()
                    }).start())
                }))
            }
            ,
            t.prototype.destoryLeader = function() {
                this.LeaderFilp && null != this.LeaderLayer && (cc.director.resume(),
                this.LeaderLayer.destroy(),
                this.LeaderLayer = null,
                this.GameState = i.GAME)
            }
            ,
            t.prototype.initMotoFastAudio = function(e) {
                f.default.AudioState && (1 == e ? (this.initMotoFastAudio(2),
                this.soundFastSpeed = cc.audioEngine.play(this.motoAudio[0], !1, 1)) : null != this.soundFastSpeed && cc.audioEngine.stop(this.soundFastSpeed))
            }
            ,
            t.prototype.initMotoSlowAudio = function(e) {
                f.default.AudioState && (1 == e ? (this.initMotoSlowAudio(2),
                this.soundSlowSpeed = cc.audioEngine.play(this.motoAudio[1], !0, 1)) : null != this.soundSlowSpeed && cc.audioEngine.stop(this.soundSlowSpeed))
            }
            ,
            t.prototype.initMotoAudio = function(e) {
                f.default.AudioState && (1 == e ? (this.initMotoAudio(2),
                this.soundMoto = cc.audioEngine.play(this.motoAudio[2], !0, 1)) : null != this.soundMoto && cc.audioEngine.stop(this.soundMoto))
            }
            ,
            t.prototype.getLevelMessage = function() {
                for (var e = this, t = function(t) {
                    d.default.resManager.loadPrefab("Other/Level/Level" + t).then(function(n) {
                        if (n)
                            for (var o = cc.instantiate(n), a = 0; a < o.children.length; a++) {
                                0 == a && (e.GameData.nodeName = [],
                                e.GameData.nodeStateX = [],
                                e.GameData.nodeStateY = [],
                                e.GameData.nodeStateScaleX = [],
                                e.GameData.nodeStateScaleY = []),
                                e.GameData.nodeName.push('"' + o.children[a].name + '"'),
                                e.GameData.nodeStateX.push(o.children[a].x),
                                e.GameData.nodeStateY.push(o.children[a].y - 100),
                                e.GameData.nodeStateScaleX.push(o.children[a].scaleX),
                                e.GameData.nodeStateScaleY.push(o.children[a].scaleY);
                                for (var r = o.children[a], i = 0; i < r.children.length; i++)
                                    if ("map8" == r.children[i].name || "map9" == r.children[i].name) {
                                        var s = o.convertToNodeSpaceAR(r.children[i].parent.convertToWorldSpaceAR(r.children[i].position));
                                        e.GameData.nodeName.push('"' + r.children[i].name + '"'),
                                        e.GameData.nodeStateX.push(s.x),
                                        e.GameData.nodeStateY.push(s.y - 100),
                                        e.GameData.nodeStateScaleX.push(r.children[i].scaleX),
                                        e.GameData.nodeStateScaleY.push(r.children[i].scaleY)
                                    }
                                a == o.children.length - 1 && (console.log("case " + t + ":"),
                                console.log("this.nodeName = [" + e.GameData.nodeName + "];"),
                                console.log("this.nodeStateX = [" + e.GameData.nodeStateX + "];"),
                                console.log("this.nodeStateY = [" + e.GameData.nodeStateY + "];"),
                                console.log("this.nodeStateScaleX = [" + e.GameData.nodeStateScaleX + "];"),
                                console.log("this.nodeStateScaleY = [" + e.GameData.nodeStateScaleY + "];"),
                                console.log("break;"))
                            }
                    })
                }, n = 1; n <= 10; n++)
                    t(n)
            }
            ,
            t.prototype.CheckADVideo = function() {
                f.default.countNumTime += 1,
                f.default.countNumTime >= 10 && (f.default.countNumTime = 0,
                f.default.NumTimeAD += 1),
                -1 == f.default.VideoState && (f.default.VideoState = d.default.connect.GetADVideoState(),
                0 == f.default.VideoState || 1 == f.default.VideoState && (f.default.NumTimeAD = 0))
            }
            ,
            t.prototype.playCoinFlyAnim = function(e, t, n, o, a) {
                var r = this;
                void 0 === a && (a = 80);
                var i = this.getCirclePoints(a, n, t).map(function(t) {
                    var a = null;
                    return a = cc.instantiate(r.coinsIcon),
                    e.addChild(a),
                    a.setPosition(n),
                    {
                        node: a,
                        stPos: n,
                        mdPos: t,
                        edPos: o,
                        dis: t.sub(o).mag()
                    }
                });
                (i = i.sort(function(e, t) {
                    return e.dis - t.dis > 0 ? 1 : e.dis - t.dis < 0 ? -1 : 0
                })).forEach(function(n, o) {
                    n && n.node && n.node.runAction(cc.sequence(cc.moveTo(.3, n.mdPos), cc.delayTime(.01 * o), cc.moveTo(.5, n.edPos), cc.callFunc(function() {
                        n.node.destroy(),
                        o == t - 1 && (e.getChildByName("node_NumGoldTT").getChildByName("text").getComponent(cc.Label).string = "" + f.default.NumGoldTT)
                    })))
                })
            }
            ,
            t.prototype.getCirclePoints = function(e, t, n, o) {
                void 0 === o && (o = 60);
                for (var a = [], r = Math.PI / 180 * Math.round(360 / n), i = 0; i < n; i++) {
                    var s = t.x + e * Math.sin(r * i)
                      , c = t.y + e * Math.cos(r * i);
                    a.unshift(cc.v3(s + Math.random() * o, c + Math.random() * o, 0))
                }
                return a
            }
            ,
            t.prototype.shuffle = function(e) {
                for (var t, n, o = e.length; o > 0; )
                    t = Math.floor(Math.random() * o),
                    n = e[o - 1],
                    e[o - 1] = e[t],
                    e[t] = n,
                    o--;
                return e
            }
            ,
            r([g({
                type: cc.Camera,
                tooltip: "\u7cfb\u7edf\u6444\u50cf\u673a"
            })], t.prototype, "MainCamera", void 0),
            r([g({
                type: cc.Camera,
                tooltip: "\u6eda\u52a8\u5730\u56fe\u6444\u50cf\u673a"
            })], t.prototype, "ScollMapCamera", void 0),
            r([g({
                type: cc.Prefab,
                tooltip: "\u8def\u9762\u9884\u5236"
            })], t.prototype, "RoadPrefab", void 0),
            r([g({
                type: cc.Prefab,
                tooltip: "\u52a0\u5206\u8282\u70b9"
            })], t.prototype, "scoreTextPre", void 0),
            r([g({
                type: cc.Prefab,
                tooltip: "\u91d1\u5e01"
            })], t.prototype, "coinsIcon", void 0),
            r([g({
                type: cc.SpriteFrame,
                tooltip: "\u7ed3\u675f\u9875\u9762\u5956\u676f\u56fe\u7247"
            })], t.prototype, "trophySP", void 0),
            r([g({
                type: cc.AudioClip,
                tooltip: "\u6469\u6258\u97f3\u6548"
            })], t.prototype, "motoAudio", void 0),
            r([v], t)
        }(cc.Component);
        n.default = P,
        cc._RF.pop()
    }
    , {
        "../Function/Flash": "Flash",
        "../Function/HeroContact": "HeroContact",
        "../Function/NPCCtrl": "NPCCtrl",
        "../GameMessage": "GameMessage",
        "../Module/App": "App",
        "../Utils/GameUtils": "GameUtils",
        "../View/GameRank": "GameRank",
        "../View/GameSetting": "GameSetting"
    }],
    GameSetting: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "a91fbQ2nQlOFooCr1rw5B2z", "GameSetting");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = e("../Utils/GameUtils")
          , s = cc._decorator
          , c = s.ccclass
          , l = s.property
          , u = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.settingSprite = [],
                t.GS = null,
                t
            }
            return a(t, e),
            t.prototype.initGame = function(e) {
                var t = this;
                this.GS = e,
                this.systemSetting(3),
                this.node.getChildByName("node_play").state = "hide",
                this.node.getChildByName("node_help").active = !1,
                this.node.getChildByName("node_audio").on(cc.Node.EventType.TOUCH_END, function() {
                    t.systemSetting(1)
                }),
                this.node.getChildByName("node_shock").on(cc.Node.EventType.TOUCH_END, function() {
                    t.systemSetting(2)
                }),
                this.node.getChildByName("node_play").on(cc.Node.EventType.TOUCH_END, function() {
                    i.default.playAudio("soundpress", !1),
                    t.systemHelp()
                }),
                this.node.getChildByName("node_help").getChildByName("panel").getChildByName("close").on(cc.Node.EventType.TOUCH_END, function() {
                    i.default.playAudio("soundpress", !1),
                    t.systemHelp()
                }),
                this.node.getChildByName("maskbg").on(cc.Node.EventType.TOUCH_END, function() {
                    t.closeSetting()
                })
            }
            ,
            t.prototype.closeSetting = function() {
                255 == this.GS.settingPage.opacity && (null != this.GS.settingPage && (this.GS.settingPage.destroy(),
                this.GS.settingPage = null),
                i.default.playAudio("soundpress", !1))
            }
            ,
            t.prototype.systemSetting = function(e) {
                1 == e ? (1 == i.default.AudioState ? (i.default.AudioState = !1,
                this.node.getChildByName("node_audio").getComponent(cc.Sprite).spriteFrame = this.settingSprite[1],
                this.GS.HomeLayer.getComponent(cc.AudioSource).stop()) : (i.default.AudioState = !0,
                this.node.getChildByName("node_audio").getComponent(cc.Sprite).spriteFrame = this.settingSprite[0],
                this.GS.HomeLayer.getComponent(cc.AudioSource).play()),
                i.default.SaveGameScore(),
                i.default.playAudio("soundpress", !1)) : 2 == e ? (1 == i.default.VibrateState ? (i.default.VibrateState = !1,
                this.node.getChildByName("node_shock").getComponent(cc.Sprite).spriteFrame = this.settingSprite[3]) : (i.default.VibrateState = !0,
                this.node.getChildByName("node_shock").getComponent(cc.Sprite).spriteFrame = this.settingSprite[2]),
                i.default.SaveGameScore(),
                i.default.playAudio("soundpress", !1)) : 3 == e && (1 == i.default.AudioState ? this.node.getChildByName("node_audio").getComponent(cc.Sprite).spriteFrame = this.settingSprite[0] : this.node.getChildByName("node_audio").getComponent(cc.Sprite).spriteFrame = this.settingSprite[1],
                1 == i.default.VibrateState ? this.node.getChildByName("node_shock").getComponent(cc.Sprite).spriteFrame = this.settingSprite[2] : this.node.getChildByName("node_shock").getComponent(cc.Sprite).spriteFrame = this.settingSprite[3])
            }
            ,
            t.prototype.systemHelp = function() {
                "hide" == this.node.getChildByName("node_play").state ? (this.node.getChildByName("node_play").state = "show",
                this.node.getChildByName("node_help").active = !0) : (this.node.getChildByName("node_play").state = "hide",
                this.node.getChildByName("node_help").active = !1)
            }
            ,
            r([l({
                type: cc.SpriteFrame,
                tooltip: ""
            })], t.prototype, "settingSprite", void 0),
            r([c], t)
        }(cc.Component);
        n.default = u,
        cc._RF.pop()
    }
    , {
        "../Utils/GameUtils": "GameUtils"
    }],
    GameUtils: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "e557c3s3z5FmJVwfyGLlc1Y", "GameUtils");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = e("../Module/App")
          , s = e("../FBGameConfig")
          , c = cc._decorator
          , l = c.ccclass
          , u = (c.property,
        function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            var n;
            return a(t, e),
            n = t,
            t.initConnect = function() {
                n.GameConnect || (n.GameConnect = i.default.connect)
            }
            ,
            t.SaveGameScore = function() {
                var e = {
                    NowHeroTTs: n.NowHeroTT,
                    NowHeroLockStates: n.NowHeroLockState,
                    NowGateTTs: n.NumGateTT,
                    NumGoldTTs: n.NumGoldTT,
                    NumScoreTTs: n.NumScoreTT,
                    AudioStates: n.AudioState,
                    VibrateStates: n.VibrateState,
                    NumStarTTs: n.NumStarTT,
                    maxSpeedLVs: n.maxSpeedLV,
                    sprintSpeedLVs: n.sprintSpeedLV
                };
                n.GameConnect.setData(e)
            }
            ,
            t.LoadGameScore = function(e) {
                void 0 === e && (e = 1);
                var t = n.GameConnect.readData();
                if (null == t || null == t.NowGateTTs || 0 == t.NowGateTTs)
                    n.NowHeroTT = 0,
                    n.NowHeroLockState = [1, 0, 0, 0, 0, 0],
                    n.NumGateTT = 1,
                    n.NumGoldTT = 100,
                    n.NumScoreTT = 0,
                    n.AudioState = !0,
                    n.VibrateState = !0,
                    n.NumStarTT = 0,
                    n.maxSpeedLV = 0,
                    n.sprintSpeedLV = 0,
                    n.SaveGameScore();
                else {
                    var o = t;
                    n.NowHeroTT = null != o.NowHeroTTs ? o.NowHeroTTs : 0,
                    n.NowHeroLockState = null != o.NowHeroLockStates ? o.NowHeroLockStates : [1, 0, 0, 0, 0, 0],
                    n.NumGateTT = null != o.NowGateTTs ? o.NowGateTTs : 1,
                    n.NumGoldTT = null != o.NumGoldTTs ? o.NumGoldTTs : 100,
                    n.NumScoreTT = null != o.NumScoreTTs ? o.NumScoreTTs : 0,
                    n.AudioState = null == o.AudioStates || o.AudioStates,
                    n.VibrateState = null == o.VibrateStates || o.VibrateStates,
                    n.NumStarTT = null != o.NumStarTTs ? o.NumStarTTs : 0,
                    n.maxSpeedLV = null != o.maxSpeedLVs ? o.maxSpeedLVs : 0,
                    n.sprintSpeedLV = null != o.sprintSpeedLVs ? o.sprintSpeedLVs : 0,
                    n.SaveGameScore()
                }
            }
            ,
            t.initNumTimeAD = function() {
                n.NumTimeAD || (n.NumTimeAD = s.default.InitADTime)
            }
            ,
            t.ShowADNow = function(e) {
                return new Promise(function(t, o) {
                    n.VideoPlayState = "start",
                    0 == e ? 1 == platform.hasRAD() ? (i.default.connect.ShowADVideo().then(function() {
                        t()
                    }).catch(function() {
                        o()
                    }),
                    n.VideoState = -1) : (o(),
                    n.showTipRemind("No ads for now!", 52)) : 1 == e && (n.NumTimeAD >= s.default.ShowADTime && 1 == platform.hasIAD() ? (n.NumTimeAD = 0,
                    i.default.connect.ShowADChaping().then(function() {
                        t()
                    }).catch(function() {
                        t()
                    })) : (t(),
                    console.log("\u65e0\u63d2\u5c4f\u5e7f\u544a time: " + n.NumTimeAD)))
                }
                )
            }
            ,
            t.initPhysicsDeploy = function(e) {
                if (1 != e && 3 != e || (cc.director.getCollisionManager().enabled = !0,
                cc.director.getCollisionManager().enabledDebugDraw = !0,
                cc.director.getCollisionManager().enabledDrawBoundingBox = !1),
                2 == e || 3 == e)
                    if (cc.director.getPhysicsManager().enabled = !0,
                    cc.director.getPhysicsManager().enabledAccumulator = !0,
                    cc.director.getPhysicsManager().gravity = cc.v2(0, n.G),
                    n.isDebug) {
                        var t = cc.PhysicsManager.DrawBits;
                        cc.director.getPhysicsManager().debugDrawFlags = t.e_jointBit | t.e_shapeBit
                    } else
                        cc.director.getPhysicsManager().debugDrawFlags = 0;
                -1 == e && (cc.director.getPhysicsManager().enabled = !1,
                cc.director.getPhysicsManager().enabledAccumulator = !1)
            }
            ,
            t.autoAdapter = function() {
                var e = cc.find("Canvas").getComponent(cc.Canvas)
                  , t = e.designResolution
                  , n = cc.view.getFrameSize();
                n.width / n.height >= t.width / t.height ? (e.fitWidth = !1,
                e.fitHeight = !0) : (e.fitWidth = !0,
                e.fitHeight = !1),
                console.warn(e.fitWidth, e.fitHeight)
            }
            ,
            t.showTipRemind = function(e, t, o) {
                void 0 === o && (o = !0),
                i.default.resManager.loadPrefab("Other/Public/node_remind").then(function(a) {
                    if (a) {
                        var r = cc.instantiate(a);
                        r.parent = cc.find("Canvas"),
                        r.zIndex = 100,
                        r.y = 100,
                        r.opacity = 0,
                        r.scaleX = .3,
                        r.scaleY = .3;
                        var i = r.getChildByName("remindText");
                        i.getComponent(cc.Label).string = e,
                        i.getComponent(cc.Label).fontSize = t,
                        cc.tween(r).to(.3, {
                            scaleX: 1,
                            scaleY: 1
                        }, {
                            easing: "sineOut"
                        }).start(),
                        cc.tween(r).to(.2, {
                            opacity: 255
                        }).to(1, {}).to(.4, {
                            y: r.y + 120,
                            opacity: 0
                        }).call(function() {
                            r.destroy()
                        }).start(),
                        o && n.playAudio("soundwarn", !1)
                    }
                })
            }
            ,
            t.playAudio = function(e, t) {
                if (0 != n.AudioState) {
                    var o = "Main/Audio/" + e;
                    i.default.resManager.loadAudioClipAsset(o).then(function(e) {
                        e && cc.audioEngine.playEffect(e, t)
                    })
                }
            }
            ,
            t.playVibrate = function(e) {
                0 != n.VibrateState && "vibrate"in window.navigator && navigator.vibrate(e)
            }
            ,
            t.FormatTime = function(e) {
                var t = new Date
                  , n = {
                    "M+": t.getMonth() + 1,
                    "d+": t.getDate(),
                    "H+": t.getHours(),
                    "m+": t.getMinutes(),
                    "s+": t.getSeconds(),
                    "q+": Math.floor((t.getMonth() + 3) / 3),
                    S: t.getMilliseconds()
                };
                for (var o in /(y+)/.test(e) && (e = e.replace(RegExp.$1, (t.getFullYear() + "").substr(4 - RegExp.$1.length))),
                n)
                    new RegExp("(" + o + ")").test(e) && (e = e.replace(RegExp.$1, 1 == RegExp.$1.length ? n[o] : ("00" + n[o]).substr(("" + n[o]).length)));
                return e
            }
            ,
            t.setStatsColor = function(e, t) {
                void 0 === e && (e = cc.Color.WHITE),
                void 0 === t && (t = cc.color(0, 0, 0, 150));
                var n = cc.find("PROFILER-NODE");
                if (!n)
                    return cc.warn("\u672a\u627e\u5230\u7edf\u8ba1\u9762\u677f\u8282\u70b9\uff01");
                n.children.forEach(function(t) {
                    return t.color = e
                });
                var o = n.getChildByName("BACKGROUND");
                o || (o = new cc.Node("BACKGROUND"),
                n.addChild(o, cc.macro.MIN_ZINDEX),
                o.setContentSize(n.getBoundingBoxToWorld()),
                o.setPosition(0, 0));
                var a = o.getComponent(cc.Graphics) || o.addComponent(cc.Graphics);
                a.clear(),
                a.rect(-5, 12.5, o.width + 10, o.height - 10),
                a.fillColor = t,
                a.fill()
            }
            ,
            t.WINSIZEW = 640,
            t.WINSIZEH = 1136,
            t.isDebug = !1,
            t.NumGold = 0,
            t.NumScore = 0,
            t.NumHeroPrice = [0, 1e3, 3e3, 5e3, 1e4, 2e4],
            t.NowHeroTT = 0,
            t.NowHeroLockState = [1, 0, 0, 0, 0, 0],
            t.NumGateTT = 1,
            t.NumGoldTT = 0,
            t.NumScoreTT = 0,
            t.AudioState = !0,
            t.VibrateState = !0,
            t.NumStarTT = 0,
            t.maxSpeedLV = 0,
            t.sprintSpeedLV = 0,
            t.NumTimeAD = 0,
            t.countNumTime = 0,
            t.VideoEntrance = "",
            t.G = -320,
            n = r([l], t)
        }(cc.Component));
        n.default = u,
        cc._RF.pop()
    }
    , {
        "../FBGameConfig": "FBGameConfig",
        "../Module/App": "App"
    }],
    HeroContact: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "62d03jEWnFPv5s2B1sy9h9d", "HeroContact");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = e("../Scene/GameScene")
          , s = cc._decorator
          , c = s.ccclass
          , l = (s.property,
        function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t.prototype.initGame = function(e) {
                this.GS = e
            }
            ,
            t.prototype.onBeginContact = function(e, t, n) {
                if (this.GS && this.GS.GameState != i.doGameState.FAIL && -1 != n.node.name.indexOf("node_road")) {
                    if ("test" == t.node.name)
                        return void this.GS.bodyCollide();
                    "node_front" == t.node.name ? this.GS.wheelTestFloor(1) : "node_after" == t.node.name && this.GS.wheelTestFloor(2),
                    -1 == this.GS.recordZoomY && (this.GS.recordZoomY = this.GS.saveHeroBody.node.convertToWorldSpaceAR(cc.Vec2.ZERO).y)
                }
            }
            ,
            t.prototype.onEndContact = function(e, t, n) {
                this.GS && this.GS.GameState != i.doGameState.FAIL && -1 != n.node.name.indexOf("node_road") && ("node_front" == t.node.name ? (this.GS.frontTestState = !1,
                this.GS.isStartTimer || (this.GS.isStartTimer = !0),
                this.GS.saveHeroNode.getChildByName("node_particle") && (this.GS.saveHeroNode.getChildByName("node_particle").getChildByName("Ffloor").active = !1)) : "node_after" == t.node.name && (this.GS.afterTestState = !1,
                this.GS.isStartTimer || (this.GS.isStartTimer = !0),
                this.GS.saveHeroNode.getChildByName("node_particle") && (this.GS.saveHeroNode.getChildByName("node_particle").getChildByName("Afloor").active = !1),
                this.GS.saveHeroNode.getChildByName("node_particle") && (this.GS.saveHeroNode.getChildByName("node_particle").getChildByName("shadow").active = !1)))
            }
            ,
            t.prototype.onPreSolve = function() {}
            ,
            t.prototype.onPostSolve = function() {}
            ,
            r([c], t)
        }(cc.Component));
        n.default = l,
        cc._RF.pop()
    }
    , {
        "../Scene/GameScene": "GameScene"
    }],
    HttpService: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "36c2cXOhqRDDq37arnjFmxn", "HttpService");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
        , i = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var s = e("../core/Http")
          , c = e("./PlatformFB")
          , l = e("../../FBGameConfig")
          , u = function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.game_id = l.default.BOT_ID,
                t.host = l.default.PL_HOST,
                t.host2 = l.default.BOT_HOST,
                t._server = new s.Http,
                t
            }
            return a(t, e),
            Object.defineProperty(t.prototype, "server", {
                get: function() {
                    return this._server
                },
                enumerable: !1,
                configurable: !0
            }),
            t.prototype.reportFriends = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return platform instanceof c.PlatformFB && platform.GetFrinedsInfo().length > 0 ? (e = {
                                action: "friends",
                                playerId: platform.getPlayerId(),
                                payload: platform.GetFrinedsInfo().map(function(e) {
                                    return e.getID()
                                })
                            },
                            [4, this._server.post(this.host2 + "/api/v0/upload_" + this.game_id, {
                                data: JSON.stringify(e)
                            })]) : [3, 2];
                        case 1:
                            t.sent(),
                            t.label = 2;
                        case 2:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.reportIfFromSkinShare = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return platform.invite_skin_data && platform.NewPlayer ? (e = this.host + "/api/game/v0/shareUpdate_" + this.game_id,
                            [4, this._server.post(e, {
                                v: $T_GAME_VERSION,
                                playerId: platform.getPlayerId(),
                                sharePlayerId: platform.invite_skin_data.playerId,
                                type: "share"
                            }).catch(function(e) {
                                return console.log(e)
                            })]) : [3, 2];
                        case 1:
                            t.sent(),
                            t.label = 2;
                        case 2:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.getSkinShareCount = function() {
                return r(this, void 0, void 0, function() {
                    var e, t, n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            e = this.host + "/api/game/v0/shareGet_" + this.game_id,
                            [4, this._server.post(e, {
                                v: $T_GAME_VERSION,
                                playerId: platform.getPlayerId(),
                                type: "share"
                            })];
                        case 2:
                            return t = o.sent(),
                            JSON.parse(t).data.count,
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log(n),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t
        }(e("../Extension/Singleton").default);
        n.default = u,
        cc._RF.pop()
    }
    , {
        "../../FBGameConfig": "FBGameConfig",
        "../Extension/Singleton": "Singleton",
        "../core/Http": "Http",
        "./PlatformFB": "PlatformFB"
    }],
    Http: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "2b06fDNCs5AtpH9KrEycqJT", "Http"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.Http = void 0;
        var o = function() {
            function e() {}
            return e.prototype.encodeValue = function(e, t) {
                return t instanceof Array ? this.encodeArray(e, t) : encodeURIComponent(e) + "=" + encodeURIComponent(t)
            }
            ,
            e.prototype.encodeArray = function(e, t) {
                return e ? 0 == t.length ? encodeURIComponent(e) + "=" : t.map(function(t) {
                    return encodeURIComponent(e) + "=" + encodeURIComponent(t)
                }).join("&") : ""
            }
            ,
            e.prototype.toString = function(e) {
                if (!e)
                    return "";
                var t = [];
                for (var n in e)
                    t.push(this.encodeValue(n, e[n]));
                return t.join("&")
            }
            ,
            e.prototype.request = function(e) {
                var t = new XMLHttpRequest;
                t.responseType = "arraybuffer" !== e.responseType ? "text" : "arraybuffer",
                t.timeout = e.timeout || 0,
                t.onerror = function(n) {
                    console.log("[http][" + e.method + "][error] [" + t.status + ":" + t.statusText + "] " + e.url),
                    e.onerror && e.onerror(n)
                }
                ,
                t.onabort = function() {
                    console.log("[http][" + e.method + "][abort] " + e.url),
                    e.onabort && e.onabort()
                }
                ,
                t.onprogress = function(t) {
                    t && t.lengthComputable && e.onprogress && e.onprogress(t.loaded / t.total)
                }
                ,
                t.onload = function(n) {
                    var o = void 0 !== t.status ? t.status : 200;
                    if (200 === o || 204 === o || 0 === o) {
                        var a = t.response || t.responseText;
                        console.log("[http][" + e.method + "][loaded] " + e.url + ":" + a),
                        e.onload(a)
                    } else
                        console.log("[http][" + e.method + "][error] [" + t.status + ":" + t.statusText + "] " + e.url),
                        e.onerror && e.onerror(n)
                }
                ;
                var n = this.toString(e.data)
                  , o = e.url;
                if ("GET" == e.method && n && (o = e.url + "?" + n,
                n = null),
                t.open(e.method, o, !0),
                "POST" == e.method && (e.rawData ? (t.setRequestHeader("Content-Type", "application/json"),
                n = JSON.stringify(e.rawData)) : t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")),
                e.headers)
                    for (var a = 0; a < e.headers.length; a++)
                        t.setRequestHeader(e.headers[a++], e.headers[a]);
                return t.send(n),
                console.log("[http][" + e.method + "] " + e.url + ":" + JSON.stringify(e.data)),
                t
            }
            ,
            e.prototype.post = function(e, t) {
                var n = this;
                return new Promise(function(o, a) {
                    n.request({
                        url: e,
                        data: t,
                        method: "POST",
                        onload: o,
                        onerror: a,
                        ontimeout: a
                    })
                }
                )
            }
            ,
            e.prototype.get = function(e, t) {
                var n = this;
                return new Promise(function(o, a) {
                    n.request({
                        url: e,
                        data: t,
                        method: "GET",
                        onload: o,
                        onerror: a,
                        ontimeout: a
                    })
                }
                )
            }
            ,
            e
        }();
        n.Http = o,
        cc._RF.pop()
    }
    , {}],
    LoadingView: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "46e62M/dBdN04WJGMjXpc5N", "LoadingView");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = e("../Module/Extension/BaseUI")
          , s = cc._decorator
          , c = s.ccclass
          , l = s.property
          , u = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.bgNode = null,
                t.centerLoading = null,
                t.progressBar = null,
                t.progress = 0,
                t.showBg = !1,
                t.maskPercent = .6,
                t.showProgress = !1,
                t
            }
            return a(t, e),
            t.prototype.initialize = function(e) {
                e = e || {
                    showBg: !1,
                    maskPercent: .6,
                    showProgress: !1
                },
                this.showBg = e.showBg || !1,
                this.maskPercent = e.maskPercent || .6,
                this.showProgress = e.showProgress || !1
            }
            ,
            t.prototype.setProgress = function(e) {
                this.progressBar.progress = e
            }
            ,
            t.prototype.start = function() {
                cc.tween(this.centerLoading).by(2, {
                    angle: -360
                }).repeatForever().start()
            }
            ,
            t.prototype.update = function() {}
            ,
            t.prototype.onEnter = function(t) {
                e.prototype.onEnter.call(this, t)
            }
            ,
            r([l(cc.Node)], t.prototype, "bgNode", void 0),
            r([l(cc.Node)], t.prototype, "centerLoading", void 0),
            r([l(cc.ProgressBar)], t.prototype, "progressBar", void 0),
            r([c], t)
        }(i.default);
        n.default = u,
        cc._RF.pop()
    }
    , {
        "../Module/Extension/BaseUI": "BaseUI"
    }],
    Manager: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "078b1W/GetEw5oiKWEoDIer", "Manager"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.HttpService = n.GameConnect = n.SceneManager = n.ResManager = void 0;
        var o = e("./ResManager");
        Object.defineProperty(n, "ResManager", {
            enumerable: !0,
            get: function() {
                return o.default
            }
        });
        var a = e("./SceneManager");
        Object.defineProperty(n, "SceneManager", {
            enumerable: !0,
            get: function() {
                return a.default
            }
        });
        var r = e("../../GameConnect");
        Object.defineProperty(n, "GameConnect", {
            enumerable: !0,
            get: function() {
                return r.default
            }
        });
        var i = e("../../Module/platform/HttpService");
        Object.defineProperty(n, "HttpService", {
            enumerable: !0,
            get: function() {
                return i.default
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../GameConnect": "GameConnect",
        "../../Module/platform/HttpService": "HttpService",
        "./ResManager": "ResManager",
        "./SceneManager": "SceneManager"
    }],
    NPCCtrl: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "b1aa8REbQFNGqRK0iOzXfaW", "NPCCtrl");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = e("../Module/App")
          , s = e("../Scene/GameScene")
          , c = e("../Utils/GameUtils")
          , l = e("./Flash")
          , u = e("./HeroContact")
          , p = e("./NpcContact")
          , d = cc._decorator
          , f = d.ccclass
          , h = (d.property,
        function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.GS = null,
                t.saveNPCNode = [],
                t.saveNPCBody = [],
                t.saveNPCAfterBody = [],
                t.saveNPCFrontBody = [],
                t.npcFixStartSite = [],
                t.npcReviveSite = [],
                t.doMoveSpeedArray = [],
                t.maxFilpSpeed = -400,
                t.nowFilpSpeed = [],
                t.addSpeed = [],
                t.maxSpeed = [],
                t.nowSpeed = [],
                t.sprintSpeed = [],
                t.isStartTimer = [],
                t.doFilpTimer = [],
                t.countFlipNum = [],
                t.saveFilpNum = [],
                t.angleRemainder = [],
                t.angleCircle = [],
                t.turnUpState = [],
                t.turnUpNumber = [],
                t.npcFlipState = [],
                t.npcFrontTestState = [],
                t.npcAfterTestState = [],
                t.npcDragonBonesName = [],
                t.npcAnimation = [],
                t
            }
            return a(t, e),
            t.prototype.update = function(e) {
                this.npcToMove(e),
                this.contactTimer(e)
            }
            ,
            t.prototype.lateUpdate = function() {}
            ,
            t.prototype.initGame = function(e) {
                this.GS = e,
                this.initflag()
            }
            ,
            t.prototype.initflag = function(e) {
                var t = this;
                void 0 === e && (e = cc.v2(-180, -265)),
                this.doMoveSpeedArray = [];
                for (var n = 0; n < this.GS.NPCGROUP.length; n++)
                    this.doMoveSpeedArray[n] = {
                        doAddSpeed: 0,
                        doMaxSpeed: 0,
                        doSprintSpeed: 0
                    };
                if (1 == c.default.NumGateTT) {
                    var o = [300, 200, 500, 150]
                      , a = [2700, 2800, 2900, 3e3]
                      , r = [600, 500, 600, 400];
                    for (n = 0; n < this.GS.NPCGROUP.length; n++)
                        this.doMoveSpeedArray[n] = {
                            doAddSpeed: o[n],
                            doMaxSpeed: a[n],
                            doSprintSpeed: r[n]
                        }
                } else {
                    for (n = 0; n < this.GS.NPCGROUP.length; n++)
                        0 == n ? (o = Math.randInt(200, 300),
                        a = Math.randInt(2500, 2700),
                        r = Math.randInt(500, 800),
                        this.doMoveSpeedArray[n] = {
                            doAddSpeed: o,
                            doMaxSpeed: a,
                            doSprintSpeed: r
                        }) : 1 == n ? (o = Math.randInt(300, 400),
                        a = Math.randInt(2700, 2900),
                        r = Math.randInt(600, 800),
                        this.doMoveSpeedArray[n] = {
                            doAddSpeed: o,
                            doMaxSpeed: a,
                            doSprintSpeed: r
                        }) : 2 == n ? (o = Math.randInt(200, 300),
                        a = Math.randInt(2900, 3100),
                        r = Math.randInt(400, 600),
                        this.doMoveSpeedArray[n] = {
                            doAddSpeed: o,
                            doMaxSpeed: a,
                            doSprintSpeed: r
                        }) : c.default.NumGateTT > 5 ? (o = 200,
                        a = this.GS.maxSpeed - Math.randInt(60, 150),
                        r = Math.randInt(300, 500),
                        this.doMoveSpeedArray[n] = {
                            doAddSpeed: o,
                            doMaxSpeed: a,
                            doSprintSpeed: r
                        }) : (o = Math.randInt(200, 300),
                        a = Math.randInt(3e3, 3100),
                        r = Math.randInt(400, 550),
                        this.doMoveSpeedArray[n] = {
                            doAddSpeed: o,
                            doMaxSpeed: a,
                            doSprintSpeed: r
                        });
                    var s = c.default.NumGateTT >= 30 ? 30 : c.default.NumGateTT
                      , l = Math.floor(s / 5);
                    if (c.default.NumGateTT > 5)
                        for (n = 0; n < this.doMoveSpeedArray.length; n++)
                            this.doMoveSpeedArray[n].doMaxSpeed += 20 * l,
                            this.doMoveSpeedArray[n].doSprintSpeed += 20 * l,
                            this.doMoveSpeedArray[n].doMaxSpeed >= this.GS.maxSpeed && (this.doMoveSpeedArray[n].doMaxSpeed = this.GS.maxSpeed - Math.randInt(50, 100))
                }
                this.GS.shuffle(this.doMoveSpeedArray),
                cc.loader.loadRes("Other/Userinfo/userinfo", function(n, o) {
                    if (!n) {
                        var a = o.json;
                        cc.loader.loadRes("Other/Userinfo/flag", function(n, o) {
                            if (!n) {
                                var r = [];
                                i.default.resManager.loadSpriteFrame("Other/Userinfo/flagicon").then(function(n) {
                                    var i = n.getTexture();
                                    for (var s in o.json.frames) {
                                        var c = o.json.frames[s].x
                                          , l = o.json.frames[s].y
                                          , u = o.json.frames[s].w
                                          , p = o.json.frames[s].h;
                                        r.push(new cc.SpriteFrame(i,cc.rect(c, l, u, p)))
                                    }
                                    for (var d = 0; d < t.GS.NPCGROUP.length; d++) {
                                        var f = Math.randInt(1, 6);
                                        t.npcFixStartSite[d] = e.clone(),
                                        t.npcFixStartSite[d].y += 80 * (d + 1),
                                        t.createNPC(f, t.npcFixStartSite[d], d, a[Math.randInt(0, a.length - 1)].nickName, r[Math.randInt(0, r.length - 1)])
                                    }
                                })
                            }
                        })
                    }
                })
            }
            ,
            t.prototype.createNPC = function(e, t, n, o, a, r) {
                var c = this;
                void 0 === r && (r = !1),
                i.default.resManager.loadPrefab("Main/role/role" + e).then(function(i) {
                    if (i) {
                        c.saveNPCNode[n] = cc.instantiate(i),
                        c.saveNPCBody[n] = c.saveNPCNode[n].getChildByName("node_body").getComponent(cc.RigidBody),
                        c.saveNPCAfterBody[n] = c.saveNPCNode[n].getChildByName("node_after").getComponent(cc.RigidBody),
                        c.saveNPCFrontBody[n] = c.saveNPCNode[n].getChildByName("node_front").getComponent(cc.RigidBody),
                        c.saveNPCNode[n].parent = c.GS.GameLayer,
                        c.saveNPCNode[n].x = t.x,
                        c.saveNPCNode[n].y = t.y,
                        c.saveNPCNode[n].zIndex = 4 - n,
                        c.saveNPCNode[n].group = c.GS.NPCGROUP[n],
                        c.saveNPCNode[n].active = !1,
                        c.saveNPCNode[n].active = !0,
                        c.saveNPCNode[n].index = n,
                        c.saveNPCNode[n].npctype = e,
                        c.saveNPCNode[n].isEnd = !1,
                        c.saveNPCNode[n].isDie = !1,
                        c.saveNPCNode[n].startX = t.x,
                        c.changeGroup(c.saveNPCNode[n]);
                        for (var d = ["node_after", "node_front", "node_body"], f = 0; f < d.length; f++)
                            "node_body" == d[f] ? (c.saveNPCNode[n].getChildByName(d[f]).getChildByName("test").getComponent(u.default).destroy(),
                            c.saveNPCNode[n].getChildByName(d[f]).getChildByName("test").addComponent(p.default),
                            c.saveNPCNode[n].getChildByName(d[f]).getChildByName("test").getComponent(p.default).initGame(c),
                            c.saveNPCNode[n].getChildByName(d[f]).getComponent(cc.RigidBody).syncPosition(!0)) : (c.saveNPCNode[n].getChildByName(d[f]).getComponent(u.default).destroy(),
                            c.saveNPCNode[n].getChildByName(d[f]).addComponent(p.default),
                            c.saveNPCNode[n].getChildByName(d[f]).getComponent(p.default).initGame(c),
                            c.saveNPCNode[n].getChildByName(d[f]).getComponent(cc.RigidBody).syncPosition(!0));
                        r ? (c.saveNPCBody[n].node.getChildByName("hero").getComponent(l.default).startToFlash(.2),
                        c.saveNPCAfterBody[n].node.getComponent(l.default).startToFlash(.2),
                        c.saveNPCFrontBody[n].node.getComponent(l.default).startToFlash(.2),
                        c.saveNPCNode[n].boxKeepSite = !0) : (c.saveNPCNode[n].getChildByName("node_box").position = c.saveNPCBody[n].node.position,
                        c.saveNPCNode[n].getChildByName("node_box").opacity = 0,
                        c.saveNPCNode[n].boxKeepSite = !1),
                        c.saveNPCNode[n].getChildByName("node_box").getChildByName("icon").active = !1,
                        c.saveNPCNode[n].getChildByName("node_box").getChildByName("name").getComponent(cc.Label).string = o,
                        c.saveNPCNode[n].getChildByName("node_box").getChildByName("flag").getChildByName("circle").getComponent(cc.Sprite).spriteFrame = a,
                        c.npcFrontTestState[n] = !1,
                        c.npcAfterTestState[n] = !1,
                        c.npcFlipState[n] = !1,
                        c.isStartTimer[n] = !1,
                        c.doFilpTimer[n] = 0,
                        c.countFlipNum[n] = 0,
                        c.saveFilpNum[n] = -1,
                        c.angleRemainder[n] = -1,
                        c.angleCircle[n] = -1,
                        c.turnUpState[n] = !1,
                        c.npcReviveSite[n] && null != c.npcReviveSite[n] || (c.npcReviveSite[n] = new cc.Vec2(0,0)),
                        c.npcAnimation[n] = c.saveNPCBody[n].node.getChildByName("hero").getComponent(dragonBones.ArmatureDisplay),
                        c.playDragonBones(n, s.doAnimationName.WAIT, -1),
                        c.npcAnimation[n].addEventListener(dragonBones.EventObject.COMPLETE, c._animationEventHandler, c),
                        c.sureSportParam(n),
                        c.saveNPCNode[n].getChildByName("node_particle").getChildByName("shimmer").active = !1
                    }
                })
            }
            ,
            t.prototype.changeGroup = function(e) {
                for (var t = 0; t < e.children.length; t++)
                    e.children[t].group = e.group,
                    e.children[t].active = !1,
                    e.children[t].active = !0,
                    -1 != e.children[t].name.indexOf("shadow") && (e.children[t].active = !1),
                    e.children[t].children.length > 0 && this.changeGroup(e.children[t])
            }
            ,
            t.prototype.sureSportParam = function(e) {
                this.nowFilpSpeed[e] = 0,
                this.nowSpeed[e] = Math.randInt(-1e3, 0),
                this.addSpeed[e] = this.doMoveSpeedArray[e].doAddSpeed,
                this.maxSpeed[e] = this.doMoveSpeedArray[e].doMaxSpeed,
                this.sprintSpeed[e] = this.doMoveSpeedArray[e].doSprintSpeed
            }
            ,
            t.prototype.npcToMove = function() {
                for (var e = 0; e < this.saveNPCNode.length; e++)
                    this.saveNPCNode[e].isDie || this.saveNPCNode[e] && this.saveNPCBody[e] && (this.saveNPCBody[e].linearVelocity.x <= 30 || !this.npcAfterTestState[e] && !this.npcFrontTestState[e] ? (this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Ffloor").active && (this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Ffloor").active = !1),
                    this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Afloor").active && (this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Afloor").active = !1)) : (this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Ffloor").active || (this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Ffloor").active = !0),
                    this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Afloor").active || (this.saveNPCNode[e].getChildByName("node_particle").getChildByName("Afloor").active = !0)));
                if (this.GS.GameState == s.doGameState.GAME || this.GS.GameState == s.doGameState.SUCCESS)
                    for (e = 0; e < this.saveNPCNode.length; e++)
                        this.saveNPCNode[e].isDie || (this.npcFlipState[e] || (this.saveNPCBody[e].angularDamping = 0,
                        this.saveNPCAfterBody[e].angularDamping = 0,
                        this.saveNPCFrontBody[e].angularDamping = 0,
                        this.saveNPCBody[e].angularVelocity = 0,
                        this.nowSpeed[e] += this.addSpeed[e],
                        this.nowSpeed[e] >= this.maxSpeed[e] && (this.nowSpeed[e] = this.maxSpeed[e]),
                        this.saveNPCAfterBody[e].angularVelocity = this.nowSpeed[e],
                        this.saveNPCFrontBody[e].angularVelocity = this.nowSpeed[e]),
                        this.turnUpState[e] && (this.saveNPCBody[e].node.angle += this.turnUpNumber[e],
                        this.turnUpNumber[e] < 0 ? this.saveNPCBody[e].node.angle <= 360 * this.angleCircle[e] && (this.saveNPCBody[e].node.angle = 360 * this.angleCircle[e]) : this.turnUpNumber[e] > 0 && this.saveNPCBody[e].node.angle >= 360 * this.angleCircle[e] && (this.saveNPCBody[e].node.angle = 360 * this.angleCircle[e])),
                        this.npcGress(e),
                        this.saveNPCNode[e].convertToWorldSpaceAR(this.saveNPCBody[e].node.position).y <= -800 && !this.saveNPCNode[e].isDie && this.bodyCollide(this.saveNPCBody[e].node.getChildByName("test")))
            }
            ,
            t.prototype.wheelTestFloor = function(e, t) {
                var n = t.parent.index;
                this.isStartTimer[n] = !1,
                this.npcFlipState[n] = !1,
                this.doFilpTimer[n] = 0,
                this.turnUpState[n] = !1,
                1 == e ? this.npcFrontTestState[n] = !0 : this.npcAfterTestState[n] = !0,
                this.GS.GameState != s.doGameState.GAME && this.GS.GameState != s.doGameState.SUCCESS || this.npcDragonBonesName[n] != s.doAnimationName.RUSH && this.playDragonBones(n, s.doAnimationName.RUSH, 1),
                this.npcFrontTestState[n] && this.npcAfterTestState[n] && this.saveNPCNode[n].getChildByName("node_particle") && (this.saveNPCNode[n].getChildByName("node_particle").getChildByName("shadow").active = !0),
                this.extraUpSpeed(n)
            }
            ,
            t.prototype.contactTimer = function() {
                for (var e = this, t = function(t) {
                    if (n.saveNPCNode[t].isDie)
                        return "continue";
                    if (!n.isStartTimer[t])
                        return "continue";
                    if (n.doFilpTimer[t] += 1,
                    n.doFilpTimer[t] >= 30 && (n.doFilpTimer[t] = 0,
                    !n.npcFrontTestState[t] && !n.npcAfterTestState[t] && !n.npcFlipState[t])) {
                        n.npcFlipState[t] = !0,
                        cc.tween(n.saveNPCBody[t].node).to(1, {
                            angle: 360
                        }).call(function() {
                            e.saveNPCBody[t].node.angle = 0,
                            e.countFlipNum[t] = 1,
                            e.turnUpState[t] || (e.turnUpState[t] = !0,
                            e.angleRemainder[t] = e.saveNPCBody[t].node.angle % 360,
                            e.angleCircle[t] = Math.floor(e.saveNPCBody[t].node.angle / 360),
                            e.angleCircle[t] <= 0 && (e.angleCircle[t] = 0),
                            e.angleRemainder[t] >= 240 ? (e.angleCircle[t] += 1,
                            e.turnUpNumber[t] = 1) : e.angleRemainder[t] <= 120 ? e.turnUpNumber[t] = -1 : e.turnUpNumber[t] = 0)
                        }).start(),
                        n.saveNPCBody[t].angularVelocity = 0,
                        n.saveNPCBody[t].angularDamping = 2e4,
                        n.playDragonBones(t, s.doAnimationName.FEIQI1, 1);
                        var o = n.saveNPCNode[t].getChildByName("node_particle").getChildByName("shimmer");
                        o.opacity = 0,
                        o.active = !0,
                        cc.tween(o).to(.15, {
                            opacity: 255,
                            scale: .6
                        }).to(.3, {}).to(.15, {
                            opacity: 0,
                            scale: .5
                        }).call(function() {
                            o.active = !1
                        }).start()
                    }
                }, n = this, o = 0; o < this.saveNPCNode.length; o++)
                    t(o)
            }
            ,
            t.prototype.npcGress = function(e) {
                if (!this.saveNPCNode[e].isDie) {
                    var t = this.GS.GameLayerUI.getChildByName("gress");
                    t.getChildByName("roboticon" + (e + 1)).active || (t.getChildByName("roboticon" + (e + 1)).active = !0,
                    this.npcDragonBonesName[e] != s.doAnimationName.RUSH && this.playDragonBones(e, s.doAnimationName.RUSH, 1));
                    var n = this.GS.saveTrackEnd.x - 360;
                    if (this.saveNPCBody[e].node.x + this.saveNPCNode[e].startX < n)
                        t.getChildByName("roboticon" + (e + 1)).x = (this.saveNPCBody[e].node.x + this.saveNPCNode[e].startX) / n * 240 - 127,
                        t.getChildByName("roboticon" + (e + 1)).x >= 115 && (t.getChildByName("roboticon" + (e + 1)).x = 115);
                    else {
                        if (t.getChildByName("roboticon" + (e + 1)).x = (this.saveNPCBody[e].node.x + this.saveNPCNode[e].startX) / n * 240 - 127,
                        t.getChildByName("roboticon" + (e + 1)).x >= 115 && (t.getChildByName("roboticon" + (e + 1)).x = 115),
                        this.saveNPCBody[e].fixedRotation = !0,
                        !this.saveNPCNode[e].isEnd) {
                            this.saveNPCNode[e].isEnd = !0,
                            this.GS.raceRanking += 1,
                            this.npcDragonBonesName[e] != s.doAnimationName.SHACHE1 && this.playDragonBones(e, s.doAnimationName.SHACHE1, 1);
                            var o = this.GS.raceRanking;
                            o <= 3 && (this.GS.resultNode && this.GS.resultNode.getChildByName("node_bg").getChildByName("item" + o) ? (this.GS.resultNode.getChildByName("node_bg").getChildByName("item" + o).getChildByName("headmask").getChildByName("img").getComponent(cc.Sprite).spriteFrame = this.saveNPCNode[e].getChildByName("node_box").getChildByName("flag").getChildByName("circle").getComponent(cc.Sprite).spriteFrame,
                            this.GS.resultNode.getChildByName("node_bg").getChildByName("item" + o).getChildByName("headmask").getChildByName("img").width = 46,
                            this.GS.resultNode.getChildByName("node_bg").getChildByName("item" + o).getChildByName("headmask").getChildByName("img").height = 46,
                            this.GS.resultNode.getChildByName("node_bg").getChildByName("item" + o).getChildByName("text").getComponent(cc.Label).string = this.saveNPCNode[e].getChildByName("node_box").getChildByName("name").getComponent(cc.Label).string,
                            cc.tween(this.GS.resultNode.getChildByName("node_bg").getChildByName("item" + o)).to(.5, {}).to(.8, {
                                x: 0
                            }, {
                                easing: "elasticOut"
                            }).start()) : this.GS.npcRanking.push({
                                npc: this.saveNPCNode[e],
                                ranking: o
                            }))
                        }
                        this.saveNPCNode[e].isEnd && (this.saveNPCAfterBody[e].angularVelocity = 0,
                        this.saveNPCFrontBody[e].angularVelocity = 0,
                        this.saveNPCAfterBody[e].linearDamping = 3,
                        this.saveNPCFrontBody[e].linearDamping = 3,
                        this.saveNPCAfterBody[e].angularDamping = 5e3,
                        this.saveNPCFrontBody[e].angularDamping = 5e3)
                    }
                }
            }
            ,
            t.prototype.extraUpSpeed = function(e) {
                if (this.saveNPCNode[e] && null != this.saveNPCNode[e] && this.npcAfterTestState[e] && this.npcFrontTestState[e] && !(this.countFlipNum[e] <= 0) && this.saveNPCAfterBody[e] && this.saveNPCFrontBody[e] && this.saveNPCBody[e]) {
                    this.countFlipNum[e] = 0,
                    this.saveNPCAfterBody[e].linearVelocity = this.saveNPCAfterBody[e].linearVelocity.clone().addSelf(cc.v2(this.sprintSpeed[e], 0)),
                    this.saveNPCFrontBody[e].linearVelocity = this.saveNPCFrontBody[e].linearVelocity.clone().addSelf(cc.v2(this.sprintSpeed[e], 0)),
                    this.saveNPCBody[e].linearVelocity = this.saveNPCBody[e].linearVelocity.clone().addSelf(cc.v2(this.sprintSpeed[e], 0));
                    for (var t = [], n = 0; n < this.saveNPCBody[e].node.children.length; n++) {
                        var o = this.saveNPCBody[e].node.children[n];
                        -1 != o.name.indexOf("shadow") && t.push(o)
                    }
                    var a = function(e) {
                        t[e].opacity = 40 + 30 * e,
                        t[e].active = !0,
                        cc.tween(t[e]).to(.05 * (7 - e) + .15, {
                            x: .956
                        }).call(function() {
                            t[e].active = !1,
                            t[e].x = -50 * (8 - e)
                        }).start()
                    };
                    for (n = 0; n < t.length; n++)
                        a(n)
                }
            }
            ,
            t.prototype.keepSite = function() {
                if (this.saveNPCNode && null != this.saveNPCNode)
                    for (var e = 0; e < this.saveNPCNode.length; e++)
                        this.saveNPCNode[e].isDie || (this.saveNPCNode[e].boxKeepSite && (this.saveNPCNode[e].getChildByName("node_box").position = this.saveNPCBody[e].node.position),
                        this.saveNPCNode[e].getChildByName("node_particle").position = this.saveNPCBody[e].node.position,
                        this.saveNPCNode[e].getChildByName("node_particle").angle = this.saveNPCBody[e].node.angle,
                        this.saveNPCBody[e].node.getChildByName("test").position = cc.v2(10, 60))
            }
            ,
            t.prototype.bodyCollide = function(e) {
                var t = this
                  , n = e.parent.parent
                  , o = n.index
                  , a = this.GS.MainCamera.node.x - (this.saveNPCBody[o].node.x + this.saveNPCNode[o].startX);
                if (this.GS.GameState == s.doGameState.SUCCESS || a >= 2e3)
                    this.scheduleOnce(function() {
                        t.saveNPCBody[o].node.angle = 0
                    });
                else {
                    n.getChildByName("node_particle").active = !1;
                    var r = this.GS.GameLayer.convertToNodeSpaceAR(this.saveNPCNode[o].convertToWorldSpaceAR(this.saveNPCBody[o].node.position));
                    i.default.resManager.loadPrefab("Other/Particle/boom").then(function(e) {
                        if (e) {
                            var n = cc.instantiate(e);
                            n.parent = t.GS.GameLayer,
                            n.zIndex = 3,
                            n.position = r
                        }
                    });
                    var c = this.saveNPCNode[o].npctype
                      , l = cc.v2()
                      , u = o
                      , p = this.saveNPCNode[o].getChildByName("node_box").getChildByName("name").getComponent(cc.Label).string
                      , d = this.saveNPCNode[o].getChildByName("node_box").getChildByName("flag").getChildByName("circle").getComponent(cc.Sprite).spriteFrame;
                    this.GS.initRevivePoint.sort(function(e, t) {
                        return e.x - t.x
                    });
                    for (var f = 0, h = 0; h < this.GS.initRevivePoint.length; h++)
                        r.x >= this.GS.initRevivePoint[h].x && (f += 1);
                    0 == f || 0 == this.GS.initRevivePoint.length ? l = cc.v2(this.GS.saveTrackStart.x, 80 * (o + 1) - 265) : f > 0 && (l = cc.v2(this.GS.initRevivePoint[f - 1].x, 80 * (o + 1) - 265)),
                    this.saveNPCNode[o].startX = l.x,
                    this.saveNPCBody[o].node.destroy(),
                    this.saveNPCNode[o].getChildByName("node_particle").destroy(),
                    this.saveNPCNode[o].getChildByName("node_box").destroy(),
                    this.saveNPCNode[o].isDie = !0,
                    setTimeout(function() {
                        t.saveNPCNode[u].isDie && (t.saveNPCAfterBody[u] && null != t.saveNPCAfterBody[u].node && t.saveNPCAfterBody[u].node.destroy(),
                        t.saveNPCFrontBody[u] && null != t.saveNPCFrontBody[u].node && t.saveNPCFrontBody[u].node.destroy(),
                        t.createNPC(c, l, u, p, d, !0))
                    }, 1e3)
                }
            }
            ,
            t.prototype.playDragonBones = function(e, t, n) {
                this.npcDragonBonesName[e] = t,
                this.npcAnimation[e] && this.npcAnimation[e].playAnimation(t, n)
            }
            ,
            t.prototype._animationEventHandler = function(e) {
                if (e.type === dragonBones.EventObject.COMPLETE)
                    for (var t = 0; t < this.npcAnimation.length; t++)
                        this.saveNPCNode[t].isDie || this.npcAnimation[t] && (e.animationState.name == s.doAnimationName.FEIQI1 && this.npcDragonBonesName[t] == s.doAnimationName.FEIQI1 ? this.playDragonBones(t, s.doAnimationName.FEIQI2, 1) : e.animationState.name == s.doAnimationName.FEIQI2 && this.npcDragonBonesName[t] == s.doAnimationName.FEIQI2 ? this.playDragonBones(t, s.doAnimationName.FEIQI3, 1) : e.animationState.name == s.doAnimationName.SHACHE1 && this.npcDragonBonesName[t] == s.doAnimationName.SHACHE1 ? this.playDragonBones(t, s.doAnimationName.SHACHE2, 1) : e.animationState.name == s.doAnimationName.SHACHE2 && this.npcDragonBonesName[t] == s.doAnimationName.SHACHE2 ? this.playDragonBones(t, s.doAnimationName.SHACHE3, 1) : e.animationState.name == s.doAnimationName.SHACHE3 && this.npcDragonBonesName[t] == s.doAnimationName.SHACHE3 && this.playDragonBones(t, s.doAnimationName.WAIT, -1))
            }
            ,
            t.prototype.releaseNPC = function() {
                for (var e = 0; e < this.saveNPCNode.length; e++)
                    this.saveNPCNode[e] && this.saveNPCNode[e].destroy();
                this.saveNPCNode = [],
                this.saveNPCBody = [],
                this.saveNPCAfterBody = [],
                this.saveNPCFrontBody = [],
                this.npcFixStartSite = [],
                this.npcReviveSite = [],
                this.doMoveSpeedArray = [],
                this.nowFilpSpeed = [],
                this.addSpeed = [],
                this.maxSpeed = [],
                this.nowSpeed = [],
                this.sprintSpeed = [],
                this.isStartTimer = [],
                this.doFilpTimer = [],
                this.countFlipNum = [],
                this.saveFilpNum = [],
                this.angleRemainder = [],
                this.angleCircle = [],
                this.turnUpState = [],
                this.npcFlipState = [],
                this.npcFrontTestState = [],
                this.npcAfterTestState = [],
                this.npcDragonBonesName = [],
                this.npcAnimation = []
            }
            ,
            r([f], t)
        }(cc.Component));
        n.default = h,
        cc._RF.pop()
    }
    , {
        "../Module/App": "App",
        "../Scene/GameScene": "GameScene",
        "../Utils/GameUtils": "GameUtils",
        "./Flash": "Flash",
        "./HeroContact": "HeroContact",
        "./NpcContact": "NpcContact"
    }],
    NpcContact: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "8ab2fsYZtZI+aZ3JR061vQY", "NpcContact");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = cc._decorator
          , s = i.ccclass
          , c = (i.property,
        function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t.prototype.initGame = function(e) {
                this.NPCCtrl = e
            }
            ,
            t.prototype.onBeginContact = function(e, t, n) {
                if (this.NPCCtrl && -1 != n.node.name.indexOf("node_road")) {
                    if ("test" == t.node.name)
                        return void this.NPCCtrl.bodyCollide(t.node);
                    "node_front" == t.node.name ? this.NPCCtrl.wheelTestFloor(1, t.node) : "node_after" == t.node.name && this.NPCCtrl.wheelTestFloor(2, t.node)
                }
            }
            ,
            t.prototype.onEndContact = function(e, t, n) {
                if (this.NPCCtrl && -1 != n.node.name.indexOf("node_road")) {
                    var o = t.node.parent.index;
                    "node_front" == t.node.name ? (this.NPCCtrl.npcFrontTestState[o] = !1,
                    this.NPCCtrl.isStartTimer[o] || (this.NPCCtrl.isStartTimer[o] = !0),
                    t.node.parent.getChildByName("node_particle") && (t.node.parent.getChildByName("node_particle").getChildByName("Ffloor").active = !1)) : "node_after" == t.node.name && (this.NPCCtrl.npcAfterTestState[o] = !1,
                    this.NPCCtrl.isStartTimer[o] || (this.NPCCtrl.isStartTimer[o] = !0),
                    this.NPCCtrl.doFilpTimer[o] = 0,
                    t.node.parent.getChildByName("node_particle") && (t.node.parent.getChildByName("node_particle").getChildByName("Afloor").active = !1),
                    t.node.parent.getChildByName("node_particle") && (t.node.parent.getChildByName("node_particle").getChildByName("shadow").active = !1))
                }
            }
            ,
            t.prototype.onPreSolve = function() {}
            ,
            t.prototype.onPostSolve = function() {}
            ,
            r([s], t)
        }(cc.Component));
        n.default = c,
        cc._RF.pop()
    }
    , {}],
    PlatformDev: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "bf622LP4S1JH4PTv8+AafNk", "PlatformDev");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        );
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.PlatformDev = void 0;
        var r = e("./BasePlatform")
          , i = e("./RankPlayerVO")
          , s = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t.prototype.getWeeklyEntries = function() {
                /* for (var e = [], t = 1; e.length < 10; ) {
                    var n = new i.RankPlayerVO;
                    n.id = "player" + t,
                    n.name = "player1" + t,
                    n.photo = "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3228549874,2173006364&fm=26&gp=0.jpg",
                    n.score = 1 + Math.floor(1e3 * Math.random()),
                    e.push(n),
                    t++
                } */
                return []
            }
            ,
            t.prototype.getAllTimeEntries = function() {
                for (var e = [], t = 1; e.length < 10; ) {
                    var n = new i.RankPlayerVO;
                    n.id = "player" + t,
                    n.name = "player1" + t,
                    n.photo = "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3228549874,2173006364&fm=26&gp=0.jpg",
                    n.score = 1 + Math.floor(1e3 * Math.random()),
                    e.push(n),
                    t++
                }
                return e
            }
            ,
            t
        }(r.BasePlatform);
        n.PlatformDev = s,
        cc._RF.pop()
    }
    , {
        "./BasePlatform": "BasePlatform",
        "./RankPlayerVO": "RankPlayerVO"
    }],
    PlatformFB: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "039bbs4FqhJZ4LaTRjy6g9Q", "PlatformFB");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
        , i = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.PlatformFB = void 0;
        var s = e("./BasePlatform")
          , c = e("../../FBGameConfig")
          , l = e("../core/Extension")
          , u = e("./FriendLeaderboard")
          , p = e("./Advertise")
          , d = e("../App")
          , f = function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.DateReady = !1,
                t._friends = null,
                t.FriendsInfo = [],
                t.ContextEntryInfo = null,
                t.UserInfo1 = {
                    name: "",
                    id: "",
                    photo: "",
                    friends: [],
                    lang: "en_US"
                },
                t._canAdd2HomeScreen = !1,
                t.ContextIds = [],
                t.CurrentID = null,
                t.CurrentType = null,
                t.LevelNum = 0,
                t.BestSessionScore = 0,
                t.Tournament = !1,
                t.TournamentInfo = null,
                t.TournamentPoint = ["feed", "bookmark", "facebook_gaming_tab", "in_game_menu"],
                t.isBanner = !1,
                t.AD_iads = c.default.FB_ADChaping,
                t.AD_rads = c.default.FB_ADVideo,
                t.AD_bads = c.default.FB_Banner,
                t.LastContextScore = 0,
                t.LastContextId = null,
                t.ContextLeaderBoard = null,
                t._isPaymentsReady = !1,
                t
            }
            return a(t, e),
            t.prototype.initSDK = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return [4, new Promise(function(e) {
                                var t = setInterval(function() {
                                    $T_FB_INITIALIZED && (clearInterval(t),
                                    e())
                                }, 100)
                            }
                            )];
                        case 1:
                            t.sent(),
                            this._worldRank = new u.FriendLeaderboard(c.default.PL_HOST,c.default.BOT_ID),
                            this.fetchData(),
                            e = this,
                            t.label = 2;
                        case 2:
                            return t.trys.push([2, 4, , 5]),
                            [4, Promise.all([this.LoadFBData().catch(function(e) {
                                console.log("pull data failed", e)
                            }), FBInstant.player.getConnectedPlayersAsync().then(function(t) {
                                e._friends = t,
                                e._worldRank.setFriends(t)
                            }).catch(function() {
                                return console.log("get friend error")
                            })])];
                        case 3:
                        case 4:
                            return t.sent(),
                            [3, 5];
                        case 5:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.startGame = function() {
                return r(this, void 0, void 0, function() {
                    var e, t, n, o, a, r, s, c = this;
                    return i(this, function(i) {
                        switch (i.label) {
                        case 0:
                            return i.trys.push([0, 2, , 3]),
                            [4, FBInstant.startGameAsync()];
                        case 1:
                        case 2:
                            return i.sent(),
                            [3, 3];
                        case 3:
                            e = "unknow",
                            i.label = 4;
                        case 4:
                            return i.trys.push([4, 6, , 7]),
                            [4, Promise.all([this.onContextChange(!0), FBInstant.getEntryPointAsync().then(function(t) {
                                return e = t
                            }).catch(function() {
                                return console.log("faiddd")
                            }), this._worldRank.initializeAsync().catch(function(e) {
                                return console.log("leaderboard init failed:", e)
                            })])];
                        case 5:
                        case 6:
                            return i.sent(),
                            [3, 7];
                        case 7:
                            return this.watchContext(),
                            t = FBInstant.context.getType(),
                            n = FBInstant.context.getID(),
                            this.ContextEntryInfo = {
                                contextEntry: e,
                                contextType: t,
                                contextId: n
                            },
                            console.log("contextId: " + n),
                            console.log("contextEntry: " + e),
                            console.log("contextType: " + t),
                            console.log("isTournament: " + this.Tournament),
                            console.log("tournamentInfo: " + JSON.stringify(this.TournamentInfo)),
                            -1 != this.TournamentPoint.indexOf(this.ContextEntryInfo.contextEntry) && "THREAD" == t && n == FBInstant.context.getID() && (this.log("thread_tournament", {
                                score: e
                            }),
                            console.log("tournament: " + FBInstant.context.getID()),
                            this.Tournament = !0),
                            o = this.getEntryPointData(),
                            this.switchGameInfo = o && o.switchGameInfo || null,
                            "in_game_menu" == this.ContextEntryInfo.contextEntry && this.switchGameInfo && (console.log("game_switch"),
                            e = "game_switch",
                            this.ContextEntryInfo.contextEntry = e),
                            [4, this.LoadFBData()];
                        case 8:
                            i.sent(),
                            i.label = 9;
                        case 9:
                            return i.trys.push([9, 11, , 12]),
                            a = this,
                            [4, FBInstant.canCreateShortcutAsync()];
                        case 10:
                            return a._canAdd2HomeScreen = i.sent(),
                            [3, 12];
                        case 11:
                            return i.sent(),
                            console.log("canCreateShortcutAsync failed"),
                            [3, 12];
                        case 12:
                            return console.log("can add sc", this._canAdd2HomeScreen),
                            this.iad = new p.InterstitialAD(this.AD_iads,!0),
                            this.iad.on("ad_failed", function(e) {
                                return c.log("ad_failed", e)
                            }),
                            this.iad.on("ad_show", function(e) {
                                return c.log("iad_times", e)
                            }),
                            this.rad = new p.RewardedVideoAD(this.AD_rads,!0),
                            this.rad.on("ad_failed", function(e) {
                                return c.log("ad_failed", e)
                            }),
                            this.rad.on("ad_show", function(e) {
                                return c.log("rad_times", e)
                            }),
                            this._friends ? [3, 14] : [4, FBInstant.player.getConnectedPlayersAsync()];
                        case 13:
                            r = i.sent(),
                            this._friends = r,
                            this._worldRank.setFriends(r),
                            i.label = 14;
                        case 14:
                            return s = this._friends.map(function(e) {
                                return e.getID()
                            }),
                            this.UserInfo1 = {
                                name: FBInstant.player.getName(),
                                id: FBInstant.player.getID(),
                                photo: FBInstant.player.getPhoto(),
                                friends: s,
                                lang: this.getLocale()
                            },
                            this.setSessionScore(),
                            this.ContextIfChanged(),
                            d.default.http.reportFriends().catch(function(e) {
                                return console.log("report friends failed:", e)
                            }),
                            [2]
                        }
                    })
                })
            }
            ,
            Object.defineProperty(t.prototype, "UserInfo", {
                get: function() {
                    return this.UserInfo1
                },
                enumerable: !1,
                configurable: !0
            }),
            t.prototype.fetchData = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            if (this.DateReady)
                                return [2];
                            t.label = 1;
                        case 1:
                            return t.trys.push([1, 3, , 4]),
                            [4, this.initRemoteData()];
                        case 2:
                            return t.sent(),
                            this.DateReady = !0,
                            [3, 4];
                        case 3:
                            return e = t.sent(),
                            console.log("\u83b7\u53d6\u6570\u636e\u5931\u8d25\uff1a", e.code || e.msg || e),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.ShareSkinData = function() {
                var e = FBInstant.getEntryPointData();
                this.invite_skin_data = e && e.invite_skin_data,
                this.invite_skin_data && this.invite_skin_data.playerId == FBInstant.player.getID() && (this.invite_skin_data = null)
            }
            ,
            t.prototype.LoadFBData = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this.fetchData()];
                        case 1:
                            return e.sent(),
                            this.NewPlayer = null == this.$remoteData.gold,
                            this.PlayerType = this.NewPlayer ? "new" : "old",
                            this.NewPlayer && (this.$remoteData.gold = 0,
                            this.$remoteData.add_hs = 0,
                            this.$remoteData.add_hs_refuse_count = 0,
                            this.$remoteData.context_ids = [],
                            this.$remoteData.h_score = 0,
                            this.$remoteData.iap_inventory = [],
                            this.$remoteData.game_db = {},
                            this.$remoteData.skin_invites = [],
                            this.$remoteData.group_context = [],
                            this.syncRemoteData()),
                            this.$remoteData.last_login_dayth ? Date.days() != this.$remoteData.last_login_dayth && (null == this.$remoteData.group_context && (this.$remoteData.group_context = []),
                            this.$remoteData.login_day_count++,
                            this.$remoteData.last_login_dayth = Date.days(),
                            this.syncRemoteData(),
                            console.log("\u8001\u7528\u6237\u767b\u5f55")) : (this.$remoteData.last_login_dayth = Date.days(),
                            this.$remoteData.login_day_count = 1,
                            this.syncRemoteData(),
                            console.log("\u65b0\u7528\u6237\u767b\u5f55")),
                            this.ContextIds = this.$remoteData.context_ids || [],
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.getData = function(e) {
                return r(this, void 0, void 0, function() {
                    var t, n, o;
                    return i(this, function(a) {
                        switch (a.label) {
                        case 0:
                            t = null,
                            n = 3,
                            a.label = 1;
                        case 1:
                            if (t || !(n-- > 0))
                                return [3, 6];
                            a.label = 2;
                        case 2:
                            return a.trys.push([2, 4, , 5]),
                            [4, FBInstant.player.getDataAsync(e)];
                        case 3:
                            return t = a.sent(),
                            [3, 5];
                        case 4:
                            return o = a.sent(),
                            console.log("\u83b7\u53d6\u7528\u6237\u6570\u636e\u5931\u8d25:" + o.code || o.message || o),
                            [3, 5];
                        case 5:
                            return [3, 1];
                        case 6:
                            return [2, t || {}]
                        }
                    })
                })
            }
            ,
            t.prototype.setData = function(e, t) {
                return void 0 === t && (t = !1),
                r(this, void 0, void 0, function() {
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            return [4, FBInstant.player.setDataAsync(e)];
                        case 1:
                            return n.sent(),
                            t ? [4, FBInstant.player.flushDataAsync()] : [3, 3];
                        case 2:
                            n.sent(),
                            n.label = 3;
                        case 3:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.setLoading = function(e) {
                $T_PROGRESS = e
            }
            ,
            t.prototype.setSessionScore = function() {
                try {
                    FBInstant.setSessionData({
                        nickname: this.UserInfo.name,
                        playerInfo: {
                            head: this.UserInfo.photo,
                            lang: this.UserInfo.lang,
                            score: this.$remoteData.h_score
                        }
                    })
                } catch (e) {}
            }
            ,
            t.prototype.getPlatFormiOS = function() {
                return "IOS" == FBInstant.getPlatform()
            }
            ,
            t.prototype.GetFrinedsInfo = function() {
                return this.FriendsInfo || []
            }
            ,
            t.prototype.getEntryPointData = function() {
                return r(this, void 0, void 0, function() {
                    var e, t, n, o, a;
                    return i(this, function(r) {
                        switch (r.label) {
                        case 0:
                            return e = FBInstant.getEntryPointData(),
                            console.log("\u5165\u53e3\u70b9\u4fe1\u606f", JSON.stringify(e)),
                            e ? (this.ChallengeInfo = e && e.challenge_info,
                            this.ChallengeInfo ? [4, FBInstant.context.getPlayersAsync()] : [3, 2]) : [3, 2];
                        case 1:
                            t = r.sent(),
                            n = {},
                            o = {},
                            t.forEach(function(e) {
                                n[e.getID()] = e.getPhoto(),
                                o[e.getID()] = e.getName()
                            }),
                            this.ChallengeInfo.opponents.forEach(function(e) {
                                e.name = o[e.playerId] || "unkonw",
                                e.photo = n[e.playerId] || "default-portrait_png"
                            }),
                            r.label = 2;
                        case 2:
                            return "normal" == (a = e ? e.type : "normal") && FBInstant.context.getID() && (a = "group_rank"),
                            platform.log("entry_point", {
                                entry: a,
                                play_type: this.NewPlayer ? "new" : "old"
                            }),
                            this.Entry = a,
                            console.log("entry", a),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.postTournamentScoreAsync = function(e) {
                return r(this, void 0, Promise, function() {
                    var t, n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            t = null,
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            [4, FBInstant.tournament.postScoreAsync(e)];
                        case 2:
                            return t = o.sent(),
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log("tournament failed", JSON.stringify(n)),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.getTournamentAsync = function() {
                return r(this, void 0, Promise, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = null,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, FBInstant.getTournamentAsync()];
                        case 2:
                            return e = n.sent(),
                            [3, 4];
                        case 3:
                            return t = n.sent(),
                            console.log("tournament failed", JSON.stringify(t)),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.getTournamentsAsync = function() {
                return r(this, void 0, Promise, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = null,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, FBInstant.tournament.getTournamentsAsync()];
                        case 2:
                            return e = n.sent(),
                            [3, 4];
                        case 3:
                            return t = n.sent(),
                            console.log("gettournaments failed", JSON.stringify(t)),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.shareTournamentAsync = function(e) {
                return r(this, void 0, Promise, function() {
                    var t, n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            t = !1,
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            this.log("shareTournamentasync", {
                                result: 0
                            }),
                            [4, FBInstant.tournament.shareAsync(e)];
                        case 2:
                            return o.sent(),
                            this.log("shareTournamentasync", {
                                result: 1
                            }),
                            t = !0,
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log("shareTournamentAsync failed", n),
                            this.log("shareTournamentasync", {
                                result: -1
                            }),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.joinTournamentAsync = function(e) {
                return r(this, void 0, Promise, function() {
                    var t, n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            t = !1,
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            this.log("joinTournamentasync", {
                                result: 0
                            }),
                            [4, FBInstant.tournament.joinAsync(e)];
                        case 2:
                            return o.sent(),
                            this.log("joinTournamentasync", {
                                result: 1
                            }),
                            t = !0,
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log("joinTournamentAsync failed", n),
                            this.log("joinTournamentasync", {
                                result: -1
                            }),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.createTournamentAsync = function(e, t, n) {
                return r(this, void 0, Promise, function() {
                    var o, a;
                    return i(this, function(r) {
                        switch (r.label) {
                        case 0:
                            o = !1,
                            r.label = 1;
                        case 1:
                            return r.trys.push([1, 3, , 4]),
                            this.log("createTournamentasync", {
                                result: 0
                            }),
                            [4, FBInstant.tournament.createAsync({
                                initialScore: e,
                                config: {
                                    title: t || "",
                                    image: n || null,
                                    sortOrder: "HIGHER_IS_BETTER",
                                    scoreFormat: "NUMERIC"
                                },
                                data: {}
                            })];
                        case 2:
                            return r.sent(),
                            o = !0,
                            this.log("createTournamentasync", {
                                result: 1
                            }),
                            [3, 4];
                        case 3:
                            return a = r.sent(),
                            console.log("createTournamentAsync failed", a),
                            "INVALID_OPERATION" == a.code && this.getTournamentAsync(),
                            this.log("createTournamentasync", {
                                result: -1
                            }),
                            [3, 4];
                        case 4:
                            return [2, o]
                        }
                    })
                })
            }
            ,
            t.prototype.createTournament = function(e) {
                var t;
                t = null == e ? "solo" : "4386211548098822" == e ? "overbtn" : "4706976649341959" == e ? "overTournament" : "oversystem",
                console.log("create new tournament"),
                this.log("tournament_create", {
                    source: t
                })
            }
            ,
            t.prototype.onContextChange = function(e, t) {
                return void 0 === t && (t = 0),
                r(this, void 0, void 0, function() {
                    var n, o, a;
                    return i(this, function(r) {
                        switch (r.label) {
                        case 0:
                            n = FBInstant.context.getID(),
                            this.BestSessionScore = 0,
                            this.CurrentID = n,
                            this.CurrentType = FBInstant.context.getType(),
                            this.Tournament = !e,
                            this.TournamentInfo = null,
                            r.label = 1;
                        case 1:
                            return r.trys.push([1, 3, , 4]),
                            [4, this.getTournamentAsync()];
                        case 2:
                            return (o = r.sent()) ? (this.TournamentInfo = {
                                id: o.getID,
                                contextId: o.getContextID(),
                                endTime: o.getEndTime()
                            },
                            console.log("tournamentinfo", {
                                tournamentid: o.getContextID(),
                                createTime: o.getEndTime() - 604800,
                                endTime: o.getEndTime()
                            }),
                            ~~(Date.now() / 1e3) < o.getEndTime() && (this.Tournament = !0),
                            this.emit("newTournament")) : 1 == e && 0 == t && null != n && -1 == platform.remoteData.context_ids.indexOf(n) && (platform.remoteData.context_ids.push(n),
                            platform.syncRemoteData()),
                            [3, 4];
                        case 3:
                            return a = r.sent(),
                            console.log("get tournament error:", a),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.watchContext = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return (e = FBInstant.context.getID()) == this.CurrentID ? [3, 2] : (this.CurrentID,
                            this.CurrentID = e,
                            this.createTournament(e),
                            [4, this.onContextChange(!1)]);
                        case 1:
                            t.sent(),
                            t.label = 2;
                        case 2:
                            return [4, l.waitAsync(500)];
                        case 3:
                            return t.sent(),
                            [3, 0];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.isTournament = function() {
                var e = !1;
                if (this.TournamentInfo && this.switchGameInfo && FBInstant.context.getID() == this.ContextEntryInfo.contextId)
                    e = !1;
                else {
                    var t = ~~(Date.now() / 1e3);
                    e = !!(this.TournamentInfo && t < this.TournamentInfo.endTime)
                }
                return e
            }
            ,
            t.prototype.setTournament = function(e) {
                this.Tournament = e
            }
            ,
            t.prototype.getHighScore = function() {
                return this._worldRank.getAllTimeHighScore()
            }
            ,
            t.prototype.setHighScore = function(e, t) {
                e > this.$remoteData.h_score && (this.$remoteData.h_score = e,
                this.syncRemoteData()),
                this._worldRank.setScoreAsync(e, t)
            }
            ,
            t.prototype.postSessionScore = function(e, t) {
                return void 0 === t && (t = !1),
                r(this, void 0, void 0, function() {
                    var n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            if (this.LevelNum++,
                            this.log("level_times", {
                                score: this.LevelNum
                            }),
                            !t && e <= this.BestSessionScore)
                                return [2];
                            0 == t && (this.BestSessionScore = e),
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            [4, FBInstant.postSessionScore(e)];
                        case 2:
                            return o.sent(),
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log("postSessionScore error ", JSON.stringify(n)),
                            [3, 4];
                        case 4:
                            return this.log("session_score", {
                                score: e
                            }),
                            console.log("session: " + this.getContextId()),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.postSessionScoreAsync = function(e, t) {
                return void 0 === t && (t = !1),
                r(this, void 0, void 0, function() {
                    var n, o;
                    return i(this, function(a) {
                        switch (a.label) {
                        case 0:
                            if (n = !1,
                            this.LevelNum++,
                            this.log("level_times", {
                                score: this.LevelNum
                            }),
                            !t && e <= this.BestSessionScore)
                                return [2];
                            0 == t && (this.BestSessionScore = e),
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 3, , 4]),
                            [4, FBInstant.postSessionScoreAsync(e)];
                        case 2:
                            return a.sent(),
                            n = !0,
                            [3, 4];
                        case 3:
                            return o = a.sent(),
                            console.log("postSessionScoreAsync error ", JSON.stringify(o)),
                            [3, 4];
                        case 4:
                            return this.log("session_score", {
                                score: e
                            }),
                            console.log("contextID: " + this.getContextId()),
                            [2, n]
                        }
                    })
                })
            }
            ,
            t.prototype.getContextId = function() {
                return FBInstant.context.getID()
            }
            ,
            t.prototype.getPlayerId = function() {
                return FBInstant.player.getID()
            }
            ,
            t.prototype.getLocale = function() {
                return FBInstant.getLocale()
            }
            ,
            t.prototype.getSDKVersion = function() {
                return FBInstant.getSDKVersion()
            }
            ,
            t.prototype.switchCtx = function(e, t) {
                return void 0 === t && (t = "default"),
                r(this, void 0, void 0, function() {
                    var n, o;
                    return i(this, function(a) {
                        switch (a.label) {
                        case 0:
                            n = !1,
                            this.log("switch_result", {
                                result: 0,
                                place: t
                            }),
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 3, , 4]),
                            [4, FBInstant.context.switchAsync(e)];
                        case 2:
                            return a.sent(),
                            this.log("switch_result", {
                                result: 1,
                                place: t
                            }),
                            this.onContextChange(!0),
                            n = !0,
                            [3, 4];
                        case 3:
                            return o = a.sent(),
                            console.log("\u6539\u53d8\u4f1a\u8bdd\u73af\u5883\u5931\u8d25", JSON.stringify(o)),
                            "SAME_CONTEXT" == o.code && (n = !0),
                            [3, 4];
                        case 4:
                            return [2, n]
                        }
                    })
                })
            }
            ,
            t.prototype.chooseAsync = function() {
                return r(this, void 0, void 0, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = !1,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            this.log("choose_result", {
                                result: 0
                            }),
                            [4, FBInstant.context.chooseAsync({
                                filters: ["INCLUDE_EXISTING_CHALLENGES"]
                            })];
                        case 2:
                            return n.sent(),
                            this.onContextChange(!0),
                            this.log("choose_result", {
                                result: 1
                            }),
                            e = !0,
                            [3, 4];
                        case 3:
                            return t = n.sent(),
                            console.log("\u9009\u62e9\u4f1a\u8bdd\u73af\u5883\u5931\u8d25", JSON.stringify(t)),
                            "SAME_CONTEXT" == t.code && (e = !0),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.createAsync = function(e) {
                return r(this, void 0, void 0, function() {
                    var t, n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            t = !1,
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            this.log("challenge_result", {
                                result: 0
                            }),
                            [4, FBInstant.context.createAsync(e)];
                        case 2:
                            return o.sent(),
                            this.log("challenge_result", {
                                result: 1
                            }),
                            this.onContextChange(!0),
                            t = !0,
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log("\u6311\u6218\u597d\u53cb\u5931\u8d25", JSON.stringify(n)),
                            "SAME_CONTEXT" == n.code && (t = !0),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.switchGame = function(e, t) {
                return r(this, void 0, void 0, function() {
                    var n, o;
                    return i(this, function(a) {
                        switch (a.label) {
                        case 0:
                            this.log("swithgame", {
                                phase: 0,
                                appid: e
                            }),
                            n = {
                                switchGameInfo: {
                                    appId: this.appId,
                                    appName: this.appName
                                },
                                type: this.appName
                            },
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 4, , 5]),
                            [4, FBInstant.switchGameAsync(e, Object.assign(n, t))];
                        case 2:
                            return a.sent(),
                            [4, this.onContextChange(!0, 1)];
                        case 3:
                            return a.sent(),
                            [3, 5];
                        case 4:
                            return o = a.sent(),
                            console.log("switchgame error", JSON.stringify(o)),
                            [2, !1];
                        case 5:
                            return this.log("swithgame", {
                                phase: 1,
                                appid: e
                            }),
                            [2, !0]
                        }
                    })
                })
            }
            ,
            t.prototype.getContextPlayers = function() {
                return r(this, void 0, void 0, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = [],
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, FBInstant.context.getPlayersAsync()];
                        case 2:
                            return e = n.sent(),
                            [3, 4];
                        case 3:
                            return t = n.sent(),
                            console.log("getContextPlayers error", JSON.stringify(t)),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.shareLinkAsync = function(e) {
                return void 0 === e && (e = {}),
                r(this, void 0, void 0, function() {
                    var t, n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            t = !1,
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            [4, FBInstant.shareLinkAsync({
                                image: e.image,
                                text: e.text || "Hey buddy, I found an awesome game. I'm sure you'll love it.",
                                data: e.data || null
                            })];
                        case 2:
                            return o.sent(),
                            t = !0,
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log("shareLinkAsync error", JSON.stringify(n)),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.inviteAsync = function(e) {
                return void 0 === e && (e = {}),
                r(this, void 0, void 0, function() {
                    var t, n;
                    return i(this, function(o) {
                        switch (o.label) {
                        case 0:
                            t = !1,
                            o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]),
                            [4, FBInstant.inviteAsync({
                                image: e.image,
                                text: e.text || "Hey buddy, I found an awesome game. I'm sure you'll love it.",
                                data: e.data || null
                            })];
                        case 2:
                            return o.sent(),
                            t = !0,
                            [3, 4];
                        case 3:
                            return n = o.sent(),
                            console.log("inviteAsync error", JSON.stringify(n)),
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.shareAsync = function(e) {
                return void 0 === e && (e = {}),
                r(this, void 0, void 0, function() {
                    var t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            t = !0,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            console.log("share..."),
                            [4, FBInstant.shareAsync({
                                intent: "SHARE",
                                image: e.img,
                                text: e.text || "Hey buddy, I found an awesome game. I'm sure you'll love it.",
                                data: e.data || null
                            })];
                        case 2:
                            return n.sent(),
                            [3, 4];
                        case 3:
                            return n.sent(),
                            t = !1,
                            [3, 4];
                        case 4:
                            return [2, t]
                        }
                    })
                })
            }
            ,
            t.prototype.updateStatues = function(e, t) {
                return r(this, void 0, void 0, function() {
                    var n, o, a;
                    return i(this, function(r) {
                        switch (r.label) {
                        case 0:
                            n = 0,
                            r.label = 1;
                        case 1:
                            if (!(n < 3))
                                return [3, 8];
                            o = !1,
                            r.label = 2;
                        case 2:
                            return r.trys.push([2, 4, , 5]),
                            [4, FBInstant.updateAsync({
                                action: t.action || "CUSTOM",
                                cta: t.cta || "Play now",
                                image: t.image,
                                text: t.text || "Play with me!",
                                template: t.template || "game_result",
                                data: e,
                                strategy: t.strategy || "IMMEDIATE",
                                notification: t.notification || "PUSH"
                            })];
                        case 3:
                            return r.sent(),
                            [3, 5];
                        case 4:
                            return a = r.sent(),
                            o = !0,
                            console.log("updateStatues failed", n, JSON.stringify(a)),
                            [3, 5];
                        case 5:
                            return o ? [4, l.waitAsync(500)] : [3, 8];
                        case 6:
                            r.sent(),
                            r.label = 7;
                        case 7:
                            return n++,
                            [3, 1];
                        case 8:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.checkMatchPlayer = function() {
                return r(this, void 0, void 0, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = !1,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, FBInstant.checkCanPlayerMatchAsync()];
                        case 2:
                            return e = n.sent(),
                            [3, 4];
                        case 3:
                            return t = n.sent(),
                            console.log("\u4e0d\u5177\u5907Match\u6761\u4ef6", JSON.stringify(t)),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.MatchPlayer = function() {
                return r(this, void 0, void 0, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = !1,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            this.log("matchplayer", {
                                score: 0
                            }),
                            [4, FBInstant.matchPlayerAsync(null, !0, !0)];
                        case 2:
                            return n.sent(),
                            this.log("matchplayer", {
                                score: 1
                            }),
                            e = !0,
                            [3, 4];
                        case 3:
                            return t = n.sent(),
                            this.log("matchplayer", {
                                score: -1
                            }),
                            console.log("MatchPlayer\u5931\u8d25", JSON.stringify(t)),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.canAdd2HomeScreen = function() {
                return this._canAdd2HomeScreen
            }
            ,
            t.prototype.add2HomeScreen = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return t.trys.push([0, 2, , 3]),
                            [4, FBInstant.createShortcutAsync()];
                        case 1:
                            return t.sent(),
                            [3, 3];
                        case 2:
                            return e = t.sent(),
                            console.log("add 2 Home Screen result", JSON.stringify(e)),
                            [2, {
                                res: !1,
                                code: e.code
                            }];
                        case 3:
                            return [2, {
                                res: !0,
                                code: ""
                            }]
                        }
                    })
                })
            }
            ,
            t.prototype.checkHomeScene = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return t.trys.push([0, 4, , 5]),
                            [4, FBInstant.canCreateShortcutAsync()];
                        case 1:
                            return t.sent() ? (this.log("homescene", {
                                score: 0
                            }),
                            [4, FBInstant.createShortcutAsync()]) : [3, 3];
                        case 2:
                            t.sent(),
                            this.log("homescene", {
                                score: 1
                            }),
                            t.label = 3;
                        case 3:
                            return [3, 5];
                        case 4:
                            return e = t.sent(),
                            this.log("homescene", {
                                score: -1
                            }),
                            console.log("\u521b\u5efa\u5feb\u6377\u65b9\u5f0f\u5931\u8d25", JSON.stringify(e)),
                            [3, 5];
                        case 5:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.checkBotSubscribe = function() {
                return r(this, void 0, void 0, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = !1,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 5, , 6]),
                            [4, FBInstant.player.canSubscribeBotAsync()];
                        case 2:
                            return t = n.sent(),
                            console.log("\u662f\u5426\u53ef\u4ee5\u8ba2\u9605Bot:", t),
                            t ? (this.log("bot_subscribe", {
                                result: -1
                            }),
                            [4, FBInstant.player.subscribeBotAsync()]) : [3, 4];
                        case 3:
                            n.sent(),
                            this.log("bot_subscribe", {
                                result: 1
                            }),
                            e = !0,
                            n.label = 4;
                        case 4:
                            return [3, 6];
                        case 5:
                            return n.sent(),
                            this.log("bot_subscribe", {
                                result: 0
                            }),
                            [3, 6];
                        case 6:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.ShowBannerAd = function() {
                return r(this, void 0, void 0, function() {
                    var e;
                    return i(this, function(t) {
                        switch (t.label) {
                        case 0:
                            if (-1 == FBInstant.getSupportedAPIs().indexOf("loadBannerAdAsync") || 1 == this.isBanner)
                                return [2];
                            t.label = 1;
                        case 1:
                            return t.trys.push([1, 3, , 4]),
                            [4, FBInstant.loadBannerAdAsync(this.AD_bads)];
                        case 2:
                            return t.sent(),
                            this.isBanner = !0,
                            console.log("loadBannerAdAsync success"),
                            [3, 4];
                        case 3:
                            return e = t.sent(),
                            console.log("loadBannerAdAsync error:" + e.code || e.message || e),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.hideBannerAd = function() {
                try {
                    FBInstant.hideBannerAdAsync(),
                    this.isBanner = !1
                } catch (e) {
                    console.log("hideBannerAdAsync error", e)
                }
            }
            ,
            t.prototype.hasAD = function() {
                return this.hasRAD() || this.hasIAD()
            }
            ,
            t.prototype.showAD = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return this.hasRAD() ? [4, this.showRAD()] : [3, 2];
                        case 1:
                            return e.sent(),
                            [3, 4];
                        case 2:
                            return this.hasIAD() ? [4, this.showIAD()] : [3, 4];
                        case 3:
                            e.sent(),
                            e.label = 4;
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.hasRAD = function() {
                return this.rad && this.rad.hasAD()
            }
            ,
            t.prototype.showRAD = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return this.rad ? [4, this.rad.showAD()] : [3, 2];
                        case 1:
                            e.sent(),
                            e.label = 2;
                        case 2:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.hasIAD = function() {
                return this.iad && this.iad.hasAD()
            }
            ,
            t.prototype.showIAD = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return this.iad ? [4, this.iad.showAD()] : [3, 2];
                        case 1:
                            e.sent(),
                            e.label = 2;
                        case 2:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.suportIAP = function() {
                return this._isPaymentsReady
            }
            ,
            t.prototype.getCatalogAsync = function() {
                return r(this, void 0, void 0, function() {
                    var e, t;
                    return i(this, function(n) {
                        switch (n.label) {
                        case 0:
                            e = null,
                            n.label = 1;
                        case 1:
                            return n.trys.push([1, 3, , 4]),
                            [4, FBInstant.payments.getCatalogAsync()];
                        case 2:
                            return e = n.sent(),
                            console.log(JSON.stringify(e)),
                            [3, 4];
                        case 3:
                            return t = n.sent(),
                            console.log("getCatalogAsync error:" + t.code || t.message || t),
                            [3, 4];
                        case 4:
                            return [2, e]
                        }
                    })
                })
            }
            ,
            t.prototype.purchaseAsync = function(e, t) {
                return void 0 === t && (t = ""),
                r(this, void 0, void 0, function() {
                    var n, o, a, r, s;
                    return i(this, function(i) {
                        switch (i.label) {
                        case 0:
                            if (!this._isPaymentsReady)
                                return [2, !1];
                            n = !1,
                            o = FBInstant.getPlatform(),
                            this.log("buyProduct", {
                                phase: 0,
                                productId: e,
                                platform: o
                            }),
                            i.label = 1;
                        case 1:
                            return i.trys.push([1, 4, , 5]),
                            (a = {}).productID = e,
                            t && (a.developerPayload = a.developerPayload),
                            [4, FBInstant.payments.purchaseAsync(a)];
                        case 2:
                            return r = i.sent(),
                            this.log("buyProduct", {
                                phase: 1,
                                productId: e,
                                platform: o
                            }),
                            [4, FBInstant.payments.consumePurchaseAsync(r.purchaseToken)];
                        case 3:
                            return i.sent(),
                            this.addIAPInventroy(r.productID),
                            this.log("buyProduct", {
                                phase: 2,
                                productId: e,
                                platform: o
                            }),
                            n = !0,
                            [3, 5];
                        case 4:
                            return s = i.sent(),
                            console.log("purchaseAsync error:" + s.code || s.message || s),
                            this.log("buyProduct", {
                                phase: -1,
                                productId: e,
                                platform: o,
                                code: s.code
                            }),
                            [3, 5];
                        case 5:
                            return [2, n]
                        }
                    })
                })
            }
            ,
            t.prototype.checkPurchaseAsync = function() {
                return r(this, void 0, void 0, function() {
                    var e, t, n, o, a, r, s;
                    return i(this, function(i) {
                        switch (i.label) {
                        case 0:
                            if (!this._isPaymentsReady)
                                return [2, null];
                            e = FBInstant.getPlatform(),
                            t = null,
                            i.label = 1;
                        case 1:
                            return i.trys.push([1, 3, , 4]),
                            [4, FBInstant.payments.getPurchasesAsync()];
                        case 2:
                            return t = i.sent(),
                            [3, 4];
                        case 3:
                            return n = i.sent(),
                            console.log("getPurchasesAsync error:" + n.code || n.message || n),
                            [3, 4];
                        case 4:
                            o = 0,
                            a = t,
                            i.label = 5;
                        case 5:
                            if (!(o < a.length))
                                return [3, 10];
                            r = a[o],
                            i.label = 6;
                        case 6:
                            return i.trys.push([6, 8, , 9]),
                            [4, FBInstant.payments.consumePurchaseAsync(r.purchaseToken)];
                        case 7:
                            return i.sent(),
                            this.addIAPInventroy(r.productID),
                            this.log("checkPurchase", {
                                phase: 1,
                                productId: r.productID,
                                platform: e
                            }),
                            [3, 9];
                        case 8:
                            return s = i.sent(),
                            console.log("checkPurchase error:" + s.code || s.message || s),
                            this.log("checkPurchase", {
                                phase: -1,
                                platform: e,
                                code: s.code
                            }),
                            [3, 9];
                        case 9:
                            return o++,
                            [3, 5];
                        case 10:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.initPayments = function() {
                var e = this;
                if (-1 != FBInstant.getSupportedAPIs().indexOf("payments.purchaseAsync") && "IOS" != FBInstant.getPlatform()) {
                    var t = FBInstant.getPlatform();
                    this.log("paymentsReady", {
                        phase: 0,
                        platform: t
                    }),
                    FBInstant.payments.onReady(function() {
                        e._isPaymentsReady = !0,
                        e.log("paymentsReady", {
                            phase: 1,
                            platform: t
                        }),
                        e.checkPurchaseAsync()
                    })
                }
            }
            ,
            t.prototype.addIAPInventroy = function(e) {
                this.remoteData.iap_inventory || (this.remoteData.iap_inventory = []),
                this.remoteData.iap_inventory.push(e),
                this.syncRemoteData()
            }
            ,
            t.prototype.hasPurchased = function(e) {
                var t = this.remoteData.iap_inventory;
                return t && -1 != t.indexOf(e)
            }
            ,
            t.prototype.initLoeaderBoard = function() {
                return r(this, void 0, void 0, function() {
                    return i(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this._worldRank.initializeAsync()];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.initLaeadReaty = function() {
                return this._worldRank.initLaeadReaty()
            }
            ,
            t.prototype.getAllTimeEntriesAsync = function() {
                return this._worldRank.getAllTimeEntriesAsync()
            }
            ,
            t.prototype.getAllTimeEntries = function() {
                return this._worldRank.getAllTimeEntries()
            }
            ,
            t.prototype.getWeeklyEntriesAsync = function() {
                return this._worldRank.getWeeklyEntriesAsync()
            }
            ,
            t.prototype.getWeeklyEntries = function() {
                return this._worldRank.getWeeklyEntries()
            }
            ,
            t.prototype.getWeeklyHighScore = function() {
                return this._worldRank.getWeeklyHighScore()
            }
            ,
            t.prototype.getAllTimeHighScore = function() {
                return this._worldRank.getAllTimeHighScore()
            }
            ,
            t.prototype.GetLeaderboard = function(e, t) {
                return r(this, void 0, void 0, function() {
                    var n, o, a, r, s, c, l;
                    return i(this, function(i) {
                        switch (i.label) {
                        case 0:
                            if (n = [],
                            !e)
                                return [3, 8];
                            o = "context." + e,
                            i.label = 1;
                        case 1:
                            return i.trys.push([1, 7, , 8]),
                            [4, FBInstant.getLeaderboardAsync(o)];
                        case 2:
                            return a = i.sent(),
                            r = null,
                            1 != t ? [3, 4] : [4, a.getConnectedPlayerEntriesAsync(100, 0)];
                        case 3:
                            return r = i.sent(),
                            [3, 6];
                        case 4:
                            return [4, a.getEntriesAsync(100, 0)];
                        case 5:
                            r = i.sent(),
                            i.label = 6;
                        case 6:
                            for (s = {},
                            c = 0; c < r.length; c++)
                                (s = {}).rank = r[c].getRank(),
                                s.score = r[c].getScore(),
                                s.id = r[c].getPlayer().getID(),
                                s.name = r[c].getPlayer().getName(),
                                s.photo = r[c].getPlayer().getPhoto(),
                                n.push(s);
                            return [3, 8];
                        case 7:
                            return l = i.sent(),
                            console.log("\u83b7\u53d6\u6392\u884c\u699c\u5931\u8d25", l.code, l.message),
                            [3, 8];
                        case 8:
                            return [2, n]
                        }
                    })
                })
            }
            ,
            t.prototype.ContextIfChanged = function() {
                return r(this, void 0, void 0, function() {
                    var e, t, n, o, a, r, s;
                    return i(this, function(i) {
                        switch (i.label) {
                        case 0:
                            e = FBInstant.player.getName(),
                            i.label = 1;
                        case 1:
                            if (!(t = FBInstant.context.getID()))
                                return [3, 13];
                            if (n = "context." + t,
                            t == this.LastContextId)
                                return [3, 8];
                            console.log("context changes detected"),
                            i.label = 2;
                        case 2:
                            return i.trys.push([2, 6, , 7]),
                            this.LastContextId = t,
                            o = this,
                            [4, FBInstant.getLeaderboardAsync(n)];
                        case 3:
                            return o.ContextLeaderBoard = i.sent(),
                            this.LastContextScore = 1,
                            console.log("seting score ..."),
                            [4, this.ContextLeaderBoard.setScoreAsync(this.LastContextScore, "")];
                        case 4:
                            return i.sent(),
                            console.log("sending update ..."),
                            [4, FBInstant.updateAsync({
                                action: "LEADERBOARD",
                                name: n,
                                text: e + " joined this game"
                            })];
                        case 5:
                            return i.sent(),
                            [3, 7];
                        case 6:
                            return a = i.sent(),
                            console.log("rank msg failed:", a),
                            [3, 7];
                        case 7:
                            console.log("all done!"),
                            i.label = 8;
                        case 8:
                            if (!((r = d.default.connect.getCurentScore()) > this.LastContextScore))
                                return [3, 13];
                            i.label = 9;
                        case 9:
                            return i.trys.push([9, 12, , 13]),
                            console.log("score changed!"),
                            this.LastContextScore = r,
                            console.log("seting score ..."),
                            [4, this.ContextLeaderBoard.setScoreAsync(this.LastContextScore, "")];
                        case 10:
                            return i.sent(),
                            console.log("sending update ..."),
                            [4, FBInstant.updateAsync({
                                action: "LEADERBOARD",
                                name: n,
                                text: e + " scored " + r,
                                data: {
                                    ss: "hhh"
                                }
                            })];
                        case 11:
                            return i.sent(),
                            console.log("all done!"),
                            [3, 13];
                        case 12:
                            return s = i.sent(),
                            console.log("score changed update failed:", s),
                            [3, 13];
                        case 13:
                            return [4, l.waitAsync(3e3)];
                        case 14:
                            return i.sent(),
                            [3, 1];
                        case 15:
                            return [2]
                        }
                    })
                })
            }
            ,
            t.prototype.log = function(t, n, o) {
                void 0 === o && (o = 1),
                e.prototype.log.call(this, t, n, o),
                (n = n || {})._appVersion = $T_GAME_VERSION,
                n.playerId = FBInstant.player.getID(),
                n.playerName = FBInstant.player.getName(),
                FBInstant.logEvent(t, o, n)
            }
            ,
            t
        }(s.BasePlatform);
        n.PlatformFB = f,
        cc._RF.pop()
    }
    , {
        "../../FBGameConfig": "FBGameConfig",
        "../App": "App",
        "../core/Extension": "Extension",
        "./Advertise": "Advertise",
        "./BasePlatform": "BasePlatform",
        "./FriendLeaderboard": "FriendLeaderboard"
    }],
    PlatformFactory: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "61c6awYHHhKbbNtU9NYaYUT", "PlatformFactory"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.PlatformFactory = void 0;
        var o = e("./PlatformDev")
          , a = e("./PlatformFB")
          , r = function() {
            function e() {}
            return e.create = function() {
                return window.FBInstant ? new a.PlatformFB : new o.PlatformDev
            }
            ,
            e
        }();
        n.PlatformFactory = r,
        cc._RF.pop()
    }
    , {
        "./PlatformDev": "PlatformDev",
        "./PlatformFB": "PlatformFB"
    }],
    PreloadScene: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "9ccb757GhRBqrxv6EwEVhDd", "PreloadScene");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        , i = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
        , s = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var c = e("../Module/Config/ConfigPreload")
          , l = e("../View/LoadingView")
          , u = e("../Module/App")
          , p = e("../Module/platform/PlatformFactory")
          , d = e("../FBGameConfig")
          , f = e("../Utils/GameUtils")
          , h = cc._decorator
          , m = h.ccclass
          , y = h.property
          , v = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.loadingViewPrefab = null,
                t.versionLabel = null,
                t.preloadCount = 0,
                t.nowProgress = 0,
                t.NewLoadingView = null,
                t.totalprogress = 0,
                t
            }
            return a(t, e),
            t.prototype.onLoad = function() {
                var e = this;
                this.nowProgress = 0,
                cc.assetManager.downloader.maxConcurrency = 300,
                cc.assetManager.downloader.maxRequestsPerFrame = 150,
                this.NewLoadingView = cc.instantiate(this.loadingViewPrefab),
                this.node.addChild(this.NewLoadingView, -1);
                var t = this.NewLoadingView.getComponent(l.default);
                t.initialize({
                    showBg: !0
                }),
                t.show(),
                this.versionLabel.string = window.$game_version || "v1.0",
                cc.director.getCollisionManager().enabled = !0,
                window.platform = p.PlatformFactory.create(),
                platform.log("game_loading", {
                    type: "initialized"
                }),
                this.initGame().then(function() {
                    var t = d.default.FB_ADChaping[0].substring(0, d.default.FB_ADChaping[0].indexOf("_"))
                      , n = d.default.FB_ADVideo[0].substring(0, d.default.FB_ADVideo[0].indexOf("_"))
                      , o = d.default.FB_ADCheck;
                    "" + parseInt(t) % 1e5 == o && "" + parseInt(n) % 1e5 == o && (f.default.initConnect(),
                    f.default.initNumTimeAD(),
                    f.default.LoadGameScore(),
                    e.PlayGame()),
                    platform.log("game_loading", {
                        type: "ready"
                    })
                })
            }
            ,
            t.prototype.initGame = function() {
                return i(this, void 0, void 0, function() {
                    var e = this;
                    return s(this, function(t) {
                        switch (t.label) {
                        case 0:
                            return this.addPreloadProgress(0),
                            [4, Promise.all([platform.initSDK().then(function() {
                                e.addPreloadProgress(10)
                            }), this.preloadResources().then(function() {
                                e.addPreloadProgress(80)
                            })])];
                        case 1:
                            return t.sent(),
                            [4, platform.startGame()];
                        case 2:
                            return t.sent(),
                            this.addPreloadProgress(100),
                            [4, platform.checkBotSubscribe()];
                        case 3:
                            return t.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.start = function() {}
            ,
            t.prototype.initialize = function() {
                return i(this, void 0, Promise, function() {
                    return s(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, Promise.all([platform.initSDK(), platform.startGame(), platform.checkBotSubscribe(), this.preloadResources()])];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            t.prototype.randomRange = function(e, t) {
                return Math.random() * (t - e) + e
            }
            ,
            t.prototype.PlayGame = function() {
                var e = this;
                cc.loader.onProgress = function(t, n) {
                    var o = t / n * .1;
                    e.totalprogress = e.nowProgress + o,
                    e.NewLoadingView.getComponent(l.default).setProgress(e.totalprogress),
                    e.NewLoadingView.getChildByName("progress").getChildByName("text").getComponent(cc.Label).string = parseInt(100 * e.totalprogress + "") + "%"
                }
                ,
                cc.director.preloadScene(c.SceneName.Game, function() {
                    cc.loader.onProgress = null,
                    cc.director.loadScene(c.SceneName.Game)
                })
            }
            ,
            t.prototype.addPreloadProgress = function(e) {
                var t = 100 - this.preloadCount
                  , n = e || .5 * t + this.randomRange(-.05, .05) * t;
                this.preloadCount += n,
                platform.setLoading(this.preloadCount)
            }
            ,
            t.prototype.loadAudio = function() {
                return Promise.resolve()
            }
            ,
            t.prototype.loatJson = function() {
                return new Promise(function(e, t) {
                    cc.loader.loadRes(c.JsonUrl.CardsData, cc.JsonAsset, function(n, o) {
                        n ? t(n) : e(o.json)
                    })
                }
                )
            }
            ,
            t.prototype.loadUI = function() {
                return u.default.resManager.loadArr([c.UIResourceUrl.LoadingView])
            }
            ,
            t.prototype.preloadResources = function() {
                var e = this
                  , t = u.default.resManager;
                return Promise.all([t.loadAll("/", function(t, n) {
                    t / n * .9 >= e.nowProgress && (e.nowProgress = t / n * .9,
                    e.NewLoadingView.getComponent(l.default).setProgress(e.nowProgress),
                    e.NewLoadingView.getChildByName("progress").getChildByName("text").getComponent(cc.Label).string = parseInt(100 * e.nowProgress + "") + "%")
                }), this.loadUI().then(function() {
                    e.addPreloadProgress(20)
                })])
            }
            ,
            r([y(cc.Prefab)], t.prototype, "loadingViewPrefab", void 0),
            r([y(cc.Label)], t.prototype, "versionLabel", void 0),
            r([m], t)
        }(cc.Component);
        n.default = v,
        cc._RF.pop()
    }
    , {
        "../FBGameConfig": "FBGameConfig",
        "../Module/App": "App",
        "../Module/Config/ConfigPreload": "ConfigPreload",
        "../Module/platform/PlatformFactory": "PlatformFactory",
        "../Utils/GameUtils": "GameUtils",
        "../View/LoadingView": "LoadingView"
    }],
    RankPlayerVO: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "29847kPiKpEuoyOCHWokBFe", "RankPlayerVO"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.RankPlayerVO = void 0;
        var o = function() {
            function e() {
                this.name = "",
                this.photo = "",
                this.score = 0,
                this.id = "",
                this.tip = "",
                this.rank = 0
            }
            return Object.defineProperty(e.prototype, "skin", {
                get: function() {
                    return this.extraData && this.extraData.skin || 1
                },
                enumerable: !1,
                configurable: !0
            }),
            Object.defineProperty(e.prototype, "skin1", {
                get: function() {
                    return this.extraData && this.extraData.skin || 1
                },
                enumerable: !1,
                configurable: !0
            }),
            e.prototype.toJSON = function() {
                return {
                    id: this.id,
                    score: this.score,
                    extraData: this.extraData
                }
            }
            ,
            e.createFromJSON = function(t) {
                var n = new e;
                if (n.id = t.id,
                n.score = t.score,
                "string" == typeof t.extraData)
                    try {
                        n.extraData = JSON.parse(t.extraData)
                    } catch (o) {}
                else
                    n.extraData = t.extraData;
                return n
            }
            ,
            e.createFromLeaderBoardEntry = function(t) {
                var n = t.getPlayer()
                  , o = new e;
                o.name = n.getName(),
                o.photo = n.getPhoto(),
                o.id = n.getID(),
                o.score = t.getScore();
                var a = t.getExtraData()
                  , r = null;
                try {
                    a && (r = JSON.parse(a))
                } catch (i) {
                    console.log(i)
                }
                return o.extraData = r,
                o.rank = t.getRank(),
                o
            }
            ,
            e.createFromContextPlayer = function(t) {
                var n = new e;
                return n.name = t.getName(),
                n.photo = t.getPhoto(),
                n.id = t.getID(),
                n
            }
            ,
            e.prototype.toJSONObj = function() {
                return {
                    id: this.id,
                    score: this.score,
                    extraData: this.extraData
                }
            }
            ,
            e.fromJSONObj = function(t) {
                var n = new e;
                if (n.id = t.id,
                n.score = t.score,
                "string" == typeof t.extraData)
                    try {
                        n.extraData = JSON.parse(t.extraData)
                    } catch (o) {}
                else
                    n.extraData = t.extraData;
                return n
            }
            ,
            e
        }();
        n.RankPlayerVO = o,
        cc._RF.pop()
    }
    , {}],
    ResManager: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "4c37aufwudM0JrJKsECtJ0l", "ResManager");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        );
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var r = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.prefabMap = {},
                t.spriteFrameMap = {},
                t.spriteAtlasMap = {},
                t.tiledMapAssetMap = {},
                t.dragonBonesAssetMap = {},
                t.texture2DAssetMap = {},
                t.jsonAssetMap = {},
                t.audioClipAssetMap = {},
                t.remoteAssetMap = {},
                t
            }
            return a(t, e),
            t.prototype.load = function(e, t, n) {
                var o = this;
                return cc.loader.load,
                new Promise(function(a, r) {
                    cc.resources.load(e, t, n, function(t, n) {
                        n ? (o.cacheToResMap(n, e),
                        a(n)) : r()
                    })
                }
                )
            }
            ,
            t.prototype.loadArr = function(e, t) {
                var n = this;
                return new Promise(function(o, a) {
                    cc.resources.load(e, t, function(t, r) {
                        if (t)
                            a();
                        else {
                            for (var i = 0; i < r.length; i++) {
                                var s = r[i]
                                  , c = e[i];
                                n.cacheToResMap(s, c)
                            }
                            o(r)
                        }
                    })
                }
                )
            }
            ,
            t.prototype.loadAll = function(e, t) {
                var n = this;
                return new Promise(function(o, a) {
                    cc.loader.loadResDir(e, t, function(e, t, r) {
                        if (e)
                            a();
                        else {
                            for (var i = 0; i < t.length; ++i) {
                                var s = t[i]
                                  , c = r[i];
                                n.cacheToResMap(s, c)
                            }
                            o(t)
                        }
                    })
                }
                )
            }
            ,
            t.prototype.loadAllWithType = function(e, t, n) {
                var o = this;
                return new Promise(function(a, r) {
                    cc.loader.loadResDir(e, t, n, function(e, t, n) {
                        if (e)
                            r();
                        else {
                            if (t.length > 0)
                                for (var i = 0; i < t.length; i++) {
                                    var s = t[i]
                                      , c = n[i];
                                    o.cacheToResMap(s, c)
                                }
                            a(t)
                        }
                    })
                }
                )
            }
            ,
            t.prototype.cacheToResMap = function(e, t) {
                switch (e.constructor) {
                case cc.Prefab:
                    this.prefabMap[t] = e;
                    break;
                case cc.SpriteFrame:
                    this.spriteFrameMap[t] = e;
                    break;
                case cc.SpriteAtlas:
                    this.spriteAtlasMap[t] = e;
                    break;
                case cc.TiledMapAsset:
                    this.tiledMapAssetMap[t] = e;
                    break;
                case cc.Texture2D:
                    this.texture2DAssetMap[t] = e;
                    break;
                case dragonBones.DragonBonesAsset:
                    (this.dragonBonesAssetMap[t] || (this.dragonBonesAssetMap[t] = {})).dragonAsset = e;
                    break;
                case dragonBones.DragonBonesAtlasAsset:
                    (this.dragonBonesAssetMap[t] || (this.dragonBonesAssetMap[t] = {})).dragonAtlasAsset = e;
                    break;
                case cc.JsonAsset:
                    this.jsonAssetMap[t] = e;
                    break;
                case cc.AudioClip:
                    this.audioClipAssetMap[t] = e
                }
            }
            ,
            t.prototype.loadPrefab = function(e, t) {
                return Promise.resolve(this.prefabMap[e] || this.load(e, cc.Prefab, t))
            }
            ,
            t.prototype.loadSpriteFrame = function(e, t) {
                return Promise.resolve(this.spriteFrameMap[e] || this.load(e, cc.SpriteFrame, t))
            }
            ,
            t.prototype.loadSpriteAtlas = function(e, t) {
                return Promise.resolve(this.spriteAtlasMap[e] || this.load(e, cc.SpriteAtlas, t))
            }
            ,
            t.prototype.loadTiledMapAsset = function(e, t) {
                return Promise.resolve(this.tiledMapAssetMap[e] || this.load(e, cc.TiledMapAsset, t))
            }
            ,
            t.prototype.loadDragonBonesAsset = function(e, t) {
                return Promise.resolve(this.dragonBonesAssetMap[e] && this.dragonBonesAssetMap[e].dragonAsset || this.load(e, dragonBones.DragonBonesAsset, t))
            }
            ,
            t.prototype.loadDragonBonesAtlasAsset = function(e, t) {
                return Promise.resolve(this.dragonBonesAssetMap[e] && this.dragonBonesAssetMap[e].dragonAtlasAsset || this.load(e, dragonBones.DragonBonesAtlasAsset, t))
            }
            ,
            t.prototype.loadTexture2DAsset = function(e, t) {
                return Promise.resolve(this.texture2DAssetMap[e] || this.load(e, cc.Texture2D, t))
            }
            ,
            t.prototype.loadJsonAsset = function(e, t) {
                return Promise.resolve(this.jsonAssetMap[e] || this.load(e, cc.JsonAsset, t))
            }
            ,
            t.prototype.loadAudioClipAsset = function(e, t) {
                return Promise.resolve(this.audioClipAssetMap[e] || this.load(e, cc.AudioClip, t))
            }
            ,
            t.prototype.loadCharacterPack = function(e) {
                return Promise.all([this.loadSpriteFrame("character/" + e + "/" + e + "_tex"), this.loadDragonBonesAsset("character/" + e + "/" + e + "_ske"), this.loadDragonBonesAtlasAsset("character/" + e + "/" + e + "_tex")])
            }
            ,
            t.prototype.loadGunPack = function(e) {
                return Promise.all([this.loadSpriteFrame("gun/" + e + "/" + e + "_tex"), this.loadDragonBonesAsset("gun/" + e + "/" + e + "_ske"), this.loadDragonBonesAtlasAsset("gun/" + e + "/" + e + "_tex")])
            }
            ,
            t.prototype.loadRemoteAsset = function(e) {
                var t = this;
                return new Promise(function(n, o) {
                    var a = t.remoteAssetMap[e];
                    a ? n(a) : cc.resources.loadDir(e, function(r, i) {
                        r ? o(r) : (t.remoteAssetMap[e] = a,
                        n(i))
                    })
                }
                )
            }
            ,
            t
        }(e("./Singleton").default);
        n.default = r,
        cc._RF.pop()
    }
    , {
        "./Singleton": "Singleton"
    }],
    SceneManager: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "532b918eNZCm7ibr83Pp8wx", "SceneManager");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        );
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var r = e("../Config/ConfigPreload")
          , i = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.currentSceneName = r.SceneName.Preload,
                t.busy = !1,
                t
            }
            return a(t, e),
            t.prototype.restartScene = function() {
                var e = this;
                return this.busy ? Promise.resolve(cc.director.getScene()) : (this.busy = !0,
                new Promise(function(t) {
                    cc.director.loadScene(e.currentSceneName, function() {
                        e.busy = !1,
                        t(cc.director.getScene()),
                        cc.sys.garbageCollect()
                    })
                }
                ))
            }
            ,
            t.prototype.replaceScene = function(e) {
                var t = this;
                if (!this.busy)
                    return this.busy = !0,
                    new Promise(function(n, o) {
                        t.currentSceneName != e ? (t.currentSceneName = e,
                        cc.director.loadScene(e, function() {
                            cc.log("Enter Scene " + e),
                            t.busy = !1,
                            n(cc.director.getScene()),
                            cc.sys.garbageCollect()
                        }) || (t.busy = !1,
                        o())) : (t.busy = !1,
                        n(cc.director.getScene()))
                    }
                    );
                Promise.resolve(cc.director.getScene())
            }
            ,
            t.prototype.preloadScene = function(e, t) {
                return new Promise(function(n, o) {
                    cc.director.preloadScene(e, t, function(e, t) {
                        t ? n() : o()
                    })
                }
                ).then(function() {
                    return cc.log(e + " Scene preload complete")
                })
            }
            ,
            t
        }(e("./Singleton").default);
        n.default = i,
        cc._RF.pop()
    }
    , {
        "../Config/ConfigPreload": "ConfigPreload",
        "./Singleton": "Singleton"
    }],
    ShareHelper: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "9233ee41NZI8ZsZ4RwNcc18", "ShareHelper");
        var o = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
          , a = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.ShareHelper = void 0;
        var r = e("../../Module/share/B64Images");
        (function(e) {
            e.shareLink = function(e, t) {
                return o(this, void 0, void 0, function() {
                    var n, o, i, s;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            n = platform.getWeeklyHighScore(),
                            o = ["Wow,\xa0it's\xa0real cool.", "My score is " + n + "! Can you do better?", "Let me help you!"],
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 3, , 4]),
                            i = r.B64Images.img_common,
                            console.log("r img done"),
                            [4, platform.shareLinkAsync({
                                image: i,
                                text: o.random(),
                                data: Object.assign({
                                    type: e
                                }, t)
                            })];
                        case 2:
                            return a.sent(),
                            [3, 4];
                        case 3:
                            return s = a.sent(),
                            console.log("update Failed" + JSON.stringify(s)),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            e.invite = function(e, t) {
                return o(this, void 0, void 0, function() {
                    var n, o, i, s;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            n = platform.getWeeklyHighScore(),
                            o = ["Wow,\xa0it's\xa0real cool.", "My score is " + n + "! Can you do better?", "Let me help you!"],
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 3, , 4]),
                            i = r.B64Images.img_common,
                            console.log("r img done"),
                            [4, platform.inviteAsync({
                                image: i,
                                text: o.random(),
                                data: Object.assign({
                                    type: e
                                }, t)
                            })];
                        case 2:
                            return a.sent(),
                            [3, 4];
                        case 3:
                            return s = a.sent(),
                            console.log("update Failed" + JSON.stringify(s)),
                            [3, 4];
                        case 4:
                            return [2]
                        }
                    })
                })
            }
            ,
            e.sendGenericUpdate = function(e, t, n) {
                return void 0 === n && (n = !1),
                o(this, void 0, void 0, function() {
                    var o, i, s, c;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            o = platform.getWeeklyHighScore(),
                            i = ["Wow,\xa0it's\xa0real cool.", "My score is " + o + "! Can you do better?", "Let me help you!"],
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 6, , 7]),
                            s = r.B64Images.img_common,
                            console.log("r img done"),
                            n ? [3, 3] : [4, platform.updateStatues(Object.assign({
                                type: e
                            }, t), {
                                text: i.random(),
                                image: s,
                                cta: "Play",
                                template: e
                            })];
                        case 2:
                            return a.sent(),
                            [3, 5];
                        case 3:
                            return [4, platform.shareAsync({
                                img: s,
                                text: i.random(),
                                cta: "Play",
                                data: Object.assign({
                                    type: e
                                }, t)
                            })];
                        case 4:
                            a.sent(),
                            a.label = 5;
                        case 5:
                            return [3, 7];
                        case 6:
                            return c = a.sent(),
                            console.log("update Failed" + JSON.stringify(c)),
                            [3, 7];
                        case 7:
                            return [2]
                        }
                    })
                })
            }
        }
        )(n.ShareHelper || (n.ShareHelper = {})),
        cc._RF.pop()
    }
    , {
        "../../Module/share/B64Images": "B64Images"
    }],
    ShareImage: [function(e, t) {
        "use strict";
        cc._RF.push(t, "f800bMWmlREvIUULrPZJ3N0", "ShareImage");
        var n, o = this && this.__extends || (n = function(e, t) {
            return (n = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function o() {
                this.constructor = e
            }
            n(e, t),
            e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype,
            new o)
        }
        );
        (function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.UserName = [],
                t.UserID = [],
                t.UserImage = [],
                t.UserScore = [],
                t
            }
            o(t, e),
            t.prototype.CreateImageHead2 = function() {}
        }
        )(cc.Sprite),
        cc._RF.pop()
    }
    , {}],
    Singleton: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "9bccerghMpOBZkzz6LQSV4H", "Singleton"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var o = function() {
            function e() {
                var t = this.constructor;
                if (t) {
                    if (-1 != e.classKeys.indexOf(t))
                        throw new Error(this + " \u53ea\u5141\u8bb8\u5b9e\u4f8b\u5316\u4e00\u6b21\uff01");
                    e.classKeys.push(t),
                    e.classValues.push(this)
                }
            }
            return e.getInstance = function() {
                return this.instance || (this.instance = new this),
                this.instance
            }
            ,
            e.prototype.destroy = function(t) {
                void 0 === t && (t = null),
                this.onDestroy(),
                e.removeInstance(this.constructor)
            }
            ,
            e.prototype.onDestroy = function() {}
            ,
            e.removeInstance = function(e) {
                var t = this.classKeys.indexOf(e);
                if (-1 == t)
                    return null;
                this.classKeys.splice(t, 1),
                this.classValues.splice(t, 1)
            }
            ,
            e.getFunValue = function(e) {
                for (var t = this.classKeys, n = t.length, o = 0; o < n; o++)
                    if (e == t[o])
                        return this.classValues[o];
                return null
            }
            ,
            e.getInstanceOrCreate = function(t) {
                var n = this.getFunValue(t);
                return n || ((n = new t)instanceof e || (this.classKeys.push(t),
                this.classValues.push(n)),
                n)
            }
            ,
            e.classKeys = [],
            e.classValues = [],
            e
        }();
        n.default = o,
        cc._RF.pop()
    }
    , {}],
    Storager: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "ba271K5OwdN9IKmg3VxbB2L", "Storager"),
        Object.defineProperty(n, "__esModule", {
            value: !0
        }),
        n.Storager = void 0;
        var o = function() {
            function e(e) {
                void 0 === e && (e = "global"),
                this.id = e
            }
            return e.prototype.set = function(e, t) {
                "object" == typeof t && (t = JSON.stringify(t)),
                localStorage.setItem(this.id + "_" + e, t)
            }
            ,
            e.prototype.get = function(e, t) {
                return localStorage.getItem(this.id + "_" + e) || t || null
            }
            ,
            e.prototype.rm = function(e) {
                localStorage.removeItem(this.id + "_" + e)
            }
            ,
            e.prototype.json = function(e, t) {
                void 0 === t && (t = null);
                var n, o = localStorage.getItem(this.id + "_" + e);
                try {
                    n = JSON.parse(o)
                } catch (a) {
                    $dev && console.log("json failed")
                }
                return n || t || null
            }
            ,
            e.clear = function() {
                localStorage.clear()
            }
            ,
            e
        }();
        n.Storager = o,
        cc._RF.pop()
    }
    , {}],
    Tournament: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "1af8eJbp7NJW7DRm+LcYTc+", "Tournament");
        var o = this && this.__awaiter || function(e, t, n, o) {
            return new (n || (n = Promise))(function(a, r) {
                function i(e) {
                    try {
                        c(o.next(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function s(e) {
                    try {
                        c(o.throw(e))
                    } catch (t) {
                        r(t)
                    }
                }
                function c(e) {
                    var t;
                    e.done ? a(e.value) : (t = e.value,
                    t instanceof n ? t : new n(function(e) {
                        e(t)
                    }
                    )).then(i, s)
                }
                c((o = o.apply(e, t || [])).next())
            }
            )
        }
          , a = this && this.__generator || function(e, t) {
            var n, o, a, r, i = {
                label: 0,
                sent: function() {
                    if (1 & a[0])
                        throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            };
            return r = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                return this
            }
            ),
            r;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(r) {
                if (n)
                    throw new TypeError("Generator is already executing.");
                for (; i; )
                    try {
                        if (n = 1,
                        o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o),
                        0) : o.next) && !(a = a.call(o, r[1])).done)
                            return a;
                        switch (o = 0,
                        a && (r = [2 & r[0], a.value]),
                        r[0]) {
                        case 0:
                        case 1:
                            a = r;
                            break;
                        case 4:
                            return i.label++,
                            {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            i.label++,
                            o = r[1],
                            r = [0];
                            continue;
                        case 7:
                            r = i.ops.pop(),
                            i.trys.pop();
                            continue;
                        default:
                            if (!(a = (a = i.trys).length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                                i = 0;
                                continue
                            }
                            if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                                i.label = r[1];
                                break
                            }
                            if (6 === r[0] && i.label < a[1]) {
                                i.label = a[1],
                                a = r;
                                break
                            }
                            if (a && i.label < a[2]) {
                                i.label = a[2],
                                i.ops.push(r);
                                break
                            }
                            a[2] && i.ops.pop(),
                            i.trys.pop();
                            continue
                        }
                        r = t.call(e, i)
                    } catch (s) {
                        r = [6, s],
                        o = 0
                    } finally {
                        n = a = 0
                    }
                if (5 & r[0])
                    throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                }
            }
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var r = e("../core/Http")
          , i = e("../core/Storager");
        (function() {
            function e(e, t) {
                this.tm_host = e,
                this.game_id = t,
                this.platform = "instant",
                this.game = "web",
                this._initialized = !1,
                this.TournamentInfo = [],
                this.TournamentReady = !1,
                this.RequestNum = 0,
                this.reqTime = -1,
                this.localDB = new i.Storager("tournament0" + FBInstant.player.getID()),
                this.localData = this.localDB.json("data")
            }
            e.prototype.setFriends = function(e) {
                this.friends = e
            }
            ,
            e.prototype.initializeAsync = function() {
                return o(this, void 0, void 0, function() {
                    var e, t, n, o, r;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            if (this._initialized)
                                return [2];
                            a.label = 1;
                        case 1:
                            return a.trys.push([1, 10, , 11]),
                            this.friends ? [3, 3] : (e = this,
                            [4, FBInstant.player.getConnectedPlayersAsync()]);
                        case 2:
                            e.friends = a.sent(),
                            a.label = 3;
                        case 3:
                            t = 2,
                            a.label = 4;
                        case 4:
                            if (!(t-- > 0))
                                return [3, 9];
                            a.label = 5;
                        case 5:
                            return a.trys.push([5, 7, , 8]),
                            [4, this.fetchTournament()];
                        case 6:
                            return n = a.sent(),
                            this.TournamentInfo = n,
                            console.log(n),
                            [3, 9];
                        case 7:
                            return o = a.sent(),
                            console.log("fetch tournament error", o),
                            [3, 8];
                        case 8:
                            return [3, 4];
                        case 9:
                            return [3, 11];
                        case 10:
                            return r = a.sent(),
                            console.log("tournament initlialize failed:", r),
                            [3, 11];
                        case 11:
                            return [2]
                        }
                    })
                })
            }
            ,
            e.prototype.fetchTournament = function() {
                return o(this, void 0, void 0, function() {
                    var e, t, n, o, i, s, c, l, u, p, d, f, h, m, y;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            return 0,
                            this.RequestNum++,
                            t = -1 == this.reqTime ? 0 : Math.floor(1e3 * this.reqTime),
                            this.localData && console.log("\u8bf7\u6c42\u95f4\u9694\uff1a" + this.reqTime + " \u5269\u4f59\u65f6\u95f4 " + (this.reqTime - Math.floor((Date.now() - this.localData.timestamp) / 1e3))),
                            this.RequestNum > 1 && this.localData && Date.now() - this.localData.timestamp < t ? (e = this.localData.result,
                            console.log("use cache", e),
                            [3, 5]) : [3, 1];
                        case 1:
                            n = this.tm_host + "/player/tournament_request",
                            o = this.friends.map(function(e) {
                                return e.getID()
                            }),
                            i = FBInstant.player.getID(),
                            o.push(i),
                            s = {
                                gameId: this.game_id,
                                game: this.game,
                                userId: i,
                                friendIds: o.toString()
                            },
                            a.label = 2;
                        case 2:
                            return a.trys.push([2, 4, , 5]),
                            l = (c = JSON).parse,
                            [4, (new r.Http).post(n, s)];
                        case 3:
                            if (0 == (e = l.apply(c, [a.sent()])).result)
                                throw "getTournament failed";
                            return console.log("\u8bf7\u6c42\u7ed3\u679c", e),
                            this.reqTime = e.data.reqTime,
                            this.reqTime || (this.reqTime = 12e4),
                            e && 0 != e.data.length && (u = e.data.mine,
                            p = e.data.friend,
                            e = u.concat(p),
                            console.log(e)),
                            this.localData = {
                                timestamp: Date.now(),
                                result: e
                            },
                            this.localDB.set("data", this.localData),
                            [3, 5];
                        case 4:
                            return a.sent(),
                            console.log("tournament load failed"),
                            e = this.localData ? this.localData.result : {
                                data: {}
                            },
                            [3, 5];
                        case 5:
                            if (0 != (d = "{}" == JSON.stringify(e.data) ? [] : e).length && "{}" != JSON.stringify(d.data))
                                for (f = d.map(function(e) {
                                    return e.playersInfo
                                }),
                                h = 0; h < d.length; h++)
                                    for (d[h].playersInfo.sorton("score", !1),
                                    null == d[h].endType && (d[h].endType = !1),
                                    m = 0; m < f[h].length; m++)
                                        y = this.MatchPhoto(f[h][m].userId),
                                        f[h][m].photo = y;
                            return this.TournamentReady = !0,
                            d && 0 != d.length && "{}" != JSON.stringify(d.data) && d.sorton("endTime", !0),
                            [2, d]
                        }
                    })
                })
            }
            ,
            e.prototype.MatchPhoto = function(e) {
                for (var t = 0; t < this.friends.length; t++) {
                    if (e == this.friends[t].getID())
                        return this.friends[t].getPhoto();
                    if (e == platform.UserInfo.id)
                        return platform.UserInfo.photo
                }
                return ""
            }
            ,
            e.prototype.removeTournament = function() {
                return o(this, void 0, void 0, function() {
                    var e, t, n;
                    return a(this, function() {
                        for (e = 0,
                        t = this.TournamentInfo.length,
                        n = 0; n < t; n++)
                            1 == this.TournamentInfo[n - e].endType && (this.TournamentInfo.splice(n - e, 1),
                            e++);
                        return this.localData && (this.localData.result.data = this.TournamentInfo,
                        this.localDB.set("data", JSON.stringify(this.localData))),
                        [2]
                    })
                })
            }
            ,
            e.prototype.setTournamentEnd = function(e) {
                return o(this, void 0, void 0, function() {
                    var t, n, o, i, s, c;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            for (t = 0; t < this.TournamentInfo.length; t++)
                                if (this.TournamentInfo[t].tournamentId == e && 0 == this.TournamentInfo[t].endType) {
                                    this.TournamentInfo[t].endType = !0;
                                    break
                                }
                            return n = this.tm_host + "/player/tournament_end",
                            o = {
                                gameId: this.game_id,
                                platform: this.platform,
                                game: this.game,
                                token: this._token,
                                userId: FBInstant.player.getID(),
                                tournamentId: e,
                                endType: 1
                            },
                            c = (s = JSON).parse,
                            [4, (new r.Http).post(n, o)];
                        case 1:
                            if (i = c.apply(s, [a.sent()]),
                            console.log(i),
                            1 != i.result)
                                throw "update_tournament error";
                            return this.localData && (this.localData.result.data = this.TournamentInfo,
                            this.localDB.set("data", JSON.stringify(this.localData))),
                            [2]
                        }
                    })
                })
            }
            ,
            e.prototype.MatchTournament = function(e) {
                for (var t = null, n = 0; n < this.TournamentInfo.length; n++)
                    if (e == this.TournamentInfo[n].tournamentId)
                        return (t = {}).index = n,
                        t.score = this.TournamentInfo[n].score,
                        t;
                return t
            }
            ,
            e.prototype.setScoreTournament = function(e) {
                return void 0 === e && (e = {}),
                o(this, void 0, void 0, function() {
                    var t, n, o, i, s, c, l, u, p, d, f, h;
                    return a(this, function(a) {
                        switch (a.label) {
                        case 0:
                            if (a.trys.push([0, 2, , 3]),
                            t = FBInstant.player.getID(),
                            n = !1,
                            o = 0,
                            null == (i = this.MatchTournament(e.tournamentId)))
                                (s = {}).gameId = this.game_id,
                                s.score = e.score,
                                s.tournamentId = e.tournamentId,
                                s.rank = 1,
                                s.endTime = e.endTime,
                                s.creatorId = "1",
                                s.playersInfo = [{
                                    userId: t,
                                    score: e.score,
                                    name: FBInstant.player.getName(),
                                    photo: platform.UserInfo.photo
                                }],
                                s.endType = !1,
                                this.TournamentInfo.push(s),
                                this.localData && (this.localData.result.data = this.TournamentInfo,
                                n = !0),
                                o++;
                            else if (e.score > i.score) {
                                for (0 == this.TournamentInfo[i.index].score && (c = {
                                    userId: t,
                                    score: e.score,
                                    name: FBInstant.player.getName(),
                                    photo: platform.UserInfo.photo
                                },
                                this.TournamentInfo[i.index].playersInfo.push(c)),
                                this.TournamentInfo[i.index].score = e.score,
                                l = 0; l < this.TournamentInfo[i.index].playersInfo.length; l++)
                                    if (this.TournamentInfo[i.index].playersInfo[l].userId == t) {
                                        this.TournamentInfo[i.index].playersInfo[l].score = e.score;
                                        break
                                    }
                                this.TournamentInfo[i.index].playersInfo.sorton("score", !1),
                                this.TournamentInfo[i.index].rank = this.TournamentInfo[i.index].playersInfo.findIndex(function(e) {
                                    return e.userId == t
                                }) + 1,
                                this.localData && (this.localData.result.data = this.TournamentInfo,
                                n = !0),
                                o++
                            }
                            return n && this.localDB.set("data", JSON.stringify(this.localData)),
                            0 == o ? [2] : (u = this.tm_host + "/player/tournament_update",
                            p = {
                                gameId: this.game_id,
                                userId: FBInstant.player.getID(),
                                name: FBInstant.player.getName(),
                                tournamentId: e.tournamentId,
                                score: e.score,
                                endTime: e.endTime
                            },
                            h = (f = JSON).parse,
                            [4, (new r.Http).post(u, p)]);
                        case 1:
                            if (d = h.apply(f, [a.sent()]),
                            console.log(d),
                            1 != d.result)
                                throw "update_tournament error";
                            return [3, 3];
                        case 2:
                            return a.sent(),
                            console.log("set core error"),
                            [3, 3];
                        case 3:
                            return [2, 1]
                        }
                    })
                })
            }
            ,
            e.prototype.getTournamentInfo = function() {
                return this.TournamentInfo || []
            }
            ,
            e.prototype.getTournamentReady = function() {
                return this.TournamentReady
            }
        }
        )(),
        cc._RF.pop()
    }
    , {
        "../core/Http": "Http",
        "../core/Storager": "Storager"
    }],
    bgfit: [function(e, t, n) {
        "use strict";
        cc._RF.push(t, "2e843nLC1pBdKsnoHgJRHgX", "bgfit");
        var o, a = this && this.__extends || (o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            )(e, t)
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            o(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), r = this && this.__decorate || function(e, t, n, o) {
            var a, r = arguments.length, i = r < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate)
                i = Reflect.decorate(e, t, n, o);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (a = e[s]) && (i = (r < 3 ? a(i) : r > 3 ? a(t, n, i) : a(t, n)) || i);
            return r > 3 && i && Object.defineProperty(t, n, i),
            i
        }
        ;
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var i = cc._decorator
          , s = i.ccclass
          , c = (i.property,
        function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this
            }
            return a(t, e),
            t.prototype.onLoad = function() {
                var e = Math.min(cc.view.getCanvasSize().width / this.node.width, cc.view.getCanvasSize().height / this.node.height)
                  , t = this.node.width * e
                  , n = this.node.height * e;
                this.node.scale = Math.max(cc.view.getCanvasSize().width / t, cc.view.getCanvasSize().height / n)
            }
            ,
            r([s], t)
        }(cc.Component));
        n.default = c,
        cc._RF.pop()
    }
    , {}],
    "type.t": [function(e, t) {
        "use strict";
        var n;
        cc._RF.push(t, "0df4873R35ABYa19xNlC1NY", "type.t"),
        function(e) {
            (function(e) {
                e[e.startup = 0] = "startup",
                e[e.game_ready = 1] = "game_ready",
                e[e.game_over = 2] = "game_over"
            }
            )(e.Notify || (e.Notify = {})),
            e.context_template = {
                heart: "heart",
                challenge: "challenge",
                challenge_result: "challenge_result",
                auto_choose: "auto_choose",
                skin_invite: "skin_invite",
                home_share: "home_share"
            },
            e.LogEvent = {
                add_home_screen: "add_home_screen",
                game_loading: "game_loading"
            },
            e.SAME_CONTEXT = "SAME_CONTEXT"
        }(n || (n = {})),
        cc._RF.pop()
    }
    , {}]
}, {}, ["FBGameConfig", "Flash", "HeroContact", "NPCCtrl", "NpcContact", "bgfit", "GameConnect", "GameMessage", "GameModule", "App", "ConfigPreload", "Constant", "AudioManager", "BaseUI", "Event", "Manager", "ResManager", "SceneManager", "Singleton", "BusyIndicator", "Emiter", "Extension", "Http", "Storager", "Advertise", "BasePlatform", "FriendLeaderboard", "HttpService", "PlatformDev", "PlatformFB", "PlatformFactory", "RankPlayerVO", "Tournament", "B64Images", "ShareHelper", "ShareImage", "type.t", "GameScene", "PreloadScene", "GameUtils", "GameRank", "GameSetting", "LoadingView"]);
