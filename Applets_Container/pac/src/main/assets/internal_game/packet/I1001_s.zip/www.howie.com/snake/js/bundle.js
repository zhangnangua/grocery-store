!function () {
    this && this.__extends || (Object.setPrototypeOf || Array),
        function e(t, n, i) {
            function o(r, s) {
                if (!n[r]) {
                    if (!t[r]) {
                        var l = "function" == typeof require && require;
                        if (!s && l) return l(r, !0);
                        if (a) return a(r, !0);
                        var c = new Error("Cannot find module '" + r + '""');
                        throw c.code = "MODULE_NOT_FOUND", c
                    }
                    var u = n[r] = {
                        exports: {}
                    };
                    t[r][0].call(u.exports, function (e) {
                        return o(t[r][1][e] || e)
                    }, u, u.exports, e, t, n, i)
                }
                return n[r].exports
            }
            for (var a = "function" == typeof require && require, r = 0; r < i.length; r++) o(i[r]);
            return o
        }({
            1: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.sts = "sts", e.sdate = "sdate", e.coin = "oxy", e.tcoin = "toxy", e.maxCoin = "mcoin", e.diamond = "diam", e.rv = "rv", e.day = "day", e.collectState = "cs", e.gameData = "gd", e.propData = "pd", e.setting = "st", e.skinData = "sk", e.signinData = "sd", e.mergeData = "md", e.lotteryData = "ld", e
                }();
                n.default = i
            }, {}],
            2: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../platform/yt"),
                    o = function () {
                        function e() {}
                        return e.getItem = function (e, t) {
                            return void 0 === t && (t = null), Laya.LocalStorage.getItem(e) || t
                        }, e.getIntItem = function (e, t) {
                            return parseInt(Laya.LocalStorage.getItem(e)) || t
                        }, e.getFloatItem = function (e, t) {
                            return parseFloat(Laya.LocalStorage.getItem(e)) || t
                        }, e.setItem = function (e, t) {
                            i.default.setStorage ? i.default.setStorage({
                                key: e,
                                data: t,
                                success: null,
                                fail: null,
                                complete: null
                            }) : Laya.LocalStorage.setItem(e, t)
                        }, e.removeItem = function (e) {
                            return Laya.LocalStorage.removeItem(e)
                        }, e
                    }();
                n.default = o
            }, {
                "../platform/yt": 63
            }],
            3: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./view/BalloonView"),
                    o = e("./script/ForIPad"),
                    a = e("./script/ScaleBtn"),
                    r = e("./script/NearBanner"),
                    s = e("./script/DialogEffect"),
                    l = e("./script/LoopScale"),
                    c = e("./ads/NativeAds"),
                    u = e("./ads/ExitAds"),
                    d = e("./script/LoopRotation"),
                    h = e("./ads/FullScrollAds"),
                    f = e("./snake_view/GameScene"),
                    p = e("./snake_view/GameScene2d"),
                    _ = e("./snake_view/GameTest"),
                    y = e("./view/GuideView"),
                    g = e("./ads/InsideAds3"),
                    m = e("./merge/MergeAddCoins"),
                    v = e("./merge/MergeItem"),
                    L = e("./merge/MergePnl"),
                    w = e("./merge/MergeCell"),
                    b = e("./ads/MoreAds"),
                    S = e("./ads/NativeBanner"),
                    A = e("./ads/NativeBottom"),
                    I = e("./ads/ScrollAds"),
                    C = e("./view/Toast"),
                    k = e("./view/DiamondAnimation"),
                    M = e("./snake_view/GameLoading"),
                    E = e("./view/GameRankView"),
                    T = e("./view/ReviveView"),
                    D = e("./view/ReviveView1"),
                    O = e("./view/RingProgress"),
                    P = e("./view/ScoreView"),
                    x = e("./view/GoldAnimation"),
                    B = e("./view/LoadingView"),
                    R = e("./view/LobbyView"),
                    N = e("./script/LoopMove"),
                    G = e("./view/MatchView"),
                    U = e("./view/SkinView"),
                    V = e("./view/SignView"),
                    F = e("./view/RankView"),
                    H = e("./view/RewardView"),
                    j = e("./view/LobbySettingView"),
                    W = e("./view/ShopView"),
                    Y = e("./view/SkinAnimation"),
                    K = e("./view/TestView"),
                    z = e("./view/LotteryView"),
                    q = function () {
                        function e() {}
                        return e.init = function () {
                            var e = Laya.ClassUtils.regClass;
                            e("view/BalloonView.ts", i.default), e("script/ForIPad.ts", o.default), e("script/ScaleBtn.ts", a.default), e("script/NearBanner.ts", r.default), e("script/DialogEffect.ts", s.default), e("script/LoopScale.ts", l.default), e("ads/NativeAds.ts", c.default), e("ads/ExitAds.ts", u.default), e("script/LoopRotation.ts", d.default), e("ads/FullScrollAds.ts", h.default), e("snake_view/GameScene.ts", f.default), e("snake_view/GameScene2d.ts", p.default), e("snake_view/GameTest.ts", _.default), e("view/GuideView.ts", y.default), e("ads/InsideAds3.ts", g.default), e("merge/MergeAddCoins.ts", m.default), e("merge/MergeItem.ts", v.default), e("merge/MergePnl.ts", L.default), e("merge/MergeCell.ts", w.default), e("ads/MoreAds.ts", b.default), e("ads/NativeBanner.ts", S.default), e("ads/NativeBottom.ts", A.default), e("ads/ScrollAds.ts", I.default), e("view/Toast.ts", C.default), e("view/DiamondAnimation.ts", k.default), e("snake_view/GameLoading.ts", M.default), e("view/GameRankView.ts", E.default), e("view/ReviveView.ts", T.default), e("view/ReviveView1.ts", D.default), e("view/RingProgress.ts", O.default), e("view/ScoreView.ts", P.default), e("view/GoldAnimation.ts", x.default), e("view/LoadingView.ts", B.default), e("view/LobbyView.ts", R.default), e("script/LoopMove.ts", N.default), e("view/MatchView.ts", G.default), e("view/SkinView.ts", U.default), e("view/SignView.ts", V.default), e("view/RankView.ts", F.default), e("view/RewardView.ts", H.default), e("view/LobbySettingView.ts", j.default), e("view/ShopView.ts", W.default), e("view/SkinAnimation.ts", Y.default), e("view/TestView.ts", K.default), e("view/LotteryView.ts", z.default)
                        }, e.width = 720, e.height = 1280, e.scaleMode = "fixedwidth", e.screenMode = "vertical", e.alignV = "middle", e.alignH = "center", e.startScene = "view/loading.scene", e.sceneRoot = "", e.debug = !1, e.stat = !1, e.physicsDebug = !1, e.exportSceneToJson = !0, e
                    }();
                n.default = q, q.init()
            }, {
                "./ads/ExitAds": 6,
                "./ads/FullScrollAds": 7,
                "./ads/InsideAds3": 9,
                "./ads/MoreAds": 10,
                "./ads/NativeAds": 11,
                "./ads/NativeBanner": 12,
                "./ads/NativeBottom": 13,
                "./ads/ScrollAds": 14,
                "./merge/MergeAddCoins": 49,
                "./merge/MergeCell": 50,
                "./merge/MergeItem": 51,
                "./merge/MergePnl": 52,
                "./script/DialogEffect": 64,
                "./script/ForIPad": 65,
                "./script/LoopMove": 66,
                "./script/LoopRotation": 67,
                "./script/LoopScale": 68,
                "./script/NearBanner": 69,
                "./script/ScaleBtn": 70,
                "./snake_view/GameLoading": 89,
                "./snake_view/GameScene": 90,
                "./snake_view/GameScene2d": 91,
                "./snake_view/GameTest": 93,
                "./view/BalloonView": 98,
                "./view/DiamondAnimation": 99,
                "./view/GameRankView": 100,
                "./view/GoldAnimation": 101,
                "./view/GuideView": 103,
                "./view/LoadingView": 104,
                "./view/LobbySettingView": 105,
                "./view/LobbyView": 106,
                "./view/LotteryView": 107,
                "./view/MatchView": 108,
                "./view/RankView": 110,
                "./view/ReviveView": 111,
                "./view/ReviveView1": 112,
                "./view/RewardView": 113,
                "./view/RingProgress": 114,
                "./view/ScoreView": 115,
                "./view/ShopView": 116,
                "./view/SignView": 117,
                "./view/SkinAnimation": 118,
                "./view/SkinView": 119,
                "./view/TestView": 120,
                "./view/Toast": 121
            }],
            4: [function (e, t, n) {
                "use strict";
                var i = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    o = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("./GameConfig");
                new(function () {
                    function e() {
                        window.Laya3D ? Laya3D.init(a.default.width, a.default.height) : Laya.init(a.default.width, a.default.height, Laya.WebGL), Laya.Physics && Laya.Physics.enable(), Laya.DebugPanel && Laya.DebugPanel.enable(), Laya.stage.scaleMode = a.default.scaleMode, Laya.stage.screenMode = a.default.screenMode, Laya.URL.exportSceneToJson = a.default.exportSceneToJson, (a.default.debug || "true" == Laya.Utils.getQueryString("debug")) && Laya.enableDebugPanel(), a.default.physicsDebug && Laya.PhysicsDebugDraw && Laya.PhysicsDebugDraw.enable(), a.default.stat && Laya.Stat.show(0, .6 * window.innerHeight), Laya.alertGlobalError = !1, Laya.ResourceVersion.enable("version.json", Laya.Handler.create(this, this.onVersionLoaded), Laya.ResourceVersion.FILENAME_VERSION)
                    }
                    return e.prototype.onVersionLoaded = function () {
                        Laya.AtlasInfoManager.enable("fileconfig.json", Laya.Handler.create(this, this.onConfigLoaded))
                    }, e.prototype.onConfigLoaded = function () {
                        YYGGames.init("Merge-Snake-Battle", () => {
                            return  !Laya.LocalStorage.getItem("Merge-Snake-Battle-LastDay") && Laya.LocalStorage.setItem("Merge-Snake-Battle-LastDay", "99"), window.isGuided = !1, i(this, void 0, void 0, function () {
                                return o(this, function (e) {
                                    return Laya.Scene.open(a.default.startScene), [2]
                                })
                            })
                        })
                    }, e
                }())
            }, {
                "./GameConfig": 3
            }],
            5: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../common/EventID"),
                    o = e("../core/MathUtil"),
                    a = e("../platform/yt"),
                    r = e("../core/Server"),
                    s = function () {
                        function e() {
                            this.list = [], this.clickedAdsList = []
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.init = function () {
                            a.default.on(a.default.Event.InsideAdsLoaded, this._onDataChanged, this)
                        }, e.prototype.getRandomOne = function () {
                            return this.isValid() ? this.getRandomList()[0] : null
                        }, e.prototype.getRandomList = function () {
                            if (!this.isValid()) return [];
                            var e = this.list.slice(0);
                            return o.default.shuffle(e), e.sort(function (e, t) {
                                return e.redPoint.visible ? -1 : t.redPoint.visible ? 1 : 0
                            }), e
                        }, e.prototype.getFixedList = function () {
                            return this.isValid() ? this.list.slice(0) : []
                        }, e.prototype.isValid = function () {
                            var e = a.default.getLaunchOptionsSync();
                            if (e) {
                                var t = e.scene;
                                if ([1011, 1012, 1023, 1025, 1031, 1032, 1047, 1048, 1049, 1072].indexOf(t) > -1) return !1
                            }
                            return 0 != this.list.length
                        }, e.prototype._onDataChanged = function () {
                            var e = this;
                            if (a.default.supportLogin && a.default.insideAds.length > 0 || a.default.isBrowser) {
                                var t = void 0;
                                t = a.default.isBrowser ? [] : a.default.insideAds, this.list = t.map(function (t) {
                                    return {
                                        id: t.id,
                                        app_id: t.app_id,
                                        app_path: t.app_path,
                                        qrcode_flag: t.qrcode_flag,
                                        qrcode_url: t.qrcode_url,
                                        icon: {
                                            skin: t.icon
                                        },
                                        nameLbl: {
                                            text: t.name
                                        },
                                        playNumLbl: {
                                            text: e.getPlayNum(t)
                                        },
                                        redPoint: {
                                            visible: e.isNewAdsItem(t)
                                        }
                                    }
                                })
                            } else this.list = []
                        }, e.prototype.getAdsKey = function (e) {
                            return e.app_id + e.app_path
                        }, e.prototype.isNewAdsItem = function (e) {
                            var t = this.getAdsKey(e);
                            return -1 == this.clickedAdsList.indexOf(t)
                        }, e.prototype.getPlayNum = function (e) {
                            for (var t = this.getAdsKey(e), n = e.id, i = 2; i < t.length; ++i) n += t.charCodeAt(i);
                            var a = o.default.FixRand.randBySeed(n);
                            return Math.floor(50 * a) + 40 + "万人在玩"
                        }, e.prototype.setAdsItemClicked = function (e) {
                            if (this.isNewAdsItem(e)) {
                                var t = this.getAdsKey(e);
                                return this.clickedAdsList.push(t), this.saveClickedAdsList(), this._onDataChanged(), Laya.stage.event(i.default.INSIDE_ADS_CLICKED), !0
                            }
                            return !1
                        }, e.prototype.loadClickedAdsList = function () {
                            var e = Laya.LocalStorage.getItem("inAdsList");
                            this.clickedAdsList = e ? e.split(",") : [], this._onDataChanged()
                        }, e.prototype.saveClickedAdsList = function () {
                            Laya.LocalStorage.setItem("inAdsList", this.clickedAdsList.join(","))
                        }, e.prototype.clearClickedAdsList = function () {
                            this.clickedAdsList = [], this.saveClickedAdsList()
                        }, e.prototype.showAds = function (t, n, i, o, s) {
                            t && (1 == t.qrcode_flag ? a.default.previewImage && a.default.previewImage({
                                urls: [t.qrcode_url],
                                success: function () {
                                    r.default.reportEvent(t.id, n), o && o()
                                }
                            }) : a.default.navToMiniGame && a.default.navToMiniGame({
                                appId: t.app_id,
                                path: t.app_path,
                                success: function () {
                                    r.default.reportEvent(t.id, i), o && o()
                                },
                                fail: function () {
                                    s && s()
                                }
                            }), e.instance.setAdsItemClicked(t))
                        }, e._instance = null, e
                    }();
                n.default = s
            }, {
                "../common/EventID": 15,
                "../core/MathUtil": 24,
                "../core/Server": 28,
                "../platform/yt": 63
            }],
            6: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("../ui/layaMaxUI"),
                    l = e("../core/GameHelper"),
                    c = (e("./AdsLogic"), e("../script/DialogEffect")),
                    u = e("../sound/SoundMgr"),
                    d = e("../sound/SoundID"),
                    h = e("../data/DataBus"),
                    f = e("../common/EventID"),
                    p = (e("./MoreAds"), function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t._showAds(), t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this._setBtnsEnabled(!0), Laya.stage.on(f.default.INSIDE_ADS_CLICKED, this, this._updateBadage)
                        }, t.prototype._setBtnsEnabled = function (e) {
                            void 0 === e && (e = !0), this._btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnExit.off(Laya.Event.CLICK, this, this._onBtnExitClick), e && (this._btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnExit.on(Laya.Event.CLICK, this, this._onBtnExitClick))
                        }, t.prototype.onOpened = function (e) {
                            e && e.isExit && (this._btnExit.visible = !0), l.default.addBannerStatus(this, !1), Laya.timer.frameLoop(420, this, this._showAds)
                        }, t.prototype._onRemoved = function () {
                            Laya.timer.clearAll(this), l.default.removeBannerStatus(this), Laya.stage.off(f.default.INSIDE_ADS_CLICKED, this, this._updateBadage), e.prototype._onRemoved.call(this), Laya.timer.clear(this, this._showAds)
                        }, t.prototype._showAds = function () {}, t.prototype._onBtnCloseClick = function () {
                            u.default.instance.playSound(d.default.ButtonTap), this.removeSelf()
                        }, t.prototype._onBtnExitClick = function () {
                            return a(this, void 0, void 0, function () {
                                return r(this, function (e) {
                                    switch (e.label) {
                                        case 0:
                                            return [4, h.default.instance.SaveDataToServer()];
                                        case 1:
                                            return e.sent(), [4, h.default.instance.SaveLocalData()];
                                        case 2:
                                            return e.sent(), Laya.MiniAdpter.exitMiniProgram(), [2]
                                    }
                                })
                            })
                        }, t.prototype._updateBadage = function () {}, t.prototype._replayPopAnimation = function () {
                            this._dialog.getComponent(c.default).play()
                        }, t
                    }(s.ui.view.ExitAdsUI));
                n.default = p
            }, {
                "../common/EventID": 15,
                "../core/GameHelper": 23,
                "../data/DataBus": 32,
                "../script/DialogEffect": 64,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./AdsLogic": 5,
                "./MoreAds": 10
            }],
            7: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/GameHelper"),
                    s = e("./AdsLogic"),
                    l = e("../sound/SoundMgr"),
                    c = e("../sound/SoundID"),
                    u = e("./MoreAds"),
                    d = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.closeCallback = null, t.homeCallback = null, t._dir = 2, t.colNum = 2, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t._showAds(), t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this._setBtnsEnabled(!0)
                        }, t.prototype._setBtnsEnabled = function (e) {
                            void 0 === e && (e = !0), this.btnHome.off(Laya.Event.CLICK, this, this.onBtnHomeClick), this._btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), e && (this.btnHome.on(Laya.Event.CLICK, this, this.onBtnHomeClick), this._btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick))
                        }, t.prototype.onOpened = function (e) {
                            var t = this;
                            e && (e.delay && (this._btnClose.visible = !1, Laya.timer.once(e.delay, this, function () {
                                t._btnClose.visible = !0
                            })), e.closeCallback && (this.closeCallback = e.closeCallback), e.homeCallback && (this.homeCallback = e.homeCallback)), r.default.addBannerStatus(this, !1)
                        }, t.prototype._onRemoved = function () {
                            console.log("移除"), Laya.timer.clearAll(this), r.default.removeBannerStatus(this), e.prototype._onRemoved.call(this)
                        }, t.prototype._showAds = function () {
                            var e = this,
                                t = s.default.instance.getRandomList();
                            this.adList.array = t, this._startScrollAction(), this.adList.mouseHandler = new Laya.Handler(this, function (n, i) {
                                if (n.type == Laya.Event.CLICK) {
                                    var o = t[i];
                                    s.default.instance.showAds(o, "get_list_friend_scan", "get_list_friend", function () {}, function () {
                                        u.default.tryToShow()
                                    }), n.currentTarget.mouseEnabled = !1, Laya.timer.once(1e3, n.currentTarget, function () {
                                        this.mouseEnabled = !0
                                    })
                                } else n.type != Laya.Event.MOUSE_UP && n.type != Laya.Event.MOUSE_OUT || (Laya.timer.clear(e, e._scroll), Laya.timer.once(500, e, e._scroll))
                            })
                        }, t.prototype._onBtnCloseClick = function () {
                            l.default.instance.playSound(c.default.ButtonTap), this.closeCallback && this.closeCallback(), this.removeSelf()
                        }, t.prototype.onBtnHomeClick = function () {
                            l.default.instance.playSound(c.default.ButtonTap), this.homeCallback && this.homeCallback(), this.removeSelf()
                        }, t.prototype._startScrollAction = function () {
                            Laya.timer.once(500, this, this._scroll)
                        }, t.prototype._scroll = function () {
                            var e = this.adList.array.length;
                            if (!(e <= 0) && this.adList.scrollBar) {
                                e = Math.ceil(e / this.colNum);
                                var t = this.adList.itemRender.props.height,
                                    n = t * e + this.adList.spaceY * (e - 1) - this.adList.height,
                                    i = this.adList.scrollBar.value;
                                i <= .1 * t ? this._dir = this.colNum : i >= n - .1 * t && (this._dir = -this.colNum);
                                var o = this.adList.startIndex + this._dir;
                                o = Math.max(0, Math.min(this.adList.array.length - 1, o)), this.adList.tweenTo(o, 4e3, Laya.Handler.create(this, this._scroll))
                            }
                        }, t
                    }(a.ui.view.FullScrollAdsUI);
                n.default = d
            }, {
                "../core/GameHelper": 23,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./AdsLogic": 5,
                "./MoreAds": 10
            }],
            8: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../common/EventID"),
                    r = e("../script/ScaleBtn"),
                    s = e("../ads/AdsLogic"),
                    l = e("./MoreAds"),
                    c = e("../platform/yt"),
                    u = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._isShowMore = !1, t.items = [], t.list = [], t._init(), t
                        }
                        return o(t, e), Object.defineProperty(t, "instance", {
                            get: function () {
                                return t._instance || (t._instance = new t), t._instance
                            },
                            enumerable: !0,
                            configurable: !0
                        }), t.prototype._init = function () {
                            this.y = 360;
                            var e = Math.min(Laya.stage.height / 1280, 1);
                            this.scale(e, e), this._mask = new Laya.Image, this._mask.width = Laya.stage.width, this._mask.height = Laya.stage.height, this._mask.alpha = .3, this._mask.skin = "ads/ads_singleColor.png", this.showMore = new Laya.Image, this.showMore.skin = "ads/ads_btn.png", this.showMore.y = 50, this.addChild(this.showMore), this.arrow = new Laya.Image, this.arrow.pivotX = 17, this.arrow.skin = "ads/ads_arrow.png", this.arrow.x = 45, this.arrow.y = 15, this.showMore.addChild(this.arrow), this._bigRedPoint = new Laya.Image, this._bigRedPoint.skin = "ads/ads_red1.png", this._bigRedPoint.x = 50, this._bigRedPoint.y = -10, this.bg = new Laya.Image, this.bg.sizeGrid = "80,80,80,0", this.bg.skin = "ads/ads_bg.png", this.bg.height = 600, this.addChild(this.bg), this.content = new Laya.List, this.content.x = 20, this.content.y = 30, this.content.width = 480, this.content.height = 540, this.content.vScrollBarSkin = "", this.content.itemRender = d, this.content.elasticEnabled = !0, this.content.mouseEnabled = !0, this.content.mouseHandler = new Laya.Handler(this, this.onItemClick), this.bg.addChild(this.content), this.title = new Laya.Image, this.title.skin = "ads/ads_title.png";
                            var t = this.title.scaleX = this.title.scaleY = .6;
                            this.title.x = .5 * (500 - 212 * t), this.title.y = -25 * t, this.bg.addChild(this.title), this._onDataChanged(), Laya.stage.on(a.default.INSIDE_ADS_CHANGED, this, this._onDataChanged), Laya.stage.on(a.default.INSIDE_ADS_CLICKED, this, this._onDataClicked), this.initAni()
                        }, t.prototype.onItemClick = function (e, t) {
                            if (e.type == Laya.Event.CLICK) {
                                var n = this.list[t];
                                s.default.instance.showAds(n, "get_list_scan", "get_list", function () {}, function () {
                                    l.default.tryToShow()
                                }), e.currentTarget.mouseEnabled = !1, Laya.timer.once(1e3, e.currentTarget, function () {
                                    this.mouseEnabled = !0
                                })
                            }
                        }, t.prototype.addEvents = function () {
                            this.showMore.off(Laya.Event.CLICK, this, this._switchMoreState), this._mask.off(Laya.Event.CLICK, this, this._playHideMoreAni), this.showMore.on(Laya.Event.CLICK, this, this._switchMoreState), this._mask.on(Laya.Event.CLICK, this, this._playHideMoreAni)
                        }, t.prototype.removeEvents = function () {
                            this.showMore.off(Laya.Event.CLICK, this, this._switchMoreState), this._mask.off(Laya.Event.CLICK, this, this._hideMore), Laya.timer.clear(this, this._showMore), Laya.timer.clear(this, this._hideMore)
                        }, t.prototype._onRemoved = function () {
                            this.hide(), Laya.stage.off(a.default.INSIDE_ADS_CHANGED, this, this._onDataChanged), Laya.stage.off(a.default.INSIDE_ADS_CLICKED, this, this._onDataClicked), e.prototype._onRemoved.call(this)
                        }, t.prototype.initAni = function () {
                            this.timeline = new Laya.TimeLine, this.showMore.scale(1, 1), this.timeline.to(this.showMore, {
                                scaleX: 1.1,
                                scaleY: 1.1
                            }, 1e3).to(this.showMore, {
                                scaleX: 1,
                                scaleY: 1
                            }, 1e3), this.timeline.play(null, !0)
                        }, t.prototype._onDataChanged = function () {
                            if (c.default.insideAds.length > 0 || c.default.isBrowser) {
                                var e = c.default.insideAds;
                                this.list = e.map(function (e) {
                                    return {
                                        id: e.id,
                                        app_id: e.app_id,
                                        app_path: e.app_path,
                                        qrcode_flag: e.qrcode_flag,
                                        qrcode_url: e.qrcode_url,
                                        icon: {
                                            skin: e.icon
                                        },
                                        nameLbl: {
                                            text: e.name
                                        },
                                        redPoint: {
                                            visible: s.default.instance.isNewAdsItem(e)
                                        }
                                    }
                                }), this.content.array = this.list, this.visible = !0
                            } else this.list = [], this.content.array = this.list, this.visible = !1;
                            this.checkRedShow()
                        }, t.prototype._onDataClicked = function () {
                            if (c.default.insideAds.length > 0 || c.default.isBrowser) {
                                var e = c.default.insideAds;
                                this.list = e.map(function (e) {
                                    return {
                                        id: e.id,
                                        app_id: e.app_id,
                                        app_path: e.app_path,
                                        qrcode_flag: e.qrcode_flag,
                                        qrcode_url: e.qrcode_url,
                                        icon: {
                                            skin: e.icon
                                        },
                                        nameLbl: {
                                            text: e.name
                                        },
                                        redPoint: {
                                            visible: s.default.instance.isNewAdsItem(e)
                                        }
                                    }
                                }), this.content.array = this.list
                            } else this.list = [], this.content.array = this.list;
                            this.checkRedShow()
                        }, t.prototype._switchMoreState = function () {
                            this._isShowMore ? this._playHideMoreAni() : this._playShowMoreAni()
                        }, t.prototype._showMore = function () {
                            this.visible && (this.arrow.scaleX = -1)
                        }, t.prototype._hideMore = function () {
                            this.visible && (this.arrow.scaleX = 1, this._mask.removeSelf(), this.bg.visible = !1, this.timeline.resume(), this.checkRedShow())
                        }, t.prototype._playShowMoreAni = function () {
                            this._isShowMore = !0, this.parent.addChildAt(this._mask, this.parent.getChildIndex(this)), this.timeline.pause(), this._bigRedPoint.removeSelf(), Laya.Tween.clearTween(this.bg), Laya.Tween.clearTween(this.showMore), Laya.Tween.clearTween(this._mask), this.bg.visible = !0, this.bg.x = -this.bg.width, this._mask.alpha = 0, Laya.Tween.to(this.bg, {
                                x: 0
                            }, 300), Laya.Tween.to(this.showMore, {
                                x: 500
                            }, 300), Laya.Tween.to(this._mask, {
                                alpha: .3
                            }, 300), Laya.timer.once(300, this, this._showMore)
                        }, t.prototype._playHideMoreAni = function () {
                            this._isShowMore = !1, Laya.Tween.clearTween(this.bg), Laya.Tween.clearTween(this.showMore), Laya.Tween.clearTween(this._mask), Laya.Tween.to(this.bg, {
                                x: -this.bg.width
                            }, 300), Laya.Tween.to(this.showMore, {
                                x: 0
                            }, 300), Laya.Tween.to(this._mask, {
                                alpha: 0
                            }, 300), Laya.timer.once(300, this, this._hideMore)
                        }, t.prototype.show = function () {
                            s.default.instance.isValid() && (this.parent || Laya.stage.addChild(this), this.addEvents(), this.visible = !0, this.showMore.x = 0, this._hideMore())
                        }, t.prototype.hide = function () {
                            this._hideMore(), this.removeEvents(), this.visible = !1
                        }, t.prototype.checkRedShow = function () {
                            for (var e = 0; e < this.list.length; e++)
                                if (s.default.instance.isNewAdsItem(this.list[e])) return void this.showMore.addChild(this._bigRedPoint);
                            this._bigRedPoint.removeSelf()
                        }, t
                    }(Laya.Sprite);
                n.default = u;
                var d = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t._init(), t
                    }
                    return o(t, e), t.prototype._init = function () {
                        this.width = 120, this.height = 150, this.x = this.pivotX = .5 * this.width, this.y = this.pivotY = .5 * this.height;
                        var e = new Laya.Image;
                        e.name = "icon", e.x = 5, e.y = 15, e.width = 92, e.height = 93, this.addChild(e);
                        var t = new Laya.Image;
                        t.y = 10, t.skin = "ads/ads_kuang.png", this.addChild(t);
                        var n = new Laya.Label;
                        n.name = "nameLbl", n.color = "#FFFFFF", n.x = 0, n.y = 112, n.width = 100, n.height = 30, n.valign = Laya.Stage.ALIGN_MIDDLE, n.align = Laya.Stage.ALIGN_CENTER, n.overflow = "hidden", n.fontSize = 20, this.addChild(n);
                        var i = new Laya.Image;
                        i.name = "redPoint", i.skin = "ads/ads_red.png", i.x = 80, i.y = 0, this.addChild(i), this.addComponent(r.default).zoom = .95
                    }, t
                }(Laya.Box)
            }, {
                "../ads/AdsLogic": 5,
                "../common/EventID": 15,
                "../platform/yt": 63,
                "../script/ScaleBtn": 70,
                "./MoreAds": 10
            }],
            9: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("./AdsLogic"),
                    s = e("./MoreAds"),
                    l = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._pnl = t.getChildByName("pnl"), t._list = t._pnl.getChildByName("list"), t._init(), t
                        }
                        return o(t, e), t.prototype.isVisible = function () {
                            return this._pnl.visible
                        }, t.prototype._init = function () {
                            var e = r.default.instance.getRandomList();
                            e.length > 8 && (e.length = 8), e.length > 0 ? (this._pnl.visible = !0, this._list.array = e) : this._pnl.visible = !1, this._list.mouseHandler = new Laya.Handler(this, this._onListTouch)
                        }, t.prototype._onRemoved = function () {
                            e.prototype._onRemoved.call(this)
                        }, t.prototype._onListTouch = function (e, t) {
                            if (e.type == Laya.Event.CLICK) {
                                var n = this._list.array[t];
                                r.default.instance.showAds(n, "get_list_friend_scan", "get_list_friend", function () {}, function () {
                                    s.default.tryToShow()
                                }), e.currentTarget.mouseEnabled = !1, Laya.timer.once(1e3, e.currentTarget, function () {
                                    this.mouseEnabled = !0
                                })
                            }
                        }, t
                    }(a.ui.view.InsideAds3UI);
                n.default = l
            }, {
                "../ui/layaMaxUI": 97,
                "./AdsLogic": 5,
                "./MoreAds": 10
            }],
            10: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../sound/SoundID"),
                    s = (e("../core/Server"), e("../sound/SoundMgr")),
                    l = e("../common/SceneID"),
                    c = e("../ads/AdsLogic"),
                    u = e("../logic/DialogLogic"),
                    d = e("../core/GameHelper"),
                    h = e("./InsideAds"),
                    f = e("../common/EventID"),
                    p = e("../script/DialogEffect"),
                    _ = (e("../common/ReportEventID"), e("../platform/yt")),
                    y = function (e) {
                        function t() {
                            var n = e.call(this) || this;
                            return n.size(Laya.stage.width, Laya.stage.height), n.bg.size(Laya.stage.width, Laya.stage.height), n._showAds(), n.AddEvents(), t._instance = n, n
                        }
                        return o(t, e), t.tryToShow = function () {
                            1 == parseInt(_.default.conf.show_1m) && !t._instance && c.default.instance.isValid() && u.default.instance.showDialog(l.default.MoreAds)
                        }, t.prototype.AddEvents = function () {
                            this._setBtnsEnabled(!0), Laya.stage.on(f.default.INSIDE_ADS_CLICKED, this, this._updateBadage)
                        }, t.prototype.onOpened = function () {
                            d.default.addBannerStatus(this, !1), h.default.instance.hide()
                        }, t.prototype._onRemoved = function () {
                            t._instance = null, Laya.timer.clearAll(this), d.default.removeBannerStatus(this), Laya.stage.off(f.default.INSIDE_ADS_CLICKED, this, this._updateBadage), e.prototype._onRemoved.call(this)
                        }, t.prototype._showAds = function () {}, t.prototype._updateBadage = function () {}, t.prototype._setBtnsEnabled = function (e) {
                            void 0 === e && (e = !0), this._btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), e && this._btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick)
                        }, t.prototype._onBtnCloseClick = function () {
                            s.default.instance.playSound(r.default.ButtonTap), this.removeSelf()
                        }, t.prototype._replayPopAnimation = function () {
                            this._dialog.getComponent(p.default).play()
                        }, t._instance = null, t
                    }(a.ui.view.MoreAdsUI);
                n.default = y
            }, {
                "../ads/AdsLogic": 5,
                "../common/EventID": 15,
                "../common/ReportEventID": 16,
                "../common/SceneID": 17,
                "../core/GameHelper": 23,
                "../core/Server": 28,
                "../logic/DialogLogic": 42,
                "../platform/yt": 63,
                "../script/DialogEffect": 64,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./InsideAds": 8
            }],
            11: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../platform/yt"),
                    r = e("../sound/SoundID"),
                    s = e("../sound/SoundMgr"),
                    l = function (e) {
                        function t() {
                            var t = null !== e && e.apply(this, arguments) || this;
                            return t.bg = null, t.closeBtn = null, t.iconSp = null, t.imgSp = null, t.titleLbl = null, t.descLbl = null, t.btnLbl = null, t.openBtn = null, t
                        }
                        return o(t, e), t.prototype.onStart = function () {
                            var e = this,
                                t = this.owner;
                            this.bg = t.getChildByName("bg"), this.closeBtn = t.getChildByName("close"), this.iconSp = t.getChildByName("icon"), this.imgSp = t.getChildByName("img"), this.titleLbl = t.getChildByName("title"), this.descLbl = t.getChildByName("desc"), this.openBtn = t.getChildByName("open"), this.btnLbl = this.openBtn && this.openBtn.getChildByName("lbl"), this._setBtnsEnabled(!0), t.visible = t.active = !1, a.default.getNativeAdData && a.default.getNativeAdData(function (t) {
                                e.destroyed || e.setData(t)
                            })
                        }, t.prototype._setBtnsEnabled = function (e) {
                            void 0 === e && (e = !0), this.bg.off(Laya.Event.CLICK, this, this.onBtnOpenClick),
                                this.openBtn.off(Laya.Event.CLICK, this, this.onBtnOpenClick), this.closeBtn.off(Laya.Event.CLICK, this, this.onBtnCloseClick), e && (this.bg.on(Laya.Event.CLICK, this, this.onBtnOpenClick), this.openBtn.on(Laya.Event.CLICK, this, this.onBtnOpenClick), this.closeBtn.on(Laya.Event.CLICK, this, this.onBtnCloseClick))
                        }, t.prototype.setData = function (e) {
                            this._data = e, this._updateDisplay();
                            var t = this.owner;
                            e && t.visible && a.default.reportAdShow && a.default.reportAdShow(e.adId)
                        }, t.prototype._updateDisplay = function () {
                            var e = this.owner,
                                t = this._data;
                            e.visible = e.active = !!t, t && (this.imgSp && (this.imgSp.skin = t.imgUrlList[0]), this.iconSp && (this.iconSp.skin = t.icon), this.titleLbl && (this.titleLbl.text = t.title || ""), this.descLbl && (this.descLbl.text = t.desc || ""), this.btnLbl && (this.btnLbl.text = t.clickBtnTxt || "查看广告"))
                        }, t.prototype.onBtnCloseClick = function () {
                            s.default.instance.playSound(r.default.ButtonTap), this.owner.destroy(!0)
                        }, t.prototype.onBtnOpenClick = function () {
                            s.default.instance.playSound(r.default.ButtonTap);
                            var e = this._data;
                            e && a.default.reportAdClick && a.default.reportAdClick(e.adId)
                        }, t
                    }(Laya.Script);
                n.default = l
            }, {
                "../platform/yt": 63,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96
            }],
            12: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return o(t, e), t
                }(e("../ui/layaMaxUI").ui.view.NativeBanner_UI);
                n.default = a
            }, {
                "../ui/layaMaxUI": 97
            }],
            13: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return o(t, e), t
                }(e("../ui/layaMaxUI").ui.view.NativeBottom_UI);
                n.default = a
            }, {
                "../ui/layaMaxUI": 97
            }],
            14: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("./AdsLogic"),
                    s = e("./MoreAds"),
                    l = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._dir = 1, t._pnl = t.getChildByName("pnl"), t._list = t._pnl.getChildByName("list"), t._init(), t
                        }
                        return o(t, e), t.prototype.isVisible = function () {
                            return this._pnl.visible
                        }, t.prototype._init = function () {
                            var e = r.default.instance.getRandomList();
                            e.length > 8 && (e.length = 8), e.length > 0 ? (this._pnl.visible = !0, this._list.array = e, this._startScrollAction()) : this._pnl.visible = !1, this._list.mouseHandler = new Laya.Handler(this, this._onListTouch)
                        }, t.prototype._onRemoved = function () {
                            this._stopScrollAction(), e.prototype._onRemoved.call(this)
                        }, t.prototype._onListTouch = function (e, t) {
                            if (e.type == Laya.Event.MOUSE_DOWN) this._stopScrollAction();
                            else if (e.type == Laya.Event.MOUSE_UP || e.type == Laya.Event.MOUSE_OUT) this._startScrollAction();
                            else if (e.type == Laya.Event.CLICK) {
                                var n = this._list.array[t];
                                r.default.instance.showAds(n, "get_list_friend_scan", "get_list_friend", function () {}, function () {
                                    s.default.tryToShow()
                                }), e.currentTarget.mouseEnabled = !1, Laya.timer.once(1e3, e.currentTarget, function () {
                                    this.mouseEnabled = !0
                                })
                            }
                        }, t.prototype._stopScrollAction = function () {
                            Laya.timer.clear(this, this._scroll)
                        }, t.prototype._startScrollAction = function () {
                            Laya.timer.clear(this, this._scroll), Laya.timer.loop(4e3, this, this._scroll)
                        }, t.prototype._scroll = function () {
                            var e = this._list.array.length;
                            if (!(e <= 0) && this._list.scrollBar) {
                                var t = 144 * e + this._list.spaceX * (e - 1) - this._list.width,
                                    n = this._list.scrollBar.value;
                                n <= 14.4 ? this._dir = 1 : n >= t - 14.4 && (this._dir = -1);
                                var i = this._list.startIndex + this._dir;
                                i = Math.max(0, Math.min(e - 1, i)), this._list.tweenTo(i, 300)
                            }
                        }, t
                    }(a.ui.view.ScrollAdsUI);
                n.default = l
            }, {
                "../ui/layaMaxUI": 97,
                "./AdsLogic": 5,
                "./MoreAds": 10
            }],
            15: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.COIN_CHANGED = "COIN_CHANGED", e.DIAMOND_CHANGED = "DIAMOND_CHANGED", e.SKIN_CHANGED = "SKIN_CHANGED", e.VIDEO_CHANGED = "VIDEO_CHANGED", e.BANNER_CHANGED = "BANNER_CHANGED", e.INSIDE_ADS_CHANGED = "INSIDE_ADS_CHANGED", e.INSIDE_ADS_CLICKED = "INSIDE_ADS_CLICKED", e.MY_BANNER_CHANGED = "MY_BANNER_CHANGED", e.MERGED = "MERGED", e.MERGE_CHANGED = "MERGE_CHANGED", e.MERGE_DRAG_START = "MERGE_DRAG_START", e.MERGE_DRAG_END = "MERGE_DRAG_END", e.UNLOCK = "UNLOCK", e.BOUGHT_TIMES_CHANGED = "BOUGHT_TIMES_CHANGED", e.TICKETS_CHANGED = "TICKETS_CHANGED", e.BALLOON_CHANGED = "BALLOON_CHANGED", e
                }();
                n.default = i
            }, {}],
            16: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.login_game = "login_game", e.enter_game = "enter_game", e.start_game = "start_game", e.up_len = "up_len", e.up_speed = "up_speed", e.up_offline = "up_offline", e.video_up_len = "video_up_len", e.video_up_speed = "video_up_speed", e.video_up_offline = "video_up_offline", e.share_up_len = "share_up_len", e.share_up_speed = "share_up_speed", e.share_up_offline = "share_up_offline", e.pop_offline = "pop_offline", e.normal_offline = "normal_offline", e.motive_offline = "motive_offline", e.video_offline = "video_offline", e.share_offline = "share_offline", e.collect_reward = "collect_reward", e.pop_experience = "pop_experience", e.click_experience = "click_experience", e.pop_experience_addlen = "experience_addlen", e.use_experience_addlen = "use_experience_addlen", e.pop_experience_skin = "pop_experience_skin", e.use_experience_skin = "use_experience_skin", e.pop_experience_food = "pop_experience_food", e.use_experience_food = "use_experience_food", e.pop_revive = "pop_revive", e.click_revive = "click_revive", e.video_revive = "video_revive", e.share_revive = "share_revive", e.pop_score = "pop_score", e.motive_score = "motive_score", e.video_score = "video_score", e.share_score = "share_score", e.pop_unlock = "pop_unlock", e.click_unlock = "click_unlock", e.video_unlock = "video_unlock", e.share_unlock = "share_unlock", e.click_1m = "click_1m", e.invite_friend = "invite_friend", e
                }();
                n.default = i
            }, {}],
            17: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.Loading = "view/loading.scene", e.Main = "view/lobby.scene", e.Setting = "view/lobby_setting.scene", e.Rank = "view/lobby_rank.scene", e.PopWin = "view/lobby_reward.scene", e.Skin = "view/lobby_pifu.scene", e.Game = "view/GameScene.scene", e.SignIn = "view/lobby_qiandao.scene", e.Match = "view/lobby_match_10.scene", e.Test = "view/test.scene", e.GameLoading = "view/gamein_loading.scene", e.Revive = "view/gamein_relive1.scene", e.Score = "view/gamein_score.scene", e.GameRank = "view/gamein_rank.scene", e.GoldAnim = "view/gold_animation.scene", e.DiamondsAnim = "view/diamonds_animation.scene", e.SkinAnim = "view/skin_animation.scene", e.Shop = "view/lobby_shop.scene", e.Guide = "view/GuideView.scene", e.Test3d = "view/GameTest.scene", e.Lottery = "view/zhuanpan.scene", e.Balloon = "view/BalloonLayer.scene", e.MoreAds = "view/MoreAds.scene", e.ExitAds = "view/ExitAds.scene", e.FullScrollAds = "view/FullScrollAds.scene", e
                }();
                n.default = i
            }, {}],
            18: [function (e, t, n) {
                "use strict";
                var i = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    o = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("./SignCnf"),
                    r = function () {
                        function e() {}
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e), this._instance
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.loadConfig = function () {
                            return i(this, void 0, void 0, function () {
                                return o(this, function (e) {
                                    switch (e.label) {
                                        case 0:
                                            return [4, this.loadSkinConfig()];
                                        case 1:
                                            return e.sent(), [4, this.loadSignConfig()];
                                        case 2:
                                            return e.sent(), [2]
                                    }
                                })
                            })
                        }, e.prototype.loadSkinConfig = function () {
                            return i(this, void 0, void 0, function () {
                                var e = this;
                                return o(this, function (t) {
                                    return [2, new Promise(function (t, n) {
                                        Laya.loader.load("config/skin.json", Laya.Handler.create(e, function (n) {
                                            e.skins = n, t()
                                        }), null, Laya.Loader.JSON)
                                    })]
                                })
                            })
                        }, e.prototype.loadSignConfig = function () {
                            return i(this, void 0, void 0, function () {
                                return o(this, function (e) {
                                    return this.signs = [{
                                        type: a.SignRewardType.GOLD,
                                        value: 10
                                    }, {
                                        type: a.SignRewardType.SKIN,
                                        value: 1
                                    }, {
                                        type: a.SignRewardType.GOLD,
                                        value: 15
                                    }, {
                                        type: a.SignRewardType.DIAMONDS,
                                        value: 1
                                    }, {
                                        type: a.SignRewardType.SKIN,
                                        value: 2
                                    }, {
                                        type: a.SignRewardType.GOLD,
                                        value: 20
                                    }, {
                                        type: a.SignRewardType.DIAMONDS,
                                        value: 1.5
                                    }], [2]
                                })
                            })
                        }, e._instance = null, e
                    }();
                n.default = r
            }, {
                "./SignCnf": 20
            }],
            19: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../common/EventID"),
                    o = e("../platform/yt"),
                    a = function () {
                        function e() {}
                        return Object.defineProperty(e, "sdkParams", {
                            get: function () {
                                return o.default.isWx ? {
                                    gameId: "snake3dnew01",
                                    gameVersion: 145,
                                    videoId: "adunit-1e4b1876e2061951",
                                    bannerId: "adunit-a56d044b42a6cc33",
                                    interId: "adunit-05298cbd1281372b",
                                    onBannerResize: function (e, t, n, o, a, r) {
                                        return Laya.timer.frameOnce(2, null, function () {
                                            Laya.stage.event(i.default.BANNER_CHANGED)
                                        }), {
                                            top: t - o,
                                            left: .5 * (e - n)
                                        }
                                    }
                                } : o.default.isOppo ? (this.RemoteRes = "", {
                                    gameId: "snake3dnewoppo01",
                                    gameVersion: 1,
                                    videoId: "295571",
                                    bannerId: "295567",
                                    nativeId: "295569",
                                    onBannerResize: function (e, t, n, o, a, r) {
                                        return Laya.timer.frameOnce(2, null, function () {
                                            Laya.stage.event(i.default.BANNER_CHANGED)
                                        }), {
                                            top: t - o,
                                            left: .5 * (e - n)
                                        }
                                    }
                                }) : (this.RemoteRes = "", {
                                    gameId: "snake3dnew01",
                                    gameVersion: 1
                                })
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.RemoteRes = "", e.IsDebug = !1, e.initLen = 4, e.initSpeed = 400, e.initOffline = 0, e.experienceLen = 100, e.experienceFood = 1, e.levelCount = 120, e
                    }();
                n.default = a
            }, {
                "../common/EventID": 15,
                "../platform/yt": 63
            }],
            20: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, o = function () {};
                n.default = o, i = n.SignRewardType || (n.SignRewardType = {}), i[i.NONE = 0] = "NONE", i[i.GOLD = 1] = "GOLD", i[i.DIAMONDS = 2] = "DIAMONDS", i[i.SKIN = 3] = "SKIN"
            }, {}],
            21: [function (e, t, n) {
                "use strict";
                var i;
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }), i = n.SkinAddAttrEnum || (n.SkinAddAttrEnum = {}), i[i.NONE = 0] = "NONE", i[i.INITLEN = 1] = "INITLEN", i[i.FOOD = 2] = "FOOD";
                var o = function () {};
                n.default = o
            }, {}],
            22: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../platform/yt"),
                    o = function () {
                        function e() {}
                        return e.getItem = function (e, t) {
                            return void 0 === t && (t = null), Laya.LocalStorage.getItem(e) || t
                        }, e.getIntItem = function (e, t) {
                            return parseInt(Laya.LocalStorage.getItem(e)) || t
                        }, e.getFloatItem = function (e, t) {
                            return parseFloat(Laya.LocalStorage.getItem(e)) || t
                        }, e.setItem = function (e, t) {
                            i.default.setStorage ? i.default.setStorage({
                                key: e,
                                data: t,
                                success: null,
                                fail: null,
                                complete: null
                            }) : Laya.LocalStorage.setItem(e, t)
                        }, e.removeItem = function (e) {
                            return Laya.LocalStorage.removeItem(e)
                        }, e
                    }();
                n.default = o
            }, {
                "../platform/yt": 63
            }],
            23: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../libs/bignumber"),
                    o = e("../platform/yt"),
                    a = function () {
                        function e() {}
                        return e.Log = function (e) {
                            for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                            console.log(e, t)
                        }, e.UploadUserScore = function (e) {
                            var t = {
                                score: e,
                                bscore: JSON.stringify({
                                    wxgame: {
                                        score: e,
                                        update_time: Math.floor((new Date).getTime())
                                    }
                                })
                            };
                            o.default.updateScore && o.default.updateScore({
                                data: t
                            })
                        }, e.GetClockTime = function (e) {
                            return e - e % 36e5
                        }, e.TransClockTime = function (e) {
                            e = Math.floor(e / 1e3);
                            var t = Math.floor(e / 3600),
                                n = Math.floor((e - 3600 * t) / 60),
                                i = e % 60;
                            return (t < 10 ? "0" : "") + t + ":" + (n < 10 ? "0" : "") + n + ":" + (i < 10 ? "0" : "") + i
                        }, e.TransSeconds = function (e) {
                            var t = Math.floor(e / 60),
                                n = Math.floor(e % 60);
                            return (t < 10 ? "0" : "") + t + ":" + (n < 10 ? "0" : "") + n
                        }, e.getLocaleDateString = function (e) {
                            var t = e.getFullYear().toString(),
                                n = e.getMonth() + 1;
                            return t + "/" + (n < 10 ? "0" + n : n.toString()) + "/" + (e.getDate() < 10 ? "0" + e.getDate() : e.getDate().toString())
                        }, e.IsWX = function () {
                            return "undefined" != typeof wx
                        }, e.IsQQ = function () {
                            return "undefined" != typeof qq
                        }, e.getIntervalDays = function (e, t, n) {
                            return void 0 === n && (n = 8), this.getDay(t, n) - this.getDay(e, n)
                        }, e.isSameDay = function (e, t, n) {
                            return void 0 === n && (n = 8), this.getDay(e, n) == this.getDay(t, n)
                        }, e.isToday = function (e, t) {
                            return void 0 === t && (t = 8), this.getDay((new Date).getTime(), t) == this.getDay(e, t)
                        }, e.getDay = function (e, t) {
                            return void 0 === t && (t = 8), Math.floor(new Date(e).getTime() / 864e5 + t / 24)
                        }, e.getNextDaysTimestamp = function (e, t) {
                            return void 0 === t && (t = 8), 864e5 * (this.getDay(e, t) + 1 - t / 24)
                        }, e.getAbbFmt = function (e) {
                            if (e > 0) {
                                for (var t = this.ABB_UNITS, n = t.length, i = Math.floor((e - 1) / n), o = t[(e - 1) % n], a = 0; a < i; ++a) o += t[n - 1];
                                return o
                            }
                            return ""
                        }, e.getAbb = function (e, t) {
                            void 0 === t && (t = 2);
                            var n = {
                                score: "0",
                                unit: 0,
                                fmt: ""
                            };
                            if (e instanceof i.default || (e = new i.default(e)), e.isNaN() || e.isZero() || !e.isFinite()) return n;
                            var o = "";
                            e.isNegative() && (o = "-", e = e.negated());
                            var a = e.toFixed(0, i.default.ROUND_FLOOR),
                                r = a.length;
                            if (r <= 3) return n.score = o + a, n;
                            for (var s = this.ABB_UNITS, l = s.length, c = Math.ceil(r / 3) - 1, u = Math.floor((c - 1) / l), d = s[(c - 1) % l], h = 0; h < u; ++h) d += s[l - 1];
                            var f = r - 3 * c,
                                p = a.substring(0, f),
                                _ = t > 0 ? "." + a.substring(f, f + t) : "";
                            return n.score = o + p + _, n.unit = c, n.fmt = d, n
                        }, e.toAbb_2 = function (e, t) {
                            var n = e.toFixed(0);
                            return n
                        }, e.toAbb = function (e, t) {
                            console.log("toAbb:" + e), void 0 === t && (t = 2);
                            var n = this.getAbb(e, t);
                            return n.score + n.fmt
                        }, e.addBannerStatus = function (e, t) {
                            var n = this._bannerStatusStack.findIndex(function (t) {
                                return t.target == e
                            });
                            n > -1 && this._bannerStatusStack.splice(n, 1), this._bannerStatusStack.push({
                                target: e,
                                show: t
                            }), t ? o.default.showBanner && o.default.showBanner() : o.default.hideBanner && o.default.hideBanner()
                        }, e.removeBannerStatus = function (e) {
                            var t = this._bannerStatusStack.findIndex(function (t) {
                                return t.target == e
                            });
                            t > -1 && this._bannerStatusStack.splice(t, 1);
                            var n = this._bannerStatusStack[this._bannerStatusStack.length - 1];
                            n && n.show ? o.default.showBanner && o.default.showBanner() : o.default.hideBanner && o.default.hideBanner()
                        }, e.loginTime = 0, e.ABB_UNITS = "kMGTPEZY", e._bannerStatusStack = [], e
                    }();
                n.default = a, window.GameHelper = a
            }, {
                "../libs/bignumber": 39,
                "../platform/yt": 63
            }],
            24: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                        function e() {}
                        return e.randBySeed = function (e) {
                            var t = this._seed;
                            this.srand(e), this.rand(), this.rand();
                            var n = this.rand();
                            return this.srand(t), n
                        }, e.rand = function () {
                            return this._seed = (214013 * this._seed + 2531011) % 32768, this._seed / 32768
                        }, e.randInt = function (e, t) {
                            return Math.floor(this.rand() * (t - e + 1) + e)
                        }, e.srand = function (e) {
                            this._seed = Math.floor(e) || 0
                        }, e._seed = 0, e
                    }(),
                    o = function () {
                        function e() {}
                        return e.RandomInt = function (e, t) {
                            return Math.floor(Math.random() * (t - e + 1) + e)
                        }, e.Random = function (e, t) {
                            return Math.random() * (t - e) + e
                        }, e.RandomArr = function (e, t) {
                            if (void 0 === t && (t = !1), t) {
                                var n = this.RandomInt(0, e.length - 1);
                                return e.splice(n, 1)[0]
                            }
                            return e.length > 0 ? e[this.RandomInt(0, e.length - 1)] : null
                        }, e.shuffle = function (e) {
                            for (var t, n, i = e.length; 0 !== i;) n = Math.floor(Math.random() * i), t = e[i -= 1], e[i] = e[n], e[n] = t;
                            return e
                        }, e.GetIntervalDays = function (e, t) {
                            var n = new Date(e).toDateString(),
                                i = new Date(t).toDateString(),
                                o = new Date(n).getTime(),
                                a = new Date(i).getTime();
                            return Math.floor((o - a) / 864e5)
                        }, e.Fixed2 = function (e) {
                            return e < 10 ? "0" + e : e.toString()
                        }, e.FixRand = i, e
                    }();
                n.default = o
            }, {}],
            25: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../common/EventID"),
                    r = e("./GameHelper"),
                    s = e("../ads/MoreAds"),
                    l = e("../ads/AdsLogic"),
                    c = e("../platform/yt"),
                    u = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._img = null, t._list = [], t._pageIdx = 0, t._stayDuration = 60, t._init(), t
                        }
                        return o(t, e), Object.defineProperty(t, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new t)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), t.prototype._init = function () {
                            this.x = .5 * Laya.stage.width, c.default.isIos() && c.default.isLongScreen() ? this.y = Laya.stage.height - 65 : this.y = Laya.stage.height, this._img = new Laya.Image, this._img.anchorX = .5, this._img.anchorY = 1, this.addChild(this._img), this.visible = !1
                        }, t.prototype._onRemoved = function () {
                            this.hide(), e.prototype._onRemoved.call(this)
                        }, t.prototype.show = function () {
                            r.default.Log("[MyBanner]显示"), this.parent || Laya.stage.addChild(this), this.visible = !0, this._addEvents()
                        }, t.prototype.hide = function () {
                            r.default.Log("[MyBanner]隐藏"), this._removeEvents(), this.visible = !1
                        }, t.prototype.getHeight = function () {
                            return this.visible && this._img.visible ? Laya.stage.height - this._img.localToGlobal(new Laya.Point(0, 0)).y : 0
                        }, t.prototype.isValid = function () {
                            return this.visible && this._img.visible
                        }, t.prototype._addEvents = function () {
                            this._img.on(Laya.Event.CLICK, this, this._openAds), this._img.on(Laya.Event.RESIZE, this, this._onImageResize), this._onDataChanged(), Laya.stage.on(a.default.INSIDE_ADS_CHANGED, this, this._onDataChanged), Laya.timer.loop(1e3 * this._stayDuration, this, this._refreshBanner)
                        }, t.prototype._removeEvents = function () {
                            this._img.off(Laya.Event.CLICK, this, this._openAds), this._img.off(Laya.Event.RESIZE, this, this._onImageResize), Laya.stage.off(a.default.INSIDE_ADS_CHANGED, this, this._onDataChanged), Laya.timer.clear(this, this._refreshBanner)
                        }, t.prototype._onDataChanged = function () {
                            if (this._list = [], c.default.insideAds.length > 0 || c.default.isBrowser)
                                for (var e = 0, t = c.default.insideAds; e < t.length; e++) {
                                    var n = t[e];
                                    n.banner_url && this._list.push(n)
                                }
                            this._refreshBanner()
                        }, t.prototype._refreshBanner = function () {
                            var e = this._list.length;
                            if (e > 0) {
                                this._pageIdx = Math.floor((this._pageIdx + 1) % e);
                                var t = this._list[this._pageIdx];
                                this._img.visible = !0, this._img.skin = t.banner_url
                            } else this._img.visible = !1;
                            this._emitChangedEvent()
                        }, t.prototype._emitChangedEvent = function () {
                            Laya.stage.event(a.default.MY_BANNER_CHANGED)
                        }, t.prototype._onImageResize = function () {
                            var e = Laya.stage.height / Laya.stage.width;
                            if (e > 1 && e < 1.5 || e < 1 && e > .66) {
                                var t = 300 / c.default.getSystemSize().width * Laya.stage.width / this._img.width;
                                this._img.scale(t, t, !0)
                            }
                            this._emitChangedEvent()
                        }, t.prototype._openAds = function () {
                            var e = this._list[this._pageIdx];
                            l.default.instance.showAds(e, "get_list_banner_scan", "get_list_banner", function () {}, function () {
                                s.default.tryToShow()
                            })
                        }, t._instance = null, t
                    }(Laya.Sprite);
                n.default = u
            }, {
                "../ads/AdsLogic": 5,
                "../ads/MoreAds": 10,
                "../common/EventID": 15,
                "../platform/yt": 63,
                "./GameHelper": 23
            }],
            26: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./GameHelper"),
                    o = e("./Server"),
                    a = e("../platform/yt"),
                    r = function () {
                        function e() {
                            this.needAuth = a.default.isBrowser ? 0 : -1
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e), this._instance
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.reportAppid = function (e) {
                            o.default.reportAppid(e, null)
                        }, e.prototype.checkNeedAuthList = function () {
                            this.needAuth = "1" == a.default.conf.authflag ? 1 : 0, i.default.Log("下发needAuth:", a.default.conf.authflag)
                        }, e
                    }();
                n.default = r
            }, {
                "../platform/yt": 63,
                "./GameHelper": 23,
                "./Server": 28
            }],
            27: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, o, a = e("./DataStorage"),
                    r = e("./GameHelper"),
                    s = e("./ShareLogic"),
                    l = e("./MathUtil"),
                    c = e("../Common/DataID"),
                    u = e("../data/DataBus"),
                    d = e("../logic/GameLogic"),
                    h = e("./Server"),
                    f = e("../view/Toast"),
                    p = e("../platform/yt");
                o = i = n.RewardMethodEnum || (n.RewardMethodEnum = {}), o[o.NONE = 0] = "NONE", o[o.SHARE = 1] = "SHARE", o[o.VIDEO = 2] = "VIDEO";
                var _ = function () {
                    function e() {
                        this.shareRatio = {}, this.shareRatio2 = {}, this.shareDate = 0, this.shareTimes = 0, this.inviteNumber = 0, this.inviteNumberTotal = 0, this.lastInviteTime = 0, this.init()
                    }
                    return Object.defineProperty(e, "instance", {
                        get: function () {
                            return this._instance || (this._instance = new e), this._instance
                        },
                        enumerable: !0,
                        configurable: !0
                    }), e.prototype.init = function () {
                        this.InitGroupData(), this.getShareRatio()
                    }, e.prototype.InitGroupData = function () {
                        r.default.isToday(this.shareDate) || (this.shareDate = (new Date).getTime())
                    }, e.prototype.getShareRatio = function () {
                        if (p.default.conf.share_chance && p.default.conf.share_chance.indexOf("_") > -1)
                            for (var e = p.default.conf.share_chance.split(","), t = 0; t < e.length; t++) {
                                var n = e[t].split("_");
                                this.shareRatio[n[0]] = n[1]
                            }
                        if (r.default.Log("分享概率：", this.shareRatio), p.default.conf.share_chance2 && p.default.conf.share_chance2.indexOf("_") > -1)
                            for (e = p.default.conf.share_chance2.split(","), t = 0; t < e.length; t++) n = e[t].split("_"), this.shareRatio2[n[0]] = n[1];
                        r.default.Log("分享概率2：", this.shareRatio2)
                    }, e.prototype.ShareOrVideo = function (e) {
                        if (p.default.isBrowser) return i.VIDEO;
                        var t, n = l.default.RandomInt(0, 99);
                        return this.inviteNumber > 0 || u.default.instance.isNewUser ? (t = this.shareRatio2, r.default.Log("[分享或看视频]使用配置2", t)) : (t = this.shareRatio, r.default.Log("[分享或看视频]使用配置1", t)), t[e] && n < t[e] ? "-1" != p.default.conf.share_flag && this.shareTimes < parseInt(p.default.conf.day_share_count) ? i.SHARE : p.default.isVideoLoaded() ? i.VIDEO : i.NONE : p.default.isVideoLoaded() ? i.VIDEO : t[e] && "-1" != p.default.conf.share_flag && this.shareTimes < parseInt(p.default.conf.day_share_count) ? i.SHARE : i.NONE
                    }, e.prototype.HasMotivate = function () {
                        return !!p.default.isBrowser || p.default.isVideoLoaded() || p.default.supportShare && "-1" != p.default.conf.share_flag && this.shareTimes < parseInt(p.default.conf.day_share_count)
                    }, e.prototype.SaveShareTimes = function () {
                        a.default.setItem(c.default.sts, this.shareTimes.toString())
                    }, e.prototype.SaveLastShareDate = function () {
                        a.default.setItem(c.default.sdate, this.shareDate)
                    }, e.prototype.checkDate = function (e) {
                        r.default.isToday(this.shareDate) || (this.shareDate = new Date(e).getTime(), this.shareGroupList = [], this.shareTimes = 0, this.SaveShareTimes(), this.SaveLastShareDate())
                    }, e.prototype.CalcSuccShareTimes = function () {
                        this.shareTimes++, this.SaveShareTimes()
                    }, e.prototype.ShareReward = function (e, t, n) {
                        void 0 === t && (t = null), void 0 === n && (n = null), p.default.isBrowser ? setTimeout(function () {
                            t && t()
                        }, 300) : s.default.instance.Share(e, null, t, n)
                    }, e.prototype.VideoReward = function (e, t, n) {
                        void 0 === t && (t = null), void 0 === n && (n = null), p.default.isBrowser ? setTimeout(function () {
                            t && t()
                        }, 300) : p.default.isVideoLoaded() ? (p.default.showLoading({
                            title: "请稍候",
                            mask: !0
                        }), r.default.addBannerStatus("video", !1), p.default.showVideo(function (e) {
                            r.default.removeBannerStatus("video"), e ? (t && t(), d.default.instance.AddVideoTimes(), p.default.reportVideo(1)) : n && n(), p.default.hideLoading()
                        }, function () {
                            r.default.removeBannerStatus("video"), n && n(), p.default.hideLoading()
                        }, function () {
                            p.default.hideLoading(), p.default.reportVideo(0)
                        })) : (n && n(), f.default.show("暂无可看视频"))
                    }, e.prototype.updateInviteNumber = function () {
                        var e = this;
                        return new Promise(function (t) {
                            h.default.getInviteShare(1, 0, function (n) {
                                e.inviteNumber = n.invite_num || 0, e.lastInviteTime = 1e3 * n.last_time || 0, t(!0)
                            }, function (e) {
                                t(!1)
                            })
                        })
                    }, e
                }();
                n.default = _
            }, {
                "../Common/DataID": 1,
                "../data/DataBus": 32,
                "../logic/GameLogic": 44,
                "../platform/yt": 63,
                "../view/Toast": 121,
                "./DataStorage": 22,
                "./GameHelper": 23,
                "./MathUtil": 24,
                "./Server": 28,
                "./ShareLogic": 29
            }],
            28: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./GameHelper"),
                    o = e("../platform/yt"),
                    a = (e("./TimeMgr"), function () {
                        function e() {}
                        return e.GetData = function (e, t) {
                            void 0 === t && (t = null), o.default.supportLogin && o.default.supportNetWork ? o.default.getUserIdOrCode({
                                key: "data",
                                success: function (e) {},
                                fail: t
                            }) : t && t()
                        }, e.saveData = function (e, t, n) {
                            void 0 === n && (n = null), o.default.supportLogin && o.default.supportNetWork ? o.default.getUserIdOrCode({
                                key: "data",
                                success: function (e) {},
                                fail: n
                            }) : n && n()
                        }, e.submitLeaderboard = function (e, t, n) {
                            void 0 === n && (n = null), o.default.supportLogin && o.default.supportNetWork && o.default.supportWorldRank ? (i.default.Log("保存成绩到世界排行榜：" + e), o.default.loginAndGetUserInfo({
                                success: function (e) {},
                                fail: function (e) {
                                    n && n(e)
                                }
                            })) : n && n()
                        }, e.getLeaderboard = function (e, t) {
                            void 0 === t && (t = null), o.default.supportLogin && o.default.supportNetWork && o.default.supportWorldRank ? (i.default.Log("开始拉取世界排行榜"), o.default.login({
                                success: function (e) {},
                                fail: t
                            })) : t && t()
                        }, e.submitLeaderboardUnit = function (e, t, n, a, r, s) {
                            o.default.supportLogin && o.default.supportNetWork && o.default.supportWorldRank ? (i.default.Log("保存成绩到世界排行榜n：" + (e + n)), o.default.loginAndGetUserInfo({
                                success: function (e) {},
                                fail: function (e) {
                                    s && s(e)
                                }
                            })) : s && s()
                        }, e.getLeaderboardUnit = function (e, t) {
                            o.default.supportLogin && o.default.supportNetWork && o.default.supportWorldRank ? (i.default.Log("开始拉取世界排行榜n"), o.default.login({
                                success: function (e) {},
                                fail: t
                            })) : t && t()
                        }, e.reportAppid = function (e, t, n) {
                            void 0 === n && (n = null), o.default.supportLogin && o.default.supportNetWork ? o.default.getUserIdOrCode({
                                key: "report",
                                success: function (e) {},
                                fail: n
                            }) : n && n()
                        }, e.reportEvent = function (e, t, n) {
                            void 0 === t && (t = "index"), void 0 === n && (n = null), o.default.supportLogin && o.default.supportNetWork ? o.default.getUserIdOrCode({
                                key: "data",
                                success: function (e) {},
                                fail: n
                            }) : n && n()
                        }, e.getInviteShare = function (e, t, n, a) {
                            if (void 0 === t && (t = 0), o.default.supportLogin && o.default.supportNetWork) {
                                o.default.getSavedUserId("data");
                                var r = function (e) {
                                    i.default.Log("查询分享后好友的点击状况失败：", e), a && a(e)
                                };
                                o.default.login({
                                    success: function (e) {},
                                    fail: r
                                })
                            } else a && a()
                        }, e.addInviteShare = function (e) {
                            if (o.default.supportLogin && o.default.supportNetWork) {
                                o.default.login({
                                    success: function (e) {}
                                })
                            }
                        }, e.time = -1, e
                    }());
                n.default = a
            }, {
                "../platform/yt": 63,
                "./GameHelper": 23,
                "./TimeMgr": 30
            }],
            29: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, o, a = e("./RewardLogic"),
                    r = e("./GameHelper"),
                    s = e("./MathUtil"),
                    l = e("../view/Toast"),
                    c = e("../platform/yt");
                o = i = n.ShareTypeEnum || (n.ShareTypeEnum = {}), o[o.NONE = 0] = "NONE", o[o.SYSTEM = 19] = "SYSTEM", o[o.SHARE = 20] = "SHARE", o[o.RANK = 21] = "RANK", o[o.GAMERANK = 22] = "GAMERANK", o[o.MATCH = 32] = "MATCH", o[o.EXPERIENCE = 23] = "EXPERIENCE", o[o.OFFLINE = 24] = "OFFLINE", o[o.SIGNIN = 25] = "SIGNIN", o[o.REVIVE = 17] = "REVIVE", o[o.SCORE = 26] = "SCORE", o[o.UNLOCK = 27] = "UNLOCK", o[o.NOCOINS = 28] = "NOCOINS", o[o.NODIAMONDS = 29] = "NODIAMONDS", o[o.LOTTERY = 30] = "LOTTERY", o[o.BALLOON = 31] = "BALLOON";
                var u = function () {
                    function e() {
                        this.shareCanceled = !1, this.localShare = {
                            System: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "system"
                                }
                            },
                            Main: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "main"
                                }
                            },
                            Rank: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "rank"
                                }
                            },
                            Gamerank: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "gamerank"
                                }
                            },
                            Skin: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "skin"
                                }
                            },
                            Experience: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "experience"
                                }
                            },
                            Offline: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "offline"
                                }
                            },
                            Signin: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "signin"
                                }
                            },
                            Revive: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "revive"
                                }
                            },
                            Score: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "score"
                                }
                            },
                            Freeuplen: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "freeuplen"
                                }
                            },
                            Freeupspeed: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "freeupspeed"
                                }
                            },
                            Freeupoff: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "freeupoff"
                                }
                            },
                            Unlock: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "unlock"
                                }
                            },
                            NoCoins: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "nocoins"
                                }
                            },
                            NoDiamonds: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "nodiamonds"
                                }
                            },
                            Lottery: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "lottery"
                                }
                            },
                            Balloon: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "balloon"
                                }
                            },
                            Match: {
                                titleArr: [],
                                picArr: [],
                                query: {
                                    src: "match"
                                }
                            },
                            defaultTitle: "蛇我其谁，等你来战！",
                            defaultPic: "tex/share.png",
                            getRandTitle: function (e) {
                                if (!this[e] || !this[e].titleArr || 0 == this[e].titleArr.length) return this.defaultTitle;
                                var t = this[e].titleArr;
                                return t[s.default.RandomInt(0, t.length - 1)]
                            },
                            getRandPic: function (e) {
                                if (!this[e] || !this[e].picArr || 0 == this[e].picArr.length) return this.defaultPic;
                                var t = this[e].picArr;
                                return t[s.default.RandomInt(0, t.length - 1)]
                            },
                            getQuery: function (e) {
                                return this[e] && this[e].query ? this[e].query : {}
                            }
                        }, this.fakeShareFailTimes = 0
                    }
                    return Object.defineProperty(e, "instance", {
                        get: function () {
                            return this._instance || (this._instance = new e), this._instance
                        },
                        enumerable: !0,
                        configurable: !0
                    }), e.prototype.Share = function (e, t, n, o) {
                        var a = this;
                        if (void 0 === t && (t = null), void 0 === n && (n = null), void 0 === o && (o = null), c.default.supportShare) {
                            var s = null == t ? this.GetShareConfig(e) : t;
                            if (r.default.Log("分享配置：", s), e == i.SYSTEM) {
                                if (!c.default.supportShareCallback) return;
                                c.default.onShare(function () {
                                    var t = s.sharePic;
                                    return c.default.reportShare(e, t), {
                                        title: s.title,
                                        imageUrl: s.pic,
                                        query: s.queryStr
                                    }
                                })
                            } else {
                                this.shareCanceled = !1, c.default.share({
                                    title: s.title,
                                    imageUrl: s.pic,
                                    query: s.queryStr,
                                    cancel: function () {
                                        r.default.Log("执行了取消回调"), parseInt(c.default.conf.share_use_cancel) > -1 && (a.shareCanceled = !0)
                                    }
                                });
                                var u = s.sharePic;
                                c.default.reportShare(e, u), (n || o) && this.fakeShareCallback(n, function (i) {
                                    "2" == c.default.conf.share_flag ? c.default.showModal({
                                        title: "失败了！",
                                        content: i,
                                        success: function (i) {
                                            i.confirm && a.Share(e, t, n, o)
                                        },
                                        fail: function () {}
                                    }) : i && "" != i && l.default.show(i), o && o()
                                })
                            }
                        }
                    }, e.prototype.GetShareConfig = function (e) {
                        var t, n, i, o = this.GetShareName(e),
                            a = this.localShare.getQuery(o),
                            r = c.default.getRandomStrategyShareInfo();
                        r ? (t = r.text, n = r.pic, i = r.sid) : (t = this.localShare.getRandTitle(o), n = this.localShare.getRandPic(o), i = -1), a.position_id = e, a.share_id = i;
                        var s = c.default.getSavedUserId("data");
                        a.host_user_id = s;
                        var l = c.default.getSavedUserId("strategy");
                        return l && (a.strategy_user_id = l), c.default.strategyChannelId && (a.strategy_cid = c.default.strategyChannelId), a.cid = "normalshare", {
                            title: t,
                            pic: n,
                            queryStr: this.GenerateQuery(a),
                            sharePic: i
                        }
                    }, e.prototype.GetShareName = function (e) {
                        switch (e) {
                            case i.SYSTEM:
                                return "System";
                            case i.SHARE:
                                return "Main";
                            case i.RANK:
                                return "Rank";
                            case i.GAMERANK:
                                return "Gamerank";
                            case i.EXPERIENCE:
                                return "Experience";
                            case i.OFFLINE:
                                return "Offline";
                            case i.SIGNIN:
                                return "Signin";
                            case i.REVIVE:
                                return "Revive";
                            case i.SCORE:
                                return "Score";
                            case i.UNLOCK:
                                return "Unlock";
                            case i.NOCOINS:
                                return "NoCoins";
                            case i.NODIAMONDS:
                                return "NoDiamonds";
                            case i.LOTTERY:
                                return "Lottery";
                            case i.BALLOON:
                                return "Balloon";
                            case i.MATCH:
                                return "Match"
                        }
                        return ""
                    }, e.prototype.GenerateQuery = function (e) {
                        var t = "";
                        for (var n in e) t += n + "=" + e[n] + "&";
                        return t + "sid=" + this.GenerateUUID() + "&t=" + (new Date).getTime()
                    }, e.prototype.GenerateUUID = function () {
                        for (var e = [], t = 0; t < 256; t++) e[t] = (t < 16 ? "0" : "") + t.toString(16);
                        var n = 4294967295 * Math.random() | 0,
                            i = 4294967295 * Math.random() | 0,
                            o = 4294967295 * Math.random() | 0,
                            a = 4294967295 * Math.random() | 0;
                        return (e[255 & n] + e[n >> 8 & 255] + e[n >> 16 & 255] + e[n >> 24 & 255] + "-" + e[255 & i] + e[i >> 8 & 255] + "-" + e[i >> 16 & 15 | 64] + e[i >> 24 & 255] + "-" + e[63 & o | 128] + e[o >> 8 & 255] + "-" + e[o >> 16 & 255] + e[o >> 24 & 255] + e[255 & a] + e[a >> 8 & 255] + e[a >> 16 & 255] + e[a >> 24 & 255]).toUpperCase()
                    }, e.prototype.fakeShareCallback = function (e, t) {
                        var n = this;
                        c.default.showLoading({
                            title: "请稍候...",
                            mask: !0
                        });
                        var i = function (t) {
                                c.default.hideLoading(), e && e(t)
                            },
                            o = function (e) {
                                c.default.hideLoading(), t && t(e)
                            },
                            s = (new Date).getTime();
                        r.default.Log("执行伪分享回调");
                        var l = function (e) {
                            c.default.offShow(l);
                            var t = ((new Date).getTime() - s) / 1e3,
                                u = !1;
                            t < parseFloat(c.default.conf.fake_share_gap) && (u = !0), setTimeout(function () {
                                var e;
                                r.default.Log("分享回调：后台返回时间：" + t + "，取值：" + c.default.conf.fake_share_gap), e = void 0 === c.default.conf.fake_share_fail_ratio_list ? ["0"] : String(c.default.conf.fake_share_fail_ratio_list).split(",");
                                var s = parseInt(e[Math.min(n.fakeShareFailTimes, e.length - 1)]);
                                if (n.shareCanceled || u) o && o(c.default.conf.share_time_toast);
                                else {
                                    var l = 100 * Math.random();
                                    r.default.Log("分享回调：重复概率随机：" + l + "，第" + n.fakeShareFailTimes + "次失败，失败概率为" + s), l < s ? (o && o(c.default.conf.share_group_toast), ++n.fakeShareFailTimes) : (i && setTimeout(function () {
                                        i()
                                    }, 1e3), r.default.Log("分享成功"), a.default.instance.CalcSuccShareTimes(), n.fakeShareFailTimes = 0)
                                }
                            }, 50)
                        };
                        c.default.onShow(l)
                    }, e
                }();
                n.default = u
            }, {
                "../platform/yt": 63,
                "../view/Toast": 121,
                "./GameHelper": 23,
                "./MathUtil": 24,
                "./RewardLogic": 27
            }],
            30: [function (e, t, n) {
                "use strict";
                var i = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    o = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../platform/yt"),
                    r = e("./GameHelper"),
                    s = function () {
                        function e() {}
                        return Object.defineProperty(e, "localTime", {
                            get: function () {
                                return this._localTime
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e, "serverTime", {
                            get: function () {
                                return this._serverTime
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.setServerTime = function (e) {
                            return !(!e || !e.header || !e.header.Date && !e.header.date || (this._localTime = (new Date).getTime(), this._serverTime = new Date(e.header.Date || e.header.date).getTime(), console.log("从header中获得服务器时间戳: ", this._serverTime), a.default.emit("UPDATE_SERVER_TIME", this._serverTime), 0))
                        }, e.getRevisionServerTime = function () {
                            var e = this._serverTime,
                                t = this._localTime;
                            return e + (new Date).getTime() - t
                        }, e.getSmartServerTime = function () {
                            return i(this, void 0, void 0, function () {
                                var e, t, n, i, a;
                                return o(this, function (o) {
                                    return e = this._serverTime, t = this._localTime, n = (new Date).getTime(), (i = n - t) >= 0 && i < 6e5 && (a = e + i, r.default.isSameDay(a, e)) ? [2, a] : [2, this.getTimeFromServer()]
                                })
                            })
                        }, e.isTimeValid = function () {
                            return Math.abs((new Date).getTime() - this._serverTime) < 6e5
                        }, e.isDateValid = function () {
                            return new Date(this._serverTime).toDateString() == (new Date).toDateString() || this.isTimeValid()
                        }, e.isMordenTime = function (e) {
                            return e > 159e10
                        }, Object.defineProperty(e, "offlineTime", {
                            get: function () {
                                return this._offlineTime
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.setOfflineTime = function (e) {
                            return !(!e || !e.header || !e.header.Date && !e.header.date || (this._offlineTime = new Date(e.header.Date || e.header.date).getTime(), console.log("从header中获得时间, 作为离线时间戳: ", this._offlineTime), 0))
                        }, e.getOfflineOffset = function () {
                            return i(this, void 0, void 0, function () {
                                var e, t, n;
                                return o(this, function (i) {
                                    switch (i.label) {
                                        case 0:
                                            return (e = this._offlineOffset) > 0 ? (this._offlineOffset = 0, [2, e]) : [3, 1];
                                        case 1:
                                            return this._offlineTime > 159e10 ? [4, this.getTimeFromServer()] : [3, 3];
                                        case 2:
                                            return t = i.sent(), n = this._offlineTime, t > n && n > 159e10 ? (this._offlineTime = t, [2, t - n]) : [2, 0];
                                        case 3:
                                            return [2, 0];
                                        case 4:
                                            return [2]
                                    }
                                })
                            })
                        }, e.calcOfflineOffset = function (e) {
                            if (e && e.header && (e.header.Date || e.header.date) && e.data && e.data.last_time) {
                                var t = 1e3 * parseInt(e.data.last_time),
                                    n = new Date(e.header.Date || e.header.date).getTime();
                                n > t && t > 159e10 && (this._offlineOffset = n - t, this._offlineTime = n)
                            }
                        }, e.getTimeFromServer = function () {}, e._localTime = 0, e._serverTime = 0, e._offlineTime = 0, e._offlineOffset = 0, e._promise = null, e
                    }();
                n.default = s
            }, {
                "../platform/yt": 63,
                "./GameHelper": 23
            }],
            31: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../platform/yt"),
                    o = e("./GameHelper"),
                    a = function () {
                        function e() {}
                        return e.prototype.createWxBtn = function (e, t, n) {
                            var a = e.localToGlobal(Laya.Point.create().reset()),
                                r = e.localToGlobal(Laya.Point.create().setTo(e.width, e.height)),
                                s = a.x / Laya.stage.width * Laya.Browser.clientWidth,
                                l = a.y / Laya.stage.height * Laya.Browser.clientHeight,
                                c = (r.x - a.x) / Laya.stage.width * Laya.Browser.clientWidth,
                                u = (r.y - a.y) / Laya.stage.height * Laya.Browser.clientHeight;
                            this._wxBtn && this._wxBtn.destroy(), this._wxBtn = i.default.createUserInfoButton({
                                type: "text",
                                text: " ",
                                style: {
                                    left: s,
                                    top: l,
                                    width: c,
                                    height: u,
                                    backgroundColor: "#00000001",
                                    color: "#00000001",
                                    fontSize: 1
                                },
                                withCredentials: !0,
                                lang: "zh_CN"
                            }), this._wxBtn && this._wxBtn.onTap(function (e) {
                                o.default.Log("使用UserInfoButton获取用户信息：", e), e.errMsg.indexOf("auth deny") > -1 || e.errMsg.indexOf("auth denied") > -1 || e.errMsg.indexOf("fail") > -1 ? (o.default.Log("使用UserInfoButton获取用户信息，授权失败！", e), n && n(e)) : (o.default.Log("使用UserInfoButton获取用户信息，授权成功！", e), t && t(e))
                            }), this.normalCallback && this._wxBtn && this._wxBtn.hide()
                        }, e.prototype.setNormalMode = function (e) {
                            this.normalCallback = e, e ? this._wxBtn && this._wxBtn.hide() : this._wxBtn && this._wxBtn.show()
                        }, e.prototype.showWxBtn = function () {
                            this.normalCallback || this._wxBtn && this._wxBtn.show()
                        }, e.prototype.hideWxBtn = function () {
                            this._wxBtn && this._wxBtn.hide()
                        }, e.prototype.onNormalTap = function (e, t) {
                            this.normalCallback ? this.normalCallback() : this._wxBtn || this._getUserInfo(function (t) {
                                e && e(t)
                            }, function (e) {
                                t && t(e)
                            })
                        }, e.prototype._getUserInfo = function (e, t) {
                            o.default.Log("使用getUserInfo获取用户信息"), i.default.getUserInfo({
                                withCredentials: !0,
                                success: function (t) {
                                    o.default.Log("getUserInfo获取用户信息成功，res:" + t), e && e(t)
                                },
                                fail: function (e) {
                                    o.default.Log("getUserInfo获取用户信息失败,res:" + e), t && t(e)
                                }
                            })
                        }, e
                    }();
                n.default = a
            }, {
                "../platform/yt": 63,
                "./GameHelper": 23
            }],
            32: [function (e, t, n) {
                "use strict";
                var i = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    o = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../core/Server"),
                    r = e("../core/GameHelper"),
                    s = e("../Common/DataID"),
                    l = e("../sound/SoundMgr"),
                    c = e("../core/RewardLogic"),
                    u = e("../core/DataStorage"),
                    d = e("../logic/EconomicLogic"),
                    h = e("./GameSvData"),
                    f = e("../logic/CollectLogic"),
                    p = e("../libs/bignumber"),
                    _ = e("./SkinSvData"),
                    y = e("./PropSvData"),
                    g = (e("../logic/GameLogic"), e("./MergeSvData")),
                    m = e("./LotterySvData"),
                    v = e("../ads/AdsLogic"),
                    L = e("../core/TimeMgr"),
                    w = function () {
                        function e() {
                            this.gameData = null, this.propData = null, this.skinData = null, this.mergeData = null, this.lotteryData = null, this.lastDate = -1, this.isNewUser = !1
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e), this._instance
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.init = function () {
                            var e = this;
                            return new Promise(function (t, n) {
                                e.LoadDataFromServer().then(function (n) {
                                    if ("string" == typeof n && "" != n && "null" != n) {
                                        var i = null;
                                        try {
                                            i = JSON.parse(n)
                                        } catch (e) {
                                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), i = null, console.e("服务端数据解析出错: ", e)
                                        }
                                        i ? void 0 === i[s.default.tcoin] || -1 != new p.default(u.default.getItem(s.default.tcoin, "0")).comparedTo(i[s.default.tcoin]) ? (r.default.Log("服务端数据不如本地"), e.LoadDataFromLocal()) : e.SetServerData(i) : e.LoadDataFromLocal()
                                    } else r.default.Log("服务端没数据"), e.isNewUser = !0, e.LoadDataFromLocal();
                                    t()
                                }, function (n) {
                                    r.default.Log("服务端请求失败：", n), e.LoadDataFromLocal(), t()
                                })
                            })
                        }, e.prototype.updateDataEveryDay = function () {}, e.prototype.LoadDataFromLocal = function () {
                            r.default.Log("从本地加载数据"), c.default.instance.shareTimes = u.default.getIntItem(s.default.sts, 0), c.default.instance.shareDate = u.default.getItem(s.default.sdate, ""), this.lastDate = u.default.getIntItem(s.default.day, -1), d.default.instance.coin = new p.default(u.default.getItem(s.default.coin, "10000")), d.default.instance.tcoin = new p.default(u.default.getItem(s.default.tcoin, "10000")), d.default.instance.tcoin.isZero() && (d.default.instance.coin = new p.default(1e4), d.default.instance.tcoin = new p.default(1e4)), d.default.instance.diamond = new p.default(u.default.getItem(s.default.diamond, "0")), d.default.instance.maxCoin = new p.default(u.default.getItem(s.default.maxCoin, "0")), l.default.instance.LoadSettingData(), f.default.instance.getCollectState(), this.LoadPropData(), this.LoadGameData(), this.LoadSkinData(), this.LoadMergeData(), this.LoadLotteryData()
                        }, e.prototype.SetServerData = function (e) {
                            r.default.Log("设置服务端数据");
                            var t = new p.default(e[s.default.coin]),
                                n = new p.default(e[s.default.tcoin]),
                                i = new p.default(e[s.default.diamond]),
                                o = new p.default(e[s.default.maxCoin]);
                            d.default.instance.SetEcoData(t, n, i, o), f.default.instance.collectState = e[s.default.collectState], f.default.instance.SaveCollectState(), this.SetGameData(e[s.default.gameData]), this.SetPropData(e[s.default.propData]), this.SetSkinData(e[s.default.skinData]), this.SetMergeData(e[s.default.mergeData]), this.SetLotteryData(e[s.default.lotteryData]), l.default.instance.setting = e[s.default.setting], l.default.instance.SaveSettingData(), this.lastDate = e[s.default.day], c.default.instance.shareTimes = e[s.default.sts], c.default.instance.shareDate = e[s.default.sdate]
                        }, e.prototype.RefreshNewDayData = function (e, t) {
                            var n; - 1 != t ? n = new Date(t) : this.gameData.loginDate = e, -1 == t || -1 == e || r.default.isSameDay(e, n) ? r.default.Log("不刷新数据") : (r.default.Log("今天日期：" + new Date(e - 216e5).toDateString()), r.default.Log("上次登陆日期：" + new Date(n.getTime() - 216e5).toDateString()), r.default.Log("新的一天到了"), this.gameData.loginDate = e, this.gameData.freeCoinTimes = 0, this.gameData.freeDiamTimes = 0, this.SaveGameData(), this.lotteryData.get_tickets = 0, this.lotteryData.balloon_times = 0, this.SaveLotteryData(), v.default.instance.clearClickedAdsList())
                        }, e.prototype.LoadDataFromServer = function () {
                            return i(this, void 0, void 0, function () {
                                return o(this, function (e) {
                                    return [2, new Promise(function (e, t) {
                                        a.default.GetData(function (t) {
                                            r.default.Log("读取到的服务端数据：", t), e(t)
                                        }, function (e) {
                                            t(e)
                                        })
                                    })]
                                })
                            })
                        }, e.prototype.SaveDataToServer = function () {
                            return i(this, void 0, void 0, function () {
                                var e;
                                return o(this, function (t) {
                                    switch (t.label) {
                                        case 0:
                                            return (e = {})[s.default.sts] = c.default.instance.shareTimes, e[s.default.sdate] = c.default.instance.shareDate, e[s.default.coin] = d.default.instance.coin.toString(), e[s.default.tcoin] = d.default.instance.tcoin.toString(), e[s.default.diamond] = d.default.instance.diamond.toString(), e[s.default.maxCoin] = d.default.instance.maxCoin.toString(), [4, this.GetNow(!0).then(function (t) {
                                                e[s.default.day] = t
                                            })];
                                        case 1:
                                            return t.sent(), e[s.default.collectState] = f.default.instance.collectState, e[s.default.gameData] = this.gameData, e[s.default.propData] = this.propData, e[s.default.setting] = l.default.instance.setting, e[s.default.skinData] = this.skinData, e[s.default.mergeData] = this.mergeData ? this.mergeData.toSvString() : "", e[s.default.lotteryData] = this.lotteryData, r.default.Log("准备保存数据到服务器", e), a.default.saveData(JSON.stringify(e), function (e) {}), r.default.UploadUserScore(d.default.instance.tcoin.toFixed()), [2]
                                    }
                                })
                            })
                        }, e.prototype.SaveLocalData = function () {
                            return i(this, void 0, void 0, function () {
                                var e = this;
                                return o(this, function (t) {
                                    switch (t.label) {
                                        case 0:
                                            return [4, this.GetNow(!0).then(function (t) {
                                                e.SaveLastDate(t)
                                            })];
                                        case 1:
                                            return t.sent(), d.default.instance.SaveEconomic(), [2]
                                    }
                                })
                            })
                        }, e.prototype.ScheduleSaveData = function () {
                            var e = this;
                            Laya.timer.loop(3e4, this, function () {
                                e.SaveLocalData()
                            }), Laya.timer.loop(12e4, this, function () {
                                e.SaveDataToServer()
                            })
                        }, e.prototype.GetNow = function (e) {
                            return void 0 === e && (e = !1), i(this, void 0, void 0, function () {
                                return o(this, function (t) {
                                    return e ? [2, L.default.getSmartServerTime()] : [2, Date.now()]
                                })
                            })
                        }, e.prototype.SaveLastDate = function (e) {
                            this.lastDate = e, u.default.setItem(s.default.day, this.lastDate)
                        }, e.prototype.CopyObj = function (e, t) {
                            if (t)
                                for (var n in t) {
                                    var i = t[n];
                                    void 0 !== i && (e[n] = i)
                                }
                        }, e.prototype.LoadPropData = function () {
                            if (null == this.propData) {
                                var e = u.default.getItem(s.default.propData);
                                this.propData = new y.default, e && this.CopyObj(this.propData, JSON.parse(e))
                            }
                        }, e.prototype.SetPropData = function (e) {
                            this.propData = new y.default, this.CopyObj(this.propData, e), this.SavePropData()
                        }, e.prototype.SavePropData = function () {
                            this.propData && u.default.setItem(s.default.propData, JSON.stringify(this.propData))
                        }, e.prototype.LoadGameData = function () {
                            if (null == this.gameData) {
                                var e = u.default.getItem(s.default.gameData);
                                this.gameData = new h.default, e && this.CopyObj(this.gameData, JSON.parse(e))
                            }
                        }, e.prototype.SetGameData = function (e) {
                            this.gameData = new h.default, this.CopyObj(this.gameData, e), this.SaveGameData()
                        }, e.prototype.SaveGameData = function () {
                            this.gameData && u.default.setItem(s.default.gameData, JSON.stringify(this.gameData))
                        }, e.prototype.LoadSkinData = function () {
                            if (null == this.skinData) {
                                var e = u.default.getItem(s.default.skinData);
                                this.skinData = new _.default, e && this.CopyObj(this.skinData, JSON.parse(e))
                            }
                        }, e.prototype.SetSkinData = function (e) {
                            this.skinData = new _.default, this.CopyObj(this.skinData, e), this.SaveSkinData()
                        }, e.prototype.SaveSkinData = function () {
                            this.skinData && u.default.setItem(s.default.skinData, JSON.stringify(this.skinData))
                        }, e.prototype.LoadMergeData = function () {
                            if (null == this.mergeData) {
                                var e = u.default.getItem(s.default.mergeData);
                                this.mergeData = g.default.createFromString(e)
                            }
                        }, e.prototype.SetMergeData = function (e) {
                            this.mergeData = g.default.createFromString(e), this.SaveMergeData()
                        }, e.prototype.SaveMergeData = function () {
                            this.mergeData && Laya.timer.callLater(u.default, u.default.setItem, [s.default.mergeData, this.mergeData.toSvString()])
                        }, e.prototype.LoadLotteryData = function () {
                            if (null == this.lotteryData) {
                                var e = u.default.getItem(s.default.lotteryData);
                                this.lotteryData = new m.default, e && this.CopyObj(this.lotteryData, JSON.parse(e))
                            }
                        }, e.prototype.SetLotteryData = function (e) {
                            this.lotteryData = new m.default, this.CopyObj(this.lotteryData, e), this.SaveLotteryData()
                        }, e.prototype.SaveLotteryData = function () {
                            this.lotteryData && u.default.setItem(s.default.lotteryData, JSON.stringify(this.lotteryData))
                        }, e
                    }();
                n.default = w
            }, {
                "../Common/DataID": 1,
                "../ads/AdsLogic": 5,
                "../core/DataStorage": 22,
                "../core/GameHelper": 23,
                "../core/RewardLogic": 27,
                "../core/Server": 28,
                "../core/TimeMgr": 30,
                "../libs/bignumber": 39,
                "../logic/CollectLogic": 41,
                "../logic/EconomicLogic": 43,
                "../logic/GameLogic": 44,
                "../sound/SoundMgr": 96,
                "./GameSvData": 33,
                "./LotterySvData": 34,
                "./MergeSvData": 35,
                "./PropSvData": 36,
                "./SkinSvData": 38
            }],
            33: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    this.maxLen = 0, this.cumulateLen = 0, this.championTimes = 0, this.offlineTime = 0, this.signTimes = 0, this.signDate = -1, this.loginDate = -1, this.videoTimes = 0, this.freeCoinTimes = 0, this.freeDiamTimes = 0, this.gameGuide = 0, this.freeGuide = 0, this.mergeGuide = 0, this.skinGuide = 0, this.boughtGuide = 0
                };
                n.default = i
            }, {}],
            34: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../common/EventID"),
                    o = function () {
                        function e() {
                            this._tickets = "", this._get_tickets = "", this.next_time = 0, this._balloon_times = ""
                        }
                        return Object.defineProperty(e.prototype, "tickets", {
                            get: function () {
                                return Number((this._tickets || "").split("_")[1]) || 0
                            },
                            set: function (e) {
                                this._tickets = "_" + e.toFixed() + "_", Laya.stage && Laya.timer.callLater(Laya.stage, Laya.stage.event, [i.default.TICKETS_CHANGED])
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "get_tickets", {
                            get: function () {
                                return Number((this._get_tickets || "").split("_")[1]) || 0
                            },
                            set: function (e) {
                                this._get_tickets = "_" + e.toFixed() + "_", Laya.stage && Laya.timer.callLater(Laya.stage, Laya.stage.event, [i.default.TICKETS_CHANGED])
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "balloon_times", {
                            get: function () {
                                return Number((this._balloon_times || "").split("_")[1]) || 0
                            },
                            set: function (e) {
                                this._balloon_times = "_" + e.toFixed() + "_"
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.toJSON = function () {
                            return {
                                tickets: this.tickets,
                                get_tickets: this.get_tickets,
                                next_time: this.next_time,
                                balloon_times: this.balloon_times
                            }
                        }, e
                    }();
                n.default = o
            }, {
                "../common/EventID": 15
            }],
            35: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {
                        this.level = 0, this.itemList = [], this.coinsTimes = {}, this.diamondsTimes = {}
                    }
                    return e.createFromString = function (t) {
                        var n = new e;
                        return t && n.loadFromSvString(t), n
                    }, e.prototype.loadFromSvString = function (e) {
                        var t = this,
                            n = null;
                        try {
                            n = JSON.parse(e)
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), console.e("载入合成数据解析出错: ", e), n = null
                        }
                        n && (n.il = n.il || "", this.itemList = n.il.split(";").map(function (e) {
                            var t = e.split("_");
                            return t.length > 1 ? {
                                level: parseInt(t[0]) || 0,
                                index: parseInt(t[1]) || 0
                            } : null
                        }).filter(function (e) {
                            return e
                        }), n.ct = n.ct || "", this.coinsTimes = {}, n.ct.split(";").forEach(function (e) {
                            var n = e.split("_");
                            if (n.length > 1) {
                                var i = parseInt(n[0]) || 0,
                                    o = parseInt(n[1]) || 0;
                                o && (t.coinsTimes[i] = o)
                            }
                        }), n.dt = n.dt || "", this.diamondsTimes = {}, n.dt.split(";").forEach(function (e) {
                            var n = e.split("_");
                            if (n.length > 1) {
                                var i = parseInt(n[0]) || 0,
                                    o = parseInt(n[1]) || 0;
                                o && (t.diamondsTimes[i] = o)
                            }
                        }), this.level = n.lv, this.itemList.forEach(function (e) {
                            e.level > t.level && (t.level = e.level)
                        }))
                    }, e.prototype.toSvString = function () {
                        var e = {
                            lv: this.level,
                            il: "",
                            ct: "",
                            dt: ""
                        };
                        for (var t in this.itemList.forEach(function (t, n) {
                                e.il += (n > 0 ? ";" : "") + t.level + "_" + t.index
                            }), this.coinsTimes)(n = this.coinsTimes[t]) && (e.ct += (e.ct ? ";" : "") + t + "_" + n);
                        for (var t in this.diamondsTimes) {
                            var n;
                            (n = this.diamondsTimes[t]) && (e.dt += (e.dt ? ";" : "") + t + "_" + n)
                        }
                        return JSON.stringify(e)
                    }, e
                }();
                n.default = i
            }, {}],
            36: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    this.initLenLv = 0, this.speedLv = 0, this.offlineLv = 0, this.freeUpLenTimes = 0, this.freeUpSpeedTimes = 0, this.freeUpOffTimes = 0
                };
                n.default = i
            }, {}],
            37: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    this.isMusicOn = 1, this.isSoundOn = 1, this.isVibrateOn = 1
                };
                n.default = i
            }, {}],
            38: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    this.useId1 = 1
                };
                n.default = i
            }, {}],
            39: [function (e, t, n) {
                ! function (e) {
                    "use strict";

                    function n(e) {
                        var t = 0 | e;
                        return e > 0 || e === t ? t : t - 1
                    }

                    function i(e) {
                        for (var t, n, i = 1, o = e.length, a = e[0] + ""; i < o;) {
                            for (t = e[i++] + "", n = y - t.length; n--; t = "0" + t);
                            a += t
                        }
                        for (o = a.length; 48 === a.charCodeAt(--o););
                        return a.slice(0, o + 1 || 1)
                    }

                    function o(e, t) {
                        var n, i, o = e.c,
                            a = t.c,
                            r = e.s,
                            s = t.s,
                            l = e.e,
                            c = t.e;
                        if (!r || !s) return null;
                        if (n = o && !o[0], i = a && !a[0], n || i) return n ? i ? 0 : -s : r;
                        if (r != s) return r;
                        if (n = r < 0, i = l == c, !o || !a) return i ? 0 : !o ^ n ? 1 : -1;
                        if (!i) return l > c ^ n ? 1 : -1;
                        for (s = (l = o.length) < (c = a.length) ? l : c, r = 0; r < s; r++)
                            if (o[r] != a[r]) return o[r] > a[r] ^ n ? 1 : -1;
                        return l == c ? 0 : l > c ^ n ? 1 : -1
                    }

                    function a(e, t, n, i) {
                        if (e < t || e > n || e !== (e < 0 ? d(e) : h(e))) throw Error(f + (i || "Argument") + ("number" == typeof e ? e < t || e > n ? " out of range: " : " not an integer: " : " not a primitive number: ") + String(e))
                    }

                    function r(e) {
                        var t = e.c.length - 1;
                        return n(e.e / y) == t && e.c[t] % 2 != 0
                    }

                    function s(e, t) {
                        return (e.length > 1 ? e.charAt(0) + "." + e.slice(1) : e) + (t < 0 ? "e" : "e+") + t
                    }

                    function l(e, t, n) {
                        var i, o;
                        if (t < 0) {
                            for (o = n + "."; ++t; o += n);
                            e = o + e
                        } else if (++t > (i = e.length)) {
                            for (o = n, t -= i; --t; o += n);
                            e += o
                        } else t < i && (e = e.slice(0, t) + "." + e.slice(t));
                        return e
                    }
                    var c, u = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i,
                        d = Math.ceil,
                        h = Math.floor,
                        f = "[BigNumber Error] ",
                        p = f + "Number primitive has more than 15 significant digits: ",
                        _ = 1e14,
                        y = 14,
                        g = 9007199254740991,
                        m = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13],
                        v = 1e7,
                        L = 1e9;
                    (c = function e(t) {
                        function c(e, t) {
                            var n, i, o, r, s, l, d, f, _ = this;
                            if (!(_ instanceof c)) return new c(e, t);
                            if (null == t) {
                                if (e instanceof c) return _.s = e.s, _.e = e.e, void(_.c = (e = e.c) ? e.slice() : e);
                                if ((l = "number" == typeof e) && 0 * e == 0) {
                                    if (_.s = 1 / e < 0 ? (e = -e, -1) : 1, e === ~~e) {
                                        for (r = 0, s = e; s >= 10; s /= 10, r++);
                                        return _.e = r, void(_.c = [e])
                                    }
                                    f = String(e)
                                } else {
                                    if (f = String(e), !u.test(f)) return M(_, f, l);
                                    _.s = 45 == f.charCodeAt(0) ? (f = f.slice(1), -1) : 1
                                }(r = f.indexOf(".")) > -1 && (f = f.replace(".", "")), (s = f.search(/e/i)) > 0 ? (r < 0 && (r = s), r += +f.slice(s + 1), f = f.substring(0, s)) : r < 0 && (r = f.length)
                            } else {
                                if (a(t, 2, z.length, "Base"), f = String(e), 10 == t) return A(_ = new c(e instanceof c ? e : f), N + _.e + 1, G);
                                if (l = "number" == typeof e) {
                                    if (0 * e != 0) return M(_, f, l, t);
                                    if (_.s = 1 / e < 0 ? (f = f.slice(1), -1) : 1, c.DEBUG && f.replace(/^0\.0*|\./, "").length > 15) throw Error(p + e);
                                    l = !1
                                } else _.s = 45 === f.charCodeAt(0) ? (f = f.slice(1), -1) : 1;
                                for (n = z.slice(0, t), r = s = 0, d = f.length; s < d; s++)
                                    if (n.indexOf(i = f.charAt(s)) < 0) {
                                        if ("." == i) {
                                            if (s > r) {
                                                r = d;
                                                continue
                                            }
                                        } else if (!o && (f == f.toUpperCase() && (f = f.toLowerCase()) || f == f.toLowerCase() && (f = f.toUpperCase()))) {
                                            o = !0, s = -1, r = 0;
                                            continue
                                        }
                                        return M(_, String(e), l, t)
                                    }(r = (f = k(f, t, 10, _.s)).indexOf(".")) > - 1 ? f = f.replace(".", "") : r = f.length
                            }
                            for (s = 0; 48 === f.charCodeAt(s); s++);
                            for (d = f.length; 48 === f.charCodeAt(--d););
                            if (f = f.slice(s, ++d)) {
                                if (d -= s, l && c.DEBUG && d > 15 && (e > g || e !== h(e))) throw Error(p + _.s * e);
                                if ((r = r - s - 1) > H) _.c = _.e = null;
                                else if (r < F) _.c = [_.e = 0];
                                else {
                                    if (_.e = r, _.c = [], s = (r + 1) % y, r < 0 && (s += y), s < d) {
                                        for (s && _.c.push(+f.slice(0, s)), d -= y; s < d;) _.c.push(+f.slice(s, s += y));
                                        f = f.slice(s), s = y - f.length
                                    } else s -= d;
                                    for (; s--; f += "0");
                                    _.c.push(+f)
                                }
                            } else _.c = [_.e = 0]
                        }

                        function w(e, t, n, o) {
                            var r, u, d, h, f;
                            if (null == n ? n = G : a(n, 0, 8), !e.c) return e.toString();
                            if (r = e.c[0], d = e.e, null == t) f = i(e.c), f = 1 == o || 2 == o && d <= U ? s(f, d) : l(f, d, "0");
                            else if (u = (e = A(new c(e), t, n)).e, h = (f = i(e.c)).length, 1 == o || 2 == o && (t <= u || u <= U)) {
                                for (; h < t; f += "0", h++);
                                f = s(f, u)
                            } else if (t -= d, f = l(f, u, "0"), u + 1 > h) {
                                if (--t > 0)
                                    for (f += "."; t--; f += "0");
                            } else if ((t += u - h) > 0)
                                for (u + 1 == h && (f += "."); t--; f += "0");
                            return e.s < 0 && r ? "-" + f : f
                        }

                        function b(e, t) {
                            for (var n, i = 1, o = new c(e[0]); i < e.length; i++) {
                                if (!(n = new c(e[i])).s) {
                                    o = n;
                                    break
                                }
                                t.call(o, n) && (o = n)
                            }
                            return o
                        }

                        function S(e, t, n) {
                            for (var i = 1, o = t.length; !t[--o]; t.pop());
                            for (o = t[0]; o >= 10; o /= 10, i++);
                            return (n = i + n * y - 1) > H ? e.c = e.e = null : n < F ? e.c = [e.e = 0] : (e.e = n, e.c = t), e
                        }

                        function A(e, t, n, i) {
                            var o, a, r, s, l, c, u, f = e.c,
                                p = m;
                            if (f) {
                                e: {
                                    for (o = 1, s = f[0]; s >= 10; s /= 10, o++);
                                    if ((a = t - o) < 0) a += y,
                                    r = t,
                                    u = (l = f[c = 0]) / p[o - r - 1] % 10 | 0;
                                    else if ((c = d((a + 1) / y)) >= f.length) {
                                        if (!i) break e;
                                        for (; f.length <= c; f.push(0));
                                        l = u = 0, o = 1, r = (a %= y) - y + 1
                                    } else {
                                        for (l = s = f[c], o = 1; s >= 10; s /= 10, o++);
                                        u = (r = (a %= y) - y + o) < 0 ? 0 : l / p[o - r - 1] % 10 | 0
                                    }
                                    if (i = i || t < 0 || null != f[c + 1] || (r < 0 ? l : l % p[o - r - 1]), i = n < 4 ? (u || i) && (0 == n || n == (e.s < 0 ? 3 : 2)) : u > 5 || 5 == u && (4 == n || i || 6 == n && (a > 0 ? r > 0 ? l / p[o - r] : 0 : f[c - 1]) % 10 & 1 || n == (e.s < 0 ? 8 : 7)), t < 1 || !f[0]) return f.length = 0,
                                    i ? (t -= e.e + 1, f[0] = p[(y - t % y) % y], e.e = -t || 0) : f[0] = e.e = 0,
                                    e;
                                    if (0 == a ? (f.length = c, s = 1, c--) : (f.length = c + 1, s = p[y - a], f[c] = r > 0 ? h(l / p[o - r] % p[r]) * s : 0), i)
                                        for (;;) {
                                            if (0 == c) {
                                                for (a = 1, r = f[0]; r >= 10; r /= 10, a++);
                                                for (r = f[0] += s, s = 1; r >= 10; r /= 10, s++);
                                                a != s && (e.e++, f[0] == _ && (f[0] = 1));
                                                break
                                            }
                                            if (f[c] += s, f[c] != _) break;
                                            f[c--] = 0, s = 1
                                        }
                                    for (a = f.length; 0 === f[--a]; f.pop());
                                }
                                e.e > H ? e.c = e.e = null : e.e < F && (e.c = [e.e = 0])
                            }
                            return e
                        }

                        function I(e) {
                            var t, n = e.e;
                            return null === n ? e.toString() : (t = i(e.c), t = n <= U || n >= V ? s(t, n) : l(t, n, "0"), e.s < 0 ? "-" + t : t)
                        }
                        var C, k, M, E, T, D, O, P, x, B = c.prototype = {
                                constructor: c,
                                toString: null,
                                valueOf: null
                            },
                            R = new c(1),
                            N = 20,
                            G = 4,
                            U = -7,
                            V = 21,
                            F = -1e7,
                            H = 1e7,
                            j = !1,
                            W = 1,
                            Y = 0,
                            K = {
                                prefix: "",
                                groupSize: 3,
                                secondaryGroupSize: 0,
                                groupSeparator: ",",
                                decimalSeparator: ".",
                                fractionGroupSize: 0,
                                fractionGroupSeparator: " ",
                                suffix: ""
                            },
                            z = "0123456789abcdefghijklmnopqrstuvwxyz";
                        return c.clone = e, c.ROUND_UP = 0, c.ROUND_DOWN = 1, c.ROUND_CEIL = 2, c.ROUND_FLOOR = 3, c.ROUND_HALF_UP = 4, c.ROUND_HALF_DOWN = 5, c.ROUND_HALF_EVEN = 6, c.ROUND_HALF_CEIL = 7, c.ROUND_HALF_FLOOR = 8, c.EUCLID = 9, c.config = c.set = function (e) {
                            var t, n;
                            if (null != e) {
                                if ("object" != typeof e) throw Error(f + "Object expected: " + e);
                                if (e.hasOwnProperty(t = "DECIMAL_PLACES") && (a(n = e[t], 0, L, t), N = n), e.hasOwnProperty(t = "ROUNDING_MODE") && (a(n = e[t], 0, 8, t), G = n), e.hasOwnProperty(t = "EXPONENTIAL_AT") && ((n = e[t]) && n.pop ? (a(n[0], -L, 0, t), a(n[1], 0, L, t), U = n[0], V = n[1]) : (a(n, -L, L, t), U = -(V = n < 0 ? -n : n))), e.hasOwnProperty(t = "RANGE"))
                                    if ((n = e[t]) && n.pop) a(n[0], -L, -1, t), a(n[1], 1, L, t), F = n[0], H = n[1];
                                    else {
                                        if (a(n, -L, L, t), !n) throw Error(f + t + " cannot be zero: " + n);
                                        F = -(H = n < 0 ? -n : n)
                                    } if (e.hasOwnProperty(t = "CRYPTO")) {
                                    if ((n = e[t]) !== !!n) throw Error(f + t + " not true or false: " + n);
                                    if (n) {
                                        if ("undefined" == typeof crypto || !crypto || !crypto.getRandomValues && !crypto.randomBytes) throw j = !n, Error(f + "crypto unavailable");
                                        j = n
                                    } else j = n
                                }
                                if (e.hasOwnProperty(t = "MODULO_MODE") && (a(n = e[t], 0, 9, t), W = n), e.hasOwnProperty(t = "POW_PRECISION") && (a(n = e[t], 0, L, t), Y = n), e.hasOwnProperty(t = "FORMAT")) {
                                    if ("object" != typeof (n = e[t])) throw Error(f + t + " not an object: " + n);
                                    K = n
                                }
                                if (e.hasOwnProperty(t = "ALPHABET")) {
                                    if ("string" != typeof (n = e[t]) || /^.$|[+-.\s]|(.).*\1/.test(n)) throw Error(f + t + " invalid: " + n);
                                    z = n
                                }
                            }
                            return {
                                DECIMAL_PLACES: N,
                                ROUNDING_MODE: G,
                                EXPONENTIAL_AT: [U, V],
                                RANGE: [F, H],
                                CRYPTO: j,
                                MODULO_MODE: W,
                                POW_PRECISION: Y,
                                FORMAT: K,
                                ALPHABET: z
                            }
                        }, c.isBigNumber = function (e) {
                            return e instanceof c || e && !0 === e._isBigNumber || !1
                        }, c.maximum = c.max = function () {
                            return b(arguments, B.lt)
                        }, c.minimum = c.min = function () {
                            return b(arguments, B.gt)
                        }, c.random = (E = 9007199254740992 * Math.random() & 2097151 ? function () {
                            return h(9007199254740992 * Math.random())
                        } : function () {
                            return 8388608 * (1073741824 * Math.random() | 0) + (8388608 * Math.random() | 0)
                        }, function (e) {
                            var t, n, i, o, r, s = 0,
                                l = [],
                                u = new c(R);
                            if (null == e ? e = N : a(e, 0, L), o = d(e / y), j)
                                if (crypto.getRandomValues) {
                                    for (t = crypto.getRandomValues(new Uint32Array(o *= 2)); s < o;)(r = 131072 * t[s] + (t[s + 1] >>> 11)) >= 9e15 ? (n = crypto.getRandomValues(new Uint32Array(2)), t[s] = n[0], t[s + 1] = n[1]) : (l.push(r % 1e14), s += 2);
                                    s = o / 2
                                } else {
                                    if (!crypto.randomBytes) throw j = !1, Error(f + "crypto unavailable");
                                    for (t = crypto.randomBytes(o *= 7); s < o;)(r = 281474976710656 * (31 & t[s]) + 1099511627776 * t[s + 1] + 4294967296 * t[s + 2] + 16777216 * t[s + 3] + (t[s + 4] << 16) + (t[s + 5] << 8) + t[s + 6]) >= 9e15 ? crypto.randomBytes(7).copy(t, s) : (l.push(r % 1e14), s += 7);
                                    s = o / 7
                                } if (!j)
                                for (; s < o;)(r = E()) < 9e15 && (l[s++] = r % 1e14);
                            for (o = l[--s], e %= y, o && e && (r = m[y - e], l[s] = h(o / r) * r); 0 === l[s]; l.pop(), s--);
                            if (s < 0) l = [i = 0];
                            else {
                                for (i = -1; 0 === l[0]; l.splice(0, 1), i -= y);
                                for (s = 1, r = l[0]; r >= 10; r /= 10, s++);
                                s < y && (i -= y - s)
                            }
                            return u.e = i, u.c = l, u
                        }), c.sum = function () {
                            for (var e = 1, t = arguments, n = new c(t[0]); e < t.length;) n = n.plus(t[e++]);
                            return n
                        }, k = function () {
                            function e(e, t, n, i) {
                                for (var o, a, r = [0], s = 0, l = e.length; s < l;) {
                                    for (a = r.length; a--; r[a] *= t);
                                    for (r[0] += i.indexOf(e.charAt(s++)), o = 0; o < r.length; o++) r[o] > n - 1 && (null == r[o + 1] && (r[o + 1] = 0), r[o + 1] += r[o] / n | 0, r[o] %= n)
                                }
                                return r.reverse()
                            }
                            return function (t, n, o, a, r) {
                                var s, u, d, h, f, p, _, y, g = t.indexOf("."),
                                    m = N,
                                    v = G;
                                for (g >= 0 && (h = Y, Y = 0, t = t.replace(".", ""), p = (y = new c(n)).pow(t.length - g), Y = h, y.c = e(l(i(p.c), p.e, "0"), 10, o, "0123456789"), y.e = y.c.length), d = h = (_ = e(t, n, o, r ? (s = z, "0123456789") : (s = "0123456789", z))).length; 0 == _[--h]; _.pop());
                                if (!_[0]) return s.charAt(0);
                                if (g < 0 ? --d : (p.c = _, p.e = d, p.s = a, _ = (p = C(p, y, m, v, o)).c, f = p.r, d = p.e), g = _[u = d + m + 1], h = o / 2, f = f || u < 0 || null != _[u + 1], f = v < 4 ? (null != g || f) && (0 == v || v == (p.s < 0 ? 3 : 2)) : g > h || g == h && (4 == v || f || 6 == v && 1 & _[u - 1] || v == (p.s < 0 ? 8 : 7)), u < 1 || !_[0]) t = f ? l(s.charAt(1), -m, s.charAt(0)) : s.charAt(0);
                                else {
                                    if (_.length = u, f)
                                        for (--o; ++_[--u] > o;) _[u] = 0, u || (++d, _ = [1].concat(_));
                                    for (h = _.length; !_[--h];);
                                    for (g = 0, t = ""; g <= h; t += s.charAt(_[g++]));
                                    t = l(t, d, s.charAt(0))
                                }
                                return t
                            }
                        }(), C = function () {
                            function e(e, t, n) {
                                var i, o, a, r, s = 0,
                                    l = e.length,
                                    c = t % v,
                                    u = t / v | 0;
                                for (e = e.slice(); l--;) s = ((o = c * (a = e[l] % v) + (i = u * a + (r = e[l] / v | 0) * c) % v * v + s) / n | 0) + (i / v | 0) + u * r, e[l] = o % n;
                                return s && (e = [s].concat(e)), e
                            }

                            function t(e, t, n, i) {
                                var o, a;
                                if (n != i) a = n > i ? 1 : -1;
                                else
                                    for (o = a = 0; o < n; o++)
                                        if (e[o] != t[o]) {
                                            a = e[o] > t[o] ? 1 : -1;
                                            break
                                        } return a
                            }

                            function i(e, t, n, i) {
                                for (var o = 0; n--;) e[n] -= o, o = e[n] < t[n] ? 1 : 0, e[n] = o * i + e[n] - t[n];
                                for (; !e[0] && e.length > 1; e.splice(0, 1));
                            }
                            return function (o, a, r, s, l) {
                                var u, d, f, p, g, m, v, L, w, b, S, I, C, k, M, E, T, D = o.s == a.s ? 1 : -1,
                                    O = o.c,
                                    P = a.c;
                                if (!(O && O[0] && P && P[0])) return new c(o.s && a.s && (O ? !P || O[0] != P[0] : P) ? O && 0 == O[0] || !P ? 0 * D : D / 0 : NaN);
                                for (w = (L = new c(D)).c = [], D = r + (d = o.e - a.e) + 1, l || (l = _, d = n(o.e / y) - n(a.e / y), D = D / y | 0), f = 0; P[f] == (O[f] || 0); f++);
                                if (P[f] > (O[f] || 0) && d--, D < 0) w.push(1), p = !0;
                                else {
                                    for (k = O.length, E = P.length, f = 0, D += 2, (g = h(l / (P[0] + 1))) > 1 && (P = e(P, g, l), O = e(O, g, l), E = P.length, k = O.length), C = E, S = (b = O.slice(0, E)).length; S < E; b[S++] = 0);
                                    T = P.slice(), T = [0].concat(T), M = P[0], P[1] >= l / 2 && M++;
                                    do {
                                        if (g = 0, (u = t(P, b, E, S)) < 0) {
                                            if (I = b[0], E != S && (I = I * l + (b[1] || 0)), (g = h(I / M)) > 1)
                                                for (g >= l && (g = l - 1), v = (m = e(P, g, l)).length, S = b.length; 1 == t(m, b, v, S);) g--, i(m, E < v ? T : P, v, l), v = m.length, u = 1;
                                            else 0 == g && (u = g = 1), v = (m = P.slice()).length;
                                            if (v < S && (m = [0].concat(m)), i(b, m, S, l), S = b.length, -1 == u)
                                                for (; t(P, b, E, S) < 1;) g++, i(b, E < S ? T : P, S, l), S = b.length
                                        } else 0 === u && (g++, b = [0]);
                                        w[f++] = g, b[0] ? b[S++] = O[C] || 0 : (b = [O[C]], S = 1)
                                    } while ((C++ < k || null != b[0]) && D--);
                                    p = null != b[0], w[0] || w.splice(0, 1)
                                }
                                if (l == _) {
                                    for (f = 1, D = w[0]; D >= 10; D /= 10, f++);
                                    A(L, r + (L.e = f + d * y - 1) + 1, s, p)
                                } else L.e = d, L.r = +p;
                                return L
                            }
                        }(), T = /^(-?)0([xbo])(?=\w[\w.]*$)/i, D = /^([^.]+)\.$/, O = /^\.([^.]+)$/, P = /^-?(Infinity|NaN)$/, x = /^\s*\+(?=[\w.])|^\s+|\s+$/g, M = function (e, t, n, i) {
                            var o, a = n ? t : t.replace(x, "");
                            if (P.test(a)) e.s = isNaN(a) ? null : a < 0 ? -1 : 1, e.c = e.e = null;
                            else {
                                if (!n && (a = a.replace(T, function (e, t, n) {
                                        return o = "x" == (n = n.toLowerCase()) ? 16 : "b" == n ? 2 : 8, i && i != o ? e : t
                                    }), i && (o = i, a = a.replace(D, "$1").replace(O, "0.$1")), t != a)) return new c(a, o);
                                if (c.DEBUG) throw Error(f + "Not a" + (i ? " base " + i : "") + " number: " + t);
                                e.c = e.e = e.s = null
                            }
                        }, B.absoluteValue = B.abs = function () {
                            var e = new c(this);
                            return e.s < 0 && (e.s = 1), e
                        }, B.comparedTo = function (e, t) {
                            return o(this, new c(e, t))
                        }, B.decimalPlaces = B.dp = function (e, t) {
                            var i, o, r, s = this;
                            if (null != e) return a(e, 0, L), null == t ? t = G : a(t, 0, 8), A(new c(s), e + s.e + 1, t);
                            if (!(i = s.c)) return null;
                            if (o = ((r = i.length - 1) - n(this.e / y)) * y, r = i[r])
                                for (; r % 10 == 0; r /= 10, o--);
                            return o < 0 && (o = 0), o
                        }, B.dividedBy = B.div = function (e, t) {
                            return C(this, new c(e, t), N, G)
                        }, B.dividedToIntegerBy = B.idiv = function (e, t) {
                            return C(this, new c(e, t), 0, 1)
                        }, B.exponentiatedBy = B.pow = function (e, t) {
                            var n, i, o, a, s, l, u, p, _ = this;
                            if ((e = new c(e)).c && !e.isInteger()) throw Error(f + "Exponent not an integer: " + I(e));
                            if (null != t && (t = new c(t)), s = e.e > 14, !_.c || !_.c[0] || 1 == _.c[0] && !_.e && 1 == _.c.length || !e.c || !e.c[0]) return p = new c(Math.pow(+I(_), s ? 2 - r(e) : +I(e))), t ? p.mod(t) : p;
                            if (l = e.s < 0, t) {
                                if (t.c ? !t.c[0] : !t.s) return new c(NaN);
                                (i = !l && _.isInteger() && t.isInteger()) && (_ = _.mod(t))
                            } else {
                                if (e.e > 9 && (_.e > 0 || _.e < -1 || (0 == _.e ? _.c[0] > 1 || s && _.c[1] >= 24e7 : _.c[0] < 8e13 || s && _.c[0] <= 9999975e7))) return a = _.s < 0 && r(e) ? -0 : 0, _.e > -1 && (a = 1 / a), new c(l ? 1 / a : a);
                                Y && (a = d(Y / y + 2))
                            }
                            for (s ? (n = new c(.5), l && (e.s = 1), u = r(e)) : u = (o = Math.abs(+I(e))) % 2, p = new c(R);;) {
                                if (u) {
                                    if (!(p = p.times(_)).c) break;
                                    a ? p.c.length > a && (p.c.length = a) : i && (p = p.mod(t))
                                }
                                if (o) {
                                    if (0 === (o = h(o / 2))) break;
                                    u = o % 2
                                } else if (A(e = e.times(n), e.e + 1, 1), e.e > 14) u = r(e);
                                else {
                                    if (0 == (o = +I(e))) break;
                                    u = o % 2
                                }
                                _ = _.times(_), a ? _.c && _.c.length > a && (_.c.length = a) : i && (_ = _.mod(t))
                            }
                            return i ? p : (l && (p = R.div(p)), t ? p.mod(t) : a ? A(p, Y, G, void 0) : p)
                        }, B.integerValue = function (e) {
                            var t = new c(this);
                            return null == e ? e = G : a(e, 0, 8), A(t, t.e + 1, e)
                        }, B.isEqualTo = B.eq = function (e, t) {
                            return 0 === o(this, new c(e, t))
                        }, B.isFinite = function () {
                            return !!this.c
                        }, B.isGreaterThan = B.gt = function (e, t) {
                            return o(this, new c(e, t)) > 0
                        }, B.isGreaterThanOrEqualTo = B.gte = function (e, t) {
                            return 1 === (t = o(this, new c(e, t))) || 0 === t
                        }, B.isInteger = function () {
                            return !!this.c && n(this.e / y) > this.c.length - 2
                        }, B.isLessThan = B.lt = function (e, t) {
                            return o(this, new c(e, t)) < 0
                        }, B.isLessThanOrEqualTo = B.lte = function (e, t) {
                            return -1 === (t = o(this, new c(e, t))) || 0 === t
                        }, B.isNaN = function () {
                            return !this.s
                        }, B.isNegative = function () {
                            return this.s < 0
                        }, B.isPositive = function () {
                            return this.s > 0
                        }, B.isZero = function () {
                            return !!this.c && 0 == this.c[0]
                        }, B.minus = function (e, t) {
                            var i, o, a, r, s = this,
                                l = s.s;
                            if (t = (e = new c(e, t)).s, !l || !t) return new c(NaN);
                            if (l != t) return e.s = -t, s.plus(e);
                            var u = s.e / y,
                                d = e.e / y,
                                h = s.c,
                                f = e.c;
                            if (!u || !d) {
                                if (!h || !f) return h ? (e.s = -t, e) : new c(f ? s : NaN);
                                if (!h[0] || !f[0]) return f[0] ? (e.s = -t, e) : new c(h[0] ? s : 3 == G ? -0 : 0)
                            }
                            if (u = n(u), d = n(d), h = h.slice(), l = u - d) {
                                for ((r = l < 0) ? (l = -l, a = h) : (d = u, a = f), a.reverse(), t = l; t--; a.push(0));
                                a.reverse()
                            } else
                                for (o = (r = (l = h.length) < (t = f.length)) ? l : t, l = t = 0; t < o; t++)
                                    if (h[t] != f[t]) {
                                        r = h[t] < f[t];
                                        break
                                    } if (r && (a = h, h = f, f = a, e.s = -e.s), (t = (o = f.length) - (i = h.length)) > 0)
                                for (; t--; h[i++] = 0);
                            for (t = _ - 1; o > l;) {
                                if (h[--o] < f[o]) {
                                    for (i = o; i && !h[--i]; h[i] = t);
                                    --h[i], h[o] += _
                                }
                                h[o] -= f[o]
                            }
                            for (; 0 == h[0]; h.splice(0, 1), --d);
                            return h[0] ? S(e, h, d) : (e.s = 3 == G ? -1 : 1, e.c = [e.e = 0], e)
                        }, B.modulo = B.mod = function (e, t) {
                            var n, i, o = this;
                            return e = new c(e, t), !o.c || !e.s || e.c && !e.c[0] ? new c(NaN) : !e.c || o.c && !o.c[0] ? new c(o) : (9 == W ? (i = e.s, e.s = 1, n = C(o, e, 0, 3), e.s = i, n.s *= i) : n = C(o, e, 0, W), (e = o.minus(n.times(e))).c[0] || 1 != W || (e.s = o.s), e)
                        }, B.multipliedBy = B.times = function (e, t) {
                            var i, o, a, r, s, l, u, d, h, f, p, g, m, L, w, b = this,
                                A = b.c,
                                I = (e = new c(e, t)).c;
                            if (!(A && I && A[0] && I[0])) return !b.s || !e.s || A && !A[0] && !I || I && !I[0] && !A ? e.c = e.e = e.s = null : (e.s *= b.s, A && I ? (e.c = [0], e.e = 0) : e.c = e.e = null), e;
                            for (o = n(b.e / y) + n(e.e / y), e.s *= b.s, (u = A.length) < (f = I.length) && (m = A, A = I, I = m, a = u, u = f, f = a), a = u + f, m = []; a--; m.push(0));
                            for (L = _, w = v, a = f; --a >= 0;) {
                                for (i = 0, p = I[a] % w, g = I[a] / w | 0, r = a + (s = u); r > a;) i = ((d = p * (d = A[--s] % w) + (l = g * d + (h = A[s] / w | 0) * p) % w * w + m[r] + i) / L | 0) + (l / w | 0) + g * h, m[r--] = d % L;
                                m[r] = i
                            }
                            return i ? ++o : m.splice(0, 1), S(e, m, o)
                        }, B.negated = function () {
                            var e = new c(this);
                            return e.s = -e.s || null, e
                        }, B.plus = function (e, t) {
                            var i, o = this,
                                a = o.s;
                            if (t = (e = new c(e, t)).s, !a || !t) return new c(NaN);
                            if (a != t) return e.s = -t, o.minus(e);
                            var r = o.e / y,
                                s = e.e / y,
                                l = o.c,
                                u = e.c;
                            if (!r || !s) {
                                if (!l || !u) return new c(a / 0);
                                if (!l[0] || !u[0]) return u[0] ? e : new c(l[0] ? o : 0 * a)
                            }
                            if (r = n(r), s = n(s), l = l.slice(), a = r - s) {
                                for (a > 0 ? (s = r, i = u) : (a = -a, i = l), i.reverse(); a--; i.push(0));
                                i.reverse()
                            }
                            for ((a = l.length) - (t = u.length) < 0 && (i = u, u = l, l = i, t = a), a = 0; t;) a = (l[--t] = l[t] + u[t] + a) / _ | 0, l[t] = _ === l[t] ? 0 : l[t] % _;
                            return a && (l = [a].concat(l), ++s), S(e, l, s)
                        }, B.precision = B.sd = function (e, t) {
                            var n, i, o, r = this;
                            if (null != e && e !== !!e) return a(e, 1, L), null == t ? t = G : a(t, 0, 8), A(new c(r), e, t);
                            if (!(n = r.c)) return null;
                            if (i = (o = n.length - 1) * y + 1, o = n[o]) {
                                for (; o % 10 == 0; o /= 10, i--);
                                for (o = n[0]; o >= 10; o /= 10, i++);
                            }
                            return e && r.e + 1 > i && (i = r.e + 1), i
                        }, B.shiftedBy = function (e) {
                            return a(e, -g, g), this.times("1e" + e)
                        }, B.squareRoot = B.sqrt = function () {
                            var e, t, o, a, r, s = this,
                                l = s.c,
                                u = s.s,
                                d = s.e,
                                h = N + 4,
                                f = new c("0.5");
                            if (1 !== u || !l || !l[0]) return new c(!u || u < 0 && (!l || l[0]) ? NaN : l ? s : 1 / 0);
                            if (0 == (u = Math.sqrt(+I(s))) || u == 1 / 0 ? (((t = i(l)).length + d) % 2 == 0 && (t += "0"), u = Math.sqrt(+t), d = n((d + 1) / 2) - (d < 0 || d % 2), o = new c(t = u == 1 / 0 ? "1e" + d : (t = u.toExponential()).slice(0, t.indexOf("e") + 1) + d)) : o = new c(u + ""), o.c[0])
                                for ((u = (d = o.e) + h) < 3 && (u = 0);;)
                                    if (r = o, o = f.times(r.plus(C(s, r, h, 1))), i(r.c).slice(0, u) === (t = i(o.c)).slice(0, u)) {
                                        if (o.e < d && --u, "9999" != (t = t.slice(u - 3, u + 1)) && (a || "4999" != t)) {
                                            +t && (+t.slice(1) || "5" != t.charAt(0)) || (A(o, o.e + N + 2, 1), e = !o.times(o).eq(s));
                                            break
                                        }
                                        if (!a && (A(r, r.e + N + 2, 0), r.times(r).eq(s))) {
                                            o = r;
                                            break
                                        }
                                        h += 4, u += 4, a = 1
                                    } return A(o, o.e + N + 1, G, e)
                        }, B.toExponential = function (e, t) {
                            return null != e && (a(e, 0, L), e++), w(this, e, t, 1)
                        }, B.toFixed = function (e, t) {
                            return null != e && (a(e, 0, L), e = e + this.e + 1), w(this, e, t)
                        }, B.toFormat = function (e, t, n) {
                            var i, o = this;
                            if (null == n) null != e && t && "object" == typeof t ? (n = t, t = null) : e && "object" == typeof e ? (n = e, e = t = null) : n = K;
                            else if ("object" != typeof n) throw Error(f + "Argument not an object: " + n);
                            if (i = o.toFixed(e, t), o.c) {
                                var a, r = i.split("."),
                                    s = +n.groupSize,
                                    l = +n.secondaryGroupSize,
                                    c = n.groupSeparator || "",
                                    u = r[0],
                                    d = r[1],
                                    h = o.s < 0,
                                    p = h ? u.slice(1) : u,
                                    _ = p.length;
                                if (l && (a = s, s = l, l = a, _ -= a), s > 0 && _ > 0) {
                                    for (a = _ % s || s, u = p.substr(0, a); a < _; a += s) u += c + p.substr(a, s);
                                    l > 0 && (u += c + p.slice(a)), h && (u = "-" + u)
                                }
                                i = d ? u + (n.decimalSeparator || "") + ((l = +n.fractionGroupSize) ? d.replace(new RegExp("\\d{" + l + "}\\B", "g"), "$&" + (n.fractionGroupSeparator || "")) : d) : u
                            }
                            return (n.prefix || "") + i + (n.suffix || "")
                        }, B.toFraction = function (e) {
                            var t, n, o, a, r, s, l, u, d, h, p, _, g = this,
                                v = g.c;
                            if (null != e && (!(l = new c(e)).isInteger() && (l.c || 1 !== l.s) || l.lt(R))) throw Error(f + "Argument " + (l.isInteger() ? "out of range: " : "not an integer: ") + I(l));
                            if (!v) return new c(g);
                            for (t = new c(R), d = n = new c(R), o = u = new c(R), _ = i(v), r = t.e = _.length - g.e - 1, t.c[0] = m[(s = r % y) < 0 ? y + s : s], e = !e || l.comparedTo(t) > 0 ? r > 0 ? t : d : l, s = H, H = 1 / 0, l = new c(_), u.c[0] = 0; h = C(l, t, 0, 1), 1 != (a = n.plus(h.times(o))).comparedTo(e);) n = o, o = a, d = u.plus(h.times(a = d)), u = a, t = l.minus(h.times(a = t)), l = a;
                            return a = C(e.minus(n), o, 0, 1), u = u.plus(a.times(d)), n = n.plus(a.times(o)), u.s = d.s = g.s, p = C(d, o, r *= 2, G).minus(g).abs().comparedTo(C(u, n, r, G).minus(g).abs()) < 1 ? [d, o] : [u, n], H = s, p
                        }, B.toNumber = function () {
                            return +I(this)
                        }, B.toPrecision = function (e, t) {
                            return null != e && a(e, 1, L), w(this, e, t, 2)
                        }, B.toString = function (e) {
                            var t, n = this,
                                o = n.s,
                                r = n.e;
                            return null === r ? o ? (t = "Infinity", o < 0 && (t = "-" + t)) : t = "NaN" : (t = i(n.c), null == e ? t = r <= U || r >= V ? s(t, r) : l(t, r, "0") : (a(e, 2, z.length, "Base"), t = k(l(t, r, "0"), 10, e, o, !0)), o < 0 && n.c[0] && (t = "-" + t)), t
                        }, B.valueOf = B.toJSON = function () {
                            return I(this)
                        }, B._isBigNumber = !0, "function" == typeof Symbol && "symbol" == typeof Symbol.iterator && (B[Symbol.toStringTag] = "BigNumber", B[Symbol.for("nodejs.util.inspect.custom")] = B.valueOf), null != t && c.set(t), c
                    }()).default = c.BigNumber = c, "function" == typeof define && define.amd ? define(function () {
                        return c
                    }) : void 0 !== t && t.exports ? t.exports = c : (e || (e = "undefined" != typeof self && self ? self : window), e.BigNumber = c)
                }(this)
            }, {}],
            40: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, o, a = e("../core/MathUtil"),
                    r = e("../core/RewardLogic"),
                    s = e("../core/ShareLogic"),
                    l = e("../data/DataBus"),
                    c = e("../common/EventID"),
                    u = e("./DialogLogic"),
                    d = e("../common/SceneID"),
                    h = e("./MergeLogic"),
                    f = e("../platform/yt"),
                    p = function () {
                        function e() {
                            this._needBalloon = !1
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "needBalloon", {
                            get: function () {
                                return this._needBalloon
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.updateBalloon = function () {
                            if (this._needBalloon) this._checkBalloon();
                            else {
                                var e = a.default.Random(15, 30);
                                console.log(e + "秒后, 尝试显示气球"), Laya.timer.clear(this, this._checkBalloon), Laya.timer.once(1e3 * e, this, this._checkBalloon)
                            }
                        }, e.prototype._checkBalloon = function () {
                            var e = this.__checkBalloon();
                            return e ? (this._cancelListener(), this._needBalloon = !0, Laya.stage.event(c.default.BALLOON_CHANGED, this._needBalloon)) : (this._addListener(), this._needBalloon = !1, Laya.stage.event(c.default.BALLOON_CHANGED, this._needBalloon)), e
                        }, e.prototype.__checkBalloon = function () {
                            var e = null != f.default.conf.balloon && parseInt(f.default.conf.balloon) >= 0,
                                t = r.default.instance.ShareOrVideo(s.ShareTypeEnum.BALLOON),
                                n = t == r.RewardMethodEnum.SHARE || t == r.RewardMethodEnum.VIDEO,
                                i = null != f.default.conf.balloon_times ? parseInt(f.default.conf.balloon_times) || 0 : 10,
                                o = l.default.instance.lotteryData.balloon_times || 0,
                                a = o < i,
                                c = e && n && a;
                            return console.log("[气球]尝试显示: 条件: 开关: " + e + ", 有视频或分享: " + n + ", 次数(" + o + ")小于下发/取值(" + f.default.conf.balloon_times + "/" + i + "): " + a + ", 是否显示气球: " + c), c
                        }, e.prototype._addListener = function () {
                            console.log("[气球]开始监听事件"), Laya.stage.off(c.default.VIDEO_CHANGED, this, this.updateBalloon), Laya.stage.on(c.default.VIDEO_CHANGED, this, this.updateBalloon)
                        }, e.prototype._cancelListener = function () {
                            console.log("[气球]取消监听事件"), Laya.stage.off(c.default.VIDEO_CHANGED, this, this.updateBalloon)
                        }, e.prototype.getPrize = function () {
                            var e = [i.Coins, i.Diamonds, i.Coins, i.Diamonds, i.Snake],
                                t = l.default.instance.lotteryData.balloon_times || 0,
                                n = t % e.length,
                                o = Math.floor(t / e.length) % 2,
                                a = e[n];
                            a == i.Snake && h.default.instance.isFull() && (a = e[o % 2]);
                            var r = 0;
                            switch (a) {
                                case i.Coins:
                                    var s = h.default.instance.getCoinsLevel();
                                    r = (d = h.default.instance.getOriginCoinsPrice(s)) / 6;
                                    var c = 2 * o + (n >= 4 ? 2 : n >= 2 ? 1 : 0);
                                    r = Math.round(r * (1 + .05 * c));
                                    break;
                                case i.Diamonds:
                                    var u = h.default.instance.getDiamondsLevel(),
                                        d = h.default.instance.getOriginDiamondsPrice(u);
                                    r = Math.max(1, Math.floor(d / 6)), c = 2 * o + (n >= 4 ? 2 : n >= 2 ? 1 : 0), r = Math.round(r * (1 + .05 * c));
                                    break;
                                case i.Snake:
                                    var f = h.default.instance.getCoinsLevel() - 2 + o;
                                    r = Math.max(1, f)
                            }
                            return {
                                type: a,
                                value: r
                            }
                        }, e.prototype.showBalloonLayer = function () {
                            this._needBalloon = !1, Laya.stage.event(c.default.BALLOON_CHANGED, this._needBalloon), u.default.instance.showDialogUnique(d.default.Balloon)
                        }, e._instance = null, e
                    }();
                n.default = p, o = i = n.BalloonPrizeType || (n.BalloonPrizeType = {}), o[o.Coins = 0] = "Coins", o[o.Diamonds = 1] = "Diamonds", o[o.Snake = 2] = "Snake"
            }, {
                "../common/EventID": 15,
                "../common/SceneID": 17,
                "../core/MathUtil": 24,
                "../core/RewardLogic": 27,
                "../core/ShareLogic": 29,
                "../data/DataBus": 32,
                "../platform/yt": 63,
                "./DialogLogic": 42,
                "./MergeLogic": 47
            }],
            41: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, o, a = e("../Core/DataStorage"),
                    r = e("../Common/DataID");
                o = i = n.CollectStateEnum || (n.CollectStateEnum = {}), o[o.NO = 0] = "NO", o[o.COLLECTED = 1] = "COLLECTED", o[o.GET = 2] = "GET";
                var s = function () {
                    function e() {}
                    return Object.defineProperty(e, "instance", {
                        get: function () {
                            return this._instance || (this._instance = new e), this._instance
                        },
                        enumerable: !0,
                        configurable: !0
                    }), e.prototype.getCollectState = function () {
                        this.collectState || (this.collectState = a.default.getIntItem(r.default.collectState, i.NO))
                    }, e.prototype.SaveCollectState = function () {
                        a.default.setItem(r.default.collectState, this.collectState)
                    }, e.prototype.GetCollectReward = function () {
                        e.instance.collectState, i.COLLECTED
                    }, e.prototype.appear = function () {}, e.prototype.pendular = function (e) {}, e.RewardDiamond = 1200, e
                }();
                n.default = s
            }, {
                "../Common/DataID": 1,
                "../Core/DataStorage": 2
            }],
            42: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./GameLogic"),
                    o = e("../view/LobbyView"),
                    a = function () {
                        function e() {
                            this._queue = []
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.showDialog = function (e, t) {
                            this._showDialog(e, t, null)
                        }, e.prototype.showDialogQueue = function (e, t) {
                            var n = {
                                url: e,
                                param: t,
                                instance: null
                            };
                            this._queue.push(n), 1 == this._queue.length && this._showDialog(e, t, n)
                        }, e.prototype.insertDialogAfter = function (e, t, n) {
                            for (var i = {
                                    url: e,
                                    param: n,
                                    instance: null
                                }, o = 1, a = this._queue.length - 1; a >= 0; --a) {
                                var r = this._queue[a];
                                if (r.url == t || r.instance) {
                                    o = a + 1;
                                    break
                                }
                            }
                            this._queue.splice(o, 0, i), 1 == this._queue.length && this._showDialog(e, n, i)
                        }, e.prototype.showDialogUnique = function (e, t) {
                            this._queue.findIndex(function (t) {
                                return t.url == e
                            }) > -1 || this.showDialogQueue(e, t)
                        }, e.prototype._showDialog = function (e, t, n) {
                            Laya.Scene.open(e, !1, t, Laya.Handler.create(this, this._onDialogLoaded, [n])), i.default.instance.HideAllWxBtn()
                        }, e.prototype._onDialogLoaded = function (e, t) {
                            e && (e.instance = t), t.on(Laya.Event.REMOVED, this, this._onDialogRemoved, [t])
                        }, e.prototype._onDialogRemoved = function (e) {
                            var t = this._queue.findIndex(function (t) {
                                return t.instance == e
                            });
                            if (t > -1 && this._queue.splice(t, 1), this._queue.length > 0) {
                                var n = this._queue[0];
                                n.instance || this._showDialog(n.url, n.param, n)
                            } else o.default.instance && i.default.instance.ShowAllWxBtn()
                        }, e._instance = null, e
                    }();
                n.default = a
            }, {
                "../view/LobbyView": 106,
                "./GameLogic": 44
            }],
            43: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a, r = e("../common/EventID"),
                    s = e("../core/DataStorage"),
                    l = e("../Common/DataID"),
                    c = e("../libs/bignumber"),
                    u = e("../common/SceneID");
                a = n.EconomicTypeEnum || (n.EconomicTypeEnum = {}), a[a.COIN = 1] = "COIN";
                var d = function (e) {
                    function t() {
                        var t = null !== e && e.apply(this, arguments) || this;
                        return t._coin = "", t._tcoin = "", t._maxCoin = "", t._diamond = "", t
                    }
                    return o(t, e), Object.defineProperty(t, "instance", {
                        get: function () {
                            return null == this._instance && (this._instance = new t), this._instance
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "coin", {
                        get: function () {
                            var e = new c.default((this._coin || "").split("_")[1] || 0);
                            return e.isNaN() ? new c.default(0) : e
                        },
                        set: function (e) {
                            this._coin = "_" + e.toFixed() + "_", this.event(r.default.COIN_CHANGED)
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "tcoin", {
                        get: function () {
                            var e = new c.default((this._tcoin || "").split("_")[1] || 0);
                            return e.isNaN() ? new c.default(0) : e
                        },
                        set: function (e) {
                            this._tcoin = "_" + e.toFixed() + "_"
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "maxCoin", {
                        get: function () {
                            var e = new c.default((this._maxCoin || "").split("_")[1] || 0);
                            return e.isNaN() ? new c.default(0) : e
                        },
                        set: function (e) {
                            this._maxCoin = "_" + e.toFixed() + "_"
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "diamond", {
                        get: function () {
                            var e = new c.default((this._diamond || "").split("_")[1] || 0);
                            return e.isNaN() ? new c.default(0) : e
                        },
                        set: function (e) {
                            this._diamond = "_" + e.toFixed() + "_", this.event(r.default.DIAMOND_CHANGED)
                        },
                        enumerable: !0,
                        configurable: !0
                    }), t.prototype.SetEcoData = function (e, t, n, i) {
                        this.coin = e, this.tcoin = t, this.diamond = n, this.maxCoin = i, this.SaveEconomic()
                    }, t.prototype.SaveEconomic = function () {
                        s.default.setItem(l.default.coin, this.coin.toString()), s.default.setItem(l.default.tcoin, this.tcoin.toString()), s.default.setItem(l.default.diamond, this.diamond.toString()), s.default.setItem(l.default.maxCoin, this.maxCoin.toString())
                    }, t.prototype.SaveCoin = function () {
                        s.default.setItem(l.default.coin, this.coin.toString()), s.default.setItem(l.default.tcoin, this.tcoin.toString())
                    }, t.prototype.SaveMaxCoin = function () {
                        s.default.setItem(l.default.maxCoin, this.maxCoin.toString())
                    }, t.prototype.SaveDiamond = function () {
                        s.default.setItem(l.default.diamond, this.diamond.toString())
                    }, t.prototype.SetMaxCoin = function (e) {
                        this.maxCoin.lt(e) && (this.maxCoin = new c.default(e), this.SaveMaxCoin())
                    }, t.prototype.AddCoin = function (e) {
                        0 != e && (this.coin = this.coin.plus(e), this.tcoin = this.tcoin.plus(e))
                    }, t.prototype.AddCoinWithAnimation = function (e, n) {
                        0 != e && Laya.Scene.open(u.default.GoldAnim, !1, {
                            onNext: function () {
                                t.instance.AddCoin(e), t.instance.SaveCoin(), n && n()
                            }
                        })
                    }, t.prototype.SubCoin = function (e) {
                        0 != e && (this.coin = this.coin.minus(e))
                    }, t.prototype.AddDiamond = function (e) {
                        e && (this.diamond = this.diamond.plus(e))
                    }, t.prototype.AddDiamondWithAnimation = function (e, n) {
                        0 != e && Laya.Scene.open(u.default.DiamondsAnim, !1, {
                            onNext: function () {
                                t.instance.AddDiamond(e), t.instance.SaveDiamond(), n && n()
                            }
                        })
                    }, t.prototype.SubDiamond = function (e) {
                        e && (this.diamond = this.diamond.minus(e))
                    }, t
                }(Laya.EventDispatcher);
                n.default = d
            }, {
                "../Common/DataID": 1,
                "../common/EventID": 15,
                "../common/SceneID": 17,
                "../core/DataStorage": 22,
                "../libs/bignumber": 39
            }],
            44: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../data/DataBus"),
                    o = e("../view/RewardView"),
                    a = e("../core/MathUtil"),
                    r = e("../core/GameHelper"),
                    s = e("../common/SceneID"),
                    l = e("../config/GameCnf"),
                    c = e("../core/Server"),
                    u = e("../common/ReportEventID"),
                    d = e("./MergeLogic"),
                    h = e("../config/SignCnf"),
                    f = e("./GuideLogic"),
                    p = e("./DialogLogic"),
                    _ = e("../view/GuideView"),
                    y = e("../platform/yt"),
                    g = function () {
                        function e() {
                            this.isMenuOpen = !1, this.isPopSignView = !1, this.isPopOffline = !1
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return null == this._instance && (this._instance = new e), this._instance
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.CreateGameClub = function (e) {
                            var t = e.localToGlobal(Laya.Point.create().setTo(100, 0)),
                                n = t.x / Laya.stage.width * Laya.Browser.clientWidth,
                                i = t.y / Laya.stage.height * Laya.Browser.clientHeight,
                                o = e.width * e.scaleX / Laya.stage.width * Laya.Browser.clientWidth,
                                a = e.height * e.scaleY / Laya.stage.height * Laya.Browser.clientHeight;
                            this._btnGameClub && this._btnGameClub.destroy(), this._btnGameClub = y.default.createGameClubButton({
                                type: "text",
                                text: " ",
                                style: {
                                    left: n,
                                    top: i,
                                    width: o,
                                    height: a,
                                    backgroundColor: "#00000001",
                                    fontSize: 1,
                                    lineHeight: 40,
                                    borderRadius: 30
                                }
                            }), this._btnGameClub || (e.visible = !1)
                        }, e.prototype.ShowGameClub = function () {
                            this._btnGameClub && this._btnGameClub.show()
                        }, e.prototype.HideGameClub = function () {
                            this._btnGameClub && this._btnGameClub.hide()
                        }, e.prototype.CreateFeedback = function (e) {
                            var t = e.localToGlobal(Laya.Point.create().reset()),
                                n = t.x / Laya.stage.width * Laya.Browser.clientWidth,
                                i = t.y / Laya.stage.height * Laya.Browser.clientHeight,
                                o = e.width * e.scaleX / Laya.stage.width * Laya.Browser.clientWidth,
                                a = e.height * e.scaleY / Laya.stage.height * Laya.Browser.clientHeight;
                            this._btnFeedback && this._btnFeedback.destroy(), this._btnFeedback = y.default.createFeedbackButton({
                                type: "text",
                                text: " ",
                                style: {
                                    left: n,
                                    top: i,
                                    width: o,
                                    height: a,
                                    backgroundColor: "#00000001",
                                    fontSize: 1,
                                    lineHeight: 40,
                                    borderRadius: 30
                                }
                            }), this._btnFeedback || (e.visible = !1)
                        }, e.prototype.ShowFeedback = function () {
                            this._btnFeedback && this._btnFeedback.show()
                        }, e.prototype.HideFeedback = function () {
                            this._btnFeedback && this._btnFeedback.hide()
                        }, e.prototype.ShowAllWxBtn = function () {
                            this.isMenuOpen ? this.ShowGameClub() : this.ShowFeedback(), this.startWxBtn && this.startWxBtn.showWxBtn()
                        }, e.prototype.HideAllWxBtn = function () {
                            this.HideFeedback(), this.HideGameClub(), this.startWxBtn && this.startWxBtn.hideWxBtn()
                        }, e.prototype.CheckPopWin = function () {
                            f.default.instance.check() != _.GuideTypeEnum.Game && (this.isPopSignView && 1 == i.default.instance.gameData.skinGuide && (this.isPopSignView = !1, p.default.instance.showDialogUnique(s.default.SignIn)), this.isPopOffline && (this.isPopOffline = !1, p.default.instance.showDialogQueue(s.default.PopWin, {
                                viewType: o.RewardViewTypeEnum.OFFLINE
                            })))
                        }, e.prototype.CheckSign = function (e) {
                            -1 != e ? r.default.isSameDay(e, i.default.instance.gameData.signDate) || (this.isPopSignView = !0) : r.default.Log("签到时间获取失败")
                        }, e.prototype.CheckOffline = function (e) {
                            var t = 0;
                            i.default.instance.lastDate <= 0 && (i.default.instance.lastDate = e), -1 != e && (console.log("当前时间：" + e), t = Math.floor((e - i.default.instance.lastDate) / 1e3), console.log("离线时间：", t), (t += i.default.instance.gameData.offlineTime) > 43200 && (t = 43200), -1 != e && t > 600 && (i.default.instance.gameData.offlineTime = t, i.default.instance.SaveGameData(), this.isPopOffline = !0))
                        }, e.prototype.CalcOfflineGold = function () {
                            var e = i.default.instance.gameData.offlineTime / d.default.instance.getProductCoinsInterval(),
                                t = d.default.instance.getTotalProfit() * e,
                                n = .05 + .05 * d.default.instance.getCurLevel();
                            return Math.round(t * n)
                        }, e.prototype.GetSignRewards = function (e) {
                            return e.type == h.SignRewardType.SKIN ? d.default.instance.getCoinsLevel() + 1 + e.value - 1 : e.type == h.SignRewardType.GOLD ? d.default.instance.getOriginCoinsPrice(d.default.instance.getCoinsLevel()) * e.value : e.type == h.SignRewardType.DIAMONDS ? d.default.instance.getOriginDiamondsPrice(d.default.instance.getDiamondsLevel()) * e.value : 0
                        }, e.prototype.PopExperienceDialog = function () {
                            var e, t = [1 / 3, 1 / 3, 1 / 3];
                            if ("string" == typeof y.default.conf.experience_ratio_list) {
                                var n = y.default.conf.experience_ratio_list.split("_").map(function (e) {
                                    return parseInt(e) || 0
                                });
                                if (n.length >= 3) {
                                    var i = n.reduce(function (e, t) {
                                        return e + t
                                    });
                                    i > 0 && (t = n.map(function (e) {
                                        return e / i
                                    }))
                                }
                            }
                            var r = Math.random(),
                                l = 0;
                            if ((e = d.default.instance.isLevelFull() ? r < t[1] / (t[1] + t[2]) ? o.ExperienceTypeEnum.LEN : o.ExperienceTypeEnum.FOOD : r < t[0] ? o.ExperienceTypeEnum.SKIN : r < t[0] + t[1] ? o.ExperienceTypeEnum.LEN : o.ExperienceTypeEnum.FOOD) == o.ExperienceTypeEnum.SKIN) {
                                var c = d.default.instance.getCurLevel() + 1,
                                    u = Math.min(c + 5, d.default.instance.getLevelCount() - 1);
                                l = a.default.RandomInt(c, u) + 1
                            }
                            p.default.instance.showDialogQueue(s.default.PopWin, {
                                viewType: o.RewardViewTypeEnum.EXPERIENCE,
                                experienceType: e,
                                skinId: l
                            })
                        }, e.prototype.AddVideoTimes = function () {
                            i.default.instance.gameData.videoTimes++, i.default.instance.SaveGameData()
                        }, e.prototype.SubmitMaxLen = function (e, t) {
                            var n = !1;
                            return e > i.default.instance.gameData.maxLen && (i.default.instance.gameData.maxLen = e, n = !0), i.default.instance.gameData.cumulateLen += e, t && i.default.instance.gameData.championTimes++, i.default.instance.SaveGameData(), n
                        }, e.prototype.EnterGame = function (e, t) {
                            void 0 === e && (e = o.ExperienceTypeEnum.NONE), void 0 === t && (t = 1);
                            var n = this.getGameParam(e, t);
                            p.default.instance.showDialogQueue(s.default.Match, {
                                onNext: function (e) {
                                    n.avatarList = e, Laya.Scene.open(s.default.Game, !0, n)
                                }
                            }), c.default.reportEvent(u.default.start_game)
                        }, e.prototype.getGameParam = function (e, t) {
                            void 0 === e && (e = o.ExperienceTypeEnum.NONE), void 0 === t && (t = 1);
                            var n = d.default.instance.getCurLevel(),
                                a = l.default.initLen,
                                r = l.default.initSpeed,
                                s = e == o.ExperienceTypeEnum.FOOD ? 2 : 1,
                                c = e == o.ExperienceTypeEnum.SKIN ? t : i.default.instance.skinData.useId1;
                            e == o.ExperienceTypeEnum.LEN && (a += l.default.experienceLen);
                            var u = c - 1,
                                h = d.default.instance.getAddition(u);
                            return {
                                avatarList: null,
                                playerSkin: c,
                                initLength: a += h.initLen,
                                initVelocity: r,
                                doubleFood: s += h.food,
                                lenLevel: n
                            }
                        }, e
                    }();
                n.default = g
            }, {
                "../common/ReportEventID": 16,
                "../common/SceneID": 17,
                "../config/GameCnf": 19,
                "../config/SignCnf": 20,
                "../core/GameHelper": 23,
                "../core/MathUtil": 24,
                "../core/Server": 28,
                "../data/DataBus": 32,
                "../platform/yt": 63,
                "../view/GuideView": 103,
                "../view/RewardView": 113,
                "./DialogLogic": 42,
                "./GuideLogic": 45,
                "./MergeLogic": 47
            }],
            45: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./GameLogic"),
                    o = e("../data/DataBus"),
                    a = e("../view/GuideView"),
                    r = e("../view/LobbyView"),
                    s = e("./MergeLogic"),
                    l = e("./DialogLogic"),
                    c = e("../common/SceneID"),
                    u = function () {
                        function e() {}
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.check = function () {
                            if (!r.default.instance) return a.GuideTypeEnum.None;
                            if (0 == o.default.instance.gameData.gameGuide) return o.default.instance.gameData.gameGuide = 1, o.default.instance.SaveGameData(), a.default.show(a.GuideTypeEnum.Game, r.default.instance), a.GuideTypeEnum.Game;
                            if (0 == o.default.instance.gameData.freeGuide) return o.default.instance.gameData.freeGuide = 1, o.default.instance.SaveGameData(), a.default.show(a.GuideTypeEnum.Buy, r.default.instance), a.GuideTypeEnum.Buy;
                            if (0 == o.default.instance.gameData.mergeGuide) {
                                if (this.findTwoSameItem(r.default.instance)) return o.default.instance.gameData.mergeGuide = 1, o.default.instance.SaveGameData(), a.default.show(a.GuideTypeEnum.Merge, r.default.instance), a.GuideTypeEnum.Merge
                            } else if (0 == o.default.instance.gameData.skinGuide && s.default.instance.getCurLevel() > 0) return o.default.instance.gameData.skinGuide = 1, o.default.instance.SaveGameData(), a.default.show(a.GuideTypeEnum.Skin, r.default.instance), i.default.instance.isPopSignView && (i.default.instance.isPopSignView = !1, l.default.instance.showDialogQueue(c.default.SignIn)), a.GuideTypeEnum.Skin;
                            return a.GuideTypeEnum.None
                        }, e.prototype.findTwoSameItem = function (e) {
                            for (var t = e.mergePnl, n = 0, i = t.cellList.length; n < i; ++n) {
                                var o = t.cellList[n].item;
                                if (o)
                                    for (var a = n + 1; a < i; ++a) {
                                        var r = t.cellList[a].item;
                                        if (r && o.level == r.level) return [o, r]
                                    }
                            }
                            return null
                        }, e._instance = null, e
                    }();
                n.default = u
            }, {
                "../common/SceneID": 17,
                "../data/DataBus": 32,
                "../view/GuideView": 103,
                "../view/LobbyView": 106,
                "./DialogLogic": 42,
                "./GameLogic": 44,
                "./MergeLogic": 47
            }],
            46: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, o, a = e("./MergeLogic"),
                    r = e("../core/MathUtil"),
                    s = e("./EconomicLogic"),
                    l = e("../data/DataBus"),
                    c = e("../view/Toast"),
                    u = e("../sound/SoundMgr"),
                    d = e("../sound/SoundID"),
                    h = e("../platform/yt"),
                    f = function () {
                        function e() {}
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.isValid = function () {
                            var e = null != h.default.conf.lottery_chance;
                            return console.log("是否显示抽奖: ", e), e
                        }, e.prototype.getPrizeList = function () {
                            for (var e = [], t = a.default.instance.getCoinsLevel(), n = 0, o = a.default.instance.getCoinsPriceForTimes(t, n), s = 0; s < 3; ++s) {
                                var l = Math.round(o * (3 - s) / 3),
                                    c = {
                                        level: s,
                                        type: i.Coins,
                                        value: l,
                                        index: 0
                                    };
                                e.push(c)
                            }
                            var u = a.default.instance.getDiamondsLevel();
                            for (n = 0, o = a.default.instance.getDiamondsPriceForTimes(u, n), s = 0; s < 3; ++s) l = Math.max(1, Math.floor(o * (3 - s) / 6)), c = {
                                level: s,
                                type: i.Diamonds,
                                value: l,
                                index: 0
                            }, e.push(c);
                            for (u = a.default.instance.getDiamondsLevel(), s = 0; s < 2; ++s) l = Math.max(0, u - s), c = {
                                level: s,
                                type: i.Snake,
                                value: l,
                                index: 0
                            }, e.push(c);
                            return r.default.shuffle(e), e.forEach(function (e, t) {
                                return e.index = t
                            }), e
                        }, e.prototype.lottery = function () {
                            for (var e = {
                                    type: i.Coins,
                                    level: 2,
                                    value: 0,
                                    index: 0
                                }, t = this._getChanceArr(), n = Math.random(), o = 0, s = 2; s >= 0; --s)
                                if (n < (o += t[s])) {
                                    e.level = s;
                                    break
                                } var l = a.default.instance.isFull();
                            return e.type = l ? r.default.RandomArr([i.Coins, i.Diamonds]) : r.default.RandomArr([i.Coins, i.Diamonds, i.Snake]), e
                        }, e.prototype._getChanceArr = function () {
                            if (!h.default.conf.lottery_chance) return [.05, .35, .6];
                            var e = h.default.conf.lottery_chance.split("_");
                            e.length = 3;
                            var t = e.map(function (e) {
                                return (parseInt(e) || 0) / 100
                            });
                            return t[0] >= 1 && (t = [1, 0, 0]), t[0] + t[1] >= 1 && (t[1] = (1 - t[0]) / 2), t[2] = 1 - t[0] - t[1], t
                        }, e.prototype.receive = function (e) {
                            switch (e.type) {
                                case i.Coins:
                                    s.default.instance.AddCoinWithAnimation(e.value);
                                    break;
                                case i.Diamonds:
                                    s.default.instance.AddDiamondWithAnimation(e.value);
                                    break;
                                case i.Snake:
                                    a.default.instance.addItemWithAnimation(e.value), u.default.instance.playSound(d.default.Unlock)
                            }
                        }, e.prototype.canGetTickets = function () {
                            return l.default.instance.lotteryData.tickets < 10 && l.default.instance.lotteryData.get_tickets < 10
                        }, e.prototype.presentTickets = function () {
                            var e = Date.now();
                            l.default.instance.lotteryData.next_time = e + 36e5, l.default.instance.lotteryData.get_tickets += 1, l.default.instance.lotteryData.tickets += 1, l.default.instance.SaveLotteryData(), c.default.show("Raffle Ticket +1")
                        }, e._instance = null, e
                    }();
                n.default = f, o = i = n.LotteryPrizeType || (n.LotteryPrizeType = {}), o[o.Coins = 0] = "Coins", o[o.Diamonds = 1] = "Diamonds", o[o.Snake = 2] = "Snake"
            }, {
                "../core/MathUtil": 24,
                "../data/DataBus": 32,
                "../platform/yt": 63,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../view/Toast": 121,
                "./EconomicLogic": 43,
                "./MergeLogic": 47
            }],
            47: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../data/DataBus"),
                    o = e("../common/SceneID"),
                    a = e("../view/RewardView"),
                    r = e("./EconomicLogic"),
                    s = e("../common/EventID"),
                    l = e("../core/GameHelper"),
                    c = e("../view/Toast"),
                    u = e("./DialogLogic"),
                    d = e("../config/GameCnf"),
                    h = e("../platform/yt"),
                    f = function () {
                        function e() {
                            this.mergePnl = null
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.getCurLevel = function () {
                            return i.default.instance.mergeData.level
                        }, e.prototype.setCurLevel = function (e) {
                            i.default.instance.mergeData.level = e
                        }, e.prototype.getLevelCount = function () {
                            return d.default.levelCount
                        }, e.prototype.getCellCount = function () {
                            return 12
                        }, e.prototype.getProductCoinsInterval = function () {
                            return 5
                        }, e.prototype.getProductItemInterval = function () {
                            var e = this.getCurLevel();
                            return Math.min(12, 1 + 2 * e)
                        }, e.prototype.isLevelFull = function () {
                            return this.getCurLevel() >= this.getLevelCount() - 1
                        }, e.prototype.getFreeLevel = function () {
                            return Math.max(0, this.getCurLevel() - 10)
                        }, e.prototype.getQuickLevel = function () {
                            return Math.max(0, this.getCurLevel() - 4)
                        }, e.prototype.getDiamondsLevel = function () {
                            return Math.max(0, this.getCurLevel() - 3)
                        }, e.prototype.getCoinsLevel = function () {
                            return Math.max(0, this.getCurLevel() - 4)
                        }, e.prototype.getCoinsPrice = function (e) {
                            var t = this.getCoinsTimes(e);
                            return this.getCoinsPriceForTimes(e, t)
                        }, e.prototype.getDiamondsPrice = function (e) {
                            var t = this.getDiamondsTimes(e);
                            return this.getDiamondsPriceForTimes(e, t)
                        }, e.prototype.getCoinsPriceForTimes = function (e, t) {
                            var n = e < 1 ? 1.07 : [1.12, 1.14, 1.2, 1.18, 1.16, 1.22, 1.24][e % 7];
                            return this.getOriginCoinsPrice(e) * Math.pow(n, t)
                        }, e.prototype.getDiamondsPriceForTimes = function (e, t) {
                            return Math.floor(this.getOriginDiamondsPrice(e) * Math.pow(1.2, t))
                        }, e.prototype.getOriginCoinsPrice = function (e) {
                            return e >= 5 ? 25 * Math.pow(2, e + 4) * (e - 4) * 50 * Math.pow(1.05, e - 5) : [100, 2500, 1e4, 4e4, 16e4][e]
                        }, e.prototype.getOriginDiamondsPrice = function (e) {
                            return 5 * (e + 1)
                        }, e.prototype.getSaleCoinsPrice = function (e) {
                            return Math.max(1, .5 * this.getOriginCoinsPrice(e))
                        }, e.prototype.getCoinsTimes = function (e) {
                            return i.default.instance.mergeData.coinsTimes[e] || 0
                        }, e.prototype.getDiamondsTimes = function (e) {
                            return i.default.instance.mergeData.diamondsTimes[e] || 0
                        }, e.prototype.getProfit = function (e) {
                            return Math.floor(25 * Math.pow(2, e))
                        }, e.prototype.getProfitPerMinute = function (e) {
                            return this.getProfit(e) * (60 / this.getProductCoinsInterval())
                        }, e.prototype.getLengthAddition = function (e) {
                            return (e % 2 == 0 ? 4 : 6) + 6 * Math.floor(e / 2) - 4
                        }, e.prototype.getEnergyAddition = function (e) {
                            return 2 * Math.floor((e + 1) / 2) / 100
                        }, e.prototype.getAddition = function (e) {
                            var t = this.getCurLevel();
                            return e < t && (e = t), {
                                initLen: this.getLengthAddition(e),
                                food: this.getEnergyAddition(e)
                            }
                        }, e.prototype.getTotalProfit = function () {
                            var e = this,
                                t = i.default.instance.mergeData.itemList,
                                n = 0;
                            return t.forEach(function (t) {
                                n += e.getProfit(t.level)
                            }), n
                        }, e.prototype.unlock = function (e) {
                            var t = this.getCurLevel();
                            e <= t || (this.setCurLevel(e), i.default.instance.SaveMergeData(), Laya.stage.event(s.default.UNLOCK), Laya.timer.once(300, this, function () {
                                u.default.instance.showDialogQueue(o.default.PopWin, {
                                    viewType: a.RewardViewTypeEnum.NEWSKIN,
                                    skinId: e + 1
                                })
                            }))
                        }, e.prototype.isFull = function () {
                            return this.mergePnl ? this.mergePnl.itemList.length >= this.getCellCount() : i.default.instance.mergeData.itemList.length >= this.getCellCount()
                        }, e.prototype.getBlankCellIndex = function () {
                            if (this.mergePnl) return this.mergePnl.getBlankCellIndex();
                            for (var e = i.default.instance.mergeData.itemList.map(function (e) {
                                    return e.index
                                }), t = this.getCellCount(), n = 0; n < t; ++n)
                                if (-1 == e.indexOf(n)) return n;
                            return -1
                        }, e.prototype.getCell = function (e) {
                            return this.mergePnl ? this.mergePnl.cellList[e] : null
                        }, e.prototype.createItem = function (e) {
                            var t = this.getCellCount(),
                                n = i.default.instance.mergeData.itemList;
                            if (n.length >= t) return !1;
                            if (this.mergePnl) return !!this.mergePnl.product(e);
                            var o = this.getBlankCellIndex();
                            return o > -1 && (n.push({
                                level: e,
                                index: o
                            }), !0)
                        }, e.prototype.coinsBuyItem = function (e, t) {
                            if (void 0 === t && (t = !1), e <= this.getCoinsLevel()) {
                                var n = this.getCoinsPrice(e);
                                r.default.instance.coin.gte(n) ? this.isFull() ? c.default.show("Pond is full, you can sell some snakes first!") : (r.default.instance.SubCoin(n), r.default.instance.SaveCoin(), this.addCoinsBoughtTimes(e), this.createItem(e), c.default.show("Purchased!")) : i.default.instance.gameData.freeCoinTimes >= (parseInt(h.default.conf.free_coins_times) || 0) ? c.default.show("Not enough coins!") : (a.default.isQuickBuy = t, u.default.instance.showDialog(o.default.PopWin, {
                                    viewType: a.RewardViewTypeEnum.NOMONEY,
                                    noMoneyType: a.NoMoneyTypeEnum.COINS,
                                    rewardVal: n
                                }))
                            }
                        }, e.prototype.diamondsBuyItem = function (e) {
                            if (e <= this.getDiamondsLevel()) {
                                var t = this.getDiamondsPrice(e);
                                r.default.instance.diamond.gte(t) ? this.isFull() ? c.default.show("Pond is full, you can sell some snakes first!") : (r.default.instance.SubDiamond(t), r.default.instance.SaveDiamond(), this.addDiamondsBoughtTimes(e), this.createItem(e),
                                    c.default.show("Purchased!")) : i.default.instance.gameData.freeDiamTimes >= (parseInt(h.default.conf.free_diamonds_times) || 0) ? c.default.show("Not enough diamonds!") : u.default.instance.showDialog(o.default.PopWin, {
                                    viewType: a.RewardViewTypeEnum.NOMONEY,
                                    noMoneyType: a.NoMoneyTypeEnum.DIAMONDS,
                                    rewardVal: t
                                })
                            }
                        }, e.prototype.loadDataToUi = function () {
                            if (this.mergePnl) {
                                this.mergePnl.itemList.forEach(function (e) {
                                    e.cell && (e.cell.item = null), e.cell = null, e.recover()
                                }), this.mergePnl.itemList = [];
                                for (var e = i.default.instance.mergeData.itemList, t = 0, n = e.length; t < n; ++t) {
                                    var o = e[t];
                                    this.mergePnl.createItem(o.index, o.level)
                                }
                                this.mergePnl.updateAllCellsDisplayStatus()
                            }
                        }, e.prototype.saveDataFromUi = function () {
                            if (this.mergePnl) {
                                for (var e = [], t = this.mergePnl.cellList, n = 0, o = t.length; n < o; ++n) {
                                    var a = t[n];
                                    a.item && e.push({
                                        level: a.item.level,
                                        index: n
                                    })
                                }
                                i.default.instance.mergeData.itemList = e
                            }
                        }, e.prototype.addCoinsBoughtTimes = function (e) {
                            i.default.instance.mergeData.coinsTimes[e] = (i.default.instance.mergeData.coinsTimes[e] || 0) + 1, Laya.stage.event(s.default.BOUGHT_TIMES_CHANGED)
                        }, e.prototype.addDiamondsBoughtTimes = function (e) {
                            i.default.instance.mergeData.diamondsTimes[e] = (i.default.instance.mergeData.diamondsTimes[e] || 0) + 1, Laya.stage.event(s.default.BOUGHT_TIMES_CHANGED)
                        }, e.prototype.sale = function (e) {
                            var t = this;
                            return new Promise(function (n) {
                                var i = t.getSaleCoinsPrice(e);
                                YYGGames.showTip("Sold the snake and you got " + l.default.toAbb(i) + " coins!"), r.default.instance.AddCoinWithAnimation(i), n(!0)
                            })
                        }, e.prototype._showAddItemAnimation = function (e, t, n) {
                            var i = e + 1;
                            Laya.Scene.open(o.default.SkinAnim, !1, {
                                skinId: i,
                                targetPos: t,
                                onNext: n
                            })
                        }, e.prototype.addItemWithAnimation = function (t) {
                            var n = e.instance.getBlankCellIndex(),
                                i = e.instance.getCell(n),
                                o = null;
                            i && ((o = Laya.Point.create()).setTo(.5 * i.width, .5 * i.height), o = i.localToGlobal(o)), e.instance._showAddItemAnimation(t, o, function () {
                                e.instance.createItem(t), o && o.recover()
                            })
                        }, e._instance = null, e
                    }();
                n.default = f
            }, {
                "../common/EventID": 15,
                "../common/SceneID": 17,
                "../config/GameCnf": 19,
                "../core/GameHelper": 23,
                "../data/DataBus": 32,
                "../platform/yt": 63,
                "../view/RewardView": 113,
                "../view/Toast": 121,
                "./DialogLogic": 42,
                "./EconomicLogic": 43
            }],
            48: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../config/ConfigBus"),
                    o = e("../config/SkinCnf"),
                    a = e("./MergeLogic"),
                    r = function () {
                        function e() {}
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e), this._instance
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.GetSkinCnf = function (e) {
                            var t = e - 1;
                            return i.default.instance.skins[t]
                        }, e.prototype.GetSkinPath = function (e) {
                            return "tex/snake/skin_" + e + ".png"
                        }, e.prototype.setTwoAttrVal = function (t, n, i) {
                            var r = a.default.instance.getAddition(i - 1);
                            e.instance.setAttrVal(t, r.initLen > 0 ? o.SkinAddAttrEnum.INITLEN : o.SkinAddAttrEnum.NONE, r.initLen), e.instance.setAttrVal(n, r.food > 0 ? o.SkinAddAttrEnum.FOOD : o.SkinAddAttrEnum.NONE, r.food)
                        }, e.prototype.setAttrVal = function (e, t, n) {
                            switch (t) {
                                case o.SkinAddAttrEnum.NONE:
                                    e.visible = !1;
                                    break;
                                case o.SkinAddAttrEnum.INITLEN:
                                    e.visible = !0, e.skin = "tex/lobby_icon_changdu.png", e.getChildAt(0).text = "+" + n.toFixed(0);
                                    break;
                                case o.SkinAddAttrEnum.FOOD:
                                    e.visible = !0, e.skin = "tex/lobby_icon_nengliang.png", e.getChildAt(0).text = "+" + (100 * n).toFixed(0) + "%"
                            }
                        }, e
                    }();
                n.default = r
            }, {
                "../config/ConfigBus": 18,
                "../config/SkinCnf": 21,
                "./MergeLogic": 47
            }],
            49: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/GameHelper"),
                    s = e("../core/MathUtil"),
                    l = function (e) {
                        function t() {
                            var t = null !== e && e.apply(this, arguments) || this;
                            return t._onNext = null, t
                        }
                        return o(t, e), t.create = function (e) {
                            var n = Laya.Pool.getItemByClass(this.poolKey, t);
                            return e && e.addChild(n), n
                        }, t.prototype.show = function (e, t, n, i, o) {
                            void 0 === i && (i = 0), void 0 === o && (o = null), this.x = t, this.y = n, this._lbl.changeText("+" + r.default.toAbb(e)), this._onNext = o, this.visible = !1, Laya.timer.once(i, this, this._moveUp)
                        }, t.prototype._moveUp = function () {
                            this.visible = !0, this._sp.x = 20, this._sp.y = 0, this._sp.scale(1, 1), this._lbl.x = 48, this._lbl.y = 0, this._lbl.alpha = 1, Laya.Tween.to(this._sp, {
                                y: -25
                            }, 200, null, Laya.Handler.create(this, this._moveToCoinsPanel)), Laya.Tween.to(this._lbl, {
                                y: -100,
                                alpha: 0
                            }, 800)
                        }, t.prototype._moveToCoinsPanel = function () {
                            var e = Laya.Point.create();
                            Laya.stage.height / Laya.stage.width > 2 ? e.setTo(60 + s.default.Random(-10, 10), 120 + s.default.Random(-10, 10)) : e.setTo(60 + s.default.Random(-10, 10), 60 + s.default.Random(-10, 10)), e = this.globalToLocal(e);
                            var t = s.default.Random(800, 1e3);
                            Laya.Tween.to(this._sp, {
                                x: e.x,
                                y: e.y,
                                scaleX: .5,
                                scaleY: .5
                            }, t, Laya.Ease.sineOut, Laya.Handler.create(this, this._complete)), e.recover()
                        }, t.prototype._complete = function () {
                            this.removeSelf(), Laya.Pool.recover(t.poolKey, this), this._onNext && this._onNext()
                        }, t.poolKey = "merge_add_coins", t
                    }(a.ui.view.MergeAddCoinsUI);
                n.default = l
            }, {
                "../core/GameHelper": 23,
                "../core/MathUtil": 24,
                "../ui/layaMaxUI": 97
            }],
            50: [function (e, t, n) {
                "use strict";
                var i, o, a, r = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }), a = o = n.MergeCellDisplayStatusEnum || (n.MergeCellDisplayStatusEnum = {}), a[a.Normal = 0] = "Normal", a[a.Hover = 1] = "Hover", a[a.Forbid = 2] = "Forbid";
                var s = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.pnl = null, t.item = null, t.setDisplayStatus(o.Normal), t.setAllowMergeDisplay(!1), t
                    }
                    return r(t, e), t.prototype.setDisplayStatus = function (e) {}, t.prototype.setAllowMergeDisplay = function (e) {
                        var t = this.getChildByName("border");
                        e ? t && (t.visible = !0) : t && (t.visible = !1)
                    }, t
                }(Laya.Sprite);
                n.default = s
            }, {}],
            51: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.pnl = null, t.cell = null, t._iconScale = .45, t._level = 0, t._iconScale = t.icon.scaleX, t.on(Laya.Event.MOUSE_DOWN, t, t._onMouseDown), t
                    }
                    return o(t, e), t.create = function () {
                        var e = Laya.Pool.getItemByClass(this._poolKey, t);
                        return e.zOrder = 0, e.cell = null, e.pnl = null, e.levelPnl.visible = !0, e.mouseEnabled = !0, e.infoPnl.visible = !1, e
                    }, Object.defineProperty(t.prototype, "level", {
                        get: function () {
                            return this._level
                        },
                        set: function (e) {
                            this._level = e, Laya.timer.callLater(this, this._updateLevel, [e])
                        },
                        enumerable: !0,
                        configurable: !0
                    }), t.prototype.recover = function () {
                        Laya.Tween.clearAll(this), Laya.Tween.clearAll(this.icon), this.icon.scale(this._iconScale, this._iconScale), this.removeSelf(), Laya.Pool.recover(t._poolKey, this)
                    }, t.prototype._updateLevel = function (e) {
                        var t = this.pnl.getItemSkin(e);
                        this.icon.skin = t, this.levelLbl.text = e + 1 + ""
                    }, t.prototype._onMouseDown = function () {
                        this.pnl.dragItem || (this.zOrder = 1, this.levelPnl.visible = !1, this.pnl.onDragStart(this), this.startDrag(), this.on(Laya.Event.MOUSE_UP, this, this._onMouseUp), this.on(Laya.Event.DRAG_END, this, this._onMouseUp))
                    }, t.prototype._onMouseUp = function () {
                        this.levelPnl.visible = !0, this.zOrder = 0;
                        var e = this._getHoverCell();
                        if (e)
                            if (e.item) {
                                if (this.pnl.mergeable(this, e.item) && this.pnl.merge(e.item, this)) return void this.pnl.onDragEnd()
                            } else if (this.pnl.addItemToCell(this, e)) return Laya.Tween.clearAll(this), Laya.Tween.to(this, {
                            x: e.x,
                            y: e.y
                        }, 150, null, null, 0, !0), void this.pnl.onDragEnd();
                        this.backToCell(), this.pnl.onDragEnd(), this.off(Laya.Event.MOUSE_UP, this, this._onMouseUp), this.off(Laya.Event.DRAG_END, this, this._onMouseUp)
                    }, t.prototype._getHoverCell = function () {
                        for (var e = 0, t = this.pnl.cellList.length; e < t; ++e) {
                            var n = this.pnl.cellList[e];
                            if (this._hoverCell(n)) return n
                        }
                        return this.pnl.salePnlEnabled && this._hoverCell(this.pnl.salePnl) ? this.pnl.salePnl : null
                    }, t.prototype._hoverCell = function (e) {
                        return this.x >= e.x - .5 * e.width && this.x < e.x + .5 * e.width && this.y >= e.y - .5 * e.height && this.y < e.y + .5 * e.height
                    }, t.prototype.backToCell = function () {
                        this.cell && (Laya.Tween.clearAll(this), Laya.Tween.to(this, {
                            x: this.cell.x,
                            y: this.cell.y
                        }, 150, null, null, 0, !0))
                    }, t.prototype.breath = function () {
                        Laya.Tween.clearAll(this.icon), this.icon.scale(this._iconScale, this._iconScale), Laya.Tween.to(this.icon, {
                            scaleX: 1.1 * this._iconScale,
                            scaleY: 1.1 * this._iconScale
                        }, 300, null, Laya.Handler.create(this, this._breath))
                    }, t.prototype._breath = function () {
                        Laya.Tween.to(this.icon, {
                            scaleX: this._iconScale,
                            scaleY: this._iconScale
                        }, 300)
                    }, t.prototype.showInfo = function (e, t) {
                        this.infoPnl.visible = !0, this.lblProduct.text = e, this.lblName.text = t
                    }, t.prototype.hideInfo = function () {
                        this.infoPnl.visible = !1
                    }, t._poolKey = "merge_item_ui", t
                }(e("../ui/layaMaxUI").ui.view.MergeItemUI);
                n.default = a
            }, {
                "../ui/layaMaxUI": 97
            }],
            52: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s, l, c = e("../ui/layaMaxUI"),
                    u = e("./MergeItem"),
                    d = e("./MergeCell"),
                    h = e("../logic/SkinLogic"),
                    f = e("../common/EventID"),
                    p = e("../logic/MergeLogic"),
                    _ = e("../sound/SoundID"),
                    y = e("../core/GameHelper"),
                    g = e("./MergeAddCoins"),
                    m = e("../logic/EconomicLogic"),
                    v = e("../sound/SoundMgr"),
                    L = e("../view/Toast"),
                    w = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.levelCount = 0, t.maxLength = 12, t.cellList = [], t.itemList = [], t.salePnl = null, t._salePnlTargetY = 485, t.dragItem = null, t.salePnlEnabled = !0, t._init(), t
                        }
                        return o(t, e), t.prototype._onRemoved = function () {
                            this.itemList.forEach(function (e) {
                                e.recover()
                            }), Laya.Tween.clearAll(this.salePnl), Laya.timer.clearAll(this), e.prototype._onRemoved.call(this)
                        }, t.prototype._init = function () {
                            this._removeIt && this._removeIt.removeSelf(), this._removeIt = null, this.salePnl = this._salePnl, this._salePnlTargetY = this.salePnl.y, this.salePnl.y = this._salePnlTargetY + 55, this.salePnl.alpha = 0, this.salePnl.visible = !1;
                            for (var e = 0, t = this._cellPnl.numChildren; e < t; ++e) {
                                var n = this._cellPnl.getChildAt(e);
                                n.pnl = this, this.cellList.push(n)
                            }
                            this.maxLength = this.cellList.length, this.updateAllCellsDisplayStatus()
                        }, t.prototype.createItem = function (e, t) {
                            var n = this.cellList[e];
                            if (n)
                                if (n.item) console.warn("[合成]索引对应的格子已有项");
                                else {
                                    if (!(this.itemList.length >= this.maxLength)) {
                                        var i = u.default.create();
                                        return this._itemPnl.addChild(i), this.itemList.push(i), i.pnl = this, i.cell = n, n.item = i, i.pos(n.x, n.y), i.level = t, i
                                    }
                                    console.warn("[合成]格子已满")
                                }
                            else console.warn("[合成]索引对应的格子不存在")
                        }, t.prototype.addItemToCell = function (e, t) {
                            return t == this.salePnl ? 1 == this.itemList.length ? (L.default.show("This snake is the hope of the whole village, please treat it well!"), !1) : (this.sale(e), !0) : t.item ? (console.warn("[合成]索引对应的格子已有项"), !1) : (e.cell && (e.cell.item = null), e.cell = t, t.item = e, this.event(f.default.MERGE_CHANGED, s.Move), !0)
                        }, t.prototype.product = function (e) {
                            var t = null,
                                n = this.getBlankCellIndex();
                            return n > -1 && (t = this.createItem(n, e)) && (this.showProductAnimation(t, 0), this.event(f.default.MERGE_CHANGED, s.Add)), t
                        }, t.prototype.sale = function (e) {
                            return a(this, void 0, void 0, function () {
                                return r(this, function (t) {
                                    switch (t.label) {
                                        case 0:
                                            return [4, p.default.instance.sale(e.level)];
                                        case 1:
                                            return t.sent() ? this.removeItem(e) : e.backToCell(), [2]
                                    }
                                })
                            })
                        }, t.prototype.mergeable = function (e, t) {
                            return t != e && t.level == e.level
                        }, t.prototype.merge = function (e, t) {
                            return e.level >= this.levelCount - 1 ? (console.warn("[合成]已经是最高等级"), L.default.show("This is the highest level!"), !1) : (this.showMergeAnimation(e.x, e.y, e.level), this.showProductAnimation(e, 270), e.level += 1, this.removeItem(t), this.event(f.default.MERGED, e.level), v.default.instance.playSound(_.default.Merge), !0)
                        }, t.prototype.removeItem = function (e) {
                            e.cell && (e.cell.item = null), e.cell = null;
                            var t = this.itemList.indexOf(e);
                            t > -1 && this.itemList.splice(t, 1), e.recover(), this.event(f.default.MERGE_CHANGED, s.Remove)
                        }, t.prototype.updateAllCellsDisplayStatus = function (e) {
                            void 0 === e && (e = null);
                            for (var t = 0, n = this.cellList.length; t < n; ++t) {
                                var i = this.cellList[t];
                                i.setDisplayStatus(d.MergeCellDisplayStatusEnum.Normal), i.setAllowMergeDisplay(e && i.item && i.item != e && i.item.level == e.level)
                            }
                        }, t.prototype.onDragStart = function (e) {
                            this.dragItem = e, this.updateAllCellsDisplayStatus(e), this.salePnlEnabled && this._showSalePnl(), this._showItemsInfo(e), this.event(f.default.MERGE_DRAG_START)
                        }, t.prototype.onDragEnd = function () {
                            this.dragItem && this._hideItemsInfo(this.dragItem), this.dragItem = null, this.updateAllCellsDisplayStatus(), this._hideSalePnl(), this.event(f.default.MERGE_DRAG_END)
                        }, t.prototype._showSalePnl = function () {
                            this.salePnl.visible = !0, Laya.Tween.clearAll(this.salePnl), Laya.Tween.to(this.salePnl, {
                                y: this._salePnlTargetY,
                                alpha: 1
                            }, 300, null, null, 0)
                        }, t.prototype._hideSalePnl = function () {
                            var e = this._salePnlTargetY + 55;
                            Laya.Tween.clearAll(this.salePnl), Laya.Tween.to(this.salePnl, {
                                y: e,
                                alpha: 0
                            }, 300, null, Laya.Handler.create(this, this.__hideSalePnl))
                        }, t.prototype.__hideSalePnl = function () {
                            this.salePnl.visible = !1
                        }, t.prototype._showItemsInfo = function (e) {
                            var t = e.level,
                                n = p.default.instance.getProfitPerMinute(t),
                                i = y.default.toAbb(n) + "/min ",
                                o = t + 1,
                                a = h.default.instance.GetSkinCnf(o);
                            e.showInfo(i, a.name)
                        }, t.prototype._hideItemsInfo = function (e) {
                            e.hideInfo()
                        }, t.prototype.getBlankCellIndex = function () {
                            for (var e = 0, t = this.cellList.length; e < t; ++e)
                                if (!this.cellList[e].item) return e;
                            return -1
                        }, t.prototype.getItemSkin = function (e) {
                            var t = e + 1,
                                n = h.default.instance.GetSkinCnf(t);
                            return h.default.instance.GetSkinPath(n.res)
                        }, t.prototype.showProductAnimation = function (e, t) {
                            void 0 === t && (t = 0), Laya.Tween.clearAll(e), e.scale(0, 0), t > 0 && (e.visible = !1, Laya.Tween.to(e, {}, t - 70, null, Laya.Handler.create(this, this._showProduct, [e]))), Laya.Tween.to(e, {
                                scaleX: 1,
                                scaleY: 1
                            }, 500, Laya.Ease.elasticOut, null, t)
                        }, t.prototype._showProduct = function (e) {
                            e.visible = !0, this._showMergeLightAnim(e.x, e.y)
                        }, t.prototype.showMergeAnimation = function (e, t, n) {
                            var i = u.default.create(),
                                o = u.default.create();
                            i.levelPnl.visible = o.levelPnl.visible = !1, i.mouseEnabled = o.mouseEnabled = !1, i.icon.skin = o.icon.skin = this.getItemSkin(n), i.y = o.y = t, i.zOrder = o.zOrder = 2, this._itemPnl.addChild(i), this._itemPnl.addChild(o), this._createMergeMoveAnimation(i, e - 50, e - 100, e), this._createMergeMoveAnimation(o, e + 50, e + 100, e)
                        }, t.prototype._createMergeMoveAnimation = function (e, t, n, i) {
                            e.x = t;
                            var o = new Laya.TimeLine;
                            o.addLabel("move_out", 0).to(e, {
                                x: n
                            }, 150, Laya.Ease.sineOut).addLabel("move_in", 0).to(e, {
                                x: i
                            }, 120, Laya.Ease.sineIn), o.on(Laya.Event.COMPLETE, this, this._onMergeMoveAnimationComplete, [o, e]), o.play(0, !1)
                        }, t.prototype._onMergeMoveAnimationComplete = function (e, t) {
                            e.destroy(), t.recover()
                        }, t.prototype._showMergeLightAnim = function (e, t) {
                            this._mergeAnimPnl.visible = !0, this._mergeAnimPnl.pos(e, t, !0), this._mergeAnim.play(0, !1), Laya.timer.clear(this, this._hideMergeLightAnim), Laya.timer.once(600, this, this._hideMergeLightAnim)
                        }, t.prototype._hideMergeLightAnim = function () {
                            this._mergeAnim.stop(), this._mergeAnimPnl.visible = !1
                        }, t.prototype.profit = function () {
                            var e = this,
                                t = 0,
                                n = this.cellList.map(function (n) {
                                    if (n.item) {
                                        var i = n.item,
                                            o = p.default.instance.getProfit(i.level);
                                        return t += o, new Promise(function (t) {
                                            Laya.timer.once(2e3 * Math.random(), e, function () {
                                                i.breath(), g.default.create(e._animPnl).show(o, n.x + 60, n.y, 200, t)
                                            })
                                        })
                                    }
                                    return Promise.resolve()
                                });
                            Promise.all(n).then(function () {
                                m.default.instance.AddCoin(t)
                            })
                        }, t
                    }(c.ui.view.MergePnlUI);
                n.default = w, l = s = n.MergeActionEnum || (n.MergeActionEnum = {}), l[l.Move = 0] = "Move", l[l.Add = 1] = "Add", l[l.Remove = 2] = "Remove"
            }, {
                "../common/EventID": 15,
                "../core/GameHelper": 23,
                "../logic/EconomicLogic": 43,
                "../logic/MergeLogic": 47,
                "../logic/SkinLogic": 48,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "../view/Toast": 121,
                "./MergeAddCoins": 49,
                "./MergeCell": 50,
                "./MergeItem": 51
            }],
            53: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../config/ConfigBus"),
                    o = function () {
                        function e() {}
                        return Object.defineProperty(e, "snakeUrl", {
                            get: function () {
                                var e = this;
                                return this._snakeUrl || (this._snakeUrl = {}, i.default.instance.skins.forEach(function (t) {
                                    e._snakeUrl[t.id] = {
                                        head: "res/model/" + t.res + "t.lh",
                                        body: "res/model/" + t.res + "s.lh"
                                    }
                                })), this._snakeUrl
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.eatParticleUrl = "res/model2/snake_hit.lh", e.sceneUrl = ["res/model2/bg.lh"], e.foodUrl = {
                            small: "res/model/baoshi.lh"
                        }, e.foodLightUrl = "res/model2/light.lh", e.crownUrl = ["res/model2/snake_huangguan.lh", "res/model2/snake_huangguan1.lh", "res/model2/snake_huangguan2.lh"], e.arrowUrl = "res/model/jiantou.lh", e.headEffectUrl = "res/model/snake_light.lh", e._snakeUrl = null, e
                    }();
                n.ModelConfig = o
            }, {
                "../config/ConfigBus": 18
            }],
            54: [function (e, t, n) {
                "use strict";
                var i = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    o = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function () {
                    function e() {
                        this._modelCallbacks = {}, this._modelMap = {}
                    }
                    return Object.defineProperty(e, "instance", {
                        get: function () {
                            return this._instance || (this._instance = new e)
                        },
                        enumerable: !0,
                        configurable: !0
                    }), e.prototype.preloadModel = function (e) {
                        var t = this,
                            n = this._modelMap[e];
                        return n ? Promise.resolve(n) : new Promise(function (n, i) {
                            var o = t._modelCallbacks[e];
                            Array.isArray(o) ? o.push(n) : (t._modelCallbacks[e] = [n], Laya.Sprite3D.load(e, Laya.Handler.create(t, function (n) {
                                n instanceof Laya.Sprite3D ? (console.info("加载模型成功: ", e), t._modelMap[e] = n, t._modelCallbacks[e] && t._modelCallbacks[e].forEach(function (e) {
                                    return e(n)
                                }), delete t._modelCallbacks[e]) : (t._modelCallbacks[e] && t._modelCallbacks[e].forEach(function (e) {
                                    return e(null)
                                }), delete t._modelCallbacks[e], console.e("加载模型失败: ", e))
                            })))
                        })
                    }, e.prototype.getModel = function (e, t) {
                        var n = Laya.Pool.getItemByCreateFun(e, this._createModel.bind(this, e, t), this);
                        return n.__url__ = e, n
                    }, e.prototype.removeModel = function (e, t) {
                        t || (t = e.__url__), e.removeSelf(), t && Laya.Pool.recover(t, e)
                    }, e.prototype._createModel = function (e, t) {
                        var n = new Laya.Sprite3D,
                            i = new Laya.Sprite3D;
                        return n.addChild(i), this.preloadModel(e).then(function (e) {
                            var n = null;
                            e && (n = e.clone(), i.addChild(n)), t && t(n)
                        }), n
                    }, e.prototype.getOriginModel = function (e) {
                        return i(this, void 0, void 0, function () {
                            var t, n, i;
                            return o(this, function (o) {
                                switch (o.label) {
                                    case 0:
                                        return t = "origin:" + e, Laya.Pool.getPoolBySign(t).length > 0 ? [2, Laya.Pool.getItem(t)] : [3, 1];
                                    case 1:
                                        return [4, this.preloadModel(e)];
                                    case 2:
                                        return n = o.sent(), (i = n.clone()).__url__ = e, [2, i]
                                }
                            })
                        })
                    }, e.prototype.removeOriginModel = function (e) {
                        var t = e.__url__;
                        if (e.removeSelf(), t) {
                            var n = "origin:" + t;
                            Laya.Pool.recover(n, e)
                        }
                    }, e._instance = null, e
                }();
                n.ModelLoader = a, window.ModelLoader = a
            }, {}],
            55: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./ModelConfig"),
                    o = function () {
                        function e() {}
                        return Object.defineProperty(e, "instace", {
                            get: function () {
                                return this._instace || (this._instace = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.createModelParam = function (e, t) {
                            var n = {
                                    sceneUrl: i.ModelConfig.sceneUrl[Math.floor(Math.random() * i.ModelConfig.sceneUrl.length)],
                                    eatParticleUrl: i.ModelConfig.eatParticleUrl,
                                    bigFoodUrl: "",
                                    smallFoodUrl: i.ModelConfig.foodUrl.small,
                                    foodLightUrl: i.ModelConfig.foodLightUrl,
                                    crownUrlList: i.ModelConfig.crownUrl,
                                    arrowUrl: i.ModelConfig.arrowUrl,
                                    headEffectUrl: "",
                                    snakeList: []
                                },
                                o = i.ModelConfig.snakeUrl[e];
                            n.snakeList.push({
                                skinId: e,
                                headModelUrl: o.head,
                                bodyModelUrl: o.body
                            });
                            var a = Object.keys(i.ModelConfig.snakeUrl).filter(function (t) {
                                return t != e
                            });
                            this._shuffle(a);
                            for (var r = 0, s = t; r < s; ++r) {
                                var l = Number(a[r % a.length]),
                                    c = i.ModelConfig.snakeUrl[l];
                                n.snakeList.push({
                                    skinId: l,
                                    headModelUrl: c.head,
                                    bodyModelUrl: c.body
                                })
                            }
                            return n
                        }, e.prototype._shuffle = function (e) {
                            for (var t, n, i = e.length; 0 !== i;) n = Math.floor(Math.random() * i), t = e[i -= 1], e[i] = e[n], e[n] = t;
                            return e
                        }, e._instace = null, e
                    }();
                n.ModelMgr = o
            }, {
                "./ModelConfig": 53
            }],
            56: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {
                        this.serverLoginType = "", this.supportNetWork = !1, this.supportLogin = !1, this.supportShare = !1, this.supportShareCallback = !1, this.supportWorldRank = !1, this.supportGroupRank = !1, this.supportFriendRank = !1, this.supportVideoAd = !1, this.supportInterAd = !1, this.supportBlockAd = !1, this.supportNativeAd = !1, this.supportGamePortalAd = !1
                    }
                    return e.prototype.init = function (e) {}, e.prototype.getSystemSize = function () {}, e.prototype.log = function () {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t]
                    }, e.prototype.warn = function () {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t]
                    }, e.prototype.error = function () {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t]
                    }, e.prototype.onShow = function (e) {}, e.prototype.offShow = function (e) {}, e.prototype.onHide = function (e) {}, e.prototype.offHide = function (e) {}, e.prototype.exitMiniProgram = function (e) {}, e.prototype.isIos = function () {}, e.prototype.isAndroid = function () {}, e.prototype.vibrateShort = function () {}, e.prototype.vibrateLong = function () {}, e.prototype.setKeepScreenOn = function (e) {}, e.prototype.setLoadingProgress = function (e) {}, e.prototype.loadingComplete = function (e) {}, e.prototype.reportMonitor = function (e, t) {}, e.prototype.installShortcut = function (e) {}, e.prototype.hasShortcutInstalled = function (e) {}, e.prototype.showToast = function (e, t) {}, e.prototype.showModal = function (e) {}, e.prototype.showLoading = function (e) {}, e.prototype.hideLoading = function () {}, e.prototype.request = function (e) {}, e.prototype.login = function (e) {}, e.prototype.getUserInfo = function (e) {}, e.prototype.getSetting = function (e) {}, e.prototype.getStorage = function (e) {}, e.prototype.getStorageSync = function (e) {}, e.prototype.setStorage = function (e) {}, e.prototype.loadSubpackage = function (e) {}, e.prototype.getLaunchOptionsSync = function () {}, e.prototype.getSystemInfoSync = function () {}, e.prototype.previewImage = function (e) {}, e.prototype.navToMiniGame = function (e) {}, e.prototype.updateScore = function (e) {}, e.prototype.onShare = function (e) {}, e.prototype.share = function (e) {}, e.prototype.createUserInfoButton = function (e) {}, e.prototype.createFeedbackButton = function (e) {}, e.prototype.createGameClubButton = function (e) {}, e.prototype._processConf = function (e) {}, e.prototype.isVideoLoaded = function () {}, e.prototype.showVideo = function (e, t, n) {}, e.prototype.isBannerLoaded = function () {}, e.prototype.isBannerVisible = function () {}, e.prototype.showBanner = function () {}, e.prototype.hideBanner = function () {}, e.prototype.setBannerWidth = function (e) {}, e.prototype.getBannerHeight = function () {}, e.prototype.isInterAdLoaded = function () {}, e.prototype.showInterAd = function () {}, e.prototype.isNativeAdLoaded = function () {}, e.prototype.getNativeAdData = function (e) {}, e.prototype.refreshNativeAd = function (e) {}, e.prototype.reportAdShow = function (e) {}, e.prototype.reportAdClick = function (e) {}, e.prototype.createBlockAd = function (e, t, n, i) {}, e.prototype.isBlockAdLoaded = function (e) {}, e.prototype.showBlockAd = function (e) {}, e.prototype.hideBlockAd = function (e) {}, e.prototype.destroyBlockAd = function (e) {}, e.prototype.destroyAllBlockAd = function () {}, e.prototype.isGamePortalAdLoaded = function () {}, e.prototype.isGamePortalAdShow = function () {}, e.prototype.showGamePortalAd = function () {}, e
                }();
                n.default = i, window.BasePlatform = i
            }, {}],
            57: [function (e, t, n) {
                "use strict";

                function i(e, t, n) {
                    return {
                        width: n,
                        top: t - 104,
                        left: .5 * (e - n)
                    }
                }

                function o(e, t, n, i, o, a) {
                    return {
                        top: t - i,
                        left: .5 * (e - n)
                    }
                }
                var a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("./PlatformEventID"),
                    l = e("./PlatformUtils"),
                    c = window.qg,
                    u = function () {
                        function e() {
                            this.serverLoginType = "oppo", this.supportNetWork = !0, this.supportLogin = !1, this.supportShare = !1, this.supportShareCallback = !1, this.supportWorldRank = !1, this.supportGroupRank = !1, this.supportFriendRank = !1, this.supportVideoAd = !0, this.supportBlockAd = !1, this._videoAdLoaded = !1, this._videoAdEventBind = !1, this._videoAdLoadCount = 0, this._onVideoAdClosed = null, this._bannerVisible = !1, this._bannerHasShow = !1, this._bannerLoaded = !1, this._bannerAdLoadFailCount = 0, this._nativeRefreshInterval = -1, this._createNativeAdDelegate = null, this._blockAds = [], this._blockAdIndex = 0, this._gamePortalLoaded = !1, this._gamePortalIsShow = !1
                        }
                        return Object.defineProperty(e.prototype, "supportInterAd", {
                                get: function () {
                                    return !!c.createInterAd
                                },
                                enumerable: !0,
                                configurable: !0
                            }), Object.defineProperty(e.prototype, "supportNativeAd", {
                                get: function () {
                                    return !!c.createNativeAd
                                },
                                enumerable: !0,
                                configurable: !0
                            }), Object.defineProperty(e.prototype, "supportGamePortalAd", {
                                get: function () {
                                    return !!c.createGamePortalAd
                                },
                                enumerable: !0,
                                configurable: !0
                            }), e.prototype.init = function (e) {
                                var t = this;
                                this._videoId = e.videoId, this._bannerId = e.bannerId, this._gamePortalId = e.gamePortalId, this._nativeId = e.nativeId, this._onBannerPlaced = e.onBannerPlaced || i, this._onBannerResize = e.onBannerResize || o, this._useLog = void 0 === e.useLog || e.useLog, c.onError && c.onError(function (e) {
                                    console.log("全局错误: ", e)
                                }), e.autoUpdate && this._autoUpdate(), this._sys = this.getSystemInfoSync(), this.log("sys: ", JSON.stringify(this._sys)), void 0 === this._bannerWidth && (this._bannerWidth = this._sys.screenWidth), l.default.setTimeout("BANNER_AD_TIMER", function () {
                                    t._bannerId && !t._bannerAd && t._createBanner()
                                }, e.loadBannerDelay || 0), l.default.setTimeout("VIDEO_AD_TIMER", function () {
                                    t._videoId && !t._videoAd && t._createVideo()
                                }, e.loadVideoAdDelay || 0), l.default.setTimeout("NATIVE_AD_TIMER", function () {
                                    t._nativeId && !t._nativeAd && t._createNativeAd()
                                }, e.loadNativeAdDelay || 0)
                            }, e.prototype._autoUpdate = function () {
                                var e = this;
                                if ("function" == typeof c.getUpdateManager) {
                                    var t = c.getUpdateManager();
                                    t.onCheckForUpdate(function (t) {
                                        e.log("hasUpdate:" + t.hasUpdate)
                                    }), t.onUpdateReady(function () {
                                        t.applyUpdate()
                                    }), t.onUpdateFailed(function () {})
                                }
                            }, e.prototype.getSystemSize = function () {
                                return {
                                    width: this._sys.screenWidth,
                                    height: this._sys.screenHeight
                                }
                            }, e.prototype.log = function () {
                                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                                return this._useLog && console.log.apply(console, e)
                            }, e.prototype.warn = function () {
                                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                                return this._useLog && console.warn.apply(console, e)
                            }, e.prototype.error = function () {
                                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                                return this._useLog && console.e.apply(console, e)
                            }, e.prototype.onShow = function (e) {
                                return c.onShow(e)
                            }, e.prototype.offShow = function (e) {
                                return c.offShow(e)
                            }, e.prototype.onHide = function (e) {
                                return c.onHide(e)
                            }, e.prototype.offHide = function (e) {
                                return c.offHide(e)
                            }, e.prototype.exitMiniProgram = function (e) {
                                return c.exitApplication(e)
                            }, e.prototype.isIos = function () {
                                var e = this.getSystemInfoSync();
                                return "ios" == e.platform || e.system.indexOf("iOS") >= 0
                            }, e.prototype.isAndroid = function () {
                                var e = this.getSystemInfoSync();
                                return "android" == e.platform || e.system.indexOf("Android") >= 0
                            }, e.prototype.vibrateShort = function () {
                                return c.vibrateShort()
                            }, e.prototype.vibrateLong = function () {
                                return c.vibrateLong()
                            }, e.prototype.setKeepScreenOn = function (e) {
                                return c.setKeepScreenOn({
                                    keepScreenOn: e
                                })
                            }, e.prototype.setLoadingProgress = function (e) {
                                return c.setLoadingProgress && c.setLoadingProgress(e)
                            },
                            e.prototype.loadingComplete = function (e) {
                                return c.loadingComplete ? c.loadingComplete(e) : e.success && e.success()
                            }, e.prototype.reportMonitor = function (e, t) {
                                return c.reportMonitor && c.reportMonitor(e, t)
                            }, e.prototype.installShortcut = function (e) {
                                return c.installShortcut ? c.installShortcut(e) : e.success && e.success()
                            }, e.prototype.hasShortcutInstalled = function (e) {
                                return c.hasShortcutInstalled ? c.hasShortcutInstalled(e) : e.success && e.success(!0)
                            }, e.prototype.showToast = function (e, t) {
                                return c.showToast({
                                    title: e,
                                    icon: "none",
                                    duration: t || 1500
                                })
                            }, e.prototype.showModal = function (e) {
                                return c.showModal && c.showModal(e)
                            }, e.prototype.showLoading = function (e) {
                                return c.showLoading && c.showLoading(e)
                            }, e.prototype.hideLoading = function () {
                                return c.hideLoading && c.hideLoading()
                            }, e.prototype.request = function (e) {
                                return l.default.xhrRequest(e)
                            }, e.prototype.login = function (e) {
                                var t = e.success;
                                return e.success = function (e) {
                                    var n = e && e.data && e.data.token;
                                    t && t({
                                        code: n
                                    })
                                }, c.login(e)
                            }, e.prototype.getStorage = function (e) {
                                var t = localStorage.getItem(e.key);
                                e.success && e.success(t), e.complete && e.complete()
                            }, e.prototype.getStorageSync = function (e) {
                                return localStorage.getItem(e)
                            }, e.prototype.setStorage = function (e) {
                                localStorage.setItem(e.key, e.data), e.success && e.success(), e.complete && e.complete()
                            }, e.prototype.loadSubpackage = function (e) {
                                var t = this;
                                c.loadSubpackage ? c.loadSubpackage({
                                    name: e.name,
                                    success: function (n) {
                                        t.log("加载分包" + e.name + "成功:", n), e.success && e.success(n)
                                    },
                                    fail: function (n) {
                                        t.log("加载分包" + e.name + "失败:", n), e.fail && e.fail(n)
                                    }
                                }) : (this.log("当前平台不支持分包, 使用require兼容"), e.gamejs && window.require && window.require(e.gamejs), e.success && e.success())
                            }, e.prototype.getLaunchOptionsSync = function () {
                                return c.getLaunchOptionsSync ? c.getLaunchOptionsSync() : {}
                            }, e.prototype.getSystemInfoSync = function () {
                                return c.getSystemInfoSync ? c.getSystemInfoSync() : {}
                            }, e.prototype.previewImage = function (e) {
                                return c.previewImage(e)
                            }, e.prototype.navToMiniGame = function (e) {
                                var t = e;
                                return t.pkgName = e.appId, delete t.appId, c.navigateToMiniGame(e)
                            }, e.prototype._processConf = function (e) {
                                var t = e.video_id || e.videoId;
                                t && !this._videoId && (this._videoAd = t, l.default.hasTimeout("VIDEO_AD_TIMER") || this._createVideo());
                                var n = e.banner_id || e.bannerId;
                                n && !this._bannerId && (this._bannerId = n, l.default.hasTimeout("BANNER_AD_TIMER") || this._createBanner(), this._bannerHasShow && this.showBanner());
                                var i = e.native_id || e.nativeId;
                                i && !this._nativeId && (this._nativeId = i, l.default.hasTimeout("NATIVE_AD_TIMER") || this._createNativeAd())
                            }, e.prototype.isVideoLoaded = function () {
                                return this._videoAdLoaded
                            }, e.prototype.showVideo = function (e, t, n) {
                                return a(this, void 0, void 0, function () {
                                    var i, o;
                                    return r(this, function (a) {
                                        switch (a.label) {
                                            case 0:
                                                if (!(i = this._videoAd || this._createVideo())) return this.log("视频广告未创建！"), [2, t && t()];
                                                this._onVideoAdClosed = e, a.label = 1;
                                            case 1:
                                                return a.trys.push([1, 4, , 5]), [4, i.load()];
                                            case 2:
                                                return a.sent(), [4, i.show()];
                                            case 3:
                                                return a.sent(), [3, 5];
                                            case 4:
                                                return o = a.sent(), this.warn("视频广告加载或播放失败：", o), t && t(o), [2];
                                            case 5:
                                                return n && n(), this._videoAdLoaded = !1, this.log("视频广告播放成功！"), [2]
                                        }
                                    })
                                })
                            }, e.prototype._createVideo = function () {
                                var e = this;
                                if (this.log("createVideoAd id:", this._videoId), this._videoId) {
                                    var t = c.createRewardedVideoAd({
                                        adUnitId: this._videoId
                                    });
                                    if (this._videoAd = t, !this._videoAdEventBind) return t.onLoad(function () {
                                        e.log("激励视频 广告加载成功"), e._videoAdLoaded = !0, l.default.emit(s.default.VideoAdLoaded)
                                    }), t.onClose(function (t) {
                                        e.log("激励视频 广告关闭", t);
                                        var n = !t || void 0 === t.isEnded || t.isEnded;
                                        l.default.emit(s.default.VideoAdClosed, n), e._onVideoAdClosed && e._onVideoAdClosed(n), e._onVideoAdClosed = null
                                    }), t.onError(function (n) {
                                        e.log("激励视频 广告加载失败"), e._videoAdEventBind = !1, e._videoAdLoadCount += 1, e._videoAdLoadCount < 4 && t.load()
                                    }), this._videoAdEventBind = !0, t
                                } else this.warn("无视频广告id")
                            }, e.prototype.isBannerLoaded = function () {
                                return this._bannerLoaded
                            }, e.prototype.isBannerVisible = function () {
                                return this._bannerVisible
                            }, e.prototype.showBanner = function () {
                                return a(this, void 0, void 0, function () {
                                    var e;
                                    return r(this, function (t) {
                                        return this._bannerHasShow ? [2] : (this._bannerHasShow = !0, (e = this._bannerAd || this._createBanner()) ? (e.show(), this._bannerVisible = !0, l.default.emit(s.default.BannerAdChanged), [2]) : [2])
                                    })
                                })
                            }, e.prototype.hideBanner = function () {
                                this._bannerHasShow = !1, this._bannerVisible = !1, l.default.emit(s.default.BannerAdChanged);
                                var e = this._bannerAd;
                                e && e.hide()
                            }, e.prototype.setBannerWidth = function (e) {
                                this._bannerWidth = e, this._updateBannerWidth()
                            }, e.prototype._updateBannerWidth = function () {
                                var e = this._bannerWidth,
                                    t = this._bannerAd;
                                t && t.style && t.style.width != e && (t.style.width = e)
                            }, e.prototype.getBannerHeight = function () {
                                var e = this._bannerAd;
                                return e && e.style && e.style.height ? e.style.height : .15 * this._bannerWidth
                            }, e.prototype._createBanner = function () {
                                var e = this;
                                if (this.log("[横幅广告]创建 id:", this._bannerId), this._bannerId) {
                                    this._bannerLoaded = !1, this._bannerAd && (this._bannerAd.offResize(), this._bannerAd.offError(), this._bannerAd.offLoad(), this._bannerAd.destroy());
                                    var t = this.getSystemSize(),
                                        n = t.width,
                                        i = t.height,
                                        o = this._bannerWidth,
                                        a = c.createBannerAd({
                                            adUnitId: this._bannerId,
                                            adIntervals: 30,
                                            style: this._onBannerPlaced(n, i, o)
                                        });
                                    return this._bannerAd = a, a.onResize(function (t) {
                                        if (a.style) {
                                            var o = e._onBannerResize(n, i, t.width, t.height, a.style.top, a.style.left);
                                            a.style.top != o.top && (a.style.top = o.top), a.style.left != o.left && (a.style.left = o.left)
                                        }
                                    }), a.onError(function (t) {
                                        e.warn("[横幅广告]加载失败", t), e._bannerLoaded = !1, e._bannerVisible = !1, l.default.emit(s.default.BannerAdChanged), ++e._bannerAdLoadFailCount, e._bannerAdLoadFailCount < 4 && e._createBanner()
                                    }), a.onLoad(function () {
                                        e.log("[横幅广告]加载成功"), e._bannerLoaded = !0
                                    }), a
                                }
                                this.log("无横幅广告id")
                            }, Object.defineProperty(e.prototype, "_createNativeAd", {
                                get: function () {
                                    var e = this;
                                    return this._createNativeAdDelegate || (this._createNativeAdDelegate = l.default.throttle(function (t) {
                                        e.log("[原生广告]" + t + ", 开始创建"), e.__createNativeAd()
                                    }, 6e3)), this._createNativeAdDelegate
                                },
                                enumerable: !0,
                                configurable: !0
                            }), e.prototype.__createNativeAd = function () {
                                var e = this;
                                this.supportNativeAd && this._nativeId && (this._nativeAd = c.createNativeAd({
                                    adUnitId: this._nativeId
                                }), this._nativeAd && this._nativeAd.offLoad(), this._nativeAd && this._nativeAd.offError(), this._nativeAd && this._nativeAd.onLoad(function (t) {
                                    e.log("[原生广告]加载成功:", JSON.stringify(t)), t.adList && t.adList.length > 0 && (e._naitveAdData = t.adList[0]), l.default.emit(s.default.NativeAdChanged)
                                }), this._nativeAd && this._nativeAd.onError(function (t) {
                                    e.log("[原生广告]错误:", JSON.stringify(t)), l.default.emit(s.default.NativeAdError)
                                }), this._nativeAd && this._nativeAd.load(), this._delayUpdateNative(this._nativeRefreshInterval))
                            }, e.prototype._delayUpdateNative = function (e) {
                                var t = this;
                                e >= 0 && (l.default.clearTimeout("NATIVE_AD_TIMER"), l.default.setTimeout("NATIVE_AD_TIMER", function () {
                                    t._createNativeAd()
                                }, e))
                            }, e.prototype.isNativeAdLoaded = function () {
                                return !!this._naitveAdData
                            }, e.prototype.getNativeAdData = function (e) {
                                if (this.log("获取原生广告数据"), !this._nativeId) return this.log("[原生广告]id不存在"), e && e(this._naitveAdData);
                                this._nativeAd || (this.log("[原生广告]未加载，开始加载"), this._createNativeAd("获取数据")), this._naitveAdData || this.log("[原生广告]暂时未拉取到"), e && e(this._naitveAdData)
                            }, e.prototype.refreshNativeAd = function (e) {
                                this._createNativeAd(e)
                            }, e.prototype.reportAdShow = function (e) {
                                this._nativeAd && this._nativeAd.reportAdShow({
                                    adId: e
                                })
                            }, e.prototype.reportAdClick = function (e) {
                                this._nativeAd && this._nativeAd.reportAdClick({
                                    adId: e
                                }), this._createNativeAd("已上报点击")
                            }, e.prototype.createBlockAd = function (e, t, n, i) {
                                var o = this,
                                    a = -1,
                                    r = {
                                        adUnitId: e.adUnitId || (1 == e.size ? this._blockAdIdSingle : "vertical" == e.orientation ? this._blockAdIdVertical : this._blockAdIdLandspace),
                                        style: e.style,
                                        adIntervals: 30
                                    };
                                if (!r.adUnitId) return this.log("不存在积木广告id"), a;
                                this.log("准备创建积木广告", r);
                                var s = c.createCustomAd(r);
                                return s.target = t, s.id = ++this._blockAdIndex, a = s.id, s.onLoad(function () {
                                    o.log("积木广告(" + t + ")(" + a + ")加载完成", s), n && n(), n = null, setTimeout(function () {
                                        s.showCalled || (o.log("积木广告(" + t + ")(" + a + ")调用过hide, 不需要加载结束自动显示", s), s.hide())
                                    }, 50)
                                }), s.onError(function (e) {
                                    o.log("积木广告(" + t + ")(" + a + ")报错", e)
                                }), s.onClose(function () {
                                    o.log("积木广告(" + t + ")(" + a + ")关闭")
                                }), s.onHide && s.onHide(function () {
                                    o.log("积木广告(" + t + ")(" + a + ")隐藏")
                                }), this._blockAds.push(s), a
                            }, e.prototype.isBlockAdLoaded = function (e) {
                                return this._blockAds.filter(function (t) {
                                    return t.target == e
                                }).length > 0
                            }, e.prototype.showBlockAd = function (e) {
                                var t = this,
                                    n = this._blockAds;
                                return "" != e && (n = n.filter(function (t) {
                                    return t.target == e
                                })), 0 == n.length ? [] : (n.forEach(function (e) {
                                    e && (e.isShow() || e.show().catch(function (n) {
                                        t.log("积木广告(" + e.target + ")(" + e.id + ")show报错: ", n)
                                    }), t.log("积木广告(" + e.target + ")(" + e.id + ")调用了show"), e.showCalled = !0)
                                }), n)
                            }, e.prototype.hideBlockAd = function (e) {
                                var t = this,
                                    n = this._blockAds;
                                "" != e && (n = n.filter(function (t) {
                                    return t.target == e
                                })), 0 != n.length && n.forEach(function (e) {
                                    e && (e.hide().catch(function (n) {
                                        t.log("积木广告(" + e.target + ")(" + e.id + ")hide报错: ", n)
                                    }), e.showCalled = !1)
                                })
                            }, e.prototype.destroyBlockAd = function (e) {
                                var t = this;
                                this.log("target " + e + " destroyBlockAd");
                                var n = this._blockAds;
                                n = "" != e ? n.filter(function (t) {
                                    return t.target == e
                                }) : n.slice(), this.log("target " + e + " showAll len " + n.length), 0 != n.length && n.forEach(function (n) {
                                    n && (t.log("destroy " + e), t._blockAds.splice(t._blockAds.indexOf(n), 1), n.destroy())
                                })
                            }, e.prototype.destroyAllBlockAd = function () {
                                this._blockAds.forEach(function (e) {
                                    return e.destroy()
                                }), this._blockAds.length = 0
                            }, e.prototype.isGamePortalAdLoaded = function () {
                                return this._gamePortalLoaded
                            }, e.prototype.isGamePortalAdShow = function () {
                                return this._gamePortalIsShow
                            }, e.prototype.showGamePortalAd = function () {
                                return a(this, void 0, void 0, function () {
                                    var e, t;
                                    return r(this, function (n) {
                                        switch (n.label) {
                                            case 0:
                                                if (this.log("尝试显示推荐弹窗"), !(e = this._gamePortalAd || this._createGamePortalAd())) return [2];
                                                n.label = 1;
                                            case 1:
                                                return n.trys.push([1, 5, , 6]), this._gamePortalLoaded ? [3, 3] : [4, e.load()];
                                            case 2:
                                                n.sent(), n.label = 3;
                                            case 3:
                                                return [4, e.show()];
                                            case 4:
                                                return n.sent(), this.log("显示推荐弹窗成功"), this._gamePortalLoaded = !1, this._gamePortalIsShow = !0, l.default.emit(s.default.GamePortalAdChanged), [3, 6];
                                            case 5:
                                                return t = n.sent(), this.warn("推荐弹窗显示错误:", t), [3, 6];
                                            case 6:
                                                return [2]
                                        }
                                    })
                                })
                            }, e.prototype._createGamePortalAd = function () {
                                var e = this;
                                if (this._gamePortalId) {
                                    try {
                                        this._gamePortalAd && this._gamePortalAd.destroy(), this.log("开始创建推荐弹窗"), this._gamePortalAd = c.createGamePortalAd({
                                            adUnitId: this._gamePortalId
                                        }), this._gamePortalAd.onLoad(function () {
                                            e.log("推荐弹窗已加载"), e._gamePortalLoaded = !0, l.default.emit(s.default.GamePortalAdChanged)
                                        }), this._gamePortalAd.onError(function (t) {
                                            e.log("推荐弹窗错误: ", t), e._gamePortalAd.destroy(), e._gamePortalAd = null, e._gamePortalLoaded = !1, e._gamePortalIsShow = !1, l.default.emit(s.default.GamePortalAdChanged), setTimeout(function () {
                                                e._createGamePortalAd()
                                            }, 3e3)
                                        }), this._gamePortalAd.onClose(function (t) {
                                            e.log("推荐弹窗关闭: ", t), e._gamePortalIsShow = !1, l.default.emit(s.default.GamePortalAdChanged), e._gamePortalAd.load()
                                        })
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), this.warn("推荐弹窗错误: ", e)
                                    }
                                    return this._gamePortalAd
                                }
                                this.log("不存在推荐弹窗id")
                            }, e
                    }();
                n.default = u
            }, {
                "./PlatformEventID": 58,
                "./PlatformUtils": 59
            }],
            58: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }), n.default = {
                    ConfigLoaded: "ConfigLoaded",
                    ConfigFail: "ConfigFail",
                    InsideAdsLoaded: "InsideAdsLoaded",
                    VideoAdLoaded: "VideoAdLoaded",
                    VideoAdClosed: "VideoAdClosed",
                    BannerAdChanged: "BannerAdChanged",
                    GamePortalAdChanged: "GamePortalAdChanged",
                    NativeAdChanged: "NativeAdChanged",
                    NativeAdError: "NativeAdError"
                }
            }, {}],
            59: [function (e, t, n) {
                "use strict";
                var i = this && this.__spreadArrays || function () {
                    for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                    var i = Array(e),
                        o = 0;
                    for (t = 0; t < n; t++)
                        for (var a = arguments[t], r = 0, s = a.length; r < s; r++, o++) i[o] = a[r];
                    return i
                };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var o = function () {
                    function e() {}
                    return e.shuffle = function (e) {
                        for (var t, n, i = e.length; 0 !== i;) n = Math.floor(Math.random() * i), t = e[i -= 1], e[i] = e[n], e[n] = t;
                        return e
                    }, e.removeElement = function (e, t) {
                        for (var n;
                            (n = e.indexOf(t)) > -1;) e.splice(n, 1)
                    }, e.emit = function (e) {
                        for (var t, n, o = [], a = 1; a < arguments.length; a++) o[a - 1] = arguments[a];
                        return window.cc ? (t = window.cc.systemEvent).emit.apply(t, i([e], o)) : window.Laya ? (n = window.Laya.stage).event.apply(n, i([e], o)) : void 0
                    }, e.on = function (e, t, n) {
                        return window.cc ? window.cc.systemEvent.on(e, t, n) : window.Laya ? window.Laya.stage.on(e, n, t) : void 0
                    }, e.off = function (e, t, n) {
                        return window.cc ? window.cc.systemEvent.off(e, t, n) : window.Laya ? window.Laya.stage.off(e, n, t) : void 0
                    }, e.once = function (e, t, n) {
                        return window.cc ? window.cc.systemEvent.once(e, t, n) : window.Laya ? window.Laya.stage.once(e, n, t) : void 0
                    }, e.getVisibleSize = function () {
                        return window.cc ? window.cc.view.getVisibleSize() : window.Laya ? {
                            width: window.Laya.stage.width,
                            height: window.Laya.stage.height
                        } : void 0
                    }, e.xhrRequest = function (e) {
                        !e.data && (e.data = {}), !e.method && (e.method = "POST");
                        var t = new XMLHttpRequest;
                        t.onreadystatechange = function () {
                            if (4 == t.readyState) {
                                var n = t.getResponseHeader("date") || t.getResponseHeader("Date");
                                if (t.status >= 200 && t.status <= 207) {
                                    var i = {
                                        statusCode: t.status,
                                        data: null,
                                        header: {
                                            Date: n,
                                            date: n
                                        }
                                    };
                                    try {
                                        i.data = JSON.parse(t.responseText)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), i.data = t.responseText
                                    }
                                    e.success && e.success(i)
                                } else e.fail && e.fail({
                                    statusCode: t.status,
                                    data: t.responseText,
                                    header: {
                                        Date: n,
                                        data: n
                                    }
                                });
                                e.complete && e.complete()
                            }
                        };
                        var n = this.objectToQuery(e.data);
                        "GET" == e.method && (e.url.indexOf("?") > -1 ? e.url += "&" + n : e.url += "?" + n), t.open(e.method, e.url, !0), t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8"), t.send(n)
                    }, e.queryToObject = function (e) {
                        void 0 === e && (e = "");
                        for (var t = e.substring(e.indexOf("?") + 1).split("&"), n = {}, i = 0, o = t.length; i < o; i++) {
                            var a = t[i].indexOf("=");
                            if (-1 != a) {
                                var r = t[i].substring(0, a),
                                    s = window.decodeURIComponent(t[i].substring(a + 1));
                                n[r] = s
                            }
                        }
                        return n
                    }, e.objectToQuery = function (e) {
                        var t = "";
                        for (var n in e) t += n + "=" + e[n] + "&";
                        return t.length > 0 && (t = t.substring(0, t.length - 1)), t
                    }, e.objectToKVArray = function (e) {
                        if (Array.isArray(e)) return e;
                        var t = [];
                        if ("object" == typeof e)
                            for (var n in e) t.push({
                                key: n,
                                value: "number" == typeof e[n] ? e[n] : e[n] + ""
                            });
                        return t
                    }, e.kvArrayToObject = function (e) {
                        var t = {};
                        return e.forEach(function (e) {
                            null != e.key && null != e.value && (t[e.key] = e.value)
                        }), t
                    }, e.debounce = function (e, t) {
                        var n;
                        return function () {
                            var i = this,
                                o = arguments;
                            clearTimeout(n), n = setTimeout(function () {
                                n = null, e.apply(i, o)
                            }, t)
                        }
                    }, e.throttle = function (e, t) {
                        var n;
                        return function () {
                            var i = Date.now();
                            (!n || n + t <= i) && (n = i, e.apply(this, arguments))
                        }
                    }, e.setTimeout = function (e, t, n) {
                        var i = this;
                        this.clearTimeout(e), this._timeoutMap[e] = setTimeout(function () {
                            i.clearTimeout(e), t && t()
                        }, n)
                    }, e.hasTimeout = function (e) {
                        return !!this._timeoutMap[e]
                    }, e.clearTimeout = function (e) {
                        this._timeoutMap[e] && (clearTimeout(this._timeoutMap[e]), delete this._timeoutMap[e])
                    }, e.promisify = function (e, t, n) {
                        return !n && (n = {}), new Promise(function (i, o) {
                            n.success = function (e) {
                                return i(e)
                            }, n.fail = function (e) {
                                return o(e)
                            }, e.call(t, n)
                        })
                    }, e.delegate = function (e, t, n, i) {
                        void 0 === i && (i = !1), Object.getOwnPropertyNames(e).forEach(function (o) {
                            n[o] || Object.defineProperty(n, o, {
                                get: function () {
                                    return "function" == typeof e[o] ? t && t[o] ? t[o].bind(t) : void(i && console.e(o + " 方法未实现.")) : t && t[o]
                                }
                            })
                        })
                    }, e._timeoutMap = {}, e
                }();
                n.default = o
            }, {}],
            60: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./PlatformUtils"),
                    o = function () {
                        function e() {
                            this.serverLoginType = "", this.supportNetWork = !0, this.supportLogin = !1, this.supportShare = !1, this.supportShareCallback = !1, this.supportWorldRank = !1, this.supportGroupRank = !1, this.supportFriendRank = !1, this.supportVideoAd = !1, this.supportInterAd = !1, this.supportBlockAd = !1, this.supportNativeAd = !0, this.supportGamePortalAd = !1
                        }
                        return e.prototype._methodNotImplemented = function (e, t) {
                            return t && t(), this.log("%c " + e + " method not implemented.", "color:gray")
                        }, e.prototype.init = function (e) {
                            return this._methodNotImplemented("init", e && e.fail)
                        }, e.prototype.getSystemSize = function () {
                            return {
                                width: window.innerWidth,
                                height: window.innerHeight
                            }
                        }, e.prototype.log = function () {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            console.log.apply(console, e)
                        }, e.prototype.warn = function () {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            console.warn.apply(console, e)
                        }, e.prototype.error = function () {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            console.e.apply(console, e)
                        }, e.prototype.onShow = function (e) {
                            return this._methodNotImplemented("onShow")
                        }, e.prototype.offShow = function (e) {
                            return this._methodNotImplemented("offShow")
                        }, e.prototype.onHide = function (e) {
                            return this._methodNotImplemented("onHide")
                        }, e.prototype.offHide = function (e) {
                            return this._methodNotImplemented("offHide")
                        }, e.prototype.exitMiniProgram = function (e) {
                            return window.location.reload()
                        }, e.prototype.isIos = function () {
                            return window.navigator && /iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase())
                        }, e.prototype.isAndroid = function () {
                            return window.navigator && /android/.test(navigator.userAgent.toLowerCase())
                        }, e.prototype.vibrateShort = function () {
                            return this._methodNotImplemented("vibrateShort")
                        }, e.prototype.vibrateLong = function () {
                            return this._methodNotImplemented("vibrateLong")
                        }, e.prototype.setKeepScreenOn = function (e) {
                            return this._methodNotImplemented("setKeepScreenOn")
                        }, e.prototype.setLoadingProgress = function (e) {
                            return this._methodNotImplemented("setLoadingProgress")
                        }, e.prototype.loadingComplete = function (e) {
                            return this._methodNotImplemented("loadingComplete", e && e.success)
                        }, e.prototype.reportMonitor = function (e, t) {
                            return this._methodNotImplemented("reportMonitor")
                        }, e.prototype.installShortcut = function (e) {
                            return this._methodNotImplemented("installShortcut", e && e.success)
                        }, e.prototype.hasShortcutInstalled = function (e) {
                            return this._methodNotImplemented("hasShortcutInstalled", e && e.success)
                        }, e.prototype.showToast = function (e, t) {
                            return this._methodNotImplemented("showToast")
                        }, e.prototype.showModal = function (e) {
                            var t = confirm([e.title, e.content].join("\n"));
                            e.success && e.success({
                                confirm: t,
                                cancel: !t
                            }), e.complete && e.complete()
                        }, e.prototype.showLoading = function (e) {
                            return this._methodNotImplemented("showLoading")
                        }, e.prototype.hideLoading = function () {
                            return this._methodNotImplemented("hideLoading")
                        }, e.prototype.request = function (e) {
                            return i.default.xhrRequest(e)
                        }, e.prototype.login = function (e) {
                            return this._methodNotImplemented("login", e && e.fail)
                        }, e.prototype.getUserInfo = function (e) {
                            return this._methodNotImplemented("getUserInfo", e && e.fail)
                        }, e.prototype.getSetting = function (e) {
                            return this._methodNotImplemented("getSetting", e && e.fail)
                        }, e.prototype.getStorage = function (e) {
                            var t = localStorage.getItem(e.key);
                            e.success && e.success({
                                data: t
                            }), e.complete && e.complete()
                        }, e.prototype.getStorageSync = function (e) {
                            return localStorage.getItem(e)
                        }, e.prototype.setStorage = function (e) {
                            localStorage.setItem(e.key, e.data), e.success && e.success(), e.complete && e.complete()
                        }, e.prototype.loadSubpackage = function (e) {
                            return this._methodNotImplemented("loadSubpackage", e && e.success)
                        }, e.prototype.getLaunchOptionsSync = function () {
                            return {}
                        }, e.prototype.getSystemInfoSync = function () {
                            return {}
                        }, e.prototype.previewImage = function (e) {
                            return this._methodNotImplemented("previewImage", e && e.fail)
                        }, e.prototype.navToMiniGame = function (e) {
                            return this._methodNotImplemented("navToMiniGame", e && e.fail)
                        }, e.prototype.updateScore = function (e) {
                            return this._methodNotImplemented("updateScore", e && e.fail)
                        }, e.prototype.onShare = function (e) {
                            return this._methodNotImplemented("onShare")
                        }, e.prototype.share = function (e) {
                            return this._methodNotImplemented("share", e && e.fail)
                        }, e.prototype.createUserInfoButton = function (e) {
                            return this._methodNotImplemented("createUserInfoButton")
                        }, e.prototype.createFeedbackButton = function (e) {
                            return this._methodNotImplemented("createFeedbackButton")
                        }, e.prototype.createGameClubButton = function (e) {
                            return this._methodNotImplemented("createGameClubButton")
                        }, e.prototype._processConf = function (e) {
                            return this._methodNotImplemented("_processConf")
                        }, e.prototype.isVideoLoaded = function () {
                            return this._methodNotImplemented("isVideoLoaded")
                        }, e.prototype.showVideo = function (e, t, n) {
                            return this._methodNotImplemented("showVideo", t)
                        }, e.prototype.isBannerLoaded = function () {
                            return this._methodNotImplemented("isBannerLoaded")
                        }, e.prototype.isBannerVisible = function () {
                            return this._methodNotImplemented("isBannerVisible")
                        }, e.prototype.showBanner = function () {
                            return this._methodNotImplemented("showBanner")
                        }, e.prototype.hideBanner = function () {
                            return this._methodNotImplemented("hideBanner")
                        }, e.prototype.setBannerWidth = function (e) {
                            return this._methodNotImplemented("setBannerWidth")
                        }, e.prototype.getBannerHeight = function () {
                            return this._methodNotImplemented("getBannerHeight")
                        }, e.prototype.isInterAdLoaded = function () {
                            return this._methodNotImplemented("isInterAdLoaded")
                        }, e.prototype.showInterAd = function () {
                            return this._methodNotImplemented("showInterAd")
                        }, e.prototype.isNativeAdLoaded = function () {
                            return !0
                        }, e.prototype.getNativeAdData = function (e) {}, e.prototype.refreshNativeAd = function (e) {
                            return this._methodNotImplemented("refreshNativeAd")
                        }, e.prototype.reportAdShow = function (e) {
                            return this._methodNotImplemented("reportAdShow")
                        }, e.prototype.reportAdClick = function (e) {
                            return this._methodNotImplemented("reportAdClick")
                        }, e.prototype.createBlockAd = function (e, t, n, i) {
                            return this._methodNotImplemented("createBlockAd")
                        }, e.prototype.isBlockAdLoaded = function (e) {
                            return this._methodNotImplemented("isBlockAdLoaded")
                        }, e.prototype.showBlockAd = function (e) {
                            return this._methodNotImplemented("showBlockAd")
                        }, e.prototype.hideBlockAd = function (e) {
                            return this._methodNotImplemented("hideBlockAd")
                        }, e.prototype.destroyBlockAd = function (e) {
                            return this._methodNotImplemented("destroyBlockAd")
                        }, e.prototype.destroyAllBlockAd = function () {
                            return this._methodNotImplemented("destroyAllBlockAd")
                        }, e.prototype.isGamePortalAdLoaded = function () {
                            return this._methodNotImplemented("isGamePortalAdLoaded")
                        }, e.prototype.isGamePortalAdShow = function () {
                            return this._methodNotImplemented("isGamePortalAdShow")
                        }, e.prototype.showGamePortalAd = function () {
                            return this._methodNotImplemented("showGamePortalAd")
                        }, e
                    }();
                n.default = o
            }, {
                "./PlatformUtils": 59
            }],
            61: [function (e, t, n) {
                "use strict";

                function i(e, t, n) {
                    return {
                        width: n,
                        top: t - 104,
                        left: .5 * (e - n)
                    }
                }

                function o(e, t, n, i, o, a) {
                    return {
                        top: t - i,
                        left: .5 * (e - n)
                    }
                }
                var a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    },
                    s = this && this.__spreadArrays || function () {
                        for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                        var i = Array(e),
                            o = 0;
                        for (t = 0; t < n; t++)
                            for (var a = arguments[t], r = 0, s = a.length; r < s; r++, o++) i[o] = a[r];
                        return i
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var l = e("./PlatformEventID"),
                    c = e("./PlatformUtils"),
                    u = window.wx,
                    d = function () {
                        function e() {
                            this.serverLoginType = "wx", this.supportNetWork = !0, this.supportLogin = !0, this.supportShare = !0, this.supportShareCallback = !0, this.supportWorldRank = !0, this.supportGroupRank = !0, this.supportFriendRank = !0, this.supportVideoAd = !0, this.supportBlockAd = !0, this.supportNativeAd = !1, this._videoAdLoaded = !1, this._videoAdEventBind = !1, this._videoAdLoadCount = 0, this._onVideoAdClosed = null, this._bannerVisible = !1, this._bannerHasShow = !1, this._bannerLoaded = !1, this._bannerAdLoadFailCount = 0, this._bannerWidth = 420, this._interAdLoaded = !1, this._blockAds = [], this._blockAdIndex = 0, this._gamePortalLoaded = !1, this._gamePortalIsShow = !1
                        }
                        return Object.defineProperty(e.prototype, "supportInterAd", {
                            get: function () {
                                return !!u.createInterstitialAd
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "supportGamePortalAd", {
                            get: function () {
                                return !!u.createGamePortal
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.init = function (e) {
                            var t = this;
                            this._videoId = e.videoId, this._bannerId = e.bannerId, this._interId = e.interId, this._gamePortalId = e.gamePortalId, this._onBannerPlaced = e.onBannerPlaced || i, this._onBannerResize = e.onBannerResize || o, this._useLog = void 0 === e.useLog || e.useLog, this.setSaveLog(!0), e.autoUpdate && this._autoUpdate(), this._sys = this.getSystemInfoSync(), this.log("sys: ", JSON.stringify(this._sys)), c.default.setTimeout("BANNER_AD_TIMER", function () {
                                t._bannerId && !t._bannerAd && t._createBanner()
                            }, e.loadBannerDelay || 0), c.default.setTimeout("VIDEO_AD_TIMER", function () {
                                t._videoId && !t._videoAd && t._createVideo()
                            }, e.loadVideoAdDelay || 0), c.default.setTimeout("INTER_AD_TIMER", function () {
                                t._interId && !t._interAd && t._createInterAd()
                            }, e.loadInterAdDelay || 0), u.showShareMenu({
                                withShareTicket: !0,
                                menus: ["shareAppMessage", "shareTimeline"]
                            })
                        }, e.prototype._autoUpdate = function () {
                            var e = this;
                            if ("function" == typeof u.getUpdateManager) {
                                var t = u.getUpdateManager();
                                t.onCheckForUpdate(function (t) {
                                    e.log("hasUpdate:" + t.hasUpdate)
                                }), t.onUpdateReady(function () {
                                    t.applyUpdate()
                                }), t.onUpdateFailed(function () {})
                            }
                        }, e.prototype.getSystemSize = function () {
                            return {
                                width: this._sys.screenWidth,
                                height: this._sys.screenHeight
                            }
                        }, e.prototype.log = function () {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            return this._useLog && console.log.apply(console, e)
                        }, e.prototype.warn = function () {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            return this._useLog && console.warn.apply(console, e)
                        }, e.prototype.error = function () {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            return this._useLog && console.e.apply(console, e)
                        }, e.prototype.onShow = function (e) {
                            return u.onShow(e)
                        }, e.prototype.offShow = function (e) {
                            return u.offShow(e)
                        }, e.prototype.onHide = function (e) {
                            return u.onHide(e)
                        }, e.prototype.offHide = function (e) {
                            return u.offHide(e)
                        }, e.prototype.exitMiniProgram = function (e) {
                            return u.exitMiniProgram(e)
                        }, e.prototype.isIos = function () {
                            var e = this.getSystemInfoSync();
                            return "ios" == e.platform || e.system.indexOf("iOS") >= 0
                        }, e.prototype.isAndroid = function () {
                            var e = this.getSystemInfoSync();
                            return "android" == e.platform || e.system.indexOf("Android") >= 0
                        }, e.prototype.vibrateShort = function () {
                            return u.vibrateShort()
                        }, e.prototype.vibrateLong = function () {
                            return u.vibrateLong()
                        }, e.prototype.setKeepScreenOn = function (e) {
                            return u.setKeepScreenOn({
                                keepScreenOn: e
                            })
                        }, e.prototype.showToast = function (e, t) {
                            return u.showToast({
                                title: e,
                                icon: "none",
                                duration: t || 1500
                            })
                        }, e.prototype.showModal = function (e) {
                            return u.showModal(e)
                        }, e.prototype.showLoading = function (e) {
                            return u.showLoading(e)
                        }, e.prototype.hideLoading = function () {
                            return u.hideLoading()
                        }, e.prototype.request = function (e) {
                            return u.request(e)
                        }, e.prototype.login = function (e) {
                            return u.login(e)
                        }, e.prototype.getUserInfo = function (e) {
                            return u.getUserInfo(e)
                        }, e.prototype.getSetting = function (e) {
                            return u.getSetting(e)
                        }, e.prototype.getStorage = function (e) {
                            return u.getStorage({
                                key: e.key,
                                success: function (t) {
                                    e.success && e.success(t.data)
                                },
                                fail: e.fail,
                                complete: e.complete
                            })
                        }, e.prototype.getStorageSync = function (e) {
                            return u.getStorageSync(e)
                        }, e.prototype.setStorage = function (e) {
                            return u.setStorage(e)
                        }, e.prototype.loadSubpackage = function (e) {
                            var t = this;
                            u.loadSubpackage ? u.loadSubpackage({
                                name: e.name,
                                success: function (n) {
                                    t.log("加载分包" + e.name + "成功:", n), e.success && e.success(n)
                                },
                                fail: function (n) {
                                    t.log("加载分包" + e.name + "失败:", n), e.fail && e.fail(n)
                                }
                            }) : (this.log("当前平台不支持分包, 使用require兼容"), e.gamejs && window.require && window.require(e.gamejs), e.success && e.success())
                        }, e.prototype.getLaunchOptionsSync = function () {
                            return u.getLaunchOptionsSync ? u.getLaunchOptionsSync() : {}
                        }, e.prototype.getSystemInfoSync = function () {
                            return u.getSystemInfoSync ? u.getSystemInfoSync() : {}
                        }, e.prototype.previewImage = function (e) {
                            return u.previewImage(e)
                        }, e.prototype.navToMiniGame = function (e) {
                            return u.navigateToMiniProgram(e)
                        }, e.prototype.updateScore = function (e) {
                            var t = c.default.objectToKVArray(e.data);
                            return u.setUserCloudStorage({
                                KVDataList: t,
                                success: e.success,
                                fail: e.fail,
                                complete: e.complete
                            })
                        }, e.prototype.onShare = function (e) {
                            return u.onShareAppMessage(e)
                        }, e.prototype.share = function (e) {
                            return u.shareAppMessage(e)
                        }, e.prototype.createUserInfoButton = function (e) {
                            return u.createUserInfoButton(e)
                        }, e.prototype.createFeedbackButton = function (e) {
                            return u.createFeedbackButton(e)
                        }, e.prototype.createGameClubButton = function (e) {
                            return u.createGameClubButton(e)
                        }, e.prototype._processConf = function (e) {
                            var t = e.video_id || e.videoId;
                            t && !this._videoId && (this._videoAd = t, c.default.hasTimeout("VIDEO_AD_TIMER") || this._createVideo());
                            var n = e.banner_id || e.bannerId;
                            n && !this._bannerId && (this._bannerId = n, c.default.hasTimeout("BANNER_AD_TIMER") || this._createBanner(), this._bannerHasShow && this.showBanner());
                            var i = e.inter_id || e.interId;
                            i && !this._interId && (this._interId = i, c.default.hasTimeout("INTER_AD_TIMER") || this._createInterAd())
                        }, e.prototype.isVideoLoaded = function () {
                            return this._videoAdLoaded
                        }, e.prototype.showVideo = function (e, t, n) {
                            return a(this, void 0, void 0, function () {
                                var i, o;
                                return r(this, function (a) {
                                    switch (a.label) {
                                        case 0:
                                            if (!(i = this._videoAd || this._createVideo())) return this.log("视频广告未创建！"), [2, t && t()];
                                            this._onVideoAdClosed = e, a.label = 1;
                                        case 1:
                                            return a.trys.push([1, 4, , 5]), [4, i.load()];
                                        case 2:
                                            return a.sent(), [4, i.show()];
                                        case 3:
                                            return a.sent(), [3, 5];
                                        case 4:
                                            return o = a.sent(), this.warn("视频广告加载或播放失败：", o), t && t(o), [2];
                                        case 5:
                                            return n && n(), this._videoAdLoaded = !1, this.log("视频广告播放成功！"), [2]
                                    }
                                })
                            })
                        }, e.prototype._createVideo = function () {
                            var e = this;
                            if (this.log("createVideoAd id:", this._videoId), this._videoId) {
                                var t = u.createRewardedVideoAd({
                                    adUnitId: this._videoId
                                });
                                if (this._videoAd = t, !this._videoAdEventBind) return t.onLoad(function () {
                                    e.log("激励视频 广告加载成功"), e._videoAdLoaded = !0, c.default.emit(l.default.VideoAdLoaded)
                                }), t.onClose(function (t) {
                                    e.log("激励视频 广告关闭", t);
                                    var n = !t || void 0 === t.isEnded || t.isEnded;
                                    c.default.emit(l.default.VideoAdClosed, n), e._onVideoAdClosed && e._onVideoAdClosed(n), e._onVideoAdClosed = null
                                }), t.onError(function (n) {
                                    e.log("激励视频 广告加载失败"), e._videoAdEventBind = !1, e._videoAdLoadCount += 1, e._videoAdLoadCount < 4 && t.load()
                                }), this._videoAdEventBind = !0, t
                            } else this.warn("无视频广告id")
                        }, e.prototype.isBannerLoaded = function () {
                            return this._bannerLoaded
                        }, e.prototype.isBannerVisible = function () {
                            return this._bannerVisible
                        }, e.prototype.showBanner = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t;
                                return r(this, function (n) {
                                    switch (n.label) {
                                        case 0:
                                            if (this._bannerHasShow = !0, !(e = this._bannerAd || this._createBanner())) return [2];
                                            n.label = 1;
                                        case 1:
                                            return n.trys.push([1, 4, , 5]), this._bannerHasShow ? [4, e.show()] : [3, 3];
                                        case 2:
                                            n.sent(), this._bannerVisible = !0, c.default.emit(l.default.BannerAdChanged), n.label = 3;
                                        case 3:
                                            return [3, 5];
                                        case 4:
                                            return t = n.sent(), this.warn("横幅广告显示失败: ", t), this._bannerVisible = !1, c.default.emit(l.default.BannerAdChanged), [3, 5];
                                        case 5:
                                            return [2]
                                    }
                                })
                            })
                        }, e.prototype.hideBanner = function () {
                            this._bannerHasShow = !1, this._bannerVisible = !1, c.default.emit(l.default.BannerAdChanged);
                            var e = this._bannerAd;
                            e && e.hide()
                        }, e.prototype.setBannerWidth = function (e) {
                            this._bannerWidth = e, this._updateBannerWidth()
                        }, e.prototype._updateBannerWidth = function () {
                            var e = this._bannerWidth,
                                t = this._bannerAd;
                            t && t.style && t.style.width != e && (t.style.width = e)
                        }, e.prototype.getBannerHeight = function () {
                            var e = this._bannerAd;
                            return e && e.style && e.style.realHeight ? e.style.realHeight : 120
                        }, e.prototype._createBanner = function () {
                            var e = this;
                            if (this.log("createBannerAd id:", this._bannerId), this._bannerId) {
                                this._bannerLoaded = !1, this._bannerAd && this._bannerAd.destroy();
                                var t = this.getSystemSize(),
                                    n = t.width,
                                    i = t.height,
                                    o = this._bannerWidth,
                                    a = u.createBannerAd({
                                        adUnitId: this._bannerId,
                                        adIntervals: 30,
                                        style: this._onBannerPlaced(n, i, o)
                                    });
                                return this._bannerAd = a, a.onResize(function (t) {
                                    if (e.log("横幅广告尺寸改变: ", t), a.style) {
                                        var o = e._onBannerResize(n, i, t.width, t.height, a.style.top, a.style.left);
                                        a.style.top != o.top && (a.style.top = o.top), a.style.left != o.left && (a.style.left = o.left)
                                    }
                                }), a.onError(function (t) {
                                    e.warn("横幅广告加载失败", t), e._bannerLoaded = !1, e._bannerVisible = !1, c.default.emit(l.default.BannerAdChanged), ++e._bannerAdLoadFailCount, e._bannerAdLoadFailCount < 4 && e._createBanner()
                                }), a.onLoad(function () {
                                    e.log("横幅广告加载成功"), e._bannerLoaded = !0
                                }), a
                            }
                            this.log("无横幅广告id")
                        }, e.prototype.isInterAdLoaded = function () {
                            return this._interAdLoaded
                        }, e.prototype.showInterAd = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t;
                                return r(this, function (n) {
                                    switch (n.label) {
                                        case 0:
                                            if (e = this._interAd || this._createInterAd(), !this._interAd) return [2];
                                            this.log("尝试显示插屏广告"), n.label = 1;
                                        case 1:
                                            return n.trys.push([1, 3, , 4]), [4, e.show()];
                                        case 2:
                                            return n.sent(), [3, 4];
                                        case 3:
                                            return t = n.sent(), this.log("插屏广告显示错误:", t), [3, 4];
                                        case 4:
                                            return this._interAdLoaded = !1, [2]
                                    }
                                })
                            })
                        }, e.prototype._createInterAd = function () {
                            var e = this;
                            if (this._interId) {
                                this._interAdLoaded = !1, this._interAd && this._interAd.destroy();
                                var t = u.createInterstitialAd({
                                    adUnitId: this._interId
                                });
                                return this._interAd = t, t.onLoad(function () {
                                    e._interAdLoaded = !0, e.log("插屏广告已加载")
                                }), t.onError(function (t) {
                                    e._interAdLoaded = !1, e.warn("插屏广告错误: ", t)
                                }), t
                            }
                            this.log("不存在插屏广告id")
                        }, e.prototype.createBlockAd = function (e, t, n, i) {
                            var o = this,
                                a = -1,
                                r = {
                                    adUnitId: e.adUnitId || (1 == e.size ? this._blockAdIdSingle : "vertical" == e.orientation ? this._blockAdIdVertical : this._blockAdIdLandspace),
                                    style: e.style,
                                    adIntervals: 30
                                };
                            if (!r.adUnitId) return this.log("不存在积木广告id"), a;
                            this.log("准备创建积木广告", r);
                            var s = u.createCustomAd(r);
                            return s.target = t, s.id = ++this._blockAdIndex, a = s.id, s.onLoad(function () {
                                o.log("积木广告(" + t + ")(" + a + ")加载完成", s), n && n(), n = null, setTimeout(function () {
                                    s.showCalled || (o.log("积木广告(" + t + ")(" + a + ")调用过hide, 不需要加载结束自动显示", s), s.hide())
                                }, 50)
                            }), s.onError(function (e) {
                                o.log("积木广告(" + t + ")(" + a + ")报错", e)
                            }), s.onClose(function () {
                                o.log("积木广告(" + t + ")(" + a + ")关闭")
                            }), s.onHide && s.onHide(function () {
                                o.log("积木广告(" + t + ")(" + a + ")隐藏")
                            }), this._blockAds.push(s), a
                        }, e.prototype.isBlockAdLoaded = function (e) {
                            return this._blockAds.filter(function (t) {
                                return t.target == e
                            }).length > 0
                        }, e.prototype.showBlockAd = function (e) {
                            var t = this,
                                n = this._blockAds;
                            return "" != e && (n = n.filter(function (t) {
                                return t.target == e
                            })), 0 == n.length ? [] : (n.forEach(function (e) {
                                e && (e.isShow() || e.show().catch(function (n) {
                                    t.log("积木广告(" + e.target + ")(" + e.id + ")show报错: ", n)
                                }), t.log("积木广告(" + e.target + ")(" + e.id + ")调用了show"), e.showCalled = !0)
                            }), n)
                        }, e.prototype.hideBlockAd = function (e) {
                            var t = this,
                                n = this._blockAds;
                            "" != e && (n = n.filter(function (t) {
                                return t.target == e
                            })), 0 != n.length && n.forEach(function (e) {
                                e && (e.hide().catch(function (n) {
                                    t.log("积木广告(" + e.target + ")(" + e.id + ")hide报错: ", n)
                                }), e.showCalled = !1)
                            })
                        }, e.prototype.destroyBlockAd = function (e) {
                            var t = this;
                            this.log("target " + e + " destroyBlockAd");
                            var n = this._blockAds;
                            n = "" != e ? n.filter(function (t) {
                                return t.target == e
                            }) : n.slice(), this.log("target " + e + " showAll len " + n.length), 0 != n.length && n.forEach(function (n) {
                                n && (t.log("destroy " + e), t._blockAds.splice(t._blockAds.indexOf(n), 1), n.destroy())
                            })
                        }, e.prototype.destroyAllBlockAd = function () {
                            this._blockAds.forEach(function (e) {
                                return e.destroy()
                            }), this._blockAds.length = 0
                        }, e.prototype.isGamePortalAdLoaded = function () {
                            return this._gamePortalLoaded
                        }, e.prototype.isGamePortalAdShow = function () {
                            return this._gamePortalIsShow
                        }, e.prototype.showGamePortalAd = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t;
                                return r(this, function (n) {
                                    switch (n.label) {
                                        case 0:
                                            if (this.log("尝试显示推荐弹窗"), !(e = this._gamePortalAd || this._createGamePortalAd())) return [2];
                                            n.label = 1;
                                        case 1:
                                            return n.trys.push([1, 5, , 6]), this._gamePortalLoaded ? [3, 3] : [4, e.load()];
                                        case 2:
                                            n.sent(), n.label = 3;
                                        case 3:
                                            return [4, e.show()];
                                        case 4:
                                            return n.sent(), this.log("显示推荐弹窗成功"), this._gamePortalLoaded = !1, this._gamePortalIsShow = !0, c.default.emit(l.default.GamePortalAdChanged), [3, 6];
                                        case 5:
                                            return t = n.sent(), this.warn("推荐弹窗显示错误:", t), [3, 6];
                                        case 6:
                                            return [2]
                                    }
                                })
                            })
                        }, e.prototype._createGamePortalAd = function () {
                            var e = this;
                            if (this._gamePortalId) {
                                try {
                                    this._gamePortalAd && this._gamePortalAd.destroy(), this.log("开始创建推荐弹窗"), this._gamePortalAd = u.createGamePortal({
                                        adUnitId: this._gamePortalId
                                    }), this._gamePortalAd.onLoad(function () {
                                        e.log("推荐弹窗已加载"), e._gamePortalLoaded = !0, c.default.emit(l.default.GamePortalAdChanged)
                                    }), this._gamePortalAd.onError(function (t) {
                                        e.log("推荐弹窗错误: ", t), e._gamePortalAd.destroy(), e._gamePortalAd = null, e._gamePortalLoaded = !1, e._gamePortalIsShow = !1, c.default.emit(l.default.GamePortalAdChanged), setTimeout(function () {
                                            e._createGamePortalAd()
                                        }, 3e3)
                                    }), this._gamePortalAd.onClose(function (t) {
                                        e.log("推荐弹窗关闭: ", t), e._gamePortalIsShow = !1, c.default.emit(l.default.GamePortalAdChanged), e._gamePortalAd.load()
                                    })
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), this.warn("推荐弹窗错误: ", e)
                                }
                                return this._gamePortalAd
                            }
                            this.log("不存在推荐弹窗id")
                        }, e.prototype.setSaveLog = function (e) {
                            var t = "function" == typeof u.getLogManager ? u.getLogManager() : null;
                            e && t && "devtools" != this.getSystemInfoSync().platform ? t && (console.log = function () {
                                h.log.apply(console, arguments), t.log.apply(t, arguments)
                            }, console.info = function () {
                                h.info.apply(console, arguments), t.info.apply(t, arguments)
                            }, console.warn = function () {
                                h.warn.apply(console, arguments), t.warn.apply(t, arguments)
                            }, console.debug = function () {
                                h.debug.apply(console, arguments), t.debug.apply(t, arguments)
                            }, console.e = function () {
                                for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                                h.error.apply(console, e), t.warn.apply(t, s(["[ERROR]"], e))
                            }) : (console.log = h.log, console.info = h.info, console.warn = h.warn, console.debug = h.debug, console.e = h.error)
                        }, e
                    }();
                n.default = d;
                var h = {
                    log: console.log,
                    info: console.info,
                    warn: console.warn,
                    debug: console.debug,
                    error: console.e
                }
            }, {
                "./PlatformEventID": 58,
                "./PlatformUtils": 59
            }],
            62: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                e("./PlatformEventID"), e("./PlatformUtils");
                var i = function () {
                    function e(e) {
                        this._conf = {}, this._insideAds = [], this._shareConfig = [], this._isHeXie = !0, this._platform = e
                    }
                    return Object.defineProperty(e.prototype, "conf", {
                        get: function () {
                            return this._conf
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "insideAds", {
                        get: function () {
                            return this._insideAds
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "shareConfig", {
                        get: function () {
                            return this._shareConfig
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isHeXie", {
                        get: function () {
                            return this._isHeXie
                        },
                        enumerable: !0,
                        configurable: !0
                    }), e.prototype.init = function (e) {
                        this._processParams(e)
                    }, e.prototype._processParams = function (e) {
                        this._gameId = e.gameId, this._gameVersion = e.gameVersion, e.pullMainConfig && this.loadMainConfig(), e.pullInsideAds && this.loadInsideAds(), e.pullShareConfig && this.loadShareConfig(), e.pullStrategyShareInfo && this.loadStrategyShareInfo()
                    }, e.prototype.getUserIdOrCode = function (e) {
                        var t = this.getSavedUserId(e.key);
                        if (t) return e.success && e.success({
                            user_id: t
                        });
                        this._platform.login({
                            success: function (t) {
                                e.success && e.success({
                                    code: t.code
                                })
                            },
                            fail: e.fail
                        })
                    }, e.prototype.getSavedUserId = function (e) {
                        return this._platform.getStorageSync(this._getUserIdKey(e)) || ""
                    }, e.prototype.saveUserId = function (e, t) {
                        if ("object" == typeof t) {
                            var n = t;
                            n && n.data && n.data.user_id && this._platform.setStorage({
                                key: this._getUserIdKey(e),
                                data: n.data.user_id
                            })
                        } else if ("string" == typeof t) {
                            var i = t;
                            i && this._platform.setStorage({
                                key: this._getUserIdKey(e),
                                data: i
                            })
                        }
                    }, e.prototype._getUserIdKey = function (e) {
                        return "_uid_" + e
                    }, e.prototype.isLongScreen = function () {
                        var e = this._platform.getSystemSize(),
                            t = e.width / e.height;
                        return t > 2 || t < .5
                    }, e.prototype.loadMainConfig = function (e) {
                        e.fail()
                    }, e.prototype.loadInsideAds = function (e) {}, e.prototype.loadShareConfig = function (e) {}, e.prototype.getShareConfig = function (e) {
                        var t = this.shareConfig;
                        if (!t || 0 == t.length) return null;
                        var n = t.findIndex(function (t) {
                            return t.position_id == e
                        });
                        return t[n] || null
                    }, e.prototype.getAddons = function (e, t, n, i) {
                        void 0 === e && (e = !0), void 0 === t && (t = !0), void 0 === n && (n = !0), void 0 === i && (i = {});
                        var o = i,
                            a = this._platform.getLaunchOptionsSync();
                        if (a && (e && (o.cid = a.query && a.query.cid ? a.query.cid : "self"), t && (o.agent = a.query && a.query.agent ? a.query.agent : "official")), n) {
                            var r = this._platform.getSystemInfoSync();
                            r && r.platform && "string" == typeof r.platform && (o.os = r.platform.toLowerCase(), "android" != o.os && "ios" != o.os && (o.os = "android"))
                        }
                        return o
                    }, e.prototype.getStorageSpecial = function (e) {
                        return this._platform.getStorage({
                            key: e.key,
                            success: function (t) {
                                var n = null;
                                try {
                                    n = JSON.parse(t.data).v
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = null
                                }
                                e.success && e.success(n)
                            },
                            fail: e.fail,
                            complete: e.complete
                        })
                    }, e.prototype.getStorageSyncSpecial = function (e) {
                        var t = this._platform.getStorageSync(e),
                            n = null;
                        try {
                            n = JSON.parse(t).v
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = null
                        }
                        return n
                    }, e.prototype.setStorageSpecial = function (e) {
                        var t = JSON.stringify({
                            v: e.value
                        });
                        return this._platform.setStorage({
                            key: e.key,
                            data: t,
                            success: e.success,
                            fail: e.fail,
                            complete: e.complete
                        })
                    }, e.prototype.requestSpecial = function (e) {
                        return !e.data && (e.data = {}), !e.data.game_id && (e.data.game_id = this._gameId), !e.data.version && (e.data.version = this._gameVersion), !e.method && (e.method = "POST"), !e.header && (e.header = {
                            "Content-Type": "application/x-www-form-urlencoded",
                            Accept: "application/json"
                        }), !e.data.login_type && (e.data.login_type = this._platform.serverLoginType), this._platform.request(e)
                    }, e.prototype.loginAndGetUserInfo = function (e) {
                        var t = this;
                        this._platform.login({
                            success: function (n) {
                                var i = n.code;
                                t._platform.getUserInfo({
                                    success: function (t) {
                                        var n = {
                                            code: i,
                                            iv: t.iv,
                                            rawData: t.rawData,
                                            encryptedData: t.encryptedData,
                                            signature: t.signature
                                        };
                                        e.success && e.success(n)
                                    },
                                    fail: function (t) {
                                        e.fail && e.fail(t)
                                    },
                                    complete: e.complete
                                })
                            },
                            fail: function (t) {
                                e.fail && e.fail(t), e.complete && e.complete()
                            }
                        })
                    }, e.prototype.shareStat = function (e, t, n) {}, e.prototype.getRandomStrategyShareInfo = function () {
                        if (this._strategyShareInfo && 0 != this._strategyShareInfo.length) return this._strategyShareInfo[Math.floor(Math.random() * this._strategyShareInfo.length)]
                    }, e.prototype.loadStrategyShareInfo = function (e) {
                        e && e.fail && e.fail()
                    }, e.prototype.reportUser = function (e, t, n, i, o, a) {}, e.prototype.reportShare = function (e, t, n) {}, e.prototype.reportLevel = function (e, t) {}, e.prototype.reportVideo = function (e) {}, e.prototype.reportChannelData = function (e, t, n, i) {
                        var o = this;
                        void 0 === i && (i = null), this._platform.supportLogin && this._platform.supportNetWork ? this.getUserIdOrCode({
                            key: "strategy",
                            success: function (a) {
                                var r = o._platform.getLaunchOptionsSync();
                                if (o.strategyChannelId ? a.channel_id = o.strategyChannelId : r.query && r.query.cid && "normalshare" != r.query.cid ? a.channel_id = r.query.cid : a.channel_id = "self", t)
                                    for (var s in t) {
                                        var l = t[s];
                                        void 0 !== l && (a[s] = l)
                                    }
                                o._platform.log("请求投放" + e + "：数据：", a);
                                var c = function (t) {
                                    o._platform.log("请求" + e + "失败", t), i && i()
                                };
                                o.requestSpecial({
                                    url: e,
                                    data: a,
                                    success: function (t) {
                                        t && t.data && 0 == t.data.code ? (o._platform.log("请求" + e + "成功", t), t.data.my_user_id && o.saveUserId("strategy", t.data.my_user_id), n && n()) : c && c(t)
                                    },
                                    fail: c,
                                    complete: null
                                })
                            },
                            fail: i
                        }) : i && i()
                    }, e
                }();
                n.default = i
            }, {
                "./PlatformEventID": 58,
                "./PlatformUtils": 59
            }],
            63: [function (e, t, n) {
                "use strict";
                var i = this && this.__spreadArrays || function () {
                    for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                    var i = Array(e),
                        o = 0;
                    for (t = 0; t < n; t++)
                        for (var a = arguments[t], r = 0, s = a.length; r < s; r++, o++) i[o] = a[r];
                    return i
                };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var o = e("./BasePlatform"),
                    a = e("./PlatformEventID"),
                    r = e("./PlatformUtils"),
                    s = e("./YTSDK"),
                    l = e("./TestPlatform"),
                    c = e("./WxPlatform"),
                    u = e("./OppoPlatform"),
                    d = new(function () {
                        function e() {
                            this.version = "0.0.3", this._isBrowser = !1;
                            var e = {
                                isQQ: void 0,
                                isTT: void 0,
                                isWx: c.default,
                                isOppo: u.default,
                                isVivo: void 0,
                                isMeizu: void 0,
                                isHuawei: void 0
                            };
                            for (var t in e)
                                if (this[t] && e[t]) {
                                    this.platform = new e[t];
                                    break
                                } this.platform || (console.log("SDK错误: 不支持的平台"), this.platform = new l.default, this._isBrowser = !0), this.platform && (this.sdk = new s.default(this.platform))
                        }
                        return Object.defineProperty(e.prototype, "isQQ", {
                            get: function () {
                                return void 0 !== window.qq
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "isTT", {
                            get: function () {
                                return void 0 !== window.tt
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "isWx", {
                            get: function () {
                                return void 0 !== window.wx && void 0 === window.qq && void 0 === window.tt
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "isOppo", {
                            get: function () {
                                return void 0 !== window.qg && "OPPO" == window.qg.getProvider()
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "isVivo", {
                            get: function () {
                                return void 0 !== window.qg && "vivo" == window.qg.getProvider()
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "isMeizu", {
                            get: function () {
                                return void 0 !== window.mz_jsb
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "isHuawei", {
                            get: function () {
                                return void 0 !== window.hbs
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "isBrowser", {
                            get: function () {
                                return this._isBrowser
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(e.prototype, "Event", {
                            get: function () {
                                return a.default
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.init = function (e) {
                            this.platform.log("游戏版本: ", e.gameVersion), this.platform.log("SDK版本: ", this.version), this.sdk.init(e), this.platform.init(e)
                        }, e.prototype.emit = function (e) {
                            for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                            return r.default.emit.apply(r.default, i([e], t))
                        }, e.prototype.on = function (e, t, n) {
                            return r.default.on(e, t, n)
                        }, e.prototype.off = function (e, t, n) {
                            return r.default.off(e, t, n)
                        }, e.prototype.once = function (e, t, n) {
                            return r.default.once(e, t, n)
                        }, e.prototype.promisify = function (e, t, n) {
                            return r.default.promisify(e, t, n)
                        }, e
                    }());
                r.default.delegate(new o.default, d.platform, d, !1), r.default.delegate(o.default.prototype, d.platform, d, !1), d.sdk && (r.default.delegate(d.sdk, d.sdk, d), r.default.delegate(d.sdk.constructor.prototype, d.sdk, d)), n.default = d, window.yt = d
            }, {
                "./BasePlatform": 56,
                "./OppoPlatform": 57,
                "./PlatformEventID": 58,
                "./PlatformUtils": 59,
                "./TestPlatform": 60,
                "./WxPlatform": 61,
                "./YTSDK": 62
            }],
            64: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.effectType = "scale", t.duration = 100, t._originScaleX = 1, t._originScaleY = 1, t._target = null, t._tween = null, t._tween = new Laya.Tween, t
                    }
                    return o(t, e), t.prototype.onEnable = function () {
                        this.owner instanceof Laya.Sprite ? (this._target = this.owner, this._originScaleX = this._target.scaleX, this._originScaleY = this._target.scaleY) : this._target = null, this.play()
                    }, t.prototype.onDisable = function () {
                        this._target && (this._tween.clear(), this._target.scaleX = this._originScaleX, this._target.scaleY = this._originScaleY)
                    }, t.prototype.play = function () {
                        this._target && (this._tween.clear(), this._target.scale(.5 * this._originScaleX, .5 * this._originScaleY), this._tween.to(this._target, {
                            scaleX: this._originScaleX,
                            scaleY: this._originScaleY
                        }, this.duration, Laya.Ease.circOut))
                    }, t
                }(Laya.Script);
                n.default = a
            }, {}],
            65: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return o(t, e), t.prototype.onEnable = function () {
                        if (this.owner instanceof Laya.Sprite) {
                            var e = t.getScale();
                            this.owner.scale(e, e)
                        }
                    }, t.prototype.onDisable = function () {}, t.getScale = function () {
                        return Math.min(Laya.stage.height / 1280, 1)
                    }, t
                }(Laya.Script);
                n.default = a
            }, {}],
            66: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = null !== e && e.apply(this, arguments) || this;
                        return t.padding = 150, t
                    }
                    return o(t, e), t.prototype.play = function () {
                        var e = this.owner;
                        this._moveRight(e)
                    }, t.prototype.stop = function () {
                        var e = this.owner;
                        Laya.Tween.clearAll(e)
                    }, t.prototype.onDisable = function () {
                        this.stop()
                    }, t.prototype._moveRight = function (e) {
                        e.x = -this.padding, Laya.Tween.clearAll(e), Laya.Tween.to(e, {
                            x: Laya.stage.width + this.padding
                        }, 12e3, null, Laya.Handler.create(this, this._moveLeft, [e]))
                    }, t.prototype._moveLeft = function (e) {
                        e.x = Laya.stage.width + this.padding, Laya.Tween.clearAll(e), Laya.Tween.to(e, {
                            x: -this.padding
                        }, 12e3, null, Laya.Handler.create(this, this._moveRight, [e]))
                    }, t
                }(Laya.Script);
                n.default = a
            }, {}],
            67: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.rotation = 10, t._timeline = null, t
                    }
                    return o(t, e), t.prototype.init = function () {
                        var e = this.rotation,
                            t = this.owner;
                        t instanceof Laya.Sprite && (this._timeline = new Laya.TimeLine).addLabel("rotation1", 0).to(t, {
                            rotation: e
                        }, 150).addLabel("rotation2", 0).to(t, {
                            rotation: -e
                        }, 150).addLabel("rotation3", 0).to(t, {
                            rotation: e
                        }, 150).addLabel("rotation4", 0).to(t, {
                            rotation: 0
                        }, 150).addLabel("rotation5", 0).to(t, {
                            rotation: 0
                        }, 2500)
                    }, t.prototype.onEnable = function () {
                        this._timeline || this.init(), this._timeline && this._timeline.play(0, !0)
                    }, t.prototype.onDisable = function () {
                        this._timeline && this._timeline.pause()
                    }, t
                }(Laya.Script);
                n.default = a
            }, {}],
            68: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.scale = 1.1, t._timeline = null, t
                    }
                    return o(t, e), t.prototype.init = function () {
                        var e = this.scale,
                            t = this.owner;
                        if (t instanceof Laya.Sprite) {
                            var n = this._timeline = new Laya.TimeLine,
                                i = t.scaleX,
                                o = t.scaleY;
                            n.addLabel("scale1", 0).to(t, {
                                scaleX: e,
                                scaleY: e
                            }, 400).addLabel("scale2", 0).to(t, {
                                scaleX: i,
                                scaleY: o
                            }, 400)
                        }
                    }, t.prototype.onEnable = function () {
                        this._timeline || this.init(), this._timeline && this._timeline.play(0, !0)
                    }, t.prototype.onDisable = function () {
                        this._timeline && this._timeline.pause()
                    }, t
                }(Laya.Script);
                n.default = a
            }, {}],
            69: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../common/EventID"),
                    r = e("./DialogEffect"),
                    s = e("../core/MyBanner"),
                    l = e("../core/GameHelper"),
                    c = e("../data/DataBus"),
                    u = e("../platform/yt"),
                    d = function (e) {
                        function t() {
                            var t = null !== e && e.apply(this, arguments) || this;
                            return t._target = null, t._nativeBottom = null, t._nearBanner = !1, t._showNative = !0, t.isQuickBuy = !1, t
                        }
                        return o(t, e), t.prototype.onEnable = function () {
                            if (this._nearBanner = this._needNearBanner(), !this._target && this.owner instanceof Laya.Sprite && (this._target = this.owner), this._target) {
                                var e = this._findComponentInParent(this._target, r.default),
                                    t = e ? e.duration + 20 : 0;
                                this._target.visible = !1, Laya.timer.once(t, this, this._init)
                            } else Laya.timer.once(0, this, this._init)
                        }, t.prototype.onDisable = function () {
                            Laya.timer.clearAll(this), Laya.stage.off(a.default.BANNER_CHANGED, this, this._onBannerChanged), Laya.stage.off(a.default.MY_BANNER_CHANGED, this, this._onBannerChanged), l.default.removeBannerStatus(this), this._nativeBottom && (this._nativeBottom.active = this._nativeBottom.visible = !1)
                        }, t.prototype.setShowNative = function (e) {
                            this._showNative = e, e || this._nativeBottom && (this._nativeBottom.active = this._nativeBottom.visible = !1)
                        }, t.prototype._init = function () {
                            var e = this.isQuickBuy ? u.default.conf.quick_buy_banner_delay : u.default.conf.banner_delay,
                                t = parseFloat(e) || 0;
                            t > 0 ? (this._nearBanner && this._target && (this._target.mouseEnabled = !1), l.default.addBannerStatus(this, !1), Laya.timer.once(1e3 * t, this, this._showBanner)) : this._showBanner(), this._target && (this._target.visible = !0), this._onBannerChanged(), Laya.stage.on(a.default.BANNER_CHANGED, this, this._onBannerChanged), Laya.stage.on(a.default.MY_BANNER_CHANGED, this, this._onBannerChanged)
                        }, t.prototype._hasNativeAds = function () {
                            return this._showNative && this._nativeBottom && !this._nativeBottom.destroyed && u.default.isNativeAdLoaded && u.default.isNativeAdLoaded()
                        }, t.prototype._showBanner = function () {
                            if (this._hasNativeAds()) return this._target.mouseEnabled = !0, void(this._nativeBottom.active = this._nativeBottom.visible = !0);
                            l.default.addBannerStatus(this, !0), this._nearBanner && this._target && (this._target.mouseEnabled = !0)
                        }, t.prototype._onBannerChanged = function () {
                            if (!this._hasNativeAds()) {
                                var e = this._getBannerHeight(),
                                    t = this._target;
                                if (t instanceof Laya.Sprite && t.parent instanceof Laya.Sprite) {
                                    var n = t.parent.globalToLocal(new Laya.Point(0, Laya.stage.height - e)).y - t.height + t.pivotY;
                                    (this._nearBanner || t.y > n) && (t.y = n)
                                }
                            }
                        }, t.prototype._needNearBanner = function () {
                            return c.default.instance.mergeData.level >= (parseInt(u.default.conf.close_btn_level) || 0) && (u.default.isQQ ? 1 == parseInt(u.default.conf.close_btn_flag_qq) : 1 == parseInt(u.default.conf.close_btn_flag))
                        }, t.prototype._getBannerHeight = function () {
                            return u.default.isQQ ? this._getBannerHeightForQQ() : this._getBannerHeightForWx()
                        }, t.prototype._getBannerHeightForWx = function () {
                            var e = 0;
                            return u.default.isBannerVisible() ? (e = u.default.getBannerHeight() / u.default.getSystemSize().height * Laya.stage.height, u.default.isIos() && u.default.isLongScreen() && (e += 65)) : s.default.instance.isValid() ? e = s.default.instance.getHeight() + 20 : (e = 70, u.default.isIos() && u.default.isLongScreen() ? e += 65 : u.default.getSystemSize().width > 720 && (e = 10)), e + 30
                        }, t.prototype._getBannerHeightForQQ = function () {
                            var e = 0;
                            return s.default.instance.isValid() ? e = s.default.instance.getHeight() + 20 : u.default.isBannerVisible() ? (e = u.default.getBannerHeight() / u.default.getSystemSize().height * Laya.stage.height, u.default.isIos() && u.default.isLongScreen() && (e += 10), console.info("获取横幅高度: ", e), t._lastBannerHeight = e) : (e = 50, u.default.isIos() && u.default.isLongScreen() ? e += 10 : u.default.getSystemSize().width > 720 && (e = 10)), e + 60
                        }, t.prototype._findComponentInParent = function (e, t) {
                            for (; e;) {
                                var n = e.getComponent(t);
                                if (n) return n;
                                e = e.parent
                            }
                            return null
                        }, t._lastBannerHeight = 230, t
                    }(Laya.Script);
                n.default = d
            }, {
                "../common/EventID": 15,
                "../core/GameHelper": 23,
                "../core/MyBanner": 25,
                "../data/DataBus": 32,
                "../platform/yt": 63,
                "./DialogEffect": 64
            }],
            70: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.zoom = 1.1, t.duration = 100, t._originScaleX = 1, t._originScaleY = 1, t._target = null, t._tween = null, t._tween = new Laya.Tween, t
                    }
                    return o(t, e), t.prototype.onEnable = function () {
                        this.owner instanceof Laya.Sprite ? (this._target = this.owner, this._originScaleX = this._target.scaleX, this._originScaleY = this._target.scaleY) : this._target = null
                    }, t.prototype.onDisable = function () {
                        this._target && (this._tween.clear(), this._target.scaleX = this._originScaleX, this._target.scaleY = this._originScaleY)
                    }, t.prototype.onMouseDown = function () {
                        this._applyZoom()
                    }, t.prototype.onMouseUp = function () {
                        this._cancelZoom()
                    }, t.prototype.onMouseOver = function () {
                        this._applyZoom()
                    }, t.prototype.onMouseOut = function () {
                        this._cancelZoom()
                    }, t.prototype._applyZoom = function () {
                        this._target && (this._tween.clear(), this._tween.to(this._target, {
                            scaleX: this._originScaleX * this.zoom,
                            scaleY: this._originScaleY * this.zoom
                        }, this.duration))
                    }, t.prototype._cancelZoom = function () {
                        this._target && (this._tween.clear(), this._tween.to(this._target, {
                            scaleX: this._originScaleX,
                            scaleY: this._originScaleY
                        }, this.duration))
                    }, t
                }(Laya.Script);
                n.default = a
            }, {}],
            71: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("./S2Controller"),
                    r = e("./S2Math"),
                    s = e("./S2Macro"),
                    l = function (e) {
                        function t(t, n) {
                            var i = e.call(this, t) || this;
                            return i._stage = null, i._interval = 6, i._frameSum = 0, i.nearestItemList = [], i.diffcult = .6, i._stage = n, i._interval = r.s2Math.rndElement([6, 12, 18, 24, 30]), Math.random() < .3 ? i.diffcult = r.s2Math.rndFloat(.8, .9) : i.diffcult = r.s2Math.rndFloat(.6, .7), i
                        }
                        return o(t, e), t.prototype.update = function (e) {
                            var t = this._interval;
                            this.snake.lowPower && (t = 30), ++this._frameSum, this._frameSum >= t && (this._frameSum = 0, this._calcNextAngle(e)), this._changeAngle(e)
                        }, t.prototype._changeAngle = function (e) {
                            var t = this.snake.angle,
                                n = this._angle;
                            if (t != n) {
                                for (; n - t > Math.PI;) n -= 2 * Math.PI;
                                for (; n - t < -Math.PI;) n += 2 * Math.PI;
                                var i = n - t,
                                    o = 2 * Math.PI * e;
                                Math.abs(i) > o ? t += i > 0 ? o : -o : t = n
                            }
                            this.snake.changeAngle(t, e)
                        }, t.prototype._calcNextAngle = function (e) {
                            var t = this.snake,
                                n = this.snake.id,
                                i = (3 * t.turnRadius + t.scale * s.s2Macro.snake_body_radius) * this.diffcult;
                            t.lowPower && (i *= 2.5);
                            var o = this._stage.collider.getTraceTree().nearest(t, 12, i * i).filter(function (e) {
                                return e[0].snakeId != n
                            });
                            this.nearestItemList = o;
                            for (var a = o.map(function (e) {
                                    var n = {
                                        x: t.x - e[0].x,
                                        y: t.y - e[0].y
                                    };
                                    r.s2Math.normalize(n);
                                    var o = Math.sqrt(e[1]) / i;
                                    return n.x *= o, n.y *= o, n
                                }), l = 0, c = o.length; l < c; ++l) {
                                var u = o[l][0];
                                if (u.isHead && this._stage.player && u.snakeId == this._stage.player.snake.id) {
                                    var d = r.s2Math.dot(t.vx, t.vy, -u.vx, -u.vy),
                                        h = {
                                            px: u.x - t.x,
                                            py: u.y - t.y
                                        };
                                    r.s2Math.normalize(h, ["px", "py"]);
                                    var f = r.s2Math.dot(t.vx, t.vy, h.px, h.py);
                                    if (d > .3 && f < -.3) {
                                        var p = 60 * t.scale,
                                            _ = {
                                                x: u.x - u.vx * p - t.x,
                                                y: u.y - u.vy * p - t.y
                                            };
                                        r.s2Math.normalize(_), a.push(_);
                                        break
                                    }
                                }
                            }
                            var y = this._stage.getRect(),
                                g = t.x,
                                m = t.y;
                            if (g <= 30 ? a.push({
                                    x: 1,
                                    y: 0
                                }) : g >= y.width - 30 && a.push({
                                    x: -1,
                                    y: 0
                                }), m <= 30 ? a.push({
                                    y: 1,
                                    x: 0
                                }) : m >= y.height - 30 && a.push({
                                    y: -1,
                                    x: 0
                                }), a.length > 0) {
                                var v = a.reduce(function (e, t) {
                                    return e.x += t.x, e.y += t.y, e
                                }, {
                                    x: 0,
                                    y: 0
                                });
                                this._angle = Math.atan2(v.y, v.x) + r.s2Math.rndFloat(-.5, .5)
                            } else {
                                var L = t.nearestFoodList.map(function (e) {
                                        var n = {
                                            vx: e[0].x - t.x,
                                            vy: e[0].y - t.y
                                        };
                                        r.s2Math.normalize(n, ["vx", "vy"]);
                                        var i = r.s2Math.dot(t.vx, t.vy, n.vx, n.vy);
                                        return {
                                            food: e[0],
                                            distance: e[1],
                                            cosAngle: i
                                        }
                                    }),
                                    w = Math.pow(2 * t.turnRadius, 2);
                                if ((L = L.filter(function (e) {
                                        return e.cosAngle > .3 || e.distance > w
                                    })).sort(function (e, t) {
                                        return t.cosAngle > 0 && e.cosAngle > 0 ? e.distance - t.distance : t.cosAngle - e.cosAngle
                                    }), L.length > 0) {
                                    var b = L[0].food;
                                    this._angle = Math.atan2(b.y - t.y, b.x - t.x), Math.random() < .25 && (this._angle += r.s2Math.rndFloat(-.5, .5))
                                } else Math.random() < .05 && (this._angle = Math.random() * Math.PI * 2)
                            }
                        }, t
                    }(a.s2Controller);
                n.s2Ai = l
            }, {
                "./S2Controller": 73,
                "./S2Macro": 75,
                "./S2Math": 77
            }],
            72: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./S2Math"),
                    o = e("./S2Types"),
                    a = e("./S2Map"),
                    r = function () {
                        function e(e) {
                            this.stage = null, this.foodTree = null, this.collideTree = null, this.traceTree = null, this.stage = e
                        }
                        return e.prototype.init = function () {
                            this._resetFoodTree(), this._resetCollideTree()
                        }, e.prototype.clear = function () {
                            this.foodTree && this.foodTree.clear(), this.foodTree = null, this.collideTree && this.collideTree.clear(), this.traceTree = null
                        }, e.prototype.update = function () {
                            this._updateCollideTree()
                        }, e.prototype.getDeadList = function () {
                            return this._collide()
                        }, e.prototype.getSafePosition = function () {
                            return this._getSafePosition()
                        }, e.prototype.getTraceTree = function () {
                            return this.traceTree || this._updateTraceTree(), this.traceTree
                        }, e.prototype._resetCollideTree = function () {
                            var e = this.stage.getRect();
                            this.collideTree && this.collideTree.clear(), this.collideTree = new a.s2Map(e.width, e.height, 320)
                        }, e.prototype._resetFoodTree = function () {
                            var e = this.stage.getRect();
                            this.foodTree && this.foodTree.clear(), this.foodTree = new a.s2Map(e.width, e.height, 260)
                        }, e.prototype._resetTraceTree = function () {
                            this.traceTree = new kdTree([], function (e, t) {
                                return i.s2Math.distanceSqr(e.x, e.y, t.x, t.y)
                            }, ["x", "y"])
                        }, e.prototype._updateCollideTree = function () {
                            this.collideTree.refresh()
                        }, e.prototype._updateFoodTree = function () {
                            this.foodTree.refresh()
                        }, e.prototype._updateTraceTree = function () {
                            this._resetTraceTree();
                            for (var e = this.stage.snakeList, t = e.length, n = 0; n < t; ++n)(i = e[n]).path.updateTraceList();
                            for (n = 0; n < t; ++n)
                                for (var i, o = (i = e[n]).path.traceList, a = 0, r = o.length; a < r; ++a) {
                                    var s = o[a];
                                    s.snakeId = i.id, this.traceTree.insert(s)
                                }
                        }, e.prototype._collide = function () {
                            for (var e = [], t = this.stage.snakeList, n = 0, a = t.length; n < a; ++n) {
                                var r = t[n],
                                    s = r.list[0];
                                if (s)
                                    for (var l = this.collideTree.retrieve(s), c = 0, u = l.length; c < u; ++c) {
                                        var d = l[c];
                                        if (d.container != r && i.s2Math.distanceSqr(s.x, s.y, d.x, d.y) <= (s.radius + d.radius) * (s.radius + d.radius)) {
                                            if (d.type != o.s2PointType.Head) {
                                                e.push(r), r.killer = d.container;
                                                break
                                            }
                                            var h = d.x - s.x,
                                                f = d.y - s.y;
                                            if (i.s2Math.dot(r.vx, r.vy, h, f) > 0) {
                                                e.push(r), r.killer = d.container;
                                                break
                                            }
                                        }
                                    }
                            }
                            return e
                        }, e.prototype._getSafePosition = function () {
                            return this.collideTree.getEmptyPosition()
                        }, e
                    }();
                n.s2Collider = r
            }, {
                "./S2Map": 76,
                "./S2Math": 77,
                "./S2Types": 87
            }],
            73: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e(e) {
                        this._angle = 0, this._slipDistance = 0, this.snake = null, this.snake = e, e.controller = this
                    }
                    return e.prototype.getAngle = function () {
                        return this._angle
                    }, e.prototype.update = function (e) {
                        this.snake.changeAngle(this._angle, e), this.snake.accelRatio = Math.max(0, Math.min(1, this._slipDistance / 300))
                    }, e
                }();
                n.s2Controller = i
            }, {}],
            74: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("./S2PointContainer"),
                    r = e("./S2Macro"),
                    s = e("./S2Math"),
                    l = e("./S2Types"),
                    c = e("./S2Scheduler"),
                    u = function (e) {
                        function t(t) {
                            var n = e.call(this, t) || this;
                            n.map = {}, n.energy = 0, n.grid = 1, n.rows = 0, n.cols = 0, n.validValueList = [15, 20, 25, 30, 40], n.validValueList2 = [50, 60, 70, 80, 90, 100], n.validValueList3 = [110, 130, 150, 170, 190], n.grid = r.s2Macro.map_food_grid;
                            var i = n.stage.getRect();
                            return n.cols = Math.ceil(i.width / n.grid), n.rows = Math.ceil(i.height / n.grid), n
                        }
                        return o(t, e), t.prototype.addFood = function (e, t, n) {
                            var i = this.addPoint();
                            if (i) {
                                i.x = t, i.y = n, i.value = e, i.type = l.s2PointType.Food, i.radius = r.s2Macro.food_radius * this.scale;
                                var o = Math.floor(t / this.grid),
                                    a = Math.floor(n / this.grid) * this.cols + o;
                                i.__mapkey = a, void 0 === this.map[a] && (this.map[a] = 0), this.map[a] += e, this.energy += e, this.stage.collider.foodTree.insert(i)
                            }
                            return i
                        }, t.prototype.removeFood = function (e) {
                            var t = e.__mapkey;
                            return void 0 !== t && (void 0 !== this.map[t] && (this.map[t] -= e.value), this.map[t] < 0 && (this.map[t] = 0)), this.energy -= e.value, this.energy < 0 && (this.energy = 0), this.stage.collider.foodTree.remove(e), this.removePoint(e)
                        }, t.prototype.clear = function () {
                            this.map = {}, this.energy = 0, e.prototype.clear.call(this)
                        }, t.prototype.update = function () {
                            var e = this;
                            if (!(this.energy >= r.s2Macro.map_total_food_max)) {
                                for (var t = [], n = this.stage.getRect(), i = 0, o = this.cols * this.rows; i < o; ++i) {
                                    var a = this.map[i] || 0;
                                    if (a < r.s2Macro.map_food_min)
                                        for (var l = i % this.cols, u = Math.floor(i / this.cols), d = s.s2Math.rndInt(r.s2Macro.map_food_min, r.s2Macro.map_food_max), h = Math.min(r.s2Macro.map_food_increase, d - a); h > this.validValueList[0];) {
                                            var f = Math.min(h, s.s2Math.rndElement(this.validValueList)),
                                                p = Math.min(n.width, l * this.grid + s.s2Math.rndFloat(0, this.grid)),
                                                _ = Math.min(n.height, u * this.grid + s.s2Math.rndFloat(0, this.grid));
                                            t.push([f, p, _]), h -= f
                                        }
                                }
                                s.s2Math.shuffle(t);
                                var y = Math.ceil(t.length / 5);
                                c.s2Scheduler.instance.schedule(function () {
                                    for (var n = t.splice(0, 5), i = 0, o = n.length; i < o; ++i) {
                                        var a = n[i],
                                            r = a[0],
                                            s = a[1],
                                            l = a[2];
                                        e.addFood(r, s, l)
                                    }
                                }, this.stage, .02, y)
                            }
                        }, t.prototype.setScale = function (e) {
                            this.scale != e && (this.scale = e, this._updateAllPointRadius())
                        }, t.prototype._updateAllPointRadius = function () {
                            for (var e = 0, t = this.list.length; e < t; ++e) this.list[e].radius = r.s2Macro.food_radius * this.scale
                        }, t
                    }(a.s2PointContainer);
                n.s2FoodContainer = u
            }, {
                "./S2Macro": 75,
                "./S2Math": 77,
                "./S2PointContainer": 82,
                "./S2Scheduler": 84,
                "./S2Types": 87
            }],
            75: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }), n.s2Macro = {
                    game_duration: 120,
                    map_width: 5120,
                    map_height: 5120,
                    player_number: 10,
                    snake_head_radius: 25,
                    snake_body_radius: 18,
                    snake_body_spacing: -4,
                    snake_init_length: 4,
                    snake_init_energy: 400,
                    snake_feed_distance: 300,
                    snake_eat_distance: 50,
                    snake_init_velocity: 400,
                    snake_max_velocity: 800,
                    snake_player_accel_ratio: .4,
                    turn_radius: 45,
                    food_radius: 10,
                    feed_interval: 1,
                    map_food_grid: 512,
                    map_food_min: 150,
                    map_food_max: 300,
                    map_total_food_max: 8e3,
                    map_food_increase: 50,
                    ai_revive_chance: .7
                }
            }, {}],
            76: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e(e, t, n) {
                        void 0 === n && (n = 320), this._maps = {}, this._mapWidth = 5120, this._mapHeight = 5120, this._gridCols = 100, this._gridRows = 100, this._gridSize = 320, this.init(e, t, n)
                    }
                    return e.prototype.init = function (e, t, n) {
                        this._mapWidth = e, this._mapHeight = t, this._gridSize = n, this._gridCols = Math.ceil(e / n), this._gridRows = Math.ceil(t / n), this.clear()
                    }, e.prototype.clear = function () {
                        this._maps = {}
                    }, e.prototype.insert = function (e) {
                        var t = this._getKey(e),
                            n = this._maps[t];
                        n || (n = this._maps[t] = []), n.push(e), e.__map__ = 1e10 + t
                    }, e.prototype.remove = function (e) {
                        var t = e.__map__;
                        if (t) {
                            t -= 1e10;
                            var n = this._maps[t];
                            if (n) {
                                var i = n.indexOf(e);
                                i > -1 && n.splice(i, 1)
                            }
                        }
                    }, e.prototype.refresh = function () {
                        for (var e = [], t = Object.keys(this._maps), n = 0, i = t.length; n < i; ++n) {
                            for (var o = Number(t[n]), a = this._maps[o], r = a.length - 1; r >= 0; --r) {
                                var s = a[r];
                                this._getKey(s) != o && (a.splice(r, 1), e.push(s))
                            }
                            0 == a.length && delete this._maps[o]
                        }
                        for (n = 0, i = e.length; n < i; ++n) s = e[n], this.insert(s)
                    }, e.prototype.retrieve = function (e) {
                        var t = Math.floor(e.x / this._gridSize),
                            n = Math.floor(e.y / this._gridSize),
                            i = (n << 16) + t,
                            o = this._maps[i] || [];
                        return i = t - 1 + (n << 16), this._maps[i] && (o = o.concat(this._maps[i])), i = (n << 16) + (t + 1), this._maps[i] && (o = o.concat(this._maps[i])), i = (n - 1 << 16) + t, this._maps[i] && (o = o.concat(this._maps[i])), i = (n + 1 << 16) + t, this._maps[i] && (o = o.concat(this._maps[i])), i = t - 1 + (n - 1 << 16), this._maps[i] && (o = o.concat(this._maps[i])), i = (n + 1 << 16) + (t + 1), this._maps[i] && (o = o.concat(this._maps[i])), i = t - 1 + (n + 1 << 16), this._maps[i] && (o = o.concat(this._maps[i])), i = (n - 1 << 16) + (t + 1), this._maps[i] && (o = o.concat(this._maps[i])), o
                    }, e.prototype.getEmptyPosition = function () {
                        var e = [],
                            t = this;
                        if (function n(i, o, a, r, s) {
                                var l = 0;
                                if (a <= 3 || r <= 3)
                                    for (var c = void 0, u = 0; u < a; ++u)
                                        for (var d = 0; d < r; ++d) c = (o + d << 16) + (i + u), l += t._maps[c] ? t._maps[c].length : 0;
                                else {
                                    var h = Math.floor(a / 2),
                                        f = Math.floor(r / 2);
                                    l = n(i, o, h, f, s + 1) + n(i + h, o, a - h, f, s + 1) + n(i, o + f, h, r - f, s + 1) + n(i + h, o + f, a - h, r - f, s + 1)
                                }
                                return e.push({
                                    x: i,
                                    y: o,
                                    w: a,
                                    h: r,
                                    depth: s,
                                    sum: l
                                }), l
                            }(0, 0, this._gridCols, this._gridRows, 0), e.sort(function (e, t) {
                                return e.sum != t.sum ? e.sum - t.sum : e.depth - t.depth
                            }), e[0]) {
                            var n = e[0],
                                i = n.x + n.w / 2,
                                o = n.y + n.h / 2;
                            return {
                                x: i * this._gridSize,
                                y: o * this._gridSize
                            }
                        }
                        return {
                            x: Math.random() * this._mapWidth,
                            y: Math.random() * this._mapHeight
                        }
                    }, e.prototype._getKey = function (e) {
                        var t = Math.floor(e.x / this._gridSize);
                        return (Math.floor(e.y / this._gridSize) << 16) + t
                    }, e
                }();
                n.s2Map = i
            }, {}],
            77: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.cross = function (e, t, n, i) {
                        return t * n - e * i
                    }, e.dot = function (e, t, n, i) {
                        return e * n + t * i
                    }, e.distance = function (e, t, n, i) {
                        return Math.sqrt((e - n) * (e - n) + (t - i) * (t - i))
                    }, e.distanceSqr = function (e, t, n, i) {
                        return (e - n) * (e - n) + (t - i) * (t - i)
                    }, e.mag = function (e, t) {
                        return Math.sqrt(e * e + t * t)
                    }, e.magSqr = function (e, t) {
                        return e * e + t * t
                    }, e.normalize = function (e, t) {
                        void 0 === t && (t = ["x", "y"]);
                        var n = e[t[0]],
                            i = e[t[1]],
                            o = n * n + i * i;
                        if (1 == o) return e;
                        if (0 == o) return e;
                        var a = 1 / Math.sqrt(o);
                        return e[t[0]] *= a, e[t[1]] *= a, e
                    }, e.rndInt = function (e, t) {
                        return Math.floor(Math.random() * (t - e) + e)
                    }, e.rndFloat = function (e, t) {
                        return Math.random() * (t - e) + e
                    }, e.rndElement = function (e) {
                        return e[Math.floor(Math.random() * e.length)]
                    }, e.shuffle = function (e) {
                        for (var t, n, i = e.length; 0 !== i;) n = Math.floor(Math.random() * i), t = e[i -= 1], e[i] = e[n], e[n] = t;
                        return e
                    }, e
                }();
                n.s2Math = i
            }, {}],
            78: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./S2Math"),
                    o = function () {
                        function e() {
                            this._list = []
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.get = function (e, t) {
                            if (this._list.length > 0) {
                                var n = this._list.pop();
                                return n.x = e, n.y = t, n.vx = 0, n.vy = 0, n.angle = 0, n.distance = 0, n.snakeId = -1, n.isHead = !1, n
                            }
                            return {
                                index: 0,
                                x: e,
                                y: t,
                                vx: 0,
                                vy: 0,
                                angle: 0,
                                distance: 0,
                                snakeId: -1,
                                isHead: !1
                            }
                        }, e.prototype.put = function (e) {
                            e.x = e.y = 0, e.distance = 0, this._list.push(e)
                        }, e.prototype.clear = function () {
                            this._list.length = 0
                        }, e.prototype.triggerGC = function (e) {
                            this._list.length = Math.min(this._list.length, e)
                        }, e.prototype.size = function () {
                            return this._list.length
                        }, e
                    }();
                n.s2PathItemPool = o;
                var a = function () {
                    function e() {
                        this.list = [], this.traceList = [], this._traceDirty = !1
                    }
                    return e.prototype.getLength = function () {
                        for (var e = 0, t = 0, n = this.list.length; t < n; ++t) e += this.list[t].distance;
                        return e
                    }, e.prototype.setPositions = function (e, t) {
                        var n = e.length,
                            i = this.list.length;
                        if (0 != n && 0 != i) {
                            for (var o = 0, a = e[o], r = e[o - 1], s = a && r ? a.radius + r.radius + t : 0, l = 0, c = 0, u = 0, d = 0, h = (this.list[l], this.list[l + 1]); o < n;) a.overlap = !1, l >= i - 1 ? (this._setPosition(a, i - 1, 0), a.overlap = l > i - 1, a = e[o += 1], l += 1) : s - u < (d = h.distance - c) ? (c += s - u, this._setPosition(a, l, c), u = 0, a = e[o += 1], r = e[o - 1], s = a && r ? a.radius + r.radius + t : 0) : (u += d, l += 1, c = 0, h = this.list[l + 1]);
                            return l
                        }
                    }, e.prototype._setPosition = function (e, t, n) {
                        var i = this.list[t],
                            o = this.list[t + 1];
                        o ? (e.x = i.x + o.vx * n, e.y = i.y + o.vy * n, e.angle = o.angle) : (e.x = i.x, e.y = i.y, e.angle = i.angle), e.dirty = !0
                    }, e.prototype.updateTraceList = function () {
                        if (this._traceDirty || 0 == this.traceList.length) {
                            this.traceList = [];
                            var e = this.list.length;
                            if (e > 0)
                                for (var t = 0, n = 0, i = this.list[0].angle, o = 0; o < e; ++o) {
                                    var a = this.list[o];
                                    t += a.distance, n += a.angle - i, i = a.angle, (t > 150 || n > Math.PI / 3 || n < -Math.PI / 3 || o == e - 1 || 0 == o) && (this.traceList.push(a), t = 0, n = 0)
                                }
                        }
                    }, e.prototype.add = function (e, t) {
                        var n = o.instance.get(e, t),
                            a = this.list[0];
                        a && (a.distance = i.s2Math.distance(n.x, n.y, a.x, a.y), a.vx = a.x - n.x, a.vy = a.y - n.y, n.angle = a.angle = Math.atan2(-a.vy, -a.vx), i.s2Math.normalize(a, ["vx", "vy"]), n.vx = a.vx, n.vy = a.vy, a.isHead = !1), n.isHead = !0, this.list.unshift(n), this._traceDirty = !0
                    }, e.prototype.remove = function (e) {
                        if (e > -1 && e < this.list.length) {
                            for (var t = this.list.splice(e), n = 0, i = t.length; n < i; ++n) {
                                var a = t[n];
                                o.instance.put(a)
                            }
                            this._traceDirty = !0
                        }
                    }, e.prototype.clear = function () {
                        for (var e = 0, t = this.list.length; e < t; ++e) {
                            var n = this.list[e];
                            o.instance.put(n)
                        }
                        this.list.length = 0, this._traceDirty = !0
                    }, e
                }();
                n.s2Path = a
            }, {
                "./S2Math": 77
            }],
            79: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.timeStart = function (e) {
                        var t = this._getData(e),
                            n = performance.now();
                        t.tsStart = n
                    }, e.timeEnd = function (e) {
                        var t = this._getData(e),
                            n = performance.now(),
                            i = n - (t.tsStart || n);
                        return t.sum += i, ++t.times, i > t.max && (t.max = i), i < t.min && (t.min = i), t.tsStart = 0, i
                    }, e.sum = function (e) {
                        var t = this._getData(e);
                        return {
                            times: t.times,
                            sum: t.sum,
                            average: t.sum / t.times,
                            max: t.max,
                            min: t.min
                        }
                    }, e.clear = function (e) {
                        delete this._map[e]
                    }, e.clearAll = function () {
                        this._map = {}
                    }, e._getData = function (e) {
                        return this._map[e] || (this._map[e] = {
                            times: 0,
                            sum: 0,
                            max: 0,
                            min: 1 / 0,
                            tsStart: 0
                        }), this._map[e]
                    }, e._map = {}, e
                }();
                n.default = i
            }, {}],
            80: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return o(t, e), t.prototype.setAngle = function (e) {
                        this._angle = e
                    }, t.prototype.setSlipDistance = function (e) {
                        this._slipDistance = e
                    }, t
                }(e("./S2Controller").s2Controller);
                n.s2Player = a
            }, {
                "./S2Controller": 73
            }],
            81: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./S2Types"),
                    o = function () {
                        function e() {
                            this.x = 0, this.y = 0, this.radius = 0, this.angle = 0, this.type = i.s2PointType.None, this.container = null, this.value = 0, this.userData = null, this.dirty = !1, this.overlap = !1, e.instanceList.push(this)
                        }
                        return e.prototype.destroy = function () {
                            var t = e.instanceList.indexOf(this);
                            t > -1 && e.instanceList.splice(t, 1)
                        }, e.instanceList = [], e
                    }();
                n.s2Point = o
            }, {
                "./S2Types": 87
            }],
            82: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./S2PointPool"),
                    o = function () {
                        function e(e) {
                            this.id = 0, this.list = [], this.stage = null, this.scale = 1, this.removedUserDataList = [], this.stage = e
                        }
                        return e.prototype.addPoint = function () {
                            var e = i.s2PointPool.instance.get();
                            return -1 == this.list.indexOf(e) ? (e.container && e.container.removePoint(e), e.container = this, e.dirty = !0, e.overlap = !1, this.list.push(e), e) : null
                        }, e.prototype.removePoint = function (e) {
                            var t = this.list.indexOf(e);
                            if (t > -1) {
                                e.container = null, e.dirty = !0;
                                var n = {
                                    type: e.type,
                                    eater: null,
                                    userData: e.userData
                                };
                                return this.removedUserDataList.push(n), e.userData = null, i.s2PointPool.instance.put(e), this.list.splice(t, 1), n
                            }
                            return null
                        }, e.prototype.removeAllPoints = function () {
                            for (var e = 0, t = this.list.length; e < t; ++e) {
                                var n = this.list[e];
                                n.container = null, n.dirty = !0;
                                var o = {
                                    type: n.type,
                                    eater: null,
                                    userData: n.userData
                                };
                                this.removedUserDataList.push(o), n.userData = null, i.s2PointPool.instance.put(n)
                            }
                            this.list.length = 0
                        }, e.prototype.clear = function () {
                            this.removeAllPoints()
                        }, e
                    }();
                n.s2PointContainer = o
            }, {
                "./S2PointPool": 83
            }],
            83: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("./S2Point"),
                    o = e("./S2Types"),
                    a = function () {
                        function e() {
                            this._list = []
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.get = function () {
                            return this._list.length > 0 ? this._list.pop() : new i.s2Point
                        }, e.prototype.put = function (e) {
                            e.container && e.container.removePoint(e), e.type = o.s2PointType.None, e.container = null, this._list.push(e)
                        }, e.prototype.clear = function () {
                            for (var e = 0, t = this._list.length; e < t; ++e) this._list[e].destroy();
                            this._list.length = 0
                        }, e.prototype.triggerGC = function (e) {
                            for (var t = e, n = this._list.length; t < n; ++t) this._list[t].destroy();
                            this._list.length = Math.min(this._list.length, e)
                        }, e.prototype.size = function () {
                            return this._list.length
                        }, e
                    }();
                n.s2PointPool = a
            }, {
                "./S2Point": 81,
                "./S2Types": 87
            }],
            84: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {
                        this._map = {}, this._index = 1e3
                    }
                    return Object.defineProperty(e, "instance", {
                        get: function () {
                            return e._instance || (e._instance = new e)
                        },
                        enumerable: !0,
                        configurable: !0
                    }), e.prototype.update = function (e) {
                        for (var t = Object.keys(this._map), n = 0, i = t.length; n < i; ++n) {
                            var o = t[n],
                                a = this._map[o];
                            a && (a._duration += e, a._duration > a.interval && (a.func.call(a.target), a._duration -= a.interval, a._count += 1), a._count >= a.times && delete this._map[o])
                        }
                    }, e.prototype.scheduleOnce = function (e, t, n) {
                        return this.schedule(e, t, n, 1)
                    }, e.prototype.schedule = function (e, t, n, i) {
                        void 0 === i && (i = 1 / 0), n < 0 && (n = 0);
                        var o = this._findTaskByFunc(e, t);
                        if (o) return o.interval = n, o.times = i, o.index;
                        var a = this._getNextIndex();
                        return o = {
                            index: a,
                            func: e,
                            target: t,
                            interval: n,
                            times: i,
                            _duration: 0,
                            _count: 0
                        }, this._map[a] = o, a
                    }, e.prototype.unschedule = function (e, t) {
                        "number" == typeof e ? this.unscheduleByIndex(e) : this.unscheduleByFunc(e, t)
                    }, e.prototype.unscheduleByIndex = function (e) {
                        delete this._map[e]
                    }, e.prototype.unscheduleByFunc = function (e, t) {
                        var n = this._findTaskByFunc(e, t);
                        n && delete this._map[n.index]
                    }, e.prototype.unscheduleByTarget = function (e) {
                        for (var t = this._findTasksByTarget(e), n = 0, i = t.length; n < i; ++n) {
                            var o = t[n];
                            delete this._map[o.index]
                        }
                    }, e.prototype.unscheduleAll = function () {
                        this._map = {}
                    }, e.prototype._findTaskByFunc = function (e, t) {
                        for (var n = Object.keys(this._map), i = 0, o = n.length; i < o; ++i) {
                            var a = n[i],
                                r = this._map[a];
                            if (r.func == e && r.target == t) return r
                        }
                        return null
                    }, e.prototype._findTasksByTarget = function (e) {
                        for (var t = [], n = Object.keys(this._map), i = 0, o = n.length; i < o; ++i) {
                            var a = n[i],
                                r = this._map[a];
                            r.target == e && t.push(r)
                        }
                        return t
                    }, e.prototype._getNextIndex = function () {
                        return this._index = this._index + 1
                    }, e._instance = null, e
                }();
                n.s2Scheduler = i
            }, {}],
            85: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("./S2PointContainer"),
                    r = e("./S2Macro"),
                    s = e("./S2Math"),
                    l = e("./S2Types"),
                    c = e("./S2Path"),
                    u = e("./S2Player"),
                    d = function (e) {
                        function t(t) {
                            var n = e.call(this, t) || this;
                            return n.userData = null, n.energy = 0, n.killCount = 0, n.eatCount = 0, n.reviveCount = 0, n.killer = null, n.isDead = !1, n.x = 0, n.y = 0, n.vx = 0, n.vy = 0, n.angle = 0, n.turnRadius = 1, n.accelRatio = 0, n._velocity = 1, n.controller = null, n.nearestFoodList = [], n.path = null, n._moveOffset = 0, n.rankItem = null, n.lowPower = !1, n._lowPowerTime = 0, n.lowPowerMaxTime = .2, n._eattingDirty = !1, n.colliderDirty = !1, n._energyOffset = 0, n.addedEnergy = 0, n.isEating = !1, n.isIncrease = !1, n._initLength = 4, n._initVelocity = 1, n._eatRatio = 1, n._initVelocity = r.s2Macro.snake_init_velocity, n.velocity = r.s2Macro.snake_init_velocity, n.turnRadius = r.s2Macro.turn_radius, n.path = new c.s2Path, n
                        }
                        return o(t, e), Object.defineProperty(t.prototype, "velocity", {
                            get: function () {
                                return this._velocity + r.s2Macro.snake_player_accel_ratio * this.accelRatio * this._velocity
                            },
                            set: function (e) {
                                this._velocity = e
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(t.prototype, "score", {
                            get: function () {
                                return Math.floor(this.energy / 100)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), t.prototype.init = function (e, t, n) {
                            this.eatCount = 0, this.killCount = 0, this.reviveCount = 0, this.killer = null, this.isDead = !1, this._initLength = 1, this.energy = 100 * e, this._initVelocity = t, this._eatRatio = n
                        }, t.prototype.changeAngle = function (e, t) {
                            for (; e - this.angle > Math.PI;) e -= 2 * Math.PI;
                            for (; e - this.angle < -Math.PI;) e += 2 * Math.PI;
                            var n = e - this.angle,
                                i = this.velocity / this.turnRadius * t;
                            Math.abs(n) > i ? this.angle += n > 0 ? i : -i : this.angle = e, this.vx = Math.cos(this.angle), this.vy = Math.sin(this.angle)
                        }, t.prototype.addPoint = function () {
                            var t = this.list[this.list.length - 1],
                                n = e.prototype.addPoint.call(this);
                            return n && (t ? (n.x = t.x, n.y = t.y, n.radius = r.s2Macro.snake_body_radius * this.scale, n.type = l.s2PointType.Body) : (n.x = this.x, n.y = this.y, n.radius = r.s2Macro.snake_head_radius * this.scale, n.type = l.s2PointType.Head)), this.stage.collider.collideTree.insert(n), n
                        }, t.prototype.removePoint = function (t) {
                            return this.stage.collider.collideTree.remove(t), e.prototype.removePoint.call(this, t)
                        }, t.prototype.clear = function () {
                            for (var t = 0, n = this.list.length; t < n; ++t) {
                                var i = this.list[t];
                                this.stage.collider.collideTree.remove(i)
                            }
                            this.addedEnergy = 0, this.isEating = !1, this.isIncrease = !1, this.nearestFoodList.length = 0, this.path.clear(), e.prototype.clear.call(this)
                        }, t.prototype.updateEatting = function () {
                            if (this.lowPower) {
                                if (!this._eattingDirty) return;
                                this._eattingDirty = !1
                            }
                            this._updateNearestFood(), this._eatting(), this._updateLength()
                        }, t.prototype.updatePosition = function (e) {
                            if (this.lowPower) {
                                if (this._lowPowerTime += e, this._lowPowerTime < this.lowPowerMaxTime) return;
                                e = this._lowPowerTime, this._lowPowerTime = 0, this._eattingDirty = !0, this.colliderDirty = !0
                            } else this._lowPowerTime = 0;
                            var t = this.x,
                                n = this.y;
                            this.x = this.x + this.vx * this.velocity * e, this.y = this.y + this.vy * this.velocity * e, this.x = Math.max(0, Math.min(r.s2Macro.map_width, this.x)), this.y = Math.max(0, Math.min(r.s2Macro.map_height, this.y));
                            var i = this.x - t,
                                o = this.y - n,
                                a = s.s2Math.mag(i, o),
                                l = Math.min(this.velocity * e * .5, r.s2Macro.snake_body_radius * this.scale * .5);
                            a >= l ? (this._moveOffset = 0, this.path.add(this.x, this.y)) : (this._moveOffset += a, this._moveOffset >= l && (this._moveOffset -= l, this.path.add(this.x, this.y)));
                            var c = this.path.setPositions(this.list, r.s2Macro.snake_body_spacing * this.scale),
                                u = this.list[0];
                            u && (u.angle = Math.atan2(this.vy, this.vx)), this.path.remove(c + 2)
                        }, t.prototype._updateNearestFood = function () {
                            var e = this;
                            this.nearestFoodList = this.stage.collider.foodTree.retrieve(this).map(function (t) {
                                return [t, s.s2Math.distanceSqr(t.x, t.y, e.x, e.y)]
                            })
                        }, t.prototype._eatting = function () {
                            var e = this.stage.foodContainer.scale * r.s2Macro.food_radius;
                            this.isIncrease = !1;
                            var t = this.list.length / 200 * 400 + 50;
                            this.isEating = !1, this.addedEnergy = 0;
                            var n = 0,
                                i = Math.pow((r.s2Macro.snake_head_radius + r.s2Macro.snake_eat_distance) * this.scale + e, 2),
                                o = 6;
                            this.lowPower && (o = 20);
                            for (var a = this.nearestFoodList.length - 1; a >= 0; --a) {
                                var s = this.nearestFoodList[a],
                                    l = s[0];
                                if (s[1] <= i) {
                                    var c = Math.floor(l.value * this._eatRatio);
                                    this.lowPower && (c = Math.floor(2 * c));
                                    var u = this.stage.foodContainer.removeFood(l);
                                    if (u && (u.eater = this), this.energy += c, this.addedEnergy += c, this.nearestFoodList.splice(a, 1), ++this.eatCount, ++n, this.isEating = !0, this._energyOffset += c, this._energyOffset > t && (this._energyOffset = 0, this.isIncrease = !0), n >= o) break
                                }
                            }
                        }, t.prototype._updateLength = function () {
                            var e = Math.max(0, Math.floor(.2 * Math.pow(this.energy, .55)) - 1),
                                t = Math.min(300, this._initLength + e) - this.list.length;
                            if (t > 0) {
                                for (var n = 0; n < t; ++n) this.addPoint();
                                this._updateScale(), this._updateVelocity()
                            }
                        }, t.prototype._updateVelocity = function () {
                            var e = this.list.length,
                                t = 800 - r.s2Macro.snake_init_velocity,
                                n = Math.min(t, t * e / 200);
                            this.velocity = this._initVelocity + n
                        }, t.prototype._updateScale = function () {
                            var e = this.list.length - r.s2Macro.snake_init_length,
                                t = Math.min(2, 2 * e / 300),
                                n = 1 + t;
                            if (n != this.scale && (this.scale = n, this._updateAllPointRadius(), this.controller == this.stage.player)) {
                                var i = 1 + (1 - t / 2 * .55) * t;
                                this.stage.foodContainer.setScale(i)
                            }
                        }, t.prototype._updateAllPointRadius = function () {
                            var e = this.list[0];
                            e && (e.radius = r.s2Macro.snake_head_radius * this.scale);
                            for (var t = 1, n = this.list.length; t < n; ++t) this.list[t].radius = r.s2Macro.snake_body_radius * this.scale
                        }, t.prototype.getRankItem = function (e) {
                            return this.rankItem = {
                                id: this.id,
                                userData: this.userData,
                                rank: e + 1,
                                isPlayer: this.controller instanceof u.s2Player,
                                isDead: this.isDead,
                                killer: this.killer ? this.killer.userData : null,
                                len: this.list.length,
                                energy: this.energy,
                                score: this.score,
                                eat: this.eatCount,
                                kill: this.killCount,
                                revive: this.reviveCount,
                                snake: this
                            }, this.rankItem
                        }, t
                    }(a.s2PointContainer);
                n.s2Snake = d
            }, {
                "./S2Macro": 75,
                "./S2Math": 77,
                "./S2Path": 78,
                "./S2Player": 80,
                "./S2PointContainer": 82,
                "./S2Types": 87
            }],
            86: [function (e, t, n) {
                "use strict";
                var i = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    o = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    },
                    a = this && this.__spreadArrays || function () {
                        for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                        var i = Array(e),
                            o = 0;
                        for (t = 0; t < n; t++)
                            for (var a = arguments[t], r = 0, s = a.length; r < s; r++, o++) i[o] = a[r];
                        return i
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var r = e("./S2Snake"),
                    s = e("./S2PointPool"),
                    l = e("./S2Macro"),
                    c = e("./S2Math"),
                    u = e("./S2Scheduler"),
                    d = e("./S2Ai"),
                    h = e("./S2Point"),
                    f = e("./S2Path"),
                    p = e("./S2Player"),
                    _ = e("./S2Types"),
                    y = e("./S2FoodContainer"),
                    g = e("./S2Collider"),
                    m = e("./S2Performance"),
                    v = function () {
                        function e() {
                            this.player = null, this.controllerList = [], this.snakeList = [], this.deadSnakeList = [], this.foodContainer = null, this.gameStatus = _.s2GameStatus.GameOver, this.gameDuration = 0, this.gameMaxDuration = 60, this.collider = null, this._rect = null, this._snakeIndex = 0, this._rankList = null, this._skipFrame = !1, this._rect = {
                                x: 0,
                                y: 0,
                                width: l.s2Macro.map_width,
                                height: l.s2Macro.map_height
                            }, this.collider = new g.s2Collider(this), this.foodContainer = new y.s2FoodContainer(this), this.foodContainer.id = 0;
                            for (var e = 0; e < l.s2Macro.player_number; ++e) this.addSnake()
                        }
                        return e.prototype.update = function (e, t) {
                            if (!window.CountDownStop) {
                                if (this.gameStatus == _.s2GameStatus.Running) {
                                    if (this.gameDuration >= this.gameMaxDuration) return this.gameDuration = this.gameMaxDuration, void this._gameOver(_.s2ResultReason.TimeOver);
                                    this.gameDuration += t, u.s2Scheduler.instance.update(e);
                                    for (var n = 0, i = this.snakeList.length; n < i; ++n)(a = this.snakeList[n]).updatePosition(e);
                                    for (this.collider.traceTree = null, n = 0, i = this.controllerList.length; n < i; ++n) this.controllerList[n].update(e);
                                    for (n = 0, i = this.snakeList.length; n < i; ++n)(a = this.snakeList[n]).isEating = !1, a.isIncrease = !1;
                                    if (this._skipFrame = !this._skipFrame) {
                                        for (this.collider.update(), n = 0, i = this.snakeList.length; n < i; ++n)(a = this.snakeList[n]).updateEatting();
                                        var o = this.collider.getDeadList();
                                        for (n = 0, i = o.length; n < i; ++n) {
                                            var a = o[n];
                                            this.snakeDead(a)
                                        }
                                        if (this._updateRankList(), this.onDead)
                                            for (n = 0, i = o.length; n < i; ++n) a = o[n], this.onDead(a.rankItem);
                                        this.snakeList.length <= 1 && this._gameOver(_.s2ResultReason.AllDead)
                                    }
                                }
                                this.gameStatus == _.s2GameStatus.PlayerDead && this._gameOver(_.s2ResultReason.PlayerDead)
                            }
                        }, e.prototype.newGame = function (e) {
                            this.foodContainer.clear(), this.collider.init(), this._feed(), u.s2Scheduler.instance.schedule(this._feed, this, l.s2Macro.feed_interval), this._initAllSnake(e), this.gameMaxDuration = e.maxDuration, this.gameDuration = 0, this.gameStatus = _.s2GameStatus.Running, m.default.clearAll()
                        }, e.prototype._gameOver = function (e) {
                            this.gameStatus = _.s2GameStatus.GameOver, u.s2Scheduler.instance.unscheduleByTarget(this);
                            var t = {
                                reason: e,
                                duration: this.gameDuration,
                                player: this.player.snake.rankItem,
                                list: this._rankList
                            };
                            this.collider.clear(), this.onGameOver && this.onGameOver(t)
                        }, e.prototype.clear = function () {
                            var e = this;
                            a(this.snakeList).forEach(function (t) {
                                t.userData = null, e.removeSnake(t), e.deadSnakeList.push(t)
                            }), this.foodContainer.clear(), this.collider.clear(), u.s2Scheduler.instance.unscheduleAll()
                        }, e.prototype.getRect = function () {
                            return this._rect
                        }, e.prototype.getPoints = function () {
                            return h.s2Point.instanceList
                        }, e.prototype.getRankList = function () {
                            return this._rankList
                        }, e.prototype.triggerGC = function () {
                            f.s2PathItemPool.instance.triggerGC(100), s.s2PointPool.instance.triggerGC(100)
                        }, e.prototype._updateRankList = function () {
                            this._rankList = a(this.snakeList, this.deadSnakeList).sort(function (e, t) {
                                return t.energy - e.energy
                            }).map(function (e, t) {
                                return e.getRankItem(t)
                            })
                        }, e.prototype._initAllSnake = function (e) {
                            var t = this;
                            this.snakeList = a(this.snakeList, this.deadSnakeList), this.deadSnakeList = [], c.s2Math.shuffle(this.snakeList), this.controllerList = this.snakeList.map(function (e) {
                                return e.controller
                            });
                            var n = this.snakeList.length,
                                i = .35 * Math.min(this._rect.width, this._rect.height),
                                o = 0;
                            this.snakeList.forEach(function (a, r) {
                                a.clear();
                                var s = 2 * Math.PI / n * r,
                                    u = .5 * t._rect.width - Math.cos(s) * i,
                                    d = .5 * t._rect.height - Math.sin(s) * i;
                                if (a.x = u, a.y = d, a.angle = s, a.controller._angle = s, a.controller instanceof p.s2Player) t.player = a.controller, a.init(e.initLength, e.initVelocity, e.eatRatio), a.userData = e.userDataList[0];
                                else {
                                    var h = Math.random(),
                                        f = l.s2Macro.snake_init_length,
                                        _ = l.s2Macro.snake_init_velocity,
                                        y = e.userDataList[o + 1].eatRatio,
                                        g = Math.min(.7, .3 + .002 * e.lenLevel);
                                    h < .05 ? f = 100 : h < .05 + g && (f = Math.max(l.s2Macro.snake_init_length, c.s2Math.rndInt(.4 * e.initLength, 1.2 * e.initLength)), _ = c.s2Math.rndInt(l.s2Macro.snake_init_velocity, e.initVelocity)), a.init(f, _, y), a.userData = e.userDataList[o + 1], ++o
                                }
                            })
                        }, e.prototype.addSnake = function () {
                            this.snakeList.length;
                            var e = new r.s2Snake(this);
                            if (e.id = ++this._snakeIndex, this.snakeList.push(e), this.player) t = new d.s2Ai(e, this), this.controllerList.push(t);
                            else {
                                var t = new p.s2Player(e);
                                this.controllerList.push(t), this.player = t
                            }
                            return e
                        }, e.prototype.removeSnake = function (e) {
                            e.clear();
                            var t = this.snakeList.indexOf(e);
                            t > -1 && this.snakeList.splice(t, 1);
                            var n = this.controllerList.indexOf(e.controller);
                            n > -1 && this.controllerList.splice(n, 1)
                        }, e.prototype.snakeDead = function (e) {
                            e.killer && ++e.killer.killCount, this._convertSnakeToFood(e), this.removeSnake(e), this.deadSnakeList.push(e), e.isDead = !0, e.controller instanceof p.s2Player ? this._playerRevive(e) : this._checkAiRevive(e)
                        }, e.prototype._playerRevive = function (e) {
                            return i(this, void 0, void 0, function () {
                                var t;
                                return o(this, function (n) {
                                    switch (n.label) {
                                        case 0:
                                            return t = !1, this.onRevive ? [4, this.onRevive()] : [3, 2];
                                        case 1:
                                            t = n.sent(), n.label = 2;
                                        case 2:
                                            return this.gameStatus != _.s2GameStatus.GameOver && (t ? this._snakeRevive(e) : this.gameStatus = _.s2GameStatus.PlayerDead), [2]
                                    }
                                })
                            })
                        }, e.prototype._checkAiRevive = function (e) {
                            var t = this;
                            if (this.snakeList.length < 6 || Math.random() < l.s2Macro.ai_revive_chance) {
                                var n = this.snakeList.length < 3 ? .5 * Math.random() + .5 : 5 * Math.random() + 2;
                                u.s2Scheduler.instance.scheduleOnce(function () {
                                    t._snakeRevive(e)
                                }, this, n)
                            }
                        }, e.prototype._snakeRevive = function (e) {
                            var t = this.deadSnakeList.indexOf(e);
                            t > -1 && this.deadSnakeList.splice(t, 1), this.snakeList.length;
                            var n = this.collider.getSafePosition();
                            e.x = n.x, e.y = n.y, this.snakeList.push(e), this.controllerList.push(e.controller), e.controller instanceof p.s2Player && (this.player = e.controller), e.angle = Math.random() * Math.PI * 2, e.controller._angle = e.angle, e.isDead = !1, ++e.reviveCount
                        }, e.prototype._convertSnakeToFood = function (e) {
                            for (var t = this, n = Math.min(6e3, Math.floor(.5 * e.energy)), i = e.list.length, o = n / i, a = [], r = n < 3e3 ? this.foodContainer.validValueList : n < 4500 ? this.foodContainer.validValueList2 : this.foodContainer.validValueList3, s = r.length - 1; s >= 0;) {
                                if (o > r[s]) {
                                    a.push(r[s]), o -= r[s];
                                    break
                                }--s
                            }
                            0 == a.length && a.push(r[0]), o = a.reduce(function (e, t) {
                                return e + t
                            }), console.info("一条长度为" + i + "的蛇挂了, 生成了" + i * a.length + "个食物, 能量" + i * o);
                            var d = l.s2Macro.snake_body_radius * e.scale,
                                h = [];
                            for (s = 0; s < i; ++s)
                                for (var f = e.list[s], p = f.x, _ = f.y, y = e.list[s - 1], g = d * (1 + 1 / (y ? c.s2Math.distance(y.x, y.y, p, _) / d * 10 + 1 : 21)), m = 0, v = a.length; m < v; ++m) {
                                    var L = Math.max(0, Math.min(l.s2Macro.map_width, p + c.s2Math.rndFloat(-g, g))),
                                        w = Math.max(0, Math.min(l.s2Macro.map_height, _ + c.s2Math.rndFloat(-g, g)));
                                    h.push([a[m], L, w])
                                }
                            var b = Math.ceil(h.length / 3);
                            u.s2Scheduler.instance.schedule(function () {
                                for (var e = h.splice(0, 3), n = 0, i = e.length; n < i; ++n) {
                                    var o = e[n],
                                        a = o[0],
                                        r = o[1],
                                        s = o[2];
                                    t.foodContainer.addFood(a, r, s)
                                }
                            }, this, .02, b)
                        }, e.prototype._feed = function () {
                            this.foodContainer.update()
                        }, e.prototype.dump = function () {}, e
                    }();
                n.s2Stage = v
            }, {
                "./S2Ai": 71,
                "./S2Collider": 72,
                "./S2FoodContainer": 74,
                "./S2Macro": 75,
                "./S2Math": 77,
                "./S2Path": 78,
                "./S2Performance": 79,
                "./S2Player": 80,
                "./S2Point": 81,
                "./S2PointPool": 83,
                "./S2Scheduler": 84,
                "./S2Snake": 85,
                "./S2Types": 87
            }],
            87: [function (e, t, n) {
                "use strict";
                var i, o, a;
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }), a = n.s2PointType || (n.s2PointType = {}), a[a.None = 0] = "None", a[a.Food = 1] = "Food", a[a.Head = 2] = "Head", a[a.Body = 3] = "Body", o = n.s2GameStatus || (n.s2GameStatus = {}), o[o.Running = 0] = "Running", o[o.Pause = 1] = "Pause", o[o.PlayerDead = 2] = "PlayerDead", o[o.GameOver = 3] = "GameOver", i = n.s2ResultReason || (n.s2ResultReason = {}), i[i.TimeOver = 0] = "TimeOver", i[i.PlayerDead = 1] = "PlayerDead", i[i.AllDead = 2] = "AllDead"
            }, {}],
            88: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.loadUserInfoFromLocal = function () {
                        var e = Laya.LocalStorage.getJSON("_avatar_user_info_");
                        if (e)
                            for (var t in e) this.userInfo[t] = e[t]
                    }, e.setUserInfo = function (e) {
                        var t = this;
                        this.userInfo = e, this._userInfoSaved || (Laya.timer.callLater(this, function () {
                            Laya.LocalStorage.setJSON("_avatar_user_info_", t.userInfo)
                        }), this._userInfoSaved = !0)
                    }, e.getRandomList = function (e) {
                        var t = [],
                            n = e - 1,
                            i = this._randomElements(this._nickList, n),
                            o = Math.floor(Math.random() * n),
                            a = n - o,
                            r = this._randomNumberList(1, 20, o),
                            s = this._randomNumberList(1, 20, a),
                            l = r.map(function (e) {
                                return "tex/avt/" + e + ".jpg"
                            }),
                            c = s.map(function (e) {
                                return "tex/avt/" + e + ".jpg"
                            }),
                            u = l.concat(c);
                        this._shuffle(u), t.push(this.userInfo);
                        for (var d = 0; d < n; ++d) t.push({
                            nickName: i[d],
                            avatarUrl: u[d]
                        });
                        return t
                    }, e._randomNumberList = function (e, t, n) {
                        if (t - e < 4 * n) {
                            for (var i = [], o = e; o < t; ++o) i.push(o);
                            return this._randomElements(i, n)
                        }
                        for (i = []; i.length < n;) {
                            var a = Math.floor(Math.random() * (t - e) + e); - 1 == i.indexOf(a) && i.push(a)
                        }
                        return i
                    }, e._randomElements = function (e, t) {
                        var n = e.slice(0);
                        return this._shuffle(n), n.length = Math.min(n.length, t), n
                    }, e._shuffle = function (e) {
                        for (var t, n, i = e.length; 0 !== i;) n = Math.floor(Math.random() * i), t = e[i -= 1], e[i] = e[n], e[n] = t;
                        return e
                    }, e.userInfo = {
                        language: "",
                        nickName: "You",
                        avatarUrl: "",
                        gender: 0,
                        country: "",
                        province: "",
                        city: ""
                    }, e._userInfoSaved = !1, e._nickList = ["Robert", "John", "Michael", "David", "William", "Richard", "Joseph", "Thomas", "Charles", "Christopher", "Daniel", "Matthew", "Anthony", "Mark", "Donald", "Steven", "Paul", "Andrew", "Joshua", "Kenneth", "Kevin", "Brian", "George", "Timothy", "Ronald", "Edward", "Jason", "Jeffrey", "Ryan", "Jacob", "Gary", "Nicholas", "Eric", "Jonathan", "Stephen", "Larry", "Justin", "Scott", "Brandon", "Benjamin", "Samuel", "Gregory", "Alexander", "Frank", "Patrick", "Raymond", "Jack", "Dennis", "Jerry", "Tyler", "Aaron", "Jose", "Adam", "Nathan", "Henry", "Douglas", "Zachary", "Peter", "Kyle", "Ethan", "Walter", "Noah", "Jeremy", "Christian", "Keith", "Roger", "Terry", "Gerald", "Harold", "Sean", "Austin", "Carl", "Arthur", "Lawrence", "Dylan", "Jesse", "Jordan", "Bryan", "Billy", "Joe", "Bruce", "Gabriel", "Logan", "Albert", "Willie", "Alan", "Juan", "Wayne", "Elijah", "Randy", "Roy", "Vincent", "Ralph", "Eugene", "Russell", "Bobby", "Mason", "Philip", "Louis"], e
                }();
                n.Avatar = i
            }, {}],
            89: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../common/EventID"),
                    s = e("../core/MyBanner"),
                    l = e("../platform/yt"),
                    c = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.init(), t
                        }
                        return o(t, e), t.prototype.init = function () {
                            this.size(Laya.stage.width, Laya.stage.height), this.bg.y = .5 * (Laya.stage.height - this.bg.height), this.progress.value = 0, this.pika.x = 0, this._onBannerChanged(), Laya.stage.on(r.default.BANNER_CHANGED, this, this._onBannerChanged), Laya.stage.on(r.default.MY_BANNER_CHANGED, this, this._onBannerChanged)
                        }, t.prototype._onRemoved = function () {
                            Laya.stage.off(r.default.BANNER_CHANGED, this, this._onBannerChanged), Laya.stage.off(r.default.MY_BANNER_CHANGED, this, this._onBannerChanged), e.prototype._onRemoved.call(this)
                        }, t.prototype.startProgress = function (e) {
                            var t = this;
                            this.progress.value = 0, this.pika.x = 0, Laya.Tween.to(this.progress, {
                                value: .9,
                                update: new Laya.Handler(this, function () {
                                    t.pika.x = Laya.stage.width * t.progress.value
                                })
                            }, e, Laya.Ease.strongOut)
                        }, t.prototype.finishProgress = function (e) {
                            var t = this;
                            return Laya.Tween.clearAll(this.progress), new Promise(function (n) {
                                Laya.Tween.to(t.progress, {
                                    value: 1,
                                    update: new Laya.Handler(t, function () {
                                        t.pika.x = Laya.stage.width * t.progress.value
                                    })
                                }, e, null, Laya.Handler.create(t, n))
                            })
                        }, t.prototype._onBannerChanged = function () {
                            if (l.default.isBannerVisible()) {
                                var e = l.default.getBannerHeight() / l.default.getSystemSize().height * Laya.stage.height + 10;
                                l.default.isIos() && l.default.isLongScreen() && (e += 65), this._footer.bottom = e
                            } else s.default.instance.isValid() ? this._footer.bottom = s.default.instance.getHeight() + 10 + 20 : this._footer.bottom = 0
                        }, t
                    }(a.ui.view.gamein_loadingUI);
                n.default = c
            }, {
                "../common/EventID": 15,
                "../core/MyBanner": 25,
                "../platform/yt": 63,
                "../ui/layaMaxUI": 97
            }],
            90: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("../ui/layaMaxUI"),
                    l = e("./GameScene3d"),
                    c = e("./SnakeBridge"),
                    u = e("../snake/S2Performance"),
                    d = e("../core/GameHelper"),
                    h = e("../snake/S2Macro"),
                    f = e("../common/SceneID"),
                    p = e("../ads/InsideAds"),
                    _ = e("../data/DataBus"),
                    y = e("../config/GameCnf"),
                    g = e("../logic/MergeLogic"),
                    m = e("../platform/yt"),
                    v = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._scene3d = null, t._scene2d = null, t._playerSkin = 0, t._initLength = 4, t._initVelocity = 150, t._avatarList = [], t._doubleFood = 1, t._lenLevel = 0, t._highScorePlayerPos3d = new Laya.Vector3, t._highScoreSnake = null, t.init(), t
                        }
                        return o(t, e), t.prototype.init = function () {
                            this._scene3d = new l.GameScene3d, this._pnl3d.addChild(this._scene3d), this._scene2d = this.scene2d
                        }, t.prototype.onOpened = function (e) {
                            console.error("");
                            var t = e.avatarList,
                                n = e.playerSkin,
                                i = void 0 === n ? 0 : n,
                                o = e.initLength,
                                a = void 0 === o ? 4 : o,
                                r = e.initVelocity,
                                s = void 0 === r ? 400 : r,
                                l = e.doubleFood,
                                c = void 0 === l ? 1 : l,
                                u = e.lenLevel,
                                d = void 0 === u ? 0 : u;
                            this._playerSkin = i, this._initLength = a, this._initVelocity = s, this._avatarList = t, this._doubleFood = c, this._lenLevel = d, this.preload(), Laya.stage.on(Laya.Event.KEY_DOWN, this, this.onKeyDown), Laya.stage.on(Laya.Event.KEY_UP, this, this.onKeyUp), this.anyKeyDown = !1
                        }, t.prototype._onRemoved = function () {
                            Laya.stage.off(Laya.Event.KEY_DOWN, this, this.onKeyDown), Laya.stage.off(Laya.Event.KEY_UP, this, this.onKeyUp), Laya.timer.clearAll(this), this.clearSnakeBrigde(), Laya.SoundManager.stopMusic(), _.default.instance.SaveDataToServer(), _.default.instance.SaveLocalData(), d.default.removeBannerStatus("game"), e.prototype._onRemoved.call(this)
                        }, t.prototype.preload = function () {
                            return a(this, void 0, void 0, function () {
                                var e;
                                return r(this, function (t) {
                                    switch (t.label) {
                                        case 0:
                                            return this._pnl3d.visible = !1, this._pnl2d.visible = !1, [4, this.showLoadingScene()];
                                        case 1:
                                            return (e = t.sent()).startProgress(1500), [4, this._scene3d.preloadModel(this._playerSkin, h.s2Macro.player_number - 1)];
                                        case 2:
                                            return t.sent(), this._scene3d.precreateFoodModel(100), this._scene3d.precreateParticleModel(30), [4, e.finishProgress(200)];
                                        case 3:
                                            return t.sent(), e.removeSelf(), this._pnl3d.visible = !0, this._pnl2d.visible = !0, d.default.addBannerStatus("game", !1), p.default.instance.hide(), this.startGame(), [2]
                                    }
                                })
                            })
                        }, t.prototype.showLoadingScene = function () {
                            var e = this;
                            return new Promise(function (t, n) {
                                Laya.Scene.open(f.default.GameLoading, !1, null, new Laya.Handler(e, function (e) {
                                    t(e)
                                }))
                            })
                        }, t.prototype.startGame = function () {
                            this.initSnakeBridge(), Laya.timer.frameLoop(1, this, this.update), Laya.timer.frameLoop(30, this, this.updateLbl), Laya.timer.frameLoop(12, this, this.updateRankList), Laya.timer.frameLoop(12, this, this.updateIndicator)
                        }, t.prototype.initSnakeBridge = function () {
                            var e = c.SnakeBridge.instance;
                            e.scene3d = this._scene3d, e.scene2d = this._scene2d;
                            var t = this._scene3d.modelParam;
                            this._scene3d.addBg(t.sceneUrl), e.setAddEnergyCallback(this._scene2d.showAddEnergy.bind(this._scene2d)), e.setGameOverCallback(this.onGameOver.bind(this)), e.setReviveCallback(this.onRevive.bind(this)), e.setDeadCallback(this.onDead.bind(this));
                            var n = {
                                userDataList: [],
                                maxDuration: parseInt(m.default.conf.game_duration) || 90,
                                initLength: this._initLength,
                                initVelocity: this._initVelocity,
                                eatRatio: Math.max(1, this._doubleFood),
                                lenLevel: this._lenLevel
                            };
                            console.log(n);
                            var i = this._avatarList;
                            t.snakeList.forEach(function (e, t) {
                                var o = e.skinId - 1,
                                    a = g.default.instance.getAddition(o);
                                n.userDataList.push({
                                    nickName: i[t].nickName,
                                    avatarUrl: i[t].avatarUrl,
                                    headModelUrl: e.headModelUrl,
                                    bodyModelUrl: e.bodyModelUrl,
                                    isPlayer: 0 == t,
                                    lenLevel: o,
                                    initLength: y.default.initLen + a.initLen,
                                    initVelocity: y.default.initSpeed,
                                    eatRatio: 1 + a.food
                                })
                            }), e.resumeGame(), e.newGame(n), this.scene2d.angle = c.SnakeBridge.instance.getAngle(), u.default.clearAll()
                        }, t.prototype.clearSnakeBrigde = function () {
                            var e = c.SnakeBridge.instance;
                            e.clear(), e.scene3d = null, e.scene2d = null
                        }, t.prototype.update = function () {
                            var e = this._scene2d,
                                t = this._scene3d,
                                n = c.SnakeBridge.instance;
                            !this.anyKeyDown && e.touching && n.setAngle(e.angle), this.keyW ? (this.playerAngle = this.playerAngle1, this.keyA && (this.playerAngle = -2.25), this.keyD && (this.playerAngle = -.75), n.setAngle(this.playerAngle)) : this.keyS ? (this.playerAngle = this.playerAngle2, this.keyA && (this.playerAngle = 2.25), this.keyD && (this.playerAngle = .75), n.setAngle(this.playerAngle)) : this.keyA ? (this.playerAngle = this.playerAngle3, this.keyW && (this.playerAngle = -2.25), this.keyS && (this.playerAngle = 2.25), n.setAngle(this.playerAngle)) : this.keyD && (this.playerAngle = this.playerAngle4, this.keyW && (this.playerAngle = -.75), this.keyS && (this.playerAngle = .75), n.setAngle(this.playerAngle)), n.setSlipDistance(e.distance), u.default.timeStart("stage_update"), n.update(), u.default.timeEnd("stage_update"), u.default.timeStart("3d_update"), n.update3d(), u.default.timeEnd("3d_update");
                            var i = n.getPlayerAttr(),
                                o = (i.scale - 1) / 2 * 2.6 + 1;
                            t.updateCamera(i.x, i.y, o)
                        }, t.prototype.onKeyDown = function (e) {
                            switch (console.log(e.keyCode), e.keyCode) {
                                case 87:
                                    this.keyW = !0, this.playerAngle1 = -1.5;
                                    break;
                                case 83:
                                    this.keyS = !0, this.playerAngle2 = 1.5;
                                    break;
                                case 65:
                                    this.keyA = !0, this.playerAngle3 = 3;
                                    break;
                                case 68:
                                    this.keyD = !0, this.playerAngle4 = 0
                            }
                        }, t.prototype.onKeyUp = function (e) {
                            switch (e.keyCode) {
                                case 87:
                                    this.keyW = !1;
                                    break;
                                case 83:
                                    this.keyS = !1;
                                    break;
                                case 65:
                                    this.keyA = !1;
                                    break;
                                case 68:
                                    this.keyD = !1
                            }
                        }, t.prototype.updateLbl = function () {
                            if (!window.CountDownStop) {
                                var e = c.SnakeBridge.instance.getRemainTime();
                                this._scene2d.updateTimeLabel(d.default.TransSeconds(e))
                            }
                        }, t.prototype.updateRankList = function () {
                            var e = c.SnakeBridge.instance.getRankList();
                            this._scene2d.updateRankList(e)
                        }, t.prototype.updateIndicator = function () {
                            var e = c.SnakeBridge.instance.getHighScorePlayer();
                            if (e && e.snake) {
                                var t = e.snake,
                                    n = this._highScorePlayerPos3d;
                                n.setValue(t.x, 20, t.y);
                                var i = this._scene3d.convertCoord3dTo2d(n),
                                    o = c.SnakeBridge.instance.getPlayerAttr();
                                t.y > o.y && i.y < 0 ? i.y = 1e5 : t.y < o.y && i.y > 1280 && (i.y = -1e5), t.x > o.x && i.x < 0 ? i.x = 1e5 : t.x < o.x && i.x > 720 && (i.x = -1e5), this._highScoreSnake != t ? (this._scene2d.showIndicator(e.rank, i, 0), this._highScoreSnake = t) : this._scene2d.showIndicator(e.rank, i, 200)
                            } else this._scene2d.hideIndicator()
                        }, t.prototype.onRevive = function () {
                            console.info("stage_update", u.default.sum("stage_update")), console.info("3d_update", u.default.sum("3d_update")), u.default.clearAll();
                            var e = c.SnakeBridge.instance.getRemainTime() < 20;
                            return new Promise(function (t, n) {
                                Laya.Scene.open(f.default.Revive, !1, {
                                    forceCoins: e,
                                    onRevive: t
                                })
                            })
                        }, t.prototype.onGameOver = function (e) {
                            c.SnakeBridge.instance.pauseGame();
                            var t = function () {
                                Laya.Scene.open(f.default.Score, !1, {
                                    result: e,
                                    onNext: function () {
                                        Laya.Scene.open(f.default.Main, !0)
                                    }
                                })
                            };
                            e.player.isDead ? t() : Laya.Scene.open(f.default.GameRank, !1, {
                                list: e.list,
                                onNext: function () {
                                    t()
                                }
                            })
                        }, t.prototype.onDead = function (e) {
                            if (e.killer && e.killer.isPlayer) {
                                this._scene2d.showCurKill();
                                var t = c.SnakeBridge.instance.getPlayerAttr();
                                this._scene2d.updateTotalKill(t.killCount)
                            }
                        }, t.prototype.showDialog = function (e, t) {
                            return new Promise(function (n) {
                                setTimeout(function () {
                                    m.default.showModal({
                                        title: e,
                                        content: t,
                                        showCancel: !0,
                                        cancelText: "取消",
                                        cancelColor: "#ff0000",
                                        confirmText: "确认",
                                        confirmColor: "#000000",
                                        success: function (e) {
                                            n(e.confirm)
                                        },
                                        fail: function () {
                                            n(!1)
                                        },
                                        complete: void 0
                                    })
                                }, 20)
                            })
                        }, t
                    }(s.ui.view.GameSceneUI);
                n.default = v
            }, {
                "../ads/InsideAds": 8,
                "../common/SceneID": 17,
                "../config/GameCnf": 19,
                "../core/GameHelper": 23,
                "../data/DataBus": 32,
                "../logic/MergeLogic": 47,
                "../platform/yt": 63,
                "../snake/S2Macro": 75,
                "../snake/S2Performance": 79,
                "../ui/layaMaxUI": 97,
                "./GameScene3d": 92,
                "./SnakeBridge": 94
            }],
            91: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../common/EventID"),
                    s = e("../core/MyBanner"),
                    l = e("../platform/yt"),
                    c = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.touching = !1, t.angle = 0, t.distance = 0, t._touchLocation = new Laya.Point, t._moveLocation = new Laya.Point, t._indicatorRects = [new Laya.Point, new Laya.Point, new Laya.Point, new Laya.Point], t._centerPos = new Laya.Point, t._indicatorPos = new Laya.Point, t._bannerHeight = 0, t._curKillTimeLine = null, t._curKill = 0, t._lastAddEnergyTimestamp = 0, Laya.timer.callLater(t, t.init), t._onBannerChanged(), Laya.stage.on(r.default.BANNER_CHANGED, t, t._onBannerChanged), Laya.stage.on(r.default.MY_BANNER_CHANGED, t, t._onBannerChanged), t
                        }
                        return o(t, e), t.prototype.init = function () {
                            this._timeLbl.text = "";
                            var e = Laya.stage.width / Laya.stage.height;
                            this._header.y = e > 2 || e < .5 ? 85 : 0, this._initTouch(), YYGGames.audio.stopMusic(), YYGGames.audio.playMusic("sound/bgm2.mp3"), Laya.stage.on(Laya.Event.KEY_DOWN, this, () => {
                                this.guide1.visible = !1, this.guide2.visible = !1
                            })
                        }, t.prototype.onEnable = function () {
                            window.isGuided ? (this.guide1.visible = !1, this.guide2.visible = !1) : (window.isGuided = !0, Laya.Browser.onPC ? (this.guide1.visible = !0, this.guide2.visible = !1) : (this.guide1.visible = !1, this.guide2.visible = !0))
                        }, t.prototype._onRemoved = function () {
                            Laya.stage.off(r.default.BANNER_CHANGED, this, this._onBannerChanged), Laya.stage.off(r.default.MY_BANNER_CHANGED, this, this._onBannerChanged), Laya.timer.clearAll(this), e.prototype._onRemoved.call(this)
                        }, t.prototype._updateIndicatorRects = function () {
                            var e = Laya.stage,
                                t = e.width,
                                n = e.height,
                                i = this._indicatorRects;
                            i[0].setTo(60, 60), i[1].setTo(t - 60, 60), i[2].setTo(t - 60, n - 60 - this._bannerHeight), i[3].setTo(60, n - 60 - this._bannerHeight), this._centerPos.x = .5 * t, this._centerPos.y = .5 * n
                        }, t.prototype._onBannerChanged = function () {
                            if (l.default.isBannerVisible()) {
                                var e = l.default.getBannerHeight() / l.default.getSystemSize().height * Laya.stage.height;
                                l.default.isIos() && l.default.isLongScreen() && (e += 65), this._bannerHeight = e
                            } else s.default.instance.isValid() ? this._bannerHeight = s.default.instance.getHeight() + 20 : this._bannerHeight = 0;
                            this._updateIndicatorRects()
                        }, t.prototype.updateTimeLabel = function (e) {
                            e != this._timeLbl.text && this._timeLbl.changeText(e)
                        }, t.prototype.drawOperator = function () {
                            var e = this._touch.graphics;
                            e.clear(), this.touching && (e.alpha(.25), e.drawCircle(this._touchLocation.x, this._touchLocation.y, 40, "#ffffff"), this._moveLocation.setTo(this._moveLocation.x - this._touchLocation.x, this._moveLocation.y - this._touchLocation.y), this._moveLocation.distance(0, 0) > 40 && (this._moveLocation.normalize(), this._moveLocation.setTo(40 * this._moveLocation.x, 40 * this._moveLocation.y)), this._moveLocation.setTo(this._moveLocation.x + this._touchLocation.x, this._moveLocation.y + this._touchLocation.y), e.drawCircle(this._moveLocation.x, this._moveLocation.y, 20, "#ffffff"))
                        }, t.prototype.showCurKill = function () {
                            var e = this,
                                t = this._curKillTimeLine,
                                n = this._curKillPnl;
                            n.visible = !0, t || (this._curKillTimeLine = t = new Laya.TimeLine, t.addLabel("reset", 0).to(n, {
                                scaleX: .1,
                                scaleY: .1,
                                alpha: 1,
                                y: .5 * Laya.stage.height
                            }, 1, null, 0).addLabel("scale", 0).to(n, {
                                scaleX: 1,
                                scaleY: 1
                            }, 500, Laya.Ease.elasticOut, 0).addLabel("fade", 0).to(n, {
                                alpha: 0,
                                y: .5 * Laya.stage.height - 100
                            }, 1e3, null, 0), t.on(Laya.Event.COMPLETE, this, function () {
                                n.visible = !1, e._curKill = 0
                            })), this._curKill += 1, this._curKillLbl.changeText("+" + this._curKill), t.play(0, !1)
                        }, t.prototype.updateTotalKill = function (e) {
                            this._totalKillLbl.changeText(e.toString())
                        }, t.prototype.showAddEnergy = function (e, t) {
                            var n = this;
                            void 0 === t && (t = 1e3);
                            var i = (new Date).getTime();
                            if (!(i - this._lastAddEnergyTimestamp < 300)) {
                                this._lastAddEnergyTimestamp = i;
                                var o = Laya.Pool.getItemByCreateFun("add_energy_lbl", function () {
                                    var e = new Laya.Text;
                                    return e.font = "Arial2", e.fontSize = 60, e.color = "#FFFFFF", e.stroke = 2, e.strokeColor = "#000000", e
                                }, null);
                                this._addScorePnl.addChild(o), Laya.Tween.clearAll(o), o.changeText("+" + e), o.pivotX = .5 * o.width, o.pivotY = .5 * o.height, o.x = .5 * Laya.stage.width, o.y = .35 * Laya.stage.height, o.alpha = 1, o.scaleX = o.scaleY = .1, Laya.Tween.to(o, {
                                    scaleX: 1,
                                    scaleY: 1
                                }, 500, Laya.Ease.elasticOut, Laya.Handler.create(this, function () {
                                    Laya.Tween.to(o, {
                                        y: o.y - 100,
                                        alpha: 0
                                    }, t, null, Laya.Handler.create(n, function () {
                                        o.removeSelf(), Laya.Pool.recover("add_energy_lbl", o)
                                    }))
                                }))
                            }
                        }, t.prototype.updateRankList = function (e) {
                            var t = this;
                            if (this._rankList.array) {
                                var n = this._rankList.array;
                                e.forEach(function (e, i) {
                                    e.rank;
                                    var o = e.userData.nickName + " ",
                                        a = e.score.toString(),
                                        r = e.isDead ? "#999999" : e.isPlayer ? "#f2e71f" : "#ffffff",
                                        s = e.isDead ? .4 : 1,
                                        l = n[i];
                                    l.nick.text == o && l.nick.color == r && l.score.text == a && l.score.alpha == s || (l.nick.text = o, l.nick.color = r, l.score.text = a, l.score.alpha = s, t._rankList.changeItem(i, l))
                                })
                            } else {
                                var i = e.length;
                                if (0 == i) return void(this._rankPnl.visible = !1);
                                this._rankPnl.visible = !0, this._rankList.height = 28 * i + 1, this._rankListBg.height = 28 * i + 10;
                                var o = e.map(function (e) {
                                    e.rank;
                                    var t = e.userData.nickName,
                                        n = e.score,
                                        i = e.isDead ? "#999999" : e.isPlayer ? "#f2e71f" : "#ffffff",
                                        o = e.isDead ? .4 : 1;
                                    return {
                                        nick: {
                                            text: t,
                                            color: i
                                        },
                                        score: {
                                            text: n.toString(),
                                            alpha: o
                                        }
                                    }
                                });
                                this._rankList.array = o
                            }
                        }, t.prototype.showIndicator = function (e, t, n) {
                            for (var i = this._centerPos, o = this._indicatorPos, a = !1, r = 0; r < 4; ++r) {
                                var s = this._indicatorRects[r],
                                    l = this._indicatorRects[(r + 1) % 4];
                                if (this._SegmentIntersect(i, t, s, l, o)) {
                                    a = !0;
                                    break
                                }
                            }
                            if (a) {
                                var c = Math.atan2(t.y - i.y, t.x - i.x) / Math.PI * 180 + 90;
                                if (this._indicator.skin = 1 == e ? "tex/gamein_huangguan.png" : "tex/gamein_huangguan1.png", Laya.Tween.clearAll(this._arrow), Laya.Tween.clearAll(this._indicator), this._indicator.visible && n > 0) {
                                    for (; c - this._arrow.rotation > 180;) c -= 360;
                                    for (; c - this._arrow.rotation < -180;) c += 360;
                                    Laya.Tween.to(this._arrow, {
                                        rotation: c
                                    }, n), Laya.Tween.to(this._indicator, {
                                        x: o.x,
                                        y: o.y
                                    }, n)
                                } else this._indicator.visible = !0, this._arrow.rotation = c, this._indicator.pos(o.x, o.y, !0)
                            } else this._indicator.visible = !1
                        }, t.prototype.hideIndicator = function () {
                            this._indicator.visible = !1
                        }, t.prototype._SegmentIntersect = function (e, t, n, i, o) {
                            var a = (i.x - n.x) * (e.y - n.y) - (i.y - n.y) * (e.x - n.x),
                                r = (t.x - e.x) * (e.y - n.y) - (t.y - e.y) * (e.x - n.x),
                                s = (i.y - n.y) * (t.x - e.x) - (i.x - n.x) * (t.y - e.y);
                            if (0 !== s) {
                                var l = a / s,
                                    c = r / s;
                                if (0 <= l && l <= 1 && 0 <= c && c <= 1) return o && o.setTo(e.x + (t.x - e.x) * l, e.y + (t.y - e.y) * l), !0
                            }
                            return !1
                        }, t.prototype._initTouch = function () {
                            this._touch.mouseEnabled = !0;
                            for (var e = this._touch; e && e instanceof Laya.Sprite && e != Laya.stage;) e.x = e.y = 0, e.width = Laya.stage.width, e.height = Laya.stage.height, e = e.parent;
                            this._touch.on(Laya.Event.MOUSE_DOWN, this, this._onTouchStart), this._touch.on(Laya.Event.MOUSE_MOVE, this, this._onTouchMove), this._touch.on(Laya.Event.MOUSE_UP, this, this._onTouchEnd)
                        }, t.prototype._onTouchStart = function (e) {
                            this._touchLocation.setTo(e.stageX, e.stageY), this.touching = !0, this.guide1.visible = !1, this.guide2.visible = !1
                        }, t.prototype._onTouchMove = function (e) {
                            if (this.touching) {
                                this._moveLocation.setTo(e.stageX, e.stageY);
                                var t = this._touchLocation,
                                    n = this._moveLocation,
                                    i = Math.atan2(n.y - t.y, n.x - t.x),
                                    o = Math.sqrt((n.y - t.y) * (n.y - t.y) + (n.x - t.x) * (n.x - t.x));
                                o > 0 && (this.angle = i, this.distance = o)
                            }
                        }, t.prototype._onTouchEnd = function (e) {
                            this.touching = !1, this.distance = 0
                        }, t
                    }(a.ui.view.GameScene2dUI);
                n.default = c
            }, {
                "../common/EventID": 15,
                "../core/MyBanner": 25,
                "../platform/yt": 63,
                "../ui/layaMaxUI": 97
            }],
            92: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__spreadArrays || function () {
                        for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                        var i = Array(e),
                            o = 0;
                        for (t = 0; t < n; t++)
                            for (var a = arguments[t], r = 0, s = a.length; r < s; r++, o++) i[o] = a[r];
                        return i
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var r = e("../model/ModelLoader"),
                    s = e("../model/ModelMgr"),
                    l = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.modelParam = null, t.camera = null, t.modelPnl = null, t.lightCamera = null, t.lightPnl = null, t.cameraDistance = 1e3, t.cameraAngle = 55 / 180 * Math.PI, t.cameraTopLeftPos = new Laya.Vector3, t.cameraBottomLeftPos = new Laya.Vector3, t._destZoom = 1, t._curZoom = 1, t._crowns = [], t._arrow = null, t._lastAddParticleTimestamp = 0, t._convertCoord3dTo2dTempV3 = new Laya.Vector3, t._convertCoord2dTo3dTempRay = new Laya.Ray(new Laya.Vector3(0, 0, 0), new Laya.Vector3(0, 0, 0)), t.init(), t
                        }
                        return o(t, e), t.prototype.init = function () {
                            this.modelPnl = this.addChild(new Laya.Sprite3D), Laya.stage.width, Laya.stage.height, this.camera = this.addChild(new Laya.Camera(0, .1, 1e4)), this.camera.fieldOfView = Math.max(47, (Laya.stage.height - 1280) / 280 * 10 + 55), this.camera.transform.translate(new Laya.Vector3(0, this.cameraDistance * Math.sin(this.cameraAngle), this.cameraDistance * Math.cos(this.cameraAngle))), this.camera.transform.rotate(new Laya.Vector3(-this.cameraAngle, 0, 0), !0, !0), this.convertCoord2dTo3d(new Laya.Vector2(0, 0), this.cameraTopLeftPos), this.convertCoord2dTo3d(new Laya.Vector2(0, Laya.stage.height), this.cameraBottomLeftPos), this.lightPnl = this.addChild(new Laya.Sprite3D), this.lightCamera = Laya.Sprite3D.instantiate(this.camera, this, !0), this.lightCamera.clearFlag = Laya.BaseCamera.CLEARFLAG_NONE, this.lightCamera.removeAllLayers(), this.lightCamera.addLayer(1), this.camera.removeLayer(1);
                            var e = this.addChild(new Laya.DirectionLight);
                            e.color = new Laya.Vector3(1, 1, 1), e.intensity = .8;
                            var t = e.transform.worldMatrix;
                            t.setForward(new Laya.Vector3(-.5, -1, -.5)), e.transform.worldMatrix = t, this.ambientColor = new Laya.Vector3(.2, .2, .2)
                        }, t.prototype._onRemoved = function () {
                            Laya.timer.clearAll(this);
                            for (var t = this.modelPnl.numChildren - 1; t >= 0; --t) {
                                var n = this.modelPnl.getChildAt(t);
                                this.removeModel(n)
                            }
                            this._crowns = this._arrow = null, e.prototype._onRemoved.call(this)
                        }, t.prototype.preloadModel = function (e, t) {
                            var n = this.modelParam = s.ModelMgr.instace.createModelParam(e, t),
                                i = a([n.sceneUrl, n.eatParticleUrl, n.smallFoodUrl], n.crownUrlList, [n.arrowUrl]);
                            n.snakeList.forEach(function (e) {
                                i.push(e.bodyModelUrl), i.push(e.headModelUrl)
                            });
                            var o = [];
                            return i.forEach(function (e) {
                                o.push(r.ModelLoader.instance.preloadModel(e))
                            }), Promise.all(o)
                        }, t.prototype.precreateFoodModel = function (e) {
                            for (var t = this.modelParam.smallFoodUrl, n = this.modelParam.foodLightUrl, i = [], o = e - (Laya.Pool.getPoolBySign(t) || []).length, a = 0; a < o; ++a) i.push(r.ModelLoader.instance.getModel(t)), i.push(r.ModelLoader.instance.getModel(n));
                            i.forEach(function (e) {
                                return r.ModelLoader.instance.removeModel(e)
                            })
                        }, t.prototype.precreateParticleModel = function (e) {
                            for (var t = this.modelParam.eatParticleUrl, n = [], i = e - (Laya.Pool.getPoolBySign(t) || []).length, o = 0; o < i; ++o) n.push(r.ModelLoader.instance.getModel(t));
                            n.forEach(function (e) {
                                return r.ModelLoader.instance.removeModel(e)
                            })
                        }, t.prototype.addBg = function (e) {
                            this.addModel(e).name = "bg"
                        }, t.prototype.addParticle = function (e, t, n, i) {
                            var o = (new Date).getTime();
                            if (!(o - this._lastAddParticleTimestamp < 150)) {
                                this._lastAddParticleTimestamp = o;
                                var a = this.modelParam.eatParticleUrl,
                                    r = this.addModel(a);
                                r.name = "particle", r.transform.localPosition.setValue(e, t, n), r.transform.localPosition = r.transform.localPosition, r.transform.localScale.setValue(i, i, i), r.transform.localScale = r.transform.localScale, Laya.timer.once(1e3, this, this.removeModel, [r, a], !1)
                            }
                        }, t.prototype.addFood = function () {
                            var e = this.modelParam.smallFoodUrl,
                                t = this.addModel(e),
                                n = this.modelParam.foodLightUrl,
                                i = this.addModel(n);
                            i.layer = 1;
                            var o = i.getChildAt(0);
                            return o.transform.localPosition.setValue(0, 30, 30), o.transform.localPosition = o.transform.localPosition, Laya.Quaternion.createFromYawPitchRoll(0, 35, 0, o.transform.localRotation), t.__light__ = i, this.runModelAnimation(t), t
                        }, t.prototype.runModelAnimation = function (e) {
                            var t = e.getChildAt(0);
                            t && (Laya.Tween.clearAll(t.transform.localScale), t.transform.localScale.setValue(.1, .1, .1), t.transform.localScale = t.transform.localScale, Laya.Tween.to(t.transform.localScale, {
                                x: 1,
                                y: 1,
                                z: 1,
                                update: new Laya.Handler(this, function () {
                                    t.transform.localScale = t.transform.localScale
                                })
                            }, 700, Laya.Ease.elasticOut))
                        }, t.prototype.updateCrown = function (e, t, n, i, o) {
                            var a = e,
                                r = this._crowns[a];
                            if (!r) {
                                var s = this.modelParam.crownUrlList[a],
                                    l = this.addModel(s);
                                r = this._crowns[a] = l
                            }!r.active && (r.active = !0), r.transform.localPosition.setValue(t, n, i), r.transform.localPosition = r.transform.localPosition, r.transform.localScale.setValue(o, o, o), r.transform.localScale = r.transform.localScale
                        }, t.prototype.hideCrown = function (e) {
                            var t = e,
                                n = this._crowns[t];
                            n && n.active && (n.active = !1)
                        }, t.prototype.updateArrow = function (e, t, n, i, o) {
                            var a = this._arrow;
                            if (!a) {
                                var r = this.modelParam.arrowUrl;
                                a = this._arrow = this.addModel(r)
                            }!a.active && (a.active = !0), a.transform.localPosition.setValue(t, n, i), a.transform.localPosition = a.transform.localPosition, a.transform.localScale.setValue(o, o, o), a.transform.localScale = a.transform.localScale, Laya.Quaternion.createFromYawPitchRoll(.5 * Math.PI - e, 0, 0, a.transform.localRotation)
                        }, t.prototype.hideArrow = function () {
                            var e = this._arrow;
                            e && e.active && (e.active = !1)
                        }, t.prototype.addModel = function (e) {
                            var t = r.ModelLoader.instance.getModel(e);
                            return this.modelPnl.addChild(t), t
                        }, t.prototype.removeModel = function (e, t) {
                            r.ModelLoader.instance.removeModel(e, t)
                        }, t.prototype.updateCamera = function (e, t, n) {
                            this._curZoom = n;
                            var i = this.cameraDistance * this._curZoom;
                            this.camera.transform.localPosition.setValue(e, i * Math.sin(this.cameraAngle), t + i * Math.cos(this.cameraAngle)), this.camera.transform.localPosition = this.camera.transform.localPosition, this.lightCamera.transform.localPosition = this.camera.transform.localPosition
                        }, t.prototype.convertCoord3dTo2d = function (e, t) {
                            var n = this._convertCoord3dTo2dTempV3;
                            return this.camera.viewport.project(e, this.camera.projectionViewMatrix, n), t || (t = new Laya.Point), t.x = n.x / Laya.stage.clientScaleX, t.y = n.y / Laya.stage.clientScaleY, t
                        }, t.prototype.convertCoord2dTo3d = function (e, t) {
                            this._convertCoord3dTo2dTempV3;
                            var n = this._convertCoord2dTo3dTempRay;
                            if (e.x *= Laya.stage.clientScaleX, e.y *= Laya.stage.clientScaleY, this.camera.viewportPointToRay(e, n), t || (t = new Laya.Vector3), 0 == n.direction.y) return t.x = n.origin.x, t.y = 0, t.z = n.origin.z, t;
                            var i = (0 - n.origin.y) / n.direction.y;
                            return t.x = n.origin.x + i * n.direction.x, t.y = 0, t.z = n.origin.z + i * n.direction.z, t
                        }, t
                    }(Laya.Scene3D);
                n.GameScene3d = l
            }, {
                "../model/ModelLoader": 54,
                "../model/ModelMgr": 55
            }],
            93: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("./GameScene3d"),
                    s = e("../snake/S2Macro"),
                    l = e("../model/ModelConfig"),
                    c = e("../snake/S2Math"),
                    u = e("../common/SceneID"),
                    d = e("../ads/InsideAds"),
                    h = e("../logic/GameLogic"),
                    f = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._scene3d = null, t._modelList = [], t._showAnim = !1, t._zoom = 5, d.default.instance.hide(), h.default.instance.HideFeedback(), h.default.instance.HideGameClub(), t._scene3d = new r.GameScene3d, t._pnl3d.addChild(t._scene3d), t._scene3d.addBg(l.ModelConfig.sceneUrl[0]), t._updateCamera(), t._btnAdd.on(Laya.Event.CLICK, t, t._onBtnAddClick), t._btnAnim.on(Laya.Event.CLICK, t, t._onBtnAnimClick), t._btnZoomIn.on(Laya.Event.CLICK, t, t._onBtnZoomInClick), t._btnZoomOut.on(Laya.Event.CLICK, t, t._onBtnZoomOutClick), t._btnClose.on(Laya.Event.CLICK, t, t._onBtnCloseClick), Laya.timer.frameLoop(1, t, t._update), t
                        }
                        return o(t, e), t.prototype._addModel = function () {
                            var e = l.ModelConfig.snakeUrl[1].body,
                                t = c.s2Math.rndFloat(.375 * s.s2Macro.map_width, .625 * s.s2Macro.map_width),
                                n = c.s2Math.rndFloat(.375 * s.s2Macro.map_height, .625 * s.s2Macro.map_height),
                                i = this._scene3d.addModel(e);
                            i.transform.localPosition.setValue(t, 20, n), i.transform.localPosition = i.transform.localPosition, this._modelList.push(i)
                        }, t.prototype._updateCamera = function () {
                            this._scene3d.updateCamera(.5 * s.s2Macro.map_width, .6 * s.s2Macro.map_height, this._zoom)
                        }, t.prototype._updateLbl = function () {
                            this._lbl.changeText(this._modelList.length + "")
                        }, t.prototype._update = function () {
                            this._showAnim && this._modelList.forEach(function (e) {
                                e.transform.localRotationEulerY = e.transform.localRotationEulerY + 1
                            })
                        }, t.prototype._onBtnAnimClick = function () {
                            this._showAnim = !this._showAnim
                        }, t.prototype._onBtnAddClick = function () {
                            for (var e = 0; e < 20; ++e) this._addModel();
                            this._updateLbl()
                        }, t.prototype._onBtnZoomInClick = function () {
                            this._zoom += .5, this._updateCamera()
                        }, t.prototype._onBtnZoomOutClick = function () {
                            this._zoom = Math.max(.5, this._zoom - .5), this._updateCamera()
                        }, t.prototype._onBtnCloseClick = function () {
                            Laya.Scene.open(u.default.Main, !0)
                        }, t
                    }(a.ui.view.GameTestUI);
                n.default = f
            }, {
                "../ads/InsideAds": 8,
                "../common/SceneID": 17,
                "../logic/GameLogic": 44,
                "../model/ModelConfig": 53,
                "../snake/S2Macro": 75,
                "../snake/S2Math": 77,
                "../ui/layaMaxUI": 97,
                "./GameScene3d": 92
            }],
            94: [function (e, t, n) {
                "use strict";
                var i = this && this.__spreadArrays || function () {
                    for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                    var i = Array(e),
                        o = 0;
                    for (t = 0; t < n; t++)
                        for (var a = arguments[t], r = 0, s = a.length; r < s; r++, o++) i[o] = a[r];
                    return i
                };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var o = e("../snake/S2Macro"),
                    a = e("../snake/S2Types"),
                    r = e("../snake/S2Stage"),
                    s = (e("../sound/SoundMgr"), e("../platform/yt")),
                    l = function () {
                        function e() {
                            this._stage = null, this._timestamp = 0, this._paused = !1, this._onAddEnergy = null, this.scene2d = null, this.scene3d = null, this._tempV1 = new Laya.Vector3, this._tempV2 = new Laya.Vector3, this._tempQuat = new Laya.Quaternion, this._tempMat = new Laya.Matrix4x4, this._stage = new r.s2Stage
                        }
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e)
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.setReviveCallback = function (e) {
                            this._stage.onRevive = e
                        }, e.prototype.setGameOverCallback = function (e) {
                            this._stage.onGameOver = e
                        }, e.prototype.setDeadCallback = function (e) {
                            this._stage.onDead = e
                        }, e.prototype.setAddEnergyCallback = function (e) {
                            this._onAddEnergy = e
                        }, e.prototype.getPlayerNumber = function () {
                            return o.s2Macro.player_number
                        }, e.prototype.newGame = function (e) {
                            this._timestamp = (new Date).getTime(), this._stage.newGame(e)
                        }, e.prototype.pauseGame = function () {
                            this._paused = !0
                        }, e.prototype.resumeGame = function () {
                            this._paused = !1
                        }, e.prototype.update = function () {
                            var e = (new Date).getTime(),
                                t = (e - this._timestamp) / 1e3;
                            if (this._timestamp = e, !this._paused) {
                                var n = s.default.isIos() ? t : 1 / 60;
                                this._stage.update(n, t)
                            }
                        }, e.prototype.setAngle = function (e) {
                            this._stage.player.setAngle(e)
                        }, e.prototype.getAngle = function () {
                            return this._stage.player.getAngle()
                        }, e.prototype.setSlipDistance = function (e) {
                            this._stage.player.setSlipDistance(e)
                        }, e.prototype.getRankList = function () {
                            return this._stage.getRankList()
                        }, e.prototype.getHighScorePlayer = function () {
                            for (var e = this._stage.getRankList(), t = null, n = 0, i = e.length; n < i; ++n) {
                                var o = e[n];
                                if (!o.isPlayer && !o.isDead) {
                                    t = o;
                                    break
                                }
                            }
                            return t
                        }, e.prototype.getGameDuration = function () {
                            return this._stage.gameDuration
                        }, e.prototype.getRemainTime = function () {
                            return Math.floor(this._stage.gameMaxDuration - Math.floor(this._stage.gameDuration))
                        }, e.prototype.getGameScore = function () {
                            return Math.floor(this._stage.player.snake.energy / 100)
                        }, e.prototype.getPlayerAttr = function () {
                            return this._stage.player.snake
                        }, e.prototype.getDefaultInitLength = function () {
                            return o.s2Macro.snake_init_length
                        }, e.prototype.getDefaultInitVelocity = function () {
                            return o.s2Macro.snake_init_velocity
                        }, e.prototype.getMaxVelocity = function () {
                            return o.s2Macro.snake_max_velocity
                        }, e.prototype.clear = function () {
                            var e = this;
                            this._stage.clear(), i(this._stage.snakeList, this._stage.deadSnakeList, [this._stage.foodContainer]).forEach(function (t) {
                                t.removedUserDataList.forEach(function (t) {
                                    t && t.userData && (Laya.Tween.clearAll(t.userData.transform.localPosition), e.scene3d.removeModel(t.userData))
                                }), t.removedUserDataList.length = 0
                            })
                        }, e.prototype.triggerGC = function () {
                            this._stage.triggerGC()
                        }, e.prototype.update3d = function () {
                            var e = this;
                            if (!this._paused) {
                                var t = this._stage.player.snake;
                                if (t.isDead) this.scene3d.hideArrow();
                                else {
                                    if (t.isEating) {
                                        var n = t.x + 45 * t.vx * t.scale,
                                            i = 20 * t.scale,
                                            r = t.y + 45 * t.vy * t.scale;
                                        this.scene3d.addParticle(n, i, r, t.scale), Laya.timer.callLater(this, this._onEating), this._onAddEnergy(t.addedEnergy)
                                    }
                                    var s = this._stage.player._angle,
                                        l = 6 * Math.pow(this.scene2d.distance, .6) * t.scale,
                                        c = (n = t.x, i = t.y, t.scale);
                                    n += Math.cos(s) * l, i += Math.sin(s) * l, this.scene3d.updateArrow(s, n, 0, i, c)
                                }
                                for (var u = this.scene3d.cameraTopLeftPos, d = this.scene3d.cameraBottomLeftPos, h = t.y + (u.z - 80) * t.scale, f = t.y + (d.z + 80) * t.scale, p = this._stage.foodContainer, _ = function (t, n) {
                                        var i = p.removedUserDataList[t];
                                        if (i && i.userData) {
                                            var a = i.eater;
                                            if (a) {
                                                var r = i.userData,
                                                    s = i.userData.__light__,
                                                    l = a.x + a.vx * (o.s2Macro.snake_head_radius * a.scale + 50),
                                                    c = a.y + a.vy * (o.s2Macro.snake_head_radius * a.scale + 50);
                                                Laya.Tween.clearAll(r.transform.localPosition), Laya.Tween.to(r.transform.localPosition, {
                                                    x: l,
                                                    y: 0,
                                                    z: c,
                                                    update: new Laya.Handler(y, function () {
                                                        r.transform.localPosition = r.transform.localPosition, s && (s.transform.localPosition = r.transform.localPosition)
                                                    })
                                                }, 100, null, new Laya.Handler(y, function () {
                                                    e.scene3d && e.scene3d.removeModel(r), s && e.scene3d.removeModel(s)
                                                }), 50 * t)
                                            } else {
                                                y.scene3d.removeModel(i.userData);
                                                var u = i.userData.__light__;
                                                u && y.scene3d.removeModel(u)
                                            }
                                        }
                                    }, y = this, g = 0, m = p.removedUserDataList.length; g < m; ++g) _(g);
                                for (p.removedUserDataList.length = 0, g = 0, m = p.list.length; g < m; ++g) {
                                    var v = p.list[g],
                                        L = v.userData,
                                        w = (v.y - h) / (f - h),
                                        b = -(u.x + (d.x - u.x) * w);
                                    b = (b + 80) * t.scale;
                                    var S = t.x - b,
                                        A = t.x + b;
                                    if (v.x < S || v.x > A || v.y < h || v.y > f) L && L.active && (L.active = !1);
                                    else {
                                        L || (L = v.userData = this.scene3d.addFood()), !L.active && (L.active = !0);
                                        var I = L.transform,
                                            C = I.localPosition;
                                        (C.x - v.x) * (C.x - v.x) + (C.z - v.y) * (C.z - v.y) > .01 && (C.setValue(v.x, 0, v.y), I.localPosition = C), c = v.radius / o.s2Macro.food_radius * (v.value >= 50 ? 1.5 : v.value >= 90 ? 2 : 1);
                                        var k = I.localScale;
                                        k.x == c && k.y == c && k.z == c || (k.setValue(c, c, c), I.localScale = k);
                                        var M = L.__light__;
                                        if (M) {
                                            var E = M;
                                            E.active = !0;
                                            var T = E.transform,
                                                D = T.localPosition;
                                            (D.x - v.x) * (D.x - v.x) + (D.z - v.y) * (D.z - v.y) > .01 && (D.setValue(v.x, 0, v.y), T.localPosition = D);
                                            var O = v.radius / o.s2Macro.food_radius * (v.value >= 50 ? 1.5 : v.value >= 90 ? 2 : 1),
                                                P = T.localScale;
                                            P.x == O && P.y == O && P.z == O || (P.setValue(O, O, O), T.localScale = P)
                                        }
                                    }
                                }
                                for (var x = 0, B = this._stage.deadSnakeList.length; x < B; ++x) {
                                    var R = (G = this._stage.deadSnakeList[x]).userData;
                                    for (G.list.length > 0 && console.e("死蛇不应该有节点"), g = 0, m = G.removedUserDataList.length; g < m; ++g) {
                                        var N = G.removedUserDataList[g];
                                        N && N.userData && this.scene3d.removeModel(N.userData)
                                    }
                                    G.removedUserDataList.length = 0
                                }
                                for (x = 0, B = this._stage.snakeList.length; x < B; ++x) {
                                    var G;
                                    R = (G = this._stage.snakeList[x]).userData, G.removedUserDataList.length > 0 && console.e("活蛇不应该有移除的节点");
                                    var U = 0,
                                        V = function (n, i) {
                                            var r = G.list[n],
                                                s = r.userData,
                                                l = -(u.x + (d.x - u.x) * (r.y - h) / (f - h));
                                            l = (l + 80) * t.scale;
                                            var c = t.x - l,
                                                p = t.x + l;
                                            if (r.overlap || r.x < c || r.x > p || r.y < h || r.y > f) return s && s.active && (s.active = !1), "continue";
                                            s || (s = r.userData = F.scene3d.addModel(r.type == a.s2PointType.Head ? R.headModelUrl : R.bodyModelUrl)), !s.active && (s.active = !0);
                                            var _ = r.radius / (r.type == a.s2PointType.Head ? o.s2Macro.snake_head_radius : o.s2Macro.snake_body_radius),
                                                y = s.transform;
                                            if (F._tempV1.setValue(r.x, 20, r.y), F._tempV2.setValue(_, _, _), Laya.Quaternion.createFromYawPitchRoll(.5 * Math.PI - r.angle, 0, 0, F._tempQuat), Laya.Matrix4x4.createAffineTransformation(F._tempV1, F._tempQuat, F._tempV2, F._tempMat), y.localMatrix = F._tempMat, ++U, G.isIncrease && 0 != n) {
                                                var g = s.getChildAt(0);
                                                g && (g.transform.localScale.setValue(1, 1, 1), g.transform.localScale = g.transform.localScale, Laya.Tween.to(g.transform.localScale, {
                                                    x: 1.5,
                                                    y: 1.5,
                                                    z: 1.5,
                                                    update: new Laya.Handler(F, function () {
                                                        s.active && (g.transform.localScale = g.transform.localScale)
                                                    })
                                                }, 200, null, new Laya.Handler(F, function () {
                                                    Laya.Tween.to(g.transform.localScale, {
                                                        x: 1,
                                                        y: 1,
                                                        z: 1,
                                                        update: new Laya.Handler(e, function () {
                                                            s.active && (g.transform.localScale = g.transform.localScale)
                                                        })
                                                    }, 200)
                                                }), 100 * n))
                                            }
                                        },
                                        F = this;
                                    for (g = 0, m = G.list.length; g < m; ++g) V(g);
                                    G.lowPower = 0 == U
                                }
                                var H = this._stage.getRankList();
                                for (g = 0; g < 1; ++g) {
                                    var j = H[g];
                                    j && !j.isDead ? this.scene3d.updateCrown(g, j.snake.x, 0, j.snake.y, j.snake.scale) : this.scene3d.hideCrown(g)
                                }
                            }
                        }, e.prototype._onEating = function () {
                            YYGGames.audio.playSound("sound/coineff.mp3")
                        }, e
                    }();
                n.SnakeBridge = l, window.SnakeBridge = l
            }, {
                "../platform/yt": 63,
                "../snake/S2Macro": 75,
                "../snake/S2Stage": 86,
                "../snake/S2Types": 87,
                "../sound/SoundMgr": 96
            }],
            95: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function () {
                    function e() {}
                    return e.ButtonTap = "sound/1000.mp3", e.PopView = "sound/1001.mp3", e.UnlockSkin = "sound/1002.mp3", e.UpgradeBtn = "sound/1003.mp3", e.BGM = "sound/1004.mp3", e.GetDiamond = "sound/1005.mp3", e.Revive = "sound/1006.mp3", e.EndCountDown = "sound/1007.mp3", e.CountDownPop = "sound/1008.mp3", e.Score = "sound/1009.mp3", e.NewRecord = "sound/1010.mp3", e.Merge = "sound/1011.mp3", e.Unlock = "sound/1012.mp3", e
                }();
                n.default = i
            }, {}],
            96: [function (e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../core/DataStorage"),
                    o = e("../Common/DataID"),
                    a = e("../data/SettingSvData"),
                    r = e("../platform/yt"),
                    s = function () {
                        function e() {}
                        return Object.defineProperty(e, "instance", {
                            get: function () {
                                return this._instance || (this._instance = new e), this._instance
                            },
                            enumerable: !0,
                            configurable: !0
                        }), e.prototype.Init = function () {}, e.prototype.SoundOn = function () {
                            this.setting.isSoundOn = 1
                        }, e.prototype.SoundOff = function () {
                            this.setting.isSoundOn = 0
                        }, e.prototype.MusicOn = function () {
                            this.setting.isMusicOn = 1
                        }, e.prototype.MusicOff = function () {
                            this.setting.isMusicOn = 0
                        }, e.prototype.VibrateOn = function () {
                            this.setting.isVibrateOn = 1
                        }, e.prototype.VibrateOff = function () {
                            this.setting.isVibrateOn = 0
                        }, e.prototype.VibrateShort = function () {
                            1 == this.setting.isVibrateOn && r.default.vibrateShort()
                        }, e.prototype.VibrateLong = function () {
                            1 == this.setting.isVibrateOn && r.default.vibrateLong()
                        }, e.prototype.playSound = function (e) {
                            console.error("playSound:" + e), 1 == this.setting.isSoundOn && Laya.SoundManager.playSound(e)
                        }, e.prototype.LoadSettingData = function () {
                            var e = i.default.getItem(o.default.setting);
                            this.setting = e ? JSON.parse(e) : new a.default
                        }, e.prototype.SaveSettingData = function () {
                            i.default.setItem(o.default.setting, JSON.stringify(this.setting))
                        }, e
                    }();
                n.default = s
            }, {
                "../Common/DataID": 1,
                "../core/DataStorage": 22,
                "../data/SettingSvData": 37,
                "../platform/yt": 63
            }],
            97: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a, r = Laya.View,
                    s = Laya.Scene,
                    l = Laya.ClassUtils.regClass;
                a = n.ui || (n.ui = {}),
                    function (e) {
                        var t = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/BalloonLayer")
                            }, t
                        }(s);
                        e.BalloonLayerUI = t, l("ui.view.BalloonLayerUI", t);
                        var n = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/ExitAds")
                            }, t
                        }(s);
                        e.ExitAdsUI = n, l("ui.view.ExitAdsUI", n);
                        var i = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/FullScrollAds")
                            }, t
                        }(s);
                        e.FullScrollAdsUI = i, l("ui.view.FullScrollAdsUI", i);
                        var a = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/GameScene")
                            }, t
                        }(s);
                        e.GameSceneUI = a, l("ui.view.GameSceneUI", a);
                        var c = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/GameScene2d")
                            }, t
                        }(s);
                        e.GameScene2dUI = c, l("ui.view.GameScene2dUI", c);
                        var u = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/GameTest")
                            }, t
                        }(s);
                        e.GameTestUI = u, l("ui.view.GameTestUI", u);
                        var d = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/GuideView")
                            }, t
                        }(s);
                        e.GuideViewUI = d, l("ui.view.GuideViewUI", d);
                        var h = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/InsideAds3")
                            }, t
                        }(s);
                        e.InsideAds3UI = h, l("ui.view.InsideAds3UI", h);
                        var f = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/MergeAddCoins")
                            }, t
                        }(r);
                        e.MergeAddCoinsUI = f, l("ui.view.MergeAddCoinsUI", f);
                        var p = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/MergeItem")
                            }, t
                        }(s);
                        e.MergeItemUI = p, l("ui.view.MergeItemUI", p);
                        var _ = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/MergePnl")
                            }, t
                        }(r);
                        e.MergePnlUI = _, l("ui.view.MergePnlUI", _);
                        var y = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/MoreAds")
                            }, t
                        }(s);
                        e.MoreAdsUI = y, l("ui.view.MoreAdsUI", y);
                        var g = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/NativeBanner_")
                            }, t
                        }(s);
                        e.NativeBanner_UI = g, l("ui.view.NativeBanner_UI", g);
                        var m = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/NativeBottom_")
                            }, t
                        }(s);
                        e.NativeBottom_UI = m, l("ui.view.NativeBottom_UI", m);
                        var v = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/ScrollAds")
                            }, t
                        }(s);
                        e.ScrollAdsUI = v, l("ui.view.ScrollAdsUI", v);
                        var L = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/Toast")
                            }, t
                        }(s);
                        e.ToastUI = L, l("ui.view.ToastUI", L);
                        var w = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/diamonds_animation")
                            }, t
                        }(r);
                        e.diamonds_animationUI = w, l("ui.view.diamonds_animationUI", w);
                        var b = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/gamein_loading")
                            }, t
                        }(s);
                        e.gamein_loadingUI = b, l("ui.view.gamein_loadingUI", b);
                        var S = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/gamein_rank")
                            }, t
                        }(s);
                        e.gamein_rankUI = S, l("ui.view.gamein_rankUI", S);
                        var A = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/gamein_relive")
                            }, t
                        }(s);
                        e.gamein_reliveUI = A, l("ui.view.gamein_reliveUI", A);
                        var I = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/gamein_relive1")
                            }, t
                        }(s);
                        e.gamein_relive1UI = I, l("ui.view.gamein_relive1UI", I);
                        var C = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/gamein_score")
                            }, t
                        }(s);
                        e.gamein_scoreUI = C, l("ui.view.gamein_scoreUI", C);
                        var k = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/gamein_ui")
                            }, t
                        }(s);
                        e.gamein_uiUI = k, l("ui.view.gamein_uiUI", k);
                        var M = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/gold_animation")
                            }, t
                        }(r);
                        e.gold_animationUI = M, l("ui.view.gold_animationUI", M);
                        var E = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/loading")
                            }, t
                        }(s);
                        e.loadingUI = E, l("ui.view.loadingUI", E);
                        var T = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby")
                            }, t
                        }(s);
                        e.lobbyUI = T, l("ui.view.lobbyUI", T);
                        var D = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby_match_10")
                            }, t
                        }(s);
                        e.lobby_match_10UI = D, l("ui.view.lobby_match_10UI", D);
                        var O = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby_pifu")
                            }, t
                        }(s);
                        e.lobby_pifuUI = O, l("ui.view.lobby_pifuUI", O);
                        var P = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby_qiandao")
                            }, t
                        }(s);
                        e.lobby_qiandaoUI = P, l("ui.view.lobby_qiandaoUI", P);
                        var x = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby_rank")
                            }, t
                        }(s);
                        e.lobby_rankUI = x, l("ui.view.lobby_rankUI", x);
                        var B = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby_reward")
                            }, t
                        }(s);
                        e.lobby_rewardUI = B, l("ui.view.lobby_rewardUI", B);
                        var R = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby_setting")
                            }, t
                        }(s);
                        e.lobby_settingUI = R, l("ui.view.lobby_settingUI", R);
                        var N = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/lobby_shop")
                            }, t
                        }(s);
                        e.lobby_shopUI = N, l("ui.view.lobby_shopUI", N);
                        var G = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/skin_animation")
                            }, t
                        }(s);
                        e.skin_animationUI = G, l("ui.view.skin_animationUI", G);
                        var U = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/test")
                            }, t
                        }(s);
                        e.testUI = U, l("ui.view.testUI", U);
                        var V = function (e) {
                            function t() {
                                return e.call(this) || this
                            }
                            return o(t, e), t.prototype.createChildren = function () {
                                e.prototype.createChildren.call(this), this.loadScene("view/zhuanpan")
                            }, t
                        }(s);
                        e.zhuanpanUI = V, l("ui.view.zhuanpanUI", V)
                    }(a.view || (a.view = {}))
            }, {}],
            98: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/RewardLogic"),
                    s = e("../core/ShareLogic"),
                    l = e("../logic/BalloonLogic"),
                    c = e("../sound/SoundMgr"),
                    u = e("../sound/SoundID"),
                    d = e("./Toast"),
                    h = e("../data/DataBus"),
                    f = e("../logic/EconomicLogic"),
                    p = e("../core/GameHelper"),
                    _ = e("../logic/MergeLogic"),
                    y = e("../logic/SkinLogic"),
                    g = e("../platform/yt"),
                    m = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            t._rewardMethod = r.RewardMethodEnum.NONE;
                            var n = Laya.stage,
                                i = n.width,
                                o = n.height;
                            return t.size(i, o), t.bg.size(i, o), t
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            this._updateRewardMethod(), this._setAllBtnsEnabled(!0)
                        }, t.prototype._onRemoved = function () {
                            Laya.timer.clear(this, this._updateRewardMethod), g.default.off(g.default.Event.VideoAdLoaded, this._updateRewardMethod, this), l.default.instance.updateBalloon(), e.prototype._onRemoved.call(this)
                        }, t.prototype._updateRewardMethod = function () {
                            console.log("更新激励类型"), Laya.timer.clear(this, this._updateRewardMethod), g.default.off(g.default.Event.VideoAdLoaded, this._updateRewardMethod, this);
                            var e = r.default.instance.ShareOrVideo(s.ShareTypeEnum.BALLOON);
                            this._rewardMethod = e, e == r.RewardMethodEnum.VIDEO ? (this.btnTxt.centerX = 25, this.btnIco.visible = !0) : (this.btnTxt.centerX = 0, this.btnIco.visible = !1)
                        }, t.prototype._updateRewardMethodAfterVideo = function () {
                            Laya.timer.once(2e3, this, this._updateRewardMethod), g.default.once(g.default.Event.VideoAdLoaded, this._updateRewardMethod, this)
                        }, t.prototype._setAllBtnsEnabled = function (e) {
                            this._btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnGet.off(Laya.Event.CLICK, this, this._onBtnGetClick), e && (this._btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnGet.on(Laya.Event.CLICK, this, this._onBtnGetClick))
                        }, t.prototype._onBtnCloseClick = function () {
                            c.default.instance.playSound(u.default.ButtonTap), this.removeSelf()
                        }, t.prototype._onBtnGetClick = function () {
                            var e = this;
                            YYGGames.showReward(() => {
                                c.default.instance.playSound(u.default.ButtonTap), this._setAllBtnsEnabled(!1), Laya.timer.once(100, this, this._setAllBtnsEnabled, [!0]);
                                var t = function () {
                                        var t = l.default.instance.getPrize();
                                        switch (t.type) {
                                            case l.BalloonPrizeType.Coins:
                                                f.default.instance.AddCoinWithAnimation(t.value), d.default.show("You got " + p.default.toAbb(t.value) + "coins");
                                                break;
                                            case l.BalloonPrizeType.Diamonds:
                                                f.default.instance.AddDiamondWithAnimation(t.value), d.default.show("You got " + p.default.toAbb(t.value) + " diamonds!");
                                                break;
                                            case l.BalloonPrizeType.Snake:
                                                _.default.instance.addItemWithAnimation(t.value);
                                                var n = t.value + 1,
                                                    i = y.default.instance.GetSkinCnf(n);
                                                d.default.show("Got " + i.name + "!")
                                        }
                                        h.default.instance.lotteryData.balloon_times += 1, h.default.instance.SaveLotteryData(), e.removeSelf()
                                    },
                                    n = function () {
                                        e._updateRewardMethodAfterVideo()
                                    };
                                switch (this._rewardMethod) {
                                    case r.RewardMethodEnum.SHARE:
                                        r.default.instance.ShareReward(s.ShareTypeEnum.BALLOON, t, n);
                                        break;
                                    case r.RewardMethodEnum.VIDEO:
                                        r.default.instance.VideoReward(!1, t, n);
                                        break;
                                    default:
                                        d.default.show("视频尚未加载好!"), this._updateRewardMethod()
                                }
                            })
                        }, t
                    }(a.ui.view.BalloonLayerUI);
                n.default = m
            }, {
                "../core/GameHelper": 23,
                "../core/RewardLogic": 27,
                "../core/ShareLogic": 29,
                "../data/DataBus": 32,
                "../logic/BalloonLogic": 40,
                "../logic/EconomicLogic": 43,
                "../logic/MergeLogic": 47,
                "../logic/SkinLogic": 48,
                "../platform/yt": 63,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./Toast": 121
            }],
            99: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../sound/SoundID"),
                    s = e("../sound/SoundMgr"),
                    l = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._onNext = null, t._aniNode.y = .45 * Laya.stage.height, t._aniNode.visible = !1, t.zOrder = 1, t
                        }
                        return o(t, e), t.prototype.onOpened = function (e) {
                            if (e || (e = {
                                    targetPos: null,
                                    onNext: null
                                }), !e.targetPos) {
                                var t = Laya.Point.create();
                                Laya.stage.height / Laya.stage.width > 2 ? t.setTo(60, 200) : t.setTo(60, 140), e.targetPos = t
                            }
                            this._onNext = e.onNext, this._playGoldAnimation(e.targetPos)
                        }, t.prototype._onRemoved = function () {
                            this._onNext && this._onNext(), e.prototype._onRemoved.call(this)
                        }, t.prototype._playGoldAnimation = function (e) {
                            Laya.timer.clear(this, this._hideGoldAnimationNode), this._aniNode.visible = !0;
                            for (var t = 0, n = this._aniNode.numChildren; t < n; ++t) {
                                var i = this._aniNode.getChildAt(t);
                                i.scale(1, 1, !0), Laya.Tween.clearAll(i)
                            }
                            this.diamondAni.play(0, !1), this.diamondAni.off(Laya.Event.COMPLETE, this, this._onGoldAnimationComplete), this.diamondAni.on(Laya.Event.COMPLETE, this, this._onGoldAnimationComplete, [e]), s.default.instance.playSound(r.default.NewRecord)
                        }, t.prototype._onGoldAnimationComplete = function (e) {
                            for (var t = 500, n = this._aniNode.globalToLocal(e), i = function (e, i) {
                                    var a = o._aniNode.getChildAt(e);
                                    if (!a.name.match("light")) {
                                        Laya.Tween.clearAll(a), a.visible = !0, a.scale(1, 1, !0);
                                        var r = 200 * Math.random(),
                                            s = 150 * Math.random(),
                                            l = 500 + s,
                                            c = n.x + 20 * Math.random() - 10,
                                            u = n.y + 20 * Math.random() - 10;
                                        Laya.Tween.to(a, {
                                            x: c,
                                            y: u,
                                            scaleX: .5,
                                            scaleY: .5
                                        }, l, Laya.Ease.sineOut, new Laya.Handler(o, function () {
                                            a.visible = !1
                                        }), r), 500 + r + s > t && (t = 500 + r + s)
                                    }
                                }, o = this, a = 0, r = this._aniNode.numChildren; a < r; ++a) i(a);
                            n.recover(), Laya.timer.once(t, this, this._hideGoldAnimationNode)
                        }, t.prototype._hideGoldAnimationNode = function () {
                            this._aniNode.visible = !1, this.removeSelf()
                        }, t
                    }(a.ui.view.diamonds_animationUI);
                n.default = l
            }, {
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            100: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/ShareLogic"),
                    s = e("../sound/SoundID"),
                    l = e("../sound/SoundMgr"),
                    c = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._onNext = null, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this._btnShare.on(Laya.Event.CLICK, this, this._onBtnShareClick), this._btnSkip.on(Laya.Event.CLICK, this, this._onBtnSkipClick)
                        }, t.prototype.onOpened = function (e) {
                            this._onNext = e.onNext, this._updateRankList(e.list)
                        }, t.prototype._onRemoved = function () {
                            e.prototype._onRemoved.call(this)
                        }, t.prototype._updateRankList = function (e) {
                            var t = e.map(function (e) {
                                var t = e.rank,
                                    n = t >= 1 && t <= 3 ? "" : t.toString();
                                return {
                                    bg: e.isPlayer ? "tex/pure/lobby_buttom_light_yellow.png" : t >= 1 && t <= 3 ? "tex/pure/lobby_buttom_light_purple.png" : "tex/pure/lobby_buttom_light_green.png",
                                    rankBg: "tex/windows_icon_rank" + (t >= 1 && t <= 3 ? t : 4) + ".png",
                                    rank: {
                                        text: n
                                    },
                                    nick: {
                                        text: e.userData.nickName
                                    },
                                    score: {
                                        text: e.score.toString()
                                    }
                                }
                            });
                            this._list.array = t
                        }, t.prototype._onBtnShareClick = function () {
                            l.default.instance.playSound(s.default.ButtonTap), r.default.instance.Share(r.ShareTypeEnum.GAMERANK)
                        }, t.prototype._onBtnSkipClick = function () {
                            YYGGames.showInterstitial(() => {
                                l.default.instance.playSound(s.default.ButtonTap), this.removeSelf(), this._onNext && this._onNext()
                            })
                        }, t
                    }(a.ui.view.gamein_rankUI);
                n.default = c
            }, {
                "../core/ShareLogic": 29,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            101: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../sound/SoundID"),
                    s = e("../sound/SoundMgr"),
                    l = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._onNext = null, t._goldAniNode.y = .45 * Laya.stage.height, t._goldAniNode.visible = !1, t.zOrder = 1, t
                        }
                        return o(t, e), t.prototype.onOpened = function (e) {
                            if (e || (e = {
                                    targetPos: null,
                                    onNext: null
                                }), !e.targetPos) {
                                var t = Laya.Point.create();
                                Laya.stage.height / Laya.stage.width > 2 ? t.setTo(60, 120) : t.setTo(60, 60), e.targetPos = t
                            }
                            this._onNext = e.onNext, this._playGoldAnimation(e.targetPos)
                        }, t.prototype._onRemoved = function () {
                            this._onNext && this._onNext(), e.prototype._onRemoved.call(this)
                        }, t.prototype._playGoldAnimation = function (e) {
                            Laya.timer.clear(this, this._hideGoldAnimationNode), this._goldAniNode.visible = !0;
                            for (var t = 0, n = this._goldAniNode.numChildren; t < n; ++t) {
                                var i = this._goldAniNode.getChildAt(t);
                                i.scale(1, 1, !0), Laya.Tween.clearAll(i)
                            }
                            this.goldAni.play(0, !1), this.goldAni.off(Laya.Event.COMPLETE, this, this._onGoldAnimationComplete), this.goldAni.on(Laya.Event.COMPLETE, this, this._onGoldAnimationComplete, [e]), s.default.instance.playSound(r.default.NewRecord)
                        }, t.prototype._onGoldAnimationComplete = function (e) {
                            for (var t = 500, n = this._goldAniNode.globalToLocal(e), i = function (e, i) {
                                    var a = o._goldAniNode.getChildAt(e);
                                    if (!a.name.match("light")) {
                                        Laya.Tween.clearAll(a), a.visible = !0, a.scale(1, 1, !0);
                                        var r = 200 * Math.random(),
                                            s = 150 * Math.random(),
                                            l = 500 + s,
                                            c = n.x + 20 * Math.random() - 10,
                                            u = n.y + 20 * Math.random() - 10;
                                        Laya.Tween.to(a, {
                                            x: c,
                                            y: u,
                                            scaleX: .5,
                                            scaleY: .5
                                        }, l, Laya.Ease.sineOut, new Laya.Handler(o, function () {
                                            a.visible = !1
                                        }), r), 500 + r + s > t && (t = 500 + r + s)
                                    }
                                }, o = this, a = 0, r = this._goldAniNode.numChildren; a < r; ++a) i(a);
                            n.recover(), Laya.timer.once(t, this, this._hideGoldAnimationNode)
                        }, t.prototype._hideGoldAnimationNode = function () {
                            this._goldAniNode.visible = !1, this.removeSelf()
                        }, t
                    }(a.ui.view.gold_animationUI);
                n.default = l
            }, {
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            102: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t._interactionArea = null, t._zoom = .5, t._init(), t
                    }
                    return o(t, e), t.prototype._init = function () {
                        var e = Laya.stage.width * this._zoom,
                            t = Laya.stage.height * this._zoom;
                        this.cacheAs = "bitmap", this.size(e, t), this.scale(1 / this._zoom, 1 / this._zoom);
                        var n = new Laya.Sprite;
                        n.alpha = .8, n.graphics.drawRect(-3, -3, e + 6, t + 6, "#000000"), this.addChild(n);
                        var i = new Laya.Sprite;
                        i.blendMode = "destination-out", this.addChild(i), this._interactionArea = i;
                        var o = new Laya.HitArea;
                        o.hit.drawRect(0, 0, e, t, "#000000"), this.hitArea = o, this.mouseEnabled = !0
                    }, t.prototype.addCircleHole = function (e, t, n) {
                        e *= this._zoom, t *= this._zoom, n *= this._zoom, this._interactionArea.graphics.drawCircle(e, t, n, "#000000"), this.hitArea.unHit.drawCircle(e, t, n, "#000000")
                    }, t.prototype.addRectHole = function (e, t, n, i) {
                        e *= this._zoom, t *= this._zoom, n *= this._zoom, i *= this._zoom, this._interactionArea.graphics.drawRect(e, t, n, i, "#000000"), this.hitArea.unHit.drawRect(e, t, n, i, "#000000")
                    }, t.prototype.clearHole = function () {
                        this._interactionArea.graphics.clear(), this.hitArea.unHit.clear()
                    }, t
                }(Laya.Sprite);
                n.default = a
            }, {}],
            103: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a, r, s = e("../ui/layaMaxUI"),
                    l = e("./GuideMask"),
                    c = e("../common/SceneID"),
                    u = e("../logic/GameLogic"),
                    d = e("../core/Server"),
                    h = e("../common/ReportEventID"),
                    f = e("../snake_view/Avatar"),
                    p = e("../snake/S2Macro"),
                    _ = e("../logic/GuideLogic"),
                    y = e("../common/EventID"),
                    g = e("../logic/MergeLogic"),
                    m = e("../ads/InsideAds"),
                    v = e("../logic/DialogLogic");
                r = a = n.GuideTypeEnum || (n.GuideTypeEnum = {}), r[r.None = 0] = "None", r[r.Game = 1] = "Game", r[r.Buy = 2] = "Buy", r[r.Merge = 3] = "Merge", r[r.Skin = 4] = "Skin", r[r.QuickBought = 5] = "QuickBought";
                var L = function (e) {
                    function t() {
                        var n = e.call(this) || this;
                        return n._type = a.None, n._target = null, n._guideMask = null, n._merged = !1, n._handTimeLine = null, t._instance = n, n._init(), n
                    }
                    return o(t, e), t.show = function (e, t) {
                        this._instance ? this._instance.show(e, t) : v.default.instance.insertDialogAfter(c.default.Guide, c.default.Guide, {
                            type: e,
                            target: t
                        })
                    }, t.prototype._init = function () {
                        this.size(0, 0), this.zOrder = 2, this._hand.zOrder = 1, this._dialog.zOrder = 1, this.mouseEnabled = !0, this._guideMask = new l.default, this.addChild(this._guideMask)
                    }, t.prototype.onOpened = function (e) {
                        Laya.timer.callLater(this, this.show, [e.type, e.target]), m.default.instance.hide()
                    }, t.prototype._onRemoved = function () {
                        t._instance = null, this._handTimeLine && this._handTimeLine.destroy(), this._type, a.Game, e.prototype._onRemoved.call(this)
                    }, t.prototype.show = function (e, t) {
                        switch (this._type = e, this._target = t, e) {
                            case a.Game:
                                this.showGameGuide(t), YYGGames.gameBox.visible = !1;
                                break;
                            case a.Buy:
                                this.showBuyGuide(t), YYGGames.gameBox.visible = !1;
                                break;
                            case a.Merge:
                                this.showMergeGuide(t), YYGGames.gameBox.visible = !1;
                                break;
                            case a.Skin:
                                this.showSkinGuide(t), YYGGames.gameBox.visible = !1;
                                break;
                            case a.QuickBought:
                                this.showQuickBoughtGuide(t), YYGGames.gameBox.visible = !1;
                                break;
                            default:
                                this.removeSelf()
                        }
                    }, t.prototype.showGameGuide = function (e) {
                        this._guideMask.clearHole();
                        var t = this._getGlobalBounds(e.btnStart, 12);
                        this._guideMask.addRectHole(t.x, t.y, t.width, t.height);
                        var n = this._getBoundsCenter(t);
                        this._showHandClickAnimation(n), this._dialog.y = t.y - 100, this._setContent("Click here to start a new game!"), e.setAllBtnsEnable(!1), e.btnStart.once(Laya.Event.CLICK, this, function () {
                            YYGGames.showInterstitial(() => {
                                var e = u.default.instance.getGameParam();
                                e.avatarList = f.Avatar.getRandomList(p.s2Macro.player_number), Laya.Scene.open(c.default.Game, !0, e), d.default.reportEvent(h.default.start_game)
                            })
                        }), n.recover()
                    }, t.prototype.showBuyGuide = function (e) {
                        var t = this;
                        this._guideMask.clearHole();
                        var n = this._getGlobalBounds(e.btnReceive, 12);
                        this._guideMask.addRectHole(n.x, n.y, n.width, n.height);
                        var i = this._getBoundsCenter(n);
                        this._showHandClickAnimation(i), this._dialog.y = n.y - 100, this._setContent("Click the button to buy snakes!", 26), e.setAllBtnsEnable(!0);
                        var o = 0,
                            a = function () {
                                0 == o ? (o = 1, t._setContent("Awesome! Now click the button to continue buying snakes!")) : (e.btnBuy.off(Laya.Event.CLICK, t, a), t.removeSelf())
                            };
                        e.btnBuy.on(Laya.Event.CLICK, this, a), this.once(Laya.Event.REMOVED, this, function () {
                            Laya.timer.callLater(t, function () {
                                e.btnReceive.off(Laya.Event.CLICK, t, a), e.setAllBtnsEnable(!0)
                            })
                        }), i.recover()
                    }, t.prototype.showMergeGuide = function (e) {
                        var t = this;
                        this._guideMask.clearHole();
                        var n = _.default.instance.findTwoSameItem(e);
                        n && n[0] && n[1] || this.removeSelf();
                        var i = this._getGlobalBounds(n[0].cell, 0),
                            o = this._getGlobalBounds(n[1].cell, 0),
                            a = this._mixBounds(i, o);
                        this._guideMask.addRectHole(a.x, a.y, a.width, a.height);
                        var r = this._getBoundsCenter(i),
                            s = this._getBoundsCenter(o);
                        this._showHandMoveAnimation(r, s), this._dialog.y = a.y - 100, this._setContent("Drag two identical snakes together to create a higher level snake!"), e.setAllBtnsEnable(!1), YYGGames.gameBox.visible = !1;
                        var l = e.mergePnl;
                        l.off(y.default.MERGE_CHANGED, this, this._onMergeChanged), l.off(y.default.MERGED, this, this._onMerged), l.on(y.default.MERGE_CHANGED, this, this._onMergeChanged), l.on(y.default.MERGED, this, this._onMerged), l.salePnlEnabled = !1, this.once(Laya.Event.REMOVED, this, function () {
                            l.off(y.default.MERGE_CHANGED, t, t._onMergeChanged), l.off(y.default.MERGED, t, t._onMerged), e.setAllBtnsEnable(!0), l.salePnlEnabled = !0
                        }), r.recover(), s.recover()
                    }, t.prototype._onMergeChanged = function () {
                        Laya.timer.callLater(this, this._afterMergeChanged)
                    }, t.prototype._onMerged = function () {
                        this._merged = !0, Laya.timer.callLater(this, this._afterMergeChanged)
                    }, t.prototype._afterMergeChanged = function () {
                        var e = this._target;
                        if (this._merged) {
                            var t = e.mergePnl;
                            t.off(y.default.MERGE_CHANGED, this, this._onMergeChanged), t.off(y.default.MERGED, this, this._onMerged), e.setAllBtnsEnable(!0), t.salePnlEnabled = !0, this.removeSelf()
                        } else this.showMergeGuide(e)
                    }, t.prototype.showSkinGuide = function (e) {
                        var t = this;
                        this._guideMask.clearHole();
                        var n = this._getGlobalBounds(e.btnSkin, 0);
                        this._guideMask.addRectHole(n.x, n.y, n.width, n.height);
                        var i = this._getBoundsCenter(n);
                        this._showHandClickAnimation(i), this._dialog.y = n.y + n.height + this._dialog.height + 100, this._setContent("Click here to switch between your favorite snakes to play! Bonus attributes are calculated based on the highest unlocked level!", 22), e.setAllBtnsEnable(!1);
                        var o = function () {
                            v.default.instance.insertDialogAfter(c.default.Skin, c.default.Guide), e.btnSkin.off(Laya.Event.CLICK, t, o), e.setAllBtnsEnable(!0),
                                t.removeSelf()
                        };
                        e.btnSkin.once(Laya.Event.CLICK, this, o), this.once(Laya.Event.REMOVED, this, function () {
                            e.btnSkin.off(Laya.Event.CLICK, t, o), e.setAllBtnsEnable(!0)
                        }), i.recover()
                    }, t.prototype.showQuickBoughtGuide = function (e) {
                        var t = this;
                        this._guideMask.clearHole();
                        var n = this._getGlobalBounds(e.btnBuy, 12);
                        this._guideMask.addRectHole(n.x, n.y, n.width, n.height);
                        var i = this._getBoundsCenter(n);
                        this._showHandClickAnimation(i), this._dialog.y = n.y - 100;
                        var o = g.default.instance.getQuickLevel();
                        this._setContent("点击这里用金币快速购买一只" + (o + 1) + "级的蛇!"), e.setAllBtnsEnable(!1);
                        var a = function () {
                            g.default.instance.coinsBuyItem(g.default.instance.getQuickLevel(), !0), e.btnBuy.off(Laya.Event.CLICK, t, a), e.setAllBtnsEnable(!0), t.removeSelf()
                        };
                        e.btnBuy.once(Laya.Event.CLICK, this, a), this.once(Laya.Event.REMOVED, this, function () {
                            e.btnBuy.off(Laya.Event.CLICK, t, a), e.setAllBtnsEnable(!0)
                        }), i.recover()
                    }, t.prototype._getGlobalBounds = function (e, t) {
                        var n = Laya.Point.create();
                        n = e.localToGlobal(n.setTo(0, 0));
                        var i = Laya.Point.create();
                        i = e.localToGlobal(i.setTo(e.width, e.height));
                        var o = {
                            x: n.x - t,
                            y: n.y - t,
                            width: i.x - n.x + 2 * t,
                            height: i.y - n.y + 2 * t
                        };
                        return n.recover(), i.recover(), o
                    }, t.prototype._getBoundsCenter = function (e) {
                        return Laya.Point.create().setTo(e.x + .5 * e.width, e.y + .5 * e.height)
                    }, t.prototype._mixBounds = function (e, t) {
                        var n = Math.min(e.x, e.x + e.width, t.x, t.x + t.width),
                            i = Math.max(e.x, e.x + e.width, t.x, t.x + t.width),
                            o = Math.min(e.y, e.y + e.height, t.y, t.y + t.height);
                        return {
                            x: n,
                            y: o,
                            width: i - n,
                            height: Math.max(e.y, e.y + e.height, t.y, t.y + t.height) - o
                        }
                    }, t.prototype._setContent = function (e, t) {
                        void 0 === t && (t = 26), this._content.fontSize = t, this._content.text = e
                    }, t.prototype._showHandClickAnimation = function (e) {
                        this._hand.pos(e.x, e.y), this.clickAnim.play(0, !0), this.slipAnim.stop()
                    }, t.prototype._showHandMoveAnimation = function (e, t) {
                        if (e.x > t.x) {
                            var n = e;
                            e = t, t = n
                        }
                        this._hand.pos(e.x, e.y), this.clickAnim.stop(), this.slipAnim.play(0, !1), this._handTimeLine && this._handTimeLine.destroy(), this._handTimeLine = new Laya.TimeLine, this._handTimeLine.addLabel("move1", 0).to(this._hand, {
                            x: t.x,
                            y: t.y
                        }, 1e3, Laya.Ease.sineInOut).play(0, !0)
                    }, t._instance = null, t
                }(s.ui.view.GuideViewUI);
                n.default = L
            }, {
                "../ads/InsideAds": 8,
                "../common/EventID": 15,
                "../common/ReportEventID": 16,
                "../common/SceneID": 17,
                "../core/Server": 28,
                "../logic/DialogLogic": 42,
                "../logic/GameLogic": 44,
                "../logic/GuideLogic": 45,
                "../logic/MergeLogic": 47,
                "../snake/S2Macro": 75,
                "../snake_view/Avatar": 88,
                "../ui/layaMaxUI": 97,
                "./GuideMask": 102
            }],
            104: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("../core/GameHelper"),
                    l = e("../core/ReportLogic"),
                    c = e("../config/ConfigBus"),
                    u = e("../ui/layaMaxUI"),
                    d = e("../data/DataBus"),
                    h = e("../sound/SoundMgr"),
                    f = e("../core/ShareLogic"),
                    p = e("../config/GameCnf"),
                    _ = e("../logic/CollectLogic"),
                    y = e("../core/Server"),
                    g = e("../common/ReportEventID"),
                    m = e("../common/EventID"),
                    v = e("../common/SceneID"),
                    L = e("../snake_view/Avatar"),
                    w = e("../core/RewardLogic"),
                    b = e("../core/MyBanner"),
                    S = e("../ads/AdsLogic"),
                    A = e("../platform/yt"),
                    I = function (e) {
                        function t() {
                            return null !== e && e.apply(this, arguments) || this
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            A.default.init(p.default.sdkParams);
                            var e = 0;
                            A.default.on(A.default.Event.InsideAdsLoaded, function () {
                                Laya.stage.event(m.default.INSIDE_ADS_CHANGED)
                            }), A.default.on(A.default.Event.BannerAdChanged, function () {
                                Laya.stage.event(m.default.BANNER_CHANGED), clearTimeout(e), e = setTimeout(function () {
                                    A.default.isBannerVisible() ? b.default.instance.hide() : b.default.instance.show()
                                }, 100)
                            }), A.default.on(A.default.Event.VideoAdLoaded, function () {
                                Laya.stage.event(m.default.VIDEO_CHANGED)
                            }), A.default.on(A.default.Event.VideoAdClosed, function () {
                                Laya.stage.event(m.default.VIDEO_CHANGED)
                            }), L.Avatar.loadUserInfoFromLocal(), S.default.instance.init(), y.default.reportEvent(g.default.login_game), this.init()
                        }, t.prototype.init = function () {
                            this.size(Laya.stage.width, Laya.stage.height), this.bg.y = .5 * (Laya.stage.height - this.bg.height), A.default.isIos() && A.default.isLongScreen() ? this._footer.bottom = 65 : this._footer.bottom = 0, this.progress.value = 0, this.pika.x = 0, this._version.changeText("v" + p.default.sdkParams.gameVersion.toString()), "" != p.default.RemoteRes && (Laya.URL.basePath = p.default.RemoteRes, Laya.MiniAdpter && (Laya.MiniAdpter.nativefiles = ["ads", "config", "js", "libs", "loading", "number", "res/atlas", "res/model2", "sound", "sub", "tex", "view", "fileconfig.json", "game.json", "project.config.json", "unpack.json", "version.json"])), l.default.instance.reportAppid(0), Laya.loader.load(["res/atlas/number.atlas", "res/atlas/tex.atlas", "view/Toast.scene"], Laya.Handler.create(this, this.onLoaded), Laya.Handler.create(this, this.onLoading, [.5], !1))
                        }, t.prototype.onLoaded = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t, n, i, o, a;
                                return r(this, function (r) {
                                    switch (r.label) {
                                        case 0:
                                            return [4, this.pullRemoteCnf()];
                                        case 1:
                                            return r.sent(), this.onLoading(.6), [4, this.loadOther()];
                                        case 2:
                                            return r.sent(), h.default.instance.Init(), e = function (e) {
                                                if (e && (e.query && e.query.host_user_id && y.default.addInviteShare(e.query.host_user_id), _.default.instance.collectState != _.CollectStateEnum.GET)) {
                                                    var t = e.scene;
                                                    "1" != A.default.conf.collect_flag || 1023 !== t && 1104 !== t ? _.default.instance.collectState = _.CollectStateEnum.NO : (s.default.Log("从桌面或小程序进入"), _.default.instance.collectState = _.CollectStateEnum.COLLECTED)
                                                }
                                            }, t = function () {
                                                d.default.instance.SaveDataToServer(), d.default.instance.SaveLocalData()
                                            }, A.default.onShow(e), A.default.onHide(t), n = A.default.getLaunchOptionsSync(), console.log("当前的启动数据：", n), n && (i = "", o = -1, a = -1, n.query && (n.query.strategy_user_id && (i = n.query.strategy_user_id), n.query.position_id && (o = n.query.position_id), n.query.share_id && (a = n.query.share_id), n.query.strategy_cid ? A.default.strategyChannelId = n.query.strategy_cid : n.query.cid && "normalshare" != n.query.cid && (A.default.strategyChannelId = n.query.cid)), A.default.reportUser(i, o, a, -1, function () {
                                                f.default.instance.Share(f.ShareTypeEnum.SYSTEM)
                                            }, function () {
                                                f.default.instance.Share(f.ShareTypeEnum.SYSTEM)
                                            }), e(n)), Laya.Scene.open(v.default.Main), y.default.reportEvent(g.default.enter_game), [2]
                                    }
                                })
                            })
                        }, t.prototype.pullRemoteCnf = function () {
                            return a(this, void 0, void 0, function () {
                                return r(this, function (e) {
                                    return A.default.loadInsideAds(), A.default.loadStrategyShareInfo(), [2, new Promise(function (e, t) {
                                        A.default.loadMainConfig({
                                            success: function (t) {
                                                s.default.Log("拉取配置成功：", t), l.default.instance.checkNeedAuthList(), s.default.Log("拉到了" + l.default.instance.needAuth), e()
                                            },
                                            fail: function (t) {
                                                s.default.Log("拉取配置失败：", t), l.default.instance.checkNeedAuthList(), s.default.Log("拉到了" + l.default.instance.needAuth), e()
                                            }
                                        })
                                    })]
                                })
                            })
                        }, t.prototype.loadOther = function () {
                            return a(this, void 0, void 0, function () {
                                var e;
                                return r(this, function (t) {
                                    switch (t.label) {
                                        case 0:
                                            return t.trys.push([0, 12, , 13]), [4, c.default.instance.loadConfig()];
                                        case 1:
                                            return t.sent(), this.onLoading(.7), [4, this.loadFont("number_1")];
                                        case 2:
                                            return t.sent(), [4, this.loadFont("number_2")];
                                        case 3:
                                            return t.sent(), [4, this.loadFont("number_3")];
                                        case 4:
                                            return t.sent(), [4, this.loadFont("number_4")];
                                        case 5:
                                            return t.sent(), [4, this.loadFont("number_5")];
                                        case 6:
                                            return t.sent(), [4, this.loadSubpackage("sound", "sound/game.js")];
                                        case 7:
                                            return t.sent(), [4, this.loadSubpackage("tex", "res/atlas/tex/game.js")];
                                        case 8:
                                            return t.sent(), this.onLoading(.9), [4, d.default.instance.init()];
                                        case 9:
                                            return t.sent(), [4, d.default.instance.updateDataEveryDay()];
                                        case 10:
                                            return t.sent(), S.default.instance.loadClickedAdsList(), [4, w.default.instance.updateInviteNumber()];
                                        case 11:
                                            return t.sent(), this.onLoading(1), [3, 13];
                                        case 12:
                                            return e = t.sent(), console.e("加载出现错误: ", e), [3, 13];
                                        case 13:
                                            return [2]
                                    }
                                })
                            })
                        }, t.prototype.loadFont = function (e) {
                            return a(this, void 0, void 0, function () {
                                var t = this;
                                return r(this, function (n) {
                                    return [2, new Promise(function (n, i) {
                                        var o = new Laya.BitmapFont;
                                        o.loadFont("number/" + e + ".fnt", new Laya.Handler(t, function (t) {
                                            Laya.Text.registerBitmapFont(e, t), n()
                                        }, [o]))
                                    })]
                                })
                            })
                        }, t.prototype.loadSubpackage = function (e, t) {
                            return a(this, void 0, void 0, function () {
                                var n;
                                return r(this, function (i) {
                                    switch (i.label) {
                                        case 0:
                                            if (!A.default.loadSubpackage) return [2, !0];
                                            n = !1, i.label = 1;
                                        case 1:
                                            return n ? [3, 6] : [4, A.default.promisify(A.default.loadSubpackage, A.default, {
                                                name: e,
                                                gamejs: t
                                            }).then(function () {
                                                return !0
                                            }).catch(function () {
                                                return !1
                                            })];
                                        case 2:
                                            return (n = i.sent()) ? [3, 5] : [4, this.showModal("提示", "加载失败了, 请稍后重试!", "重试", !1)];
                                        case 3:
                                            return i.sent(), [4, new Promise(function (e) {
                                                return setTimeout(e, 500)
                                            })];
                                        case 4:
                                            i.sent(), i.label = 5;
                                        case 5:
                                            return [3, 1];
                                        case 6:
                                            return [2, !0]
                                    }
                                })
                            })
                        }, t.prototype.showModal = function (e, t, n, i, o) {
                            return void 0 === n && (n = "确定"), void 0 === i && (i = !0), void 0 === o && (o = "取消"), A.default.promisify(A.default.showModal, A.default, {
                                title: e,
                                content: t,
                                showCancel: i,
                                cancelText: o,
                                confirmText: n
                            }).then(function (e) {
                                return e.confirm
                            }).catch(function (e) {
                                return !1
                            })
                        }, t.prototype.onLoading = function (e, t) {
                            var n = this;
                            void 0 === t && (t = 1), 1 == t && console.log("当前进度：" + e), e < 1 ? A.default.setLoadingProgress && A.default.setLoadingProgress({
                                progress: Math.floor(100 * e)
                            }) : A.default.loadingComplete && A.default.loadingComplete({});
                            var i = e * t;
                            Laya.Tween.clearAll(this.progress), Laya.Tween.to(this.progress, {
                                value: i,
                                update: new Laya.Handler(this, function () {
                                    n.pika.x = Laya.stage.width * n.progress.value
                                })
                            }, 800)
                        }, t
                    }(u.ui.view.loadingUI);
                n.default = I
            }, {
                "../ads/AdsLogic": 5,
                "../common/EventID": 15,
                "../common/ReportEventID": 16,
                "../common/SceneID": 17,
                "../config/ConfigBus": 18,
                "../config/GameCnf": 19,
                "../core/GameHelper": 23,
                "../core/MyBanner": 25,
                "../core/ReportLogic": 26,
                "../core/RewardLogic": 27,
                "../core/Server": 28,
                "../core/ShareLogic": 29,
                "../data/DataBus": 32,
                "../logic/CollectLogic": 41,
                "../platform/yt": 63,
                "../snake_view/Avatar": 88,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            105: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../sound/SoundMgr"),
                    s = e("../sound/SoundID"),
                    l = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.hasModified = !1, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            this.btnMusic.selected = 1 != r.default.instance.setting.isMusicOn, this.btnSound.selected = 1 != r.default.instance.setting.isSoundOn, this.btnVibrate.selected = 1 != r.default.instance.setting.isVibrateOn
                        }, t.prototype.AddEvents = function () {
                            this.btnMusic.on(Laya.Event.CLICK, this, this.OnMusicBtnTap), this.btnSound.on(Laya.Event.CLICK, this, this.OnSoundBtnTap), this.btnVibrate.on(Laya.Event.CLICK, this, this.OnVibrateBtnTap), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtnTap)
                        }, t.prototype.OnMusicBtnTap = function () {
                            this.hasModified = !0, this.btnMusic.selected ? (this.btnMusic.selected = !1, r.default.instance.MusicOn()) : (this.btnMusic.selected = !0, r.default.instance.MusicOff()), r.default.instance.playSound(s.default.ButtonTap)
                        }, t.prototype.OnSoundBtnTap = function () {
                            this.hasModified = !0, this.btnSound.selected ? (this.btnSound.selected = !1, r.default.instance.SoundOn()) : (this.btnSound.selected = !0, r.default.instance.SoundOff()), r.default.instance.playSound(s.default.ButtonTap)
                        }, t.prototype.OnVibrateBtnTap = function () {
                            this.hasModified = !0, this.btnVibrate.selected ? (this.btnVibrate.selected = !1, r.default.instance.VibrateOn()) : (this.btnVibrate.selected = !0, r.default.instance.VibrateOff()), r.default.instance.playSound(s.default.ButtonTap)
                        }, t.prototype.OnCloseBtnTap = function () {
                            this.hasModified && (this.hasModified = !1, r.default.instance.SaveSettingData()), r.default.instance.playSound(s.default.ButtonTap), this.close()
                        }, t
                    }(a.ui.view.lobby_settingUI);
                n.default = l
            }, {
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            106: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("../core/ShareLogic"),
                    l = e("../ui/layaMaxUI"),
                    c = e("../logic/EconomicLogic"),
                    u = e("../common/EventID"),
                    d = e("../sound/SoundID"),
                    h = e("../sound/SoundMgr"),
                    f = e("../core/ReportLogic"),
                    p = e("../core/GameHelper"),
                    _ = e("../core/UserInfoBtn"),
                    y = (e("../logic/CollectLogic"), e("../core/RewardLogic")),
                    g = e("../logic/GameLogic"),
                    m = e("../common/SceneID"),
                    v = e("../config/ConfigBus"),
                    L = e("../logic/SkinLogic"),
                    w = e("../data/DataBus"),
                    b = e("../snake_view/Avatar"),
                    S = e("./ModelView"),
                    A = e("../config/GameCnf"),
                    I = e("../core/MyBanner"),
                    C = e("../merge/MergePnl"),
                    k = e("../logic/MergeLogic"),
                    M = e("./GuideView"),
                    E = e("../logic/GuideLogic"),
                    T = e("../logic/DialogLogic"),
                    D = e("../logic/LotteryLogic"),
                    O = e("../logic/BalloonLogic"),
                    P = e("../script/LoopMove"),
                    x = e("../ads/AdsLogic"),
                    B = e("../ads/MoreAds"),
                    R = e("../platform/yt"),
                    N = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            t._mergePnl = null, t._modelTween = null, t._pauseAutoProduct = !1, t._modelView = null, t.size(Laya.stage.width, Laya.stage.height), window.GuideView = M.default, R.default.reportMonitor && R.default.reportMonitor("game_scene", 0), t.height / t.width > 2 && (t.boxTop.y = 85), t._updateCollectArrow(), t._initMergePnl(), t.btnLottery.visible = D.default.instance.isValid(), t.setAllBtnsEnable(!0), p.default.addBannerStatus("lobby", !1);
                            parseFloat(R.default.conf.ads_btn_refresh_interval);
                            return t
                        }
                        return o(t, e), t.prototype.onAwake = function () {
                            var e = this;
                            1 == f.default.instance.needAuth && R.default.getSetting && R.default.getSetting({
                                success: function (t) {
                                    t.authSetting["scope.userInfo"] || e.createUserInfoBtn()
                                },
                                fail: function () {
                                    e.createUserInfoBtn()
                                },
                                complete: null
                            }), g.default.instance.CreateFeedback(this.btnFeedback), g.default.instance.CreateGameClub(this.btnClub), A.default.IsDebug && (this.btnTest.visible = !0, this.btnTest.on(Laya.Event.CLICK, this, function () {
                                T.default.instance.showDialogQueue(m.default.Test)
                            })), this.btnRank.visible = R.default.supportFriendRank || R.default.supportWorldRank, this.btnShare.visible = R.default.supportShare, this._updateLeftBtnsPos()
                        }, t.prototype.onOpened = function () {
							if(!window.IsFirst)
							{
								window.IsFirst=true;
								window.HUHU_gameLoadingCompleted();
							}
                            t.instance = this, this.OnCoinChanged(), c.default.instance.on(u.default.COIN_CHANGED, this, this.OnCoinChanged), this.OnDiamondChanged(), c.default.instance.on(u.default.DIAMOND_CHANGED, this, this.OnDiamondChanged), this._updateModelView(), Laya.stage.on(u.default.SKIN_CHANGED, this, this._updateModelView), this._onTicketsChanged(), Laya.stage.on(u.default.TICKETS_CHANGED, this, this._onTicketsChanged), this._updateFooterPos(), this._updateMergeLbl(), this.mergePnl.on(u.default.MERGED, this, this._onMerged), this.mergePnl.on(u.default.MERGE_CHANGED, this, this._onMergeChange), this.mergePnl.on(u.default.MERGE_DRAG_START, this, this._onMergeDragStart), this.mergePnl.on(u.default.MERGE_DRAG_END, this, this._onMergeDragEnd), this._updateQuickBoughtBtn(), Laya.stage.on(u.default.BOUGHT_TIMES_CHANGED, this, this._updateQuickBoughtBtn), Laya.stage.on(u.default.BALLOON_CHANGED, this, this._onBalloonChanged), O.default.instance.updateBalloon(), Laya.stage.on(u.default.INSIDE_ADS_CHANGED, this, this._onInsideAdsChanged), this._onInsideAdsChanged(), g.default.instance.startWxBtn && g.default.instance.startWxBtn.showWxBtn(), g.default.instance.ShowFeedback(), g.default.instance.CheckPopWin(), this.startProductSnake(t.autoProductProgress), Laya.timer.loop(1e3 * k.default.instance.getProductCoinsInterval(), this, this._profit), YYGGames.gameBox.visible = !0, h5splash.hideLoading(), YYGGames.audio.stopMusic(), YYGGames.audio.playMusic("sound/bgm1.mp3"), YYGGames.audio.pause = !!Laya.LocalStorage.getItem("Merge-Snake-Battle-MusicState") && "true" == Laya.LocalStorage.getItem("Merge-Snake-Battle-MusicState"), YYGGames.audio.pause ? this.soundBtn.skin = "tex/pure/sound-off.png" : this.soundBtn.skin = "tex/pure/sound-on.png", this.soundBtn.on(Laya.Event.CLICK, this, () => {
                                YYGGames.audio.pause = !YYGGames.audio.pause, YYGGames.audio.pause ? this.soundBtn.skin = "tex/pure/sound-off.png" : (this.soundBtn.skin = "tex/pure/sound-on.png", YYGGames.audio.stopMusic(), YYGGames.audio.playMusic("sound/bgm1.mp3")), Laya.LocalStorage.setItem("Merge-Snake-Battle-MusicState", YYGGames.audio.pause)
                            }), this.addCoins.on(Laya.Event.CLICK, this, () => {
                                YYGGames.showReward(() => {
                                    var e = k.default.instance.getCoinsLevel(),
                                        t = k.default.instance.getCoinsPrice(e);
                                    YYGGames.showTip("You got " + 5 * p.default.toAbb_2(t) + " coins."), c.default.instance.AddCoinWithAnimation(5 * p.default.toAbb_2(t))
                                })
                            })
                        }, t.prototype._onRemoved = function () {
                            c.default.instance.off(u.default.COIN_CHANGED, this, this.OnCoinChanged), c.default.instance.off(u.default.DIAMOND_CHANGED, this, this.OnDiamondChanged), Laya.stage.off(u.default.SKIN_CHANGED, this, this._updateModelView), Laya.stage.off(u.default.BANNER_CHANGED, this, this._onBannerChanged), Laya.stage.off(u.default.MY_BANNER_CHANGED, this, this._onBannerChanged), this.mergePnl.off(u.default.MERGED, this, this._onMerged), this.mergePnl.off(u.default.MERGE_CHANGED, this, this._onMergeChange), this.mergePnl.off(u.default.MERGE_DRAG_START, this, this._onMergeDragStart), this.mergePnl.off(u.default.MERGE_DRAG_END, this, this._onMergeDragEnd), Laya.stage.off(u.default.BOUGHT_TIMES_CHANGED, this, this._updateQuickBoughtBtn), Laya.stage.off(u.default.TICKETS_CHANGED, this, this._onTicketsChanged), g.default.instance.startWxBtn && g.default.instance.startWxBtn.hideWxBtn(), g.default.instance.HideFeedback(), g.default.instance.HideGameClub(), g.default.instance.isMenuOpen = !1, Laya.Tween.clearTween(this.leftPanel), this.leftPanel.x = -100, this.btnMenu.skin = "tex/lobby_btn_zhankai.png", w.default.instance.SaveDataToServer(), w.default.instance.SaveLocalData(), k.default.instance.mergePnl = null, Laya.timer.clearAll(this), this._modelTween && this._modelTween.clear(), this._modelTween = null, p.default.removeBannerStatus("lobby"), t.instance = null, e.prototype._onRemoved.call(this), YYGGames.gameBox.visible = !1
                        }, t.prototype.createUserInfoBtn = function () {
                            var e = this;
                            g.default.instance.startWxBtn = new _.default, g.default.instance.startWxBtn.createWxBtn(this.btnStart, function (t) {
                                g.default.instance.startWxBtn.setNormalMode(e.OnStartBtnTap), e.OnStartBtnTap(), f.default.instance.reportAppid(1), b.Avatar.setUserInfo(t.userInfo)
                            }, function () {
                                g.default.instance.startWxBtn.hideWxBtn()
                            })
                        }, t.prototype.setAllBtnsEnable = function (e) {
                            this.btnStart.off(Laya.Event.CLICK, this, this.OnStartBtnTap), this.btnShare.off(Laya.Event.CLICK, this, this.OnShareBtnTap), this.btnSetting.off(Laya.Event.CLICK, this, this.OnSettingBtnTap), this.btnRank.off(Laya.Event.CLICK, this, this.OnRankBtnTap), this.btnBuy.off(Laya.Event.CLICK, this, this.OnQuickBoughtBtnTap), this.btnSkin.off(Laya.Event.CLICK, this, this.OnSkinBtnTap), this.btnSign.off(Laya.Event.CLICK, this, this.OnSignBtnTap), this.btnShop.off(Laya.Event.CLICK, this, this.OnShopBtnTap), this.btnLottery.off(Laya.Event.CLICK, this, this.OnBtnLotteryTap), this.btnBalloon.off(Laya.Event.CLICK, this, this.OnBtnBalloonTap), this.btnMenu.off(Laya.Event.CLICK, this, this.OnBtnMenuTap), this.btnExit.off(Laya.Event.CLICK, this, this.OnBtnExitTap), e && (this.btnStart.on(Laya.Event.CLICK, this, this.OnStartBtnTap), this.btnShare.on(Laya.Event.CLICK, this, this.OnShareBtnTap), this.btnSetting.on(Laya.Event.CLICK, this, this.OnSettingBtnTap), this.btnRank.on(Laya.Event.CLICK, this, this.OnRankBtnTap), this.btnBuy.on(Laya.Event.CLICK, this, this.OnQuickBoughtBtnTap), this.btnSkin.on(Laya.Event.CLICK, this, this.OnSkinBtnTap), this.btnSign.on(Laya.Event.CLICK, this, this.OnSignBtnTap), this.btnShop.on(Laya.Event.CLICK, this, this.OnShopBtnTap), this.btnLottery.on(Laya.Event.CLICK, this, this.OnBtnLotteryTap), this.btnBalloon.on(Laya.Event.CLICK, this, this.OnBtnBalloonTap), this.btnMenu.on(Laya.Event.CLICK, this, this.OnBtnMenuTap), this.btnExit.on(Laya.Event.CLICK, this, this.OnBtnExitTap))
                        }, t.prototype._updateLeftBtnsPos = function () {}, t.prototype._updateFooterPos = function () {
                            var e = -this.btnSkin.centerY + .5 * Laya.stage.height - .5 * this.btnSkin.height;
                            this._footer.bottom = .5 * (e - this._footer.height * this._footer.scaleY)
                        }, t.prototype._onBannerChanged = function () {
                            if (R.default.isBannerVisible()) {
                                var e = R.default.getBannerHeight() / R.default.getSystemSize().height * Laya.stage.height + 30;
                                R.default.isIos() && R.default.isLongScreen() && (e += 65), this._footer.bottom = e
                            } else I.default.instance.isValid() ? this._footer.bottom = I.default.instance.getHeight() + 30 + 20 : this._updateFooterPos()
                        }, t.prototype.OnCoinChanged = function () {
                            var e = c.default.instance.coin,
                                t = p.default.toAbb(e);
                            this.lbGold.text != t && (this.lbGold.text = t, this._scaleAnimation(this._moneyBar))
                        }, t.prototype.OnDiamondChanged = function () {
                            var e = c.default.instance.diamond,
                                t = p.default.toAbb(e);
                            this.lblDiamond.text != t && (this.lblDiamond.text = t, this._scaleAnimation(this._diamondBar))
                        }, t.prototype._onTicketsChanged = function () {
                            this.ticketsLbl.text = "X" + w.default.instance.lotteryData.tickets
                        }, t.prototype.OnStartBtnTap = function () {
                            YYGGames.showInterstitial(() => {
                                YYGGames.gameBox.visible = !1, console.log("开始游戏"), this.startGame(), h.default.instance.playSound(d.default.ButtonTap), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                            })
                        }, t.prototype.startGame = function () {
                            y.default.instance.HasMotivate() && Math.random() < .01 * parseInt(R.default.conf.experience_rate) ? g.default.instance.PopExperienceDialog() : g.default.instance.EnterGame()
                        }, t.prototype.OnShareBtnTap = function () {
                            s.default.instance.Share(s.ShareTypeEnum.SHARE), h.default.instance.playSound(d.default.ButtonTap), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnSettingBtnTap = function () {
                            T.default.instance.showDialogQueue(m.default.Setting), h.default.instance.playSound(d.default.ButtonTap), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnRankBtnTap = function () {
                            T.default.instance.showDialogQueue(m.default.Rank), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnQuickBoughtBtnTap = function () {
                            h.default.instance.playSound(d.default.ButtonTap), k.default.instance.coinsBuyItem(k.default.instance.getQuickLevel(), !0), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnSkinBtnTap = function () {
                                h.default.instance.playSound(d.default.ButtonTap), T.default.instance.showDialogQueue(m.default.Skin), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnSignBtnTap = function () {
                            h.default.instance.playSound(d.default.ButtonTap), g.default.instance.isPopSignView = !1, T.default.instance.showDialogQueue(m.default.SignIn), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnShopBtnTap = function () {
                                h.default.instance.playSound(d.default.ButtonTap), T.default.instance.showDialogQueue(m.default.Shop), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnBtnLotteryTap = function () {
                            h.default.instance.playSound(d.default.ButtonTap), T.default.instance.showDialogQueue(m.default.Lottery), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnBtnBalloonTap = function () {
                            h.default.instance.playSound(d.default.ButtonTap), O.default.instance.showBalloonLayer(), this.btnBalloon.visible = !1;
                            var e = this.btnBalloon.getComponent(P.default);
                            e && e.stop(), this.setAllBtnsEnable(!1), Laya.timer.once(100, this, this.setAllBtnsEnable, [!0])
                        }, t.prototype.OnBtnMenuTap = function () {
                            var e = this;
                            g.default.instance.HideFeedback(), g.default.instance.HideGameClub(), Laya.Tween.clearTween(this.leftPanel), g.default.instance.isMenuOpen = !g.default.instance.isMenuOpen, g.default.instance.isMenuOpen ? Laya.Tween.to(this.leftPanel, {
                                x: 0
                            }, 300, null, Laya.Handler.create(this, function () {
                                e.btnMenu.skin = "tex/lobby_btn_zhankai2.png", g.default.instance.ShowGameClub()
                            })) : Laya.Tween.to(this.leftPanel, {
                                x: -100
                            }, 300, null, Laya.Handler.create(this, function () {
                                e.btnMenu.skin = "tex/lobby_btn_zhankai.png", g.default.instance.ShowFeedback()
                            }))
                        }, t.prototype.OnBtnMoreGameTap = function () {
                            T.default.instance.showDialog(m.default.ExitAds)
                        }, t.prototype.OnBtnExitTap = function () {
                            T.default.instance.showDialog(m.default.ExitAds, {
                                isExit: !0
                            })
                        }, t.prototype._onBalloonChanged = function () {
                            var e;
                            O.default.instance.needBalloon ? this.btnBalloon.visible || (this.btnBalloon.visible = !0, (e = this.btnBalloon.getComponent(P.default)) && e.play()) : (this.btnBalloon.visible = !1, (e = this.btnBalloon.getComponent(P.default)) && e.stop())
                        }, t.prototype._onInsideAdsChanged = function () {
                            var e = x.default.instance.isValid();
                            this.btnExit.visible = e
                        }, t.prototype._initModelView = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t, n, i, o, a, s, l, c, u;
                                return r(this, function (r) {
                                    switch (r.label) {
                                        case 0:
                                            return e = this._modelPnl.localToGlobal(new Laya.Point(0, 0)), t = e.x, n = e.y, i = this._modelPnl.localToGlobal(new Laya.Point(this._modelPnl.width, this._modelPnl.height)), o = i.x, a = i.y, s = o - t, l = a - n, c = new Laya.Rectangle(t, n, s, l), u = new S.default(c, 130, 6, 65), this._modelPnl.addChild(u), this._modelView = u, [4, u.setAnimator("res/model2/snake_anima_stay.lh", 0, new Laya.Vector3(0, -33, 10))];
                                        case 1:
                                            return r.sent(), this._rotateModel(u.root), [2]
                                    }
                                })
                            })
                        }, t.prototype._updateModelView = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t, n;
                                return r(this, function (i) {
                                    switch (i.label) {
                                        case 0:
                                            return this._modelView ? [3, 2] : [4, this._initModelView()];
                                        case 1:
                                            i.sent(), i.label = 2;
                                        case 2:
                                            return e = w.default.instance.skinData.useId1, t = S.default.createModelParam(e), this._modelView.setModel(t), n = v.default.instance.skins[e - 1], this._skinName.text = " " + n.name + " ", [2]
                                    }
                                })
                            })
                        }, t.prototype._rotateModel = function (e) {
                            e.transform.localRotationEulerY = 0, this._modelTween = Laya.Tween.to(e.transform, {
                                localRotationEulerY: 360
                            }, 3e4, null, Laya.Handler.create(this, this._rotateModel, [e]), 0, !0)
                        }, t.prototype._updateModelRatation = function (e) {}, t.prototype._updateCollectArrow = function () {}, t.prototype._scaleAnimation = function (e) {
                            Laya.Tween.clearAll(e), Laya.Tween.to(e, {
                                scaleX: 1.05,
                                scaleY: 1.05
                            }, 100, null, Laya.Handler.create(this, this.__scaleAnimationOver, [e]))
                        }, t.prototype.__scaleAnimationOver = function (e) {
                            Laya.Tween.to(e, {
                                scaleX: 1,
                                scaleY: 1
                            }, 100)
                        }, t.prototype._initMergePnl = function () {
                            this._mergePnl = this.mergePnl, k.default.instance.mergePnl = this._mergePnl, this._mergePnl.levelCount = k.default.instance.getLevelCount(), k.default.instance.loadDataToUi()
                        }, t.prototype.startProductSnake = function (e) {
                            if (void 0 === e && (e = 0), Laya.Tween.clearAll(this.progressReceive), k.default.instance.isFull()) return this.progressReceive.value = 0, void(this._pauseAutoProduct = !0);
                            this._pauseAutoProduct = !1;
                            var t = k.default.instance.getProductItemInterval();
                            this.progressReceive.value = e;
                            var n = Math.max(0, 1 - this.progressReceive.value) * t * 1e3;
                            Laya.Tween.to(this.progressReceive, {
                                value: 1
                            }, n)
                        }, t.prototype._updateQuickBoughtBtn = function () {
                            var e = k.default.instance.getCoinsLevel(),
                                t = e + 1,
                                n = v.default.instance.skins[t - 1];
                            this._buySkin.skin = L.default.instance.GetSkinPath(n.res);
                            var i = k.default.instance.getCoinsPrice(e);
                            this._buyPrice.text = p.default.toAbb(i)
                        }, t.prototype._profit = function () {
                            this._mergePnl.profit()
                        }, t.prototype._updateMergeLbl = function () {
                            var e = 60 / k.default.instance.getProductCoinsInterval(),
                                t = k.default.instance.getTotalProfit() * e,
                                n = p.default.toAbb(t) + "/min ";
                            this.lblProduct.text != n && (this.lblProduct.changeText(n), this._scaleAnimation(this.lblProduct))
                        }, t.prototype._onMerged = function (e) {
                            e > w.default.instance.mergeData.level && (k.default.instance.unlock(e), this._updateMergeLbl(), this._updateQuickBoughtBtn())
                        }, t.prototype._onMergeChange = function (e) {
                            k.default.instance.saveDataFromUi(), (e == C.MergeActionEnum.Remove || C.MergeActionEnum.Add) && (w.default.instance.SaveMergeData(), this._updateMergeLbl()), e == C.MergeActionEnum.Add && 0 == w.default.instance.gameData.mergeGuide && E.default.instance.check(), this._pauseAutoProduct && this.startProductSnake()
                        }, t.prototype._onMergeDragStart = function () {
                            this._hideFooterBtns()
                        }, t.prototype._onMergeDragEnd = function () {
                            this._showFooterBtns()
                        }, t.prototype._hideFooterBtns = function () {
                            Laya.Tween.clearAll(this._footerBtns), Laya.Tween.to(this._footerBtns, {
                                y: 760,
                                alpha: 0
                            }, 300, null, Laya.Handler.create(this, this.__hideFooterBtns), 0)
                        }, t.prototype.__hideFooterBtns = function () {
                            this._footerBtns.visible = !1
                        }, t.prototype._showFooterBtns = function () {
                            Laya.Tween.clearAll(this._footerBtns), this._footerBtns.visible = !0, Laya.Tween.to(this._footerBtns, {
                                y: 674,
                                alpha: 1
                            }, 300)
                        }, t.prototype.updateBtnAds = function () {}, t.prototype._onBtnAdsClick = function (e, t) {
                            void 0 === t && (t = null), h.default.instance.playSound(d.default.ButtonTap),
                                x.default.instance.showAds(e, "get_list_scan", "get_list", function () {}, function () {
                                    B.default.tryToShow()
                                }), t && (t.currentTarget.mouseEnabled = !1, Laya.timer.once(1e3, t.currentTarget, function () {
                                    this.mouseEnabled = !0
                                }))
                        }, t.autoProductProgress = 0, t.instance = null, t
                    }(l.ui.view.lobbyUI);
                n.default = N
            }, {
                "../ads/AdsLogic": 5,
                "../ads/MoreAds": 10,
                "../common/EventID": 15,
                "../common/SceneID": 17,
                "../config/ConfigBus": 18,
                "../config/GameCnf": 19,
                "../core/GameHelper": 23,
                "../core/MyBanner": 25,
                "../core/ReportLogic": 26,
                "../core/RewardLogic": 27,
                "../core/ShareLogic": 29,
                "../core/UserInfoBtn": 31,
                "../data/DataBus": 32,
                "../logic/BalloonLogic": 40,
                "../logic/CollectLogic": 41,
                "../logic/DialogLogic": 42,
                "../logic/EconomicLogic": 43,
                "../logic/GameLogic": 44,
                "../logic/GuideLogic": 45,
                "../logic/LotteryLogic": 46,
                "../logic/MergeLogic": 47,
                "../logic/SkinLogic": 48,
                "../merge/MergePnl": 52,
                "../platform/yt": 63,
                "../script/LoopMove": 66,
                "../snake_view/Avatar": 88,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./GuideView": 103,
                "./ModelView": 109
            }],
            107: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s, l, c = e("../ui/layaMaxUI"),
                    u = e("../logic/LotteryLogic"),
                    d = e("../logic/SkinLogic"),
                    h = e("../core/GameHelper"),
                    f = e("../sound/SoundMgr"),
                    p = e("../sound/SoundID"),
                    _ = e("../data/DataBus"),
                    y = e("./Toast"),
                    g = e("../core/RewardLogic"),
                    m = e("../core/ShareLogic"),
                    v = e("../common/EventID"),
                    L = e("../platform/yt"),
                    w = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._dataList = null, t._defaultData = null, t._rewardMethod = g.RewardMethodEnum.NONE, t._second = 0, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            _.default.instance.lotteryData.tickets > 20 && (_.default.instance.lotteryData.tickets = 20), this._loadDataList(), this._initUi(), this._enablePresentTickets(), this._playLightAnim(s.Idle), this._setAllBtnsEnabled(!0), this._onTicketsChanged(), Laya.stage.on(v.default.TICKETS_CHANGED, this, this._onTicketsChanged), h.default.addBannerStatus(this, !1)
                        }, t.prototype._onRemoved = function () {
                            Laya.timer.clear(this, this._playLightAnim), Laya.timer.clear(this, this._presentTickets), Laya.timer.clear(this, this._onCountDown), Laya.timer.clear(this, this._updateRewardMethod), Laya.stage.off(v.default.TICKETS_CHANGED, this, this._onTicketsChanged), L.default.off(L.default.Event.VideoAdLoaded, this._updateRewardMethod, this), h.default.removeBannerStatus(this), e.prototype._onRemoved.call(this)
                        }, t.prototype._loadDataList = function () {
                            this._dataList = u.default.instance.getPrizeList();
                            var e = this._dataList.slice(0);
                            e.sort(function (e, t) {
                                return 10 * (t.level - e.level) + (e.type - t.type)
                            }), this._defaultData = e[0]
                        }, t.prototype._initUi = function () {
                            this.wheel.numChildren != this._dataList.length && console.e("抽奖UI与数据数量不一致!");
                            for (var e = 0, t = this._dataList.length; e < t; ++e) {
                                var n = this._dataList[e],
                                    i = this.wheel.getChildAt((8 - e) % 8),
                                    o = i.getChildByName("icon"),
                                    a = i.getChildByName("lbl");
                                switch (n.type) {
                                    case u.LotteryPrizeType.Coins:
                                        o.skin = "tex/windows_icon_offlinegold.png", a.text = "+" + h.default.toAbb(n.value);
                                        break;
                                    case u.LotteryPrizeType.Diamonds:
                                        o.skin = "tex/windows_icon_offlinezuanshi.png", a.text = "+" + h.default.toAbb(n.value);
                                        break;
                                    case u.LotteryPrizeType.Snake:
                                        var r = n.value + 1,
                                            s = d.default.instance.GetSkinCnf(r);
                                        o.skin = d.default.instance.GetSkinPath(s.res), a.text = "+1"
                                }
                            }
                        }, t.prototype._rotateToIndex = function (e) {
                            return a(this, void 0, void 0, function () {
                                var t, n, i, o, a;
                                return r(this, function (r) {
                                    switch (r.label) {
                                        case 0:
                                            return t = this.wheel.rotation = this.wheel.rotation % 360, i = 500, a = ((n = 1080 + 45 * e) - t) / (1e3 + (o = 3e3)) * 1e3 + t, [4, this.__rotateToAngle(this.wheel, a, 1e3, Laya.Ease.quintIn)];
                                        case 1:
                                            return r.sent(), this.wheel.rotation = a - 720, [4, this.__rotateToAngle(this.wheel, a, i)];
                                        case 2:
                                            return r.sent(), [4, this.__rotateToAngle(this.wheel, n, o, Laya.Ease.quintOut)];
                                        case 3:
                                            return r.sent(), [2]
                                    }
                                })
                            })
                        }, t.prototype.__rotateToAngle = function (e, t, n, i) {
                            var o = this;
                            return new Promise(function (a) {
                                Laya.Tween.clearAll(e), Laya.Tween.to(e, {
                                    rotation: t
                                }, n, i, new Laya.Handler(o, a))
                            })
                        }, t.prototype._playLightAnim = function (e) {
                            switch (Laya.timer.clear(this, this._playLightAnim), this.idleAnim.stop(), this.runningAnim.stop(), this.bingoAnim.stop(), e) {
                                case s.Idle:
                                    this.idleAnim.play(0, !0);
                                    break;
                                case s.Running:
                                    this.runningAnim.play(0, !0);
                                    break;
                                case s.Bingo:
                                    this.bingoAnim.play(0, !0), Laya.timer.once(2e3, this, this._playLightAnim, [s.Idle])
                            }
                        }, t.prototype._onTicketsChanged = function () {
                            this.lblTickets.text = "X" + _.default.instance.lotteryData.tickets, this.lblGetTickets.text = "X" + _.default.instance.lotteryData.get_tickets
                        }, t.prototype._enablePresentTickets = function () {
                            if (u.default.instance.canGetTickets()) {
                                var e = _.default.instance.lotteryData.next_time - Date.now();
                                e > 0 ? (Laya.timer.clear(this, this._presentTickets), Laya.timer.once(e + 500, this, this._presentTickets), this._stopCountDown(), this._beginCountDown(e)) : this._presentTickets()
                            } else this._stopPresentTickets();
                            Laya.timer.callLater(this, this._updateRewardMethod)
                        }, t.prototype._presentTickets = function () {
                            u.default.instance.canGetTickets() ? (u.default.instance.presentTickets(), this._enablePresentTickets()) : this._stopPresentTickets(), Laya.timer.callLater(this, this._updateRewardMethod)
                        }, t.prototype._stopPresentTickets = function () {
                            this.lblCountDown.text = "00:00", this._stopCountDown(), Laya.timer.clear(this, this._presentTickets)
                        }, t.prototype._beginCountDown = function (e) {
                            this._second = Math.floor(e / 1e3), this.lblCountDown.text = h.default.TransSeconds(this._second), Laya.timer.loop(1e3, this, this._onCountDown)
                        }, t.prototype._onCountDown = function () {
                            this._second -= 1, this._second <= 0 && (this._second = 0, this._stopCountDown()), this.lblCountDown.text = h.default.TransSeconds(this._second)
                        }, t.prototype._stopCountDown = function () {
                            Laya.timer.clear(this, this._onCountDown)
                        }, t.prototype._lottery = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t, n;
                                return r(this, function (i) {
                                    switch (i.label) {
                                        case 0:
                                            return this._setAllBtnsEnabled(!1), _.default.instance.lotteryData.tickets <= 0 ? (y.default.show('"You dont "have enough raffle tickets!'), Laya.timer.once(100, this, this._setAllBtnsEnabled, [!0]), [2]) : (_.default.instance.lotteryData.tickets -= 1, _.default.instance.SaveLotteryData(), this._enablePresentTickets(), e = u.default.instance.lottery(), t = this._dataList.findIndex(function (t) {
                                                return t.type == e.type && t.level == e.level
                                            }), n = this._dataList[t] || this._defaultData, t = n.index, this._playLightAnim(s.Running), [4, this._rotateToIndex(t)]);
                                        case 1:
                                            return i.sent(), this._playLightAnim(s.Bingo), u.default.instance.receive(n), this._setAllBtnsEnabled(!0), [2]
                                    }
                                })
                            })
                        }, t.prototype._updateRewardMethod = function () {
                            console.log("更新激励类型"), Laya.timer.clear(this, this._updateRewardMethod), L.default.off(L.default.Event.VideoAdLoaded, this._updateRewardMethod, this);
                            var e = g.default.instance.ShareOrVideo(m.ShareTypeEnum.LOTTERY);
                            this._rewardMethod = e, e == g.RewardMethodEnum.VIDEO ? (this.btnTxt.centerX = 25, this.btnIco.visible = !0) : (this.btnTxt.centerX = 0, this.btnIco.visible = !1)
                        }, t.prototype._updateRewardMethodAfterVideo = function () {
                            Laya.timer.once(2e3, this, this._updateRewardMethod), L.default.once(L.default.Event.VideoAdLoaded, this._updateRewardMethod, this)
                        }, t.prototype._setAllBtnsEnabled = function (e) {
                            this.btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), this.btnLottery.off(Laya.Event.CLICK, this, this._onBtnLotteryClick), this.btnGetTickets.off(Laya.Event.CLICK, this, this._onBtnTicketsClick), e && (this.btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick), this.btnLottery.on(Laya.Event.CLICK, this, this._onBtnLotteryClick), this.btnGetTickets.on(Laya.Event.CLICK, this, this._onBtnTicketsClick))
                        }, t.prototype._onBtnLotteryClick = function () {
                            f.default.instance.playSound(p.default.ButtonTap), this._lottery()
                        }, t.prototype._onBtnTicketsClick = function () {
                            var e = this;
                            if (f.default.instance.playSound(p.default.ButtonTap), this._setAllBtnsEnabled(!1), Laya.timer.once(100, this, this._setAllBtnsEnabled, [!0]), this._rewardMethod == g.RewardMethodEnum.NONE && this._updateRewardMethod(), _.default.instance.lotteryData.get_tickets >= 10) y.default.show("You have already collected 10 times today, please come back tomorrow!");
                            else if (_.default.instance.lotteryData.tickets >= 10) y.default.show("The number of raffle tickets has exceeded 10, please use them first!");
                            else {
                                var t = function () {
                                        e._presentTickets(), e._enablePresentTickets()
                                    },
                                    n = function () {
                                        e._updateRewardMethodAfterVideo()
                                    };
                                switch (this._rewardMethod) {
                                    case g.RewardMethodEnum.SHARE:
                                        g.default.instance.ShareReward(m.ShareTypeEnum.LOTTERY, t, n);
                                        break;
                                    case g.RewardMethodEnum.VIDEO:
                                        g.default.instance.VideoReward(!1, t, n);
                                        break;
                                    default:
                                        y.default.show("视频尚未加载好!")
                                }
                            }
                        }, t.prototype._onBtnCloseClick = function () {
                            f.default.instance.playSound(p.default.ButtonTap), this.removeSelf()
                        }, t
                    }(c.ui.view.zhuanpanUI);
                n.default = w, l = s || (s = {}), l[l.Idle = 0] = "Idle", l[l.Running = 1] = "Running", l[l.Bingo = 2] = "Bingo"
            }, {
                "../common/EventID": 15,
                "../core/GameHelper": 23,
                "../core/RewardLogic": 27,
                "../core/ShareLogic": 29,
                "../data/DataBus": 32,
                "../logic/LotteryLogic": 46,
                "../logic/SkinLogic": 48,
                "../platform/yt": 63,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./Toast": 121
            }],
            108: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../sound/SoundID"),
                    s = e("../snake_view/Avatar"),
                    l = e("../snake/S2Macro"),
                    c = e("../sound/SoundMgr"),
                    u = e("../script/NearBanner"),
                    d = e("../core/ShareLogic"),
                    h = e("../core/MathUtil"),
                    f = e("../core/Server"),
                    p = e("../common/ReportEventID"),
                    _ = e("../platform/yt"),
                    y = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._isTimeStop = !1, t._isWaitFriend = !1, t.joinTimes = [], t._adsPnl = null, t._ticktime = 0, t._times = 10, t._inviteTimes = 3, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t.AddEvents(), t._adsPnl = t.adsPnl, t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtnTap), this._timesLbl.changeText(this._times.toString()), Laya.timer.loop(100, this, this._ticktok)
                        }, t.prototype.onOpened = function (e) {
                            this._onNext = e.onNext, this._match(), this.btnClose.getComponent(u.default) || this.btnClose.addComponent(u.default)
                        }, t.prototype._onRemoved = function () {
                            Laya.timer.clearAll(this), e.prototype._onRemoved.call(this)
                        }, t.prototype._ticktok = function () {
                            var e = this;
                            if (!this._isTimeStop) {
                                this._ticktime += .1, this._isWaitFriend ? (this._inviteTimes -= .1, this._inviteTimes < 0 && (this.inviteTip.visible = !1, this._isWaitFriend = !1), this._inviteTimesLbl.changeText(this._inviteTimes.toFixed(0))) : (this._times -= .1, this._times < 0 && (this._times = 0, Laya.timer.clear(this, this._ticktok)), this._timesLbl.changeText(this._times.toFixed(0)));
                                for (var t = function (t) {
                                        if (0 == t && n._isWaitFriend) return "break";
                                        if (1e3 * n._ticktime > n.joinTimes[t].time) {
                                            var i = n.joinTimes.splice(t, 1)[0],
                                                o = n._list.array.filter(function (e) {
                                                    return e.index == i.index
                                                })[0],
                                                a = _.default.getSystemInfoSync();
                                            o.data.avatarUrl && a && "devtools" != a.platform && (o.avatar = o.data.avatarUrl, n._list.array = n._list.array), Laya.timer.once(200, n, function () {
                                                e._progressLbl.changeText(l.s2Macro.player_number - e.joinTimes.length + "/" + l.s2Macro.player_number)
                                            }), 0 == n.joinTimes.length && Laya.timer.once(500, n, n.success, [n.avatarList])
                                        }
                                    }, n = this, i = this.joinTimes.length - 1; i >= 0 && "break" !== t(i); --i);
                            }
                        }, t.prototype._match = function () {
                            var e = this;
                            this.inviteTip.visible = !1;
                            var t = l.s2Macro.player_number,
                                n = s.Avatar.getRandomList(t),
                                i = [];
                            n.forEach(function (e, t) {
                                i.push({
                                    avatar: "tex/common_player_snake.png",
                                    data: e,
                                    index: t
                                })
                            }), this.avatarList = n, this._shuffle(i), this._list.array = i, this.joinTimes.length = 0, i.forEach(function (t) {
                                var n = 400 * t.index + 150 * Math.random();
                                e.joinTimes.push({
                                    index: t.index,
                                    time: n
                                })
                            })
                        }, t.prototype.success = function (e) {
                            this._onNext && this._onNext(e), this.destroy()
                        }, t.prototype.cancel = function () {
                            this.destroy()
                        }, t.prototype.OnCloseBtnTap = function () {
                            YYGGames.showInterstitial(() => {
                                YYGGames.gameBox.visible = !0, c.default.instance.playSound(r.default.ButtonTap), this.cancel()
                            })
                        }, t.prototype.OnInviteBtnTap = function () {
                            var e = this;
                            c.default.instance.playSound(r.default.ButtonTap), this.btnClose.mouseEnabled = !1, this._isTimeStop = !0, d.default.instance.Share(d.ShareTypeEnum.MATCH, null, function () {
                                e.inviteTip.visible = !0, e._inviteTimesLbl.changeText(e._inviteTimes.toString()), e._isWaitFriend = !0;
                                for (var t = e.joinTimes.length - 1; t >= 0; --t) e.joinTimes[t].time += 0 == t ? 3e3 + h.default.RandomInt(1e3, 2e3) : h.default.RandomInt(1e3, 2e3);
                                e._isTimeStop = !1, e.btnClose.mouseEnabled = !0, f.default.reportEvent(p.default.invite_friend)
                            }, function () {
                                _.default.showToast("分享失败！"), e._isTimeStop = !1, e.btnClose.mouseEnabled = !0, f.default.reportEvent(p.default.invite_friend)
                            })
                        }, t.prototype._shuffle = function (e) {
                            for (var t, n, i = e.length; 0 !== i;) n = Math.floor(Math.random() * i), t = e[i -= 1], e[i] = e[n], e[n] = t;
                            return e
                        }, t
                    }(a.ui.view.lobby_match_10UI);
                n.default = y
            }, {
                "../common/ReportEventID": 16,
                "../core/MathUtil": 24,
                "../core/Server": 28,
                "../core/ShareLogic": 29,
                "../platform/yt": 63,
                "../script/NearBanner": 69,
                "../snake/S2Macro": 75,
                "../snake_view/Avatar": 88,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            109: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("../model/ModelLoader"),
                    l = e("../config/ConfigBus"),
                    c = function (e) {
                        function t(t, n, i, o) {
                            void 0 === o && (o = 60);
                            var a = e.call(this) || this;
                            return a.root = null, a.animatorNode = null, a.modelList = [], a._animatorUrl = "", a.root = a.addChild(new Laya.Sprite3D("root")), a._createCamera(t, n, i, o), a._createLight(), a.mouseEnabled = !1, a
                        }
                        return o(t, e), t.createModelParam = function (e) {
                            var t = "unknown",
                                n = l.default.instance.skins[e - 1];
                            return n && n.res && (t = n.res), [{
                                avatar: "model_1",
                                url: "res/model/" + t + "t.lh"
                            }, {
                                avatar: "model_2",
                                url: "res/model/" + t + "s.lh"
                            }, {
                                avatar: "model_3",
                                url: "res/model/" + t + "s.lh"
                            }]
                        }, t.prototype._createCamera = function (e, t, n, i) {
                            var o = new Laya.Camera(0, .1, 2e3);
                            this._convertStageRectToClientRect(e), o.viewport = new Laya.Viewport(e.x, e.y, e.width, e.height), o.clearFlag = Laya.BaseCamera.CLEARFLAG_DEPTHONLY, o.fieldOfView = i;
                            var a = n / 180 * Math.PI;
                            o.transform.translate(new Laya.Vector3(0, t * Math.sin(a), t * Math.cos(a))), o.transform.lookAt(new Laya.Vector3(0, 0, 0), new Laya.Vector3(0, 1, 0)), this.addChild(o)
                        }, t.prototype._createLight = function () {
                            var e = this.addChild(new Laya.DirectionLight);
                            e.color = new Laya.Vector3(1, 1, 1), e.intensity = .8;
                            var t = e.transform.worldMatrix;
                            t.setForward(new Laya.Vector3(.5, 1, -.5)), e.transform.worldMatrix = t, this.ambientColor = new Laya.Vector3(.6, .6, .6)
                        }, t.prototype._convertStageRectToClientRect = function (e) {
                            var t = Laya.RenderContext3D.clientWidth / Laya.stage.width,
                                n = Laya.RenderContext3D.clientHeight / Laya.stage.height;
                            return e.x *= t, e.y *= n, e.width *= t, e.height *= n, e
                        }, t.prototype._onRemoved = function () {
                            this.animatorNode && this._removeAnimator(this.animatorNode), this.animatorNode = null, this.modelList.length = 0, this._animatorUrl = "", e.prototype._onRemoved.call(this)
                        }, t.prototype.setAnimator = function (e, t, n) {
                            return void 0 === t && (t = 0), void 0 === n && (n = new Laya.Vector3(0, 0, 0)), a(this, void 0, void 0, function () {
                                var i, o;
                                return r(this, function (a) {
                                    switch (a.label) {
                                        case 0:
                                            return this._animatorUrl = e, [4, s.ModelLoader.instance.getOriginModel(e)];
                                        case 1:
                                            return i = a.sent(), this._animatorUrl == e && (o = this._findAnimatorComponent(i), i.__animator__ = o, this.animatorNode && this._removeAnimator(this.animatorNode), i.transform.position = n, i.transform.localRotationEuler = new Laya.Vector3(0, t, 0), this.root.addChild(i), this.animatorNode = i), [2]
                                    }
                                })
                            })
                        }, t.prototype.setModel = function (e) {
                            return a(this, void 0, void 0, function () {
                                var t = this;
                                return r(this, function (n) {
                                    return this.animatorNode && this._clearAnimator(this.animatorNode), this.modelList = e, this.modelList.forEach(function (e, n) {
                                        t._loadModel(e.url, n)
                                    }), [2]
                                })
                            })
                        }, t.prototype._removeAnimator = function (e) {
                            this._clearAnimator(e), s.ModelLoader.instance.removeOriginModel(e)
                        }, t.prototype._clearAnimator = function (e) {
                            for (var t = e.__animator__, n = t.owner, i = n.numChildren - 1; i >= 0; --i) {
                                var o = n.getChildAt(i);
                                t && t.unLinkSprite3DToAvatarNode(o), s.ModelLoader.instance.removeOriginModel(o)
                            }
                        }, t.prototype._loadModel = function (e, t) {
                            return a(this, void 0, void 0, function () {
                                var n, i;
                                return r(this, function (o) {
                                    switch (o.label) {
                                        case 0:
                                            return [4, s.ModelLoader.instance.getOriginModel(e)];
                                        case 1:
                                            return (n = o.sent())._children[0].transform.localScale = new Laya.Vector3(1, 1, 1), i = this.modelList[t], this.animatorNode && i && i.url == e && this._mountModel(this.animatorNode, i, n), [2]
                                    }
                                })
                            })
                        }, t.prototype._mountModel = function (e, t, n) {
                            var i = e.__animator__;
                            i && (t.model && (i.unLinkSprite3DToAvatarNode(t.model), t.model != n && s.ModelLoader.instance.removeOriginModel(t.model)), t.model = n, i.owner.addChild(n), i.linkSprite3DToAvatarNode(t.avatar, n))
                        }, t.prototype._findAnimatorComponent = function (e) {
                            for (var t = [e]; t.length > 0;) {
                                var n = t.shift(),
                                    i = n.getComponent(Laya.Animator);
                                if (i) return i;
                                for (var o = 0, a = n.numChildren; o < a; ++o) {
                                    var r = n.getChildAt(o);
                                    t.push(r)
                                }
                            }
                            return null
                        }, t
                    }(Laya.Scene3D);
                n.default = c
            }, {
                "../config/ConfigBus": 18,
                "../model/ModelLoader": 54
            }],
            110: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("../ui/layaMaxUI"),
                    l = e("../core/Server"),
                    c = e("../core/GameHelper"),
                    u = e("../core/UserInfoBtn"),
                    d = e("../sound/SoundID"),
                    h = e("../core/ShareLogic"),
                    f = e("../snake_view/Avatar"),
                    p = e("../logic/EconomicLogic"),
                    _ = e("./Toast"),
                    y = e("../sound/SoundMgr"),
                    g = e("../platform/yt"),
                    m = function (e) {
                        function t() {
                            var n = e.call(this) || this;
                            return t._instance = n, n.size(Laya.stage.width, Laya.stage.height), n.bg.size(Laya.stage.width, Laya.stage.height), n.AddEvents(), n.scrollList.vScrollBarSkin = " ", n.btnFriendRank.visible = g.default.supportFriendRank && g.default.supportWorldRank, n.btnWorldRank.visible = g.default.supportFriendRank && g.default.supportWorldRank, n
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            var e = this;
                            Laya.timer.once(50, this, function () {
                                e.ShowFriendRank(), g.default.supportWorldRank && (e.worldWxBtn ? e.worldWxBtn.showWxBtn() : (e.worldWxBtn = new u.default, e.worldWxBtn.createWxBtn(e.btnWorldRank, function (t) {
                                    e.worldWxBtn.setNormalMode(e.WorldRankBtnSuccess), e.WorldRankBtnSuccess(), f.Avatar.setUserInfo(t.userInfo)
                                }, e.WorldRankBtnFail))), e.isWorldRefresh = !1
                            })
                        }, t.prototype._onRemoved = function () {
                            this.worldWxBtn && this.worldWxBtn.hideWxBtn(), this.CloseFriendRank(), Laya.timer.clearAll(this), e.prototype._onRemoved.call(this)
                        }, t.prototype.AddEvents = function () {
                            this.btnFriendRank.on(Laya.Event.CLICK, this, this.OnFriendRankTap), this.btnWorldRank.on(Laya.Event.CLICK, this, this.OnWorldRankTap), this.btnFlaunt.on(Laya.Event.CLICK, this, this.OnFlauntBtnTap), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtnTap)
                        }, t.prototype.OnFriendRankTap = function () {
                            y.default.instance.playSound(d.default.ButtonTap), this.ShowFriendRank()
                        }, t.prototype.ShowFriendRank = function () {
                            this.SwitchRank(), this.openDataView.active = !0;
                            var e = this.openDataView.localToGlobal(new Laya.Point(0, 0)),
                                t = {
                                    msg: "rank",
                                    action: "show",
                                    resolution: [e.x, e.y, Laya.stage.width, Laya.stage.height],
                                    startUpdate: !0,
                                    pageMode: !1,
                                    key: "score"
                                };
                            this.openDataView.postMsg(t)
                        }, t.prototype.CloseFriendRank = function () {
                            this.openDataView.postMsg({
                                msg: "closeAll",
                                pauseUpdate: !0
                            }), this.openDataView.active = !1
                        }, t.prototype.HideFriendRank = function () {
                            this.openDataView.postMsg({
                                msg: "hideAll",
                                pauseUpdate: !0
                            }), this.openDataView.active = !1
                        }, t.prototype.SwitchRank = function (e) {
                            void 0 === e && (e = !1), this.btnFriendRank.selected = e, this.btnFriendRank.mouseEnabled = e, this.btnWorldRank.selected = !e, this.btnWorldRank.mouseEnabled = !e, this.openDataView.visible = !e, this.myRank.visible = e, this.scrollList.visible = e, e && this.HideFriendRank()
                        }, t.prototype.OnWorldRankTap = function () {
                            this.worldWxBtn.normalCallback ? this.worldWxBtn.normalCallback() : this.worldWxBtn._wxBtn && this.worldWxBtn.onNormalTap(this.WorldRankBtnSuccess, this.WorldRankBtnFail)
                        }, t.prototype.WorldRankBtnSuccess = function () {
                            if (t._instance.isWorldRefresh) t._instance.SwitchRank(!0);
                            else {
                                g.default.showLoading({
                                    title: "Loading...",
                                    mask: !0
                                });
                                var e = p.default.instance.tcoin,
                                    n = c.default.getAbb(e),
                                    i = n.score,
                                    o = n.unit,
                                    a = n.fmt;
                                l.default.submitLeaderboardUnit(i, o, a, null, function (e) {
                                    l.default.getLeaderboardUnit(function (e) {
                                        if (!(e && e.data && e.data.data && Array.isArray(e.data.data.list))) return c.default.Log("世界榜数据不正确：", e), g.default.hideLoading(), void _.default.show("获取世界榜失败了！");
                                        g.default.hideLoading(), t._instance.isWorldRefresh = !0, t._instance.SwitchWorldRank(e.data.data)
                                    }, function (e) {
                                        c.default.Log("排行榜加载失败", e), g.default.hideLoading(), _.default.show("排行榜获取失败")
                                    })
                                }, function () {
                                    g.default.hideLoading(), _.default.show("提交成绩到世界榜失败！")
                                })
                            }
                            y.default.instance.playSound(d.default.ButtonTap)
                        }, t.prototype.SwitchWorldRank = function (e) {
                            c.default.Log("获取到的排行榜数据：", e), this.SwitchRank(!0), this.InitItems(e)
                        }, t.prototype.InitItems = function (e) {
                            return a(this, void 0, void 0, function () {
                                var t, n, i, o, a, s, l;
                                return r(this, function (r) {
                                    for (this.scrollList.scrollTo(0), t = [], n = 0; n < e.list.length; ++n) i = e.list[n], o = parseInt(i.rank), a = {
                                        rk_avatar: {
                                            skin: i.avatar
                                        },
                                        rk_name: {
                                            text: i.name
                                        },
                                        rk_rank: {
                                            text: i.rank,
                                            visible: o < 1 || o > 3
                                        },
                                        rk_rankBg: {
                                            skin: "tex/windows_icon_rank" + (o >= 1 && o <= 3 ? o : 4) + ".png"
                                        },
                                        rk_score: {
                                            text: i.score + c.default.getAbbFmt(i.unit)
                                        }
                                    }, t.push(a);
                                    return this.scrollList.dataSource = t, this.scrollList.renderHandler = new Laya.Handler(this, this._onScrollListRender), s = parseInt(e.mine.rank), this.myRank.dataSource = {
                                        rk_avatar: {
                                            skin: e.mine.avatar
                                        },
                                        rk_name: {
                                            text: e.mine.name
                                        },
                                        rk_rank: {
                                            text: e.mine.rank,
                                            visible: s < 1 || s > 3
                                        },
                                        rk_rankBg: {
                                            skin: "tex/windows_icon_rank" + (s >= 1 && s <= 3 ? s : 4) + ".png"
                                        },
                                        rk_score: {
                                            text: e.mine.score + c.default.getAbbFmt(e.mine.unit)
                                        }
                                    }, l = this.myRank.getChildByName("rk_name"), this.__updateLblSize(l, 160, 1), [2]
                                })
                            })
                        }, t.prototype._onScrollListRender = function (e, t) {
                            var n = e.getChildByName("rk_name");
                            this.__updateLblSize(n, 180, 1)
                        }, t.prototype.__updateLblSize = function (e, t, n) {
                            if (void 0 === n && (n = .4), e.width > 0) {
                                var i = Math.min(n, t / e.width);
                                e.scale(i, i, !0)
                            }
                        }, t.prototype.WorldRankBtnFail = function (e) {
                            _.default.show("需要用户授权才能查看世界榜哦！")
                        }, t.prototype.OnCloseBtnTap = function () {
                            this.removeSelf(), y.default.instance.playSound(d.default.ButtonTap)
                        }, t.prototype.OnFlauntBtnTap = function () {
                            h.default.instance.Share(h.ShareTypeEnum.RANK), y.default.instance.playSound(d.default.ButtonTap)
                        }, t
                    }(s.ui.view.lobby_rankUI);
                n.default = m
            }, {
                "../core/GameHelper": 23,
                "../core/Server": 28,
                "../core/ShareLogic": 29,
                "../core/UserInfoBtn": 31,
                "../logic/EconomicLogic": 43,
                "../platform/yt": 63,
                "../snake_view/Avatar": 88,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./Toast": 121
            }],
            111: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/RewardLogic"),
                    s = e("../core/ShareLogic"),
                    l = e("../logic/EconomicLogic"),
                    c = e("../sound/SoundID"),
                    u = e("../core/Server"),
                    d = e("../common/ReportEventID"),
                    h = e("../ads/InsideAds"),
                    f = e("../core/GameHelper"),
                    p = e("./Toast"),
                    _ = e("../sound/SoundMgr"),
                    y = e("../platform/yt"),
                    g = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._onRevive = null, t._times = 6, t._curTimes = 6, t._price = 100, t._type = r.RewardMethodEnum.NONE, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t._dialog.y = .45 * Laya.stage.height, t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this.gemein_relive.on(Laya.Event.LABEL, this, this._onTickTock), this._setBtnsEnabled(!0)
                        }, t.prototype.onOpened = function (e) {
                            u.default.reportEvent(d.default.pop_revive), this._onRevive = e.onRevive, this._times = this._curTimes = parseInt(y.default.conf.revive_countdown) || 10, this._price = parseInt(y.default.conf.revive_price) || 10, this._countDown.changeText(this._curTimes.toFixed()), this._priceLbl.changeText(this._price.toFixed()), this._updateReviveMethod(e.forceCoins), f.default.addBannerStatus(this, !0)
                        }, t.prototype._onRemoved = function () {
                            f.default.removeBannerStatus(this), h.default.instance.hide(), e.prototype._onRemoved.call(this)
                        }, t.prototype._onTickTock = function (e) {
                            this._curTimes < 0 ? this._fail() : this._countDown.changeText(this._curTimes.toFixed()), this._curTimes -= 1
                        }, t.prototype._updateReviveMethod = function (e) {
                            var t = e ? r.RewardMethodEnum.NONE : r.default.instance.ShareOrVideo(s.ShareTypeEnum.REVIVE);
                            this._type = t;
                            var n = 1 != parseInt(y.default.conf.revive_hide_closebtn);
                            switch (this._coinsPnl.visible = !1, this._sharePnl.visible = !1, this._videoPnl.visible = !1, t) {
                                case r.RewardMethodEnum.NONE:
                                    this._coinsPnl.visible = !0, this._btnClose.visible = !0;
                                    break;
                                case r.RewardMethodEnum.SHARE:
                                    this._sharePnl.visible = !0, this._btnClose.visible = n;
                                    break;
                                case r.RewardMethodEnum.VIDEO:
                                    this._videoPnl.visible = !0, this._btnClose.visible = n
                            }
                        }, t.prototype._coinsRevive = function () {
                            l.default.instance.coin.gte(this._price) ? (l.default.instance.SubCoin(this._price), l.default.instance.SaveCoin(), this._success()) : (p.default.show("Not enough coins!"), this._continue())
                        }, t.prototype._diamondsRevive = function () {
                            l.default.instance.diamond.gte(this._price) ? (l.default.instance.SubDiamond(this._price), l.default.instance.SaveDiamond(), this._success()) : (p.default.show("Not enough diamonds!"), this._continue())
                        }, t.prototype._shareRevive = function () {
                            var e = this;
                            r.default.instance.ShareReward(s.ShareTypeEnum.REVIVE, function () {
                                u.default.reportEvent(d.default.share_revive), e._success()
                            }, function () {
                                e._continue()
                            })
                        }, t.prototype._videoRevive = function () {
                            var e = this;
                            YYGGames.showReward(() => {
                                r.default.instance.VideoReward(!0, function () {
                                    u.default.reportEvent(d.default.video_revive), e._success()
                                }, function () {
                                    e._continue()
                                })
                            })
                        }, t.prototype._success = function () {
                            this.gemein_relive.stop(), this._onRevive && this._onRevive(!0), this.removeSelf()
                        }, t.prototype._fail = function () {
                            this.gemein_relive.stop(), this._onRevive && this._onRevive(!1), this.removeSelf()
                        }, t.prototype._continue = function () {
                            this.gemein_relive.play()
                        }, t.prototype._setBtnsEnabled = function (e) {
                            void 0 === e && (e = !0), this._btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnRevive.off(Laya.Event.CLICK, this, this._onBtnReviveClick), e && (this._btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick),
                                this._btnRevive.on(Laya.Event.CLICK, this, this._onBtnReviveClick))
                        }, t.prototype._onBtnReviveClick = function () {
                            switch (u.default.reportEvent(d.default.click_revive), _.default.instance.playSound(c.default.ButtonTap), this.gemein_relive.stop(), this._setBtnsEnabled(!1), this._type) {
                                case r.RewardMethodEnum.NONE:
                                    this._diamondsRevive();
                                    break;
                                case r.RewardMethodEnum.SHARE:
                                    this._shareRevive();
                                    break;
                                case r.RewardMethodEnum.VIDEO:
                                    this._videoRevive()
                            }
                            Laya.timer.once(200, this, this._setBtnsEnabled)
                        }, t.prototype._onBtnCloseClick = function () {
                            YYGGames.showInterstitial(() => {
                                _.default.instance.playSound(c.default.ButtonTap), this._fail()
                            })
                        }, t
                    }(a.ui.view.gamein_reliveUI);
                n.default = g
            }, {
                "../ads/InsideAds": 8,
                "../common/ReportEventID": 16,
                "../core/GameHelper": 23,
                "../core/RewardLogic": 27,
                "../core/Server": 28,
                "../core/ShareLogic": 29,
                "../logic/EconomicLogic": 43,
                "../platform/yt": 63,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./Toast": 121
            }],
            112: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/RewardLogic"),
                    s = e("../core/ShareLogic"),
                    l = e("../logic/EconomicLogic"),
                    c = e("../sound/SoundID"),
                    u = e("../core/Server"),
                    d = e("../common/ReportEventID"),
                    h = e("../core/GameHelper"),
                    f = e("./Toast"),
                    p = e("../sound/SoundMgr"),
                    _ = e("../snake_view/SnakeBridge"),
                    y = e("../platform/yt"),
                    g = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._onRevive = null, t._times = 6, t._curTimes = 6, t._price = 100, t._type = r.RewardMethodEnum.NONE, t._ring = null, t._adsPnl = null, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t._dialog.y = .5 * Laya.stage.height, t._ring = t.ring, t._adsPnl = t.adsPnl, t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this._setBtnsEnabled(!0)
                        }, t.prototype.onOpened = function (e) {
                            u.default.reportEvent(d.default.pop_revive), this._onRevive = e.onRevive, this._times = this._curTimes = parseInt(y.default.conf.revive_countdown) || 10, this._price = parseInt(y.default.conf.revive_price) || 10, this._countDown.changeText(this._curTimes + ""), this._priceLbl.changeText(this._price.toFixed());
                            var t = _.SnakeBridge.instance.getPlayerAttr();
                            this._scoreLbl.changeText(t.score.toString()), this._killLbl.changeText(t.killCount.toString()), this._updateReviveMethod(e.forceCoins), h.default.addBannerStatus(this, !0), this._updateInsideAds(), this._continue(), window.CountDownStop = !0
                        }, t.prototype._onRemoved = function () {
                            window.CountDownStop = !1, this._pause(), Laya.Tween.clearAll(this._countDown), h.default.removeBannerStatus(this), e.prototype._onRemoved.call(this)
                        }, t.prototype._updateInsideAds = function () {}, t.prototype._updateReviveMethod = function (e) {
                            var t = e ? r.RewardMethodEnum.NONE : r.default.instance.ShareOrVideo(s.ShareTypeEnum.REVIVE);
                            this._type = t;
                            var n = 1 != parseInt(y.default.conf.revive_hide_closebtn);
                            switch (this._coinsPnl.visible = !1, this._sharePnl.visible = !1, this._videoPnl.visible = !1, t) {
                                case r.RewardMethodEnum.NONE:
                                    this._coinsPnl.visible = !0, this._btnClose.visible = !0;
                                    break;
                                case r.RewardMethodEnum.SHARE:
                                    this._sharePnl.visible = !0, this._btnClose.visible = n;
                                    break;
                                case r.RewardMethodEnum.VIDEO:
                                    this._videoPnl.visible = !0, this._btnClose.visible = n
                            }
                        }, t.prototype._coinsRevive = function () {
                            l.default.instance.coin.gte(this._price) ? (l.default.instance.SubCoin(this._price), l.default.instance.SaveCoin(), this._success()) : (f.default.show("Not enough coins!"), this._continue())
                        }, t.prototype._diamondsRevive = function () {
                            l.default.instance.diamond.gte(this._price) ? (l.default.instance.SubDiamond(this._price), l.default.instance.SaveDiamond(), this._success()) : (f.default.show("Not enough diamonds!"), this._continue())
                        }, t.prototype._shareRevive = function () {
                            var e = this;
                            r.default.instance.ShareReward(s.ShareTypeEnum.REVIVE, function () {
                                u.default.reportEvent(d.default.share_revive), e._success()
                            }, function () {
                                e._continue()
                            })
                        }, t.prototype._videoRevive = function () {
                            var e = this;
                            YYGGames.showReward(() => {
                                r.default.instance.VideoReward(!0, function () {
                                    u.default.reportEvent(d.default.video_revive), e._success()
                                }, function () {
                                    e._continue()
                                })
                            }, () => {
                                e._continue()
                            }, () => {
                                e._continue()
                            })
                        }, t.prototype._success = function () {
                            this._onRevive && this._onRevive(!0), this.destroy()
                        }, t.prototype._fail = function () {
                            this._pause(), this._onRevive && this._onRevive(!1), this.destroy()
                        }, t.prototype._continue = function () {
                            var e = (1 - this._ring.progress) * this._times * 1e3;
                            Laya.Tween.clearAll(this._ring), Laya.Tween.to(this._ring, {
                                progress: 1,
                                update: new Laya.Handler(this, this._onTickTock)
                            }, e, null, Laya.Handler.create(this, this._fail))
                        }, t.prototype._pause = function () {
                            Laya.Tween.clearAll(this._ring)
                        }, t.prototype._onTickTock = function () {
                            var e = this,
                                t = this._ring.progress,
                                n = Math.floor((1 - t) * this._times);
                            n != this._curTimes && (this._curTimes = n, this._countDown.changeText(this._curTimes + ""), Laya.Tween.clearAll(this._countDown), Laya.Tween.to(this._countDown, {
                                scaleX: .8,
                                scaleY: .8
                            }, 150, null, Laya.Handler.create(this, function () {
                                Laya.Tween.to(e._countDown, {
                                    scaleX: .7,
                                    scaleY: .7
                                }, 150, null, Laya.Handler.create(e, function () {}))
                            })))
                        }, t.prototype._setBtnsEnabled = function (e) {
                            void 0 === e && (e = !0), this._btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnRevive.off(Laya.Event.CLICK, this, this._onBtnReviveClick), e && (this._btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnRevive.on(Laya.Event.CLICK, this, this._onBtnReviveClick))
                        }, t.prototype._onBtnReviveClick = function () {
                            switch (u.default.reportEvent(d.default.click_revive), p.default.instance.playSound(c.default.ButtonTap), this._pause(), this._setBtnsEnabled(!1), this._type) {
                                case r.RewardMethodEnum.NONE:
                                    this._diamondsRevive();
                                    break;
                                case r.RewardMethodEnum.SHARE:
                                    this._shareRevive();
                                    break;
                                case r.RewardMethodEnum.VIDEO:
                                    this._videoRevive()
                            }
                            Laya.timer.once(200, this, this._setBtnsEnabled)
                        }, t.prototype._onBtnCloseClick = function () {
                            YYGGames.showInterstitial(() => {
                                p.default.instance.playSound(c.default.ButtonTap), this._fail()
                            })
                        }, t
                    }(a.ui.view.gamein_relive1UI);
                n.default = g
            }, {
                "../common/ReportEventID": 16,
                "../core/GameHelper": 23,
                "../core/RewardLogic": 27,
                "../core/Server": 28,
                "../core/ShareLogic": 29,
                "../logic/EconomicLogic": 43,
                "../platform/yt": 63,
                "../snake_view/SnakeBridge": 94,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./Toast": 121
            }],
            113: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s, l, c, u, d, h, f = e("../ui/layaMaxUI"),
                    p = e("../core/ShareLogic"),
                    _ = e("../core/RewardLogic"),
                    y = e("../logic/SkinLogic"),
                    g = e("../data/DataBus"),
                    m = e("../config/GameCnf"),
                    v = e("../logic/GameLogic"),
                    L = e("../logic/EconomicLogic"),
                    w = e("./ModelView"),
                    b = e("../config/ConfigBus"),
                    S = e("../core/Server"),
                    A = e("../common/ReportEventID"),
                    I = e("../script/DialogEffect"),
                    C = e("../logic/MergeLogic"),
                    k = e("../core/GameHelper"),
                    M = e("../config/SignCnf"),
                    E = e("../sound/SoundID"),
                    T = e("../logic/GuideLogic"),
                    D = e("./Toast"),
                    O = e("../sound/SoundMgr"),
                    P = e("../script/NearBanner"),
                    x = e("../platform/yt");
                h = s = n.RewardViewTypeEnum || (n.RewardViewTypeEnum = {}), h[h.NONE = 0] = "NONE", h[h.OFFLINE = 1] = "OFFLINE", h[h.EXPERIENCE = 2] = "EXPERIENCE", h[h.NEWSKIN = 3] = "NEWSKIN", h[h.SIGNIN = 4] = "SIGNIN", h[h.NOMONEY = 5] = "NOMONEY", d = l = n.ExperienceTypeEnum || (n.ExperienceTypeEnum = {}), d[d.NONE = 0] = "NONE", d[d.SKIN = 1] = "SKIN", d[d.LEN = 2] = "LEN", d[d.FOOD = 3] = "FOOD", u = c = n.NoMoneyTypeEnum || (n.NoMoneyTypeEnum = {}), u[u.NONE = 0] = "NONE", u[u.COINS = 1] = "COINS", u[u.DIAMONDS = 2] = "DIAMONDS";
                var B = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.viewType = s.NONE, t.shareType = p.ShareTypeEnum.NONE, t.rewardMethod = _.RewardMethodEnum.NONE, t._adsPnl = null, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t._adsPnl = t.adsPnl, t
                    }
                    return o(t, e), t.prototype.onOpened = function (e) {
                        switch (YYGGames.gameBox.visible = !1, this.viewType = e.viewType, this.unlockReceivePnl.visible = !1, this.offTip.visible = !1, this.rewardNum.visible = !1, this.freeTip.visible = !1, this.attr1.visible = !1, this.attr2.visible = !1, this.viewType) {
                            case s.OFFLINE:
                                this.OpenOffline(e), S.default.reportEvent(A.default.pop_offline);
                                break;
                            case s.EXPERIENCE:
                                this.OpenExperience(e), S.default.reportEvent(A.default.pop_experience);
                                break;
                            case s.NEWSKIN:
                                this.OpenNewSkin(e), S.default.reportEvent(A.default.pop_unlock);
                                break;
                            case s.SIGNIN:
                                this.OpenSignIn(e);
                                break;
                            case s.NOMONEY:
                                this.OpenNoMoney(e)
                        }
                        this._setBtnsEnabled(!0);
                        var n = null;
                        n = this.btnClose.getComponent(P.default) || this.btnClose.addComponent(P.default), n && (n.isQuickBuy = t.isQuickBuy, t.isQuickBuy = !1)
                    }, t.prototype._onRemoved = function () {
                        YYGGames.gameBox.visible = !0, window.signPage && (YYGGames.gameBox.visible = !1), e.prototype._onRemoved.call(this), this.viewType == s.NEWSKIN && (0 != g.default.instance.gameData.skinGuide && 0 != g.default.instance.gameData.boughtGuide || T.default.instance.check())
                    }, t.prototype.OpenOffline = function (e) {
                        this.offTip.visible = !0, this.descTxt.text = "您已离线" + (g.default.instance.gameData.offlineTime / 3600).toFixed(1) + "小时，可领取", this.btnTxt.skin = "tex/fnt_windows_btn_three.png", this.btnCloseSkin.skin = "tex/fnt_windows_btn_get.png", this.Ico.skin = "tex/windows_icon_offlinegold.png", this.title.skin = "tex/fnt_windows_biaoti_offlinegold.png", this.shareType = p.ShareTypeEnum.OFFLINE, this.rewardMethod = _.default.instance.ShareOrVideo(this.shareType), this.val1 = v.default.instance.CalcOfflineGold(), this.rewardNum.visible = !0, this.rewardNum.text = "+" + k.default.toAbb(this.val1), this.rewardMethod == _.RewardMethodEnum.VIDEO ? this.SetBtnState(!0) : this.SetBtnState(!1), v.default.instance.isPopOffline = !1
                    }, t.prototype.OpenExperience = function (e) {
                        switch (this.shareType = p.ShareTypeEnum.EXPERIENCE, this.rewardMethod = _.default.instance.ShareOrVideo(this.shareType), this.btnTxt.skin = "tex/fnt_windows_btn_trynow.png", this.btnCloseSkin.skin = "tex/fnt_windows_btn_nothx.png", this.rewardMethod == _.RewardMethodEnum.VIDEO ? this.SetBtnState(!0) : this.SetBtnState(!1), this.val1 = e.experienceType, this.val1) {
                            case l.SKIN:
                                this.val2 = e.skinId, this.title.skin = "tex/fnt_windows_biaoti_pftry.png";
                                var t = y.default.instance.GetSkinCnf(e.skinId);
                                this.descTxt.text = t.name, y.default.instance.setTwoAttrVal(this.attr1, this.attr2, t.id), this.Ico.visible = !1, this._createModelView(e.skinId), S.default.reportEvent(A.default.pop_experience_skin);
                                break;
                            case l.LEN:
                                this.title.skin = "tex/fnt_windows_biaoti_kjcdzj.png", this.descTxt.text = "Length +" + m.default.experienceLen, this.Ico.visible = !0, this.Ico.skin = "tex/windows_icon_changdu.png", S.default.reportEvent(A.default.pop_experience_addlen);
                                break;
                            case l.FOOD:
                                this.title.skin = "tex/fnt_windows_biaoti_doublefood.png", this.descTxt.text = "拾取食物得分翻倍", this.Ico.visible = !0, this.Ico.skin = "tex/windows_icon_doublefood.png", S.default.reportEvent(A.default.pop_experience_food)
                        }
                    }, t.prototype.OpenNewSkin = function (e) {
                        this.Ico.visible = !1, this.title.skin = "tex/fnt_windows_biaoti_pfunlock.png", this.btnTxt.skin = "tex/fnt_windows_biaoti_pftry.png", this.btnCloseSkin.skin = "tex/fnt_windows_btn_nothx.png", this.shareType = p.ShareTypeEnum.UNLOCK, this.rewardMethod = _.default.instance.ShareOrVideo(this.shareType), this.SetBtnState(this.rewardMethod == _.RewardMethodEnum.VIDEO);
                        var t = y.default.instance.GetSkinCnf(e.skinId);
                        this.descTxt.text = t.name, this.val1 = C.default.instance.getOriginDiamondsPrice(e.skinId - 1), this.unlockReceivePnl.visible = !0, this.unlockReceiveDiamonds.changeText(this.val1 + ""), this._createModelView(e.skinId), O.default.instance.playSound(E.default.Unlock)
                    }, t.prototype.OpenSignIn = function (e) {
                        this.btnCloseSkin.skin = "tex/fnt_windows_btn_zclq.png", this.title.skin = "tex/fnt_windows_biaoti_receive.png", this.shareType = p.ShareTypeEnum.SIGNIN, this.rewardMethod = _.default.instance.ShareOrVideo(this.shareType), this.SetBtnState(this.rewardMethod == _.RewardMethodEnum.VIDEO);
                        var t = e.signCnf,
                            n = !1;
                        t.type == M.SignRewardType.SKIN && C.default.instance.isFull() && (t.type = M.SignRewardType.GOLD, n = !0);
                        var i = v.default.instance.GetSignRewards(t);
                        switch (this.val1 = t.type, this.val2 = i, t.type) {
                            case M.SignRewardType.SKIN:
                                var o = i;
                                b.default.instance.skins[o - 1];
                                this.descTxt.text = "Day " + e.day, this.rewardNum.visible = !1, this.Ico.visible = !1, this._createModelView(o), o - 1 + 1 > C.default.instance.getCurLevel() ? this.btnGet.visible = !1 : this.btnGet.visible = !0, this.btnTxt.skin = "tex/fnt_windows_btn_upgrade.png";
                                break;
                            case M.SignRewardType.GOLD:
                                if (n) {
                                    var a = "Pond is full, rewards are converted to gold!";
                                    this.descTxt.text = a, D.default.show(a)
                                } else this.descTxt.text = "Day " + e.day;
                                this.rewardNum.visible = !0, this.rewardNum.changeText("+" + k.default.toAbb(i)), this.Ico.visible = !0, this.Ico.skin = "tex/windows_icon_offlinegold.png", this.btnGet.visible = !0, this.btnTxt.skin = "tex/fnt_windows_btn_double.png";
                                break;
                            case M.SignRewardType.DIAMONDS:
                                this.descTxt.text = "Day " + e.day, this.rewardNum.visible = !0, this.rewardNum.changeText("+" + k.default.toAbb(i)), this.Ico.visible = !0, this.Ico.skin = "tex/windows_icon_offlinezuanshi.png", this.btnGet.visible = !0, this.btnTxt.skin = "tex/fnt_windows_btn_double.png"
                        }
                    }, t.prototype.OpenNoMoney = function (e) {
                        this.freeTip.visible = !0;
                        var t = this.val1 = e.noMoneyType;
                        if (this.val2 = e.rewardVal, t == c.DIAMONDS) {
                            var n = g.default.instance.gameData.freeDiamTimes,
                                i = parseInt(x.default.conf.free_diamonds_times) || 0;
                            this.freeTip.changeText("You can still claim (" + (i - n) + "/" + i + ") times today"), this.descTxt.text = '"You dont "have enough diamonds...@w@', this.title.skin = "tex/fnt_windows_biaoti_zsbz.png", this.Ico.skin = "tex/windows_icon_offlinezuanshi.png", this.shareType = p.ShareTypeEnum.NODIAMONDS
                        } else {
                            var o = g.default.instance.gameData.freeCoinTimes,
                                a = parseInt(x.default.conf.free_coins_times) || 0;
                            this.freeTip.changeText("You can still claim (" + (a - o) + "/" + a + ") times today"), this.descTxt.text = "You don't have enough coins...@w@", this.title.skin = "tex/fnt_windows_biaoti_jbbz.png", this.Ico.skin = "tex/windows_icon_offlinegold.png", this.shareType = p.ShareTypeEnum.NOCOINS
                        }
                        this.btnTxt.skin = "tex/fnt_windows_biaoti_pftry.png", this.btnCloseSkin.skin = "tex/fnt_windows_btn_nothx.png", this.rewardMethod = _.default.instance.ShareOrVideo(this.shareType), this.rewardNum.visible = !0, this.rewardNum.text = "+" + k.default.toAbb(this.val2), this.rewardMethod == _.RewardMethodEnum.VIDEO ? this.SetBtnState(!0) : this.SetBtnState(!1)
                    }, t.prototype._createModelView = function (e) {
                        var t = this._findComponentInParent(this, I.default),
                            n = t ? t.duration : 0;
                        Laya.timer.once(n + 10, this, this.__createModelView, [e])
                    }, t.prototype.__createModelView = function (e) {
                        return a(this, void 0, void 0, function () {
                            var t, n, i, o, a, s, l, c, u, d, h;
                            return r(this, function (r) {
                                switch (r.label) {
                                    case 0:
                                        return t = this._modelPnl.localToGlobal(new Laya.Point(0, 0)), n = t.x, i = t.y, o = this._modelPnl.localToGlobal(new Laya.Point(this._modelPnl.width, this._modelPnl.height)), a = o.x, s = o.y, l = a - n, c = s - i, u = new Laya.Rectangle(n, i, l, c), d = new w.default(u, 200, 15, 30), this.addChild(d), [4, d.setAnimator("res/model2/snake_anima_stay.lh", -45, new Laya.Vector3(0, -10, 0))];
                                    case 1:
                                        return r.sent(), h = w.default.createModelParam(e), d.setModel(h), [2]
                                }
                            })
                        })
                    }, t.prototype._findComponentInParent = function (e, t) {
                        for (; e;) {
                            var n = e.getComponent(t);
                            if (n) return n;
                            e = e.parent
                        }
                        return null
                    }, t.prototype.SetBtnState = function (e) {
                        this.btnIco.visible = e, this.btnTxt.centerX = e ? 25 : 0;
                        var t = e ? 260 : 219;
                        this.btnGet.width = t
                    }, t.prototype._setBtnsEnabled = function (e) {
                        this.btnGet.off(Laya.Event.CLICK, this, this.OnGetBtnTap), this.btnClose.off(Laya.Event.CLICK, this, this.OnCloseBtnTap), e && (this.btnGet.on(Laya.Event.CLICK, this, this.OnGetBtnTap), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtnTap))
                    }, t.prototype.OnCloseBtnTap = function () {
                        switch (this._setBtnsEnabled(!1), this.viewType) {
                            case s.OFFLINE:
                                L.default.instance.AddCoinWithAnimation(this.val1), g.default.instance.gameData.offlineTime = 0, g.default.instance.SaveGameData(), S.default.reportEvent(A.default.normal_offline);
                                break;
                            case s.EXPERIENCE:
                                v.default.instance.EnterGame();
                                break;
                            case s.SIGNIN:
                                this._receiveSignReward(!1)
                        }
                        this.close()
                    }, t.prototype.OnGetBtnTap = function () {
                        var e = this;
                        this._setBtnsEnabled(!1), Laya.timer.once(100, this, this._setBtnsEnabled, [!0]);
                        var t = null,
                            n = function () {};
                        switch (this.viewType) {
                            case s.OFFLINE:
                                t = function () {
                                    L.default.instance.AddCoinWithAnimation(3 * e.val1), g.default.instance.gameData.offlineTime = 0, g.default.instance.SaveGameData(), e.rewardMethod == _.RewardMethodEnum.SHARE ? (S.default.reportEvent(A.default.share_offline), S.default.reportEvent(A.default.motive_offline)) : e.rewardMethod == _.RewardMethodEnum.VIDEO && (S.default.reportEvent(A.default.video_offline), S.default.reportEvent(A.default.motive_offline)), e.close()
                                };
                                break;
                            case s.EXPERIENCE:
                                t = function () {
                                    switch (v.default.instance.EnterGame(e.val1, e.val2), e.val1) {
                                        case l.SKIN:
                                            S.default.reportEvent(A.default.use_experience_skin);
                                            break;
                                        case l.LEN:
                                            S.default.reportEvent(A.default.use_experience_addlen);
                                            break;
                                        case l.FOOD:
                                            S.default.reportEvent(A.default.use_experience_food)
                                    }
                                    S.default.reportEvent(A.default.click_experience)
                                }, this.close();
                                break;
                            case s.NEWSKIN:
                                t = function () {
                                    L.default.instance.AddDiamondWithAnimation(e.val1), S.default.reportEvent(A.default.click_unlock), e.rewardMethod == _.RewardMethodEnum.SHARE ? S.default.reportEvent(A.default.share_unlock) : e.rewardMethod == _.RewardMethodEnum.VIDEO && S.default.reportEvent(A.default.video_unlock), e.close()
                                };
                                break;
                            case s.SIGNIN:
                                t = function () {
                                    e._receiveSignReward(!0), e.close()
                                };
                                break;
                            case s.NOMONEY:
                                t = function () {
                                    e.val1 == c.DIAMONDS ? (++g.default.instance.gameData.freeDiamTimes, g.default.instance.SaveGameData(), L.default.instance.AddDiamondWithAnimation(e.val2, function () {})) : (++g.default.instance.gameData.freeCoinTimes, g.default.instance.SaveGameData(), L.default.instance.AddCoinWithAnimation(e.val2, function () {})), e.close()
                                }
                        }
                        if (null != t) switch (this.rewardMethod) {
                            case _.RewardMethodEnum.SHARE:
                                _.default.instance.ShareReward(this.shareType, t, n);
                                break;
                            case _.RewardMethodEnum.VIDEO:
                                YYGGames.showReward(() => {
                                    _.default.instance.VideoReward(!0, t, n)
                                });
                                break;
                            default:
                                "-1" == x.default.conf.prize_flag || this.viewType == s.NEWSKIN ? t() : D.default.show("Reached today's limit")
                        }
                    }, t.prototype._receiveSignReward = function (e) {
                        var t = this.val1,
                            n = this.val2;
                        switch (t) {
                            case M.SignRewardType.SKIN:
                                var i = n - 1;
                                e && (i += 1), C.default.instance.addItemWithAnimation(i);
                                break;
                            case M.SignRewardType.GOLD:
                                e && (n *= 2), L.default.instance.AddCoinWithAnimation(n);
                                break;
                            case M.SignRewardType.DIAMONDS:
                                e && (n *= 2), L.default.instance.AddDiamondWithAnimation(n)
                        }
                    }, t.isQuickBuy = !1, t
                }(f.ui.view.lobby_rewardUI);
                n.default = B
            }, {
                "../common/ReportEventID": 16,
                "../config/ConfigBus": 18,
                "../config/GameCnf": 19,
                "../config/SignCnf": 20,
                "../core/GameHelper": 23,
                "../core/RewardLogic": 27,
                "../core/Server": 28,
                "../core/ShareLogic": 29,
                "../data/DataBus": 32,
                "../logic/EconomicLogic": 43,
                "../logic/GameLogic": 44,
                "../logic/GuideLogic": 45,
                "../logic/MergeLogic": 47,
                "../logic/SkinLogic": 48,
                "../platform/yt": 63,
                "../script/DialogEffect": 64,
                "../script/NearBanner": 69,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./ModelView": 109,
                "./Toast": 121
            }],
            114: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t._progressNode = null, t._progressMask = null, t._progress = 0, t
                    }
                    return o(t, e), Object.defineProperty(t.prototype, "progress", {
                        get: function () {
                            return this._progress
                        },
                        set: function (e) {
                            this._progress = Math.max(0, Math.min(.999, e)), Laya.timer.callLater(this, this._updateProgress)
                        },
                        enumerable: !0,
                        configurable: !0
                    }), t.prototype.onAwake = function () {
                        this._initUi()
                    }, t.prototype._initUi = function () {
                        this._progressNode = this.getChildByName("progressNode"), this._progressMask = this._progressNode.mask
                    }, t.prototype._updateProgress = function () {
                        this._progressMask.graphics.clear();
                        var e = .5 * this._progressMask.width;
                        this._progressMask.graphics.drawPie(e, e, e, 360 * this._progress - 90, -90, "#ffffff")
                    }, t
                }(Laya.Sprite);
                n.default = a
            }, {}],
            115: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/GameHelper"),
                    s = e("../sound/SoundID"),
                    l = e("../core/Server"),
                    c = e("../common/ReportEventID"),
                    u = e("../core/RewardLogic"),
                    d = e("../core/ShareLogic"),
                    h = e("../sound/SoundMgr"),
                    f = e("../logic/GameLogic"),
                    p = e("../logic/EconomicLogic"),
                    _ = (e("../common/SceneID"), e("../ads/InsideAds"), e("../logic/MergeLogic")),
                    y = (e("../ads/AdsLogic"), e("../ads/MoreAds"), e("../data/DataBus")),
                    g = e("../platform/yt"),
                    m = (e("../script/NearBanner"), function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.__prizeCoins = "_1_", t.__prizeDiamonds = "_1_", t.__bet = "_1_", t._type = u.RewardMethodEnum.NONE, t._onNext = null, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t._showRankOrAds(), t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this._setBtnsEnabled(!0)
                        }, Object.defineProperty(t.prototype, "_prizeCoins", {
                            get: function () {
                                return Number((this.__prizeCoins || "").split("_")[1]) || 0
                            },
                            set: function (e) {
                                this.__prizeCoins = "_" + e + "_"
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(t.prototype, "_prizeDiamonds", {
                            get: function () {
                                return Number((this.__prizeDiamonds || "").split("_")[1]) || 0
                            },
                            set: function (e) {
                                this.__prizeDiamonds = "_" + e + "_"
                            },
                            enumerable: !0,
                            configurable: !0
                        }), Object.defineProperty(t.prototype, "_bet", {
                            get: function () {
                                return Number((this.__bet || "").split("_")[1]) || 0
                            },
                            set: function (e) {
                                this.__bet = "_" + e + "_"
                            },
                            enumerable: !0,
                            configurable: !0
                        }), t.prototype.onOpened = function (e) {
                            l.default.reportEvent(c.default.pop_score), this._onNext = e.onNext, this._updateUi(e.result), r.default.addBannerStatus(this, !0), YYGGames.gameBanner.visible = !0
                        }, t.prototype._onRemoved = function () {
                            YYGGames.gameBanner.visible = !1, Laya.timer.clearAll(this), r.default.removeBannerStatus(this), e.prototype._onRemoved.call(this)
                        }, t.prototype._updateUi = function (e) {
                            var t = this,
                                n = e.player;
                            this._score.changeText(n.score.toString()), n.rank > 0 && n.rank <= 3 && !n.isDead ? (this._rank.visible = !1, this._rankBg.skin = "tex/windows_icon_rank" + n.rank + ".png") : (this._rank.visible = !0, this._rank.changeText(n.isDead ? "--" : n.rank.toString()), this._rankBg.skin = "tex/windows_icon_rank4.png"), this._kills.changeText(n.kill.toString()), this._duration.changeText(r.default.TransSeconds(e.duration)), this.calcPrize(n, e.duration), this._coins_1.text = "" + r.default.toAbb(this._prizeCoins), this._diamonds_1.text = "" + r.default.toAbb(this._prizeDiamonds), p.default.instance.SetMaxCoin(this._prizeCoins), this._bet = 1;
                            var i = f.default.instance.SubmitMaxLen(n.score, !n.isDead && 1 == n.rank);
                            this._newRecord.visible = !1, i && Laya.timer.once(300, this, function () {
                                t._newRecord.visible = !0, h.default.instance.playSound(s.default.NewRecord)
                            });
                            var o = u.default.instance.ShareOrVideo(d.ShareTypeEnum.SCORE);
                            switch (this._type = o, o) {
                                case u.RewardMethodEnum.NONE:
                                    this._btnReceive.visible = !1;
                                    break;
                                case u.RewardMethodEnum.SHARE:
                                    this._btnReceive.visible = !0, this._videoIcon.visible = !1, this._receiveTxt.x = 134.5;
                                    break;
                                case u.RewardMethodEnum.VIDEO:
                                    this._btnReceive.visible = !0, this._videoIcon.visible = !0, this._receiveTxt.x = 159
                            }
                            var a = e.duration / _.default.instance.getProductCoinsInterval();
                            if (a > 1) {
                                var l = _.default.instance.getTotalProfit() * a;
                                p.default.instance.AddCoin(l)
                            }
                        }, t.prototype._setRewardsLbl = function (e, t, n, i) {
                            void 0 === i && (i = .4), e.changeText(t), Laya.timer.callLater(this, this.__updateRewardsLblSize, [e, n, i])
                        }, t.prototype.__updateRewardsLblSize = function (e, t, n) {}, t.prototype._showRankOrAds = function () {}, t.prototype._showAds = function () {}, t.prototype.calcPrize = function (e, t) {
                            var n = _.default.instance.getCoinsLevel(),
                                i = Math.min(16, _.default.instance.getCoinsTimes(n)),
                                o = _.default.instance.getCoinsPriceForTimes(n, i);
                            this._prizeCoins = Math.max(1, 5 * e.score, o * e.score / (e.score + 2e4)), e.isDead ? this._prizeDiamonds = 1 + e.kill : this._prizeDiamonds = ([50, 30, 20, 10, 10, 5][e.rank - 1] || 5) + e.kill
                        }, t.prototype._share = function () {
                            var e = this;
                            u.default.instance.ShareReward(d.ShareTypeEnum.SCORE, function () {
                                l.default.reportEvent(c.default.share_score), e._success()
                            }, function () {
                                e._fail()
                            })
                        }, t.prototype._video = function () {
                            var e = this;
                            YYGGames.showInterstitial(() => {
                                u.default.instance.VideoReward(!0, function () {
                                    l.default.reportEvent(c.default.video_score), e._success()
                                }, function () {
                                    e._fail()
                                })
                            })
                        }, t.prototype._success = function () {
                            this._bet = 3, this.checkFullAd()
                        }, t.prototype._fail = function () {}, t.prototype.checkFullAd = function () {
                            this._next()
                        }, t.prototype._next = function () {
                            var e = this._prizeCoins * this._bet,
                                t = this._prizeDiamonds * this._bet;
                            if (this.removeSelf(), this._onNext && this._onNext(), Laya.timer.once(100, null, function () {
                                    p.default.instance.AddCoinWithAnimation(e)
                                }), Laya.timer.once(900, null, function () {
                                    p.default.instance.AddDiamondWithAnimation(t)
                                }), g.default.supportInterAd) {
                                var n = parseFloat(g.default.conf.inter_ad_chance) || 0,
                                    i = 100 * Math.random();
                                console.info("插屏广告, 下发几率:" + n + ", 随机几率:" + i + ", 尝试显示:" + (i < n)), i < n && y.default.instance.mergeData.level >= 3 && g.default.showInterAd()
                            }
                        }, t.prototype._setBtnsEnabled = function (e) {
                            void 0 === e && (e = !0), this._btnClose.off(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnReceive.off(Laya.Event.CLICK, this, this._onBtnReceiveClick), e && (this._btnClose.on(Laya.Event.CLICK, this, this._onBtnCloseClick), this._btnReceive.on(Laya.Event.CLICK, this, this._onBtnReceiveClick))
                        }, t.prototype._onBtnCloseClick = function () {
                            YYGGames.showInterstitial(() => {
                                h.default.instance.playSound(s.default.ButtonTap), this.checkFullAd()
                            })
                        }, t.prototype._onBtnReceiveClick = function () {
                            YYGGames.showReward(() => {
                                switch (l.default.reportEvent(c.default.motive_score), h.default.instance.playSound(s.default.ButtonTap), this._setBtnsEnabled(!1), this._type) {
                                    case u.RewardMethodEnum.NONE:
                                        break;
                                    case u.RewardMethodEnum.SHARE:
                                        this._share();
                                        break;
                                    case u.RewardMethodEnum.VIDEO:
                                        this._video()
                                }
                                Laya.timer.once(200, this, this._setBtnsEnabled)
                            })
                        }, t
                    }(a.ui.view.gamein_scoreUI));
                n.default = m
            }, {
                "../ads/AdsLogic": 5,
                "../ads/InsideAds": 8,
                "../ads/MoreAds": 10,
                "../common/ReportEventID": 16,
                "../common/SceneID": 17,
                "../core/GameHelper": 23,
                "../core/RewardLogic": 27,
                "../core/Server": 28,
                "../core/ShareLogic": 29,
                "../data/DataBus": 32,
                "../logic/EconomicLogic": 43,
                "../logic/GameLogic": 44,
                "../logic/MergeLogic": 47,
                "../platform/yt": 63,
                "../script/NearBanner": 69,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            116: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../core/GameHelper"),
                    s = e("../logic/MergeLogic"),
                    l = e("../sound/SoundID"),
                    c = e("../config/ConfigBus"),
                    u = e("../common/EventID"),
                    d = e("../logic/SkinLogic"),
                    h = e("../sound/SoundMgr"),
                    f = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            YYGGames.gameBox.visible = !1, this._init(), Laya.stage.on(u.default.BOUGHT_TIMES_CHANGED, this, this._updateList)
                        }, t.prototype._onRemoved = function () {
                            YYGGames.gameBox.visible = !0, Laya.stage.off(u.default.BOUGHT_TIMES_CHANGED, this, this._updateList), Laya.timer.clearAll(this)
                        }, t.prototype._init = function () {
                            this._initList(), this._setAllBtnsEnabled(!0), Laya.timer.once(60, this, this._scrollToCurLevel)
                        }, t.prototype._scrollToCurLevel = function () {
                            var e = s.default.instance.getCoinsLevel() - 1;
                            this.scrollList.tweenTo(e, 300)
                        }, t.prototype._initList = function () {
                            var e = [],
                                t = s.default.instance.getCoinsLevel(),
                                n = s.default.instance.getDiamondsLevel(),
                                i = s.default.instance.getCurLevel();
                            this.scrollList.renderHandler = new Laya.Handler(this, this._onListItemRender);
                            for (var o = 0, a = c.default.instance.skins.length; o < a; ++o) {
                                var l = c.default.instance.skins[o],
                                    u = l.id - 1,
                                    h = "",
                                    f = "",
                                    p = !1,
                                    _ = !1,
                                    y = l.res,
                                    g = l.name;
                                u <= t ? (h = r.default.toAbb(s.default.instance.getCoinsPrice(u)), f = "tex/common_icon_gold.png") : u == n ? (h = r.default.toAbb(s.default.instance.getDiamondsPrice(u)), f = "tex/common_icon_diamond.png") : u <= i ? (_ = !0, p = !0) : (_ = !0, y = "unknown", g = "");
                                var m = {
                                    skinId: l.id,
                                    skinName: {
                                        text: g
                                    },
                                    skinIcon: {
                                        skin: d.default.instance.GetSkinPath(y),
                                        gray: p
                                    },
                                    btnBuy: {
                                        dataSource: {
                                            priceIcon: {
                                                skin: f,
                                                visible: !_
                                            },
                                            priceLbl: {
                                                text: h,
                                                visible: !_
                                            },
                                            lock: {
                                                visible: _
                                            }
                                        }
                                    },
                                    productLbl: {
                                        visible: !_,
                                        text: r.default.toAbb(s.default.instance.getProfitPerMinute(u)) + "/min "
                                    },
                                    productPnl: {
                                        visible: !_
                                    }
                                };
                                e.push(m)
                            }
                            this.scrollList.array = e
                        }, t.prototype._updateList = function () {
                            for (var e = this.scrollList.array, t = s.default.instance.getCoinsLevel(), n = s.default.instance.getDiamondsLevel(), i = s.default.instance.getCurLevel(), o = 0, a = e.length; o < a; ++o) {
                                var l = e[o],
                                    u = c.default.instance.skins[o],
                                    h = u.id - 1,
                                    f = u.res;
                                if (l.skinIcon.gray = !1, h <= t) {
                                    var p = r.default.toAbb(s.default.instance.getCoinsPrice(h));
                                    l.btnBuy.dataSource.priceLbl.text = p, l.btnBuy.dataSource.priceIcon.skin = "tex/common_icon_gold.png", l.productLbl.visible = !0, l.productPnl.visible = !0, l.productLbl.text = r.default.toAbb(s.default.instance.getProfitPerMinute(h)) + "/min "
                                } else h == n ? (p = r.default.toAbb(s.default.instance.getDiamondsPrice(h)), l.btnBuy.dataSource.priceLbl.text = p, l.btnBuy.dataSource.priceIcon.skin = "tex/common_icon_diamond.png", l.productLbl.visible = !0, l.productPnl.visible = !0, l.productLbl.text = r.default.toAbb(s.default.instance.getProfitPerMinute(h)) + "/min ") : h <= i ? (l.btnBuy.dataSource.priceLbl.visible = !1, l.btnBuy.dataSource.priceIcon.visible = !1, l.btnBuy.dataSource.lock.visible = !0, l.skinIcon.gray = !0, l.productLbl.visible = !1, l.productPnl.visible = !1) : (l.btnBuy.dataSource.priceLbl.visible = !1, l.btnBuy.dataSource.priceIcon.visible = !1, l.btnBuy.dataSource.lock.visible = !0, f = "unknown", l.productLbl.visible = !1, l.productPnl.visible = !1);
                                l.skinIcon.skin = d.default.instance.GetSkinPath(f)
                            }
                            this.scrollList.refresh()
                        }, t.prototype._onListItemRender = function (e, t) {
                            var n = e.dataSource,
                                i = e.getChildByName("btnBuy"),
                                o = i.getChildByName("priceLbl"),
                                a = i.getChildByName("priceIcon"),
                                r = i.getChildByName("lock");
                            o.visible = n.btnBuy.dataSource.priceLbl.visible, this._setPriceLbl(o, n.btnBuy.dataSource.priceLbl.text, 85), a.visible = n.btnBuy.dataSource.priceIcon.visible, a.skin = n.btnBuy.dataSource.priceIcon.skin, r.visible = n.btnBuy.dataSource.lock.visible, i.off(Laya.Event.CLICK, this, this._onBoughtBtnTap), i.on(Laya.Event.CLICK, this, this._onBoughtBtnTap)
                        }, t.prototype._setPriceLbl = function (e, t, n, i) {
                            void 0 === i && (i = .4), e.text = t, this.__updatePriceLblSize(e, n, i)
                        }, t.prototype.__updatePriceLblSize = function (e, t, n) {
                            if (void 0 === n && (n = .4), e.width > 0) {
                                var i = Math.min(n, t / e.width);
                                e.scale(i, i, !0)
                            }
                        }, t.prototype._setAllBtnsEnabled = function (e) {
                            var t = this;
                            this.btnClose.off(Laya.Event.CLICK, this, this._onCloseBtnTap), e && this.btnClose.on(Laya.Event.CLICK, this, this._onCloseBtnTap), this.scrollList.cells.forEach(function (n) {
                                var i = n.getChildByName("btnBuy");
                                i && (i.off(Laya.Event.CLICK, t, t._onBoughtBtnTap), e && i.on(Laya.Event.CLICK, t, t._onBoughtBtnTap))
                            })
                        }, t.prototype._onCloseBtnTap = function () {
							platform.getInstance().showInterstitial(()=>{
								h.default.instance.playSound(l.default.ButtonTap), this.close()
							})
                        }, t.prototype._onBoughtBtnTap = function (e) {
                            if (e && e.target) {
                                h.default.instance.playSound(l.default.ButtonTap);
                                var t = e.target.parent.dataSource,
                                    n = s.default.instance.getCoinsLevel(),
                                    i = s.default.instance.getDiamondsLevel(),
                                    o = (s.default.instance.getCurLevel(), t.skinId - 1);
                                o <= n ? s.default.instance.coinsBuyItem(o) : o == i && s.default.instance.diamondsBuyItem(o), this._setAllBtnsEnabled(!1), Laya.timer.once(100, this, this._setAllBtnsEnabled, [!0])
                            }
                        }, t
                    }(a.ui.view.lobby_shopUI);
                n.default = f
            }, {
                "../common/EventID": 15,
                "../config/ConfigBus": 18,
                "../core/GameHelper": 23,
                "../logic/MergeLogic": 47,
                "../logic/SkinLogic": 48,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            117: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../data/DataBus"),
                    s = e("../config/ConfigBus"),
                    l = e("../logic/SkinLogic"),
                    c = e("../common/SceneID"),
                    u = e("./RewardView"),
                    d = e("../logic/GameLogic"),
                    h = e("../core/GameHelper"),
                    f = e("../sound/SoundID"),
                    p = e("../config/SignCnf"),
                    _ = (e("./Toast"), e("../logic/DialogLogic")),
                    y = e("../sound/SoundMgr"),
                    g = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.day = 0, t.week = 0, t.date = 0, t.signCnf = {
                                type: p.SignRewardType.NONE,
                                value: -1
                            }, t.received = !1, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            var e = this;
                            this._tips.visible = !0, this._content.visible = !1, r.default.instance.GetNow(!0).then(function (t) {
                                const n = Date.now(),
                                    i = new Date(n),
                                    o = Laya.LocalStorage.getItem("Merge-Snake-Battle-LastDay");
                                Number(o) != Number(i.getDate()) ? (e._tips.visible = !1, e._content.visible = !0, e.date = t, e.init(), YYGGames.gameBox.visible = !1, window.signPage = !0) : (YYGGames.showTip("Signed"), e.close())
                            }), d.default.instance.isPopSignView = !1
                        }, t.prototype.init = function () {
                            console.log("登陆第" + (r.default.instance.gameData.signTimes + 1) + "天");
                            var e = this.received = h.default.isSameDay(this.date, r.default.instance.gameData.signDate);
                            this.day = r.default.instance.gameData.signTimes % 7, e && 0 == this.day && (this.day = 7);
                            for (var t, n = [], i = 0; i < 6; ++i) {
                                var o = s.default.instance.signs[i],
                                    a = d.default.instance.GetSignRewards(o);
                                switch (t = {
                                    sign_day: {
                                        text: (i + 1).toString()
                                    }
                                }, o.type) {
                                    case p.SignRewardType.SKIN:
                                        var c = a,
                                            u = s.default.instance.skins[c - 1];
                                        t.skin_shadow = {
                                            visible: !0
                                        }, t.skin_ico = {
                                            visible: !0,
                                            skin: l.default.instance.GetSkinPath(u.res)
                                        }, t.gold_ico = {
                                            visible: !1
                                        }, t.gold_num = {
                                            visible: !1
                                        };
                                        break;
                                    case p.SignRewardType.GOLD:
                                        t.skin_shadow = {
                                            visible: !1
                                        }, t.skin_ico = {
                                            visible: !1
                                        }, t.gold_ico = {
                                            visible: !0,
                                            x: 46,
                                            skin: "tex/common_icon_gold.png"
                                        };
                                        var f = "+" + h.default.toAbb(a);
                                        Math.min(.36, .04 * (14 - f.length));
                                        t.gold_num = {
                                            visible: !0,
                                            x: 74,
                                            text: f
                                        };
                                        break;
                                    case p.SignRewardType.DIAMONDS:
                                        t.skin_shadow = {
                                            visible: !1
                                        }, t.skin_ico = {
                                            visible: !1
                                        }, t.gold_ico = {
                                            visible: !0,
                                            x: 67,
                                            skin: "tex/common_icon_diamond.png"
                                        }, f = "+" + h.default.toAbb(a), Math.min(.36, .04 * (14 - f.length)), t.gold_num = {
                                            visible: !0,
                                            x: 99,
                                            text: f
                                        }
                                }
                                i < this.day ? (t.state_noget = {
                                    visible: !1
                                }, t.state_toget = {
                                    visible: !1
                                }, t.state_get = {
                                    visible: !0
                                }, t.sign_mask = {
                                    visible: !0
                                }) : i != this.day || e ? (t.state_noget = {
                                    visible: !0
                                }, t.state_toget = {
                                    visible: !1
                                }, t.state_get = {
                                    visible: !1
                                }, t.sign_mask = {
                                    visible: !1
                                }) : (t.state_noget = {
                                    visible: !1
                                }, t.state_toget = {
                                    visible: !0
                                }, t.state_get = {
                                    visible: !1
                                }, t.sign_mask = {
                                    visible: !1
                                }, this.signCnf = o), n.push(t)
                            }
                            this.signList.dataSource = n;
                            var _ = s.default.instance.signs[6],
                                y = d.default.instance.GetSignRewards(_);
                            switch (_.type) {
                                case p.SignRewardType.SKIN:
                                    c = y, u = s.default.instance.skins[c - 1], this.skin_shadow.visible = !0, this.day7_ico.scale(.7, .7), this.day7_ico.skin = l.default.instance.GetSkinPath(u.res), this.day7_gold.visible = !1, this.gold_ico.visible = !1;
                                    break;
                                case p.SignRewardType.GOLD:
                                    this.skin_shadow.visible = !1, this.day7_gold.visible = !0, this.gold_ico.visible = !0, this.day7_ico.scale(1, 1), this.gold_ico.skin = "tex/common_icon_gold.png", this.day7_ico.skin = "tex/windows_icon_offlinegold.png", this.day7_gold.text = "+" + h.default.toAbb(y);
                                    break;
                                case p.SignRewardType.DIAMONDS:
                                    this.skin_shadow.visible = !1, this.day7_gold.visible = !0, this.gold_ico.visible = !0, this.day7_ico.scale(1, 1), this.gold_ico.skin = "tex/common_icon_diamond.png", this.day7_ico.skin = "tex/windows_icon_offlinezuanshi.png", this.day7_gold.text = "+" + h.default.toAbb(y)
                            }
                            6 < this.day ? (this.day7_noGet.visible = !1, this.day7_toGet.visible = !1, this.day7_get.visible = !0, this.day7_mask.visible = !0) : 6 != this.day || e ? (this.day7_noGet.visible = !0, this.day7_toGet.visible = !1, this.day7_get.visible = !1, this.day7_mask.visible = !1) : (this.day7_noGet.visible = !1, this.day7_toGet.visible = !0, this.day7_get.visible = !1, this.day7_mask.visible = !1, this.signCnf = _), this.AddEvents()
                        }, t.prototype.AddEvents = function () {
                            this.signList.on(Laya.Event.CLICK, this, this.OnSignListTap), this.signDay7.on(Laya.Event.CLICK, this, this.OnSignDay7Tap), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtnTap)
                        }, t.prototype.RemoveEvents = function () {
                            this.signList.off(Laya.Event.CLICK, this, this.OnSignListTap), this.signDay7.off(Laya.Event.CLICK, this, this.OnSignDay7Tap)
                        }, t.prototype.OnSignListTap = function (e) {
                            this.signList.selectedIndex != this.day || this.received || this.GetTodayReward()
                        }, t.prototype.OnSignDay7Tap = function (e) {
                            6 != this.day || this.received || this.GetTodayReward()
                        }, t.prototype.GetTodayReward = function () {
                            this.RemoveEvents(), this.signList.selectEnable = !1, 6 == this.day ? (this.day7_noGet.visible = !1, this.day7_toGet.visible = !1, this.day7_get.visible = !0, this.day7_mask.visible = !0) : (this.signList.selectedItem.state_noget = {
                                visible: !1
                            }, this.signList.selectedItem.state_toget = {
                                visible: !1
                            }, this.signList.selectedItem.state_get = {
                                visible: !0
                            }, this.signList.selectedItem.sign_mask = {
                                visible: !0
                            }), _.default.instance.showDialog(c.default.PopWin, {
                                viewType: u.RewardViewTypeEnum.SIGNIN,
                                signCnf: this.signCnf,
                                day: this.day + 1
                            }), r.default.instance.gameData.signTimes++, console.log("传入的日期：", this.date), r.default.instance.gameData.signDate = this.date, r.default.instance.SaveGameData();
                            const e = Date.now(),
                                t = new Date(e);
                            Laya.LocalStorage.setItem("Merge-Snake-Battle-LastDay", t.getDate())
                        }, t.prototype.OnCloseBtnTap = function () {
							platform.getInstance().showInterstitial(()=>{
								window.signPage = !1, YYGGames.gameBox.visible = !0, y.default.instance.playSound(f.default.ButtonTap), this.close()
							})
                        }, t
                    }(a.ui.view.lobby_qiandaoUI);
                n.default = g
            }, {
                "../common/SceneID": 17,
                "../config/ConfigBus": 18,
                "../config/SignCnf": 20,
                "../core/GameHelper": 23,
                "../data/DataBus": 32,
                "../logic/DialogLogic": 42,
                "../logic/GameLogic": 44,
                "../logic/SkinLogic": 48,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./RewardView": 113,
                "./Toast": 121
            }],
            118: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../logic/SkinLogic"),
                    s = e("../sound/SoundID"),
                    l = e("../sound/SoundMgr"),
                    c = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t._onNext = null, t.icon.y = .5 * Laya.stage.height, t.icon.visible = !1, t.zOrder = 1, t
                        }
                        return o(t, e), t.prototype.onOpened = function (e) {
                            e || (e = {
                                skinId: 1,
                                targetPos: null,
                                onNext: null
                            });
                            var t = Laya.Point.create();
                            e.targetPos ? t.setTo(e.targetPos.x, e.targetPos.y) : t.setTo(360, .75 * Laya.stage.height), e.targetPos = t, this._onNext = e.onNext;
                            var n = r.default.instance.GetSkinCnf(e.skinId);
                            this.icon.skin = r.default.instance.GetSkinPath(n.res), this._playAnimation(e.targetPos)
                        }, t.prototype._onRemoved = function () {
                            this._onNext && this._onNext(), e.prototype._onRemoved.call(this)
                        }, t.prototype._playAnimation = function (e) {
                            var t = this.icon;
                            t.visible = !0, t.scale(.3, .3), Laya.Tween.to(t, {
                                scaleX: 1,
                                scaleY: 1
                            }, 500, Laya.Ease.elasticOut, Laya.Handler.create(this, this._move, [e])), l.default.instance.playSound(s.default.NewRecord)
                        }, t.prototype._move = function (e) {
                            Laya.Tween.to(this.icon, {
                                x: e.x,
                                y: e.y,
                                scaleX: .2,
                                scaleY: .2
                            }, 300, Laya.Ease.sineOut, Laya.Handler.create(this, this._complete)), e.recover()
                        }, t.prototype._complete = function () {
                            this.removeSelf()
                        }, t
                    }(a.ui.view.skin_animationUI);
                n.default = c
            }, {
                "../logic/SkinLogic": 48,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97
            }],
            119: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                        return (i = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function (e, t) {
                                e.__proto__ = t
                            } || function (e, t) {
                                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                            })(e, t)
                    }, function (e, t) {
                        function n() {
                            this.constructor = e
                        }
                        i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                    }),
                    a = this && this.__awaiter || function (e, t, n, i) {
                        return new(n || (n = Promise))(function (o, a) {
                            function r(e) {
                                try {
                                    l(i.next(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function s(e) {
                                try {
                                    l(i.throw(e))
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), a(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function (e) {
                                    e(t)
                                })).then(r, s)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    },
                    r = this && this.__generator || function (e, t) {
                        function n(n) {
                            return function (r) {
                                return function (n) {
                                    if (i) throw new TypeError("Generator is already executing.");
                                    for (; s;) try {
                                        if (i = 1, o && (a = 2 & n[0] ? o.return : n[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, n[1])).done) return a;
                                        switch (o = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                            case 0:
                                            case 1:
                                                a = n;
                                                break;
                                            case 4:
                                                return s.label++, {
                                                    value: n[1],
                                                    done: !1
                                                };
                                            case 5:
                                                s.label++, o = n[1], n = [0];
                                                continue;
                                            case 7:
                                                n = s.ops.pop(), s.trys.pop();
                                                continue;
                                            default:
                                                if (!(a = (a = s.trys).length > 0 && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                                    s = 0;
                                                    continue
                                                }
                                                if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                                    s.label = n[1];
                                                    break
                                                }
                                                if (6 === n[0] && s.label < a[1]) {
                                                    s.label = a[1], a = n;
                                                    break
                                                }
                                                if (a && s.label < a[2]) {
                                                    s.label = a[2], s.ops.push(n);
                                                    break
                                                }
                                                a[2] && s.ops.pop(), s.trys.pop();
                                                continue
                                        }
                                        n = t.call(e, s)
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e), n = [6, e], o = 0
                                    } finally {
                                        i = a = 0
                                    }
                                    if (5 & n[0]) throw n[1];
                                    return {
                                        value: n[0] ? n[1] : void 0,
                                        done: !0
                                    }
                                }([n, r])
                            }
                        }
                        var i, o, a, r, s = {
                            label: 0,
                            sent: function () {
                                if (1 & a[0]) throw a[1];
                                return a[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return r = {
                            next: n(0),
                            throw: n(1),
                            return: n(2)
                        }, "function" == typeof Symbol && (r[Symbol.iterator] = function () {
                            return this
                        }), r
                    };
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var s = e("../ui/layaMaxUI"),
                    l = e("../config/ConfigBus"),
                    c = e("../data/DataBus"),
                    u = e("../logic/SkinLogic"),
                    d = e("../sound/SoundID"),
                    h = e("./ModelView"),
                    f = e("../common/EventID"),
                    p = e("../script/DialogEffect"),
                    _ = e("../logic/MergeLogic"),
                    y = e("../sound/SoundMgr"),
                    g = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.curSelId = -1, t.useSkinId = -1, t._modelView = null, t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t.init(), t
                        }
                        return o(t, e), t.prototype.onOpened = function () {
                            YYGGames.gameBox.visible = !1, this.RefreshScrollList();
                            var e = c.default.instance.skinData.useId1;
                            this.selSkinId(e), this.scrollList.tweenTo(e - 3), this._initModelView()
                        }, t.prototype.init = function () {
                            this.AddEvents(), this.InitScrollList()
                        }, t.prototype.AddEvents = function () {
                            this.scrollList.on(Laya.Event.CLICK, this, this.onScrollListTap), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseBtnTap)
                        }, t.prototype.InitScrollList = function () {
                            for (var e, t = [], n = _.default.instance.getCurLevel() + 1, i = 0; i < l.default.instance.skins.length; ++i) {
                                var o = (e = l.default.instance.skins[i]).id > n ? "unknown" : e.res,
                                    a = e.id > n ? "" : e.name,
                                    r = {
                                        skin_id: e.id,
                                        skin_name: {
                                            text: " " + a + " "
                                        },
                                        skin_ico: {
                                            skin: u.default.instance.GetSkinPath(o)
                                        }
                                    };
                                t.push(r)
                            }
                            this.scrollList.dataSource = t
                        }, t.prototype.RefreshScrollList = function () {
                            for (var e, t = _.default.instance.getCurLevel(), n = this.scrollList.dataSource, i = 0; i < n.length; ++i) {
                                var o = n[i];
                                (e = u.default.instance.GetSkinCnf(o.skin_id)).id == this.curSelId ? o.skin_bg = {
                                    skin: "tex/pure/lobby_buttom_light_yellow.png"
                                } : o.skin_bg = {
                                    skin: "tex/pure/lobby_buttom_light_green.png"
                                }, e.id - 1 <= t ? (o.skin_sel_bg = {
                                    visible: !0
                                }, o.skin_mask = {
                                    visible: !1
                                }) : (o.skin_sel_bg = {
                                    visible: !1
                                }, o.skin_mask = {
                                    visible: !0
                                }), e.id == this.useSkinId ? o.skin_sel = {
                                    visible: !0
                                } : o.skin_sel = {
                                    visible: !1
                                }
                            }
                        }, t.prototype.onScrollListTap = function () {
                            this.scrollList.selectedItem && (y.default.instance.playSound(d.default.ButtonTap), this.selSkinId(this.scrollList.selectedItem.skin_id))
                        }, t.prototype.selSkinId = function (e) {
                            if (this.curSelId != e) {
                                var t = _.default.instance.getCurLevel() + 1;
                                this.curSelId = e;
                                var n = u.default.instance.GetSkinCnf(e),
                                    i = n.id > t ? "" : n.name;
                                this.curSkinName.text = i, e <= t && (this.useSkinId = e), u.default.instance.setTwoAttrVal(this.attr1, this.attr2, e), this.RefreshScrollList(), this._updateModelView(this.curSelId)
                            }
                        }, t.prototype._initModelView = function () {
                            var e = this._findComponentInParent(this, p.default),
                                t = e ? e.duration : 0;
                            Laya.timer.once(t + 10, this, this.__initModelView)
                        }, t.prototype.__initModelView = function () {
                            return a(this, void 0, void 0, function () {
                                var e, t, n, i, o, a, s, l, c, u, d;
                                return r(this, function (r) {
                                    switch (r.label) {
                                        case 0:
                                            return e = this._modelPnl.localToGlobal(new Laya.Point(0, 0)), t = e.x, n = e.y, i = this._modelPnl.localToGlobal(new Laya.Point(this._modelPnl.width, this._modelPnl.height)), o = i.x, a = i.y, s = o - t, l = a - n, c = new Laya.Rectangle(t, n, s, l), u = new h.default(c, 240, 15, 22), this._modelPnl.addChild(u), this._modelView = u, [4, u.setAnimator("res/model2/snake_anima_stay.lh", -45, new Laya.Vector3(0, -15, 0))];
                                        case 1:
                                            return r.sent(), d = this.curSelId > 0 ? this.curSelId : 1, this._updateModelView(d), [2]
                                    }
                                })
                            })
                        }, t.prototype._updateModelView = function (e) {
                            if (this._modelView) {
                                e > _.default.instance.getCurLevel() + 1 ? (e = -1, this._modelQuestion.visible = !0) : this._modelQuestion.visible = !1;
                                var t = h.default.createModelParam(e);
                                this._modelView.setModel(t)
                            }
                        }, t.prototype._findComponentInParent = function (e, t) {
                            for (; e;) {
                                var n = e.getComponent(t);
                                if (n) return n;
                                e = e.parent
                            }
                            return null
                        }, t.prototype.OnCloseBtnTap = function () {
							platform.getInstance().showInterstitial(()=>{
								YYGGames.gameBox.visible = !0, this.useSkinId > -1 && c.default.instance.skinData.useId1 != this.useSkinId && (c.default.instance.skinData.useId1 = this.useSkinId, c.default.instance.SaveSkinData(), Laya.stage.event(f.default.SKIN_CHANGED)), y.default.instance.playSound(d.default.ButtonTap), this.close()
							})
                        }, t
                    }(s.ui.view.lobby_pifuUI);
                n.default = g
            }, {
                "../common/EventID": 15,
                "../config/ConfigBus": 18,
                "../data/DataBus": 32,
                "../logic/MergeLogic": 47,
                "../logic/SkinLogic": 48,
                "../script/DialogEffect": 64,
                "../sound/SoundID": 95,
                "../sound/SoundMgr": 96,
                "../ui/layaMaxUI": 97,
                "./ModelView": 109
            }],
            120: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = e("../ui/layaMaxUI"),
                    r = e("../logic/EconomicLogic"),
                    s = e("../data/DataBus"),
                    l = e("../data/GameSvData"),
                    c = e("../data/SkinSvData"),
                    u = e("../data/MergeSvData"),
                    d = e("../data/PropSvData"),
                    h = e("../libs/bignumber"),
                    f = e("../logic/MergeLogic"),
                    p = e("./Toast"),
                    _ = e("../common/SceneID"),
                    y = e("../common/EventID"),
                    g = function (e) {
                        function t() {
                            var t = e.call(this) || this;
                            return t.size(Laya.stage.width, Laya.stage.height), t.bg.size(Laya.stage.width, Laya.stage.height), t.AddEvents(), t
                        }
                        return o(t, e), t.prototype.AddEvents = function () {
                            this.btnAddGold.on(Laya.Event.CLICK, this, this.OnAddGoldTap), this.btnClearGold.on(Laya.Event.CLICK, this, this.OnClearGoldTap), this.btnClearAll.on(Laya.Event.CLICK, this, this.OnGetClearAll), this.btnTest3d.on(Laya.Event.CLICK, this, this.OnTest3D), this.btnAddLevel.on(Laya.Event.CLICK, this, this.OnAddLevel), this.btnReduceLevel.on(Laya.Event.CLICK, this, this.OnReduceLevel), this.btnClose.on(Laya.Event.CLICK, this, this.OnCloseTap)
                        }, t.prototype.OnCloseTap = function (e) {
                            this.close()
                        }, t.prototype.OnAddGoldTap = function (e) {
                            r.default.instance.AddCoin(Math.pow(10, 9))
                        }, t.prototype.OnClearGoldTap = function (e) {
                            r.default.instance.SubCoin(r.default.instance.coin.toString())
                        }, t.prototype.OnGetClearAll = function (e) {
                            s.default.instance.gameData = new l.default, s.default.instance.skinData = new c.default, s.default.instance.mergeData = new u.default, s.default.instance.propData = new d.default, s.default.instance.SaveGameData(), s.default.instance.SaveSkinData(), s.default.instance.SaveMergeData(), s.default.instance.SavePropData(), f.default.instance.loadDataToUi(), r.default.instance.coin = new h.default(1e4), r.default.instance.tcoin = new h.default(1e4), r.default.instance.diamond = new h.default(0), r.default.instance.maxCoin = new h.default(0), s.default.instance.SaveLocalData(), s.default.instance.SaveDataToServer(), p.default.show("已清空, 请重启游戏")
                        }, t.prototype.OnTest3D = function () {
                            this.removeSelf(), Laya.Scene.open(_.default.Test3d, !0)
                        }, t.prototype.OnAddLevel = function () {
                            var e = f.default.instance.getCurLevel();
                            e >= f.default.instance.getLevelCount() - 1 || (f.default.instance.setCurLevel(e + 1), s.default.instance.SaveMergeData(), Laya.stage.event(y.default.UNLOCK), p.default.show("Current level " + (e + 2)))
                        }, t.prototype.OnReduceLevel = function () {
                            var e = f.default.instance.getCurLevel();
                            e <= 0 || (f.default.instance.setCurLevel(e - 1), s.default.instance.SaveMergeData(), Laya.stage.event(y.default.UNLOCK), p.default.show("Current level " + e))
                        }, t
                    }(a.ui.view.testUI);
                n.default = g
            }, {
                "../common/EventID": 15,
                "../common/SceneID": 17,
                "../data/DataBus": 32,
                "../data/GameSvData": 33,
                "../data/MergeSvData": 35,
                "../data/PropSvData": 36,
                "../data/SkinSvData": 38,
                "../libs/bignumber": 39,
                "../logic/EconomicLogic": 43,
                "../logic/MergeLogic": 47,
                "../ui/layaMaxUI": 97,
                "./Toast": 121
            }],
            121: [function (e, t, n) {
                "use strict";
                var i, o = this && this.__extends || (i = function (e, t) {
                    return (i = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function (e, t) {
                            e.__proto__ = t
                        } || function (e, t) {
                            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                        })(e, t)
                }, function (e, t) {
                    function n() {
                        this.constructor = e
                    }
                    i(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                });
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var a = function (e) {
                    function t() {
                        var t = e.call(this) || this;
                        return t.zOrder = 1, t._lbl.on(Laya.Event.RESIZE, t, t._onLblResize), t
                    }
                    return o(t, e), t.show = function (e, t, n, i) {
                        YYGGames.showTip(e)
                    }, t.prototype.show = function (e, t, n, i) {
                        this._lbl.text = e, this._appear(t, n, i)
                    }, t.prototype._appear = function (e, t, n) {
                        var i = Laya.stage,
                            o = i.width,
                            a = i.height;
                        this.size(o, a), this._bg.x = .5 * o + t, this._bg.y = .5 * a + n, this._bg.scaleX = this._bg.scaleY = .5, this._bg.alpha = 1, Laya.Tween.to(this._bg, {
                            scaleX: 1,
                            scaleY: 1
                        }, 100, Laya.Ease.sineOut, Laya.Handler.create(this, this._fadeOut, [e]))
                    }, t.prototype._fadeOut = function (e) {
                        Laya.Tween.to(this._bg, {
                            y: this._bg.y - 80,
                            alpha: 0
                        }, 300, null, Laya.Handler.create(this, this._complete), e)
                    }, t.prototype._complete = function () {
                        this.removeSelf(), Laya.Pool.recover(t._poolKey, this)
                    }, t.prototype._onLblResize = function () {
                        this._bg.height = this._lbl.height + 54, this._bg.pivotY = .5 * this._bg.height
                    }, t._poolKey = "toast_key", t
                }(e("../ui/layaMaxUI").ui.view.ToastUI);
                n.default = a, window.Toast = a
            }, {
                "../ui/layaMaxUI": 97
            }]
        }, {}, [4]), window.showMetheAuthor = function () {
            const e = document.createElement("iframe");
            e.style.display = "none", document.head.appendChild(e);
            const t = e.contentWindow.console;
            t.log.apply(this, ["%c %c %c YYGGAMES %c%s %c %c ", "background: #fb8cb3", "background: #d44a52", "color: #ffffff; background: #871905", "color: #ffffff;background: #871905;", "116,104,101,32,103,97,109,101,32,105,115,32,112,111,119,101,114,101,100,32,98,121,32,121,121,103".split(",").map(e => String.fromCharCode(~~e)).join(""), "background: #d44a52", "background: #fb8cb3"])
        }
}();