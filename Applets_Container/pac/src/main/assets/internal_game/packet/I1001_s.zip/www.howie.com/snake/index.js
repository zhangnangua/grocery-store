window.screenOrientation = "portrait",
 loadLib("libs/laya.core.js"), 
 loadLib("libs/laya.webgl.js"), 
loadLib("libs/laya.particle.js"),
// loadLib("https://h5gamessdk.yyggames.com/sdk/laya/2.0.2beta/laya.ui.js"),
 loadLib("libs/laya.ui.js"), 
 loadLib("libs/laya.d3.js"), 
// loadLib("https://h5gamessdk.yyggames.com/sdk/laya/2.6.0/laya.core.js"),
// loadLib("libs/laya.webgl.js"), 
// loadLib("https://h5gamessdk.yyggames.com/sdk/laya/2.6.0/laya.particle.js"),

// loadLib("https://h5gamessdk.yyggames.com/sdk/laya/2.6.0/laya.d3.js"),

    loadLib("libs/domparser.js"), loadLib("libs/tslib.js"),
loadLib("libs/kdtree.js"), loadLib("libs/quadtree.js"), loadLib("js/bundle.js");