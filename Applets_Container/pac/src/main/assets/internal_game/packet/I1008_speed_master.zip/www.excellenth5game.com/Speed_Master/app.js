var f;
f || (f = typeof Module !== "undefined" ? Module : {});
String.prototype.startsWith ||
  (String.prototype.startsWith = function (a) {
    return 0 == this.lastIndexOf(a, 0);
  });
String.prototype.includes ||
  (String.prototype.includes = function (a, b) {
    return b ? 0 <= this.indexOf(a, b) : 0 <= this.indexOf(a);
  });
var k,
  aa,
  l,
  n,
  ba,
  p,
  q,
  r,
  ca,
  da,
  ea,
  ha,
  ia,
  ja,
  t,
  ka,
  la,
  v,
  w,
  ma,
  na,
  x,
  y,
  oa,
  pa,
  z,
  A,
  B,
  C,
  D,
  E;
function qa(a) {
  q.famobi ? q.famobi.log(a) : q.console.log(a);
}
function ra() {
  var a = (k.createGain || k.createGainNode).call(k),
    b = {};
  a.connect(k.destination);
  b.Gb = a;
  b.Cb = 1;
  b.ub = 0;
  b.Db = 1;
  return b;
}
function sa(a, b, c) {
  try {
    (a.Db = b), (a.Gb.gain.value = b * c);
  } catch (d) {}
}
function ta(a, b, c, d) {
  var e;
  var g = n.length;
  for (e = 0; e < g; e++) {
    var h = n[e];
    if (!h.wb || h.Cb) break;
  }
  if (e == g)
    if (64 > g) n[g] = ra();
    else return 0;
  h = n[e];
  h.Cb = 0;
  h.src = k.createBufferSource();
  h.src.loop = a.Hb;
  h.src.playbackRate.value = d;
  h.src.connect(h.Gb);
  h.src.onended = function () {
    h.Cb = 1;
  };
  h.src.buffer = a.buffer;
  h.wb = a;
  sa(h, b, c);
  (h.src.start || h.src.noteOn).call(h.src, 0);
  16777215 <= ba ? (ba = 1) : ba++;
  h.ub = e + 128 * ba;
  return h.ub;
}
function ua() {
  va();
}
function wa() {
  ja = 0;
  xa();
}
function F(a) {
  a = a || q.event;
  if (a.type in x) x[a.type]();
  else this[y] ? wa() : va();
}
function ya() {
  var a = oa,
    b = pa,
    c = za(Aa),
    d = { Tb: c, attributes: b, version: b.Ub, Fb: a };
  a.canvas && (a.canvas.Pb = d);
  Aa[c] = d;
  ("undefined" === typeof b.Nb || b.Nb) && Ba(d);
  Ca = Aa[c];
  f.Qb = G = Ca && Ca.Fb;
  typeof r[y] != E && F({ type: r[y] ? "blur" : "focus" });
  Da(ma);
}
window.eso_init = function (a) {
  na = a;
  ba = 0;
  D = "dat_";
  E = "undefined";
  q = window;
  r = q.document;
  (a = q.AudioContext || q.webkitAudioContext) && (k = new a());
  C = B = A = z = 1;
  l = [];
  p = [];
  pa = { alpha: 0, depth: 1, antialias: 0, stencil: 0 };
  (oa =
    f.canvas.getContext("webgl", pa) ||
    f.canvas.getContext("experimental-webgl", pa)) ||
    (r.body.innerHTML =
      "<h1>This game requires browser with WebGL support!</h1>");
  a = q.navigator.userAgent;
  ha = a.match(/Android/i);
  a.match(/iPhone|iPad|iPod/i);
  (ia = a.match(/IEMobile/i)) && (ha = !1);
  w = ha ? 1 : 0;
  ea = ha && typeof q.AudioContext == E && typeof q.webkitAudioContext != E;
  t = q.devicePixelRatio || 1;
  ka = la = 0;
  q.eso_upd_cnv = Ea;
  q.eso_post_init = ya;
  if (k) {
    aa = !!k.decodeAudioData;
    n = [];
    for (a = 0; 16 > a; a++) n[a] = ra();
    a = new q.Audio();
    try {
      a.canPlayType("audio/ogg") && (v = ".ogg");
    } catch (b) {}
    try {
      v || (a.canPlayType("audio/mpeg") && (v = ".mp3"));
    } catch (b) {}
    v || (k = null);
  }
  ma =
    "ontouchstart" in q ||
    (typeof q.navigator.msMaxTouchPoints != E &&
      0 < q.navigator.msMaxTouchPoints) ||
    (typeof q.navigator.maxTouchPoints != E && 0 < q.navigator.maxTouchPoints);
  q.addEventListener("keydown", Fa, !1);
  q.addEventListener("keyup", Ga, !1);
  a = f.canvas;
  ma &&
    (q.navigator.pointerEnabled
      ? (a.addEventListener("pointerdown", Ha, !1),
        a.addEventListener("pointermove", Ia, !1),
        a.addEventListener("pointerup", Ja, !1))
      : q.navigator.msPointerEnabled
      ? (a.addEventListener("MSPointerDown", Ha, !1),
        a.addEventListener("MSPointerMove", Ia, !1),
        a.addEventListener("MSPointerUp", Ja, !1))
      : (a.addEventListener("touchstart", Ka, !1),
        a.addEventListener("touchend", La, !1),
        a.addEventListener("touchcancel", La, !1),
        a.addEventListener("touchmove", Ma, !1)));
  a.addEventListener("mousedown", Na, !1);
  a.addEventListener("mousemove", Oa, !1);
  a.addEventListener("mouseup", Pa, !1);
  y = "hidden";
  y in r
    ? r.addEventListener("visibilitychange", F)
    : (y = "mozHidden") in r
    ? r.addEventListener("mozvisibilitychange", F)
    : (y = "webkitHidden") in r
    ? r.addEventListener("webkitvisibilitychange", F)
    : (y = "msHidden") in r
    ? r.addEventListener("msvisibilitychange", F)
    : "onfocusin" in r
    ? (r.onfocusin = r.onfocusout = F)
    : (q.onpageshow = q.onpagehide = q.onfocus = q.onblur = F);
  x = {};
  x.focus = ua;
  x.focusin = ua;
  x.pageshow = ua;
  x.blur = wa;
  x.focusout = wa;
  x.pagehide = wa;
};
function Ea() {
  var a;
  var b = (a = 0);
  var c = r.documentElement;
  var d = c.clientWidth;
  c = c.clientHeight;
  ea && typeof d != E && typeof c != E && ((a = d), (b = c));
  a || (a = q.innerWidth || 1280);
  b || (b = q.innerHeight || 720);
  a = Math.ceil(a);
  b = Math.ceil(b);
  c = a * t;
  var e = b * t;
  if (4096 < c || 4096 < e)
    (c = a),
      (e = b),
      (t = 1),
      (ka = -1),
      qa(
        "Screen dimensions are too big! Scaling down with device pixel ratio == 1"
      );
  if (0.625 < Math.abs(c - ka) || 0.625 < Math.abs(e - la)) {
    ka = c;
    la = e;
    d = f.canvas;
    if (H && H.getOffsets) {
      var g = H.getOffsets();
      var h = g.left || 0;
      var m = g.top || 0;
      if (h || m)
        d.style.transform = "translate(" + (h | 0) + "px," + (m | 0) + "px)";
      var u = g.right || 0;
      h = (a - u - h) / a;
      0 >= h && (h = 1);
      a *= h;
      c *= h;
      u = g.bottom || 0;
      h = (b - u - m) / b;
      0 >= h && (h = 1);
      b *= h;
      e *= h;
    }
    d.style.width = a + "px";
    d.style.height = b + "px";
    d.width = c;
    d.height = e;
    Qa(c, e);
  }
}
function I(a) {
  typeof a.stopPropagation != E && a.stopPropagation && a.stopPropagation();
  typeof a.preventDefault != E && a.preventDefault && a.preventDefault();
}
function Fa(a) {
  var b = a.keyCode;
  Ra(b);
  if (32 == b && a.target == r.body) return I(a), 0;
}
function Ga(a) {
  var b = a.keyCode;
  Sa(b);
  if (32 == b && a.target == r.body) return I(a), 0;
}
function Ta() {
  var a;
  for (a = 0; a < n.length; a++) {
    var b = n[a];
    if (b.wb) {
      var c = b.wb.Ib ? C * A : B * z;
      sa(b, b.Db, c);
    }
  }
}
function Ua(a, b) {
  var c = new XMLHttpRequest();
  c.open("GET", J(a) + v);
  c.responseType = "arraybuffer";
  c.onload = function () {
    var d = c.response;
    aa
      ? k.decodeAudioData(
          d,
          function (e) {
            b(e);
          },
          function (e) {
            qa("decodeAudioData error: " + ((e && e.err) || "null"));
            b(k.createBuffer(1, 1, 11025));
          }
        )
      : b(k.createBuffer(d, !1));
  };
  c.send();
}
function Va() {
  if (k && !ja) {
    var a = k.createBuffer(1, 1, 22050),
      b = k.createBufferSource();
    b.buffer = a;
    b.connect(k.destination);
    (b.start || b.noteOn).call(b, 0, 0, 0);
    q.setTimeout(function () {
      if (
        b.playbackState == b.PLAYING_STATE ||
        b.playbackState == b.FINISHED_STATE
      ) {
        ja = !0;
        for (var c = 0, d; c < p.length; c++)
          if ((d = p[c]) && d.Jb) {
            1 == w && Wa(Xa(d.ub), d.ub);
            try {
              if (0 == w) {
                try {
                  d.vb.volume = d.volume * C;
                } catch (e) {}
                try {
                  d.vb.muted = !A;
                } catch (e) {}
                d.vb.play();
              } else d.ub = ta(d, d.volume, C * A, 1);
            } catch (e) {}
          }
      }
    }, 0);
  }
}
function K(a, b, c) {
  a(b.clientX * t, b.clientY * t, c);
}
function Ka(a) {
  Va();
  for (var b = 0; b < a.changedTouches.length; b++) {
    var c = a.changedTouches[b];
    K(Ya, c, c.identifier);
  }
  I(a);
}
function Ma(a) {
  for (var b = 0; b < a.changedTouches.length; b++) {
    var c = a.changedTouches[b];
    K(Za, c, c.identifier);
  }
  I(a);
}
function La(a) {
  for (var b = 0; b < a.changedTouches.length; b++) {
    var c = a.changedTouches[b];
    K($a, c, c.identifier);
  }
  I(a);
}
function Ha(a) {
  a.pointerType !== a.MSPOINTER_TYPE_MOUSE &&
    "mouse" !== a.pointerType &&
    (I(a), K(Ya, a, a.pointerId));
}
function Ia(a) {
  a.pointerType !== a.MSPOINTER_TYPE_MOUSE &&
    "mouse" !== a.pointerType &&
    (I(a), K(Za, a, a.pointerId));
}
function Ja(a) {
  a.pointerType !== a.MSPOINTER_TYPE_MOUSE &&
    "mouse" !== a.pointerType &&
    (I(a), K($a, a, a.pointerId));
}
function Na(a) {
  var b = f.canvas;
  r.activeElement != b && b.focus();
  Va();
  I(a);
  K(Ya, a, -2);
}
function Oa(a) {
  I(a);
  K(Za, a, -2);
}
function Pa(a) {
  I(a);
  K($a, a, -2);
}
function Wa(a, b) {
  if (b && a && a.ub == b) {
    try {
      (a.src.stop || a.src.noteOff).call(a.src, 0);
    } catch (c) {}
    a.ub = 0;
  }
}
function Xa(a) {
  if (a) {
    var b = a & 127;
    if (b < n.length && ((b = n[b]), b.ub == a)) return b;
  }
  return null;
}
var bb, cb, H, db, eb, fb, gb;
function hb(a) {
  return (H && H.hasFeature(a)) || 0;
}
function L(a, b) {
  return db
    ? db.trackEvent(a, b)
    : {
        then: function (c) {
          "function" == typeof c && c();
        },
      };
}
function ib(a, b) {
  if (eb) {
    var c = eb.EVENTS;
    c && eb.trackEvent(c[a], b);
  }
}
var jb = {},
  M;
for (M in f) f.hasOwnProperty(M) && (jb[M] = f[M]);
var kb = "object" === typeof window,
  lb = "function" === typeof importScripts,
  N = "",
  mb,
  nb,
  ob,
  pb,
  qb;
if (
  "object" === typeof process &&
  "object" === typeof process.versions &&
  "string" === typeof process.versions.node
)
  (N = lb ? require("path").dirname(N) + "/" : __dirname + "/"),
    (mb = function (a, b) {
      pb || (pb = require("fs"));
      qb || (qb = require("path"));
      a = qb.normalize(a);
      return pb.readFileSync(a, b ? null : "utf8");
    }),
    (ob = function (a) {
      a = mb(a, !0);
      a.buffer || (a = new Uint8Array(a));
      a.buffer || rb("Assertion failed: undefined");
      return a;
    }),
    (nb = function (a, b, c) {
      pb || (pb = require("fs"));
      qb || (qb = require("path"));
      a = qb.normalize(a);
      pb.readFile(a, function (d, e) {
        d ? c(d) : b(e.buffer);
      });
    }),
    1 < process.argv.length && process.argv[1].replace(/\\/g, "/"),
    process.argv.slice(2),
    "undefined" !== typeof module && (module.exports = f),
    process.on("uncaughtException", function (a) {
      throw a;
    }),
    process.on("unhandledRejection", function (a) {
      throw a;
    }),
    (f.inspect = function () {
      return "[Emscripten Module object]";
    });
else if (kb || lb)
  lb
    ? (N = self.location.href)
    : "undefined" !== typeof document &&
      document.currentScript &&
      (N = document.currentScript.src),
    (N =
      0 !== N.indexOf("blob:")
        ? N.substr(0, N.replace(/[?#].*/, "").lastIndexOf("/") + 1)
        : ""),
    (mb = function (a) {
      var b = new XMLHttpRequest();
      b.open("GET", a, !1);
      b.send(null);
      return b.responseText;
    }),
    lb &&
      (ob = function (a) {
        var b = new XMLHttpRequest();
        b.open("GET", a, !1);
        b.responseType = "arraybuffer";
        b.send(null);
        return new Uint8Array(b.response);
      }),
    (nb = function (a, b, c) {
      var d = new XMLHttpRequest();
      d.open("GET", a, !0);
      d.responseType = "arraybuffer";
      d.onload = function () {
        200 == d.status || (0 == d.status && d.response) ? b(d.response) : c();
      };
      d.onerror = c;
      d.send(null);
    });
f.print || console.log.bind(console);
var O = f.printErr || console.warn.bind(console);
for (M in jb) jb.hasOwnProperty(M) && (f[M] = jb[M]);
jb = null;
var sb;
f.wasmBinary && (sb = f.wasmBinary);
var noExitRuntime = f.noExitRuntime || !0;
"object" !== typeof WebAssembly && rb("no native wasm support detected");
var tb,
  ub = !1,
  vb = "undefined" !== typeof TextDecoder ? new TextDecoder("utf8") : void 0;
function J(a, b) {
  if (a) {
    var c = wb,
      d = a + b;
    for (b = a; c[b] && !(b >= d); ) ++b;
    if (16 < b - a && c.subarray && vb) a = vb.decode(c.subarray(a, b));
    else {
      for (d = ""; a < b; ) {
        var e = c[a++];
        if (e & 128) {
          var g = c[a++] & 63;
          if (192 == (e & 224)) d += String.fromCharCode(((e & 31) << 6) | g);
          else {
            var h = c[a++] & 63;
            e =
              224 == (e & 240)
                ? ((e & 15) << 12) | (g << 6) | h
                : ((e & 7) << 18) | (g << 12) | (h << 6) | (c[a++] & 63);
            65536 > e
              ? (d += String.fromCharCode(e))
              : ((e -= 65536),
                (d += String.fromCharCode(
                  55296 | (e >> 10),
                  56320 | (e & 1023)
                )));
          }
        } else d += String.fromCharCode(e);
      }
      a = d;
    }
  } else a = "";
  return a;
}
function xb(a, b, c) {
  var d = wb;
  if (!(0 < c)) return 0;
  var e = b;
  c = b + c - 1;
  for (var g = 0; g < a.length; ++g) {
    var h = a.charCodeAt(g);
    if (55296 <= h && 57343 >= h) {
      var m = a.charCodeAt(++g);
      h = (65536 + ((h & 1023) << 10)) | (m & 1023);
    }
    if (127 >= h) {
      if (b >= c) break;
      d[b++] = h;
    } else {
      if (2047 >= h) {
        if (b + 1 >= c) break;
        d[b++] = 192 | (h >> 6);
      } else {
        if (65535 >= h) {
          if (b + 2 >= c) break;
          d[b++] = 224 | (h >> 12);
        } else {
          if (b + 3 >= c) break;
          d[b++] = 240 | (h >> 18);
          d[b++] = 128 | ((h >> 12) & 63);
        }
        d[b++] = 128 | ((h >> 6) & 63);
      }
      d[b++] = 128 | (h & 63);
    }
  }
  d[b] = 0;
  return b - e;
}
var wb,
  yb,
  Q,
  zb,
  R,
  Ab,
  Bb = [],
  Cb = [],
  Db = [];
function Eb() {
  var a = f.preRun.shift();
  Bb.unshift(a);
}
var S = 0,
  Fb = null,
  Gb = null;
f.preloadedImages = {};
f.preloadedAudios = {};
function rb(a) {
  if (f.onAbort) f.onAbort(a);
  a = "Aborted(" + a + ")";
  O(a);
  ub = !0;
  throw new WebAssembly.RuntimeError(
    a + ". Build with -s ASSERTIONS=1 for more info."
  );
}
function Hb() {
  return T.startsWith("data:application/octet-stream;base64,");
}
var T;
T = "app.wasm";
if (!Hb()) {
  var Ib = T;
  T = f.locateFile ? f.locateFile(Ib, N) : N + Ib;
}
function Jb() {
  var a = T;
  try {
    if (a == T && sb) return new Uint8Array(sb);
    if (ob) return ob(a);
    throw "both async and sync fetching of the wasm failed";
  } catch (b) {
    rb(b);
  }
}
function Kb() {
  if (!sb && (kb || lb)) {
    if ("function" === typeof fetch && !T.startsWith("file://"))
      return fetch(T, { credentials: "same-origin" })
        .then(function (a) {
          if (!a.ok) throw "failed to load wasm binary file at '" + T + "'";
          return a.arrayBuffer();
        })
        .catch(function () {
          return Jb();
        });
    if (nb)
      return new Promise(function (a, b) {
        nb(
          T,
          function (c) {
            a(new Uint8Array(c));
          },
          b
        );
      });
  }
  return Promise.resolve().then(function () {
    return Jb();
  });
}
function Lb(a) {
  for (; 0 < a.length; ) {
    var b = a.shift();
    if ("function" == typeof b) b(f);
    else {
      var c = b.Sb;
      "number" === typeof c
        ? void 0 === b.Bb
          ? Ab.get(c)()
          : Ab.get(c)(b.Bb)
        : c(void 0 === b.Bb ? null : b.Bb);
    }
  }
}
function Mb(a) {
  var b = a.getExtension("ANGLE_instanced_arrays");
  b &&
    ((a.vertexAttribDivisor = function (c, d) {
      b.vertexAttribDivisorANGLE(c, d);
    }),
    (a.drawArraysInstanced = function (c, d, e, g) {
      b.drawArraysInstancedANGLE(c, d, e, g);
    }),
    (a.drawElementsInstanced = function (c, d, e, g, h) {
      b.drawElementsInstancedANGLE(c, d, e, g, h);
    }));
}
function Nb(a) {
  var b = a.getExtension("OES_vertex_array_object");
  b &&
    ((a.createVertexArray = function () {
      return b.createVertexArrayOES();
    }),
    (a.deleteVertexArray = function (c) {
      b.deleteVertexArrayOES(c);
    }),
    (a.bindVertexArray = function (c) {
      b.bindVertexArrayOES(c);
    }),
    (a.isVertexArray = function (c) {
      return b.isVertexArrayOES(c);
    }));
}
function Ob(a) {
  var b = a.getExtension("WEBGL_draw_buffers");
  b &&
    (a.drawBuffers = function (c, d) {
      b.drawBuffersWEBGL(c, d);
    });
}
var Pb = 1,
  Qb = [],
  U = [],
  Rb = [],
  Sb = [],
  Tb = [],
  V = [],
  Aa = [],
  Vb = {},
  Wb = 4;
function W(a) {
  Xb || (Xb = a);
}
function za(a) {
  for (var b = Pb++, c = a.length; c < b; c++) a[c] = null;
  return b;
}
function Ba(a) {
  a || (a = Ca);
  if (!a.Ob) {
    a.Ob = !0;
    var b = a.Fb;
    Mb(b);
    Nb(b);
    Ob(b);
    b.Rb = b.getExtension("EXT_disjoint_timer_query");
    b.Vb = b.getExtension("WEBGL_multi_draw");
    (b.getSupportedExtensions() || []).forEach(function (c) {
      c.includes("lose_context") || c.includes("debug") || b.getExtension(c);
    });
  }
}
var Xb, Ca;
function Yb(a, b, c, d) {
  for (var e = 0; e < a; e++) {
    var g = G[c](),
      h = g && za(d);
    g ? ((g.name = h), (d[h] = g)) : W(1282);
    Q[(b + 4 * e) >> 2] = h;
  }
}
function Zb(a, b) {
  if (b) {
    var c = void 0;
    switch (a) {
      case 36346:
        c = 1;
        break;
      case 36344:
        W(1280);
        return;
      case 36345:
        c = 0;
        break;
      case 34466:
        var d = G.getParameter(34467);
        c = d ? d.length : 0;
    }
    if (void 0 === c)
      switch (((d = G.getParameter(a)), typeof d)) {
        case "number":
          c = d;
          break;
        case "boolean":
          c = d ? 1 : 0;
          break;
        case "string":
          W(1280);
          return;
        case "object":
          if (null === d)
            switch (a) {
              case 34964:
              case 35725:
              case 34965:
              case 36006:
              case 36007:
              case 32873:
              case 34229:
              case 34068:
                c = 0;
                break;
              default:
                W(1280);
                return;
            }
          else {
            if (
              d instanceof Float32Array ||
              d instanceof Uint32Array ||
              d instanceof Int32Array ||
              d instanceof Array
            ) {
              for (a = 0; a < d.length; ++a) R[(b + 4 * a) >> 2] = d[a];
              return;
            }
            try {
              c = d.name | 0;
            } catch (e) {
              W(1280);
              O(
                "GL_INVALID_ENUM in glGet2v: Unknown object returned from WebGL getParameter(" +
                  a +
                  ")! (error: " +
                  e +
                  ")"
              );
              return;
            }
          }
          break;
        default:
          W(1280);
          O(
            "GL_INVALID_ENUM in glGet2v: Native code calling glGet2v(" +
              a +
              ") and it returns " +
              d +
              " of type " +
              typeof d +
              "!"
          );
          return;
      }
    R[b >> 2] = c;
  } else W(1281);
}
function $b(a) {
  for (var b = 0, c = 0; c < a.length; ++c) {
    var d = a.charCodeAt(c);
    55296 <= d &&
      57343 >= d &&
      (d = (65536 + ((d & 1023) << 10)) | (a.charCodeAt(++c) & 1023));
    127 >= d ? ++b : (b = 2047 >= d ? b + 2 : 65535 >= d ? b + 3 : b + 4);
  }
  b += 1;
  c = ac(b);
  xb(a, c, b);
  return c;
}
function bc(a) {
  return "]" == a.slice(-1) && a.lastIndexOf("[");
}
function X(a) {
  var b = G.Mb;
  if (b) {
    var c = b.xb[a];
    "number" === typeof c &&
      (b.xb[a] = c =
        G.getUniformLocation(b, b.Kb[a] + (0 < c ? "[" + c + "]" : "")));
    return c;
  }
  W(1282);
}
for (var cc = [], G, dc = new Float32Array(288), ec = 0; 288 > ec; ++ec)
  cc[ec] = dc.subarray(0, ec + 1);
var jc = {
  Ua: function (a, b, c) {
    wb.copyWithin(a, b, b + c);
  },
  D: function () {
    rb("OOM");
  },
  v: function (a, b, c) {
    var d = new q.XMLHttpRequest();
    d.open("GET", J(a), !0);
    d.responseType = "arraybuffer";
    d.onload = function () {
      var e = new Uint8Array(d.response),
        g = e.length * e.BYTES_PER_ELEMENT,
        h = ac(g),
        m = new Uint8Array(f.HEAPU8.buffer, h, g);
      m.set(e);
      f[J(b)](c, m.byteOffset, g);
      fc(h);
    };
    d.send();
  },
  ra: function (a, b) {
    a = J(a);
    if (na) {
      var c = a.length - 3;
      "png" == a.slice(c) && (a = a.slice(0, c) + "webp");
    }
    c = new Image();
    if ("famobi_branding_button" == a.substring(4, 26)) {
      var d = a;
      a = fb;
      c.crossOrigin = "anonymous";
      c.onerror = function () {
        c.src = d;
      };
    }
    c.src = a;
    c.onload = function () {
      ca = c;
      gc(b);
    };
  },
  oa: function (a) {
    da -= a;
    0 <= da || ((da = 0.5), Ea());
  },
  Ja: function (a, b) {
    G.texImage2D(G.TEXTURE_2D, 0, a, a, b, ca);
    ca = 0;
  },
  pa: function (a, b) {
    function c(h) {
      for (var m = 0; p[m]; m++);
      0 == w
        ? (p[m] = { vb: h })
        : ((p[m] = { buffer: h, Hb: 1 }), (p[m].Ib = 1));
      hc(b, m);
    }
    function d() {
      e || (c(g), (e = 1));
    }
    var e;
    if (k)
      if (0 == w) {
        var g = new q.Audio();
        g.preload = "auto";
        g.loop = 1;
        g.oncanplaythrough = d;
        g.src = J(a) + v;
        g.load();
        q.setTimeout(d, 4800);
      } else Ua(a, c);
    else c();
  },
  ia: function (a) {
    C = a;
    if (0 == w) {
      a = 0;
      for (var b; a < p.length; a++)
        if ((b = p[a]) && b.Jb)
          try {
            b.vb.volume = b.volume * C;
          } catch (c) {}
    } else Ta();
  },
  va: function (a) {
    if (k) {
      A = a;
      for (var b = 0, c; b < p.length; b++)
        if ((c = p[b]) && c.Jb)
          if (0 == w) {
            try {
              c.vb.volume = c.volume * C;
            } catch (e) {}
            try {
              c.vb.muted = !a;
            } catch (e) {}
          } else {
            var d = Xa(c.ub);
            d && sa(d, c.volume, A * C);
          }
    }
  },
  sa: function (a) {
    l[a] = null;
  },
  qa: function (a, b, c) {
    function d(e) {
      var g;
      for (g = 0; l[g]; g++);
      l[g] = { buffer: e, Hb: c };
      ic(b, g);
    }
    k ? Ua(a, d) : d();
  },
  ja: function (a) {
    B = a;
    Ta();
  },
  L: function (a, b, c) {
    return k && 0 <= a && a < l.length ? ta(l[a], b, B * z, c) : 0;
  },
  ua: function (a, b) {
    k && (a = Xa(a)) && (a.src.playbackRate.value = b);
  },
  s: function (a) {
    k && Wa(Xa(a), a);
  },
  wa: function (a) {
    if (k)
      for (z = a, a = 0; a < n.length; a++) {
        var b = n[a];
        b.wb && !b.wb.Ib && sa(b, b.Db, B * z);
      }
  },
  ta: function (a, b) {
    k && (a = Xa(a)) && sa(a, b, B * z);
  },
  da: function (a) {
    function b() {
      Y(8, 0);
    }
    H
      ? L(a ? "EVENT_LEVELRESTART" : "EVENT_LEVELSTART", {
          levelName: "",
        }).then(b)
      : b();
  },
  p: function () {
    return hb("rewarded");
  },
  ea: function () {
    return hb("external_mute");
  },
  I: function () {
    return hb("external_pause");
  },
  la: function (a) {
    return H
      ? (a = H.localStorage.getItem(D + a)) && 0 < a.length
      : (a = q.localStorage.getItem(D + a)) && 0 < a.length;
  },
  ba: function (a) {
    var b;
    var c = f.HEAPU8;
    if (H) {
      var d = H.getCurrentLanguage();
      d = "" + d;
      for (b = 0; b < d.length && !((c[a++] = d.charCodeAt(b)), 61 < b); b++);
    }
    c[a] = 0;
  },
  J: function () {
    return hb("rewarded") && H.hasRewardedAd && H.hasRewardedAd();
  },
  _: function () {
    return hb("copyright");
  },
  F: function () {
    return bb ? 0 : 1;
  },
  ma: function (a, b, c) {
    if (H) {
      var d = D + a;
      if ((a = H.localStorage.getItem(D + a)))
        if (c != a.length) qa("eso_lodd: size mismatch in " + d);
        else for (c = 0; c < a.length; c++) f.HEAPU8[b++] = a.charCodeAt(c);
    } else if (((d = D + a), (a = q.localStorage.getItem(D + a))))
      if (c != a.length) qa("eso_lodd: size mismatch in " + d);
      else for (c = 0; c < a.length; c++) f.HEAPU8[b++] = a.charCodeAt(c);
  },
  Wa: function () {
    H && H.openBrandingLink();
  },
  Va: function () {
    function a() {
      Y(9, 0);
    }
    H ? L("EVENT_LEVELFAIL", { levelName: "", reason: "quit" }).then(a) : a();
  },
  ca: function () {
    H && H.gameReady();
  },
  Y: function (a) {
    L("EVENT_LIVESCORE", { liveScore: a });
  },
  aa: function () {
    H && H.playerReady();
  },
  fa: function (a) {
    function b() {
      H ? (H.setPreloadProgress(gb), (gb = 0)) : q.setTimeout(b, 1e3);
    }
    gb ? (gb = a) : ((gb = a), b());
  },
  E: function () {
    hb("rewarded")
      ? ((bb = 1),
        (cb = 0),
        H.rewardedAd(function (a) {
          cb = a? 1 : 0;
          bb = 0;
        }))
      : (bb = 0);
  },
  na: function (a, b, c) {
    H
      ? ((b = f.HEAPU8.subarray(b, b + c)),
        (b = q.String.fromCharCode.apply(q.String, b)),
        H.localStorage.setItem(D + a, b))
      : ((b = f.HEAPU8.subarray(b, b + c)),
        (b = q.String.fromCharCode.apply(q.String, b)),
        q.localStorage.setItem(D + a, b));
  },
  V: function (a, b) {
    H && H.showInterstitialAd
      ? ((a = J(a)),
        qa("fam_show_interstitial(" + a + ",callback_id=" + b + ")"),
        H.showInterstitialAd(a, function () {
          qa("fm_cb(fme_cb_interstitial_callback,callback_id=" + b + ")");
          Y(11, b);
        }))
      : Y(11, b);
  },
  ha: function (a, b) {
    L("EVENT_VOLUMECHANGE", { bgmVolume: a, sfxVolume: b });
  },
  Z: function (a, b) {
    function c() {
      Y(5, 0);
    }
    H
      ? L("EVENT_CUSTOM", {
          eventName: "LEVELEND",
          result: J(a),
          score: b,
        }).then(c)
      : c();
  },
  X: function (a, b) {
    function c() {
      Y(4, 0);
    }
    H
      ? (ib("LEVEL_END", { success: a, score: b, level: "" }),
        L("EVENT_LEVELFAIL", { levelName: "", reason: "dead" }).then(c),
        L("EVENT_TOTALSCORE", { totalScore: b }))
      : c();
  },
  $: function () {
    ib("LEVEL_START", { level: 1 });
  },
  G: function (a) {
    L(a ? "EVENT_PAUSE" : "EVENT_RESUME");
  },
  r: function (a) {
    J(a);
  },
  W: function () {
    return cb;
  },
  f: function (a) {
    G.activeTexture(a);
  },
  H: function (a, b) {
    G.attachShader(U[a], V[b]);
  },
  Xa: function (a, b, c) {
    G.bindAttribLocation(U[a], b, J(c));
  },
  c: function (a, b) {
    G.bindBuffer(a, Qb[b]);
  },
  w: function (a, b) {
    G.bindFramebuffer(a, Rb[b]);
  },
  N: function (a, b) {
    G.bindRenderbuffer(a, Sb[b]);
  },
  d: function (a, b) {
    G.bindTexture(a, Tb[b]);
  },
  u: function (a, b) {
    G.blendFunc(a, b);
  },
  i: function (a, b, c, d) {
    G.bufferData(a, c ? wb.subarray(c, c + b) : b, d);
  },
  xa: function (a) {
    return G.checkFramebufferStatus(a);
  },
  x: function (a) {
    G.clear(a);
  },
  U: function (a, b, c, d) {
    G.clearColor(a, b, c, d);
  },
  C: function (a) {
    G.clearDepth(a);
  },
  M: function (a) {
    G.compileShader(V[a]);
  },
  ga: function () {
    var a = za(U),
      b = G.createProgram();
    b.name = a;
    b.Ab = b.yb = b.zb = 0;
    b.Eb = 1;
    U[a] = b;
    return a;
  },
  S: function (a) {
    var b = za(V);
    V[b] = G.createShader(a);
    return b;
  },
  Fa: function (a) {
    G.cullFace(a);
  },
  Oa: function (a) {
    if (a) {
      var b = V[a];
      b ? (G.deleteShader(b), (V[a] = null)) : W(1281);
    }
  },
  Ka: function (a, b) {
    for (var c = 0; c < a; c++) {
      var d = Q[(b + 4 * c) >> 2],
        e = Tb[d];
      e && (G.deleteTexture(e), (e.name = 0), (Tb[d] = null));
    }
  },
  q: function (a) {
    G.depthMask(!!a);
  },
  o: function (a) {
    G.disable(a);
  },
  z: function (a) {
    G.disableVertexAttribArray(a);
  },
  Q: function (a, b, c) {
    G.drawArrays(a, b, c);
  },
  t: function (a, b, c, d) {
    G.drawElements(a, b, c, d);
  },
  m: function (a) {
    G.enable(a);
  },
  k: function (a) {
    G.enableVertexAttribArray(a);
  },
  ya: function (a, b, c, d) {
    G.framebufferRenderbuffer(a, b, c, Sb[d]);
  },
  za: function (a, b, c, d, e) {
    G.framebufferTexture2D(a, b, c, Tb[d], e);
  },
  A: function (a, b) {
    Yb(a, b, "createBuffer", Qb);
  },
  Ca: function (a, b) {
    Yb(a, b, "createFramebuffer", Rb);
  },
  Ba: function (a, b) {
    Yb(a, b, "createRenderbuffer", Sb);
  },
  B: function (a, b) {
    Yb(a, b, "createTexture", Tb);
  },
  Ia: function (a) {
    G.generateMipmap(a);
  },
  Na: function (a, b) {
    Zb(a, b);
  },
  Ra: function (a, b, c, d) {
    a = G.getProgramInfoLog(U[a]);
    null === a && (a = "(unknown error)");
    b = 0 < b && d ? xb(a, d, b) : 0;
    c && (Q[c >> 2] = b);
  },
  Sa: function (a, b, c) {
    if (c)
      if (a >= Pb) W(1281);
      else if (((a = U[a]), 35716 == b))
        (a = G.getProgramInfoLog(a)),
          null === a && (a = "(unknown error)"),
          (Q[c >> 2] = a.length + 1);
      else if (35719 == b) {
        if (!a.Ab)
          for (b = 0; b < G.getProgramParameter(a, 35718); ++b)
            a.Ab = Math.max(a.Ab, G.getActiveUniform(a, b).name.length + 1);
        Q[c >> 2] = a.Ab;
      } else if (35722 == b) {
        if (!a.yb)
          for (b = 0; b < G.getProgramParameter(a, 35721); ++b)
            a.yb = Math.max(a.yb, G.getActiveAttrib(a, b).name.length + 1);
        Q[c >> 2] = a.yb;
      } else if (35381 == b) {
        if (!a.zb)
          for (b = 0; b < G.getProgramParameter(a, 35382); ++b)
            a.zb = Math.max(a.zb, G.getActiveUniformBlockName(a, b).length + 1);
        Q[c >> 2] = a.zb;
      } else Q[c >> 2] = G.getProgramParameter(a, b);
    else W(1281);
  },
  Ma: function (a, b, c, d) {
    a = G.getShaderInfoLog(V[a]);
    null === a && (a = "(unknown error)");
    b = 0 < b && d ? xb(a, d, b) : 0;
    c && (Q[c >> 2] = b);
  },
  K: function (a, b, c) {
    c
      ? 35716 == b
        ? ((a = G.getShaderInfoLog(V[a])),
          null === a && (a = "(unknown error)"),
          (Q[c >> 2] = a ? a.length + 1 : 0))
        : 35720 == b
        ? ((a = G.getShaderSource(V[a])), (Q[c >> 2] = a ? a.length + 1 : 0))
        : (Q[c >> 2] = G.getShaderParameter(V[a], b))
      : W(1281);
  },
  y: function (a) {
    var b = Vb[a];
    if (!b) {
      switch (a) {
        case 7939:
          b = G.getSupportedExtensions() || [];
          b = b.concat(
            b.map(function (d) {
              return "GL_" + d;
            })
          );
          b = $b(b.join(" "));
          break;
        case 7936:
        case 7937:
        case 37445:
        case 37446:
          (b = G.getParameter(a)) || W(1280);
          b = b && $b(b);
          break;
        case 7938:
          b = $b("OpenGL ES 2.0 (" + G.getParameter(7938) + ")");
          break;
        case 35724:
          b = G.getParameter(35724);
          var c = b.match(/^WebGL GLSL ES ([0-9]\.[0-9][0-9]?)(?:$| .*)/);
          null !== c &&
            (3 == c[1].length && (c[1] += "0"),
            (b = "OpenGL ES GLSL ES " + c[1] + " (" + b + ")"));
          b = $b(b);
          break;
        default:
          W(1280);
      }
      Vb[a] = b;
    }
    return b;
  },
  a: function (a, b) {
    b = J(b);
    if ((a = U[a])) {
      var c = a,
        d = c.xb,
        e = c.Lb,
        g;
      if (!d)
        for (
          c.xb = d = {}, c.Kb = {}, g = 0;
          g < G.getProgramParameter(c, 35718);
          ++g
        ) {
          var h = G.getActiveUniform(c, g);
          var m = h.name;
          h = h.size;
          var u = bc(m);
          u = 0 < u ? m.slice(0, u) : m;
          var fa = c.Eb;
          c.Eb += h;
          e[u] = [h, fa];
          for (m = 0; m < h; ++m) (d[fa] = m), (c.Kb[fa++] = u);
        }
      c = a.xb;
      d = 0;
      e = b;
      g = bc(b);
      0 < g && ((d = parseInt(b.slice(g + 1)) >>> 0), (e = b.slice(0, g)));
      if (
        (e = a.Lb[e]) &&
        d < e[0] &&
        ((d += e[1]), (c[d] = c[d] || G.getUniformLocation(a, b)))
      )
        return d;
    } else W(1281);
    return -1;
  },
  Pa: function (a) {
    return (a = V[a]) ? G.isShader(a) : 0;
  },
  Ta: function (a) {
    a = U[a];
    G.linkProgram(a);
    a.xb = 0;
    a.Lb = {};
  },
  La: function (a, b) {
    3317 == a && (Wb = b);
    G.pixelStorei(a, b);
  },
  Aa: function (a, b, c, d) {
    G.renderbufferStorage(a, b, c, d);
  },
  ka: function (a, b, c, d) {
    G.scissor(a, b, c, d);
  },
  O: function (a, b, c, d) {
    for (var e = "", g = 0; g < b; ++g) {
      var h = d ? Q[(d + 4 * g) >> 2] : -1;
      e += J(Q[(c + 4 * g) >> 2], 0 > h ? void 0 : h);
    }
    G.shaderSource(V[a], e);
  },
  T: function (a, b, c, d, e, g, h, m, u) {
    var fa = G,
      lc = fa.texImage2D;
    if (u) {
      var P = m - 5120;
      P =
        1 == P ? wb : 4 == P ? Q : 6 == P ? R : 5 == P || 28922 == P ? zb : yb;
      var ab = 31 - Math.clz32(P.BYTES_PER_ELEMENT),
        Ub = Wb;
      u = P.subarray(
        u >> ab,
        (u +
          e *
            ((d *
              ({ 5: 3, 6: 4, 8: 2, 29502: 3, 29504: 4 }[h - 6402] || 1) *
              (1 << ab) +
              Ub -
              1) &
              -Ub)) >>
          ab
      );
    } else u = null;
    lc.call(fa, a, b, c, d, e, g, h, m, u);
  },
  Ha: function (a, b, c) {
    G.texParameterf(a, b, c);
  },
  l: function (a, b, c) {
    G.texParameteri(a, b, c);
  },
  Da: function (a, b) {
    G.uniform1f(X(a), b);
  },
  Qa: function (a, b) {
    G.uniform1i(X(a), b);
  },
  P: function (a, b, c) {
    G.uniform2f(X(a), b, c);
  },
  h: function (a, b, c, d) {
    G.uniform3f(X(a), b, c, d);
  },
  Ea: function (a, b, c) {
    if (96 >= b)
      for (var d = cc[3 * b - 1], e = 0; e < 3 * b; e += 3)
        (d[e] = R[(c + 4 * e) >> 2]),
          (d[e + 1] = R[(c + (4 * e + 4)) >> 2]),
          (d[e + 2] = R[(c + (4 * e + 8)) >> 2]);
    else d = R.subarray(c >> 2, (c + 12 * b) >> 2);
    G.uniform3fv(X(a), d);
  },
  j: function (a, b, c, d, e) {
    G.uniform4f(X(a), b, c, d, e);
  },
  g: function (a, b, c) {
    if (72 >= b) {
      var d = cc[4 * b - 1],
        e = R;
      c >>= 2;
      for (var g = 0; g < 4 * b; g += 4) {
        var h = c + g;
        d[g] = e[h];
        d[g + 1] = e[h + 1];
        d[g + 2] = e[h + 2];
        d[g + 3] = e[h + 3];
      }
    } else d = R.subarray(c >> 2, (c + 16 * b) >> 2);
    G.uniform4fv(X(a), d);
  },
  Ga: function (a, b, c, d) {
    if (32 >= b)
      for (var e = cc[9 * b - 1], g = 0; g < 9 * b; g += 9)
        (e[g] = R[(d + 4 * g) >> 2]),
          (e[g + 1] = R[(d + (4 * g + 4)) >> 2]),
          (e[g + 2] = R[(d + (4 * g + 8)) >> 2]),
          (e[g + 3] = R[(d + (4 * g + 12)) >> 2]),
          (e[g + 4] = R[(d + (4 * g + 16)) >> 2]),
          (e[g + 5] = R[(d + (4 * g + 20)) >> 2]),
          (e[g + 6] = R[(d + (4 * g + 24)) >> 2]),
          (e[g + 7] = R[(d + (4 * g + 28)) >> 2]),
          (e[g + 8] = R[(d + (4 * g + 32)) >> 2]);
    else e = R.subarray(d >> 2, (d + 36 * b) >> 2);
    G.uniformMatrix3fv(X(a), !!c, e);
  },
  n: function (a, b, c, d) {
    if (18 >= b) {
      var e = cc[16 * b - 1],
        g = R;
      d >>= 2;
      for (var h = 0; h < 16 * b; h += 16) {
        var m = d + h;
        e[h] = g[m];
        e[h + 1] = g[m + 1];
        e[h + 2] = g[m + 2];
        e[h + 3] = g[m + 3];
        e[h + 4] = g[m + 4];
        e[h + 5] = g[m + 5];
        e[h + 6] = g[m + 6];
        e[h + 7] = g[m + 7];
        e[h + 8] = g[m + 8];
        e[h + 9] = g[m + 9];
        e[h + 10] = g[m + 10];
        e[h + 11] = g[m + 11];
        e[h + 12] = g[m + 12];
        e[h + 13] = g[m + 13];
        e[h + 14] = g[m + 14];
        e[h + 15] = g[m + 15];
      }
    } else e = R.subarray(d >> 2, (d + 64 * b) >> 2);
    G.uniformMatrix4fv(X(a), !!c, e);
  },
  b: function (a) {
    a = U[a];
    G.useProgram(a);
    G.Mb = a;
  },
  e: function (a, b, c, d, e, g) {
    G.vertexAttribPointer(a, b, c, !!d, e, g);
  },
  R: function (a, b, c, d) {
    G.viewport(a, b, c, d);
  },
};
(function () {
  function a(e) {
    f.asm = e.exports;
    tb = f.asm.Ya;
    e = tb.buffer;
    f.HEAP8 = new Int8Array(e);
    f.HEAP16 = new Int16Array(e);
    f.HEAP32 = Q = new Int32Array(e);
    f.HEAPU8 = wb = new Uint8Array(e);
    f.HEAPU16 = yb = new Uint16Array(e);
    f.HEAPU32 = zb = new Uint32Array(e);
    f.HEAPF32 = R = new Float32Array(e);
    f.HEAPF64 = new Float64Array(e);
    Ab = f.asm.tb;
    Cb.unshift(f.asm.Za);
    S--;
    f.monitorRunDependencies && f.monitorRunDependencies(S);
    0 == S &&
      (null !== Fb && (clearInterval(Fb), (Fb = null)),
      Gb && ((e = Gb), (Gb = null), e()));
  }
  function b(e) {
    a(e.instance);
  }
  function c(e) {
    return Kb()
      .then(function (g) {
        return WebAssembly.instantiate(g, d);
      })
      .then(function (g) {
        return g;
      })
      .then(e, function (g) {
        O("failed to asynchronously prepare wasm: " + g);
        rb(g);
      });
  }
  var d = { a: jc };
  S++;
  f.monitorRunDependencies && f.monitorRunDependencies(S);
  if (f.instantiateWasm)
    try {
      return f.instantiateWasm(d, a);
    } catch (e) {
      return O("Module.instantiateWasm callback failed with error: " + e), !1;
    }
  (function () {
    return sb ||
      "function" !== typeof WebAssembly.instantiateStreaming ||
      Hb() ||
      T.startsWith("file://") ||
      "function" !== typeof fetch
      ? c(b)
      : fetch(T, { credentials: "same-origin" }).then(function (e) {
          return WebAssembly.instantiateStreaming(e, d).then(b, function (g) {
            O("wasm streaming compile failed: " + g);
            O("falling back to ArrayBuffer instantiation");
            return c(b);
          });
        });
  })();
  return {};
})();
f.___wasm_call_ctors = function () {
  return (f.___wasm_call_ctors = f.asm.Za).apply(null, arguments);
};
var ac = (f._malloc = function () {
    return (ac = f._malloc = f.asm._a).apply(null, arguments);
  }),
  fc = (f._free = function () {
    return (fc = f._free = f.asm.$a).apply(null, arguments);
  }),
  ic = (f._sw_snd_ld = function () {
    return (ic = f._sw_snd_ld = f.asm.ab).apply(null, arguments);
  }),
  hc = (f._sw_mus_ld = function () {
    return (hc = f._sw_mus_ld = f.asm.bb).apply(null, arguments);
  }),
  gc = (f._sw_tex_ld = function () {
    return (gc = f._sw_tex_ld = f.asm.cb).apply(null, arguments);
  });
f._sw_cus_ld = function () {
  return (f._sw_cus_ld = f.asm.db).apply(null, arguments);
};
f._sw_fnt_ld = function () {
  return (f._sw_fnt_ld = f.asm.eb).apply(null, arguments);
};
f._sw_mdl_ld = function () {
  return (f._sw_mdl_ld = f.asm.fb).apply(null, arguments);
};
f._sw_txt_ld = function () {
  return (f._sw_txt_ld = f.asm.gb).apply(null, arguments);
};
f._sw_init = function () {
  return (f._sw_init = f.asm.hb).apply(null, arguments);
};
var Qa = (f._sw_cnv_upd = function () {
  return (Qa = f._sw_cnv_upd = f.asm.ib).apply(null, arguments);
});
f._sw_tick = function () {
  return (f._sw_tick = f.asm.jb).apply(null, arguments);
};
var Ra = (f._sw_key_dwn = function () {
    return (Ra = f._sw_key_dwn = f.asm.kb).apply(null, arguments);
  }),
  Sa = (f._sw_key_up = function () {
    return (Sa = f._sw_key_up = f.asm.lb).apply(null, arguments);
  }),
  Ya = (f._sw_tch_beg = function () {
    return (Ya = f._sw_tch_beg = f.asm.mb).apply(null, arguments);
  }),
  $a = (f._sw_tch_end = function () {
    return ($a = f._sw_tch_end = f.asm.nb).apply(null, arguments);
  }),
  Za = (f._sw_tch_mov = function () {
    return (Za = f._sw_tch_mov = f.asm.ob).apply(null, arguments);
  }),
  Da = (f._sw_sys_info = function () {
    return (Da = f._sw_sys_info = f.asm.pb).apply(null, arguments);
  }),
  xa = (f._sw_susp = function () {
    return (xa = f._sw_susp = f.asm.qb).apply(null, arguments);
  }),
  va = (f._sw_resm = function () {
    return (va = f._sw_resm = f.asm.rb).apply(null, arguments);
  }),
  Y = (f._fm_cb = function () {
    return (Y = f._fm_cb = f.asm.sb).apply(null, arguments);
  }),
  kc;
Gb = function mc() {
  kc || nc();
  kc || (Gb = mc);
};
function nc() {
  function a() {
    if (!kc && ((kc = !0), (f.calledRun = !0), !ub)) {
      Lb(Cb);
      if (f.onRuntimeInitialized) f.onRuntimeInitialized();
      if (f.postRun)
        for (
          "function" == typeof f.postRun && (f.postRun = [f.postRun]);
          f.postRun.length;

        ) {
          var b = f.postRun.shift();
          Db.unshift(b);
        }
      Lb(Db);
    }
  }
  if (!(0 < S)) {
    if (f.preRun)
      for (
        "function" == typeof f.preRun && (f.preRun = [f.preRun]);
        f.preRun.length;

      )
        Eb();
    Lb(Bb);
    0 < S ||
      (f.setStatus
        ? (f.setStatus("Running..."),
          setTimeout(function () {
            setTimeout(function () {
              f.setStatus("");
            }, 1);
            a();
          }, 1))
        : a());
  }
}
f.run = nc;
if (f.preInit)
  for (
    "function" == typeof f.preInit && (f.preInit = [f.preInit]);
    0 < f.preInit.length;

  )
    f.preInit.pop()();
nc();
function Z(a, b) {
  if (H) H.onRequest(a, b);
}
function oc() {
  function a(b) {
    Y(2, (65535 * b) | 0);
  }
  Z("enableAudio", function () {
    Y(0, 1);
  });
  Z("disableAudio", function () {
    Y(0, 0);
  });
  Z("enableMusic", function () {
    Y(1, 1);
  });
  Z("disableMusic", function () {
    Y(1, 0);
  });
  Z("changeVolume", a);
  H && a(H.getVolume());
  Z("pauseGameplay", function () {
    Y(3, 1);
  });
  Z("resumeGameplay", function () {
    Y(3, 0);
  });
  Z("startGame", function () {
    Y(7, 0);
  });
  Z("restartGame", function () {
    Y(10, 0);
  });
}
window.famobi_init = function () {
  H = q.famobi;
  try {
    oc();
  } catch (a) {}
  H
    ? ((fb = H.getBrandingButtonImage()),
      (q.famobi_onPauseRequested = function () {
        Y(6, 1);
      }),
      (q.famobi_onResumeRequested = function () {
        Y(6, 0);
      }))
    : (fb = "tex/famobi_branding_button.png");
  db = q.famobi_analytics;
  (eb = q.famobi_tracking) && eb.init("e-scooter", null, 0, !1, !0);
};
