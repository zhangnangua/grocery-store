// Copyright 2011 Google Inc. All Rights Reserved.
(function () {
  var l,
    aa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    ba =
      "function" == typeof Object.defineProperties
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("Cannot find global object");
    },
    da = ca(this),
    q = function (a, b) {
      if (b)
        a: {
          var c = da;
          a = a.split(".");
          for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            null != b &&
            ba(c, a, { configurable: !0, writable: !0, value: b });
        }
    };
  q("Symbol", function (a) {
    if (a) return a;
    var b = function (f, g) {
      this.g = f;
      ba(this, "description", { configurable: !0, writable: !0, value: g });
    };
    b.prototype.toString = function () {
      return this.g;
    };
    var c = "jscomp_symbol_" + ((1e9 * Math.random()) >>> 0) + "_",
      d = 0,
      e = function (f) {
        if (this instanceof e)
          throw new TypeError("Symbol is not a constructor");
        return new b(c + (f || "") + "_" + d++, f);
      };
    return e;
  });
  q("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = da[b[c]];
      "function" === typeof d &&
        "function" != typeof d.prototype[a] &&
        ba(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return ea(aa(this));
          },
        });
    }
    return a;
  });
  var ea = function (a) {
      a = { next: a };
      a[Symbol.iterator] = function () {
        return this;
      };
      return a;
    },
    fa = function (a) {
      return (a.raw = a);
    },
    u = function (a) {
      var b =
        "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if ("number" == typeof a.length) return { next: aa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    ha = function (a) {
      if (!(a instanceof Array)) {
        a = u(a);
        for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
        a = c;
      }
      return a;
    },
    ia = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    la =
      "function" == typeof Object.assign
        ? Object.assign
        : function (a, b) {
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d) for (var e in d) ia(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  q("Object.assign", function (a) {
    return a || la;
  });
  var ma =
      "function" == typeof Object.create
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    na = (function () {
      function a() {
        function c() {}
        new c();
        Reflect.construct(c, [], function () {});
        return new c() instanceof c;
      }
      if ("undefined" != typeof Reflect && Reflect.construct) {
        if (a()) return Reflect.construct;
        var b = Reflect.construct;
        return function (c, d, e) {
          c = b(c, d);
          e && Reflect.setPrototypeOf(c, e.prototype);
          return c;
        };
      }
      return function (c, d, e) {
        void 0 === e && (e = c);
        e = ma(e.prototype || Object.prototype);
        return Function.prototype.apply.call(c, e, d) || e;
      };
    })(),
    oa;
  if ("function" == typeof Object.setPrototypeOf) oa = Object.setPrototypeOf;
  else {
    var qa;
    a: {
      var ra = { a: !0 },
        sa = {};
      try {
        sa.__proto__ = ra;
        qa = sa.a;
        break a;
      } catch (a) {}
      qa = !1;
    }
    oa = qa
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var ta = oa,
    v = function (a, b) {
      a.prototype = ma(b.prototype);
      a.prototype.constructor = a;
      if (ta) ta(a, b);
      else
        for (var c in b)
          if ("prototype" != c)
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.Fa = b.prototype;
    },
    va = function () {
      this.B = !1;
      this.A = null;
      this.j = void 0;
      this.g = 1;
      this.I = this.l = 0;
      this.o = null;
    },
    wa = function (a) {
      if (a.B) throw new TypeError("Generator is already running");
      a.B = !0;
    };
  va.prototype.C = function (a) {
    this.j = a;
  };
  var xa = function (a, b) {
    a.o = { pe: b, eg: !0 };
    a.g = a.l || a.I;
  };
  va.prototype.return = function (a) {
    this.o = { return: a };
    this.g = this.I;
  };
  var ya = function (a, b, c) {
      a.g = c;
      return { value: b };
    },
    za = function (a) {
      a.g = 0;
      a.l = 0;
    },
    Aa = function (a) {
      a.l = 0;
      var b = a.o.pe;
      a.o = null;
      return b;
    },
    Ba = function (a) {
      this.g = new va();
      this.j = a;
    },
    Ea = function (a, b) {
      wa(a.g);
      var c = a.g.A;
      if (c)
        return Ca(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.g.return
        );
      a.g.return(b);
      return Da(a);
    },
    Ca = function (a, b, c, d) {
      try {
        var e = b.call(a.g.A, c);
        if (!(e instanceof Object))
          throw new TypeError("Iterator result " + e + " is not an object");
        if (!e.done) return (a.g.B = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.g.A = null), xa(a.g, g), Da(a);
      }
      a.g.A = null;
      d.call(a.g, f);
      return Da(a);
    },
    Da = function (a) {
      for (; a.g.g; )
        try {
          var b = a.j(a.g);
          if (b) return (a.g.B = !1), { value: b.value, done: !1 };
        } catch (c) {
          (a.g.j = void 0), xa(a.g, c);
        }
      a.g.B = !1;
      if (a.g.o) {
        b = a.g.o;
        a.g.o = null;
        if (b.eg) throw b.pe;
        return { value: b.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Fa = function (a) {
      this.next = function (b) {
        wa(a.g);
        a.g.A ? (b = Ca(a, a.g.A.next, b, a.g.C)) : (a.g.C(b), (b = Da(a)));
        return b;
      };
      this.throw = function (b) {
        wa(a.g);
        a.g.A
          ? (b = Ca(a, a.g.A["throw"], b, a.g.C))
          : (xa(a.g, b), (b = Da(a)));
        return b;
      };
      this.return = function (b) {
        return Ea(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Ga = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function f(g) {
          g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
        }
        f(a.next());
      });
    },
    Ha = function (a) {
      return Ga(new Fa(new Ba(a)));
    },
    Ia = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  q("Reflect", function (a) {
    return a ? a : {};
  });
  q("Reflect.construct", function () {
    return na;
  });
  q("Reflect.setPrototypeOf", function (a) {
    return a
      ? a
      : ta
      ? function (b, c) {
          try {
            return ta(b, c), !0;
          } catch (d) {
            return !1;
          }
        }
      : null;
  });
  q("Promise", function (a) {
    function b() {
      this.g = null;
    }
    function c(g) {
      return g instanceof e
        ? g
        : new e(function (h) {
            h(g);
          });
    }
    if (a) return a;
    b.prototype.j = function (g) {
      if (null == this.g) {
        this.g = [];
        var h = this;
        this.l(function () {
          h.o();
        });
      }
      this.g.push(g);
    };
    var d = da.setTimeout;
    b.prototype.l = function (g) {
      d(g, 0);
    };
    b.prototype.o = function () {
      for (; this.g && this.g.length; ) {
        var g = this.g;
        this.g = [];
        for (var h = 0; h < g.length; ++h) {
          var k = g[h];
          g[h] = null;
          try {
            k();
          } catch (n) {
            this.A(n);
          }
        }
      }
      this.g = null;
    };
    b.prototype.A = function (g) {
      this.l(function () {
        throw g;
      });
    };
    var e = function (g) {
      this.g = 0;
      this.l = void 0;
      this.j = [];
      this.C = !1;
      var h = this.A();
      try {
        g(h.resolve, h.reject);
      } catch (k) {
        h.reject(k);
      }
    };
    e.prototype.A = function () {
      function g(n) {
        return function (m) {
          k || ((k = !0), n.call(h, m));
        };
      }
      var h = this,
        k = !1;
      return { resolve: g(this.H), reject: g(this.o) };
    };
    e.prototype.H = function (g) {
      if (g === this)
        this.o(new TypeError("A Promise cannot resolve to itself"));
      else if (g instanceof e) this.L(g);
      else {
        a: switch (typeof g) {
          case "object":
            var h = null != g;
            break a;
          case "function":
            h = !0;
            break a;
          default:
            h = !1;
        }
        h ? this.G(g) : this.B(g);
      }
    };
    e.prototype.G = function (g) {
      var h = void 0;
      try {
        h = g.then;
      } catch (k) {
        this.o(k);
        return;
      }
      "function" == typeof h ? this.P(h, g) : this.B(g);
    };
    e.prototype.o = function (g) {
      this.I(2, g);
    };
    e.prototype.B = function (g) {
      this.I(1, g);
    };
    e.prototype.I = function (g, h) {
      if (0 != this.g)
        throw Error(
          "Cannot settle(" +
            g +
            ", " +
            h +
            "): Promise already settled in state" +
            this.g
        );
      this.g = g;
      this.l = h;
      2 === this.g && this.J();
      this.N();
    };
    e.prototype.J = function () {
      var g = this;
      d(function () {
        if (g.F()) {
          var h = da.console;
          "undefined" !== typeof h && h.error(g.l);
        }
      }, 1);
    };
    e.prototype.F = function () {
      if (this.C) return !1;
      var g = da.CustomEvent,
        h = da.Event,
        k = da.dispatchEvent;
      if ("undefined" === typeof k) return !0;
      "function" === typeof g
        ? (g = new g("unhandledrejection", { cancelable: !0 }))
        : "function" === typeof h
        ? (g = new h("unhandledrejection", { cancelable: !0 }))
        : ((g = da.document.createEvent("CustomEvent")),
          g.initCustomEvent("unhandledrejection", !1, !0, g));
      g.promise = this;
      g.reason = this.l;
      return k(g);
    };
    e.prototype.N = function () {
      if (null != this.j) {
        for (var g = 0; g < this.j.length; ++g) f.j(this.j[g]);
        this.j = null;
      }
    };
    var f = new b();
    e.prototype.L = function (g) {
      var h = this.A();
      g.rc(h.resolve, h.reject);
    };
    e.prototype.P = function (g, h) {
      var k = this.A();
      try {
        g.call(h, k.resolve, k.reject);
      } catch (n) {
        k.reject(n);
      }
    };
    e.prototype.then = function (g, h) {
      function k(p, t) {
        return "function" == typeof p
          ? function (w) {
              try {
                n(p(w));
              } catch (y) {
                m(y);
              }
            }
          : t;
      }
      var n,
        m,
        r = new e(function (p, t) {
          n = p;
          m = t;
        });
      this.rc(k(g, n), k(h, m));
      return r;
    };
    e.prototype.catch = function (g) {
      return this.then(void 0, g);
    };
    e.prototype.rc = function (g, h) {
      function k() {
        switch (n.g) {
          case 1:
            g(n.l);
            break;
          case 2:
            h(n.l);
            break;
          default:
            throw Error("Unexpected state: " + n.g);
        }
      }
      var n = this;
      null == this.j ? f.j(k) : this.j.push(k);
      this.C = !0;
    };
    e.resolve = c;
    e.reject = function (g) {
      return new e(function (h, k) {
        k(g);
      });
    };
    e.race = function (g) {
      return new e(function (h, k) {
        for (var n = u(g), m = n.next(); !m.done; m = n.next())
          c(m.value).rc(h, k);
      });
    };
    e.all = function (g) {
      var h = u(g),
        k = h.next();
      return k.done
        ? c([])
        : new e(function (n, m) {
            function r(w) {
              return function (y) {
                p[w] = y;
                t--;
                0 == t && n(p);
              };
            }
            var p = [],
              t = 0;
            do
              p.push(void 0),
                t++,
                c(k.value).rc(r(p.length - 1), m),
                (k = h.next());
            while (!k.done);
          });
    };
    return e;
  });
  q("Object.setPrototypeOf", function (a) {
    return a || ta;
  });
  q("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          a: {
            var d = this;
            d instanceof String && (d = String(d));
            for (var e = d.length, f = 0; f < e; f++) {
              var g = d[f];
              if (b.call(c, g, f, d)) {
                b = g;
                break a;
              }
            }
            b = void 0;
          }
          return b;
        };
  });
  q("WeakMap", function (a) {
    function b() {}
    function c(k) {
      var n = typeof k;
      return ("object" === n && null !== k) || "function" === n;
    }
    function d(k) {
      if (!ia(k, f)) {
        var n = new b();
        ba(k, f, { value: n });
      }
    }
    function e(k) {
      var n = Object[k];
      n &&
        (Object[k] = function (m) {
          if (m instanceof b) return m;
          Object.isExtensible(m) && d(m);
          return n(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            n = Object.seal({}),
            m = new a([
              [k, 2],
              [n, 3],
            ]);
          if (2 != m.get(k) || 3 != m.get(n)) return !1;
          m.delete(k);
          m.set(n, 4);
          return !m.has(k) && 4 == m.get(n);
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
      h = function (k) {
        this.g = (g += Math.random() + 1).toString();
        if (k) {
          k = u(k);
          for (var n; !(n = k.next()).done; )
            (n = n.value), this.set(n[0], n[1]);
        }
      };
    h.prototype.set = function (k, n) {
      if (!c(k)) throw Error("Invalid WeakMap key");
      d(k);
      if (!ia(k, f)) throw Error("WeakMap key fail: " + k);
      k[f][this.g] = n;
      return this;
    };
    h.prototype.get = function (k) {
      return c(k) && ia(k, f) ? k[f][this.g] : void 0;
    };
    h.prototype.has = function (k) {
      return c(k) && ia(k, f) && ia(k[f], this.g);
    };
    h.prototype.delete = function (k) {
      return c(k) && ia(k, f) && ia(k[f], this.g) ? delete k[f][this.g] : !1;
    };
    return h;
  });
  q("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          "function" != typeof a ||
          !a.prototype.entries ||
          "function" != typeof Object.seal
        )
          return !1;
        try {
          var h = Object.seal({ x: 4 }),
            k = new a(u([[h, "s"]]));
          if (
            "s" != k.get(h) ||
            1 != k.size ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            2 != k.size
          )
            return !1;
          var n = k.entries(),
            m = n.next();
          if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
          m = n.next();
          return m.done ||
            4 != m.value[0].x ||
            "t" != m.value[1] ||
            !n.next().done
            ? !1
            : !0;
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (h) {
        this[0] = {};
        this[1] = f();
        this.size = 0;
        if (h) {
          h = u(h);
          for (var k; !(k = h.next()).done; )
            (k = k.value), this.set(k[0], k[1]);
        }
      };
    c.prototype.set = function (h, k) {
      h = 0 === h ? 0 : h;
      var n = d(this, h);
      n.list || (n.list = this[0][n.id] = []);
      n.pa
        ? (n.pa.value = k)
        : ((n.pa = {
            next: this[1],
            Wa: this[1].Wa,
            head: this[1],
            key: h,
            value: k,
          }),
          n.list.push(n.pa),
          (this[1].Wa.next = n.pa),
          (this[1].Wa = n.pa),
          this.size++);
      return this;
    };
    c.prototype.delete = function (h) {
      h = d(this, h);
      return h.pa && h.list
        ? (h.list.splice(h.index, 1),
          h.list.length || delete this[0][h.id],
          (h.pa.Wa.next = h.pa.next),
          (h.pa.next.Wa = h.pa.Wa),
          (h.pa.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].Wa = f();
      this.size = 0;
    };
    c.prototype.has = function (h) {
      return !!d(this, h).pa;
    };
    c.prototype.get = function (h) {
      return (h = d(this, h).pa) && h.value;
    };
    c.prototype.entries = function () {
      return e(this, function (h) {
        return [h.key, h.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (h) {
        return h.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (h) {
        return h.value;
      });
    };
    c.prototype.forEach = function (h, k) {
      for (var n = this.entries(), m; !(m = n.next()).done; )
        (m = m.value), h.call(k, m[1], m[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (h, k) {
        var n = k && typeof k;
        "object" == n || "function" == n
          ? b.has(k)
            ? (n = b.get(k))
            : ((n = "" + ++g), b.set(k, n))
          : (n = "p_" + k);
        var m = h[0][n];
        if (m && ia(h[0], n))
          for (h = 0; h < m.length; h++) {
            var r = m[h];
            if ((k !== k && r.key !== r.key) || k === r.key)
              return { id: n, list: m, index: h, pa: r };
          }
        return { id: n, list: m, index: -1, pa: void 0 };
      },
      e = function (h, k) {
        var n = h[1];
        return ea(function () {
          if (n) {
            for (; n.head != h[1]; ) n = n.Wa;
            for (; n.next != n.head; )
              return (n = n.next), { done: !1, value: k(n) };
            n = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      f = function () {
        var h = {};
        return (h.Wa = h.next = h.head = h);
      },
      g = 0;
    return c;
  });
  q("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  q("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return "number" !== typeof b
            ? !1
            : !isNaN(b) && Infinity !== b && -Infinity !== b;
        };
  });
  q("Number.isInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isFinite(b) ? b === Math.floor(b) : !1;
        };
  });
  q("Number.isSafeInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER;
        };
  });
  q("Math.trunc", function (a) {
    return a
      ? a
      : function (b) {
          b = Number(b);
          if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b)
            return b;
          var c = Math.floor(Math.abs(b));
          return 0 > b ? -c : c;
        };
  });
  q("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) ia(b, d) && c.push(b[d]);
          return c;
        };
  });
  q("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  q("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  var Ja = function (a, b, c) {
    if (null == a)
      throw new TypeError(
        "The 'this' value for String.prototype." +
          c +
          " must not be null or undefined"
      );
    if (b instanceof RegExp)
      throw new TypeError(
        "First argument to String.prototype." +
          c +
          " must not be a regular expression"
      );
    return a + "";
  };
  q("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return -1 !== Ja(this, b, "includes").indexOf(b, c || 0);
        };
  });
  q("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return "number" === typeof b && isNaN(b);
        };
  });
  var Ka = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var f = c++;
            return { value: b(f, a[f]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[Symbol.iterator] = function () {
      return e;
    };
    return e;
  };
  q("Array.prototype.entries", function (a) {
    return a
      ? a
      : function () {
          return Ka(this, function (b, c) {
            return [b, c];
          });
        };
  });
  q("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return Ka(this, function (b) {
            return b;
          });
        };
  });
  q("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return Ka(this, function (b, c) {
            return c;
          });
        };
  });
  q("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            null != c
              ? c
              : function (h) {
                  return h;
                };
          var e = [],
            f =
              "undefined" != typeof Symbol &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if ("function" == typeof f) {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, g++));
          } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
          return e;
        };
  });
  q("Set", function (a) {
    if (
      (function () {
        if (
          !a ||
          "function" != typeof a ||
          !a.prototype.entries ||
          "function" != typeof Object.seal
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(u([c]));
          if (
            !d.has(c) ||
            1 != d.size ||
            d.add(c) != d ||
            1 != d.size ||
            d.add({ x: 4 }) != d ||
            2 != d.size
          )
            return !1;
          var e = d.entries(),
            f = e.next();
          if (f.done || f.value[0] != c || f.value[1] != c) return !1;
          f = e.next();
          return f.done ||
            f.value[0] == c ||
            4 != f.value[0].x ||
            f.value[1] != f.value[0]
            ? !1
            : e.next().done;
        } catch (g) {
          return !1;
        }
      })()
    )
      return a;
    var b = function (c) {
      this.g = new Map();
      if (c) {
        c = u(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.g.size;
    };
    b.prototype.add = function (c) {
      c = 0 === c ? 0 : c;
      this.g.set(c, c);
      this.size = this.g.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.g.delete(c);
      this.size = this.g.size;
      return c;
    };
    b.prototype.clear = function () {
      this.g.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.g.has(c);
    };
    b.prototype.entries = function () {
      return this.g.entries();
    };
    b.prototype.values = function () {
      return this.g.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.g.forEach(function (f) {
        return c.call(d, f, f, e);
      });
    };
    return b;
  });
  q("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) ia(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  q("String.prototype.startsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ja(this, b, "startsWith");
          b += "";
          var e = d.length,
            f = b.length;
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var g = 0; g < f && c < e; ) if (d[c++] != b[g++]) return !1;
          return g >= f;
        };
  });
  q("String.prototype.repeat", function (a) {
    return a
      ? a
      : function (b) {
          var c = Ja(this, null, "repeat");
          if (0 > b || 1342177279 < b)
            throw new RangeError("Invalid count value");
          b |= 0;
          for (var d = ""; b; ) if ((b & 1 && (d += c), (b >>>= 1))) c += c;
          return d;
        };
  });
  q("globalThis", function (a) {
    return a || da;
  });
  q("String.prototype.padStart", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ja(this, null, "padStart");
          b -= d.length;
          c = void 0 !== c ? String(c) : " ";
          return (
            (0 < b && c
              ? c.repeat(Math.ceil(b / c.length)).substring(0, b)
              : "") + d
          );
        };
  });
  q("Math.imul", function (a) {
    return a
      ? a
      : function (b, c) {
          b = Number(b);
          c = Number(c);
          var d = b & 65535,
            e = c & 65535;
          return (
            (d * e +
              (((((b >>> 16) & 65535) * e + d * ((c >>> 16) & 65535)) << 16) >>>
                0)) |
            0
          );
        };
  });
  q("Object.fromEntries", function (a) {
    return a
      ? a
      : function (b) {
          var c = {};
          if (!(Symbol.iterator in b))
            throw new TypeError("" + b + " is not iterable");
          b = b[Symbol.iterator].call(b);
          for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            if (Object(d) !== d)
              throw new TypeError(
                "iterable for fromEntries should yield objects"
              );
            c[d[0]] = d[1];
          }
          return c;
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var La = La || {},
    x = this || self,
    z = function (a, b, c) {
      a = a.split(".");
      c = c || x;
      a[0] in c ||
        "undefined" == typeof c.execScript ||
        c.execScript("var " + a[0]);
      for (var d; a.length && (d = a.shift()); )
        a.length || void 0 === b
          ? c[d] && c[d] !== Object.prototype[d]
            ? (c = c[d])
            : (c = c[d] = {})
          : (c[d] = b);
    },
    Oa = function (a) {
      var b = Na("CLOSURE_FLAGS");
      a = b && b[a];
      return null != a ? a : !1;
    },
    Na = function (a, b) {
      a = a.split(".");
      b = b || x;
      for (var c = 0; c < a.length; c++)
        if (((b = b[a[c]]), null == b)) return null;
      return b;
    },
    Pa = function (a) {
      var b = typeof a;
      return "object" != b ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    },
    Qa = function (a) {
      var b = Pa(a);
      return "array" == b || ("object" == b && "number" == typeof a.length);
    },
    Ra = function (a) {
      var b = typeof a;
      return ("object" == b && null != a) || "function" == b;
    },
    Va = function (a) {
      return (
        (Object.prototype.hasOwnProperty.call(a, Sa) && a[Sa]) || (a[Sa] = ++Ua)
      );
    },
    Wa = function (a) {
      null !== a && "removeAttribute" in a && a.removeAttribute(Sa);
      try {
        delete a[Sa];
      } catch (b) {}
    },
    Sa = "closure_uid_" + ((1e9 * Math.random()) >>> 0),
    Ua = 0,
    Xa = function (a, b, c) {
      return a.call.apply(a.bind, arguments);
    },
    Ya = function (a, b, c) {
      if (!a) throw Error();
      if (2 < arguments.length) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function () {
          var e = Array.prototype.slice.call(arguments);
          Array.prototype.unshift.apply(e, d);
          return a.apply(b, e);
        };
      }
      return function () {
        return a.apply(b, arguments);
      };
    },
    Za = function (a, b, c) {
      Za =
        Function.prototype.bind &&
        -1 != Function.prototype.bind.toString().indexOf("native code")
          ? Xa
          : Ya;
      return Za.apply(null, arguments);
    },
    $a = function (a, b) {
      var c = Array.prototype.slice.call(arguments, 1);
      return function () {
        var d = c.slice();
        d.push.apply(d, arguments);
        return a.apply(this, d);
      };
    },
    bb = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.Fa = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.wi = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    },
    cb = function (a) {
      return a;
    };
  function db(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, db);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    void 0 !== b && (this.cause = b);
  }
  bb(db, Error);
  db.prototype.name = "CustomError";
  var eb;
  var fb,
    gb = "function" === typeof String.prototype.hg,
    ib = "undefined" !== typeof TextEncoder;
  function jb(a) {
    var b = !1;
    b = void 0 === b ? !1 : b;
    if (ib) {
      if (
        b &&
        (gb
          ? !a.hg()
          : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(
              a
            ))
      )
        throw Error("Found an unpaired surrogate");
      a = (fb || (fb = new TextEncoder())).encode(a);
    } else {
      for (
        var c = 0, d = new Uint8Array(3 * a.length), e = 0;
        e < a.length;
        e++
      ) {
        var f = a.charCodeAt(e);
        if (128 > f) d[c++] = f;
        else {
          if (2048 > f) d[c++] = (f >> 6) | 192;
          else {
            if (55296 <= f && 57343 >= f) {
              if (56319 >= f && e < a.length) {
                var g = a.charCodeAt(++e);
                if (56320 <= g && 57343 >= g) {
                  f = 1024 * (f - 55296) + g - 56320 + 65536;
                  d[c++] = (f >> 18) | 240;
                  d[c++] = ((f >> 12) & 63) | 128;
                  d[c++] = ((f >> 6) & 63) | 128;
                  d[c++] = (f & 63) | 128;
                  continue;
                } else e--;
              }
              if (b) throw Error("Found an unpaired surrogate");
              f = 65533;
            }
            d[c++] = (f >> 12) | 224;
            d[c++] = ((f >> 6) & 63) | 128;
          }
          d[c++] = (f & 63) | 128;
        }
      }
      a = c === d.length ? d : d.subarray(0, c);
    }
    return a;
  }
  function kb(a) {
    x.setTimeout(function () {
      throw a;
    }, 0);
  }
  var lb = function (a, b) {
      var c = a.length - b.length;
      return 0 <= c && a.indexOf(b, c) == c;
    },
    nb = function (a) {
      return /^[\s\xa0]*$/.test(a);
    },
    ob = String.prototype.trim
      ? function (a) {
          return a.trim();
        }
      : function (a) {
          return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
        },
    pb = function (a, b) {
      return -1 != a.indexOf(b);
    },
    qb = function (a, b) {
      return pb(a.toLowerCase(), b.toLowerCase());
    },
    sb = function (a, b) {
      var c = 0;
      a = ob(String(a)).split(".");
      b = ob(String(b)).split(".");
      for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
        var f = a[e] || "",
          g = b[e] || "";
        do {
          f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
          g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
          if (0 == f[0].length && 0 == g[0].length) break;
          c =
            rb(
              0 == f[1].length ? 0 : parseInt(f[1], 10),
              0 == g[1].length ? 0 : parseInt(g[1], 10)
            ) ||
            rb(0 == f[2].length, 0 == g[2].length) ||
            rb(f[2], g[2]);
          f = f[3];
          g = g[3];
        } while (0 == c);
      }
      return c;
    },
    rb = function (a, b) {
      return a < b ? -1 : a > b ? 1 : 0;
    };
  var tb = Oa(610401301),
    ub = Oa(188588736);
  function wb() {
    var a = x.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  var xb,
    yb = x.navigator;
  xb = yb ? yb.userAgentData || null : null;
  function zb(a) {
    return tb
      ? xb
        ? xb.brands.some(function (b) {
            return (b = b.brand) && pb(b, a);
          })
        : !1
      : !1;
  }
  function A(a) {
    return pb(wb(), a);
  }
  function Ab() {
    return tb ? !!xb && 0 < xb.brands.length : !1;
  }
  function Bb() {
    return Ab() ? !1 : A("Opera");
  }
  function Cb() {
    return Ab() ? !1 : A("Trident") || A("MSIE");
  }
  function Db() {
    return A("Firefox") || A("FxiOS");
  }
  function Eb() {
    return (
      A("Safari") &&
      !(
        Fb() ||
        (Ab() ? 0 : A("Coast")) ||
        Bb() ||
        (Ab() ? 0 : A("Edge")) ||
        (Ab() ? zb("Microsoft Edge") : A("Edg/")) ||
        (Ab() ? zb("Opera") : A("OPR")) ||
        Db() ||
        A("Silk") ||
        A("Android")
      )
    );
  }
  function Fb() {
    return Ab()
      ? zb("Chromium")
      : ((A("Chrome") || A("CriOS")) && !(Ab() ? 0 : A("Edge"))) || A("Silk");
  }
  function Gb() {
    return tb ? !!xb && !!xb.platform : !1;
  }
  function Hb() {
    return Gb() ? "Android" === xb.platform : A("Android");
  }
  function Kb() {
    return A("iPhone") && !A("iPod") && !A("iPad");
  }
  function Lb() {
    return Gb() ? "macOS" === xb.platform : A("Macintosh");
  }
  var Mb = function (a, b) {
      if ("string" === typeof a)
        return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
      for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
      return -1;
    },
    Nb = function (a, b) {
      for (
        var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        e in d && b.call(void 0, d[e], e, a);
    };
  function Ob(a, b) {
    for (
      var c = "string" === typeof a ? a.split("") : a, d = a.length - 1;
      0 <= d;
      --d
    )
      d in c && b.call(void 0, c[d], d, a);
  }
  var Pb = function (a, b) {
      for (
        var c = a.length,
          d = [],
          e = 0,
          f = "string" === typeof a ? a.split("") : a,
          g = 0;
        g < c;
        g++
      )
        if (g in f) {
          var h = f[g];
          b.call(void 0, h, g, a) && (d[e++] = h);
        }
      return d;
    },
    Qb = function (a, b) {
      for (
        var c = a.length,
          d = Array(c),
          e = "string" === typeof a ? a.split("") : a,
          f = 0;
        f < c;
        f++
      )
        f in e && (d[f] = b.call(void 0, e[f], f, a));
      return d;
    },
    Rb = function (a, b, c) {
      var d = c;
      Nb(a, function (e, f) {
        d = b.call(void 0, d, e, f, a);
      });
      return d;
    },
    Sb = function (a, b) {
      for (
        var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0;
        e < c;
        e++
      )
        if (e in d && b.call(void 0, d[e], e, a)) return !0;
      return !1;
    };
  function Tb(a, b) {
    b = Ub(a, b);
    return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b];
  }
  function Ub(a, b) {
    for (
      var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0;
      e < c;
      e++
    )
      if (e in d && b.call(void 0, d[e], e, a)) return e;
    return -1;
  }
  function Vb(a, b) {
    for (
      var c = "string" === typeof a ? a.split("") : a, d = a.length - 1;
      0 <= d;
      d--
    )
      if (d in c && b.call(void 0, c[d], d, a)) return d;
    return -1;
  }
  function Xb(a, b) {
    return 0 <= Mb(a, b);
  }
  function Yb(a, b) {
    b = Mb(a, b);
    var c;
    (c = 0 <= b) && Zb(a, b);
    return c;
  }
  function Zb(a, b) {
    return 1 == Array.prototype.splice.call(a, b, 1).length;
  }
  function $b(a, b) {
    var c = 0;
    Ob(a, function (d, e) {
      b.call(void 0, d, e, a) && Zb(a, e) && c++;
    });
  }
  function ac(a) {
    return Array.prototype.concat.apply([], arguments);
  }
  function bc(a) {
    var b = a.length;
    if (0 < b) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function cc(a) {
    for (var b = 0, c = 0, d = {}; c < a.length; ) {
      var e = a[c++],
        f = Ra(e) ? "o" + Va(e) : (typeof e).charAt(0) + e;
      Object.prototype.hasOwnProperty.call(d, f) || ((d[f] = !0), (a[b++] = e));
    }
    a.length = b;
  }
  function dc(a, b) {
    a.sort(b || ec);
  }
  function ec(a, b) {
    return a > b ? 1 : a < b ? -1 : 0;
  }
  function fc(a) {
    for (var b = [], c = 0; c < a; c++) b[c] = "";
    return b;
  }
  var gc = function (a) {
    gc[" "](a);
    return a;
  };
  gc[" "] = function () {};
  var hc = function (a, b) {
      try {
        return gc(a[b]), !0;
      } catch (c) {}
      return !1;
    },
    jc = function (a) {
      var b = ic;
      return Object.prototype.hasOwnProperty.call(b, 8) ? b[8] : (b[8] = a(8));
    };
  var kc = Bb(),
    lc = Cb(),
    mc = A("Edge"),
    nc =
      A("Gecko") &&
      !(qb(wb(), "WebKit") && !A("Edge")) &&
      !(A("Trident") || A("MSIE")) &&
      !A("Edge"),
    oc = qb(wb(), "WebKit") && !A("Edge"),
    pc = Lb(),
    qc = Hb(),
    rc = Kb(),
    sc = A("iPad"),
    tc = A("iPod"),
    uc = Kb() || A("iPad") || A("iPod"),
    vc;
  a: {
    var wc = "",
      xc = (function () {
        var a = wb();
        if (nc) return /rv:([^\);]+)(\)|;)/.exec(a);
        if (mc) return /Edge\/([\d\.]+)/.exec(a);
        if (lc) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
        if (oc) return /WebKit\/(\S+)/.exec(a);
        if (kc) return /(?:Version)[ \/]?(\S+)/.exec(a);
      })();
    xc && (wc = xc ? xc[1] : "");
    if (lc) {
      var yc,
        zc = x.document;
      yc = zc ? zc.documentMode : void 0;
      if (null != yc && yc > parseFloat(wc)) {
        vc = String(yc);
        break a;
      }
    }
    vc = wc;
  }
  var Ac = vc,
    ic = {},
    Bc = function () {
      return jc(function () {
        return 0 <= sb(Ac, 8);
      });
    };
  var Cc = Db(),
    Dc = A("Android") && !(Fb() || Db() || Bb() || A("Silk")),
    Ec = Fb();
  Eb();
  var Fc = {},
    Gc = null,
    Ic = function (a, b) {
      void 0 === b && (b = 0);
      Hc();
      b = Fc[b];
      for (
        var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0;
        e < a.length - 2;
        e += 3
      ) {
        var g = a[e],
          h = a[e + 1],
          k = a[e + 2],
          n = b[g >> 2];
        g = b[((g & 3) << 4) | (h >> 4)];
        h = b[((h & 15) << 2) | (k >> 6)];
        k = b[k & 63];
        c[f++] = "" + n + g + h + k;
      }
      n = 0;
      k = d;
      switch (a.length - e) {
        case 2:
          (n = a[e + 1]), (k = b[(n & 15) << 2] || d);
        case 1:
          (a = a[e]),
            (c[f] = "" + b[a >> 2] + b[((a & 3) << 4) | (n >> 4)] + k + d);
      }
      return c.join("");
    },
    Kc = function (a) {
      var b = [];
      Jc(a, function (c) {
        b.push(c);
      });
      return b;
    },
    Jc = function (a, b) {
      function c(k) {
        for (; d < a.length; ) {
          var n = a.charAt(d++),
            m = Gc[n];
          if (null != m) return m;
          if (!nb(n)) throw Error("Unknown base64 encoding at char: " + n);
        }
        return k;
      }
      Hc();
      for (var d = 0; ; ) {
        var e = c(-1),
          f = c(0),
          g = c(64),
          h = c(64);
        if (64 === h && -1 === e) break;
        b((e << 2) | (f >> 4));
        64 != g &&
          (b(((f << 4) & 240) | (g >> 2)), 64 != h && b(((g << 6) & 192) | h));
      }
    },
    Hc = function () {
      if (!Gc) {
        Gc = {};
        for (
          var a =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
                ""
              ),
            b = ["+/=", "+/", "-_=", "-_.", "-_"],
            c = 0;
          5 > c;
          c++
        ) {
          var d = a.concat(b[c].split(""));
          Fc[c] = d;
          for (var e = 0; e < d.length; e++) {
            var f = d[e];
            void 0 === Gc[f] && (Gc[f] = e);
          }
        }
      }
    };
  var Lc = "undefined" !== typeof Uint8Array,
    Mc = !lc && "function" === typeof btoa;
  function Nc() {
    return "function" === typeof BigInt;
  }
  var Qc = 0,
    Rc = 0,
    Sc;
  function Tc(a) {
    var b = 0 > a;
    a = Math.abs(a);
    var c = a >>> 0;
    a = Math.floor((a - c) / 4294967296);
    b &&
      ((c = u(Uc(c, a))), (b = c.next().value), (a = c.next().value), (c = b));
    Qc = c >>> 0;
    Rc = a >>> 0;
  }
  function Vc(a, b) {
    b >>>= 0;
    a >>>= 0;
    if (2097151 >= b) var c = "" + (4294967296 * b + a);
    else
      Nc()
        ? (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)))
        : ((c = ((a >>> 24) | (b << 8)) & 16777215),
          (b = (b >> 16) & 65535),
          (a = (a & 16777215) + 6777216 * c + 6710656 * b),
          (c += 8147497 * b),
          (b *= 2),
          1e7 <= a && ((c += Math.floor(a / 1e7)), (a %= 1e7)),
          1e7 <= c && ((b += Math.floor(c / 1e7)), (c %= 1e7)),
          (c = b + Wc(c) + Wc(a)));
    return c;
  }
  function Wc(a) {
    a = String(a);
    return "0000000".slice(a.length) + a;
  }
  function Xc() {
    var a = Qc,
      b = Rc;
    b & 2147483648
      ? Nc()
        ? (a = "" + ((BigInt(b | 0) << BigInt(32)) | BigInt(a >>> 0)))
        : ((b = u(Uc(a, b))),
          (a = b.next().value),
          (b = b.next().value),
          (a = "-" + Vc(a, b)))
      : (a = Vc(a, b));
    return a;
  }
  function Yc(a) {
    if (16 > a.length) Tc(Number(a));
    else if (Nc())
      (a = BigInt(a)),
        (Qc = Number(a & BigInt(4294967295)) >>> 0),
        (Rc = Number((a >> BigInt(32)) & BigInt(4294967295)));
    else {
      var b = +("-" === a[0]);
      Rc = Qc = 0;
      for (
        var c = a.length, d = 0 + b, e = ((c - b) % 6) + b;
        e <= c;
        d = e, e += 6
      )
        (d = Number(a.slice(d, e))),
          (Rc *= 1e6),
          (Qc = 1e6 * Qc + d),
          4294967296 <= Qc &&
            ((Rc += Math.trunc(Qc / 4294967296)), (Rc >>>= 0), (Qc >>>= 0));
      b &&
        ((b = u(Uc(Qc, Rc))),
        (a = b.next().value),
        (b = b.next().value),
        (Qc = a),
        (Rc = b));
    }
  }
  function Uc(a, b) {
    b = ~b;
    a ? (a = ~a + 1) : (b += 1);
    return [a, b];
  }
  var Zc = function (a, b) {
      this.j = a >>> 0;
      this.g = b >>> 0;
    },
    ad = function (a) {
      if (!a) return $c || ($c = new Zc(0, 0));
      if (!/^\d+$/.test(a)) return null;
      Yc(a);
      return new Zc(Qc, Rc);
    },
    $c,
    bd = function (a, b) {
      this.j = a >>> 0;
      this.g = b >>> 0;
    },
    dd = function (a) {
      if (!a) return cd || (cd = new bd(0, 0));
      if (!/^-?\d+$/.test(a)) return null;
      Yc(a);
      return new bd(Qc, Rc);
    },
    cd;
  var ed = function () {
    this.g = [];
  };
  ed.prototype.length = function () {
    return this.g.length;
  };
  ed.prototype.end = function () {
    var a = this.g;
    this.g = [];
    return a;
  };
  var fd = function (a, b, c) {
      for (; 0 < c || 127 < b; )
        a.g.push((b & 127) | 128),
          (b = ((b >>> 7) | (c << 25)) >>> 0),
          (c >>>= 7);
      a.g.push(b);
    },
    gd = function (a, b) {
      for (; 127 < b; ) a.g.push((b & 127) | 128), (b >>>= 7);
      a.g.push(b);
    },
    hd = function (a, b) {
      if (0 <= b) gd(a, b);
      else {
        for (var c = 0; 9 > c; c++) a.g.push((b & 127) | 128), (b >>= 7);
        a.g.push(1);
      }
    },
    id = function (a, b) {
      a.g.push((b >>> 0) & 255);
      a.g.push((b >>> 8) & 255);
      a.g.push((b >>> 16) & 255);
      a.g.push((b >>> 24) & 255);
    };
  var jd = function () {
      this.l = [];
      this.j = 0;
      this.g = new ed();
    },
    kd = function (a, b) {
      0 !== b.length && (a.l.push(b), (a.j += b.length));
    },
    md = function (a, b) {
      ld(a, b, 2);
      b = a.g.end();
      kd(a, b);
      b.push(a.j);
      return b;
    },
    nd = function (a, b) {
      var c = b.pop();
      for (c = a.j + a.g.length() - c; 127 < c; )
        b.push((c & 127) | 128), (c >>>= 7), a.j++;
      b.push(c);
      a.j++;
    },
    od = function (a) {
      kd(a, a.g.end());
      for (
        var b = new Uint8Array(a.j), c = a.l, d = c.length, e = 0, f = 0;
        f < d;
        f++
      ) {
        var g = c[f];
        b.set(g, e);
        e += g.length;
      }
      a.l = [b];
      return b;
    },
    ld = function (a, b, c) {
      gd(a.g, 8 * b + c);
    },
    pd = function (a, b, c) {
      ld(a, b, 2);
      gd(a.g, c.length);
      kd(a, a.g.end());
      kd(a, c);
    },
    qd = function (a, b, c, d) {
      null != c && ((b = md(a, b)), d(c, a), nd(a, b));
    },
    sd = function (a, b, c) {
      var d = rd;
      if (null != c)
        for (var e = 0; e < c.length; e++) {
          var f = md(a, b);
          d(c[e], a);
          nd(a, f);
        }
    };
  var td = function (a, b) {
    this.g = a;
    this.Te = b;
  };
  function ud(a) {
    return Array.prototype.slice.call(a);
  }
  function vd(a) {
    return "function" === typeof Symbol && "symbol" === typeof Symbol()
      ? Symbol()
      : a;
  }
  var wd = vd(),
    xd = vd("0di"),
    yd = vd("2ex"),
    zd = vd("0dg");
  var Ad = wd
      ? function (a, b) {
          a[wd] |= b;
        }
      : function (a, b) {
          void 0 !== a.Ba
            ? (a.Ba |= b)
            : Object.defineProperties(a, {
                Ba: {
                  value: b,
                  configurable: !0,
                  writable: !0,
                  enumerable: !1,
                },
              });
        },
    Bd = wd
      ? function (a, b) {
          a[wd] &= ~b;
        }
      : function (a, b) {
          void 0 !== a.Ba && (a.Ba &= ~b);
        };
  function Cd(a, b, c) {
    return c ? a | b : a & ~b;
  }
  var Dd = wd
      ? function (a) {
          return a[wd] | 0;
        }
      : function (a) {
          return a.Ba | 0;
        },
    Ed = wd
      ? function (a) {
          return a[wd];
        }
      : function (a) {
          return a.Ba;
        },
    Fd = wd
      ? function (a, b) {
          a[wd] = b;
          return a;
        }
      : function (a, b) {
          void 0 !== a.Ba
            ? (a.Ba = b)
            : Object.defineProperties(a, {
                Ba: {
                  value: b,
                  configurable: !0,
                  writable: !0,
                  enumerable: !1,
                },
              });
          return a;
        };
  function Gd(a) {
    Ad(a, 34);
    return a;
  }
  function Hd(a) {
    Ad(a, 32);
    return a;
  }
  function Id(a, b) {
    Fd(b, (a | 0) & -14591);
  }
  function Jd(a, b) {
    Fd(b, (a | 34) & -14557);
  }
  function Kd(a) {
    a = (a >> 14) & 1023;
    return 0 === a ? 536870912 : a;
  }
  var Ld = {},
    Md = {};
  function Nd(a) {
    return !(!a || "object" !== typeof a || a.ig !== Md);
  }
  function Od(a) {
    return (
      null !== a &&
      "object" === typeof a &&
      !Array.isArray(a) &&
      a.constructor === Object
    );
  }
  var Pd;
  function Qd(a, b, c) {
    if (!Array.isArray(a) || a.length) return !1;
    var d = Dd(a);
    if (d & 1) return !0;
    if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
    Fd(a, d | 1);
    return !0;
  }
  var Rd,
    Sd = [];
  Fd(Sd, 55);
  Rd = Object.freeze(Sd);
  function Td(a) {
    if (a & 2) throw Error();
  }
  var Ud = function (a, b, c) {
    this.l = 0;
    this.g = a;
    this.j = b;
    this.A = c;
  };
  Ud.prototype.next = function () {
    if (this.l < this.g.length) {
      var a = this.g[this.l++];
      return { done: !1, value: this.j ? this.j.call(this.A, a) : a };
    }
    return { done: !0, value: void 0 };
  };
  Ud.prototype[Symbol.iterator] = function () {
    return new Ud(this.g, this.j, this.A);
  };
  Object.freeze(new (function () {})());
  Object.freeze(new (function () {})());
  var Vd = function (a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  };
  var Wd;
  function Xd() {
    var a = Error();
    Vd(a, "incident");
    kb(a);
  }
  function Yd(a) {
    a = Error(a);
    Vd(a, "warning");
    return a;
  }
  function Zd(a) {
    if (null == a || "number" === typeof a) return a;
    if ("NaN" === a || "Infinity" === a || "-Infinity" === a) return Number(a);
  }
  function $d(a) {
    if ("boolean" !== typeof a)
      throw Error("Expected boolean but got " + Pa(a) + ": " + a);
    return a;
  }
  function ae(a) {
    return null == a ? a : $d(a);
  }
  function be(a) {
    if (null == a || "boolean" === typeof a) return a;
    if ("number" === typeof a) return !!a;
  }
  var ce = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function de(a) {
    var b = typeof a;
    return "number" === b
      ? Number.isFinite(a)
      : "string" !== b
      ? !1
      : ce.test(a);
  }
  function ee(a) {
    if (!Number.isFinite(a)) throw Yd("enum");
    return a | 0;
  }
  function fe(a) {
    return null == a ? a : ee(a);
  }
  function ge(a) {
    return null == a ? a : Number.isFinite(a) ? a | 0 : void 0;
  }
  function he(a) {
    if ("number" !== typeof a) throw Yd("int32");
    if (!Number.isFinite(a)) throw Yd("int32");
    return a | 0;
  }
  function ie(a) {
    return null == a ? a : he(a);
  }
  function je(a) {
    if (null == a) return a;
    if ("string" === typeof a) {
      if (!a) return;
      a = +a;
    }
    if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0;
  }
  function ke(a) {
    if (null == a) return a;
    if ("string" === typeof a) {
      if (!a) return;
      a = +a;
    }
    if ("number" === typeof a) return Number.isFinite(a) ? a >>> 0 : void 0;
  }
  function le(a) {
    if (null != a) {
      var b = !!b;
      if (!de(a)) throw Yd("int64");
      a = "string" === typeof a ? me(a) : b ? ne(a) : oe(a);
    }
    return a;
  }
  function pe(a) {
    return "-" === a[0]
      ? !1
      : 20 > a.length
      ? !0
      : 20 === a.length && 184467 > Number(a.substring(0, 6));
  }
  function qe(a) {
    return "-" === a[0]
      ? 20 > a.length
        ? !0
        : 20 === a.length && -922337 < Number(a.substring(0, 7))
      : 19 > a.length
      ? !0
      : 19 === a.length && 922337 > Number(a.substring(0, 6));
  }
  function re(a) {
    if (0 > a) {
      Tc(a);
      var b = Vc(Qc, Rc);
      a = Number(b);
      return Number.isSafeInteger(a) ? a : b;
    }
    if (pe(String(a))) return a;
    Tc(a);
    return 4294967296 * Rc + (Qc >>> 0);
  }
  function oe(a) {
    a = Math.trunc(a);
    if (!Number.isSafeInteger(a)) {
      Tc(a);
      var b = Qc,
        c = Rc;
      if ((a = c & 2147483648))
        (b = (~b + 1) >>> 0), (c = ~c >>> 0), 0 == b && (c = (c + 1) >>> 0);
      b = 4294967296 * c + (b >>> 0);
      a = a ? -b : b;
    }
    return a;
  }
  function ne(a) {
    a = Math.trunc(a);
    if (Number.isSafeInteger(a)) a = String(a);
    else {
      var b = String(a);
      qe(b) ? (a = b) : (Tc(a), (a = Xc()));
    }
    return a;
  }
  function me(a) {
    var b = Math.trunc(Number(a));
    if (Number.isSafeInteger(b)) return String(b);
    b = a.indexOf(".");
    -1 !== b && (a = a.substring(0, b));
    qe(a) || (Yc(a), (a = Xc()));
    return a;
  }
  function se(a) {
    if ("string" !== typeof a) throw Error();
    return a;
  }
  function te(a) {
    if (null != a && "string" !== typeof a) throw Error();
    return a;
  }
  function ue(a) {
    return null == a || "string" === typeof a ? a : void 0;
  }
  function ve(a, b, c, d) {
    if (null != a && "object" === typeof a && a.yd === Ld) return a;
    if (!Array.isArray(a)) return c ? (d & 2 ? we(b) : new b()) : void 0;
    var e = (c = Dd(a));
    0 === e && (e |= d & 32);
    e |= d & 2;
    e !== c && Fd(a, e);
    return new b(a);
  }
  function we(a) {
    var b = a[xd];
    if (b) return b;
    b = new a();
    Gd(b.K);
    return (a[xd] = b);
  }
  function xe(a, b, c) {
    if (b) return $d(a);
    var d;
    return null != (d = be(a)) ? d : c ? !1 : void 0;
  }
  function ye(a, b, c) {
    if (b) return se(a);
    var d;
    return null != (d = ue(a)) ? d : c ? "" : void 0;
  }
  var ze;
  function Ae(a, b) {
    ze = b;
    a = new a(b);
    ze = void 0;
    return a;
  }
  var Be, Ce;
  function De(a) {
    switch (typeof a) {
      case "boolean":
        return Be || (Be = [0, void 0, !0]);
      case "number":
        return 0 < a
          ? void 0
          : 0 === a
          ? Ce || (Ce = [0, void 0])
          : [-a, void 0];
      case "string":
        return [0, a];
      case "object":
        return a;
    }
  }
  function B(a, b, c) {
    null == a && (a = ze);
    ze = void 0;
    if (null == a) {
      var d = 96;
      c ? ((a = [c]), (d |= 512)) : (a = []);
      b && (d = (d & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      d = Dd(a);
      if (d & 2048) throw Error("farr");
      if (d & 64) return a;
      d |= 64;
      if (c && ((d |= 512), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        var e = c.length;
        if (e) {
          var f = e - 1;
          if (Od(c[f])) {
            d |= 256;
            b = f - (+!!(d & 512) - 1);
            if (1024 <= b) throw Error("pvtlmt");
            d = (d & -16760833) | ((b & 1023) << 14);
            break a;
          }
        }
        if (b) {
          b = Math.max(b, e - (+!!(d & 512) - 1));
          if (1024 < b) throw Error("spvt");
          d = (d & -16760833) | ((b & 1023) << 14);
        }
      }
    }
    Fd(a, d);
    return a;
  }
  var Ee = {},
    Fe = (function () {
      try {
        var a = function () {
          return na(Map, [], this.constructor);
        };
        v(a, Map);
        gc(new a());
        return !1;
      } catch (b) {
        return !0;
      }
    })(),
    Ge = function () {
      this.g = new Map();
    };
  l = Ge.prototype;
  l.get = function (a) {
    return this.g.get(a);
  };
  l.set = function (a, b) {
    this.g.set(a, b);
    this.size = this.g.size;
    return this;
  };
  l.delete = function (a) {
    a = this.g.delete(a);
    this.size = this.g.size;
    return a;
  };
  l.clear = function () {
    this.g.clear();
    this.size = this.g.size;
  };
  l.has = function (a) {
    return this.g.has(a);
  };
  l.entries = function () {
    return this.g.entries();
  };
  l.keys = function () {
    return this.g.keys();
  };
  l.values = function () {
    return this.g.values();
  };
  l.forEach = function (a, b) {
    return this.g.forEach(a, b);
  };
  Ge.prototype[Symbol.iterator] = function () {
    return this.entries();
  };
  var He = (function () {
    if (Fe)
      return (
        Object.setPrototypeOf(Ge.prototype, Map.prototype),
        Object.defineProperties(Ge.prototype, {
          size: { value: 0, configurable: !0, enumerable: !0, writable: !0 },
        }),
        Ge
      );
    var a = function () {
      return na(Map, [], this.constructor);
    };
    v(a, Map);
    return a;
  })();
  function Ie(a) {
    return a;
  }
  var Ke = function (a, b, c, d) {
    c = void 0 === c ? Ie : c;
    d = void 0 === d ? Ie : d;
    var e = He.call(this) || this;
    var f = Dd(a);
    f |= 64;
    Fd(a, f);
    e.Lb = f;
    e.bd = b;
    e.Wb = c;
    e.Wd = e.bd ? Je : d;
    for (var g = 0; g < a.length; g++) {
      var h = a[g],
        k = c(h[0], !1, !0),
        n = h[1];
      b ? void 0 === n && (n = null) : (n = d(h[1], !1, !0, void 0, void 0, f));
      He.prototype.set.call(e, k, n);
    }
    return e;
  };
  v(Ke, He);
  var Le = function (a) {
      if (a.Lb & 2) throw Error("Cannot mutate an immutable Map");
    },
    Oe = function (a, b) {
      b = void 0 === b ? Me : b;
      if (0 !== a.size) return Ne(a, b);
    },
    Ne = function (a, b) {
      b = void 0 === b ? Me : b;
      var c = [];
      a = He.prototype.entries.call(a);
      for (var d; !(d = a.next()).done; )
        (d = d.value), (d[0] = b(d[0])), (d[1] = b(d[1])), c.push(d);
      return c;
    };
  l = Ke.prototype;
  l.clear = function () {
    Le(this);
    He.prototype.clear.call(this);
  };
  l.delete = function (a) {
    Le(this);
    return He.prototype.delete.call(this, this.Wb(a, !0, !1));
  };
  l.entries = function () {
    var a = Array.from(He.prototype.keys.call(this));
    return new Ud(a, Pe, this);
  };
  l.keys = function () {
    return He.prototype.keys.call(this);
  };
  l.values = function () {
    var a = Array.from(He.prototype.keys.call(this));
    return new Ud(a, Ke.prototype.get, this);
  };
  l.forEach = function (a, b) {
    var c = this;
    He.prototype.forEach.call(this, function (d, e) {
      a.call(b, c.get(e), e, c);
    });
  };
  l.set = function (a, b) {
    Le(this);
    a = this.Wb(a, !0, !1);
    return null == a
      ? this
      : null == b
      ? (He.prototype.delete.call(this, a), this)
      : He.prototype.set.call(
          this,
          a,
          this.Wd(b, !0, !0, this.bd, !1, this.Lb)
        );
  };
  l.has = function (a) {
    return He.prototype.has.call(this, this.Wb(a, !1, !1));
  };
  l.get = function (a) {
    a = this.Wb(a, !1, !1);
    var b = He.prototype.get.call(this, a);
    if (void 0 !== b) {
      var c = this.bd;
      return c
        ? ((c = this.Wd(b, !1, !0, c, this.Ff, this.Lb)),
          c !== b && He.prototype.set.call(this, a, c),
          c)
        : b;
    }
  };
  Ke.prototype[Symbol.iterator] = function () {
    return this.entries();
  };
  Ke.prototype.toJSON = void 0;
  Ke.prototype.ig = Md;
  function Je(a, b, c, d, e, f) {
    a = ve(a, d, c, f);
    e && (a = Qe(a));
    return a;
  }
  function Me(a) {
    return a;
  }
  function Pe(a) {
    return [a, this.get(a)];
  }
  var Re;
  function Se() {
    return Re || (Re = new Ke(Gd([]), void 0, void 0, void 0, Ee));
  }
  function Te(a, b) {
    return Ue(b);
  }
  function Ue(a) {
    switch (typeof a) {
      case "number":
        return isFinite(a) ? a : String(a);
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (a)
          if (Array.isArray(a)) {
            if (Qd(a, void 0, 0)) return;
          } else {
            if (Lc && null != a && a instanceof Uint8Array) {
              if (Mc) {
                for (var b = "", c = 0, d = a.length - 10240; c < d; )
                  b += String.fromCharCode.apply(
                    null,
                    a.subarray(c, (c += 10240))
                  );
                b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                a = btoa(b);
              } else a = Ic(a);
              return a;
            }
            if (a instanceof Ke) return Oe(a);
          }
    }
    return a;
  }
  function Ve(a, b, c) {
    a = ud(a);
    var d = a.length,
      e = b & 256 ? a[d - 1] : void 0;
    d += e ? -1 : 0;
    for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
    if (e) {
      b = a[b] = {};
      for (var f in e) b[f] = c(e[f]);
    }
    return a;
  }
  function We(a, b, c, d, e) {
    if (null != a) {
      if (Array.isArray(a))
        a = Qd(a, void 0, 0)
          ? void 0
          : e && Dd(a) & 2
          ? a
          : Xe(a, b, c, void 0 !== d, e);
      else if (Od(a)) {
        var f = {},
          g;
        for (g in a) f[g] = We(a[g], b, c, d, e);
        a = f;
      } else a = b(a, d);
      return a;
    }
  }
  function Xe(a, b, c, d, e) {
    var f = d || c ? Dd(a) : 0;
    d = d ? !!(f & 32) : void 0;
    a = ud(a);
    for (var g = 0; g < a.length; g++) a[g] = We(a[g], b, c, d, e);
    c && c(f, a);
    return a;
  }
  function Ye(a) {
    return We(a, Ze, void 0, void 0, !1);
  }
  function Ze(a) {
    return a.yd === Ld ? a.toJSON() : a instanceof Ke ? Oe(a, Ye) : Ue(a);
  }
  function $e(a, b, c) {
    c = void 0 === c ? Jd : c;
    if (null != a) {
      if (Lc && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
      if (Array.isArray(a)) {
        var d = Dd(a);
        if (d & 2) return a;
        b && (b = 0 === d || (!!(d & 32) && !(d & 64 || !(d & 16))));
        return b ? Fd(a, (d | 34) & -12293) : Xe(a, $e, d & 4 ? Jd : c, !0, !0);
      }
      a.yd === Ld
        ? ((c = a.K),
          (d = Ed(c)),
          (a = d & 2 ? a : Ae(a.constructor, af(c, d, !0))))
        : a instanceof Ke &&
          !(a.Lb & 2) &&
          ((c = Gd(Ne(a, $e))), (a = new Ke(c, a.bd, a.Wb, a.Wd)));
      return a;
    }
  }
  function af(a, b, c) {
    var d = c || b & 2 ? Jd : Id,
      e = !!(b & 32);
    a = Ve(a, b, function (f) {
      return $e(f, e, d);
    });
    Ad(a, 32 | (c ? 2 : 0));
    return a;
  }
  function Qe(a) {
    var b = a.K,
      c = Ed(b);
    return c & 2 ? Ae(a.constructor, af(b, c, !1)) : a;
  }
  function bf(a, b, c, d) {
    if (!(4 & b)) return !0;
    if (null == c) return !1;
    !d &&
      0 === c &&
      (4096 & b || 8192 & b) &&
      5 > (a.constructor[zd] = (a.constructor[zd] | 0) + 1) &&
      Xd();
    return 0 === c ? !1 : !(c & b);
  }
  var df = function (a, b) {
    a = a.K;
    return cf(a, Ed(a), b);
  };
  function ef(a, b, c, d) {
    b = d + (+!!(b & 512) - 1);
    if (!(0 > b || b >= a.length || b >= c)) return a[b];
  }
  var cf = function (a, b, c, d) {
      if (-1 === c) return null;
      var e = Kd(b);
      if (c >= e) {
        if (b & 256) return a[a.length - 1][c];
      } else {
        var f = a.length;
        if (d && b & 256 && ((d = a[f - 1][c]), null != d)) {
          if (ef(a, b, e, c) && null != yd) {
            var g;
            a = null != (g = Wd) ? g : (Wd = {});
            g = a[yd] || 0;
            4 <= g || ((a[yd] = g + 1), Xd());
          }
          return d;
        }
        return ef(a, b, e, c);
      }
    },
    C = function (a, b, c) {
      var d = a.K,
        e = Ed(d);
      Td(e);
      ff(d, e, b, c);
      return a;
    };
  function ff(a, b, c, d, e) {
    var f = Kd(b);
    if (c >= f || e) {
      var g = b;
      if (b & 256) e = a[a.length - 1];
      else {
        if (null == d) return g;
        e = a[f + (+!!(b & 512) - 1)] = {};
        g |= 256;
      }
      e[c] = d;
      c < f && (a[c + (+!!(b & 512) - 1)] = void 0);
      g !== b && Fd(a, g);
      return g;
    }
    a[c + (+!!(b & 512) - 1)] = d;
    b & 256 && ((a = a[a.length - 1]), c in a && delete a[c]);
    return b;
  }
  function gf(a, b, c) {
    var d = a.K,
      e = Ed(d),
      f = 2 & e ? 1 : 2,
      g = hf(d, e, b),
      h = Dd(g);
    if (bf(a, h, void 0, !1)) {
      if (4 & h || Object.isFrozen(g))
        (g = ud(g)), (h = jf(h, e)), (e = ff(d, e, b, g));
      for (var k = (a = 0); a < g.length; a++) {
        var n = c(g[a]);
        null != n && (g[k++] = n);
      }
      k < a && (g.length = k);
      h = kf(h, e);
      h = Cd(h, 20, !0);
      h = Cd(h, 4096, !1);
      h = Cd(h, 8192, !1);
      Fd(g, h);
      2 & h && Object.freeze(g);
    }
    lf(h) ||
      ((c = h),
      (a = 1 === f)
        ? (32 & h || ((g = ud(g)), (c = 0), (e = ff(d, e, b, g))),
          (h = Cd(h, 2, !0)))
        : (h = mf(h, e, !1)),
      h !== c && Fd(g, h),
      a && Object.freeze(g));
    2 === f &&
      lf(h) &&
      ((g = ud(g)),
      (h = jf(h, e)),
      (h = mf(h, e, !1)),
      Fd(g, h),
      ff(d, e, b, g));
    return g;
  }
  function hf(a, b, c) {
    a = cf(a, b, c);
    return Array.isArray(a) ? a : Rd;
  }
  function kf(a, b) {
    0 === a && (a = jf(a, b));
    return (a = Cd(a, 1, !0));
  }
  function lf(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(2048 & a);
  }
  function nf(a, b, c, d, e, f) {
    var g = b & 2;
    a: {
      var h = c,
        k = b & 2;
      c = !1;
      if (null == h) {
        if (k) {
          a = Se();
          break a;
        }
        h = [];
      } else if (h.constructor === Ke) {
        if (0 == (h.Lb & 2) || k) {
          a = h;
          break a;
        }
        h = Ne(h);
      } else Array.isArray(h) ? (c = !!(Dd(h) & 2)) : (h = []);
      if (k) {
        if (!h.length) {
          a = Se();
          break a;
        }
        c || ((c = !0), Gd(h));
      } else if (c) {
        c = !1;
        k = ud(h);
        for (h = 0; h < k.length; h++) {
          var n = (k[h] = ud(k[h]));
          Array.isArray(n[1]) && (n[1] = Gd(n[1]));
        }
        h = k;
      }
      c || (Dd(h) & 64 ? Bd(h, 32) : 32 & b && Hd(h));
      f = new Ke(h, e, ye, f);
      ff(a, b, d, f, !1);
      a = f;
    }
    if (null == a) return a;
    !g && e && (a.Ff = !0);
    return a;
  }
  function of(a, b, c) {
    a = a.K;
    var d = Ed(a);
    return nf(a, d, cf(a, d, b), b, void 0, c);
  }
  function pf(a, b, c, d) {
    var e = a.K,
      f = Ed(e);
    Td(f);
    if (null == c) return ff(e, f, b), a;
    var g = Dd(c),
      h = g,
      k = !!(2 & g) || Object.isFrozen(c),
      n = !k && !1;
    if (bf(a, g))
      for (
        g = 21,
          k && ((c = ud(c)), (h = 0), (g = jf(g, f)), (g = mf(g, f, !0))),
          k = 0;
        k < c.length;
        k++
      )
        c[k] = d(c[k]);
    n && ((c = ud(c)), (h = 0), (g = jf(g, f)), (g = mf(g, f, !0)));
    g !== h && Fd(c, g);
    ff(e, f, b, c);
    return a;
  }
  function D(a, b, c, d) {
    var e = a.K,
      f = Ed(e);
    Td(f);
    ff(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
    return a;
  }
  var qf = function (a, b, c, d) {
    var e = a.K,
      f = Ed(e);
    Td(f);
    for (var g = f, h = 0, k = 0; k < c.length; k++) {
      var n = c[k];
      null != cf(e, g, n) && (0 !== h && (g = ff(e, g, h)), (h = n));
    }
    (c = h) && c !== b && null != d && (f = ff(e, f, c));
    ff(e, f, b, d);
    return a;
  };
  function rf(a, b, c, d) {
    a = a.K;
    var e = Ed(a),
      f = cf(a, e, c, d);
    b = ve(f, b, !1, e);
    b !== f && null != b && ff(a, e, c, b, d);
    return b;
  }
  var sf = function (a, b) {
      return (a = rf(a, b, 5, !1)) ? a : we(b);
    },
    tf = function (a, b, c) {
      var d = void 0 === d ? !1 : d;
      b = rf(a, b, c, d);
      if (null == b) return b;
      a = a.K;
      var e = Ed(a);
      if (!(e & 2)) {
        var f = Qe(b);
        f !== b && ((b = f), ff(a, e, c, b, d));
      }
      return b;
    };
  function uf(a, b, c, d, e, f) {
    var g = !!(2 & b),
      h = g ? 1 : 2,
      k = 1 === h;
    h = 2 === h;
    e = !!e;
    f && (f = !g);
    g = hf(a, b, d);
    var n = Dd(g),
      m = !!(4 & n);
    if (!m) {
      n = kf(n, b);
      var r = g,
        p = b,
        t;
      (t = !!(2 & n)) && (p = Cd(p, 2, !0));
      for (var w = !t, y = !0, R = 0, ka = 0; R < r.length; R++) {
        var ua = ve(r[R], c, !1, p);
        if (ua instanceof c) {
          if (!t) {
            var pa = !!(Dd(ua.K) & 2);
            w && (w = !pa);
            y && (y = pa);
          }
          r[ka++] = ua;
        }
      }
      ka < R && (r.length = ka);
      n = Cd(n, 4, !0);
      n = Cd(n, 16, y);
      n = Cd(n, 8, w);
      Fd(r, n);
      t && Object.freeze(r);
    }
    c = !!(8 & n) || (k && !g.length);
    if (f && !c) {
      lf(n) && ((g = ud(g)), (n = jf(n, b)), (b = ff(a, b, d, g)));
      f = g;
      c = n;
      for (r = 0; r < f.length; r++)
        (n = f[r]), (p = Qe(n)), n !== p && (f[r] = p);
      c = Cd(c, 8, !0);
      c = Cd(c, 16, !f.length);
      Fd(f, c);
      n = c;
    }
    lf(n) ||
      ((f = n),
      k
        ? ((c = !!(32 & n)),
          c || ((g = ud(g)), (f = 0), (b = ff(a, b, d, g))),
          (n = Cd(n, !g.length || (16 & n && (!m || c)) ? 2 : 2048, !0)))
        : (n = mf(n, b, e)),
      n !== f && Fd(g, n),
      k && Object.freeze(g));
    h &&
      lf(n) &&
      ((g = ud(g)),
      (n = jf(n, b)),
      (n = mf(n, b, e)),
      Fd(g, n),
      ff(a, b, d, g));
    return g;
  }
  var vf = function (a, b, c) {
      a = a.K;
      var d = Ed(a);
      return uf(a, d, b, c, !1, !(2 & d));
    },
    wf = function (a, b, c) {
      null == c && (c = void 0);
      return C(a, b, c);
    },
    xf = function (a, b, c) {
      var d = a.K,
        e = Ed(d);
      Td(e);
      if (null == c) return ff(d, e, b), a;
      for (
        var f = Dd(c),
          g = f,
          h = !!(2 & f) || !!(2048 & f),
          k = h || Object.isFrozen(c),
          n = !0,
          m = !0,
          r = 0;
        r < c.length;
        r++
      ) {
        var p = c[r];
        h || ((p = !!(Dd(p.K) & 2)), n && (n = !p), m && (m = p));
      }
      h || ((f = Cd(f, 5, !0)), (f = Cd(f, 8, n)), (f = Cd(f, 16, m)));
      k &&
        f !== g &&
        ((c = ud(c)), (g = 0), (f = jf(f, e)), (f = mf(f, e, !0)));
      f !== g && Fd(c, f);
      ff(d, e, b, c);
      return a;
    };
  function jf(a, b) {
    a = Cd(a, 2, !!(2 & b));
    a = Cd(a, 32, !0);
    return (a = Cd(a, 2048, !1));
  }
  function mf(a, b, c) {
    (32 & b && c) || (a = Cd(a, 32, !1));
    return a;
  }
  function yf(a, b, c, d) {
    a = a.K;
    var e = Ed(a);
    Td(e);
    b = uf(a, e, c, b, !0);
    c = null != d ? d : new c();
    b.push(c);
    Dd(c.K) & 2 ? Bd(b, 8) : Bd(b, 16);
    return c;
  }
  var zf = function (a, b, c, d) {
      yf(a, b, c, d);
      return a;
    },
    Af = function (a, b) {
      a = df(a, b);
      var c;
      null == a
        ? (c = a)
        : de(a)
        ? "number" === typeof a
          ? (c = oe(a))
          : (c = me(a))
        : (c = void 0);
      return c;
    },
    Bf = function (a, b) {
      return ue(df(a, b));
    };
  function Cf(a, b) {
    return null != a ? a : b;
  }
  var Df = function (a, b) {
      var c = void 0 === c ? !1 : c;
      return Cf(be(df(a, b)), c);
    },
    Ef = function (a, b) {
      var c = void 0 === c ? 0 : c;
      return Cf(je(df(a, b)), c);
    },
    Ff = function (a, b) {
      var c = void 0 === c ? 0 : c;
      return Cf(ke(df(a, b)), c);
    },
    Gf = function (a, b) {
      var c = void 0 === c ? 0 : c;
      return Cf(Af(a, b), c);
    },
    E = function (a, b) {
      var c = void 0 === c ? "" : c;
      return Cf(Bf(a, b), c);
    },
    Hf = function (a, b) {
      var c = 0;
      c = void 0 === c ? 0 : c;
      return Cf(ge(df(a, b)), c);
    },
    If = function (a, b) {
      var c = void 0 === c ? "0" : c;
      a = df(a, b);
      b = !0;
      b = void 0 === b ? !1 : b;
      a =
        null == a
          ? a
          : de(a)
          ? "string" === typeof a
            ? me(a)
            : b
            ? ne(a)
            : oe(a)
          : void 0;
      return Cf(a, c);
    },
    Jf = function (a, b, c) {
      return C(a, b, ae(c));
    },
    Kf = function (a, b, c) {
      return C(a, b, te(c));
    };
  var F = function (a, b, c) {
    this.K = B(a, b, c);
  };
  F.prototype.toJSON = function () {
    return Pd
      ? Lf(this, this.K, !1)
      : Lf(this, Xe(this.K, Ze, void 0, void 0, !1), !0);
  };
  var Mf = function (a) {
    Pd = !0;
    try {
      return JSON.stringify(a.toJSON(), Te);
    } finally {
      Pd = !1;
    }
  };
  F.prototype.yd = Ld;
  F.prototype.toString = function () {
    return Lf(this, this.K, !1).toString();
  };
  function Lf(a, b, c) {
    var d = ub ? void 0 : a.constructor.na;
    var e = Ed(c ? a.K : b);
    a = b.length;
    if (!a) return b;
    var f;
    if (Od((c = b[a - 1]))) {
      a: {
        var g = c;
        var h = {},
          k = !1,
          n;
        for (n in g) {
          var m = g[n];
          if (Array.isArray(m)) {
            var r = m;
            if (Qd(m, d, +n) || (Nd(m) && 0 === m.size)) m = null;
            m != r && (k = !0);
          }
          null != m ? (h[n] = m) : (k = !0);
        }
        if (k) {
          for (var p in h) {
            g = h;
            break a;
          }
          g = null;
        }
      }
      g != c && (f = !0);
      a--;
    }
    for (n = +!!(e & 512) - 1; 0 < a; a--) {
      p = a - 1;
      c = b[p];
      p -= n;
      if (!(null == c || Qd(c, d, p) || (Nd(c) && 0 === c.size))) break;
      var t = !0;
    }
    if (!f && !t) return b;
    b = Array.prototype.slice.call(b, 0, a);
    g && b.push(g);
    return b;
  }
  function Nf(a, b) {
    if (Array.isArray(b)) {
      var c = Dd(b);
      if (c & 4) return b;
      for (var d = 0, e = 0; d < b.length; d++) {
        var f = a(b[d]);
        null != f && (b[e++] = f);
      }
      e < d && (b.length = e);
      Fd(b, (c | 5) & -12289);
      c & 2 && Object.freeze(b);
      return b;
    }
  }
  var Of = Symbol();
  function Pf(a, b, c) {
    a[b] = c;
  }
  var Qf = Symbol();
  function Rf(a) {
    var b = a[Qf];
    if (!b) {
      var c = Sf(a);
      b = function (d, e) {
        return Tf(d, e, c);
      };
      a[Qf] = b;
    }
    return b;
  }
  var Uf = Symbol();
  function Vf(a) {
    return a.g;
  }
  function Wf(a, b) {
    var c,
      d,
      e = a.g;
    return function (f, g, h) {
      return e(f, g, h, d || (d = Sf(b).g), c || (c = Rf(b)));
    };
  }
  function Sf(a) {
    var b = a[Uf];
    if (b) return b;
    b = a[Uf] = {};
    var c = Vf,
      d = Wf;
    var e = void 0 === e ? Pf : e;
    b.g = De(a[0]);
    var f = 0,
      g = a[++f];
    g &&
      g.constructor === Object &&
      ((b.Mf = g),
      (g = a[++f]),
      "function" === typeof g && ((b.l = g), (b.j = a[++f]), (g = a[++f])));
    for (
      var h = {};
      Array.isArray(g) && "number" === typeof g[0] && 0 < g[0];

    ) {
      for (var k = 0; k < g.length; k++) h[g[k]] = g;
      g = a[++f];
    }
    for (k = 1; void 0 !== g; ) {
      "number" === typeof g && ((k += g), (g = a[++f]));
      var n = void 0;
      if (g instanceof td) var m = g;
      else (m = Xf), f--;
      if (m.Te) {
        g = a[++f];
        n = a;
        var r = f;
        "function" == typeof g && ((g = g()), (n[r] = g));
        n = g;
      }
      g = a[++f];
      r = k + 1;
      "number" === typeof g && 0 > g && ((r -= g), (g = a[++f]));
      for (; k < r; k++) {
        var p = h[k];
        e(b, k, n ? d(m, n, p) : c(m, p));
      }
    }
    Yf in a && Of in a && Uf in a && (a.length = 0);
    return b;
  }
  var Yf = Symbol();
  function Zf(a, b) {
    var c = a[b];
    if (c) return c;
    if ((c = a.Mf))
      if ((c = c[b])) {
        c = Array.isArray(c) ? (c[0] instanceof td ? c : [$f, c]) : [c, void 0];
        var d = c[0].g;
        if ((c = c[1])) {
          var e = Rf(c),
            f = Sf(c).g;
          c = (c = a.j)
            ? c(f, e)
            : function (g, h, k) {
                return d(g, h, k, f, e);
              };
        } else c = d;
        return (a[b] = c);
      }
  }
  function Tf(a, b, c) {
    for (
      var d = Ed(a),
        e = +!!(d & 512) - 1,
        f = a.length,
        g = f + (d & 256 ? -1 : 0),
        h = d & 512 ? 1 : 0;
      h < g;
      h++
    ) {
      var k = a[h];
      if (null != k) {
        var n = h - e,
          m = Zf(c, n);
        m && m(b, k, n);
      }
    }
    if (d & 256) {
      a = a[f - 1];
      for (var r in a)
        (d = +r),
          Number.isNaN(d) ||
            ((e = a[r]), null != e && (f = Zf(c, d)) && f(b, e, d));
    }
  }
  var ag = function (a, b) {
    var c = new jd();
    Tf(a.K, c, Sf(b));
    return od(c);
  };
  function bg(a) {
    return new td(a, !1);
  }
  function cg(a, b, c) {
    b = Zd(b);
    null != b &&
      (ld(a, c, 1),
      (a = a.g),
      (c = Sc || (Sc = new DataView(new ArrayBuffer(8)))),
      c.setFloat64(0, +b, !0),
      (Qc = c.getUint32(0, !0)),
      (Rc = c.getUint32(4, !0)),
      id(a, Qc),
      id(a, Rc));
  }
  function dg(a, b, c) {
    a: if (null != b) {
      if (de(b)) {
        if ("string" === typeof b) {
          b = me(b);
          break a;
        }
        if ("number" === typeof b) {
          b = oe(b);
          break a;
        }
      }
      b = void 0;
    }
    null != b &&
      ("string" === typeof b && dd(b),
      null != b &&
        (ld(a, c, 0),
        "number" === typeof b
          ? ((a = a.g), Tc(b), fd(a, Qc, Rc))
          : ((c = dd(b)), fd(a.g, c.j, c.g))));
  }
  function eg(a, b, c) {
    b = je(b);
    null != b && null != b && (ld(a, c, 0), hd(a.g, b));
  }
  function fg(a, b, c) {
    b = be(b);
    null != b && (ld(a, c, 0), a.g.g.push(b ? 1 : 0));
  }
  function gg(a, b, c) {
    b = ue(b);
    null != b && pd(a, c, jb(b));
  }
  function hg(a, b, c, d, e) {
    qd(
      a,
      c,
      b instanceof F ? b.K : Array.isArray(b) ? B(b, d[0], d[1]) : void 0,
      e
    );
  }
  function ig(a, b, c) {
    b = je(b);
    null != b && ((b = parseInt(b, 10)), ld(a, c, 0), hd(a.g, b));
  }
  var jg = bg(cg),
    kg = bg(cg),
    lg = bg(function (a, b, c) {
      b = Zd(b);
      null != b &&
        (ld(a, c, 5),
        (a = a.g),
        (c = Sc || (Sc = new DataView(new ArrayBuffer(8)))),
        c.setFloat32(0, +b, !0),
        (Rc = 0),
        (Qc = c.getUint32(0, !0)),
        id(a, Qc));
    }),
    mg = bg(dg),
    ng = bg(dg),
    og = bg(dg),
    pg = bg(function (a, b, c) {
      a: if (null != b) {
        if (de(b)) {
          if ("string" === typeof b) {
            var d = Math.trunc(Number(b));
            Number.isSafeInteger(d) && 0 <= d
              ? (b = String(d))
              : ((d = b.indexOf(".")),
                -1 !== d && (b = b.substring(0, d)),
                pe(b) || (Yc(b), (b = Vc(Qc, Rc))));
            break a;
          }
          if ("number" === typeof b) {
            b = Math.trunc(b);
            b = 0 <= b && Number.isSafeInteger(b) ? b : re(b);
            break a;
          }
        }
        b = void 0;
      }
      null != b &&
        ("string" === typeof b && ad(b),
        null != b &&
          (ld(a, c, 0),
          "number" === typeof b
            ? ((a = a.g), Tc(b), fd(a, Qc, Rc))
            : ((c = ad(b)), fd(a.g, c.j, c.g))));
    }),
    qg = bg(eg),
    rg = bg(eg),
    sg = bg(fg),
    tg = bg(fg),
    ug = bg(gg),
    vg = bg(gg),
    wg = bg(gg),
    xg;
  xg = new td(function (a, b, c) {
    b = Nf(ue, b);
    if (null != b)
      for (var d = 0; d < b.length; d++) {
        var e = a,
          f = c,
          g = b[d];
        null != g && pd(e, f, jb(g));
      }
  }, !1);
  var $f = new td(hg, !0),
    Xf = new td(hg, !0),
    yg;
  yg = new td(function (a, b, c, d, e) {
    if (Array.isArray(b))
      for (var f = 0; f < b.length; f++) hg(a, b[f], c, d, e);
  }, !0);
  var zg = bg(function (a, b, c) {
      b = ke(b);
      null != b && null != b && (ld(a, c, 0), gd(a.g, b));
    }),
    Ag = bg(ig),
    Bg;
  Bg = new td(function (a, b, c) {
    b = Nf(je, b);
    if (null != b && b.length) {
      c = md(a, c);
      for (var d = 0; d < b.length; d++) hd(a.g, b[d]);
      nd(a, c);
    }
  }, !1);
  var Cg = bg(ig);
  function Dg(a) {
    return function (b) {
      return ag(b, a);
    };
  }
  function Eg(a) {
    return function () {
      return ag(this, a);
    };
  }
  function Fg(a) {
    return function (b) {
      if (null == b || "" == b) b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        b = Ae(a, Hd(b));
      }
      return b;
    };
  }
  var Gg = function (a) {
    var b = void 0 === b ? [] : b;
    this.g = a;
    this.defaultValue = b;
  };
  var Hg = function () {},
    Ig = function (a) {
      var b = !1,
        c;
      return function () {
        b || ((c = a()), (b = !0));
        return c;
      };
    },
    Jg = function (a) {
      var b = a;
      return function () {
        if (b) {
          var c = b;
          b = null;
          c();
        }
      };
    },
    Kg = function (a) {
      var b = 0,
        c = !1,
        d = [],
        e = function () {
          b = 0;
          c && ((c = !1), f());
        },
        f = function () {
          b = x.setTimeout(e, 1e3);
          var g = d;
          d = [];
          a.apply(void 0, g);
        };
      return function (g) {
        d = arguments;
        b ? (c = !0) : f();
      };
    };
  var Lg = Ig(function () {
    var a = !1;
    try {
      var b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
      x.addEventListener("test", null, b);
    } catch (c) {}
    return a;
  });
  function Mg(a) {
    return a ? (a.passive && Lg() ? a : a.capture || !1) : !1;
  }
  var Ng = function (a, b, c, d) {
      return a.addEventListener ? (a.addEventListener(b, c, Mg(d)), !0) : !1;
    },
    Og = function (a, b, c) {
      a.removeEventListener && a.removeEventListener(b, c, Mg());
    };
  function Pg(a, b, c) {
    for (var d in a) b.call(c, a[d], d, a);
  }
  function Qg(a, b) {
    var c = {},
      d;
    for (d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
    return c;
  }
  function Rg(a) {
    var b = Sg,
      c;
    for (c in b) if (!a.call(void 0, b[c], c, b)) return !1;
    return !0;
  }
  function Tg(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function Ug(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = d;
    return b;
  }
  function Vg(a, b) {
    var c = Qa(b),
      d = c ? b : arguments;
    for (c = c ? 0 : 1; c < d.length; c++) {
      if (null == a) return;
      a = a[d[c]];
    }
    return a;
  }
  function Wg(a, b) {
    return null !== a && b in a;
  }
  function Xg(a, b) {
    for (var c in a) if (a[c] == b) return !0;
    return !1;
  }
  function Yg(a) {
    var b = Zg,
      c;
    for (c in b) if (a.call(void 0, b[c], c, b)) return c;
  }
  function $g(a) {
    for (var b in a) return !1;
    return !0;
  }
  function ah(a) {
    for (var b in a) delete a[b];
  }
  function bh(a, b, c) {
    return null !== a && b in a ? a[b] : c;
  }
  var ch =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function dh(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
      d = arguments[e];
      for (c in d) a[c] = d[c];
      for (var f = 0; f < ch.length; f++)
        (c = ch[f]),
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
  var eh,
    fh = function () {
      if (void 0 === eh) {
        var a = null,
          b = x.trustedTypes;
        if (b && b.createPolicy) {
          try {
            a = b.createPolicy("goog#html", {
              createHTML: cb,
              createScript: cb,
              createScriptURL: cb,
            });
          } catch (c) {
            x.console && x.console.error(c.message);
          }
          eh = a;
        } else eh = a;
      }
      return eh;
    };
  var gh = function (a) {
    this.g = a;
  };
  gh.prototype.toString = function () {
    return this.g + "";
  };
  var hh = {},
    ih = function (a) {
      var b = fh();
      a = b ? b.createScriptURL(a) : a;
      return new gh(a, hh);
    }; /*

 SPDX-License-Identifier: Apache-2.0
*/
  var jh = function (a) {
    this.g = a;
  };
  jh.prototype.toString = function () {
    return this.g;
  };
  var kh = new jh("about:invalid#zClosurez");
  var lh = function (a) {
    this.gg = a;
  };
  function oh(a) {
    return new lh(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var ph = [
    oh("data"),
    oh("http"),
    oh("https"),
    oh("mailto"),
    oh("ftp"),
    new lh(function (a) {
      return /^[^:]*([/?#]|$)/.test(a);
    }),
  ];
  function qh(a) {
    if ("undefined" !== typeof MediaSource && a instanceof MediaSource)
      return new jh(URL.createObjectURL(a));
    var b = a.type.match(/^([^;]+)(?:;\w+=(?:\w+|"[\w;,= ]+"))*$/i);
    if (
      2 !== (null == b ? void 0 : b.length) ||
      !(
        /^image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon|heic|heif|avif|x-ms-bmp)$/i.test(
          b[1]
        ) ||
        /^video\/(?:mpeg|mp4|ogg|webm|x-matroska|quicktime|x-ms-wmv)$/i.test(
          b[1]
        ) ||
        /^audio\/(?:3gpp2|3gpp|aac|amr|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-matroska|x-wav|wav|webm)$/i.test(
          b[1]
        ) ||
        /^font\/\w+/i.test(b[1])
      )
    )
      throw Error("");
    return new jh(URL.createObjectURL(a));
  }
  var rh = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  var sh = {},
    th = function (a) {
      this.g = a;
    };
  th.prototype.toString = function () {
    return this.g.toString();
  };
  var uh = new th("", sh);
  var vh = {},
    wh = function (a) {
      this.g = a;
    };
  wh.prototype.toString = function () {
    return this.g.toString();
  };
  var xh = function (a) {
    return a instanceof wh && a.constructor === wh
      ? a.g
      : "type_error:SafeHtml";
  };
  function yh(a) {
    var b = Ia.apply(1, arguments);
    if (0 === b.length) return ih(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return ih(c);
  }
  function zh(a) {
    for (var b = Ia.apply(1, arguments), c = a[0], d = 0; d < a.length - 1; d++)
      c += String(b[d]) + a[d + 1];
    if (/[<>]/.test(c))
      throw Error("Forbidden characters in style string: " + c);
    return new th(c, sh);
  }
  var Ah = function (a, b) {
    this.x = void 0 !== a ? a : 0;
    this.y = void 0 !== b ? b : 0;
  };
  Ah.prototype.ceil = function () {
    this.x = Math.ceil(this.x);
    this.y = Math.ceil(this.y);
    return this;
  };
  Ah.prototype.floor = function () {
    this.x = Math.floor(this.x);
    this.y = Math.floor(this.y);
    return this;
  };
  Ah.prototype.round = function () {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
    return this;
  };
  Ah.prototype.scale = function (a, b) {
    this.x *= a;
    this.y *= "number" === typeof b ? b : a;
    return this;
  };
  var Bh = function (a, b) {
      this.width = a;
      this.height = b;
    },
    Ch = function (a, b) {
      return a == b
        ? !0
        : a && b
        ? a.width == b.width && a.height == b.height
        : !1;
    };
  l = Bh.prototype;
  l.aspectRatio = function () {
    return this.width / this.height;
  };
  l.isEmpty = function () {
    return !(this.width * this.height);
  };
  l.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  l.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  l.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  l.scale = function (a, b) {
    this.width *= a;
    this.height *= "number" === typeof b ? b : a;
    return this;
  };
  function Dh(a, b) {
    if (1 === a.nodeType) {
      var c = a.tagName;
      if ("SCRIPT" === c || "STYLE" === c) throw Error("");
    }
    a.innerHTML = xh(b);
  }
  function Eh(a, b) {
    a.src =
      b instanceof gh && b.constructor === gh
        ? b.g
        : "type_error:TrustedResourceUrl";
    var c, d;
    (c = (b =
      null ==
      (d = (c = ((a.ownerDocument && a.ownerDocument.defaultView) || window)
        .document).querySelector)
        ? void 0
        : d.call(c, "script[nonce]"))
      ? b.nonce || b.getAttribute("nonce") || ""
      : "") && a.setAttribute("nonce", c);
  }
  var Fh = function (a) {
    var b = [],
      c = [],
      d = {},
      e = function (f, g) {
        var h = g + "  ";
        try {
          if (void 0 === f) b.push("undefined");
          else if (null === f) b.push("NULL");
          else if ("string" === typeof f)
            b.push('"' + f.replace(/\n/g, "\n" + g) + '"');
          else if ("function" === typeof f)
            b.push(String(f).replace(/\n/g, "\n" + g));
          else if (Ra(f)) {
            f[Sa] || c.push(f);
            var k = Va(f);
            if (d[k]) b.push("*** reference loop detected (id=" + k + ") ***");
            else {
              d[k] = !0;
              b.push("{");
              for (var n in f)
                "function" !== typeof f[n] &&
                  (b.push("\n"), b.push(h), b.push(n + " = "), e(f[n], h));
              b.push("\n" + g + "}");
              delete d[k];
            }
          } else b.push(f);
        } catch (m) {
          b.push("*** " + m + " ***");
        }
      };
    e(a, "");
    for (a = 0; a < c.length; a++) Wa(c[a]);
    return b.join("");
  };
  function Gh(a, b) {
    a.write(xh(b));
  }
  var Hh = function (a) {
      return decodeURIComponent(a.replace(/\+/g, " "));
    },
    Ih = function (a, b) {
      a.length > b && (a = a.substring(0, b - 3) + "...");
      return a;
    },
    Jh = String.prototype.repeat
      ? function (a, b) {
          return a.repeat(b);
        }
      : function (a, b) {
          return Array(b + 1).join(a);
        },
    Kh = function (a) {
      return null == a ? "" : String(a);
    },
    Lh = (2147483648 * Math.random()) | 0,
    Mh = function (a) {
      return String(a).replace(/\-([a-z])/g, function (b, c) {
        return c.toUpperCase();
      });
    },
    Nh = function () {
      return "googleAvInapp".replace(/([A-Z])/g, "-$1").toLowerCase();
    },
    Oh = function (a) {
      return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
        return c + d.toUpperCase();
      });
    },
    Ph = function (a) {
      isFinite(a) && (a = String(a));
      return "string" === typeof a
        ? /^\s*-?0x/i.test(a)
          ? parseInt(a, 16)
          : parseInt(a, 10)
        : NaN;
    };
  var Sh = function (a) {
      return a ? new Qh(Rh(a)) : eb || (eb = new Qh());
    },
    Th = function (a) {
      var b = document;
      return "string" === typeof a ? b.getElementById(a) : a;
    },
    Vh = function (a, b) {
      Pg(b, function (c, d) {
        "style" == d
          ? (a.style.cssText = c)
          : "class" == d
          ? (a.className = c)
          : "for" == d
          ? (a.htmlFor = c)
          : Uh.hasOwnProperty(d)
          ? a.setAttribute(Uh[d], c)
          : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0)
          ? a.setAttribute(d, c)
          : (a[d] = c);
      });
    },
    Uh = {
      cellpadding: "cellPadding",
      cellspacing: "cellSpacing",
      colspan: "colSpan",
      frameborder: "frameBorder",
      height: "height",
      maxlength: "maxLength",
      nonce: "nonce",
      role: "role",
      rowspan: "rowSpan",
      type: "type",
      usemap: "useMap",
      valign: "vAlign",
      width: "width",
    },
    Wh = function (a) {
      a = a.document;
      a = "CSS1Compat" == a.compatMode ? a.documentElement : a.body;
      return new Bh(a.clientWidth, a.clientHeight);
    },
    Xh = function (a) {
      var b = a.scrollingElement
        ? a.scrollingElement
        : oc || "CSS1Compat" != a.compatMode
        ? a.body || a.documentElement
        : a.documentElement;
      a = a.parentWindow || a.defaultView;
      return new Ah(
        a.pageXOffset || b.scrollLeft,
        a.pageYOffset || b.scrollTop
      );
    },
    G = function (a) {
      return a ? a.parentWindow || a.defaultView : window;
    },
    $h = function (a, b, c) {
      var d = arguments,
        e = document,
        f = d[1],
        g = Yh(e, String(d[0]));
      f &&
        ("string" === typeof f
          ? (g.className = f)
          : Array.isArray(f)
          ? (g.className = f.join(" "))
          : Vh(g, f));
      2 < d.length && Zh(e, g, d, 2);
      return g;
    },
    Zh = function (a, b, c, d) {
      function e(h) {
        h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h);
      }
      for (; d < c.length; d++) {
        var f = c[d];
        if (!Qa(f) || (Ra(f) && 0 < f.nodeType)) e(f);
        else {
          a: {
            if (f && "number" == typeof f.length) {
              if (Ra(f)) {
                var g =
                  "function" == typeof f.item || "string" == typeof f.item;
                break a;
              }
              if ("function" === typeof f) {
                g = "function" == typeof f.item;
                break a;
              }
            }
            g = !1;
          }
          Nb(g ? bc(f) : f, e);
        }
      }
    },
    Yh = function (a, b) {
      b = String(b);
      "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
      return a.createElement(b);
    },
    ai = function (a) {
      a && a.parentNode && a.parentNode.removeChild(a);
    },
    bi = function (a) {
      var b;
      if (oc && (b = a.parentElement)) return b;
      b = a.parentNode;
      return Ra(b) && 1 == b.nodeType ? b : null;
    },
    ci = function (a, b) {
      if (!a || !b) return !1;
      if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
      if ("undefined" != typeof a.compareDocumentPosition)
        return a == b || !!(a.compareDocumentPosition(b) & 16);
      for (; b && a != b; ) b = b.parentNode;
      return b == a;
    },
    Rh = function (a) {
      return 9 == a.nodeType ? a : a.ownerDocument || a.document;
    },
    di = function (a) {
      try {
        return (
          a.contentWindow || (a.contentDocument ? G(a.contentDocument) : null)
        );
      } catch (b) {}
      return null;
    },
    ei = function (a, b) {
      a && (a = a.parentNode);
      for (var c = 0; a; ) {
        if (b(a)) return a;
        a = a.parentNode;
        c++;
      }
      return null;
    },
    Qh = function (a) {
      this.g = a || x.document || document;
    };
  l = Qh.prototype;
  l.getElementsByTagName = function (a, b) {
    return (b || this.g).getElementsByTagName(String(a));
  };
  l.appendChild = function (a, b) {
    a.appendChild(b);
  };
  l.append = function (a, b) {
    Zh(Rh(a), a, arguments, 1);
  };
  l.canHaveChildren = function (a) {
    if (1 != a.nodeType) return !1;
    switch (a.tagName) {
      case "APPLET":
      case "AREA":
      case "BASE":
      case "BR":
      case "COL":
      case "COMMAND":
      case "EMBED":
      case "FRAME":
      case "HR":
      case "IMG":
      case "INPUT":
      case "IFRAME":
      case "ISINDEX":
      case "KEYGEN":
      case "LINK":
      case "NOFRAMES":
      case "NOSCRIPT":
      case "META":
      case "OBJECT":
      case "PARAM":
      case "SCRIPT":
      case "SOURCE":
      case "STYLE":
      case "TRACK":
      case "WBR":
        return !1;
    }
    return !0;
  };
  l.contains = ci;
  var gi = function () {
      return tb && xb
        ? xb.mobile
        : !fi() && (A("iPod") || A("iPhone") || A("Android") || A("IEMobile"));
    },
    fi = function () {
      return tb && xb
        ? !xb.mobile && (A("iPad") || A("Android") || A("Silk"))
        : A("iPad") || (A("Android") && !A("Mobile")) || A("Silk");
    };
  var hi = RegExp(
      "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
    ),
    ii = function (a) {
      var b = a.match(hi);
      a = b[1];
      var c = b[3];
      b = b[4];
      var d = "";
      a && (d += a + ":");
      c && ((d = d + "//" + c), b && (d += ":" + b));
      return d;
    },
    ji = function (a, b) {
      if (a) {
        a = a.split("&");
        for (var c = 0; c < a.length; c++) {
          var d = a[c].indexOf("="),
            e = null;
          if (0 <= d) {
            var f = a[c].substring(0, d);
            e = a[c].substring(d + 1);
          } else f = a[c];
          b(f, e ? Hh(e) : "");
        }
      }
    },
    ki = /#|$/,
    li = function (a, b) {
      var c = a.search(ki);
      a: {
        var d = 0;
        for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c; ) {
          var f = a.charCodeAt(d - 1);
          if (38 == f || 63 == f)
            if (
              ((f = a.charCodeAt(d + e)), !f || 61 == f || 38 == f || 35 == f)
            )
              break a;
          d += e + 1;
        }
        d = -1;
      }
      if (0 > d) return null;
      e = a.indexOf("&", d);
      if (0 > e || e > c) e = c;
      d += b.length + 1;
      return Hh(a.slice(d, -1 !== e ? e : 0));
    };
  var mi = function (a) {
      try {
        return !!a && null != a.location.href && hc(a, "foo");
      } catch (b) {
        return !1;
      }
    },
    oi = function (a) {
      var b = void 0 === b ? !1 : b;
      var c = void 0 === c ? x : c;
      for (var d = 0; c && 40 > d++ && ((!b && !mi(c)) || !a(c)); ) c = ni(c);
    },
    pi = function () {
      var a = window;
      oi(function (b) {
        a = b;
        return !1;
      });
      return a;
    },
    ni = function (a) {
      try {
        var b = a.parent;
        if (b && b != a) return b;
      } catch (c) {}
      return null;
    },
    qi = function () {
      var a = window;
      return mi(a.top) ? a.top : null;
    },
    ri = function () {
      if (!globalThis.crypto) return Math.random();
      try {
        var a = new Uint32Array(1);
        globalThis.crypto.getRandomValues(a);
        return a[0] / 65536 / 65536;
      } catch (b) {
        return Math.random();
      }
    },
    si = function (a, b) {
      if (a)
        for (var c in a)
          Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
    },
    ti = function (a) {
      var b = a.length;
      if (0 == b) return 0;
      for (var c = 305419896, d = 0; d < b; d++)
        c ^= ((c << 5) + (c >> 2) + a.charCodeAt(d)) & 4294967295;
      return 0 < c ? c : 4294967296 + c;
    };
  function ui(a) {
    var b, c;
    return null !=
      (c = null == (b = /https?:\/\/[^\/]+/.exec(a)) ? void 0 : b[0])
      ? c
      : "";
  }
  var vi = function () {
      var a = x;
      try {
        for (var b = null; b != a; b = a, a = a.parent)
          switch (a.location.protocol) {
            case "https:":
              return !0;
            case "file:":
              return !0;
            case "http:":
              return !1;
          }
      } catch (c) {}
      return !0;
    },
    wi = function (a, b) {
      try {
        return !(!a.frames || !a.frames[b]);
      } catch (c) {
        return !1;
      }
    },
    xi = function (a, b) {
      for (var c = 0; 50 > c; ++c) {
        if (wi(a, b)) return a;
        if (!(a = ni(a))) break;
      }
      return null;
    },
    yi = function (a, b) {
      b = void 0 === b ? document : b;
      return b.createElement(String(a).toLowerCase());
    },
    zi = function (a) {
      for (var b = a; a && a != a.parent; ) (a = a.parent), mi(a) && (b = a);
      return b;
    };
  var H = function (a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d;
  };
  H.prototype.getWidth = function () {
    return this.right - this.left;
  };
  H.prototype.getHeight = function () {
    return this.bottom - this.top;
  };
  var Ai = function (a) {
    return new H(a.top, a.right, a.bottom, a.left);
  };
  l = H.prototype;
  l.contains = function (a) {
    return this && a
      ? a instanceof H
        ? a.left >= this.left &&
          a.right <= this.right &&
          a.top >= this.top &&
          a.bottom <= this.bottom
        : a.x >= this.left &&
          a.x <= this.right &&
          a.y >= this.top &&
          a.y <= this.bottom
      : !1;
  };
  l.expand = function (a, b, c, d) {
    Ra(a)
      ? ((this.top -= a.top),
        (this.right += a.right),
        (this.bottom += a.bottom),
        (this.left -= a.left))
      : ((this.top -= a),
        (this.right += Number(b)),
        (this.bottom += Number(c)),
        (this.left -= Number(d)));
    return this;
  };
  l.ceil = function () {
    this.top = Math.ceil(this.top);
    this.right = Math.ceil(this.right);
    this.bottom = Math.ceil(this.bottom);
    this.left = Math.ceil(this.left);
    return this;
  };
  l.floor = function () {
    this.top = Math.floor(this.top);
    this.right = Math.floor(this.right);
    this.bottom = Math.floor(this.bottom);
    this.left = Math.floor(this.left);
    return this;
  };
  l.round = function () {
    this.top = Math.round(this.top);
    this.right = Math.round(this.right);
    this.bottom = Math.round(this.bottom);
    this.left = Math.round(this.left);
    return this;
  };
  var Bi = function (a, b, c) {
    b instanceof Ah
      ? ((a.left += b.x), (a.right += b.x), (a.top += b.y), (a.bottom += b.y))
      : ((a.left += b),
        (a.right += b),
        "number" === typeof c && ((a.top += c), (a.bottom += c)));
    return a;
  };
  H.prototype.scale = function (a, b) {
    b = "number" === typeof b ? b : a;
    this.left *= a;
    this.right *= a;
    this.top *= b;
    this.bottom *= b;
    return this;
  };
  var Ci = function (a, b, c, d) {
      this.left = a;
      this.top = b;
      this.width = c;
      this.height = d;
    },
    Di = function (a) {
      return new H(a.top, a.left + a.width, a.top + a.height, a.left);
    };
  l = Ci.prototype;
  l.contains = function (a) {
    return a instanceof Ah
      ? a.x >= this.left &&
          a.x <= this.left + this.width &&
          a.y >= this.top &&
          a.y <= this.top + this.height
      : this.left <= a.left &&
          this.left + this.width >= a.left + a.width &&
          this.top <= a.top &&
          this.top + this.height >= a.top + a.height;
  };
  l.getSize = function () {
    return new Bh(this.width, this.height);
  };
  l.ceil = function () {
    this.left = Math.ceil(this.left);
    this.top = Math.ceil(this.top);
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  l.floor = function () {
    this.left = Math.floor(this.left);
    this.top = Math.floor(this.top);
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  l.round = function () {
    this.left = Math.round(this.left);
    this.top = Math.round(this.top);
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  l.scale = function (a, b) {
    b = "number" === typeof b ? b : a;
    this.left *= a;
    this.width *= a;
    this.top *= b;
    this.height *= b;
    return this;
  };
  function Ei(a) {
    a = void 0 === a ? x : a;
    var b = a.context || a.AMP_CONTEXT_DATA;
    if (!b)
      try {
        b = a.parent.context || a.parent.AMP_CONTEXT_DATA;
      } catch (e) {}
    var c, d;
    return (null == (c = b) ? 0 : c.pageViewId) &&
      (null == (d = b) ? 0 : d.canonicalUrl)
      ? b
      : null;
  }
  var Fi = function () {
      this.S = {};
    },
    Gi = function () {
      var a = Ei(window);
      if (a) {
        if (a) {
          var b = a.pageViewId;
          a = a.clientId;
          "string" === typeof a && (b += a.replace(/\D/g, "").substr(0, 6));
        } else b = null;
        return +b;
      }
      b = zi(window);
      a = b.google_global_correlator;
      a ||
        (b.google_global_correlator = a =
          1 + Math.floor(Math.random() * Math.pow(2, 43)));
      return a;
    },
    Ii = function (a, b) {
      var c = Hi[7] || "google_ps_7";
      a = a.S;
      var d = a[c];
      return void 0 === d ? ((a[c] = b()), a[c]) : d;
    },
    Ji = function (a) {
      var b = Gi();
      return Ii(a, function () {
        return b;
      });
    },
    Li = function () {
      if (Ki) var a = Ki;
      else {
        a =
          ((a = void 0 === a ? Ei() : a)
            ? mi(a.master)
              ? a.master
              : null
            : null) || window;
        var b = a.google_persistent_state_async;
        a =
          null != b &&
          "object" == typeof b &&
          null != b.S &&
          "object" == typeof b.S
            ? (Ki = b)
            : (a.google_persistent_state_async = Ki = new Fi());
      }
      return Ji(a);
    },
    Ki = null,
    Mi = {},
    Hi =
      ((Mi[8] = "google_prev_ad_formats_by_region"),
      (Mi[9] = "google_prev_ad_slotnames_by_region"),
      Mi);
  var Oi = function (a, b, c, d, e) {
    Ni(
      a,
      b,
      void 0 === c ? null : c,
      void 0 === d ? !1 : d,
      void 0 === e ? !1 : e
    );
  };
  function Ni(a, b, c, d, e) {
    e = void 0 === e ? !1 : e;
    a.google_image_requests || (a.google_image_requests = []);
    var f = yi("IMG", a.document);
    if (c || d) {
      var g = function (h) {
        c && c(h);
        d && Yb(a.google_image_requests, f);
        Og(f, "load", g);
        Og(f, "error", g);
      };
      Ng(f, "load", g);
      Ng(f, "error", g);
    }
    e && (f.attributionSrc = "");
    f.src = b;
    a.google_image_requests.push(f);
  }
  var Qi = function (a, b) {
      var c = void 0 === c ? !1 : c;
      var d = "pagead/gen_204?id=" + b;
      si(a, function (e, f) {
        if (e || 0 === e) d += "&" + f + "=" + encodeURIComponent("" + e);
      });
      Pi(d, c);
    },
    Pi = function (a, b) {
      var c = window;
      b = void 0 === b ? !1 : b;
      var d = void 0 === d ? !1 : d;
      c.fetch
        ? ((b = {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors",
          }),
          d &&
            ((b.mode = "cors"),
            "setAttributionReporting" in XMLHttpRequest.prototype
              ? (b.attributionReporting = {
                  eventSourceEligible: "true",
                  triggerEligible: "false",
                })
              : (b.headers = {
                  "Attribution-Reporting-Eligible": "event-source",
                })),
          c.fetch(a, b))
        : Oi(c, a, void 0, b, d);
    };
  var Ri = function (a, b, c) {
      c = void 0 === c ? {} : c;
      this.error = a;
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
      this.meta = c;
    },
    Si = function (a) {
      return !!(a.error && a.meta && a.id);
    };
  var Ti = fa(["pagead/js/err_rep.js"]),
    Ui = function () {
      var a = void 0 === a ? "jserror" : a;
      var b = void 0 === b ? 0.01 : b;
      var c = void 0 === c ? yh(Ti) : c;
      this.j = a;
      this.l = !1;
      this.g = null;
      this.A = !1;
      this.C = Math.random();
      this.o = b;
      this.B = this.Ua;
      this.I = c;
    };
  l = Ui.prototype;
  l.Od = function (a) {
    this.j = a;
  };
  l.Wc = function (a) {
    this.g = a;
  };
  l.Pd = function (a) {
    this.l = a;
  };
  l.Qd = function (a) {
    this.A = a;
  };
  l.Ua = function (a, b, c, d, e) {
    c = void 0 === c ? this.o : c;
    e = void 0 === e ? this.j : e;
    if ((this.A ? this.C : Math.random()) > c) return this.l;
    Si(b) || (b = new Ri(b, { context: a, id: e }));
    if (d || this.g) (b.meta = {}), this.g && this.g(b.meta), d && d(b.meta);
    x.google_js_errors = x.google_js_errors || [];
    x.google_js_errors.push(b);
    x.error_rep_loaded ||
      ((b = x.document),
      (a = yi("SCRIPT", b)),
      Eh(a, this.I),
      (b = b.getElementsByTagName("script")[0]) &&
        b.parentNode &&
        b.parentNode.insertBefore(a, b),
      (x.error_rep_loaded = !0));
    return this.l;
  };
  l.wb = function (a, b, c) {
    try {
      return b();
    } catch (d) {
      if (!this.B(a, d, this.o, c, this.j)) throw d;
    }
  };
  l.Hd = function (a, b, c, d) {
    var e = this;
    return function () {
      var f = Ia.apply(0, arguments);
      return e.wb(
        a,
        function () {
          return b.apply(c, f);
        },
        d
      );
    };
  };
  var Vi = function (a) {
      return a.prerendering
        ? 3
        : { visible: 1, hidden: 2, prerender: 3, preview: 4, unloaded: 5 }[
            a.visibilityState ||
              a.webkitVisibilityState ||
              a.mozVisibilityState ||
              ""
          ] || 0;
    },
    Wi = function (a) {
      var b;
      a.visibilityState
        ? (b = "visibilitychange")
        : a.mozVisibilityState
        ? (b = "mozvisibilitychange")
        : a.webkitVisibilityState && (b = "webkitvisibilitychange");
      return b;
    };
  var Xi = null;
  function Yi() {
    var a = void 0 === a ? x : a;
    return (a = a.performance) && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function Zi() {
    var a = void 0 === a ? x : a;
    return (a = a.performance) && a.now ? a.now() : null;
  }
  function $i(a, b) {
    b = void 0 === b ? x : b;
    var c, d;
    return (
      (null == (c = b.performance)
        ? void 0
        : null == (d = c.timing)
        ? void 0
        : d[a]) || 0
    );
  }
  function aj() {
    var a = void 0 === a ? x : a;
    var b = Math.min(
      $i("domLoading", a) || Infinity,
      $i("domInteractive", a) || Infinity
    );
    return Infinity === b
      ? Math.max($i("responseEnd", a), $i("navigationStart", a))
      : b;
  }
  var bj = function (a, b, c, d) {
    this.label = a;
    this.type = b;
    this.value = c;
    this.duration = void 0 === d ? 0 : d;
    this.taskId = this.slotId = void 0;
    this.uniqueId = Math.random();
  };
  var cj = x.performance,
    dj = !!(cj && cj.mark && cj.measure && cj.clearMarks),
    ej = Ig(function () {
      var a;
      if ((a = dj)) {
        var b;
        if (null === Xi) {
          Xi = "";
          try {
            a = "";
            try {
              a = x.top.location.hash;
            } catch (c) {
              a = x.location.hash;
            }
            a && (Xi = (b = a.match(/\bdeid=([\d,]+)/)) ? b[1] : "");
          } catch (c) {}
        }
        b = Xi;
        a = !!b.indexOf && 0 <= b.indexOf("1337");
      }
      return a;
    }),
    fj = function (a, b) {
      this.events = [];
      this.g = b || x;
      var c = null;
      b &&
        ((b.google_js_reporting_queue = b.google_js_reporting_queue || []),
        (this.events = b.google_js_reporting_queue),
        (c = b.google_measure_js_timing));
      this.l = ej() || (null != c ? c : Math.random() < a);
    };
  fj.prototype.B = function () {
    this.l = !1;
    this.events != this.g.google_js_reporting_queue &&
      (ej() && Nb(this.events, gj), (this.events.length = 0));
  };
  fj.prototype.C = function (a) {
    !this.l || 2048 < this.events.length || this.events.push(a);
  };
  var gj = function (a) {
    a &&
      cj &&
      ej() &&
      (cj.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"),
      cj.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"));
  };
  fj.prototype.start = function (a, b) {
    if (!this.l) return null;
    a = new bj(a, b, Zi() || Yi());
    b = "goog_" + a.label + "_" + a.uniqueId + "_start";
    cj && ej() && cj.mark(b);
    return a;
  };
  fj.prototype.end = function (a) {
    if (this.l && "number" === typeof a.value) {
      a.duration = (Zi() || Yi()) - a.value;
      var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
      cj && ej() && cj.mark(b);
      this.C(a);
    }
  };
  var hj = function (a) {
    a = a._google_rum_ns_ = a._google_rum_ns_ || {};
    return (a.pq = a.pq || []);
  };
  function ij(a) {
    a = null === a ? "null" : void 0 === a ? "undefined" : a;
    var b = fh();
    a = b ? b.createHTML(a) : a;
    return new wh(a, vh);
  }
  function jj(a, b, c) {
    si(b, function (d, e) {
      var f = c && c[e];
      (!d && 0 !== d) ||
        f ||
        ((a +=
          "&" + encodeURIComponent(e) + "=" + encodeURIComponent(String(d))),
        c && (c[e] = !0));
    });
    return a;
  }
  var pj = function (a, b, c, d, e, f, g, h) {
    f = void 0 === f ? Infinity : f;
    g = void 0 === g ? !1 : g;
    fj.call(this, a, h);
    var k = this;
    this.W = b;
    this.domain = c;
    this.path = d;
    this.Z = e;
    this.I = 0;
    this.o = {};
    this.G = {};
    this.Y = [];
    this.report = {};
    this.j = 0;
    this.F = [];
    this.H = f;
    a = this.g.navigator;
    this.U = !("csi.gstatic.com" !== this.domain || !a || !a.sendBeacon);
    (this.g.performance && this.g.performance.now) || kj(this, "dat", 1);
    a && a.deviceMemory && kj(this, "dmc", a.deviceMemory);
    this.g === this.g.top && kj(this, "top", 1);
    this.P = !g;
    this.J = function () {
      k.g.setTimeout(function () {
        lj(k);
      }, 1100);
    };
    this.L = function () {
      kj(k, "uet", 2);
      for (var m = u(k.Y), r = m.next(); !r.done; r = m.next()) {
        r = r.value;
        try {
          r();
        } catch (t) {}
      }
      m = k.g;
      var p = void 0 === p ? {} : p;
      "function" === typeof window.CustomEvent
        ? (r = new CustomEvent("rum_blp", p))
        : ((r = document.createEvent("CustomEvent")),
          r.initCustomEvent("rum_blp", !!p.bubbles, !!p.cancelable, p.detail));
      m.dispatchEvent(r);
      lj(k);
      null != k.o.uet && ((k.A -= 3 + k.o.uet.length + 2), delete k.o.uet);
    };
    this.ba = Kg(function () {
      lj(k);
    });
    this.fa = function () {
      var m = k.g.document;
      (null != m.hidden
        ? m.hidden
        : null != m.mozHidden
        ? m.mozHidden
        : null != m.webkitHidden && m.webkitHidden) && k.ba();
    };
    this.N = this.g.setTimeout(function () {
      lj(k);
    }, 5e3);
    this.A = b.length + c.length + d.length + e.length + 3;
    Nb(this.events, function (m) {
      mj(k, m);
    });
    b = hj(this.g);
    var n = function () {
      var m = Ia.apply(0, arguments)[0],
        r = m[0];
      m = m[1];
      var p = r.length + m.length + 2;
      8e3 < k.A + k.j + p && lj(k);
      k.F.push([r, m]);
      k.j += p;
      nj(k);
      return 0;
    };
    Nb(b, function (m) {
      return n(m);
    });
    b.length = 0;
    b.push = n;
    kj(this, "puid", (this.I + 1).toString(36) + "~" + Date.now().toString(36));
    oj(this);
  };
  v(pj, fj);
  var oj = function (a) {
      "complete" === a.g.document.readyState
        ? a.g.setTimeout(function () {
            lj(a);
          }, 0)
        : Ng(a.g, "load", a.J);
      var b = Wi(a.g.document);
      "undefined" !== typeof b && Ng(a.g, b, a.fa);
      Ng(a.g, "pagehide", a.L);
    },
    kj = function (a, b, c) {
      c = String(c);
      a.A =
        null != a.o[b]
          ? a.A + (c.length - a.o[b].length)
          : a.A + (b.length + c.length + 2);
      a.o[b] = c;
    },
    sj = function (a, b, c, d, e) {
      e = void 0 === e ? "" : e;
      var f = qj(a, b, c, d, e);
      8e3 < a.A + a.j + f && (lj(a), (f = b.length + c.length + 2));
      rj(a, b, c, d, e);
      a.j += f;
      nj(a);
    },
    qj = function (a, b, c, d, e) {
      return null == a.report[b]
        ? b.length + c.length + 2
        : d
        ? c.length + (void 0 === e ? "" : e).length
        : c.length - a.report[b].length;
    },
    rj = function (a, b, c, d, e) {
      a.report[b] =
        d && null != a.report[b]
          ? a.report[b] + ("" + (void 0 === e ? "" : e) + c)
          : c;
    },
    nj = function (a) {
      6e3 <= a.A + a.j && lj(a);
    },
    lj = function (a) {
      if (a.l && a.P) {
        try {
          a.j && (a.sendBeacon(a.report), a.I === a.H && a.B());
        } catch (b) {
          new Ui().Ua(358, b);
        }
        a.report = {};
        a.j = 0;
        a.events.length = 0;
        a.g.clearTimeout(a.N);
        a.N = 0;
      }
    },
    tj = function (a, b) {
      var c = a.W + "//" + a.domain + a.path + a.Z,
        d = {};
      c = jj(c, a.o, d);
      c = jj(c, b, d);
      b = a.g;
      b.google_timing_params &&
        ((c = jj(c, b.google_timing_params, d)),
        (b.google_timing_params = void 0));
      Nb(a.F, function (e) {
        var f = u(e);
        e = f.next().value;
        f = f.next().value;
        var g = {};
        c = jj(c, ((g[e] = f), g));
      });
      a.F.length = 0;
      return c;
    };
  pj.prototype.sendBeacon = function (a) {
    this.I++;
    a = tj(this, a);
    var b = !1;
    try {
      b = !!(
        this.U &&
        this.g.navigator &&
        this.g.navigator.sendBeacon(a, null)
      );
    } catch (c) {
      this.U = !1;
    }
    b || Oi(this.g, a);
    kj(this, "puid", (this.I + 1).toString(36) + "~" + Date.now().toString(36));
  };
  var mj = function (a, b) {
    var c = "met." + b.type,
      d =
        "number" === typeof b.value
          ? Math.round(b.value).toString(36)
          : b.value,
      e = Math.round(b.duration);
    b =
      "" +
      b.label +
      (null != b.slotId ? "_" + b.slotId : "") +
      ("." + d) +
      (0 < e ? "_" + e.toString(36) : "") +
      (null != b.taskId ? "__" + Math.round(b.taskId).toString(36) : "");
    sj(a, c, b, !0, "~");
  };
  pj.prototype.C = function (a) {
    this.l && this.I < this.H && (fj.prototype.C.call(this, a), mj(this, a));
  };
  pj.prototype.B = function () {
    fj.prototype.B.call(this);
    this.g.clearTimeout(this.N);
    this.j = this.N = 0;
    this.report = {};
    ah(this.G);
    ah(this.o);
    Og(this.g, "load", this.J);
    Og(this.g, "pagehide", this.L);
  };
  var I = function (a) {
    var b = "tb";
    if (a.tb && a.hasOwnProperty(b)) return a.tb;
    b = new a();
    return (a.tb = b);
  };
  var J = function () {
      this.g = new pj(
        1,
        "https:",
        "csi.gstatic.com",
        "/csi?v=2&s=",
        "ima",
        void 0,
        !0
      );
      var a = Li();
      null != a && kj(this.g, "c", a);
      a = parseInt(this.g.o.c, 10) / 2;
      null != a && kj(this.g, "slotId", a);
    },
    K = function (a, b, c) {
      if (null != c) {
        a = a.g;
        var d = b + "=" + c;
        a.G[d] || (sj(a, b, c, !1), 1e3 > d.length && (a.G[d] = !0));
      }
    },
    uj = function (a, b) {
      for (var c in b)
        b[c] =
          "object" === typeof b[c]
            ? encodeURIComponent(JSON.stringify(b[c]))
            : encodeURIComponent(String(b[c]));
      a = a.g;
      var d = !1;
      c = 0;
      for (var e = u(Object.keys(b)), f = e.next(); !f.done; f = e.next())
        (f = f.value),
          null != a.report[f] && (d = !0),
          (c += qj(a, f, b[f], !1));
      (8e3 < a.A + a.j + c || d) && lj(a);
      d = u(Object.keys(b));
      for (e = d.next(); !e.done; e = d.next())
        (e = e.value), rj(a, e, b[e], !1);
      a.j += c;
      nj(a);
    },
    L = function (a) {
      var b = J.getInstance().g;
      b.l && b.C(new bj(a, 4, Yi() - 0, 0));
    };
  J.prototype.recordClick = function (a, b, c, d) {
    for (
      var e = !1, f = "notag";
      void 0 != d && d != document.documentElement;

    ) {
      var g = void 0,
        h = void 0;
      if (
        (null == (g = d) ? 0 : g.getAttribute("data-ck-navigates")) ||
        (null == (h = d) ? 0 : h.getAttribute("data-ck-tag"))
      ) {
        g = f = void 0;
        e =
          null !=
          (g = null == (f = d) ? void 0 : f.getAttribute("data-ck-navigates"))
            ? g
            : !1;
        h = g = void 0;
        f =
          null != (h = null == (g = d) ? void 0 : g.getAttribute("data-ck-tag"))
            ? h
            : "notag";
        break;
      }
      g = void 0;
      d = null != (g = d.parentElement) ? g : void 0;
    }
    d = this.g;
    d.l && d.C(new bj(a + "_" + b + "x" + c + "|" + e + "|" + f, 4, Yi(), 0));
  };
  J.getInstance = function () {
    return I(J);
  };
  var vj = function (a) {
      return /^\s*$/.test(a)
        ? !1
        : /^[\],:{}\s\u2028\u2029]*$/.test(
            a
              .replace(/\\["\\\/bfnrtu]/g, "@")
              .replace(
                /(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g,
                "]"
              )
              .replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, "")
          );
    },
    wj = function (a) {
      try {
        return x.JSON.parse(a);
      } catch (b) {}
      a = String(a);
      if (vj(a))
        try {
          return eval("(" + a + ")");
        } catch (b) {}
      throw Error("Invalid JSON string: " + a);
    },
    yj = function () {
      this.g = xj;
    },
    zj = function (a, b, c) {
      if (null == b) c.push("null");
      else {
        if ("object" == typeof b) {
          if (Array.isArray(b)) {
            var d = b;
            b = d.length;
            c.push("[");
            for (var e = "", f = 0; f < b; f++)
              c.push(e),
                (e = d[f]),
                zj(a, a.g ? a.g.call(d, String(f), e) : e, c),
                (e = ",");
            c.push("]");
            return;
          }
          if (
            b instanceof String ||
            b instanceof Number ||
            b instanceof Boolean
          )
            b = b.valueOf();
          else {
            c.push("{");
            f = "";
            for (d in b)
              Object.prototype.hasOwnProperty.call(b, d) &&
                ((e = b[d]),
                "function" != typeof e &&
                  (c.push(f),
                  Aj(d, c),
                  c.push(":"),
                  zj(a, a.g ? a.g.call(b, d, e) : e, c),
                  (f = ",")));
            c.push("}");
            return;
          }
        }
        switch (typeof b) {
          case "string":
            Aj(b, c);
            break;
          case "number":
            c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
            break;
          case "boolean":
            c.push(String(b));
            break;
          case "function":
            c.push("null");
            break;
          default:
            throw Error("Unknown type: " + typeof b);
        }
      }
    },
    Bj = {
      '"': '\\"',
      "\\": "\\\\",
      "/": "\\/",
      "\b": "\\b",
      "\f": "\\f",
      "\n": "\\n",
      "\r": "\\r",
      "\t": "\\t",
      "\v": "\\u000b",
    },
    Cj = /\uffff/.test("\uffff")
      ? /[\\"\x00-\x1f\x7f-\uffff]/g
      : /[\\"\x00-\x1f\x7f-\xff]/g,
    Aj = function (a, b) {
      b.push(
        '"',
        a.replace(Cj, function (c) {
          var d = Bj[c];
          d ||
            ((d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).slice(1)),
            (Bj[c] = d));
          return d;
        }),
        '"'
      );
    };
  var Dj = function () {
      this.l = null;
      this.g = "missing-id";
      this.j = !1;
    },
    Fj = function (a) {
      var b = null;
      try {
        b = document.getElementsByClassName("lima-exp-data");
      } catch (c) {
        return Ej("missing-element", a.g), null;
      }
      if (1 < b.length) return Ej("multiple-elements", a.g), null;
      b = b[0];
      return b ? b.innerHTML : (Ej("missing-element", a.g), null);
    },
    Hj = function () {
      var a = Gj,
        b = Fj(a);
      if (null !== b)
        if (vj(b)) {
          var c = JSON.parse(b);
          b = c.experimentIds;
          var d = c.binaryIdentifier;
          c = c.adEventId;
          var e = "string" === typeof d;
          if ("string" == typeof c) {
            var f = J.getInstance();
            null != c && kj(f.g, "qqid", c);
          }
          e && (a.g = d);
          "string" !== typeof b
            ? Ej("missing-flags", a.g)
            : (e || Ej("missing-binary-id", a.g), (a.l = b));
        } else Ej("invalid-json", a.g);
    };
  Dj.prototype.reset = function () {
    this.l = null;
    this.g = "missing-id";
  };
  var Ij = function (a, b, c) {
      this.id = a;
      this.D = b;
      this.j = c;
      this.g = !1;
    },
    M = function (a) {
      return a.g || a.j;
    },
    Jj = function () {
      this.g = [];
    },
    Kj = function () {
      this.g = new Map();
      this.j = !1;
      this.A = new Jj();
      this.o = new Ij(0, 0, !1);
      this.l = [this.A];
    },
    N = function (a) {
      var b = Lj;
      if (
        b.j ||
        b.g.has(a.id) ||
        (null == a.D && null == a.control) ||
        0 == a.Ai
      )
        return b.o;
      var c = b.A;
      if (null != a.control)
        for (var d = u(b.l), e = d.next(); !e.done; e = d.next()) {
          if (((e = e.value), e.g.includes(a.control))) {
            c = e;
            break;
          }
        }
      else null != a.V && (c = a.V);
      d = 0;
      null != a.control ? (d = a.control.D) : null != a.D && (d = a.D);
      a = new Ij(a.id, d, !!a.Di);
      c.g.push(a);
      b.l.includes(c) || b.l.push(c);
      b.g.set(a.id, a);
      return a;
    },
    Mj = function () {
      var a = Lj;
      return [].concat(ha(a.g.keys())).filter(function (b) {
        return M(this.g.get(b));
      }, a);
    },
    Nj = function (a) {
      var b = Lj;
      b.j || (a.g(b.l, b.g), (b.j = !0));
    };
  Kj.prototype.reset = function () {
    for (var a = u(this.g), b = a.next(); !b.done; b = a.next())
      (b = u(b.value)), b.next(), (b.next().value.g = !1);
    this.j = !1;
  };
  var Lj = new Kj(),
    Pj = function () {
      return Oj.g
        .filter(function (a) {
          return M(a);
        })
        .map(function (a) {
          return a.id;
        });
    };
  var Qj = function () {};
  Qj.prototype.g = function (a) {
    a = u(a);
    for (var b = a.next(); !b.done; b = a.next()) {
      var c = 0,
        d = Math.floor(1e3 * Math.random());
      b = u(b.value.g);
      for (var e = b.next(); !e.done; e = b.next())
        if (((e = e.value), (c += e.D), d < c)) {
          e.g = !0;
          break;
        }
    }
  };
  var Rj = function (a) {
    this.j = a;
  };
  Rj.prototype.g = function (a, b) {
    a = u(this.j);
    for (var c = a.next(); !c.done; c = a.next())
      if ((c = b.get(c.value))) c.g = !0;
  };
  var Sj = function (a, b) {
    this.j = a;
    this.l = b;
  };
  v(Sj, Rj);
  Sj.prototype.g = function (a, b) {
    Rj.prototype.g.call(this, a, b);
    var c = [];
    a = [];
    for (var d = u(this.j), e = d.next(); !e.done; e = d.next())
      (e = e.value), b.get(e) ? c.push(e) : a.push(e);
    b = c.map(String).join(",") || "0";
    a = a.map(String).join(",") || "0";
    K(J.getInstance(), "sei", b);
    K(J.getInstance(), "nsei", a);
    K(J.getInstance(), "bi", this.l);
  };
  var Tj = function () {
    Dj.apply(this, arguments);
  };
  v(Tj, Dj);
  var Ej = function (a, b) {
    var c = J.getInstance();
    K(c, "eee", a);
    K(c, "bi", b);
  };
  Tj.getInstance = function () {
    return I(Tj);
  };
  function Uj() {
    return Vj.split(",")
      .map(function (a) {
        return parseInt(a, 10);
      })
      .filter(function (a) {
        return !isNaN(a);
      });
  }
  var Oj = new Jj(),
    Wj = new Jj(),
    Xj = new Jj(),
    Yj = new Jj(),
    Zj = new Jj(),
    ak = new Jj(),
    bk = new Jj(),
    ck = new Jj(),
    dk = new Jj(),
    ek = new Jj(),
    fk = new Jj(),
    gk = new Jj(),
    hk = new Jj(),
    ik = new Jj(),
    jk = new Jj(),
    kk = new Jj(),
    lk = new Jj(),
    mk = new Jj(),
    nk = new Jj();
  N({ id: 95329493, D: 0 });
  N({ id: 95329494, D: 0 });
  N({ id: 318475490, D: 0 });
  N({ id: 324123032, D: 0 });
  N({ id: 418572103, D: 0 });
  N({ id: 420706097, D: 10 });
  N({ id: 420706098, D: 10 });
  N({ id: 21062100, D: 0 });
  N({ id: 420706105, D: 0 });
  N({ id: 420706106, D: 0 });
  N({ id: 420706142, D: 0 });
  N({ id: 44745813, D: 0 });
  N({ id: 44746068, D: 0 });
  N({ id: 21064565, D: 0 });
  N({ id: 21064567, D: 0 });
  N({ id: 418572006, D: 10 });
  var ok = N({ id: 44768716, D: 10, V: bk }),
    pk = N({ id: 44768717, D: 10, V: bk }),
    qk = N({ id: 44787137, D: 0, V: bk }),
    rk = N({ id: 44744588, D: 10 }),
    sk = N({ id: 44747319, D: 10 });
  N({ id: 44740339, D: 10 });
  var tk = N({ id: 44740340, D: 10 });
  N({ id: 44749839, D: 0 });
  N({ id: 44714743, D: 0 });
  N({ id: 44719216, D: 0 });
  N({ id: 44715336, D: 10 });
  N({ id: 75259410, D: 0 });
  N({ id: 75259412, D: 0 });
  N({ id: 75259413, D: 0 });
  N({ id: 44773378, D: 10, V: Wj });
  var uk = N({ id: 44773379, D: 10, V: Wj });
  N({ id: 44724516, D: 0 });
  N({ id: 44726389, D: 10 });
  N({ id: 44752711, D: 50 });
  N({ id: 44752052, D: 50 });
  N({ id: 44752657, D: 50 });
  N({ id: 44781407, V: Xj, D: 0 });
  N({ id: 44781408, V: Xj, D: 0 });
  N({ id: 44781409, V: Xj, D: 1e3 });
  N({ id: 44777647, V: Yj, D: 0 });
  N({ id: 44777648, V: Yj, D: 0 });
  N({ id: 44777649, V: Yj, D: 1e3 });
  N({ id: 44727953, D: 0 });
  N({ id: 44733246, D: 10 });
  N({ id: 44750823, D: 10, V: Zj });
  N({ id: 44750824, D: 10, V: Zj });
  N({ id: 44794282, D: 10, V: Zj });
  N({ id: 44797013, D: 10, V: Zj });
  N({ id: 44797014, D: 10, V: Zj });
  N({ id: 44750822, D: 10, V: Zj });
  N({ id: 44751889, D: 10 });
  N({ id: 44751890, D: 10 });
  N({ id: 44752995, D: 10 });
  N({ id: 44752996, D: 10 });
  N({ id: 44762627, D: 0 });
  N({ id: 44762628, D: 0 });
  N({ id: 95322371, D: 5 });
  N({ id: 95322372, D: 5 });
  N({ id: 95327100, D: 0 });
  N({ id: 44801479, D: 10, V: ak });
  N({ id: 44801480, D: 10, V: ak });
  N({ id: 44752538, D: 0 });
  N({ id: 44754608, D: 10 });
  N({ id: 44754609, D: 10 });
  N({ id: 44770822, D: 10 });
  N({ id: 44770823, D: 10 });
  N({ id: 44770824, D: 10 });
  N({ id: 44770825, D: 10 });
  N({ id: 75259414, D: 0 });
  var vk,
    wk = (
      null == (vk = window.document.featurePolicy)
        ? 0
        : vk.allowedFeatures().includes("attribution-reporting")
    )
      ? 300
      : 0;
  N({ id: 44776494, D: wk, V: ck });
  N({ id: 44776495, D: wk, V: ck });
  N({ id: 44776384, D: 0 });
  N({ id: 95322945, D: 10 });
  var xk = N({ id: 95322946, D: 10 });
  N({ id: 44787954, D: 0 });
  N({ id: 44789282, D: 0 });
  N({ id: 44792636, D: 0 });
  N({ id: 44794298, D: 0 });
  N({ id: 44803996, D: 0 });
  N({ id: 44805453, D: 0 });
  N({ id: 44804917, D: 0 });
  N({ id: 44809796, D: 0 });
  N({ id: 75259415, D: 0 });
  var yk = N({ id: 75259416, D: 0 }),
    zk = N({ id: 75259420, D: 0 }),
    Ak = N({ id: 75259421, D: 0 });
  N({ id: 44785452, D: 10 });
  N({ id: 44785453, D: 10 });
  N({ id: 45401791, D: 0 });
  N({ id: 44795414, D: 1, V: dk });
  var Bk = N({ id: 44795415, D: 1, V: dk }),
    Ck = N({ id: 44795416, D: 1, V: dk }),
    Dk = N({ id: 44795417, D: 1, V: dk });
  N({ id: 95326337, D: 990, V: ek });
  N({ id: 44802172, D: 10 });
  var Ek = N({ id: 44802173, D: 10 });
  N({ id: 44806074, D: 50, V: lk });
  N({ id: 44806075, D: 50, V: lk });
  N({ id: 44806732, D: 10 });
  N({ id: 44806733, D: 10 });
  var Fk = window.navigator || {},
    Gk = Fk.cookieDeprecationLabel ? 990 : 0;
  N({ id: 95322906, D: Fk.cookieDeprecationLabel ? 10 : 0, V: fk });
  var Hk = N({ id: 95320461, D: 0, V: fk }),
    Ik = N({ id: 95322907, D: Gk, V: fk });
  N({ id: 44807614, D: 10 });
  N({ id: 44807615, D: 10 });
  N({ id: 95322545, D: 10 });
  var Jk = N({ id: 95322546, D: 10 }),
    Kk = N({ id: 95322547, D: 10 }),
    Lk = N({ id: 95322548, D: 10 });
  N({ id: 44809192, D: 10, V: kk });
  N({ id: 44809193, D: 10, V: kk });
  N({ id: 95320804, D: 10, V: kk });
  N({ id: 95320805, D: 10, V: kk });
  N({ id: 95321947, D: 1e3, V: gk });
  N({ id: 95321698, D: 0 });
  var Mk = N({ id: 95321699, D: 0 });
  N({ id: 95322027, D: 1e3, V: hk });
  N({ id: 95323893, D: 1e3, V: ik });
  N({ id: 95324128, D: 1e3, V: jk });
  var Nk = N({ id: 46130031, D: 0 }),
    Ok = N({ id: 95324210, D: 1e3, V: mk });
  N({ id: 95328713, D: 10 });
  N({ id: 95328714, D: 10 });
  var Pk = N({ id: 95327848, D: 0 });
  N({ id: 95329629, D: 50 });
  N({ id: 95329630, D: 50 });
  N({ id: 95327717, D: 10, V: nk });
  N({ id: 95327718, D: 10, V: nk });
  N({ id: 31065644, D: 1 });
  var Qk = N({ id: 31065645, D: 1 });
  if ("undefined" === typeof window.initializeVirtualDom) {
    var Gj = Tj.getInstance();
    Gj.j || (Hj(), (Gj.j = !0));
    var Vj = Gj.l,
      Rk;
    Gj.j || (Hj(), (Gj.j = !0));
    Rk = Gj.g;
    if (null != Vj) {
      var Sk = new Sj(Uj(), Rk);
      Nj(Sk);
    }
  }
  Lj.reset();
  Nj(new Qj());
  var Tk = function (a) {
    var b = {};
    Nb(a, function (c) {
      var d = c.g,
        e = b[d];
      b.hasOwnProperty(d)
        ? null !== e && (c.j(e) || (b[d] = null))
        : (b[d] = c);
    });
    $b(a, function (c) {
      return null === b[c.g];
    });
  };
  var Uk = { NONE: 0, ih: 1 },
    Vk = { gh: 0, Xh: 1, Wh: 2, Yh: 3 },
    Wk = { Ve: "a", hh: "d", VIDEO: "v" };
  var Xk = function () {
    this.aa = 0;
    this.g = !1;
    this.j = -1;
    this.ub = !1;
    this.ta = 0;
  };
  Xk.prototype.isVisible = function () {
    return this.ub ? 0.3 <= this.aa : 0.5 <= this.aa;
  };
  var Yk = { fh: 0, lh: 1 },
    Zk = { 668123728: 0, 668123729: 1 },
    $k = { 44731964: 0, 44731965: 1 },
    al = { NONE: 0, Kh: 1, qh: 2 },
    bl = { 480596784: 0, 480596785: 1, 21063355: 2 };
  var cl = function () {
      this.g = null;
      this.A = !1;
      this.l = null;
    },
    dl = function (a) {
      a.A = !0;
      return a;
    },
    el = function (a, b) {
      a.l &&
        Nb(b, function (c) {
          c = a.l[c];
          void 0 !== c && a.j(c);
        });
    };
  cl.prototype.getValue = function () {
    return this.g;
  };
  var fl = function (a) {
    cl.call(this);
    this.o = a;
  };
  v(fl, cl);
  fl.prototype.j = function (a) {
    null === this.g && Xg(this.o, a) && (this.g = a);
  };
  var gl = function () {
    cl.call(this);
  };
  v(gl, cl);
  gl.prototype.j = function (a) {
    null === this.g && "number" === typeof a && (this.g = a);
  };
  var hl = function () {
    cl.call(this);
  };
  v(hl, cl);
  hl.prototype.j = function (a) {
    null === this.g && "string" === typeof a && (this.g = a);
  };
  var il = function () {
    this.g = {};
    this.l = !0;
    this.j = {};
  };
  il.prototype.reset = function () {
    this.g = {};
    this.l = !0;
    this.j = {};
  };
  var jl = function (a, b, c) {
      a.g[b] || (a.g[b] = new fl(c));
      return a.g[b];
    },
    kl = function (a) {
      a.g.queryid || (a.g.queryid = new hl());
    },
    ll = function (a, b, c) {
      (a = a.g[b]) && a.j(c);
    },
    ml = function (a, b) {
      if (Wg(a.j, b)) return a.j[b];
      if ((a = a.g[b])) return a.getValue();
    },
    nl = function (a) {
      var b = {},
        c = Qg(a.g, function (d) {
          return d.A;
        });
      Pg(
        c,
        function (d, e) {
          d =
            void 0 !== a.j[e]
              ? String(a.j[e])
              : d.A && null !== d.g
              ? String(d.g)
              : "";
          0 < d.length && (b[e] = d);
        },
        a
      );
      return b;
    },
    ol = function (a) {
      a = nl(a);
      var b = [];
      Pg(a, function (c, d) {
        d in Object.prototype ||
          ("undefined" != typeof c && b.push([d, ":", c].join("")));
      });
      return b;
    },
    pl = function () {
      var a = O().R,
        b = Pj();
      a.l &&
        Nb(Tg(a.g), function (c) {
          return el(c, b);
        });
    };
  var ql = function (a) {
    jl(a, "od", Uk);
    dl(jl(a, "opac", Yk));
    dl(jl(a, "sbeos", Yk));
    dl(jl(a, "prf", Yk));
    dl(jl(a, "mwt", Yk));
    jl(a, "iogeo", Yk);
  };
  var rl = document,
    P = window;
  var sl = !lc && !Eb();
  var tl = function () {
    this.g = this.kb = null;
  };
  var ul = function () {};
  ul.prototype.now = function () {
    return 0;
  };
  ul.prototype.j = function () {
    return 0;
  };
  ul.prototype.l = function () {
    return 0;
  };
  ul.prototype.g = function () {
    return 0;
  };
  var wl = function () {
    if (!vl()) throw Error();
  };
  v(wl, ul);
  var vl = function () {
    return !(!P || !P.performance);
  };
  wl.prototype.now = function () {
    return vl() && P.performance.now
      ? P.performance.now()
      : ul.prototype.now.call(this);
  };
  wl.prototype.j = function () {
    return vl() && P.performance.memory
      ? P.performance.memory.totalJSHeapSize || 0
      : ul.prototype.j.call(this);
  };
  wl.prototype.l = function () {
    return vl() && P.performance.memory
      ? P.performance.memory.usedJSHeapSize || 0
      : ul.prototype.l.call(this);
  };
  wl.prototype.g = function () {
    return vl() && P.performance.memory
      ? P.performance.memory.jsHeapSizeLimit || 0
      : ul.prototype.g.call(this);
  };
  var xl = function () {};
  xl.prototype.isVisible = function () {
    return 1 === Vi(rl);
  };
  var yl = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
    Cl = function (a) {
      a = a || zl();
      for (
        var b = new Al(x.location.href, !1), c = null, d = a.length - 1, e = d;
        0 <= e;
        --e
      ) {
        var f = a[e];
        !c && yl.test(f.url) && (c = f);
        if (f.url && !f.td) {
          b = f;
          break;
        }
      }
      e = null;
      f = a.length && a[d].url;
      0 != b.depth && f && (e = a[d]);
      return new Bl(b, e, c);
    },
    zl = function () {
      var a = x,
        b = [],
        c = null;
      do {
        var d = a;
        if (mi(d)) {
          var e = d.location.href;
          c = (d.document && d.document.referrer) || null;
        } else (e = c), (c = null);
        b.push(new Al(e || ""));
        try {
          a = d.parent;
        } catch (f) {
          a = null;
        }
      } while (a && d != a);
      d = 0;
      for (a = b.length - 1; d <= a; ++d) b[d].depth = a - d;
      d = x;
      if (
        d.location &&
        d.location.ancestorOrigins &&
        d.location.ancestorOrigins.length == b.length - 1
      )
        for (a = 1; a < b.length; ++a)
          (e = b[a]),
            e.url ||
              ((e.url = d.location.ancestorOrigins[a - 1] || ""), (e.td = !0));
      return b;
    },
    Bl = function (a, b, c) {
      this.g = a;
      this.j = b;
      this.l = c;
    },
    Al = function (a, b) {
      this.url = a;
      this.td = !!b;
      this.depth = null;
    };
  var Dl = function () {
      this.l = "&";
      this.j = {};
      this.A = 0;
      this.g = [];
    },
    El = function (a, b) {
      var c = {};
      c[a] = b;
      return [c];
    },
    Gl = function (a, b, c, d, e) {
      var f = [];
      si(a, function (g, h) {
        (g = Fl(g, b, c, d, e)) && f.push(h + "=" + g);
      });
      return f.join(b);
    },
    Fl = function (a, b, c, d, e) {
      if (null == a) return "";
      b = b || "&";
      c = c || ",$";
      "string" == typeof c && (c = c.split(""));
      if (a instanceof Array) {
        if (((d = d || 0), d < c.length)) {
          for (var f = [], g = 0; g < a.length; g++)
            f.push(Fl(a[g], b, c, d + 1, e));
          return f.join(c[d]);
        }
      } else if ("object" == typeof a)
        return (
          (e = e || 0),
          2 > e ? encodeURIComponent(Gl(a, b, c, d, e + 1)) : "..."
        );
      return encodeURIComponent(String(a));
    },
    Hl = function (a, b, c) {
      a.g.push(b);
      a.j[b] = c;
    },
    Il = function (a, b, c, d) {
      a.g.push(b);
      a.j[b] = El(c, d);
    },
    Kl = function (a, b, c) {
      b = b + "//pagead2.googlesyndication.com" + c;
      var d = Jl(a) - c.length;
      if (0 > d) return "";
      a.g.sort(function (m, r) {
        return m - r;
      });
      c = null;
      for (var e = "", f = 0; f < a.g.length; f++)
        for (var g = a.g[f], h = a.j[g], k = 0; k < h.length; k++) {
          if (!d) {
            c = null == c ? g : c;
            break;
          }
          var n = Gl(h[k], a.l, ",$");
          if (n) {
            n = e + n;
            if (d >= n.length) {
              d -= n.length;
              b += n;
              e = a.l;
              break;
            }
            c = null == c ? g : c;
          }
        }
      a = "";
      null != c && (a = e + "trn=" + c);
      return b + a;
    },
    Jl = function (a) {
      var b = 1,
        c;
      for (c in a.j) b = c.length > b ? c.length : b;
      return 3997 - b - a.l.length - 1;
    };
  var Ll = function (a, b) {
      this.g = a;
      this.depth = b;
    },
    Nl = function () {
      var a = zl(),
        b = Math.max(a.length - 1, 0),
        c = Cl(a);
      a = c.g;
      var d = c.j,
        e = c.l,
        f = [];
      c = function (h, k) {
        return null == h ? k : h;
      };
      e && f.push(new Ll([e.url, e.td ? 2 : 0], c(e.depth, 1)));
      d && d != e && f.push(new Ll([d.url, 2], 0));
      a.url && a != e && f.push(new Ll([a.url, 0], c(a.depth, b)));
      var g = Qb(f, function (h, k) {
        return f.slice(0, f.length - k);
      });
      !a.url ||
        ((e || d) && a != e) ||
        ((d = ui(a.url)) && g.push([new Ll([d, 1], c(a.depth, b))]));
      g.push([]);
      return Qb(g, function (h) {
        return Ml(b, h);
      });
    };
  function Ml(a, b) {
    var c = Rb(
        b,
        function (e, f) {
          return Math.max(e, f.depth);
        },
        -1
      ),
      d = fc(c + 2);
    d[0] = a;
    Nb(b, function (e) {
      return (d[e.depth + 1] = e.g);
    });
    return d;
  }
  function Ol() {
    var a = void 0 === a ? Nl() : a;
    return a.map(function (b) {
      return Fl(b);
    });
  }
  var Pl = function () {
      this.j = new xl();
      this.g = vl() ? new wl() : new ul();
    },
    Rl = function () {
      Ql();
      var a = P.document;
      return !!(
        a &&
        a.body &&
        a.body.getBoundingClientRect &&
        "function" === typeof P.setInterval &&
        "function" === typeof P.clearInterval &&
        "function" === typeof P.setTimeout &&
        "function" === typeof P.clearTimeout
      );
    };
  Pl.prototype.setTimeout = function (a, b) {
    return P.setTimeout(a, b);
  };
  Pl.prototype.clearTimeout = function (a) {
    P.clearTimeout(a);
  };
  var Sl = function () {
    Ql();
    return Ol();
  };
  var Tl = function () {},
    Ql = function () {
      var a = I(Tl);
      if (!a.g) {
        if (!P)
          throw Error("Context has not been set and window is undefined.");
        a.g = I(Pl);
      }
      return a.g;
    };
  var Ul = function (a) {
    this.K = B(a);
  };
  v(Ul, F);
  Ul.prototype.g = Eg([0, jg, ng, -2, rg]);
  var Vl = function (a) {
      this.l = a;
      this.g = -1;
      this.j = this.A = 0;
    },
    Wl = function (a, b) {
      return function () {
        var c = Ia.apply(0, arguments);
        if (-1 < a.g) return b.apply(null, ha(c));
        try {
          return (a.g = a.l.g.now()), b.apply(null, ha(c));
        } finally {
          (a.A += a.l.g.now() - a.g), (a.g = -1), (a.j += 1);
        }
      };
    };
  var Xl = function (a, b) {
    this.j = a;
    this.l = b;
    this.g = new Vl(a);
  };
  var Yl = function () {
      this.g = {};
    },
    $l = function () {
      var a = O().flags,
        b = Zl;
      a = a.g[b.key];
      if ("proto" === b.valueType) {
        try {
          var c = JSON.parse(a);
          if (Array.isArray(c)) return c;
        } catch (d) {}
        return b.defaultValue;
      }
      return typeof a === typeof b.defaultValue ? a : b.defaultValue;
    };
  var am = { Th: 1, li: 2, Ph: 3 };
  var bm = function () {
    this.l = void 0;
    this.j = this.B = 0;
    this.o = -1;
    this.R = new il();
    dl(jl(this.R, "mv", al)).l = void 0 === bl ? null : bl;
    jl(this.R, "omid", Yk);
    dl(jl(this.R, "epoh", Yk));
    dl(jl(this.R, "epph", Yk));
    dl(jl(this.R, "umt", Yk)).l = void 0 === Zk ? null : Zk;
    dl(jl(this.R, "phel", Yk));
    dl(jl(this.R, "phell", Yk));
    dl(jl(this.R, "oseid", am));
    var a = this.R;
    a.g.sloi || (a.g.sloi = new gl());
    dl(a.g.sloi);
    jl(this.R, "mm", Wk);
    dl(jl(this.R, "ovms", Vk));
    dl(jl(this.R, "xdi", Yk));
    dl(jl(this.R, "amp", Yk));
    dl(jl(this.R, "prf", Yk));
    dl(jl(this.R, "gtx", Yk));
    dl(jl(this.R, "mvp_lv", Yk));
    dl(jl(this.R, "ssmol", Yk)).l = void 0 === $k ? null : $k;
    dl(jl(this.R, "fmd", Yk));
    jl(this.R, "gen204simple", Yk);
    this.g = new Xl(Ql(), this.R);
    this.A = !1;
    this.flags = new Yl();
  };
  bm.prototype.Gd = function (a) {
    if ("string" === typeof a && 0 != a.length) {
      var b = this.R;
      if (b.l) {
        a = a.split("&");
        for (var c = a.length - 1; 0 <= c; c--) {
          var d = a[c].split("="),
            e = decodeURIComponent(d[0]);
          1 < d.length
            ? ((d = decodeURIComponent(d[1])),
              (d = /^[0-9]+$/g.exec(d) ? parseInt(d, 10) : d))
            : (d = 1);
          (e = b.g[e]) && e.j(d);
        }
      }
    }
  };
  var O = function () {
    return I(bm);
  };
  var cm = function (a, b, c, d, e) {
    if ((d ? a.l : Math.random()) < (e || a.g))
      try {
        if (c instanceof Dl) var f = c;
        else
          (f = new Dl()),
            si(c, function (h, k) {
              var n = f,
                m = n.A++;
              Hl(n, m, El(k, h));
            });
        var g = Kl(f, a.j, "/pagead/gen_204?id=" + b + "&");
        g && (Ql(), Oi(P, g));
      } catch (h) {}
  };
  var fm = function () {
    var a = dm;
    this.B = em;
    this.o = "jserror";
    this.l = !0;
    this.j = null;
    this.C = this.Ua;
    this.g = void 0 === a ? null : a;
    this.A = !1;
  };
  l = fm.prototype;
  l.Wc = function (a) {
    this.j = a;
  };
  l.Od = function (a) {
    this.o = a;
  };
  l.Pd = function (a) {
    this.l = a;
  };
  l.Qd = function (a) {
    this.A = a;
  };
  l.wb = function (a, b, c) {
    var d = this;
    return Wl(O().g.g, function () {
      try {
        if (d.g && d.g.l) {
          var e = d.g.start(a.toString(), 3);
          var f = b();
          d.g.end(e);
        } else f = b();
      } catch (h) {
        var g = d.l;
        try {
          gj(e), (g = d.C(a, new gm(hm(h)), void 0, c));
        } catch (k) {
          d.Ua(217, k);
        }
        if (!g) throw h;
      }
      return f;
    })();
  };
  l.Hd = function (a, b, c, d) {
    var e = this;
    return Wl(O().g.g, function () {
      var f = Ia.apply(0, arguments);
      return e.wb(
        a,
        function () {
          return b.apply(c, f);
        },
        d
      );
    });
  };
  l.Ua = function (a, b, c, d, e) {
    e = e || this.o;
    try {
      var f = new Dl();
      Il(f, 1, "context", a);
      Si(b) || (b = new gm(hm(b)));
      b.msg && Il(f, 2, "msg", b.msg.substring(0, 512));
      var g = b.meta || {};
      if (this.j)
        try {
          this.j(g);
        } catch (k) {}
      if (d)
        try {
          d(g);
        } catch (k) {}
      Hl(f, 3, [g]);
      var h = Cl();
      h.j && Il(f, 4, "top", h.j.url || "");
      Hl(f, 5, [{ url: h.g.url || "" }, { url: h.g.url ? ii(h.g.url) : "" }]);
      cm(this.B, e, f, this.A, c);
    } catch (k) {
      try {
        cm(
          this.B,
          e,
          { context: "ecmserr", rctx: a, msg: hm(k), url: h && h.g.url },
          this.A,
          c
        );
      } catch (n) {}
    }
    return this.l;
  };
  var hm = function (a) {
      var b = a.toString();
      a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
      a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
      if (a.stack) {
        a = a.stack;
        var c = b;
        try {
          -1 == a.indexOf(c) && (a = c + "\n" + a);
          for (var d; a != d; )
            (d = a),
              (a = a.replace(/((https?:\/..*\/)[^\/:]*:\d+(?:.|\n)*)\2/, "$1"));
          b = a.replace(/\n */g, "\n");
        } catch (e) {
          b = c;
        }
      }
      return b;
    },
    gm = function (a) {
      Ri.call(this, Error(a), { message: a });
    };
  v(gm, Ri);
  var em,
    im,
    dm = new fj(1, window),
    jm = function () {
      P &&
        "undefined" != typeof P.google_measure_js_timing &&
        (P.google_measure_js_timing || dm.B());
    };
  em = new (function () {
    var a = "https:";
    P && P.location && "http:" === P.location.protocol && (a = "http:");
    this.j = a;
    this.g = 0.01;
    this.l = Math.random();
  })();
  im = new fm();
  P &&
    P.document &&
    ("complete" == P.document.readyState
      ? jm()
      : dm.l &&
        Ng(P, "load", function () {
          jm();
        }));
  var km = function (a) {
      im.Wc(function (b) {
        Nb(a, function (c) {
          c(b);
        });
      });
    },
    lm = function (a, b) {
      return im.wb(a, b);
    },
    mm = function (a, b, c, d) {
      return im.Hd(a, b, c, d);
    },
    nm = function (a, b, c, d) {
      im.Ua(a, b, c, d);
    };
  var om = Date.now(),
    pm = -1,
    qm = -1,
    rm,
    sm = -1,
    tm = !1,
    um = function () {
      return Date.now() - om;
    },
    vm = function () {
      var a = O().l,
        b = 0 <= qm ? um() - qm : -1,
        c = tm ? um() - pm : -1,
        d = 0 <= sm ? um() - sm : -1;
      if (947190542 == a) return 100;
      if (79463069 == a) return 200;
      a = [2e3, 4e3];
      var e = [250, 500, 1e3];
      nm(637, Error(), 0.001);
      var f = b;
      -1 != c && c < b && (f = c);
      for (b = 0; b < a.length; ++b)
        if (f < a[b]) {
          var g = e[b];
          break;
        }
      void 0 === g && (g = e[a.length]);
      return -1 != d && 1500 < d && 4e3 > d ? 500 : g;
    };
  var wm = function (a, b, c) {
    var d = new H(0, 0, 0, 0);
    this.time = a;
    this.volume = null;
    this.l = b;
    this.g = d;
    this.j = c;
  };
  var xm = function (a, b, c, d, e, f, g) {
    this.l = a;
    this.j = b;
    this.o = c;
    this.g = d;
    this.A = e;
    this.C = f;
    this.B = g;
  };
  xm.prototype.getTimestamp = function () {
    return this.C;
  };
  var ym = {
      currentTime: 1,
      duration: 2,
      isVpaid: 4,
      volume: 8,
      isYouTube: 16,
      isPlaying: 32,
    },
    Zg = {
      ee: "start",
      FIRST_QUARTILE: "firstquartile",
      MIDPOINT: "midpoint",
      THIRD_QUARTILE: "thirdquartile",
      COMPLETE: "complete",
      ERROR: "error",
      kf: "metric",
      PAUSE: "pause",
      vf: "resume",
      SKIPPED: "skip",
      VIEWABLE_IMPRESSION: "viewable_impression",
      lf: "mute",
      zf: "unmute",
      FULLSCREEN: "fullscreen",
      gf: "exitfullscreen",
      af: "bufferstart",
      Ze: "bufferfinish",
      Zd: "fully_viewable_audible_half_duration_impression",
      de: "measurable_impression",
      Ue: "abandon",
      Yd: "engagedview",
      IMPRESSION: "impression",
      cf: "creativeview",
      LOADED: "loaded",
      PROGRESS: "progress",
      Xg: "close",
      Yg: "collapse",
      mf: "overlay_resize",
      nf: "overlay_unmeasurable_impression",
      qf: "overlay_unviewable_impression",
      sf: "overlay_viewable_immediate_impression",
      rf: "overlay_viewable_end_of_session_impression",
      df: "custom_metric_viewable",
      We: "audio_audible",
      Ye: "audio_measurable",
      Xe: "audio_impression",
    },
    zm = "start firstquartile midpoint thirdquartile resume loaded".split(" "),
    Am = ["start", "firstquartile", "midpoint", "thirdquartile"],
    Bm = ["abandon"],
    Cm = {
      UNKNOWN: -1,
      ee: 0,
      FIRST_QUARTILE: 1,
      MIDPOINT: 2,
      THIRD_QUARTILE: 3,
      COMPLETE: 4,
      kf: 5,
      PAUSE: 6,
      vf: 7,
      SKIPPED: 8,
      VIEWABLE_IMPRESSION: 9,
      lf: 10,
      zf: 11,
      FULLSCREEN: 12,
      gf: 13,
      Zd: 14,
      de: 15,
      Ue: 16,
      Yd: 17,
      IMPRESSION: 18,
      cf: 19,
      LOADED: 20,
      df: 21,
      af: 22,
      Ze: 23,
      Xe: 27,
      Ye: 28,
      We: 29,
    };
  var Sg = {
      Tg: "addEventListener",
      rh: "getMaxSize",
      sh: "getScreenSize",
      th: "getState",
      uh: "getVersion",
      Vh: "removeEventListener",
      Lh: "isViewable",
    },
    Dm = function (a) {
      var b = a !== a.top,
        c = a.top === zi(a),
        d = -1,
        e = 0;
      if (b && c && a.top.mraid) {
        d = 3;
        var f = a.top.mraid;
      } else d = (f = a.mraid) ? (b ? (c ? 2 : 1) : 0) : -1;
      f &&
        (f.IS_GMA_SDK || (e = 2),
        Rg(function (g) {
          return "function" === typeof f[g];
        }) || (e = 1));
      return { Da: f, uc: e, Cg: d };
    };
  var Em = function () {
    var a = window.document;
    return a && "function" === typeof a.elementFromPoint;
  };
  function Fm(a, b, c) {
    try {
      a && (b = b.top);
      var d = b;
      a && null !== d && d != d.top && (d = d.top);
      try {
        var e = (void 0 === c ? 0 : c)
          ? new Bh(d.innerWidth, d.innerHeight).round()
          : Wh(d || window).round();
      } catch (m) {
        e = new Bh(-12245933, -12245933);
      }
      a = e;
      var f = a.height,
        g = a.width;
      if (-12245933 === g) return new H(g, g, g, g);
      var h = Xh(Sh(b.document).g),
        k = h.x,
        n = h.y;
      return new H(n, k + g, n + f, k);
    } catch (m) {
      return new H(-12245933, -12245933, -12245933, -12245933);
    }
  }
  var Hm = function (a, b) {
      if ("string" === typeof b) (b = Gm(a, b)) && (a.style[b] = void 0);
      else
        for (var c in b) {
          var d = a,
            e = b[c],
            f = Gm(d, c);
          f && (d.style[f] = e);
        }
    },
    Im = {},
    Gm = function (a, b) {
      var c = Im[b];
      if (!c) {
        var d = Mh(b);
        c = d;
        void 0 === a.style[d] &&
          ((d = (oc ? "Webkit" : nc ? "Moz" : lc ? "ms" : null) + Oh(d)),
          void 0 !== a.style[d] && (c = d));
        Im[b] = c;
      }
      return c;
    },
    Jm = function (a, b) {
      var c = a.style[Mh(b)];
      return "undefined" !== typeof c ? c : a.style[Gm(a, b)] || "";
    },
    Km = function (a, b) {
      var c = Rh(a);
      return c.defaultView &&
        c.defaultView.getComputedStyle &&
        (a = c.defaultView.getComputedStyle(a, null))
        ? a[b] || a.getPropertyValue(b) || ""
        : "";
    },
    Lm = function (a) {
      try {
        return a.getBoundingClientRect();
      } catch (b) {
        return { left: 0, top: 0, right: 0, bottom: 0 };
      }
    },
    Mm = function (a) {
      var b = Rh(a),
        c = new Ah(0, 0);
      if (a == (b ? Rh(b) : document).documentElement) return c;
      a = Lm(a);
      b = Xh(Sh(b).g);
      c.x = a.left + b.x;
      c.y = a.top + b.y;
      return c;
    },
    Nm = function (a, b) {
      var c = new Ah(0, 0),
        d = G(Rh(a));
      if (!hc(d, "parent")) return c;
      do {
        if (d == b) var e = Mm(a);
        else (e = Lm(a)), (e = new Ah(e.left, e.top));
        c.x += e.x;
        c.y += e.y;
      } while (
        d &&
        d != b &&
        d != d.parent &&
        (a = d.frameElement) &&
        (d = d.parent)
      );
      return c;
    },
    Om = function () {
      var a = "100%";
      "number" == typeof a && (a = Math.round(a) + "px");
      return a;
    },
    Qm = function (a) {
      var b = Pm,
        c;
      (c = Km(a, "display")) ||
        (c = a.currentStyle ? a.currentStyle.display : null);
      if ("none" != (c || (a.style && a.style.display))) return b(a);
      c = a.style;
      var d = c.display,
        e = c.visibility,
        f = c.position;
      c.visibility = "hidden";
      c.position = "absolute";
      c.display = "inline";
      a = b(a);
      c.display = d;
      c.position = f;
      c.visibility = e;
      return a;
    },
    Pm = function (a) {
      var b = a.offsetWidth,
        c = a.offsetHeight,
        d = oc && !b && !c;
      return (void 0 === b || d) && a.getBoundingClientRect
        ? ((a = Lm(a)), new Bh(a.right - a.left, a.bottom - a.top))
        : new Bh(b, c);
    },
    Rm = function (a) {
      var b = new Bh(a.offsetWidth, a.offsetHeight);
      var c = Km(a, "paddingLeft");
      var d = Km(a, "paddingRight"),
        e = Km(a, "paddingTop"),
        f = Km(a, "paddingBottom");
      c = new H(parseFloat(e), parseFloat(d), parseFloat(f), parseFloat(c));
      d = Km(a, "borderLeftWidth");
      e = Km(a, "borderRightWidth");
      f = Km(a, "borderTopWidth");
      a = Km(a, "borderBottomWidth");
      a = new H(parseFloat(f), parseFloat(e), parseFloat(a), parseFloat(d));
      return new Bh(
        b.width - a.left - c.left - c.right - a.right,
        b.height - a.top - c.top - c.bottom - a.bottom
      );
    };
  var Sm = function (a, b) {
    b = Math.pow(10, b);
    return Math.floor(a * b) / b;
  };
  function Tm(a, b, c, d) {
    if (!a) return { value: d, done: !1 };
    d = b(d, a);
    var e = c(d, a);
    return !e && hc(a, "parentElement")
      ? Tm(bi(a), b, c, d)
      : { done: e, value: d };
  }
  var Um = function (a, b, c, d) {
    if (!a) return d;
    d = Tm(a, b, c, d);
    if (!d.done)
      try {
        var e = Rh(a),
          f = e && G(e);
        return Um(f && f.frameElement, b, c, d.value);
      } catch (g) {}
    return d.value;
  };
  function Vm(a) {
    var b = !lc || Bc();
    return Um(
      a,
      function (c, d) {
        c = hc(d, "style") && d.style && Jm(d, "visibility");
        return { hidden: "hidden" === c, visible: b && "visible" === c };
      },
      function (c) {
        return c.hidden || c.visible;
      },
      { hidden: !1, visible: !1 }
    ).hidden;
  }
  var Wm = function (a) {
      return Um(
        a,
        function (b, c) {
          return !(!hc(c, "style") || !c.style || "none" !== Jm(c, "display"));
        },
        function (b) {
          return b;
        },
        !1
      )
        ? !0
        : Vm(a);
    },
    Xm = function (a) {
      return new H(a.top, a.right, a.bottom, a.left);
    },
    Ym = function (a) {
      var b = a.top || 0,
        c = a.left || 0;
      return new H(b, c + (a.width || 0), b + (a.height || 0), c);
    },
    Zm = function (a) {
      return null != a && 0 <= a && 1 >= a;
    };
  function $m() {
    var a = wb();
    return a
      ? Sb(
          "AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(
            ";"
          ),
          function (b) {
            return qb(a, b);
          }
        ) ||
        (qb(a, "OMI/") && !qb(a, "XiaoMi/"))
        ? !0
        : qb(a, "Presto") &&
          qb(a, "Linux") &&
          !qb(a, "X11") &&
          !qb(a, "Android") &&
          !qb(a, "Mobi")
      : !1;
  }
  function an() {
    var a = wb();
    return (
      qb(a, "AppleTV") ||
      qb(a, "Apple TV") ||
      qb(a, "CFNetwork") ||
      qb(a, "tvOS")
    );
  }
  function bn() {
    var a;
    (a =
      qb(wb(), "CrKey") ||
      qb(wb(), "PlayStation") ||
      qb(wb(), "Roku") ||
      $m() ||
      qb(wb(), "Xbox") ||
      an()) ||
      ((a = wb()), (a = qb(a, "sdk_google_atv_x86") || qb(a, "Android TV")));
    return a;
  }
  var dn = function () {
      this.l = !mi(P.top);
      this.C = fi() || gi();
      var a = zl();
      a =
        0 < a.length && null != a[a.length - 1] && null != a[a.length - 1].url
          ? ((a = a[a.length - 1].url.match(hi)[3] || null)
              ? decodeURI(a)
              : a) || ""
          : "";
      this.domain = a;
      this.g = new H(0, 0, 0, 0);
      this.o = new Bh(0, 0);
      this.A = new Bh(0, 0);
      this.I = new H(0, 0, 0, 0);
      this.frameOffset = new Ah(0, 0);
      this.B = 0;
      this.N = !1;
      this.j = !(!P || !Dm(P).Da);
      cn(this);
    },
    en = function (a, b) {
      b && b.screen && (a.o = new Bh(b.screen.width, b.screen.height));
    },
    fn = function (a, b) {
      var c = a.g ? new Bh(a.g.getWidth(), a.g.getHeight()) : new Bh(0, 0);
      b = void 0 === b ? P : b;
      null !== b && b != b.top && (b = b.top);
      var d = 0,
        e = 0;
      try {
        var f = b.document,
          g = f.body,
          h = f.documentElement;
        if ("CSS1Compat" == f.compatMode && h.scrollHeight)
          (d = h.scrollHeight != c.height ? h.scrollHeight : h.offsetHeight),
            (e = h.scrollWidth != c.width ? h.scrollWidth : h.offsetWidth);
        else {
          var k = h.scrollHeight,
            n = h.scrollWidth,
            m = h.offsetHeight,
            r = h.offsetWidth;
          h.clientHeight != m &&
            ((k = g.scrollHeight),
            (n = g.scrollWidth),
            (m = g.offsetHeight),
            (r = g.offsetWidth));
          k > c.height
            ? k > m
              ? ((d = k), (e = n))
              : ((d = m), (e = r))
            : k < m
            ? ((d = k), (e = n))
            : ((d = m), (e = r));
        }
        var p = new Bh(e, d);
      } catch (t) {
        p = new Bh(-12245933, -12245933);
      }
      a.A = p;
    },
    cn = function (a) {
      P &&
        P.document &&
        ((a.I = Fm(!1, P, a.C)), (a.g = Fm(!0, P, a.C)), fn(a, P), en(a, P));
    },
    hn = function () {
      var a = gn();
      if (0 < a.B || a.N) return !0;
      a = Ql().j.isVisible();
      var b = 0 === Vi(rl);
      return a || b;
    },
    gn = function () {
      return I(dn);
    };
  var jn = function (a) {
    this.l = a;
    this.j = 0;
    this.g = null;
  };
  jn.prototype.cancel = function () {
    Ql().clearTimeout(this.g);
    this.g = null;
  };
  var kn = function (a) {
    var b = Ql(),
      c = O().g.g;
    a.g = b.setTimeout(
      Wl(
        c,
        mm(143, function () {
          a.j++;
          a.l.sample();
        })
      ),
      vm()
    );
  };
  var ln = function (a, b, c) {
    this.l = a;
    this.ka = void 0 === c ? "na" : c;
    this.o = [];
    this.va = !1;
    this.A = new wm(-1, !0, this);
    this.g = this;
    this.N = b;
    this.H = this.F = !1;
    this.Y = "uk";
    this.P = !1;
    this.C = !0;
  };
  ln.prototype.G = function () {
    return !1;
  };
  ln.prototype.initialize = function () {
    return (this.va = !0);
  };
  ln.prototype.Cb = function () {
    return this.g.Y;
  };
  ln.prototype.Tb = function () {
    return this.g.H;
  };
  var nn = function (a, b, c) {
    if (!a.H || (void 0 === c ? 0 : c))
      (a.H = !0), (a.Y = b), (a.N = 0), a.g != a || mn(a);
  };
  ln.prototype.getName = function () {
    return this.g.ka;
  };
  ln.prototype.fb = function () {
    return this.g.Z();
  };
  ln.prototype.Z = function () {
    return {};
  };
  ln.prototype.Qa = function () {
    return this.g.N;
  };
  var on = function (a, b) {
    Xb(a.o, b) || (a.o.push(b), b.Eb(a.g), b.gb(a.A), b.Ma() && (a.F = !0));
  };
  ln.prototype.U = function () {
    var a = gn();
    a.g = Fm(!0, this.l, a.C);
  };
  ln.prototype.W = function () {
    en(gn(), this.l);
  };
  ln.prototype.ba = function () {
    return this.A.g;
  };
  var pn = function (a) {
    a = a.g;
    a.W();
    a.U();
    var b = gn();
    b.I = Fm(!1, a.l, b.C);
    fn(gn(), a.l);
    a.A.g = a.ba();
  };
  ln.prototype.sample = function () {};
  ln.prototype.isActive = function () {
    return this.g.C;
  };
  var qn = function (a) {
      a.F = a.o.length
        ? Sb(a.o, function (b) {
            return b.Ma();
          })
        : !1;
    },
    rn = function (a) {
      var b = bc(a.o);
      Nb(b, function (c) {
        c.gb(a.A);
      });
    },
    mn = function (a) {
      var b = bc(a.o);
      Nb(b, function (c) {
        c.Eb(a.g);
      });
      a.g != a || rn(a);
    };
  l = ln.prototype;
  l.Eb = function (a) {
    var b = this.g;
    this.g = a.Qa() >= this.N ? a : this;
    b !== this.g
      ? ((this.C = this.g.C), mn(this))
      : this.C !== this.g.C && ((this.C = this.g.C), mn(this));
  };
  l.gb = function (a) {
    if (a.j === this.g) {
      var b = this.A,
        c = this.F;
      if ((c = a && (void 0 === c || !c || b.volume == a.volume) && b.l == a.l))
        (b = b.g),
          (c = a.g),
          (c =
            b == c
              ? !0
              : b && c
              ? b.top == c.top &&
                b.right == c.right &&
                b.bottom == c.bottom &&
                b.left == c.left
              : !1);
      this.A = a;
      !c && rn(this);
    }
  };
  l.Ma = function () {
    return this.F;
  };
  l.X = function () {
    this.P = !0;
  };
  l.Ca = function () {
    return this.P;
  };
  var sn = function (a, b, c, d) {
    this.l = a;
    this.g = new H(0, 0, 0, 0);
    this.o = new H(0, 0, 0, 0);
    this.j = b;
    this.R = c;
    this.H = d;
    this.G = !1;
    this.timestamp = -1;
    this.I = new xm(b.A, this.g, new H(0, 0, 0, 0), 0, 0, um(), 0);
  };
  l = sn.prototype;
  l.dd = function () {
    return !0;
  };
  l.dc = function () {};
  l.X = function () {
    if (!this.Ca()) {
      var a = this.j;
      Yb(a.o, this);
      a.F && this.Ma() && qn(a);
      this.dc();
      this.G = !0;
    }
  };
  l.Ca = function () {
    return this.G;
  };
  l.fb = function () {
    return this.j.fb();
  };
  l.Qa = function () {
    return this.j.Qa();
  };
  l.Cb = function () {
    return this.j.Cb();
  };
  l.Tb = function () {
    return this.j.Tb();
  };
  l.Eb = function () {};
  l.gb = function () {
    this.ab();
  };
  l.Ma = function () {
    return this.H;
  };
  var tn = function (a) {
    this.o = !1;
    this.g = a;
    this.A = function () {};
  };
  l = tn.prototype;
  l.Qa = function () {
    return this.g.Qa();
  };
  l.Cb = function () {
    return this.g.Cb();
  };
  l.Tb = function () {
    return this.g.Tb();
  };
  l.create = function (a, b, c) {
    var d = null;
    this.g && ((d = this.ec(a, b, c)), on(this.g, d));
    return d;
  };
  l.ae = function () {
    return this.Kb();
  };
  l.Kb = function () {
    return !1;
  };
  l.init = function (a) {
    return this.g.initialize() ? (on(this.g, this), (this.A = a), !0) : !1;
  };
  l.Eb = function (a) {
    0 == a.Qa() && this.A(a.Cb(), this);
  };
  l.gb = function () {};
  l.Ma = function () {
    return !1;
  };
  l.X = function () {
    this.o = !0;
  };
  l.Ca = function () {
    return this.o;
  };
  l.fb = function () {
    return {};
  };
  var un = function (a, b, c) {
      this.l = void 0 === c ? 0 : c;
      this.j = a;
      this.g = null == b ? "" : b;
    },
    vn = function (a) {
      switch (Math.trunc(a.l)) {
        case -16:
          return -16;
        case -8:
          return -8;
        case 0:
          return 0;
        case 8:
          return 8;
        case 16:
          return 16;
        default:
          return 16;
      }
    },
    wn = function (a, b) {
      return a.l < b.l
        ? !0
        : a.l > b.l
        ? !1
        : a.j < b.j
        ? !0
        : a.j > b.j
        ? !1
        : typeof a.g < typeof b.g
        ? !0
        : typeof a.g > typeof b.g
        ? !1
        : a.g < b.g;
    };
  var xn = function () {
    this.l = 0;
    this.g = [];
    this.j = !1;
  };
  xn.prototype.add = function (a, b, c) {
    ++this.l;
    a = new un(a, b, c);
    this.g.push(new un(a.j, a.g, a.l + this.l / 4096));
    this.j = !0;
    return this;
  };
  var yn = function (a, b) {
      Nb(b.g, function (c) {
        a.add(c.j, c.g, vn(c));
      });
    },
    zn = function (a, b) {
      var c = void 0 === c ? 0 : c;
      var d = void 0 === d ? !0 : d;
      si(b, function (e, f) {
        (d && void 0 === e) || a.add(f, e, c);
      });
      return a;
    },
    Bn = function (a) {
      var b = An;
      a.j &&
        (dc(a.g, function (c, d) {
          return wn(d, c) ? 1 : wn(c, d) ? -1 : 0;
        }),
        (a.j = !1));
      return Rb(
        a.g,
        function (c, d) {
          d = b(d);
          return "" + c + ("" != c && "" != d ? "&" : "") + d;
        },
        ""
      );
    };
  var An = function (a) {
    var b = a.j;
    a = a.g;
    return "" === a
      ? b
      : "boolean" === typeof a
      ? a
        ? b
        : ""
      : Array.isArray(a)
      ? 0 === a.length
        ? b
        : b + "=" + a.join()
      : b + "=" + (Xb(["mtos", "tos", "p"], b) ? a : encodeURIComponent(a));
  };
  var Cn = function (a) {
    var b = void 0 === b ? !0 : b;
    this.g = new xn();
    void 0 !== a && yn(this.g, a);
    b && this.g.add("v", "unreleased", -16);
  };
  Cn.prototype.toString = function () {
    var a = "//pagead2.googlesyndication.com//pagead/gen_204",
      b = Bn(this.g);
    0 < b.length && (a += "?" + b);
    return a;
  };
  var Dn = function (a) {
      var b = [],
        c = [];
      Pg(a, function (d, e) {
        if (!(e in Object.prototype) && "undefined" != typeof d)
          switch (
            (Array.isArray(d) && (d = d.join(",")),
            (d = [e, "=", d].join("")),
            e)
          ) {
            case "adk":
            case "r":
            case "tt":
            case "error":
            case "mtos":
            case "tos":
            case "p":
            case "bs":
              b.unshift(d);
              break;
            case "req":
            case "url":
            case "referrer":
            case "iframe_loc":
              c.push(d);
              break;
            default:
              b.push(d);
          }
      });
      return b.concat(c);
    },
    En = function (a) {
      a = a.toString();
      Ql();
      Oi(P, a);
    };
  var Fn = function () {
    this.g = 0;
  };
  function Gn(a) {
    a && "function" == typeof a.X && a.X();
  }
  var Q = function () {
    this.N = this.N;
    this.I = this.I;
  };
  Q.prototype.N = !1;
  Q.prototype.Ca = function () {
    return this.N;
  };
  Q.prototype.X = function () {
    this.N || ((this.N = !0), this.M());
  };
  var In = function (a, b) {
      Hn(a, $a(Gn, b));
    },
    Hn = function (a, b) {
      a.N ? b() : (a.I || (a.I = []), a.I.push(b));
    };
  Q.prototype.M = function () {
    if (this.I) for (; this.I.length; ) this.I.shift()();
  };
  var Jn = function (a, b, c) {
    Nb(a.l, function (d) {
      var e = a.g;
      if (!d.g && (d.l(b, c), d.A())) {
        d.g = !0;
        var f = d.j(),
          g = new xn();
        g.add("id", "av-js");
        g.add("type", "verif");
        g.add("vtype", d.o);
        d = I(Fn);
        g.add("i", d.g++);
        g.add("adk", e);
        zn(g, f);
        e = new Cn(g);
        En(e);
      }
    });
  };
  var Kn = function () {
      this.j = this.l = this.A = this.g = 0;
    },
    Ln = function (a, b, c, d) {
      b && ((a.g += c), (a.j += c), (a.A += c), (a.l = Math.max(a.l, a.A)));
      if (void 0 === d ? !b : d) a.A = 0;
    };
  var Mn = [1, 0.75, 0.5, 0.3, 0],
    Nn = function (a) {
      this.j = a = void 0 === a ? Mn : a;
      this.g = Qb(this.j, function () {
        return new Kn();
      });
    },
    Pn = function (a, b) {
      return On(
        a,
        function (c) {
          return c.g;
        },
        void 0 === b ? !0 : b
      );
    },
    Rn = function (a, b) {
      return Qn(a, b, function (c) {
        return c.g;
      });
    },
    Sn = function (a, b) {
      return On(
        a,
        function (c) {
          return c.l;
        },
        void 0 === b ? !0 : b
      );
    },
    Tn = function (a, b) {
      return Qn(a, b, function (c) {
        return c.l;
      });
    },
    Un = function (a, b) {
      return Qn(a, b, function (c) {
        return c.j;
      });
    },
    Vn = function (a) {
      Nb(a.g, function (b) {
        b.j = 0;
      });
    },
    Wn = function (a, b, c, d, e, f, g) {
      g = void 0 === g ? !0 : g;
      c = f ? Math.min(b, c) : c;
      for (f = 0; f < a.j.length; f++) {
        var h = a.j[f],
          k = 0 < c && c >= h;
        h = !(0 < b && b >= h) || d;
        Ln(a.g[f], g && k, e, !g || h);
      }
    },
    On = function (a, b, c) {
      a = Qb(a.g, function (d) {
        return b(d);
      });
      return c ? a : Xn(a);
    },
    Qn = function (a, b, c) {
      var d = Vb(a.j, function (e) {
        return b <= e;
      });
      return -1 == d ? 0 : c(a.g[d]);
    },
    Xn = function (a) {
      return Qb(a, function (b, c, d) {
        return 0 < c ? d[c] - d[c - 1] : d[c];
      });
    };
  var Yn = function () {
      this.j = new Nn();
      this.Y = new Kn();
      this.H = this.C = -1;
      this.fa = 1e3;
      this.ga = new Nn([1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0]);
      this.P = this.J = -1;
    },
    Zn = function (a, b) {
      return Sn(a.j, void 0 === b ? !0 : b);
    };
  Yn.prototype.N = function (a, b, c, d) {
    this.C = -1 != this.C ? Math.min(this.C, b.aa) : b.aa;
    this.H = Math.max(this.H, b.aa);
    this.J = -1 != this.J ? Math.min(this.J, b.ta) : b.ta;
    this.P = Math.max(this.P, b.ta);
    Wn(this.ga, b.ta, c.ta, b.g, a, d);
    Wn(this.j, b.aa, c.aa, b.g, a, d);
    c = d || c.ub != b.ub ? c.isVisible() && b.isVisible() : c.isVisible();
    b = !b.isVisible() || b.g;
    Ln(this.Y, c, a, b);
  };
  Yn.prototype.Ta = function () {
    return this.Y.l >= this.fa;
  };
  if (rl && rl.URL) {
    var $n = rl.URL,
      ao;
    if ((ao = !!$n)) {
      var bo;
      a: {
        if ($n) {
          var co = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
          try {
            var eo = co.exec(decodeURIComponent($n));
            if (eo) {
              bo = eo[1] && 1 < eo[1].length ? eo[1].substring(1) : "true";
              break a;
            }
          } catch (a) {}
        }
        bo = "";
      }
      ao = 0 < bo.length;
    }
    im.Pd(!ao);
  }
  var fo = function (a, b, c, d) {
    var e = void 0 === e ? !1 : e;
    c = mm(d, c);
    Ng(a, b, c, { capture: e });
  };
  var go = new H(0, 0, 0, 0);
  function ho(a, b) {
    b = io(b);
    return 0 === b ? 0 : io(a) / b;
  }
  function io(a) {
    return Math.max(a.bottom - a.top, 0) * Math.max(a.right - a.left, 0);
  }
  function jo(a, b) {
    if (!a || !b) return !1;
    for (var c = 0; null !== a && 100 > c++; ) {
      if (a === b) return !0;
      try {
        if ((a = bi(a) || a)) {
          var d = Rh(a),
            e = d && G(d),
            f = e && e.frameElement;
          f && (a = f);
        }
      } catch (g) {
        break;
      }
    }
    return !1;
  }
  function ko(a, b, c) {
    if (!a || !b) return !1;
    b = Bi(Ai(a), -b.left, -b.top);
    a = (b.left + b.right) / 2;
    b = (b.top + b.bottom) / 2;
    mi(window.top) &&
      window.top &&
      window.top.document &&
      (window = window.top);
    if (!Em()) return !1;
    a = window.document.elementFromPoint(a, b);
    if (!a) return !1;
    b =
      (b = (b = Rh(c)) && b.defaultView && b.defaultView.frameElement) &&
      jo(b, a);
    var d = a === c;
    a =
      !d &&
      a &&
      ei(a, function (e) {
        return e === c;
      });
    return !(b || d || a);
  }
  function lo(a, b, c, d) {
    return gn().l
      ? !1
      : 0 >= a.getWidth() || 0 >= a.getHeight()
      ? !0
      : c && d
      ? lm(208, function () {
          return ko(a, b, c);
        })
      : !1;
  }
  var mo = new H(0, 0, 0, 0),
    oo = function (a, b, c) {
      Q.call(this);
      this.position = Ai(mo);
      this.Mc = this.Ac();
      this.ud = -2;
      this.Hg = Date.now();
      this.Oe = -1;
      this.Dc = b;
      this.Cc = null;
      this.Pb = !1;
      this.Rc = null;
      this.opacity = -1;
      this.wg = c;
      this.Ig = !1;
      this.xd = function () {};
      this.Qe = function () {};
      this.ua = new tl();
      this.ua.kb = a;
      this.ua.g = a;
      this.Ra = !1;
      this.qb = { Bd: null, zd: null };
      this.Ke = !0;
      this.bc = null;
      this.Fb = this.fg = !1;
      O().B++;
      this.ra = this.nd();
      this.Ne = -1;
      this.ca = null;
      this.ue = this.dg = !1;
      this.R = new il();
      ql(this.R);
      no(this);
      1 == this.wg ? ll(this.R, "od", 1) : ll(this.R, "od", 0);
    };
  v(oo, Q);
  oo.prototype.M = function () {
    this.ua.g &&
      (this.qb.Bd &&
        (Og(this.ua.g, "mouseover", this.qb.Bd), (this.qb.Bd = null)),
      this.qb.zd &&
        (Og(this.ua.g, "mouseout", this.qb.zd), (this.qb.zd = null)));
    this.bc && this.bc.X();
    this.ca && this.ca.X();
    delete this.Mc;
    delete this.xd;
    delete this.Qe;
    delete this.ua.kb;
    delete this.ua.g;
    delete this.qb;
    delete this.bc;
    delete this.ca;
    delete this.R;
    Q.prototype.M.call(this);
  };
  oo.prototype.sb = function () {
    return this.ca ? this.ca.g : this.position;
  };
  oo.prototype.Gd = function (a) {
    O().Gd(a);
  };
  var no = function (a) {
    a = a.ua.kb;
    var b;
    if ((b = a && a.getAttribute))
      b = /-[a-z]/.test("googleAvInapp")
        ? !1
        : sl && a.dataset
        ? "googleAvInapp" in a.dataset
        : a.hasAttribute
        ? a.hasAttribute("data-" + Nh())
        : !!a.getAttribute("data-" + Nh());
    b && (gn().j = !0);
  };
  oo.prototype.Ma = function () {
    return !1;
  };
  oo.prototype.Ac = function () {
    return new Yn();
  };
  oo.prototype.qa = function () {
    return this.Mc;
  };
  var po = function (a, b) {
      b != a.Fb && ((a.Fb = b), (a = gn()), b ? a.B++ : 0 < a.B && a.B--);
    },
    qo = function (a, b) {
      if (a.ca) {
        if (b.getName() === a.ca.getName()) return;
        a.ca.X();
        a.ca = null;
      }
      b = b.create(a.ua.g, a.R, a.Ma());
      if ((b = null != b && b.dd() ? b : null)) a.ca = b;
    },
    ro = function (a, b, c) {
      if (
        !a.Cc ||
        -1 == a.Dc ||
        -1 === b.getTimestamp() ||
        -1 === a.Cc.getTimestamp()
      )
        return 0;
      a = b.getTimestamp() - a.Cc.getTimestamp();
      return a > c ? 0 : a;
    };
  oo.prototype.re = function (a) {
    return ro(this, a, 1e4);
  };
  var so = function (a, b, c) {
      if (a.ca) {
        a.ca.ab();
        var d = a.ca.I,
          e = d.l,
          f = e.g;
        if (null != d.o) {
          var g = d.j;
          a.Rc = new Ah(g.left - f.left, g.top - f.top);
        }
        f = a.Yc() ? Math.max(d.g, d.A) : d.g;
        g = {};
        null !== e.volume && (g.volume = e.volume);
        e = a.re(d);
        a.Cc = d;
        a.Td(f, b, c, !1, g, e, d.B);
      }
    },
    to = function (a) {
      if (a.Pb && a.bc) {
        var b = 1 == ml(a.R, "od"),
          c = gn().g,
          d = a.bc,
          e = a.ca ? a.ca.getName() : "ns",
          f = a.Rc,
          g = new Bh(c.getWidth(), c.getHeight());
        c = a.Yc();
        a = { Eg: e, Rc: f, Sg: g, Yc: c, aa: a.ra.aa, Ng: b };
        if ((b = d.j)) {
          b.ab();
          e = b.I;
          f = e.l.g;
          var h = (g = null);
          null != e.o &&
            f &&
            ((g = e.j),
            (g = new Ah(g.left - f.left, g.top - f.top)),
            (h = new Bh(f.right - f.left, f.bottom - f.top)));
          e = c ? Math.max(e.g, e.A) : e.g;
          c = { Eg: b.getName(), Rc: g, Sg: h, Yc: c, Ng: !1, aa: e };
        } else c = null;
        c && Jn(d, a, c);
      }
    };
  l = oo.prototype;
  l.Td = function (a, b, c, d, e, f, g) {
    this.Ra ||
      (this.Pb &&
        ((a = this.ed(a, c, e, g)),
        (d = d && this.ra.aa >= (this.ub() ? 0.3 : 0.5)),
        this.Ud(f, a, d),
        (this.Dc = b),
        0 < a.aa && -1 === this.Ne && (this.Ne = b),
        -1 == this.Oe && this.Ta() && (this.Oe = b),
        -2 == this.ud && (this.ud = io(this.sb()) ? a.aa : -1),
        (this.ra = a)),
      this.xd(this));
  };
  l.Ud = function (a, b, c) {
    this.qa().N(a, b, this.ra, c);
  };
  l.nd = function () {
    return new Xk();
  };
  l.ed = function (a, b, c, d) {
    c = this.nd();
    c.g = b;
    b = Ql().j;
    b = 0 === Vi(rl) ? -1 : b.isVisible() ? 0 : 1;
    c.j = b;
    c.aa = this.jd(a);
    c.ub = this.ub();
    c.ta = d;
    return c;
  };
  l.jd = function (a) {
    return 0 === this.opacity && 1 === ml(this.R, "opac") ? 0 : a;
  };
  l.ub = function () {
    return !1;
  };
  l.Yc = function () {
    return this.dg || this.fg;
  };
  l.ya = function () {
    return 0;
  };
  l.Ta = function () {
    return this.Mc.Ta();
  };
  l.te = function () {
    var a = this.Pb;
    a = (this.ue || this.Ca()) && !a;
    var b = 2 !== O().j || this.Ig;
    return this.Ra || (b && a) ? 2 : this.Ta() ? 4 : 3;
  };
  l.yc = function () {
    return 0;
  };
  var uo = function (a, b, c) {
    b && (a.xd = b);
    c && (a.Qe = c);
  };
  var vo = function () {};
  vo.prototype.next = function () {
    return wo;
  };
  var wo = { done: !0, value: void 0 };
  vo.prototype.zb = function () {
    return this;
  };
  var xo = function () {
      this.A = this.g = this.l = this.j = this.o = 0;
    },
    yo = function (a) {
      var b = {};
      b = ((b.ptlt = Date.now() - a.o), b);
      var c = a.j;
      c && (b.pnk = c);
      (c = a.l) && (b.pnc = c);
      (c = a.A) && (b.pnmm = c);
      (a = a.g) && (b.pns = a);
      return b;
    };
  var zo = function () {
    Xk.call(this);
    this.fullscreen = !1;
    this.volume = void 0;
    this.l = !1;
    this.mediaTime = -1;
  };
  v(zo, Xk);
  var Ao = function (a) {
    return Zm(a.volume) && 0 < a.volume;
  };
  var Co = function (a, b, c, d) {
      c = void 0 === c ? !0 : c;
      d =
        void 0 === d
          ? function () {
              return !0;
            }
          : d;
      return function (e) {
        var f = e[a];
        if (Array.isArray(f) && d(e)) return Bo(f, b, c);
      };
    },
    Do = function (a, b) {
      return function (c) {
        return b(c) ? c[a] : void 0;
      };
    },
    Eo = function (a) {
      return function (b) {
        for (var c = 0; c < a.length; c++)
          if (a[c] === b.e || (void 0 === a[c] && !b.hasOwnProperty("e")))
            return !0;
        return !1;
      };
    },
    Bo = function (a, b, c) {
      return void 0 === c || c
        ? Pb(a, function (d, e) {
            return Xb(b, e);
          })
        : Qb(b, function (d, e, f) {
            return a
              .slice(0 < e ? f[e - 1] + 1 : 0, d + 1)
              .reduce(function (g, h) {
                return g + h;
              }, 0);
          });
    };
  var Fo = Eo([void 0, 1, 2, 3, 4, 8, 16]),
    Go = Eo([void 0, 4, 8, 16]),
    Ho = {
      sv: "sv",
      v: "v",
      cb: "cb",
      e: "e",
      nas: "nas",
      msg: "msg",
      if: "if",
      sdk: "sdk",
      p: "p",
      p0: Do("p0", Go),
      p1: Do("p1", Go),
      p2: Do("p2", Go),
      p3: Do("p3", Go),
      cp: "cp",
      tos: "tos",
      mtos: "mtos",
      amtos: "amtos",
      mtos1: Co("mtos1", [0, 2, 4], !1, Go),
      mtos2: Co("mtos2", [0, 2, 4], !1, Go),
      mtos3: Co("mtos3", [0, 2, 4], !1, Go),
      mcvt: "mcvt",
      ps: "ps",
      scs: "scs",
      bs: "bs",
      vht: "vht",
      mut: "mut",
      a: "a",
      a0: Do("a0", Go),
      a1: Do("a1", Go),
      a2: Do("a2", Go),
      a3: Do("a3", Go),
      ft: "ft",
      dft: "dft",
      at: "at",
      dat: "dat",
      as: "as",
      vpt: "vpt",
      gmm: "gmm",
      std: "std",
      efpf: "efpf",
      swf: "swf",
      nio: "nio",
      px: "px",
      nnut: "nnut",
      vmer: "vmer",
      vmmk: "vmmk",
      vmiec: "vmiec",
      nmt: "nmt",
      tcm: "tcm",
      bt: "bt",
      pst: "pst",
      vpaid: "vpaid",
      dur: "dur",
      vmtime: "vmtime",
      dtos: "dtos",
      dtoss: "dtoss",
      dvs: "dvs",
      dfvs: "dfvs",
      dvpt: "dvpt",
      fmf: "fmf",
      vds: "vds",
      is: "is",
      i0: "i0",
      i1: "i1",
      i2: "i2",
      i3: "i3",
      ic: "ic",
      cs: "cs",
      c: "c",
      c0: Do("c0", Go),
      c1: Do("c1", Go),
      c2: Do("c2", Go),
      c3: Do("c3", Go),
      mc: "mc",
      nc: "nc",
      mv: "mv",
      nv: "nv",
      qmt: Do("qmtos", Fo),
      qnc: Do("qnc", Fo),
      qmv: Do("qmv", Fo),
      qnv: Do("qnv", Fo),
      raf: "raf",
      rafc: "rafc",
      lte: "lte",
      ces: "ces",
      tth: "tth",
      femt: "femt",
      femvt: "femvt",
      emc: "emc",
      emuc: "emuc",
      emb: "emb",
      avms: "avms",
      nvat: "nvat",
      qi: "qi",
      psm: "psm",
      psv: "psv",
      psfv: "psfv",
      psa: "psa",
      pnk: "pnk",
      pnc: "pnc",
      pnmm: "pnmm",
      pns: "pns",
      ptlt: "ptlt",
      pngs: "pings",
      veid: "veid",
      ssb: "ssb",
      ss0: Do("ss0", Go),
      ss1: Do("ss1", Go),
      ss2: Do("ss2", Go),
      ss3: Do("ss3", Go),
      dc_rfl: "urlsigs",
      obd: "obd",
      omidp: "omidp",
      omidr: "omidr",
      omidv: "omidv",
      omida: "omida",
      omids: "omids",
      omidpv: "omidpv",
      omidam: "omidam",
      omidct: "omidct",
      omidia: "omidia",
      omiddc: "omiddc",
      omidlat: "omidlat",
      omiddit: "omiddit",
      nopd: "nopd",
      co: "co",
    },
    Io = Object.assign({}, Ho, {
      avid: (function (a) {
        return function () {
          return a;
        };
      })("audio"),
      avas: "avas",
      vs: "vs",
    }),
    Jo = {
      atos: "atos",
      avt: Co("atos", [2]),
      davs: "davs",
      dafvs: "dafvs",
      dav: "dav",
      ss: (function (a, b) {
        return function (c) {
          return void 0 === c[a] && void 0 !== b ? b : c[a];
        };
      })("ss", 0),
      t: "t",
    };
  var Ko = function () {
    this.j = this.g = "";
  };
  var Lo = function () {},
    Mo = function (a, b) {
      var c = {};
      if (void 0 !== a)
        if (null != b)
          for (var d in b) {
            var e = b[d];
            d in Object.prototype ||
              (null != e && (c[d] = "function" === typeof e ? e(a) : a[e]));
          }
        else dh(c, a);
      return Bn(zn(new xn(), c));
    };
  var No = function () {
    var a = {};
    this.j =
      ((a.vs = [1, 0]),
      (a.vw = [0, 1]),
      (a.am = [2, 2]),
      (a.a = [4, 4]),
      (a.f = [8, 8]),
      (a.bm = [16, 16]),
      (a.b = [32, 32]),
      (a.avw = [0, 64]),
      (a.avs = [64, 0]),
      (a.pv = [256, 256]),
      (a.gdr = [0, 512]),
      (a.p = [0, 1024]),
      (a.r = [0, 2048]),
      (a.m = [0, 4096]),
      (a.um = [0, 8192]),
      (a.ef = [0, 16384]),
      (a.s = [0, 32768]),
      (a.pmx = [0, 16777216]),
      (a.mut = [33554432, 33554432]),
      (a.umutb = [67108864, 67108864]),
      (a.tvoff = [134217728, 134217728]),
      a);
    this.g = {};
    for (var b in this.j) 0 < this.j[b][1] && (this.g[b] = 0);
    this.l = 0;
  };
  No.prototype.reportEvent = function (a) {
    var b = this.j[a],
      c = b[1];
    this.l += b[0];
    0 < c && 0 == this.g[a] && (this.g[a] = 1);
  };
  var Oo = function (a) {
      var b = Ug(a.j),
        c = 0,
        d;
      for (d in a.g)
        Xb(b, d) && 1 == a.g[d] && ((c += a.j[d][1]), (a.g[d] = 2));
      return c;
    },
    Po = function (a) {
      var b = 0,
        c;
      for (c in a.g) {
        var d = a.g[c];
        if (1 == d || 2 == d) b += a.j[c][1];
      }
      return b;
    };
  var Qo = function () {
    this.g = this.j = 0;
  };
  Qo.prototype.getValue = function () {
    return this.j;
  };
  var Ro = function (a, b, c) {
    32 <= b ||
      (a.g & (1 << b) && !c
        ? (a.j &= ~(1 << b))
        : a.g & (1 << b) || !c || (a.j |= 1 << b),
      (a.g |= 1 << b));
  };
  var So = function () {
    Yn.call(this);
    this.l = new Kn();
    this.W = this.F = this.L = 0;
    this.I = -1;
    this.ka = new Kn();
    this.o = new Kn();
    this.g = new Nn();
    this.B = this.A = -1;
    this.G = new Kn();
    this.fa = 2e3;
    this.U = new Qo();
    this.ba = new Qo();
    this.Z = new Qo();
  };
  v(So, Yn);
  var To = function (a, b, c) {
    var d = a.W;
    tm || c || -1 == a.I || (d += b - a.I);
    return d;
  };
  So.prototype.N = function (a, b, c, d) {
    if (!b.l) {
      Yn.prototype.N.call(this, a, b, c, d);
      var e = Ao(b) && Ao(c),
        f = 0.5 <= (d ? Math.min(b.aa, c.aa) : c.aa);
      Zm(b.volume) &&
        ((this.A = -1 != this.A ? Math.min(this.A, b.volume) : b.volume),
        (this.B = Math.max(this.B, b.volume)));
      f && ((this.L += a), (this.F += e ? a : 0));
      Wn(this.g, b.aa, c.aa, b.g, a, d, e);
      Ln(this.l, !0, a);
      Ln(this.o, e, a);
      Ln(this.G, c.fullscreen, a);
      Ln(this.ka, e && !f, a);
      a = Math.floor(b.mediaTime / 1e3);
      Ro(this.U, a, b.isVisible());
      Ro(this.ba, a, 1 <= b.aa);
      Ro(this.Z, a, Ao(b));
    }
  };
  var Uo = function () {
    this.l = !1;
  };
  Uo.prototype.j = function (a) {
    this.l ||
      (this.g(a)
        ? ((a = this.N.report(this.A, a)), (this.o |= a), (a = 0 == a))
        : (a = !1),
      (this.l = a));
  };
  var Vo = function (a, b) {
    this.l = !1;
    this.A = a;
    this.N = b;
    this.o = 0;
  };
  v(Vo, Uo);
  Vo.prototype.g = function () {
    return !0;
  };
  Vo.prototype.B = function () {
    return !1;
  };
  Vo.prototype.getId = function () {
    var a = this,
      b = Yg(function (c) {
        return c == a.A;
      });
    return Cm[b].toString();
  };
  Vo.prototype.toString = function () {
    var a = "";
    this.B() && (a += "c");
    this.l && (a += "s");
    0 < this.o && (a += ":" + this.o);
    return this.getId() + a;
  };
  var Wo = function (a, b) {
    Vo.call(this, a, b);
    this.C = [];
  };
  v(Wo, Vo);
  Wo.prototype.j = function (a, b) {
    b = void 0 === b ? null : b;
    null != b && this.C.push(b);
    Vo.prototype.j.call(this, a);
  };
  var Xo = function () {};
  var Yo = function () {};
  v(Yo, Xo);
  Yo.prototype.j = function () {
    return null;
  };
  Yo.prototype.l = function () {
    return [];
  };
  var Zo = function (a, b, c, d) {
    sn.call(this, a, b, c, d);
  };
  v(Zo, sn);
  l = Zo.prototype;
  l.gd = function () {
    if (this.l) {
      var a = this.l,
        b = this.j.g.l;
      try {
        try {
          var c = Xm(a.getBoundingClientRect());
        } catch (n) {
          c = new H(0, 0, 0, 0);
        }
        var d = c.right - c.left,
          e = c.bottom - c.top,
          f = Nm(a, b),
          g = f.x,
          h = f.y;
        var k = new H(
          Math.round(h),
          Math.round(g + d),
          Math.round(h + e),
          Math.round(g)
        );
      } catch (n) {
        k = Ai(go);
      }
      this.g = k;
    }
  };
  l.ie = function () {
    this.o = this.j.A.g;
  };
  l.we = function (a) {
    var b = 1 == ml(this.R, "od");
    return lo(a, this.o, this.l, b);
  };
  l.je = function () {
    this.timestamp = um();
  };
  l.ab = function () {
    this.je();
    this.gd();
    if (
      this.l &&
      "number" === typeof this.l.videoWidth &&
      "number" === typeof this.l.videoHeight
    ) {
      var a = this.l;
      var b = new Bh(a.videoWidth, a.videoHeight);
      a = this.g;
      var c = a.getWidth(),
        d = a.getHeight(),
        e = b.width;
      b = b.height;
      0 >= e ||
        0 >= b ||
        0 >= c ||
        0 >= d ||
        ((e /= b),
        (a = Ai(a)),
        e > c / d
          ? ((c /= e),
            (d = (d - c) / 2),
            0 < d &&
              ((d = a.top + d),
              (a.top = Math.round(d)),
              (a.bottom = Math.round(d + c))))
          : ((d *= e),
            (c = Math.round((c - d) / 2)),
            0 < c &&
              ((c = a.left + c),
              (a.left = Math.round(c)),
              (a.right = Math.round(c + d)))));
      this.g = a;
    }
    this.ie();
    a = this.g;
    c = this.o;
    a =
      a.left <= c.right &&
      c.left <= a.right &&
      a.top <= c.bottom &&
      c.top <= a.bottom
        ? new H(
            Math.max(a.top, c.top),
            Math.min(a.right, c.right),
            Math.min(a.bottom, c.bottom),
            Math.max(a.left, c.left)
          )
        : new H(0, 0, 0, 0);
    c = a.top >= a.bottom || a.left >= a.right ? new H(0, 0, 0, 0) : a;
    a = this.j.A;
    b = e = d = 0;
    0 < (this.g.bottom - this.g.top) * (this.g.right - this.g.left) &&
      (this.we(c)
        ? (c = new H(0, 0, 0, 0))
        : ((d = gn().o),
          (b = new H(0, d.height, d.width, 0)),
          (d = ho(c, this.g)),
          (e = ho(c, gn().g)),
          (b = ho(c, b))));
    c =
      c.top >= c.bottom || c.left >= c.right
        ? new H(0, 0, 0, 0)
        : Bi(c, -this.g.left, -this.g.top);
    hn() || (e = d = 0);
    this.I = new xm(a, this.g, c, d, e, this.timestamp, b);
  };
  l.getName = function () {
    return this.j.getName();
  };
  var $o = new H(0, 0, 0, 0),
    ap = function (a, b, c) {
      sn.call(this, null, a, b, c);
      this.C = a.isActive();
      this.B = 0;
    };
  v(ap, Zo);
  l = ap.prototype;
  l.dd = function () {
    this.A();
    return !0;
  };
  l.gb = function () {
    Zo.prototype.ab.call(this);
  };
  l.je = function () {};
  l.gd = function () {};
  l.ab = function () {
    this.A();
    Zo.prototype.ab.call(this);
  };
  l.Eb = function (a) {
    a = a.isActive();
    a !== this.C &&
      (a
        ? this.A()
        : ((gn().g = new H(0, 0, 0, 0)),
          (this.g = new H(0, 0, 0, 0)),
          (this.o = new H(0, 0, 0, 0)),
          (this.timestamp = -1)));
    this.C = a;
  };
  function bp(a) {
    return [a.top, a.left, a.bottom, a.right];
  }
  var cp = {},
    dp =
      ((cp.firstquartile = 0),
      (cp.midpoint = 1),
      (cp.thirdquartile = 2),
      (cp.complete = 3),
      cp),
    ep = function (a, b, c, d, e, f) {
      f = void 0 === f ? new Yo() : f;
      oo.call(this, b, c, d);
      this.Fd = e;
      this.md = 0;
      this.ia = {};
      this.ha = new No();
      this.Se = {};
      this.ma = "";
      this.lb = null;
      this.Pa = !1;
      this.g = [];
      this.Va = f.j();
      this.B = f.l();
      this.o = null;
      this.l = -1;
      this.Z = this.G = void 0;
      this.J = this.H = 0;
      this.U = -1;
      this.ka = this.ga = !1;
      this.P = this.F = this.j = this.Jb = this.Oa = 0;
      new Nn();
      this.W = this.ba = 0;
      this.fa = -1;
      this.la = 0;
      this.C = Hg;
      this.L = [this.Ac()];
      this.Bb = 2;
      this.yb = {};
      this.yb.pause = "p";
      this.yb.resume = "r";
      this.yb.skip = "s";
      this.yb.mute = "m";
      this.yb.unmute = "um";
      this.yb.exitfullscreen = "ef";
      this.A = null;
      this.Ga = this.Ha = !1;
      this.Ab = Math.floor(Date.now() / 1e3 - 1704067200);
      this.Y = 0;
    };
  v(ep, oo);
  ep.prototype.Ma = function () {
    return !0;
  };
  var fp = function (a) {
      a.ue = !0;
      0 != a.la && (a.la = 3);
    },
    gp = function (a) {
      return void 0 === a ? a : Number(a) ? Sm(a, 3) : 0;
    };
  l = ep.prototype;
  l.re = function (a) {
    return ro(this, a, Math.max(1e4, this.l / 3));
  };
  l.Td = function (a, b, c, d, e, f, g) {
    var h = this,
      k = this.C(this) || {};
    dh(k, e);
    this.l = k.duration || this.l;
    this.G = k.isVpaid || this.G;
    this.Z = k.isYouTube || this.Z;
    Ql();
    this.Ga = !1;
    e = hp(this, b);
    1 === ip(this) && (f = e);
    oo.prototype.Td.call(this, a, b, c, d, k, f, g);
    this.Va &&
      this.Va.l &&
      Nb(this.B, function (n) {
        n.j(h);
      });
  };
  l.Ud = function (a, b, c) {
    oo.prototype.Ud.call(this, a, b, c);
    jp(this).N(a, b, this.ra, c);
    this.ka = Ao(this.ra) && Ao(b);
    -1 == this.U && this.ga && (this.U = this.qa().l.g);
    this.ha.l = 0;
    a = this.Ta();
    b.isVisible() && this.ha.reportEvent("vs");
    a && this.ha.reportEvent("vw");
    Zm(b.volume) && this.ha.reportEvent("am");
    Ao(b) ? this.ha.reportEvent("a") : this.ha.reportEvent("mut");
    this.Fb && this.ha.reportEvent("f");
    -1 != b.j &&
      (this.ha.reportEvent("bm"),
      1 == b.j &&
        (this.ha.reportEvent("b"), Ao(b) && this.ha.reportEvent("umutb")));
    Ao(b) && b.isVisible() && this.ha.reportEvent("avs");
    this.ka && a && this.ha.reportEvent("avw");
    0 < b.aa && this.ha.reportEvent("pv");
    kp(this, this.qa().l.g, !0) && this.ha.reportEvent("gdr");
    2e3 <= Tn(this.qa().j, 1) && this.ha.reportEvent("pmx");
    this.Ga && this.ha.reportEvent("tvoff");
  };
  l.Ac = function () {
    return new So();
  };
  l.qa = function () {
    return this.Mc;
  };
  var jp = function (a, b) {
    return a.L[null != b && b < a.L.length ? b : a.L.length - 1];
  };
  ep.prototype.nd = function () {
    return new zo();
  };
  ep.prototype.ed = function (a, b, c, d) {
    a = oo.prototype.ed.call(this, a, b, c, void 0 === d ? -1 : d);
    a.fullscreen = this.Fb;
    a.l = 2 == this.la;
    a.volume = c.volume;
    Zm(a.volume) ||
      (this.Oa++, (b = this.ra), Zm(b.volume) && (a.volume = b.volume));
    c = c.currentTime;
    a.mediaTime = void 0 !== c && 0 <= c ? c : -1;
    return a;
  };
  var ip = function (a) {
      var b = !!ml(O().R, "umt");
      return a.G || (!b && !a.Z) ? 0 : 1;
    },
    hp = function (a, b) {
      2 == a.la
        ? (b = 0)
        : -1 == a.Dc
        ? (b = 0)
        : ((b -= a.Dc), (b = b > Math.max(1e4, a.l / 3) ? 0 : b));
      var c = a.C(a) || {};
      c = void 0 !== c.currentTime ? c.currentTime : a.H;
      var d = c - a.H,
        e = 0;
      0 <= d
        ? ((a.J += b), (a.W += Math.max(b - d, 0)), (e = Math.min(d, a.J)))
        : (a.ba += Math.abs(d));
      0 != d && (a.J = 0);
      -1 == a.fa && 0 < d && (a.fa = 0 <= sm ? um() - sm : -1);
      a.H = c;
      return e;
    };
  ep.prototype.jd = function (a) {
    return gn(), this.Fb ? 1 : oo.prototype.jd.call(this, a);
  };
  ep.prototype.ya = function () {
    return 1;
  };
  ep.prototype.getDuration = function () {
    return this.l;
  };
  var lp = function (a, b) {
      Sb(a.B, function (c) {
        return c.A == b.A;
      }) || a.B.push(b);
    },
    mp = function (a) {
      var b = Rn(a.qa().g, 1);
      return kp(a, b);
    },
    kp = function (a, b, c) {
      return 15e3 <= b
        ? !0
        : a.ga
        ? (void 0 === c ? 0 : c)
          ? !0
          : 0 < a.l
          ? b >= a.l / 2
          : 0 < a.U
          ? b >= a.U
          : !1
        : !1;
    },
    np = function (a) {
      var b = {},
        c = gn();
      b.insideIframe = c.l;
      b.unmeasurable = a.Ra;
      b.position = a.sb();
      b.exposure = a.ra.aa;
      b.documentSize = c.A;
      b.viewportSize = new Bh(c.g.getWidth(), c.g.getHeight());
      null != a.A && (b.presenceData = a.A);
      b.screenShare = a.ra.ta;
      return b;
    },
    op = function (a) {
      var b = Sm(a.ra.aa, 2),
        c = a.ha.l,
        d = a.ra,
        e = jp(a),
        f = gp(e.A),
        g = gp(e.B),
        h = gp(d.volume),
        k = Sm(e.C, 2),
        n = Sm(e.H, 2),
        m = Sm(d.aa, 2),
        r = Sm(e.J, 2),
        p = Sm(e.P, 2);
      d = Sm(d.ta, 2);
      a = Ai(a.sb());
      a.round();
      e = Zn(e, !1);
      return {
        Rg: b,
        Vb: c,
        Nc: f,
        Jc: g,
        Mb: h,
        Oc: k,
        Kc: n,
        aa: m,
        Pc: r,
        Lc: p,
        ta: d,
        position: a,
        Qc: e,
      };
    },
    qp = function (a, b) {
      pp(a.g, b, function () {
        return {
          Rg: 0,
          Vb: void 0,
          Nc: -1,
          Jc: -1,
          Mb: -1,
          Oc: -1,
          Kc: -1,
          aa: -1,
          Pc: -1,
          Lc: -1,
          ta: -1,
          position: void 0,
          Qc: [],
        };
      });
      a.g[b] = op(a);
    },
    pp = function (a, b, c) {
      for (var d = a.length; d < b + 1; ) a.push(c()), d++;
    },
    tp = function (a, b, c) {
      var d = a.Se[b];
      if (null != d) return d;
      d = rp(a, b);
      var e = Yg(function (f) {
        return f == b;
      });
      a = sp(a, d, d, c, dp[Zg[e]]);
      "fully_viewable_audible_half_duration_impression" == b && (a.std = "csm");
      return a;
    },
    up = function (a, b, c) {
      var d = [b];
      if (a != b || c != b) d.unshift(a), d.push(c);
      return d;
    },
    sp = function (a, b, c, d, e) {
      if (a.Ra) return { if: 0, vs: 0 };
      var f = Ai(a.sb());
      f.round();
      var g = gn(),
        h = O(),
        k = a.qa(),
        n = a.ca ? a.ca.getName() : "ns",
        m = {};
      m["if"] = g.l ? 1 : void 0;
      m.sdk = a.o ? a.o : void 0;
      m.t = a.Hg;
      m.p = [f.top, f.left, f.bottom, f.right];
      m.tos = Pn(k.j, !1);
      m.mtos = Zn(k);
      m.mcvt = k.Y.l;
      m.ps = void 0;
      m.vht = To(k, um(), 2 == a.la);
      m.mut = k.ka.l;
      m.a = gp(a.ra.volume);
      m.mv = gp(k.B);
      m.fs = a.Fb ? 1 : 0;
      m.ft = k.G.g;
      m.at = k.o.g;
      m.as = 0 < k.A ? 1 : 0;
      m.atos = Pn(k.g);
      m.ssb = Pn(k.ga, !1);
      m.amtos = Sn(k.g, !1);
      m.uac = a.Oa;
      m.vpt = k.l.g;
      "nio" == n && ((m.nio = 1), (m.avms = "nio"));
      m.gmm = "4";
      m.gdr = kp(a, k.l.g, !0) ? 1 : 0;
      m.efpf = a.Bb;
      if ("gsv" == n || "nis" == n) (f = a.ca), 0 < f.B && (m.nnut = f.B);
      m.tcm = ip(a);
      m.nmt = a.ba;
      m.bt = a.W;
      m.pst = a.fa;
      m.vpaid = a.G;
      m.dur = a.l;
      m.vmtime = a.H;
      m.is = a.ha.l;
      1 <= a.g.length &&
        ((m.i0 = a.g[0].Vb),
        (m.a0 = [a.g[0].Mb]),
        (m.c0 = [a.g[0].aa]),
        (m.ss0 = [a.g[0].ta]),
        (f = a.g[0].position),
        (m.p0 = f ? bp(f) : void 0));
      2 <= a.g.length &&
        ((m.i1 = a.g[1].Vb),
        (m.a1 = up(a.g[1].Nc, a.g[1].Mb, a.g[1].Jc)),
        (m.c1 = up(a.g[1].Oc, a.g[1].aa, a.g[1].Kc)),
        (m.ss1 = up(a.g[1].Pc, a.g[1].ta, a.g[1].Lc)),
        (f = a.g[1].position),
        (m.p1 = f ? bp(f) : void 0),
        (m.mtos1 = a.g[1].Qc));
      3 <= a.g.length &&
        ((m.i2 = a.g[2].Vb),
        (m.a2 = up(a.g[2].Nc, a.g[2].Mb, a.g[2].Jc)),
        (m.c2 = up(a.g[2].Oc, a.g[2].aa, a.g[2].Kc)),
        (m.ss2 = up(a.g[2].Pc, a.g[2].ta, a.g[2].Lc)),
        (f = a.g[2].position),
        (m.p2 = f ? bp(f) : void 0),
        (m.mtos2 = a.g[2].Qc));
      4 <= a.g.length &&
        ((m.i3 = a.g[3].Vb),
        (m.a3 = up(a.g[3].Nc, a.g[3].Mb, a.g[3].Jc)),
        (m.c3 = up(a.g[3].Oc, a.g[3].aa, a.g[3].Kc)),
        (m.ss3 = up(a.g[3].Pc, a.g[3].ta, a.g[3].Lc)),
        (f = a.g[3].position),
        (m.p3 = f ? bp(f) : void 0),
        (m.mtos3 = a.g[3].Qc));
      m.cs = Po(a.ha);
      b &&
        ((m.ic = Oo(a.ha)),
        (m.dvpt = k.l.j),
        (m.dvs = Un(k.j, 0.5)),
        (m.dfvs = Un(k.j, 1)),
        (m.davs = Un(k.g, 0.5)),
        (m.dafvs = Un(k.g, 1)),
        c && ((k.l.j = 0), Vn(k.j), Vn(k.g)),
        a.Ta() &&
          ((m.dtos = k.L),
          (m.dav = k.F),
          (m.dtoss = a.md + 1),
          c && ((k.L = 0), (k.F = 0), a.md++)),
        (m.dat = k.o.j),
        (m.dft = k.G.j),
        c && ((k.o.j = 0), (k.G.j = 0)));
      m.ps = [g.A.width, g.A.height];
      m.bs = [g.g.getWidth(), g.g.getHeight()];
      m.scs = [g.o.width, g.o.height];
      m.dom = g.domain;
      a.Jb && (m.vds = a.Jb);
      if (0 < a.B.length || a.Va)
        (b = bc(a.B)),
          a.Va && b.push(a.Va),
          (m.pings = Qb(b, function (r) {
            return r.toString();
          }));
      b = Qb(
        Pb(a.B, function (r) {
          return r.B();
        }),
        function (r) {
          return r.getId();
        }
      );
      cc(b);
      m.ces = b;
      a.j && (m.vmer = a.j);
      a.F && (m.vmmk = a.F);
      a.P && (m.vmiec = a.P);
      m.avms = a.ca ? a.ca.getName() : "ns";
      a.ca && dh(m, a.ca.fb());
      d
        ? ((m.c = Sm(a.ra.aa, 2)), (m.ss = Sm(a.ra.ta, 2)))
        : (m.tth = um() - rm);
      m.mc = Sm(k.H, 2);
      m.nc = Sm(k.C, 2);
      m.mv = gp(k.B);
      m.nv = gp(k.A);
      m.lte = Sm(a.ud, 2);
      d = jp(a, e);
      Zn(k);
      m.qmtos = Zn(d);
      m.qnc = Sm(d.C, 2);
      m.qmv = gp(d.B);
      m.qnv = gp(d.A);
      m.qas = 0 < d.A ? 1 : 0;
      m.qi = a.ma;
      m.avms || (m.avms = "geo");
      m.psm = k.U.g;
      m.psv = k.U.getValue();
      m.psfv = k.ba.getValue();
      m.psa = k.Z.getValue();
      h = ol(h.R);
      h.length && (m.veid = h);
      a.A && dh(m, yo(a.A));
      m.avas = a.yc();
      m.vs = a.te();
      m.co = vp(a);
      return m;
    },
    rp = function (a, b) {
      if (Xb(Bm, b)) return !0;
      var c = a.ia[b];
      return void 0 !== c ? ((a.ia[b] = !0), !c) : !1;
    };
  ep.prototype.te = function () {
    return this.Ra ? 2 : mp(this) ? 5 : this.Ta() ? 4 : 3;
  };
  ep.prototype.yc = function () {
    return this.Ha ? (2e3 <= this.qa().o.l ? 4 : 3) : 2;
  };
  var vp = function (a) {
    var b = a.Y.toString(10).padStart(2, "0");
    b = "" + a.Ab + b;
    99 > a.Y && a.Y++;
    return b;
  };
  var wp = Date.now(),
    zp = function () {
      this.g = {};
      var a = G();
      xp(this, a, document);
      var b = yp();
      try {
        if ("1" == b) {
          for (var c = a.parent; c != a.top; c = c.parent)
            xp(this, c, c.document);
          xp(this, a.top, a.top.document);
        }
      } catch (d) {}
    },
    yp = function () {
      var a = document.documentElement;
      try {
        if (!mi(G().top)) return "2";
        var b = [],
          c = G(a.ownerDocument);
        for (a = c; a != c.top; a = a.parent)
          if (a.frameElement) b.push(a.frameElement);
          else break;
        return b && 0 != b.length ? "1" : "0";
      } catch (d) {
        return "2";
      }
    },
    xp = function (a, b, c) {
      fo(
        c,
        "mousedown",
        function () {
          return Ap(a);
        },
        301
      );
      fo(
        b,
        "scroll",
        function () {
          return Bp(a);
        },
        302
      );
      fo(
        c,
        "touchmove",
        function () {
          return Cp(a);
        },
        303
      );
      fo(
        c,
        "mousemove",
        function () {
          return Dp(a);
        },
        304
      );
      fo(
        c,
        "keydown",
        function () {
          return Ep(a);
        },
        305
      );
    },
    Ap = function (a) {
      Pg(a.g, function (b) {
        1e5 < b.l || ++b.l;
      });
    },
    Bp = function (a) {
      Pg(a.g, function (b) {
        1e5 < b.g || ++b.g;
      });
    },
    Cp = function (a) {
      Pg(a.g, function (b) {
        1e5 < b.g || ++b.g;
      });
    },
    Ep = function (a) {
      Pg(a.g, function (b) {
        1e5 < b.j || ++b.j;
      });
    },
    Dp = function (a) {
      Pg(a.g, function (b) {
        1e5 < b.A || ++b.A;
      });
    };
  var Fp = function () {
      this.g = [];
      this.j = [];
    },
    Gp = function (a, b) {
      return Tb(a.g, function (c) {
        return c.ma == b;
      });
    },
    Hp = function (a, b) {
      return b
        ? Tb(a.g, function (c) {
            return c.ua.kb == b;
          })
        : null;
    },
    Ip = function (a, b) {
      return Tb(a.j, function (c) {
        return 2 == c.ya() && c.ma == b;
      });
    },
    Kp = function () {
      var a = Jp;
      return 0 == a.g.length ? a.j : 0 == a.j.length ? a.g : ac(a.j, a.g);
    };
  Fp.prototype.reset = function () {
    this.g = [];
    this.j = [];
  };
  var Lp = function (a, b) {
      a = 1 == b.ya() ? a.g : a.j;
      var c = Ub(a, function (d) {
        return d == b;
      });
      return -1 != c ? (a.splice(c, 1), b.ca && b.ca.dc(), b.X(), !0) : !1;
    },
    Mp = function (a) {
      var b = Jp;
      if (Lp(b, a)) {
        switch (a.ya()) {
          case 0:
            var c = function () {
              return null;
            };
          case 2:
            c = function () {
              return Ip(b, a.ma);
            };
            break;
          case 1:
            c = function () {
              return Gp(b, a.ma);
            };
        }
        for (var d = c(); d; d = c()) Lp(b, d);
      }
    },
    Np = function (a) {
      var b = Jp;
      a = Pb(a, function (c) {
        return !Hp(b, c.ua.kb);
      });
      b.g.push.apply(b.g, ha(a));
    },
    Op = function (a) {
      var b = [];
      Nb(a, function (c) {
        Sb(Jp.g, function (d) {
          return d.ua.kb === c.ua.kb && d.ma === c.ma;
        }) || (Jp.g.push(c), b.push(c));
      });
    },
    Jp = I(Fp);
  var Pp = function () {
      this.g = this.j = null;
    },
    Qp = function (a, b) {
      if (null == a.j) return !1;
      var c = function (d, e) {
        b(d, e);
      };
      a.g = Tb(a.j, function (d) {
        return null != d && d.ae();
      });
      a.g && (a.g.init(c) ? pn(a.g.g) : b(a.g.g.Cb(), a.g));
      return null != a.g;
    };
  var Sp = function (a) {
    a = Rp(a);
    tn.call(this, a.length ? a[a.length - 1] : new ln(P, 0));
    this.l = a;
    this.j = null;
  };
  v(Sp, tn);
  l = Sp.prototype;
  l.getName = function () {
    return (this.j ? this.j : this.g).getName();
  };
  l.fb = function () {
    return (this.j ? this.j : this.g).fb();
  };
  l.Qa = function () {
    return (this.j ? this.j : this.g).Qa();
  };
  l.init = function (a) {
    var b = !1;
    Nb(this.l, function (c) {
      c.initialize() && (b = !0);
    });
    b && ((this.A = a), on(this.g, this));
    return b;
  };
  l.X = function () {
    Nb(this.l, function (a) {
      a.X();
    });
    tn.prototype.X.call(this);
  };
  l.ae = function () {
    return Sb(this.l, function (a) {
      return a.G();
    });
  };
  l.Kb = function () {
    return Sb(this.l, function (a) {
      return a.G();
    });
  };
  l.ec = function (a, b, c) {
    return new Zo(a, this.g, b, c);
  };
  l.gb = function (a) {
    this.j = a.j;
  };
  var Rp = function (a) {
    if (!a.length) return [];
    a = Pb(a, function (c) {
      return null != c && c.G();
    });
    for (var b = 1; b < a.length; b++) on(a[b - 1], a[b]);
    return a;
  };
  var Tp = { threshold: [0, 0.3, 0.5, 0.75, 1] },
    Up = function (a, b, c, d) {
      sn.call(this, a, b, c, d);
      this.F = this.N = this.B = this.C = this.A = null;
    };
  v(Up, Zo);
  Up.prototype.dd = function () {
    var a = this;
    this.F || (this.F = um());
    if (
      lm(298, function () {
        return Vp(a);
      })
    )
      return !0;
    nn(this.j, "msf");
    return !1;
  };
  Up.prototype.dc = function () {
    if (this.A && this.l)
      try {
        this.A.unobserve(this.l),
          this.C
            ? (this.C.unobserve(this.l), (this.C = null))
            : this.B && (this.B.disconnect(), (this.B = null));
      } catch (a) {}
  };
  var Wp = function (a) {
      return a.A && a.A.takeRecords ? a.A.takeRecords() : [];
    },
    Vp = function (a) {
      if (!a.l) return !1;
      var b = a.l,
        c = a.j.g.l,
        d = O().g.g;
      a.A = new c.IntersectionObserver(
        Wl(d, function (e) {
          return Xp(a, e);
        }),
        Tp
      );
      d = Wl(d, function () {
        a.A.unobserve(b);
        a.A.observe(b);
        Xp(a, Wp(a));
      });
      c.ResizeObserver
        ? ((a.C = new c.ResizeObserver(d)), a.C.observe(b))
        : c.MutationObserver &&
          ((a.B = new x.MutationObserver(d)),
          a.B.observe(b, {
            attributes: !0,
            childList: !0,
            characterData: !0,
            subtree: !0,
          }));
      a.A.observe(b);
      Xp(a, Wp(a));
      return !0;
    },
    Xp = function (a, b) {
      try {
        if (b.length) {
          a.N || (a.N = um());
          var c = Yp(b),
            d = Nm(a.l, a.j.g.l),
            e = d.x,
            f = d.y;
          a.g = new H(
            Math.round(f),
            Math.round(e) + c.boundingClientRect.width,
            Math.round(f) + c.boundingClientRect.height,
            Math.round(e)
          );
          var g = Xm(c.intersectionRect);
          a.o = Bi(g, a.g.left - g.left, a.g.top - g.top);
        }
      } catch (h) {
        a.dc(), nm(299, h);
      }
    },
    Yp = function (a) {
      return Rb(
        a,
        function (b, c) {
          return b.time > c.time ? b : c;
        },
        a[0]
      );
    };
  l = Up.prototype;
  l.ab = function () {
    var a = Wp(this);
    0 < a.length && Xp(this, a);
    Zo.prototype.ab.call(this);
  };
  l.gd = function () {};
  l.we = function () {
    return !1;
  };
  l.ie = function () {};
  l.fb = function () {
    var a = {};
    return Object.assign(
      this.j.fb(),
      ((a.niot_obs = this.F), (a.niot_cbk = this.N), a)
    );
  };
  l.getName = function () {
    return "nio";
  };
  var Zp = function (a) {
    a = void 0 === a ? P : a;
    tn.call(this, new ln(a, 2));
  };
  v(Zp, tn);
  Zp.prototype.getName = function () {
    return "nio";
  };
  Zp.prototype.Kb = function () {
    return !gn().j && null != this.g.g.l.IntersectionObserver;
  };
  Zp.prototype.ec = function (a, b, c) {
    return new Up(a, this.g, b, c);
  };
  var aq = function () {
    var a = $p();
    ln.call(this, P.top, a, "geo");
  };
  v(aq, ln);
  aq.prototype.ba = function () {
    return gn().g;
  };
  aq.prototype.G = function () {
    var a = $p();
    this.N !== a &&
      (this.g != this && a > this.g.N && ((this.g = this), mn(this)),
      (this.N = a));
    return 2 == a;
  };
  var $p = function () {
    O();
    var a = gn();
    return a.l || a.j ? 0 : 2;
  };
  var bq = function () {};
  var cq = function () {
      this.done = !1;
      this.g = {
        Af: 0,
        fe: 0,
        Mi: 0,
        oe: 0,
        rd: -1,
        If: 0,
        Hf: 0,
        Jf: 0,
        Dg: 0,
      };
      this.o = null;
      this.B = !1;
      this.l = null;
      this.C = 0;
      this.j = new jn(this);
    },
    fq = function () {
      var a = dq;
      a.B ||
        ((a.B = !0),
        eq(a, function () {
          return a.A.apply(a, ha(Ia.apply(0, arguments)));
        }),
        a.A());
    };
  cq.prototype.sample = function () {
    gq(this, Kp(), !1);
  };
  var hq = function () {
      I(bq);
      var a = I(Pp);
      null != a.g && a.g.g ? pn(a.g.g) : cn(gn());
    },
    gq = function (a, b, c) {
      if (!a.done && (a.j.cancel(), 0 != b.length)) {
        a.l = null;
        try {
          hq();
          var d = um();
          O().o = d;
          if (null != I(Pp).g)
            for (var e = 0; e < b.length; e++) so(b[e], d, c);
          for (d = 0; d < b.length; d++) to(b[d]);
          ++a.g.oe;
        } finally {
          c
            ? Nb(b, function (f) {
                f.ra.aa = 0;
              })
            : kn(a.j);
        }
      }
    },
    eq = function (a, b) {
      if (!a.o) {
        b = mm(142, b);
        Ql();
        var c = Wi(rl);
        c && Ng(rl, c, b, { capture: !1 }) && (a.o = b);
      }
    };
  cq.prototype.A = function () {
    var a = hn(),
      b = um();
    a
      ? (tm ||
          ((pm = b),
          Nb(Jp.g, function (c) {
            var d = c.qa();
            d.W = To(d, b, 1 != c.la);
          })),
        (tm = !0))
      : ((this.C = iq(this, b)),
        (tm = !1),
        (rm = b),
        Nb(Jp.g, function (c) {
          c.Pb && (c.qa().I = b);
        }));
    gq(this, Kp(), !a);
  };
  var jq = function () {
      var a = I(Pp);
      if (null != a.g) {
        var b = a.g;
        Nb(Kp(), function (c) {
          return qo(c, b);
        });
      }
    },
    iq = function (a, b) {
      a = a.C;
      tm && (a += b - pm);
      return a;
    },
    kq = function (a) {
      a =
        void 0 === a
          ? function () {
              return {};
            }
          : a;
      im.Od("av-js");
      em.g = 0.01;
      km([
        function (b) {
          var c = O(),
            d = {};
          d = ((d.bin = c.j), (d.type = "error"), d);
          c = nl(c.R);
          if (!dq.l) {
            var e = dq,
              f = P.document,
              g = 0 <= qm ? um() - qm : -1,
              h = um();
            -1 == e.g.rd && (g = h);
            var k = gn(),
              n = O(),
              m = nl(n.R),
              r = Kp();
            try {
              if (0 < r.length) {
                var p = k.g;
                p && (m.bs = [p.getWidth(), p.getHeight()]);
                var t = k.A;
                t && (m.ps = [t.width, t.height]);
                P.screen && (m.scs = [P.screen.width, P.screen.height]);
              } else
                (m.url = encodeURIComponent(P.location.href.substring(0, 512))),
                  f.referrer &&
                    (m.referrer = encodeURIComponent(
                      f.referrer.substring(0, 512)
                    ));
              m.tt = g;
              m.pt = qm;
              m.bin = n.j;
              void 0 !== P.google_osd_load_pub_page_exp &&
                (m.olpp = P.google_osd_load_pub_page_exp);
              m.deb = [
                1,
                e.g.Af,
                e.g.fe,
                e.g.oe,
                e.g.rd,
                0,
                e.j.j,
                e.g.If,
                e.g.Hf,
                e.g.Jf,
                e.g.Dg,
                -1,
              ].join(";");
              m.tvt = iq(e, h);
              k.j && (m.inapp = 1);
              if (null !== P && P != P.top) {
                0 < r.length &&
                  (m.iframe_loc = encodeURIComponent(
                    P.location.href.substring(0, 512)
                  ));
                var w = k.I;
                m.is = [w.getWidth(), w.getHeight()];
              }
            } catch (R) {
              m.error = 1;
            }
            dq.l = m;
          }
          t = dq.l;
          p = {};
          for (var y in t) p[y] = t[y];
          y = O().g;
          if (1 == ml(y.l, "prf")) {
            t = new Ul();
            w = y.g;
            e = 0;
            -1 < w.g && (e = w.l.g.now() - w.g);
            w = w.A + e;
            if (null != w && "number" !== typeof w)
              throw Error(
                "Value of float/double field must be a number, found " +
                  typeof w +
                  ": " +
                  w
              );
            t = D(t, 1, w, 0);
            w = y.g;
            t = D(t, 5, ie(-1 < w.g ? w.j + 1 : w.j), 0);
            t = D(t, 2, le(y.j.g.l()), "0");
            t = D(t, 3, le(y.j.g.j()), "0");
            y = D(t, 4, le(y.j.g.g()), "0");
            t = {};
            y = ((t.pf = Ic(y.g())), t);
          } else y = {};
          dh(p, y);
          dh(b, d, c, p, a());
        },
      ]);
    },
    dq = I(cq);
  var lq = null,
    mq = "",
    nq = !1,
    oq = function () {
      var a = lq || P;
      if (!a) return "";
      var b = [];
      if (!a.location || !a.location.href) return "";
      b.push("url=" + encodeURIComponent(a.location.href.substring(0, 512)));
      a.document &&
        a.document.referrer &&
        b.push(
          "referrer=" +
            encodeURIComponent(a.document.referrer.substring(0, 512))
        );
      return b.join("&");
    };
  function pq() {
    var a =
        "av.default_js_unreleased_RCxx".match(/_(\d{8})_RC\d+$/) ||
        "av.default_js_unreleased_RCxx".match(/_(\d{8})_\d+_\d+$/) ||
        "av.default_js_unreleased_RCxx".match(/_(\d{8})_\d+\.\d+$/) ||
        "av.default_js_unreleased_RCxx".match(/_(\d{8})_\d+_RC\d+$/),
      b;
    if (2 == (null == (b = a) ? void 0 : b.length)) return a[1];
    a = "av.default_js_unreleased_RCxx".match(
      /.*_(\d{2})\.(\d{4})\.\d+_RC\d+$/
    );
    var c;
    return 3 == (null == (c = a) ? void 0 : c.length)
      ? "20" + a[1] + a[2]
      : null;
  }
  var qq = function () {
      return "ima_html5_sdk".includes("ima_html5_sdk")
        ? { Ja: "ima", Ka: null }
        : "ima_html5_sdk".includes("ima_native_sdk")
        ? { Ja: "nima", Ka: null }
        : "ima_html5_sdk".includes("admob-native-video-javascript")
        ? { Ja: "an", Ka: null }
        : "av.default_js_unreleased_RCxx".includes("cast_js_sdk")
        ? { Ja: "cast", Ka: pq() }
        : "av.default_js_unreleased_RCxx".includes("youtube.player.web")
        ? { Ja: "yw", Ka: pq() }
        : "av.default_js_unreleased_RCxx".includes("outstream_web_client")
        ? { Ja: "out", Ka: pq() }
        : "av.default_js_unreleased_RCxx".includes("drx_rewarded_web")
        ? { Ja: "r", Ka: pq() }
        : "av.default_js_unreleased_RCxx".includes("gam_native_web_video")
        ? { Ja: "n", Ka: pq() }
        : "av.default_js_unreleased_RCxx".includes("admob_interstitial_video")
        ? { Ja: "int", Ka: pq() }
        : { Ja: "j", Ka: null };
    },
    rq = qq().Ja,
    sq = qq().Ka;
  var uq = function (a, b) {
      var c = { sv: "961" };
      null !== sq && (c.v = sq);
      c.cb = rq;
      c.nas = Jp.g.length;
      c.msg = a;
      void 0 !== b && (a = tq(b)) && (c.e = Cm[a]);
      return c;
    },
    vq = function (a) {
      return 0 == a.lastIndexOf("custom_metric_viewable", 0);
    },
    tq = function (a) {
      var b = vq(a) ? "custom_metric_viewable" : a.toLowerCase();
      return Yg(function (c) {
        return c == b;
      });
    };
  var wq = { mh: "visible", Vg: "audible", bi: "time", di: "timetype" },
    xq = {
      visible: function (a) {
        return /^(100|[0-9]{1,2})$/.test(a);
      },
      audible: function (a) {
        return "0" == a || "1" == a;
      },
      timetype: function (a) {
        return "mtos" == a || "tos" == a;
      },
      time: function (a) {
        return /^(100|[0-9]{1,2})%$/.test(a) || /^([0-9])+ms$/.test(a);
      },
    },
    yq = function () {
      this.g = void 0;
      this.j = !1;
      this.l = 0;
      this.A = -1;
      this.o = "tos";
    },
    zq = function (a) {
      try {
        var b = a.split(",");
        return b.length > Ug(wq).length
          ? null
          : Rb(
              b,
              function (c, d) {
                d = d.toLowerCase().split("=");
                if (2 != d.length || void 0 === xq[d[0]] || !xq[d[0]](d[1]))
                  throw Error("Entry (" + d[0] + ", " + d[1] + ") is invalid.");
                c[d[0]] = d[1];
                return c;
              },
              {}
            );
      } catch (c) {
        return null;
      }
    },
    Aq = function (a, b) {
      if (void 0 == a.g) return 0;
      switch (a.o) {
        case "mtos":
          return a.j ? Tn(b.g, a.g) : Tn(b.j, a.g);
        case "tos":
          return a.j ? Rn(b.g, a.g) : Rn(b.j, a.g);
      }
      return 0;
    };
  var Bq = function (a, b, c, d) {
    Vo.call(this, b, d);
    this.C = a;
    this.I = c;
  };
  v(Bq, Vo);
  Bq.prototype.getId = function () {
    return this.C;
  };
  Bq.prototype.B = function () {
    return !0;
  };
  Bq.prototype.g = function (a) {
    var b = a.qa(),
      c = a.getDuration();
    return Sb(this.I, function (d) {
      if (void 0 != d.g) var e = Aq(d, b);
      else
        b: {
          switch (d.o) {
            case "mtos":
              e = d.j ? b.o.l : b.l.g;
              break b;
            case "tos":
              e = d.j ? b.o.g : b.l.g;
              break b;
          }
          e = 0;
        }
      0 == e
        ? (d = !1)
        : ((d = -1 != d.l ? d.l : void 0 !== c && 0 < c ? d.A * c : -1),
          (d = -1 != d && e >= d));
      return d;
    });
  };
  var Cq = function () {};
  v(Cq, Lo);
  Cq.prototype.g = function (a) {
    var b = new Ko();
    b.g = Mo(a, Ho);
    b.j = Mo(a, Jo);
    return b;
  };
  var Dq = function (a) {
    Vo.call(this, "fully_viewable_audible_half_duration_impression", a);
  };
  v(Dq, Vo);
  Dq.prototype.g = function (a) {
    return mp(a);
  };
  var Eq = function (a) {
    this.g = a;
  };
  v(Eq, Xo);
  var Fq = function (a, b) {
    Vo.call(this, a, b);
  };
  v(Fq, Vo);
  Fq.prototype.g = function (a) {
    return a.qa().Ta();
  };
  var Gq = function (a) {
    Wo.call(this, "measurable_impression", a);
  };
  v(Gq, Wo);
  Gq.prototype.g = function (a) {
    var b = Xb(this.C, ml(O().R, "ovms"));
    return !a.Ra && (0 != a.la || b);
  };
  var Hq = function () {
    Eq.apply(this, arguments);
  };
  v(Hq, Eq);
  Hq.prototype.j = function () {
    return new Gq(this.g);
  };
  Hq.prototype.l = function () {
    return [new Fq("viewable_impression", this.g), new Dq(this.g)];
  };
  var Iq = function (a, b, c) {
    ap.call(this, a, b, c);
  };
  v(Iq, ap);
  Iq.prototype.A = function () {
    var a = Na("ima.admob.getViewability"),
      b = ml(this.R, "queryid");
    "function" === typeof a && b && a(b);
  };
  Iq.prototype.getName = function () {
    return "gsv";
  };
  var Jq = function (a) {
    a = void 0 === a ? P : a;
    tn.call(this, new ln(a, 2));
  };
  v(Jq, tn);
  Jq.prototype.getName = function () {
    return "gsv";
  };
  Jq.prototype.Kb = function () {
    var a = gn();
    O();
    return a.j && !1;
  };
  Jq.prototype.ec = function (a, b, c) {
    return new Iq(this.g, b, c);
  };
  var Kq = function (a, b, c) {
    ap.call(this, a, b, c);
  };
  v(Kq, ap);
  Kq.prototype.A = function () {
    var a = this,
      b = Na("ima.bridge.getNativeViewability"),
      c = ml(this.R, "queryid");
    "function" === typeof b &&
      c &&
      b(c, function (d) {
        $g(d) && a.B++;
        var e = d.opt_nativeViewVisibleBounds || {},
          f = d.opt_nativeViewHidden;
        a.g = Ym(d.opt_nativeViewBounds || {});
        var g = a.j.A;
        g.g = f ? Ai($o) : Ym(e);
        a.timestamp = d.opt_nativeTime || -1;
        gn().g = g.g;
        d = d.opt_nativeVolume;
        void 0 !== d && (g.volume = d);
      });
  };
  Kq.prototype.getName = function () {
    return "nis";
  };
  var Lq = function (a) {
    a = void 0 === a ? P : a;
    tn.call(this, new ln(a, 2));
  };
  v(Lq, tn);
  Lq.prototype.getName = function () {
    return "nis";
  };
  Lq.prototype.Kb = function () {
    var a = gn();
    O();
    return a.j && !1;
  };
  Lq.prototype.ec = function (a, b, c) {
    return new Kq(this.g, b, c);
  };
  var Mq = function () {
    ln.call(this, P, 2, "mraid");
    this.fa = 0;
    this.J = this.L = !1;
    this.I = null;
    this.j = Dm(this.l);
    this.A.g = new H(0, 0, 0, 0);
    this.ga = !1;
  };
  v(Mq, ln);
  Mq.prototype.G = function () {
    return null != this.j.Da;
  };
  Mq.prototype.Z = function () {
    var a = {};
    this.fa && (a.mraid = this.fa);
    this.L && (a.mlc = 1);
    a.mtop = this.j.Cg;
    this.I && (a.mse = this.I);
    this.ga && (a.msc = 1);
    a.mcp = this.j.uc;
    return a;
  };
  Mq.prototype.B = function (a) {
    var b = Ia.apply(1, arguments);
    try {
      return this.j.Da[a].apply(this.j.Da, b);
    } catch (c) {
      nm(538, c, 0.01, function (d) {
        d.method = a;
      });
    }
  };
  var Nq = function (a, b, c) {
    a.B("addEventListener", b, c);
  };
  Mq.prototype.initialize = function () {
    var a = this;
    if (this.va) return !this.Tb();
    this.va = !0;
    if (2 === this.j.uc) return (this.I = "ng"), nn(this, "w"), !1;
    if (1 === this.j.uc) return (this.I = "mm"), nn(this, "w"), !1;
    gn().N = !0;
    this.l.document.readyState && "complete" == this.l.document.readyState
      ? Oq(this)
      : fo(
          this.l,
          "load",
          function () {
            Ql().setTimeout(
              mm(292, function () {
                return Oq(a);
              }),
              100
            );
          },
          292
        );
    return !0;
  };
  var Oq = function (a) {
      O().A = !!a.B("isViewable");
      Nq(a, "viewableChange", Pq);
      "loading" === a.B("getState") ? Nq(a, "ready", Qq) : Rq(a);
    },
    Rq = function (a) {
      "string" === typeof a.j.Da.AFMA_LIDAR
        ? ((a.L = !0), Sq(a))
        : ((a.j.uc = 3), (a.I = "nc"), nn(a, "w"));
    },
    Sq = function (a) {
      a.J = !1;
      var b = 1 == ml(O().R, "rmmt"),
        c = !!a.B("isViewable");
      (b ? !c : 1) &&
        Ql().setTimeout(
          mm(524, function () {
            a.J || (Tq(a), nm(540, Error()), (a.I = "mt"), nn(a, "w"));
          }),
          500
        );
      Uq(a);
      Nq(a, a.j.Da.AFMA_LIDAR, Vq);
    },
    Uq = function (a) {
      var b = 1 == ml(O().R, "sneio"),
        c = void 0 !== a.j.Da.AFMA_LIDAR_EXP_1,
        d = void 0 !== a.j.Da.AFMA_LIDAR_EXP_2;
      (b = b && d) && (a.j.Da.AFMA_LIDAR_EXP_2 = !0);
      c && (a.j.Da.AFMA_LIDAR_EXP_1 = !b);
    },
    Tq = function (a) {
      a.B("removeEventListener", a.j.Da.AFMA_LIDAR, Vq);
      a.L = !1;
    };
  Mq.prototype.U = function () {
    var a = gn(),
      b = Wq(this, "getMaxSize");
    a.g = new H(0, b.width, b.height, 0);
  };
  Mq.prototype.W = function () {
    gn().o = Wq(this, "getScreenSize");
  };
  var Wq = function (a, b) {
    if ("loading" === a.B("getState")) return new Bh(-1, -1);
    b = a.B(b);
    if (!b) return new Bh(-1, -1);
    a = parseInt(b.width, 10);
    b = parseInt(b.height, 10);
    return isNaN(a) || isNaN(b) ? new Bh(-1, -1) : new Bh(a, b);
  };
  Mq.prototype.X = function () {
    Tq(this);
    ln.prototype.X.call(this);
  };
  var Qq = function () {
      try {
        var a = I(Mq);
        a.B("removeEventListener", "ready", Qq);
        Rq(a);
      } catch (b) {
        nm(541, b);
      }
    },
    Vq = function (a, b) {
      try {
        var c = I(Mq);
        c.J = !0;
        var d = a
          ? new H(a.y, a.x + a.width, a.y + a.height, a.x)
          : new H(0, 0, 0, 0);
        var e = um(),
          f = hn();
        var g = new wm(e, f, c);
        g.g = d;
        g.volume = b;
        c.gb(g);
      } catch (h) {
        nm(542, h);
      }
    },
    Pq = function (a) {
      var b = O(),
        c = I(Mq);
      a && !b.A && ((b.A = !0), (c.ga = !0), c.I && nn(c, "w", !0));
    };
  var Zl = new (function (a, b) {
    this.key = a;
    this.defaultValue = void 0 === b ? !1 : b;
    this.valueType = "boolean";
  })("45378663");
  var Yq = function () {
    this.l = this.va = !1;
    this.g = this.j = null;
    var a = {};
    this.L =
      ((a.start = this.ag),
      (a.firstquartile = this.Vf),
      (a.midpoint = this.Xf),
      (a.thirdquartile = this.bg),
      (a.complete = this.Sf),
      (a.error = this.Tf),
      (a.pause = this.Ed),
      (a.resume = this.He),
      (a.skip = this.Zf),
      (a.viewable_impression = this.La),
      (a.mute = this.Ib),
      (a.unmute = this.Ib),
      (a.fullscreen = this.Wf),
      (a.exitfullscreen = this.Uf),
      (a.fully_viewable_audible_half_duration_impression = this.La),
      (a.measurable_impression = this.La),
      (a.abandon = this.Ed),
      (a.engagedview = this.La),
      (a.impression = this.La),
      (a.creativeview = this.La),
      (a.progress = this.Ib),
      (a.custom_metric_viewable = this.La),
      (a.bufferstart = this.Ed),
      (a.bufferfinish = this.He),
      (a.audio_measurable = this.La),
      (a.audio_audible = this.La),
      a);
    a = {};
    this.U =
      ((a.overlay_resize = this.Yf),
      (a.abandon = this.pd),
      (a.close = this.pd),
      (a.collapse = this.pd),
      (a.overlay_unmeasurable_impression = function (b) {
        return tp(b, "overlay_unmeasurable_impression", hn());
      }),
      (a.overlay_viewable_immediate_impression = function (b) {
        return tp(b, "overlay_viewable_immediate_impression", hn());
      }),
      (a.overlay_unviewable_impression = function (b) {
        return tp(b, "overlay_unviewable_impression", hn());
      }),
      (a.overlay_viewable_end_of_session_impression = function (b) {
        return tp(b, "overlay_viewable_end_of_session_impression", hn());
      }),
      a);
    O().j = 3;
    Xq(this);
  };
  Yq.prototype.o = function (a) {
    po(a, !1);
    Mp(a);
  };
  Yq.prototype.I = function () {};
  var Zq = function (a, b, c, d) {
    a = a.B(null, d, !0, b);
    a.o = c;
    Np([a]);
    return a;
  };
  Yq.prototype.B = function (a, b, c, d) {
    var e = this;
    a = new ep(P, a, c ? b : -1, 7, this.kd(), this.me());
    a.ma = d;
    kl(a.R);
    ll(a.R, "queryid", a.ma);
    a.Gd("");
    uo(
      a,
      function () {
        return e.J.apply(e, ha(Ia.apply(0, arguments)));
      },
      function () {
        return e.P.apply(e, ha(Ia.apply(0, arguments)));
      }
    );
    (d = I(Pp).g) && qo(a, d);
    a.ua.kb && I(bq);
    return a;
  };
  var $q = function (a, b, c) {
      Tk(b);
      var d = a.g;
      Nb(b, function (e) {
        var f = Qb(e.l, function (g) {
          var h = zq(g);
          if (null == h) g = null;
          else if (
            ((g = new yq()),
            null != h.visible && (g.g = h.visible / 100),
            null != h.audible && (g.j = 1 == h.audible),
            null != h.time)
          ) {
            var k = "mtos" == h.timetype ? "mtos" : "tos",
              n = lb(h.time, "%") ? "%" : "ms";
            h = parseInt(h.time, 10);
            "%" == n && (h /= 100);
            "ms" == n ? ((g.l = h), (g.A = -1)) : ((g.l = -1), (g.A = h));
            g.o = void 0 === k ? "tos" : k;
          }
          return g;
        });
        Sb(f, function (g) {
          return null == g;
        }) || lp(c, new Bq(e.id, e.g, f, d));
      });
    },
    ar = function () {
      var a = [],
        b = O();
      a.push(I(aq));
      ml(b.R, "mvp_lv") && a.push(I(Mq));
      b = [new Jq(), new Lq()];
      b.push(new Sp(a));
      b.push(new Zp(P));
      return b;
    },
    cr = function (a) {
      if (!a.va) {
        a.va = !0;
        try {
          var b = um(),
            c = O(),
            d = gn();
          qm = b;
          c.l = 79463069;
          "o" !== a.j && (lq = zi(P));
          if (Rl()) {
            dq.g.fe = 0;
            dq.g.rd = um() - b;
            var e = ar(),
              f = I(Pp);
            f.j = e;
            Qp(f, function () {
              br();
            })
              ? dq.done || (jq(), on(f.g.g, a), fq())
              : d.l
              ? br()
              : fq();
          } else nq = !0;
        } catch (g) {
          throw (Jp.reset(), g);
        }
      }
    },
    dr = function (a) {
      dq.j.cancel();
      mq = a;
      dq.done = !0;
    },
    er = function (a) {
      if (a.j) return a.j;
      var b = I(Pp).g;
      if (b)
        switch (b.getName()) {
          case "nis":
            a.j = "n";
            break;
          case "gsv":
            a.j = "m";
        }
      a.j || (a.j = "h");
      return a.j;
    },
    fr = function (a, b, c) {
      if (null == a.g) return (b.Jb |= 4), !1;
      a = a.g.report(c, b);
      b.Jb |= a;
      return 0 == a;
    };
  Yq.prototype.Eb = function (a) {
    switch (a.Qa()) {
      case 0:
        if ((a = I(Pp).g)) (a = a.g), Yb(a.o, this), a.F && this.Ma() && qn(a);
        br();
        break;
      case 2:
        fq();
    }
  };
  Yq.prototype.gb = function () {};
  Yq.prototype.Ma = function () {
    return !1;
  };
  var br = function () {
    var a = [new Zp(P)],
      b = I(Pp);
    b.j = a;
    Qp(b, function () {
      dr("i");
    })
      ? dq.done || (jq(), fq())
      : dr("i");
  };
  Yq.prototype.P = function (a, b) {
    a.Ra = !0;
    switch (a.ya()) {
      case 1:
        gr(a, b);
        break;
      case 2:
        this.Jd(a);
    }
    this.Nd(a);
  };
  var gr = function (a, b) {
    if (!a.Pa) {
      var c = tp(a, "start", hn());
      c = a.Fd.g(c).g;
      var d = { id: "lidarv" };
      d.r = b;
      d.sv = "961";
      null !== sq && (d.v = sq);
      ji(c, function (e, f) {
        return (d[e] = "mtos" == e || "tos" == e ? f : encodeURIComponent(f));
      });
      b = oq();
      ji(b, function (e, f) {
        return (d[e] = encodeURIComponent(f));
      });
      b =
        "//pagead2.googlesyndication.com/pagead/gen_204?" + Bn(zn(new xn(), d));
      En(b);
      a.Pa = !0;
    }
  };
  l = Yq.prototype;
  l.ag = function (a) {
    var b = a.C(a);
    b && ((b = b.volume), (a.Ha = Zm(b) && 0 < b));
    qp(a, 0);
    return tp(a, "start", hn());
  };
  l.Ib = function (a, b, c) {
    gq(dq, [a], !hn());
    return this.La(a, b, c);
  };
  l.La = function (a, b, c) {
    return tp(a, c, hn());
  };
  l.Vf = function (a) {
    return hr(a, "firstquartile", 1);
  };
  l.Xf = function (a) {
    a.ga = !0;
    return hr(a, "midpoint", 2);
  };
  l.bg = function (a) {
    return hr(a, "thirdquartile", 3);
  };
  l.Sf = function (a) {
    var b = hr(a, "complete", 4);
    fp(a);
    return b;
  };
  l.Tf = function (a) {
    a.la = 3;
    return tp(a, "error", hn());
  };
  var hr = function (a, b, c) {
    gq(dq, [a], !hn());
    qp(a, c);
    4 != c && pp(a.L, c, a.Ac);
    return tp(a, b, hn());
  };
  l = Yq.prototype;
  l.He = function (a, b, c) {
    b = hn();
    2 != a.la || b || (a.qa().I = um());
    gq(dq, [a], !b);
    2 == a.la && (a.la = 1);
    return tp(a, c, b);
  };
  l.Zf = function (a, b) {
    b = this.Ib(a, b || {}, "skip");
    fp(a);
    return b;
  };
  l.Wf = function (a, b) {
    po(a, !0);
    return this.Ib(a, b || {}, "fullscreen");
  };
  l.Uf = function (a, b) {
    po(a, !1);
    return this.Ib(a, b || {}, "exitfullscreen");
  };
  l.Ed = function (a, b, c) {
    b = a.qa();
    b.W = To(b, um(), 1 != a.la);
    gq(dq, [a], !hn());
    1 == a.la && (a.la = 2);
    return tp(a, c, hn());
  };
  l.Yf = function (a) {
    gq(dq, [a], !hn());
    return a.j();
  };
  l.pd = function (a) {
    gq(dq, [a], !hn());
    this.Ee(a);
    fp(a);
    return a.j();
  };
  var Xq = function (a) {
      kq(function () {
        var b = ir();
        null != a.j && (b.sdk = a.j);
        var c = I(Pp);
        null != c.g && (b.avms = c.g.getName());
        return b;
      });
    },
    jr = function (a, b, c, d) {
      var e = Hp(Jp, c);
      null !== e && e.ma !== b && (a.o(e), (e = null));
      e ||
        ((b = a.B(c, um(), !1, b)),
        0 == Jp.j.length && (O().l = 79463069),
        Op([b]),
        (e = b),
        (e.o = er(a)),
        d && (e.lb = d));
      return e;
    };
  Yq.prototype.J = function () {};
  var lr = function (a, b) {
    b.F = 0;
    for (var c in ym) null == a[c] && (b.F |= ym[c]);
    kr(a, "currentTime");
    kr(a, "duration");
  };
  l = Yq.prototype;
  l.Jd = function () {};
  l.Ee = function () {};
  l.be = function () {};
  l.Nd = function () {};
  l.ld = function () {};
  l.me = function () {
    this.g || (this.g = this.ld());
    return null == this.g || this.l ? new Yo() : new Hq(this.g);
  };
  l.kd = function () {
    return new Cq();
  };
  var kr = function (a, b) {
      var c = a[b];
      void 0 !== c && 0 < c && (a[b] = Math.floor(1e3 * c));
    },
    ir = function () {
      var a = gn(),
        b = {},
        c = {},
        d = {};
      return Object.assign(
        {},
        ((b.sv = "961"), b),
        null !== sq && ((c.v = sq), c),
        ((d["if"] = a.l ? "1" : "0"), (d.nas = String(Jp.g.length)), d)
      );
    };
  var mr = function (a) {
    Vo.call(this, "audio_audible", a);
  };
  v(mr, Vo);
  mr.prototype.g = function (a) {
    return 4 == a.yc();
  };
  var nr = function (a) {
    Wo.call(this, "audio_measurable", a);
  };
  v(nr, Wo);
  nr.prototype.g = function (a) {
    a = a.yc();
    return 3 == a || 4 == a;
  };
  var or = function () {
    Eq.apply(this, arguments);
  };
  v(or, Eq);
  or.prototype.j = function () {
    return new nr(this.g);
  };
  or.prototype.l = function () {
    return [new mr(this.g)];
  };
  var pr = function () {};
  v(pr, Lo);
  pr.prototype.g = function (a) {
    a &&
      (28 === a.e && (a = Object.assign({}, a, { avas: 3 })),
      4 === a.vs || 5 === a.vs) &&
      (a = Object.assign({}, a, { vs: 3 }));
    var b = new Ko();
    b.g = Mo(a, Io);
    b.j = Mo(a, Jo);
    return b;
  };
  var qr = function (a) {
    this.j = a;
  };
  qr.prototype.report = function (a, b) {
    var c = this.g(b);
    if ("function" === typeof c) {
      var d = {};
      var e = {};
      d = Object.assign(
        {},
        null !== sq && ((d.v = sq), d),
        ((e.sv = "961"), (e.cb = rq), (e.e = rr(a)), e)
      );
      e = tp(b, a, hn());
      dh(d, e);
      b.Se[a] = e;
      d = 2 == b.ya() ? Dn(d).join("&") : b.Fd.g(d).g;
      try {
        return c(b.ma, d, a), 0;
      } catch (f) {
        return 2;
      }
    } else return 1;
  };
  var rr = function (a) {
    var b = vq(a) ? "custom_metric_viewable" : a;
    a = Yg(function (c) {
      return c == b;
    });
    return Cm[a];
  };
  qr.prototype.g = function () {
    return Na(this.j);
  };
  var sr = function (a, b) {
    this.j = a;
    this.l = b;
  };
  v(sr, qr);
  sr.prototype.g = function (a) {
    if (!a.lb) return qr.prototype.g.call(this, a);
    if (this.l[a.lb]) return function () {};
    nm(393, Error());
    return null;
  };
  var tr = function () {
    Yq.call(this);
    this.F = void 0;
    this.G = null;
    this.N = !1;
    this.A = {};
    this.H = 0;
    this.C = "ACTIVE_VIEW_TRAFFIC_TYPE_UNSPECIFIED";
  };
  v(tr, Yq);
  tr.prototype.I = function (a, b) {
    var c = this,
      d = I(Pp);
    if (null != d.g)
      switch (d.g.getName()) {
        case "nis":
          var e = ur(this, a, b);
          break;
        case "gsv":
          e = vr(this, a, b);
          break;
        case "exc":
          e = wr(this, a);
      }
    e ||
      (b.opt_overlayAdElement
        ? (e = void 0)
        : b.opt_adElement && (e = jr(this, a, b.opt_adElement, b.opt_osdId)));
    e &&
      1 == e.ya() &&
      (e.C == Hg &&
        (e.C = function (f) {
          return c.be(f);
        }),
      xr(this, e, b));
    return e;
  };
  var xr = function (a, b, c) {
    c = c.opt_configurable_tracking_events;
    null != a.g && Array.isArray(c) && $q(a, c, b);
  };
  tr.prototype.be = function (a) {
    a.j = 0;
    a.P = 0;
    if ("h" == a.o || "n" == a.o) {
      var b;
      O();
      if (a.lb && yr(this)) {
        var c = this.A[a.lb];
        c
          ? (b = function (e) {
              return zr(c, e);
            })
          : null !== c && nm(379, Error());
      } else b = Na("ima.common.getVideoMetadata");
      if ("function" === typeof b)
        try {
          var d = b(a.ma);
        } catch (e) {
          a.j |= 4;
        }
      else a.j |= 2;
    } else if ("b" == a.o)
      if (((b = Na("ytads.bulleit.getVideoMetadata")), "function" === typeof b))
        try {
          d = b(a.ma);
        } catch (e) {
          a.j |= 4;
        }
      else a.j |= 2;
    else if ("ml" == a.o)
      if (((b = Na("ima.common.getVideoMetadata")), "function" === typeof b))
        try {
          d = b(a.ma);
        } catch (e) {
          a.j |= 4;
        }
      else a.j |= 2;
    else a.j |= 1;
    a.j ||
      (void 0 === d
        ? (a.j |= 8)
        : null === d
        ? (a.j |= 16)
        : $g(d)
        ? (a.j |= 32)
        : null != d.errorCode && ((a.P = d.errorCode), (a.j |= 64)));
    null == d && (d = {});
    lr(d, a);
    Zm(d.volume) && Zm(this.F) && (d.volume *= this.F);
    return d;
  };
  var vr = function (a, b, c) {
      var d = Gp(Jp, b);
      d ||
        ((d = c.opt_nativeTime || -1),
        (d = Zq(a, b, er(a), d)),
        c.opt_osdId && (d.lb = c.opt_osdId));
      return d;
    },
    ur = function (a, b, c) {
      var d = Gp(Jp, b);
      d || (d = Zq(a, b, "n", c.opt_nativeTime || -1));
      return d;
    },
    wr = function (a, b) {
      var c = Gp(Jp, b);
      c || (c = Zq(a, b, "h", -1));
      return c;
    };
  tr.prototype.ld = function () {
    if (yr(this))
      return new sr("ima.common.triggerExternalActivityEvent", this.A);
    var a = Ar(this);
    return null != a ? new qr(a) : null;
  };
  var Ar = function (a) {
    O();
    switch (er(a)) {
      case "b":
        return "ytads.bulleit.triggerExternalActivityEvent";
      case "n":
        return "ima.bridge.triggerExternalActivityEvent";
      case "h":
      case "m":
      case "ml":
        return "ima.common.triggerExternalActivityEvent";
    }
    return null;
  };
  tr.prototype.Jd = function (a) {
    !a.g &&
      a.Ra &&
      fr(this, a, "overlay_unmeasurable_impression") &&
      (a.g = !0);
  };
  tr.prototype.Ee = function (a) {
    a.Ke &&
      (a.Ta()
        ? fr(this, a, "overlay_viewable_end_of_session_impression")
        : fr(this, a, "overlay_unviewable_impression"),
      (a.Ke = !1));
  };
  var Br = function (a, b, c, d) {
    c = void 0 === c ? {} : c;
    var e = {};
    dh(e, { opt_adElement: void 0, opt_fullscreen: void 0 }, c);
    var f = a.I(b, c);
    c = f ? f.Fd : a.kd();
    if (e.opt_bounds) return c.g(uq("ol", d));
    if (void 0 !== d)
      if (void 0 !== tq(d))
        if (nq) a = uq("ue", d);
        else if ((cr(a), "i" == mq)) (a = uq("i", d)), (a["if"] = 0);
        else if ((b = a.I(b, e))) {
          b: {
            "i" == mq && ((b.Ra = !0), a.Nd(b));
            f = e.opt_fullscreen;
            void 0 !== f && po(b, !!f);
            var g;
            if ((f = !gn().j && !bn())) Ql(), (f = 0 === Vi(rl));
            if ((g = f)) {
              switch (b.ya()) {
                case 1:
                  gr(b, "pv");
                  break;
                case 2:
                  a.Jd(b);
              }
              dr("pv");
            }
            f = d.toLowerCase();
            if ((g = !g))
              c: {
                if (ml(O().R, "ssmol") && ((g = a.l), "loaded" === f)) break c;
                g = Xb(zm, f);
              }
            if (g && 0 == b.la) {
              "i" != mq && (dq.done = !1);
              g = void 0 !== e ? e.opt_nativeTime : void 0;
              sm = g = "number" === typeof g ? g : um();
              b.Pb = !0;
              var h = hn();
              b.la = 1;
              b.ia = {};
              b.ia.start = !1;
              b.ia.firstquartile = !1;
              b.ia.midpoint = !1;
              b.ia.thirdquartile = !1;
              b.ia.complete = !1;
              b.ia.resume = !1;
              b.ia.pause = !1;
              b.ia.skip = !1;
              b.ia.mute = !1;
              b.ia.unmute = !1;
              b.ia.viewable_impression = !1;
              b.ia.measurable_impression = !1;
              b.ia.fully_viewable_audible_half_duration_impression = !1;
              b.ia.fullscreen = !1;
              b.ia.exitfullscreen = !1;
              b.md = 0;
              h || (b.qa().I = g);
              gq(dq, [b], !h);
            }
            (g = b.yb[f]) && b.ha.reportEvent(g);
            ml(O().R, "fmd") || (Xb(Am, f) && b.Va && b.Va.j(b, null));
            switch (b.ya()) {
              case 1:
                var k = vq(f) ? a.L.custom_metric_viewable : a.L[f];
                break;
              case 2:
                k = a.U[f];
            }
            if (
              k &&
              ((d = k.call(a, b, e, d)),
              ml(O().R, "fmd") && Xb(Am, f) && b.Va && b.Va.j(b, null),
              void 0 !== d)
            ) {
              e = uq(void 0, f);
              dh(e, d);
              d = e;
              break b;
            }
            d = void 0;
          }
          3 == b.la && a.o(b);
          a = d;
        } else a = uq("nf", d);
      else a = void 0;
    else
      nq
        ? (a = uq("ue"))
        : f
        ? ((a = uq()), dh(a, sp(f, !0, !1, !1)))
        : (a = uq("nf"));
    return "string" === typeof a ? c.g() : c.g(a);
  };
  tr.prototype.J = function (a) {
    this.l && 1 == a.ya() && Cr(this, a);
  };
  tr.prototype.Nd = function (a) {
    this.l && 1 == a.ya() && Cr(this, a);
  };
  var Cr = function (a, b) {
      var c;
      if (b.lb && yr(a)) {
        var d = a.A[b.lb];
        d
          ? (c = function (f, g) {
              Dr(d, f, g);
            })
          : null !== d && nm(379, Error());
      } else c = Na("ima.common.triggerViewabilityMeasurementUpdate");
      if ("function" === typeof c) {
        var e = np(b);
        e.nativeVolume = a.F;
        c(b.ma, e);
      }
    },
    yr = function (a) {
      return (O(), "h" != er(a) && "m" != er(a)) ? !1 : 0 != a.H;
    };
  tr.prototype.B = function (a, b, c, d) {
    if ($l()) {
      var e = ml(O().R, "mm"),
        f = {};
      (e = ((f[Wk.Ve] = "ACTIVE_VIEW_TRAFFIC_TYPE_AUDIO"),
      (f[Wk.VIDEO] = "ACTIVE_VIEW_TRAFFIC_TYPE_VIDEO"),
      f)[e]) &&
        e &&
        (this.C = e);
      "ACTIVE_VIEW_TRAFFIC_TYPE_UNSPECIFIED" === this.C && nm(1044, Error());
    }
    a = Yq.prototype.B.call(this, a, b, c, d);
    this.N &&
      ((b = this.G),
      null == a.A && (a.A = new xo()),
      (b.g[a.ma] = a.A),
      (a.A.o = wp));
    return a;
  };
  tr.prototype.o = function (a) {
    a && 1 == a.ya() && this.N && delete this.G.g[a.ma];
    return Yq.prototype.o.call(this, a);
  };
  tr.prototype.me = function () {
    this.g || (this.g = this.ld());
    return null == this.g || this.l
      ? new Yo()
      : "ACTIVE_VIEW_TRAFFIC_TYPE_AUDIO" === this.C
      ? new or(this.g)
      : new Hq(this.g);
  };
  tr.prototype.kd = function () {
    return "ACTIVE_VIEW_TRAFFIC_TYPE_AUDIO" === this.C ? new pr() : new Cq();
  };
  var Er = function (a) {
      var b = {};
      return (b.viewability = a.g), (b.googleViewability = a.j), b;
    },
    Fr = function (a, b, c) {
      c = void 0 === c ? {} : c;
      a = Br(I(tr), b, c, a);
      return Er(a);
    },
    Gr = mm(193, Fr, void 0, ir);
  z("Goog_AdSense_Lidar_sendVastEvent", Gr);
  var Hr = mm(194, function (a, b) {
    b = void 0 === b ? {} : b;
    a = Br(I(tr), a, b);
    return Er(a);
  });
  z("Goog_AdSense_Lidar_getViewability", Hr);
  var Ir = mm(195, function () {
    return Sl();
  });
  z("Goog_AdSense_Lidar_getUrlSignalsArray", Ir);
  var Jr = mm(196, function () {
    return JSON.stringify(Sl());
  });
  z("Goog_AdSense_Lidar_getUrlSignalsList", Jr);
  x.console &&
    "function" === typeof x.console.log &&
    Za(x.console.log, x.console);
  var Kr = function (a) {
    for (var b = [], c = (a = G(a.ownerDocument)); c != a.top; c = c.parent)
      if (c.frameElement) b.push(c.frameElement);
      else break;
    return b;
  };
  var Lr = function (a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = this.j = !1;
  };
  Lr.prototype.stopPropagation = function () {
    this.j = !0;
  };
  Lr.prototype.preventDefault = function () {
    this.defaultPrevented = !0;
  };
  var Mr = (function () {
    if (!x.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
      b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
    try {
      var c = function () {};
      x.addEventListener("test", c, b);
      x.removeEventListener("test", c, b);
    } catch (d) {}
    return a;
  })();
  var Nr = function (a, b) {
    Lr.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.g = null;
    a && this.init(a, b);
  };
  bb(Nr, Lr);
  var Or = { 2: "touch", 3: "pen", 4: "mouse" };
  Nr.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    (b = a.relatedTarget)
      ? nc && (hc(b, "nodeName") || (b = null))
      : "mouseover" == c
      ? (b = a.fromElement)
      : "mouseout" == c && (b = a.toElement);
    this.relatedTarget = b;
    d
      ? ((this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX),
        (this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX),
        (this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType =
      "string" === typeof a.pointerType
        ? a.pointerType
        : Or[a.pointerType] || "";
    this.state = a.state;
    this.g = a;
    a.defaultPrevented && Nr.Fa.preventDefault.call(this);
  };
  Nr.prototype.stopPropagation = function () {
    Nr.Fa.stopPropagation.call(this);
    this.g.stopPropagation
      ? this.g.stopPropagation()
      : (this.g.cancelBubble = !0);
  };
  Nr.prototype.preventDefault = function () {
    Nr.Fa.preventDefault.call(this);
    var a = this.g;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var Pr = "closure_listenable_" + ((1e6 * Math.random()) | 0),
    Qr = function (a) {
      return !(!a || !a[Pr]);
    };
  var Rr = 0;
  var Sr = function (a, b, c, d, e) {
      this.listener = a;
      this.proxy = null;
      this.src = b;
      this.type = c;
      this.capture = !!d;
      this.Bc = e;
      this.key = ++Rr;
      this.ac = this.qc = !1;
    },
    Tr = function (a) {
      a.ac = !0;
      a.listener = null;
      a.proxy = null;
      a.src = null;
      a.Bc = null;
    };
  var Ur = function (a) {
    this.src = a;
    this.g = {};
    this.j = 0;
  };
  Ur.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.g[f];
    a || ((a = this.g[f] = []), this.j++);
    var g = Vr(a, b, d, e);
    -1 < g
      ? ((b = a[g]), c || (b.qc = !1))
      : ((b = new Sr(b, this.src, f, !!d, e)), (b.qc = c), a.push(b));
    return b;
  };
  Ur.prototype.remove = function (a, b, c, d) {
    a = a.toString();
    if (!(a in this.g)) return !1;
    var e = this.g[a];
    b = Vr(e, b, c, d);
    return -1 < b
      ? (Tr(e[b]), Zb(e, b), 0 == e.length && (delete this.g[a], this.j--), !0)
      : !1;
  };
  var Wr = function (a, b) {
    var c = b.type;
    c in a.g &&
      Yb(a.g[c], b) &&
      (Tr(b), 0 == a.g[c].length && (delete a.g[c], a.j--));
  };
  Ur.prototype.Rb = function (a, b, c, d) {
    a = this.g[a.toString()];
    var e = -1;
    a && (e = Vr(a, b, c, d));
    return -1 < e ? a[e] : null;
  };
  var Vr = function (a, b, c, d) {
    for (var e = 0; e < a.length; ++e) {
      var f = a[e];
      if (!f.ac && f.listener == b && f.capture == !!c && f.Bc == d) return e;
    }
    return -1;
  };
  var Xr = "closure_lm_" + ((1e6 * Math.random()) | 0),
    Yr = {},
    Zr = 0,
    as = function (a, b, c, d, e) {
      if (d && d.once) return $r(a, b, c, d, e);
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) as(a, b[f], c, d, e);
        return null;
      }
      c = bs(c);
      return Qr(a)
        ? a.O(b, c, Ra(d) ? !!d.capture : !!d, e)
        : cs(a, b, c, !1, d, e);
    },
    cs = function (a, b, c, d, e, f) {
      if (!b) throw Error("Invalid event type");
      var g = Ra(e) ? !!e.capture : !!e,
        h = ds(a);
      h || (a[Xr] = h = new Ur(a));
      c = h.add(b, c, d, g, f);
      if (c.proxy) return c;
      d = es();
      c.proxy = d;
      d.src = a;
      d.listener = c;
      if (a.addEventListener)
        Mr || (e = g),
          void 0 === e && (e = !1),
          a.addEventListener(b.toString(), d, e);
      else if (a.attachEvent) a.attachEvent(fs(b.toString()), d);
      else if (a.addListener && a.removeListener) a.addListener(d);
      else throw Error("addEventListener and attachEvent are unavailable.");
      Zr++;
      return c;
    },
    es = function () {
      var a = gs,
        b = function (c) {
          return a.call(b.src, b.listener, c);
        };
      return b;
    },
    $r = function (a, b, c, d, e) {
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) $r(a, b[f], c, d, e);
        return null;
      }
      c = bs(c);
      return Qr(a)
        ? a.Xb(b, c, Ra(d) ? !!d.capture : !!d, e)
        : cs(a, b, c, !0, d, e);
    },
    hs = function (a, b, c, d, e) {
      if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) hs(a, b[f], c, d, e);
      else
        (d = Ra(d) ? !!d.capture : !!d),
          (c = bs(c)),
          Qr(a)
            ? a.ob(b, c, d, e)
            : a && (a = ds(a)) && (b = a.Rb(b, c, d, e)) && is(b);
    },
    is = function (a) {
      if ("number" !== typeof a && a && !a.ac) {
        var b = a.src;
        if (Qr(b)) Wr(b.A, a);
        else {
          var c = a.type,
            d = a.proxy;
          b.removeEventListener
            ? b.removeEventListener(c, d, a.capture)
            : b.detachEvent
            ? b.detachEvent(fs(c), d)
            : b.addListener && b.removeListener && b.removeListener(d);
          Zr--;
          (c = ds(b))
            ? (Wr(c, a), 0 == c.j && ((c.src = null), (b[Xr] = null)))
            : Tr(a);
        }
      }
    },
    fs = function (a) {
      return a in Yr ? Yr[a] : (Yr[a] = "on" + a);
    },
    gs = function (a, b) {
      if (a.ac) a = !0;
      else {
        b = new Nr(b, this);
        var c = a.listener,
          d = a.Bc || a.src;
        a.qc && is(a);
        a = c.call(d, b);
      }
      return a;
    },
    ds = function (a) {
      a = a[Xr];
      return a instanceof Ur ? a : null;
    },
    js = "__closure_events_fn_" + ((1e9 * Math.random()) >>> 0),
    bs = function (a) {
      if ("function" === typeof a) return a;
      a[js] ||
        (a[js] = function (b) {
          return a.handleEvent(b);
        });
      return a[js];
    };
  var S = function () {
    Q.call(this);
    this.A = new Ur(this);
    this.Ab = this;
    this.fa = null;
  };
  bb(S, Q);
  S.prototype[Pr] = !0;
  l = S.prototype;
  l.addEventListener = function (a, b, c, d) {
    as(this, a, b, c, d);
  };
  l.removeEventListener = function (a, b, c, d) {
    hs(this, a, b, c, d);
  };
  l.dispatchEvent = function (a) {
    var b,
      c = this.fa;
    if (c) for (b = []; c; c = c.fa) b.push(c);
    c = this.Ab;
    var d = a.type || a;
    if ("string" === typeof a) a = new Lr(a, c);
    else if (a instanceof Lr) a.target = a.target || c;
    else {
      var e = a;
      a = new Lr(d, c);
      dh(a, e);
    }
    e = !0;
    if (b)
      for (var f = b.length - 1; !a.j && 0 <= f; f--) {
        var g = (a.currentTarget = b[f]);
        e = ks(g, d, !0, a) && e;
      }
    a.j ||
      ((g = a.currentTarget = c),
      (e = ks(g, d, !0, a) && e),
      a.j || (e = ks(g, d, !1, a) && e));
    if (b)
      for (f = 0; !a.j && f < b.length; f++)
        (g = a.currentTarget = b[f]), (e = ks(g, d, !1, a) && e);
    return e;
  };
  l.M = function () {
    S.Fa.M.call(this);
    if (this.A) {
      var a = this.A,
        b = 0,
        c;
      for (c in a.g) {
        for (var d = a.g[c], e = 0; e < d.length; e++) ++b, Tr(d[e]);
        delete a.g[c];
        a.j--;
      }
    }
    this.fa = null;
  };
  l.O = function (a, b, c, d) {
    return this.A.add(String(a), b, !1, c, d);
  };
  l.Xb = function (a, b, c, d) {
    return this.A.add(String(a), b, !0, c, d);
  };
  l.ob = function (a, b, c, d) {
    this.A.remove(String(a), b, c, d);
  };
  var ks = function (a, b, c, d) {
    b = a.A.g[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
      var g = b[f];
      if (g && !g.ac && g.capture == c) {
        var h = g.listener,
          k = g.Bc || g.src;
        g.qc && Wr(a.A, g);
        e = !1 !== h.call(k, d) && e;
      }
    }
    return e && !d.defaultPrevented;
  };
  S.prototype.Rb = function (a, b, c, d) {
    return this.A.Rb(String(a), b, c, d);
  };
  var ls = function (a, b) {
    this.l = a;
    this.A = b;
    this.j = 0;
    this.g = null;
  };
  ls.prototype.get = function () {
    if (0 < this.j) {
      this.j--;
      var a = this.g;
      this.g = a.next;
      a.next = null;
    } else a = this.l();
    return a;
  };
  var ms = function (a, b) {
    a.A(b);
    100 > a.j && (a.j++, (b.next = a.g), (a.g = b));
  };
  var ns,
    os = function () {
      var a = x.MessageChannel;
      "undefined" === typeof a &&
        "undefined" !== typeof window &&
        window.postMessage &&
        window.addEventListener &&
        !A("Presto") &&
        (a = function () {
          var e = Yh(document, "IFRAME");
          e.style.display = "none";
          document.documentElement.appendChild(e);
          var f = e.contentWindow;
          e = f.document;
          e.open();
          e.close();
          var g = "callImmediate" + Math.random(),
            h =
              "file:" == f.location.protocol
                ? "*"
                : f.location.protocol + "//" + f.location.host;
          e = Za(function (k) {
            if (("*" == h || k.origin == h) && k.data == g)
              this.port1.onmessage();
          }, this);
          f.addEventListener("message", e, !1);
          this.port1 = {};
          this.port2 = {
            postMessage: function () {
              f.postMessage(g, h);
            },
          };
        });
      if ("undefined" !== typeof a) {
        var b = new a(),
          c = {},
          d = c;
        b.port1.onmessage = function () {
          if (void 0 !== c.next) {
            c = c.next;
            var e = c.ke;
            c.ke = null;
            e();
          }
        };
        return function (e) {
          d.next = { ke: e };
          d = d.next;
          b.port2.postMessage(0);
        };
      }
      return function (e) {
        x.setTimeout(e, 0);
      };
    };
  var ps = function () {
    this.j = this.g = null;
  };
  ps.prototype.add = function (a, b) {
    var c = qs.get();
    c.set(a, b);
    this.j ? (this.j.next = c) : (this.g = c);
    this.j = c;
  };
  ps.prototype.remove = function () {
    var a = null;
    this.g &&
      ((a = this.g),
      (this.g = this.g.next),
      this.g || (this.j = null),
      (a.next = null));
    return a;
  };
  var qs = new ls(
      function () {
        return new rs();
      },
      function (a) {
        return a.reset();
      }
    ),
    rs = function () {
      this.next = this.g = this.j = null;
    };
  rs.prototype.set = function (a, b) {
    this.j = a;
    this.g = b;
    this.next = null;
  };
  rs.prototype.reset = function () {
    this.next = this.g = this.j = null;
  };
  var ts,
    us = !1,
    vs = new ps(),
    xs = function (a, b) {
      ts || ws();
      us || (ts(), (us = !0));
      vs.add(a, b);
    },
    ws = function () {
      if (x.Promise && x.Promise.resolve) {
        var a = x.Promise.resolve(void 0);
        ts = function () {
          a.then(ys);
        };
      } else
        ts = function () {
          var b = ys;
          "function" !== typeof x.setImmediate ||
          (x.Window &&
            x.Window.prototype &&
            x.Window.prototype.setImmediate == x.setImmediate)
            ? (ns || (ns = os()), ns(b))
            : x.setImmediate(b);
        };
    },
    ys = function () {
      for (var a; (a = vs.remove()); ) {
        try {
          a.j.call(a.g);
        } catch (b) {
          kb(b);
        }
        ms(qs, a);
      }
      us = !1;
    };
  var zs = function (a) {
    if (!a) return !1;
    try {
      return !!a.$goog_Thenable;
    } catch (b) {
      return !1;
    }
  };
  var Bs = function (a) {
      this.g = 0;
      this.C = void 0;
      this.A = this.j = this.l = null;
      this.o = this.B = !1;
      if (a != Hg)
        try {
          var b = this;
          a.call(
            void 0,
            function (c) {
              As(b, 2, c);
            },
            function (c) {
              As(b, 3, c);
            }
          );
        } catch (c) {
          As(this, 3, c);
        }
    },
    Cs = function () {
      this.next = this.context = this.j = this.l = this.g = null;
      this.A = !1;
    };
  Cs.prototype.reset = function () {
    this.context = this.j = this.l = this.g = null;
    this.A = !1;
  };
  var Ds = new ls(
      function () {
        return new Cs();
      },
      function (a) {
        a.reset();
      }
    ),
    Es = function (a, b, c) {
      var d = Ds.get();
      d.l = a;
      d.j = b;
      d.context = c;
      return d;
    };
  Bs.prototype.then = function (a, b, c) {
    return Fs(
      this,
      "function" === typeof a ? a : null,
      "function" === typeof b ? b : null,
      c
    );
  };
  Bs.prototype.$goog_Thenable = !0;
  Bs.prototype.I = function (a, b) {
    return Fs(this, null, a, b);
  };
  Bs.prototype.catch = Bs.prototype.I;
  Bs.prototype.cancel = function (a) {
    if (0 == this.g) {
      var b = new Gs(a);
      xs(function () {
        Hs(this, b);
      }, this);
    }
  };
  var Hs = function (a, b) {
      if (0 == a.g)
        if (a.l) {
          var c = a.l;
          if (c.j) {
            for (
              var d = 0, e = null, f = null, g = c.j;
              g && (g.A || (d++, g.g == a && (e = g), !(e && 1 < d)));
              g = g.next
            )
              e || (f = g);
            e &&
              (0 == c.g && 1 == d
                ? Hs(c, b)
                : (f
                    ? ((d = f),
                      d.next == c.A && (c.A = d),
                      (d.next = d.next.next))
                    : Is(c),
                  Js(c, e, 3, b)));
          }
          a.l = null;
        } else As(a, 3, b);
    },
    Ls = function (a, b) {
      a.j || (2 != a.g && 3 != a.g) || Ks(a);
      a.A ? (a.A.next = b) : (a.j = b);
      a.A = b;
    },
    Fs = function (a, b, c, d) {
      var e = Es(null, null, null);
      e.g = new Bs(function (f, g) {
        e.l = b
          ? function (h) {
              try {
                var k = b.call(d, h);
                f(k);
              } catch (n) {
                g(n);
              }
            }
          : f;
        e.j = c
          ? function (h) {
              try {
                var k = c.call(d, h);
                void 0 === k && h instanceof Gs ? g(h) : f(k);
              } catch (n) {
                g(n);
              }
            }
          : g;
      });
      e.g.l = a;
      Ls(a, e);
      return e.g;
    };
  Bs.prototype.F = function (a) {
    this.g = 0;
    As(this, 2, a);
  };
  Bs.prototype.G = function (a) {
    this.g = 0;
    As(this, 3, a);
  };
  var As = function (a, b, c) {
      if (0 == a.g) {
        a === c &&
          ((b = 3), (c = new TypeError("Promise cannot resolve to itself")));
        a.g = 1;
        a: {
          var d = c,
            e = a.F,
            f = a.G;
          if (d instanceof Bs) {
            Ls(d, Es(e || Hg, f || null, a));
            var g = !0;
          } else if (zs(d)) d.then(e, f, a), (g = !0);
          else {
            if (Ra(d))
              try {
                var h = d.then;
                if ("function" === typeof h) {
                  Ms(d, h, e, f, a);
                  g = !0;
                  break a;
                }
              } catch (k) {
                f.call(a, k);
                g = !0;
                break a;
              }
            g = !1;
          }
        }
        g ||
          ((a.C = c),
          (a.g = b),
          (a.l = null),
          Ks(a),
          3 != b || c instanceof Gs || Ns(a, c));
      }
    },
    Ms = function (a, b, c, d, e) {
      var f = !1,
        g = function (k) {
          f || ((f = !0), c.call(e, k));
        },
        h = function (k) {
          f || ((f = !0), d.call(e, k));
        };
      try {
        b.call(a, g, h);
      } catch (k) {
        h(k);
      }
    },
    Ks = function (a) {
      a.B || ((a.B = !0), xs(a.N, a));
    },
    Is = function (a) {
      var b = null;
      a.j && ((b = a.j), (a.j = b.next), (b.next = null));
      a.j || (a.A = null);
      return b;
    };
  Bs.prototype.N = function () {
    for (var a; (a = Is(this)); ) Js(this, a, this.g, this.C);
    this.B = !1;
  };
  var Js = function (a, b, c, d) {
      if (3 == c && b.j && !b.A) for (; a && a.o; a = a.l) a.o = !1;
      if (b.g) (b.g.l = null), Os(b, c, d);
      else
        try {
          b.A ? b.l.call(b.context) : Os(b, c, d);
        } catch (e) {
          Ps.call(null, e);
        }
      ms(Ds, b);
    },
    Os = function (a, b, c) {
      2 == b ? a.l.call(a.context, c) : a.j && a.j.call(a.context, c);
    },
    Ns = function (a, b) {
      a.o = !0;
      xs(function () {
        a.o && Ps.call(null, b);
      });
    },
    Ps = kb,
    Gs = function (a) {
      db.call(this, a);
    };
  bb(Gs, db);
  Gs.prototype.name = "cancel";
  var Qs = function (a, b) {
    S.call(this);
    this.j = a || 1;
    this.g = b || x;
    this.l = Za(this.Gg, this);
    this.o = Date.now();
  };
  bb(Qs, S);
  l = Qs.prototype;
  l.enabled = !1;
  l.Na = null;
  l.Gg = function () {
    if (this.enabled) {
      var a = Date.now() - this.o;
      0 < a && a < 0.8 * this.j
        ? (this.Na = this.g.setTimeout(this.l, this.j - a))
        : (this.Na && (this.g.clearTimeout(this.Na), (this.Na = null)),
          this.dispatchEvent("tick"),
          this.enabled && (this.stop(), this.start()));
    }
  };
  l.start = function () {
    this.enabled = !0;
    this.Na ||
      ((this.Na = this.g.setTimeout(this.l, this.j)), (this.o = Date.now()));
  };
  l.stop = function () {
    this.enabled = !1;
    this.Na && (this.g.clearTimeout(this.Na), (this.Na = null));
  };
  l.M = function () {
    Qs.Fa.M.call(this);
    this.stop();
    delete this.g;
  };
  var Rs = function (a, b, c) {
      if ("function" === typeof a) c && (a = Za(a, c));
      else if (a && "function" == typeof a.handleEvent)
        a = Za(a.handleEvent, a);
      else throw Error("Invalid listener argument");
      return 2147483647 < Number(b) ? -1 : x.setTimeout(a, b || 0);
    },
    Ss = function (a, b) {
      var c = null;
      return new Bs(function (d, e) {
        c = Rs(function () {
          d(b);
        }, a);
        -1 == c && e(Error("Failed to schedule timer."));
      }).I(function (d) {
        x.clearTimeout(c);
        throw d;
      });
    };
  var Ts = function () {
    return Math.round(Date.now() / 1e3);
  };
  var Us = function () {
    this.g = {};
    return this;
  };
  Us.prototype.remove = function (a) {
    var b = this.g;
    a in b && delete b[a];
  };
  Us.prototype.set = function (a, b) {
    this.g[a] = b;
  };
  var Vs = function (a, b) {
    a.g.eb = bh(a.g, "eb", 0) | b;
  };
  Us.prototype.get = function (a) {
    return bh(this.g, a, null);
  };
  var Ws = null,
    Xs = function () {
      this.g = {};
      this.j = 0;
    },
    Ys = function () {
      Ws || (Ws = new Xs());
      return Ws;
    },
    Zs = function (a, b) {
      a.g[b.getName()] = b;
    },
    $s = function (a, b) {
      this.A = a;
      this.l = !0;
      this.g = b;
    };
  $s.prototype.getName = function () {
    return this.A;
  };
  $s.prototype.getValue = function () {
    return this.g;
  };
  $s.prototype.j = function () {
    return String(this.g);
  };
  var at = function (a, b) {
    $s.call(this, String(a), b);
    this.o = a;
    this.g = !!b;
  };
  v(at, $s);
  at.prototype.j = function () {
    return this.g ? "1" : "0";
  };
  var bt = function (a, b) {
    $s.call(this, a, b);
  };
  v(bt, $s);
  bt.prototype.j = function () {
    return this.g
      ? Math.round(this.g.top) +
          "." +
          Math.round(this.g.left) +
          "." +
          (Math.round(this.g.top) + Math.round(this.g.height)) +
          "." +
          (Math.round(this.g.left) + Math.round(this.g.width))
      : "";
  };
  var ct = function (a) {
    if (a.match(/^-?[0-9]+\.-?[0-9]+\.-?[0-9]+\.-?[0-9]+$/)) {
      a = a.split(".");
      var b = Number(a[0]),
        c = Number(a[1]);
      return new bt("", new Ci(c, b, Number(a[3]) - c, Number(a[2]) - b));
    }
    return new bt("", new Ci(0, 0, 0, 0));
  };
  var dt = function (a) {
      var b = new Ci(
          -Number.MAX_VALUE / 2,
          -Number.MAX_VALUE / 2,
          Number.MAX_VALUE,
          Number.MAX_VALUE
        ),
        c = new Ci(0, 0, 0, 0);
      if (!a || 0 == a.length) return c;
      for (var d = 0; d < a.length; d++) {
        a: {
          var e = b;
          var f = a[d],
            g = Math.max(e.left, f.left),
            h = Math.min(e.left + e.width, f.left + f.width);
          if (g <= h) {
            var k = Math.max(e.top, f.top);
            f = Math.min(e.top + e.height, f.top + f.height);
            if (k <= f) {
              e.left = g;
              e.top = k;
              e.width = h - g;
              e.height = f - k;
              e = !0;
              break a;
            }
          }
          e = !1;
        }
        if (!e) return c;
      }
      return b;
    },
    et = function (a, b) {
      var c = a.getBoundingClientRect();
      a = Nm(a, b);
      return new Ci(
        Math.round(a.x),
        Math.round(a.y),
        Math.round(c.right - c.left),
        Math.round(c.bottom - c.top)
      );
    },
    ft = function (a, b, c) {
      if (b && c) {
        a: {
          var d = Math.max(b.left, c.left);
          var e = Math.min(b.left + b.width, c.left + c.width);
          if (d <= e) {
            var f = Math.max(b.top, c.top),
              g = Math.min(b.top + b.height, c.top + c.height);
            if (f <= g) {
              d = new Ci(d, f, e - d, g - f);
              break a;
            }
          }
          d = null;
        }
        e = d ? d.height * d.width : 0;
        f = d ? b.height * b.width : 0;
        d = d && f ? Math.round((e / f) * 100) : 0;
        Zs(a, new $s("vp", d));
        d && 0 < d
          ? ((e = Di(b)), (f = Di(c)), (e = e.top >= f.top && e.top < f.bottom))
          : (e = !1);
        Zs(a, new at(512, e));
        d && 0 < d
          ? ((e = Di(b)),
            (f = Di(c)),
            (e = e.bottom <= f.bottom && e.bottom > f.top))
          : (e = !1);
        Zs(a, new at(1024, e));
        d && 0 < d
          ? ((e = Di(b)),
            (f = Di(c)),
            (e = e.left >= f.left && e.left < f.right))
          : (e = !1);
        Zs(a, new at(2048, e));
        d && 0 < d
          ? ((b = Di(b)),
            (c = Di(c)),
            (c = b.right <= c.right && b.right > c.left))
          : (c = !1);
        Zs(a, new at(4096, c));
      }
    };
  var gt = function (a, b) {
    var c = 0;
    Vg(G(), "ima", "video", "client", "tagged") && (c = 1);
    var d = null;
    a && (d = a());
    if (d) {
      a = Ys();
      a.g = {};
      var e = new at(32, !0);
      e.l = !1;
      Zs(a, e);
      e = G().document;
      e =
        e.visibilityState ||
        e.webkitVisibilityState ||
        e.mozVisibilityState ||
        e.msVisibilityState ||
        "";
      Zs(
        a,
        new at(
          64,
          "hidden" != e.toLowerCase().substring(e.length - 6) ? !0 : !1
        )
      );
      try {
        var f = G().top;
        try {
          var g = !!f.location.href || "" === f.location.href;
        } catch (m) {
          g = !1;
        }
        if (g) {
          var h = Kr(d);
          var k = h && 0 != h.length ? "1" : "0";
        } else k = "2";
      } catch (m) {
        k = "2";
      }
      Zs(a, new at(256, "2" == k));
      Zs(a, new at(128, "1" == k));
      h = g = G().top;
      "2" == k && (h = G());
      f = et(d, h);
      Zs(a, new bt("er", f));
      try {
        var n = h.document && !h.document.body ? null : Wh(h || window);
      } catch (m) {
        n = null;
      }
      n
        ? ((h = Xh(Sh(h.document).g)),
          Zs(a, new at(16384, !!h)),
          (n = h ? new Ci(h.x, h.y, n.width, n.height) : null))
        : (n = null);
      Zs(a, new bt("vi", n));
      if (n && "1" == k) {
        k = Kr(d);
        d = [];
        for (h = 0; h < k.length; h++) (e = et(k[h], g)) && d.push(e);
        d.push(n);
        n = dt(d);
      }
      ft(a, f, n);
      a.j && Zs(a, new $s("ts", Ts() - a.j));
      a.j = Ts();
    } else (a = Ys()), (a.g = {}), (a.j = Ts()), Zs(a, new at(32, !1));
    this.l = a;
    this.g = new Us();
    this.g.set("ve", 4);
    c && Vs(this.g, 1);
    Vg(G(), "ima", "video", "client", "crossdomainTag") && Vs(this.g, 4);
    Vg(G(), "ima", "video", "client", "sdkTag") && Vs(this.g, 8);
    Vg(G(), "ima", "video", "client", "jsTag") && Vs(this.g, 2);
    b && bh(b, "fullscreen", !1) && Vs(this.g, 16);
    this.j = b = null;
    if (c && ((c = Vg(G(), "ima", "video", "client")), c.getEData)) {
      this.j = c.getEData();
      if ((c = Vg(G(), "ima", "video", "client", "getLastSnapshotFromTop")))
        if ((a = c()))
          this.j.extendWithDataFromTopIframe(
            a.tagstamp,
            a.playstamp,
            a.lactstamp
          ),
            (c = this.l),
            (b = a.er),
            (a = a.vi),
            b &&
              a &&
              ((b = ct(b).getValue()),
              (a = ct(a).getValue()),
              (k = null),
              bh(c.g, "er", null) &&
                ((k = bh(c.g, "er", null).getValue()),
                (k.top += b.top),
                (k.left += b.left),
                Zs(c, new bt("er", k))),
              bh(c.g, "vi", null) &&
                ((n = bh(c.g, "vi", null).getValue()),
                (n.top += b.top),
                (n.left += b.left),
                (d = []),
                d.push(n),
                d.push(b),
                d.push(a),
                (b = dt(d)),
                ft(c, k, b),
                Zs(c, new bt("vi", a))));
      a: {
        if (this.j) {
          if (this.j.getTagLoadTimestamp) {
            b = this.j.getTagLoadTimestamp();
            break a;
          }
          if (this.j.getTimeSinceTagLoadSeconds) {
            b = this.j.getTimeSinceTagLoadSeconds();
            break a;
          }
        }
        b = null;
      }
    }
    c = this.g;
    a =
      window.performance &&
      window.performance.timing &&
      window.performance.timing.domLoading &&
      0 < window.performance.timing.domLoading
        ? Math.round(window.performance.timing.domLoading / 1e3)
        : null;
    c.set.call(c, "td", Ts() - (null != a ? a : null != b ? b : Ts()));
  };
  new Qs(200);
  var ht = function (a, b) {
    try {
      var c = new gt(a, b);
      a = [];
      var d = Number(c.g.get("eb"));
      c.g.remove("eb");
      var e,
        f = c.g;
      b = [];
      for (var g in f.g) b.push(g + f.g[g]);
      (e = b.join("_")) && a.push(e);
      if (c.j) {
        var h = c.j.serialize();
        h && a.push(h);
      }
      var k,
        n = c.l;
      e = d;
      f = [];
      e || (e = 0);
      for (var m in n.g) {
        var r = n.g[m];
        if (r instanceof at) r.getValue() && (e |= r.o);
        else {
          var p = n.g[m],
            t = p.l ? p.j() : "";
          t && f.push(m + t);
        }
      }
      f.push("eb" + String(e));
      (k = f.join("_")) && a.push(k);
      c.g.set("eb", d);
      return a.join("_");
    } catch (w) {
      return "tle;" + Ih(w.name, 12) + ";" + Ih(w.message, 40);
    }
  };
  var it = function (a) {
    this.K = B(a);
  };
  v(it, F);
  it.prototype.getId = function () {
    return E(this, 1);
  };
  var jt = [0, ug];
  var kt = function (a) {
    this.K = B(a);
  };
  v(kt, F);
  kt.prototype.getWidth = function () {
    return Ef(this, 1);
  };
  kt.prototype.getHeight = function () {
    return Ef(this, 2);
  };
  var lt = [0, qg, -1];
  var mt = function (a) {
    this.K = B(a);
  };
  v(mt, F);
  var nt = [0, mg, sg, ug, -1];
  var ot = function (a) {
    this.K = B(a);
  };
  v(ot, F);
  ot.prototype.getAdId = function () {
    return E(this, 1);
  };
  ot.prototype.getSize = function () {
    return tf(this, kt, 7);
  };
  ot.prototype.Sb = function () {
    return tf(this, mt, 9);
  };
  ot.na = [4];
  var pt = [0, ug, mg, ug, xg, Ag, jt, lt, mg, nt];
  var qt = function (a) {
    this.K = B(a);
  };
  v(qt, F);
  var rt = function (a, b) {
      return C(a, 1, fe(b));
    },
    tt = function (a, b) {
      return Jf(a, 4, b);
    },
    ut = function (a, b) {
      return C(a, 2, ie(b));
    },
    vt = [0, Ag, qg, ug, sg];
  var wt = function (a) {
    this.K = B(a);
  };
  v(wt, F);
  var xt = function (a, b) {
      return Kf(a, 1, b);
    },
    yt = function (a, b) {
      return zf(a, 3, ot, b);
    },
    zt = function (a, b) {
      return C(a, 4, fe(b));
    };
  wt.na = [10, 3];
  var At = [0, ug, mg, yg, pt, Ag, vt, sg, Ag, 2, xg];
  var Bt = function (a) {
    this.K = B(a);
  };
  v(Bt, F);
  var Ct = [0, Ag, sg, mg];
  var Dt = function (a) {
    this.K = B(a);
  };
  v(Dt, F);
  var Et = function (a, b) {
      return yf(a, 2, wt, b);
    },
    Ft = function (a, b) {
      wf(a, 5, b);
    },
    Gt = function (a, b) {
      Kf(a, 10, b);
    };
  Dt.na = [2];
  var Ht = [0, Ag, yg, At, Ag, ug, vt, ug, sg, qg, Ct, ug, -1];
  var It = function (a) {
    this.K = B(a);
  };
  v(It, F);
  var Jt = function (a) {
    var b = new Dt();
    b = C(b, 1, fe(1));
    return yf(a, 1, Dt, b);
  };
  It.na = [1];
  It.prototype.g = Eg([0, yg, Ht]);
  var Kt = function (a) {
    this.K = B(a);
  };
  v(Kt, F);
  var Lt = function (a) {
    this.K = B(a);
  };
  v(Lt, F);
  var Mt = function (a) {
    this.K = B(a);
  };
  v(Mt, F);
  Mt.na = [1];
  var Nt = function (a) {
    this.K = B(a);
  };
  v(Nt, F);
  var Ot = Fg(Nt);
  Nt.na = [1];
  var Pt = function (a) {
    this.K = B(a);
  };
  v(Pt, F);
  var Qt = function (a) {
      var b = new Pt();
      return C(b, 1, fe(a));
    },
    Rt = [0, Ag];
  var St = function (a) {
    this.K = B(a);
  };
  v(St, F);
  var Tt = function (a) {
      var b = new St();
      return Kf(b, 1, a);
    },
    Ut = function (a) {
      var b = window.Date.now();
      b = Number.isFinite(b) ? Math.round(b) : 0;
      return C(a, 3, le(b));
    };
  St.prototype.getError = function () {
    return tf(this, Pt, 10);
  };
  St.prototype.Ya = function (a) {
    return wf(this, 10, a);
  };
  var Vt = Fg(St),
    Wt = [0, ug, -1, mg, qg, -2, mg, lg, sg, Rt, sg];
  var Xt = [0, 1, [0, pg, -2], -1, ug, -1, sg, [0, 3, Ag, ug], mg, Bg, zg];
  var Yt = function (a) {
    this.K = B(a);
  };
  v(Yt, F);
  Yt.na = [1, 2];
  Yt.prototype.g = Eg([0, yg, Xt, yg, Wt]);
  var au = function () {
    var a = Zt;
    this.o = $t;
    this.B = "jserror";
    this.A = !0;
    this.g = void 0 === a ? null : a;
    this.j = null;
    this.l = !1;
    this.C = this.Ua;
  };
  l = au.prototype;
  l.Wc = function (a) {
    this.j = a;
  };
  l.Od = function (a) {
    this.B = a;
  };
  l.Pd = function (a) {
    this.A = a;
  };
  l.Qd = function (a) {
    this.l = a;
  };
  l.wb = function (a, b, c) {
    try {
      if (this.g && this.g.l) {
        var d = this.g.start(a.toString(), 3);
        var e = b();
        this.g.end(d);
      } else e = b();
    } catch (h) {
      b = this.A;
      try {
        gj(d), (b = this.C(a, new Ri(h, { message: bu(h) }), void 0, c));
      } catch (k) {
        this.Ua(217, k);
      }
      if (b) {
        var f, g;
        null == (f = window.console) || null == (g = f.error) || g.call(f, h);
      } else throw h;
    }
    return e;
  };
  l.Hd = function (a, b, c, d) {
    var e = this;
    return function () {
      var f = Ia.apply(0, arguments);
      return e.wb(
        a,
        function () {
          return b.apply(c, f);
        },
        d
      );
    };
  };
  l.Ua = function (a, b, c, d, e) {
    e = e || this.B;
    try {
      var f = new Dl();
      Il(f, 1, "context", a);
      Si(b) || (b = new Ri(b, { message: bu(b) }));
      b.msg && Il(f, 2, "msg", b.msg.substring(0, 512));
      var g = b.meta || {};
      if (this.j)
        try {
          this.j(g);
        } catch (k) {}
      if (d)
        try {
          d(g);
        } catch (k) {}
      Hl(f, 3, [g]);
      var h = Cl();
      h.j && Il(f, 4, "top", h.j.url || "");
      Hl(f, 5, [{ url: h.g.url || "" }, { url: h.g.url ? ii(h.g.url) : "" }]);
      cu(this.o, e, f, this.l, c);
    } catch (k) {
      try {
        cu(
          this.o,
          e,
          { context: "ecmserr", rctx: a, msg: bu(k), url: h && h.g.url },
          this.l,
          c
        );
      } catch (n) {}
    }
    return this.A;
  };
  var bu = function (a) {
    var b = a.toString();
    a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
    a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
    if (a.stack) {
      a = a.stack;
      var c = b;
      try {
        -1 == a.indexOf(c) && (a = c + "\n" + a);
        for (var d; a != d; )
          (d = a),
            (a = a.replace(
              RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
              "$1"
            ));
        b = a.replace(RegExp("\n *", "g"), "\n");
      } catch (e) {
        b = c;
      }
    }
    return b;
  };
  var du = function (a) {
      this.g = a || { cookie: "" };
    },
    eu = function (a) {
      if (!x.navigator.cookieEnabled) return !1;
      if (!a.isEmpty()) return !0;
      a.set("TESTCOOKIESENABLED", "1", { Ic: 60 });
      if ("1" !== a.get("TESTCOOKIESENABLED")) return !1;
      a.remove("TESTCOOKIESENABLED");
      return !0;
    };
  l = du.prototype;
  l.set = function (a, b, c) {
    var d = !1;
    if ("object" === typeof c) {
      var e = c.Li;
      d = c.Ie || !1;
      var f = c.domain || void 0;
      var g = c.path || void 0;
      var h = c.Ic;
    }
    if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
    if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
    void 0 === h && (h = -1);
    this.g.cookie =
      a +
      "=" +
      b +
      (f ? ";domain=" + f : "") +
      (g ? ";path=" + g : "") +
      (0 > h
        ? ""
        : 0 == h
        ? ";expires=" + new Date(1970, 1, 1).toUTCString()
        : ";expires=" + new Date(Date.now() + 1e3 * h).toUTCString()) +
      (d ? ";secure" : "") +
      (null != e ? ";samesite=" + e : "");
  };
  l.get = function (a, b) {
    for (
      var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f;
      e < d.length;
      e++
    ) {
      f = ob(d[e]);
      if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
      if (f == a) return "";
    }
    return b;
  };
  l.remove = function (a, b, c) {
    var d = void 0 !== this.get(a);
    this.set(a, "", { Ic: 0, path: b, domain: c });
    return d;
  };
  l.zc = function () {
    return fu(this).keys;
  };
  l.Db = function () {
    return fu(this).values;
  };
  l.isEmpty = function () {
    return !this.g.cookie;
  };
  l.clear = function () {
    for (var a = fu(this).keys, b = a.length - 1; 0 <= b; b--)
      this.remove(a[b]);
  };
  var fu = function (a) {
    a = (a.g.cookie || "").split(";");
    for (var b = [], c = [], d, e, f = 0; f < a.length; f++)
      (e = ob(a[f])),
        (d = e.indexOf("=")),
        -1 == d
          ? (b.push(""), c.push(e))
          : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
    return { keys: b, values: c };
  };
  function gu(a) {
    return new du(a.document);
  }
  function hu(a, b, c) {
    return Df(b, 5) ? iu(a, c) : null;
  }
  var ju;
  function ku() {
    var a = new lu().g;
    return ju ? ju : "null" === a.origin ? (ju = !1) : (ju = eu(gu(a)));
  }
  function iu(a, b) {
    b = "null" !== b.origin ? b.document.cookie : null;
    return null === b ? null : new du({ cookie: b }).get(a) || "";
  }
  var mu = function (a) {
    this.K = B(a);
  };
  v(mu, F);
  var nu = Dg([0, Cg, vg]);
  function ou(a, b) {
    var c = new jd();
    try {
      var d = a
        .filter(function (f) {
          return f.wd;
        })
        .map(pu);
      sd(c, 1, d);
      qd(c, 2, nu(b), rd);
      var e = a
        .filter(function (f) {
          return !f.wd;
        })
        .map(pu);
      sd(c, 3, e);
    } catch (f) {
      qu(f, b);
    }
    return od(c);
  }
  function qu(a, b) {
    try {
      Qi(
        {
          m: bu(a instanceof Error ? a : Error(String(a))),
          b: Hf(b, 1) || null,
          v: E(b, 2) || null,
        },
        "rcs_internal"
      );
    } catch (c) {}
  }
  function pu(a) {
    var b = new jd();
    qd(b, a.Pe, a.Je, rd);
    return od(b);
  }
  function rd(a, b) {
    a = a.subarray(0, a.length);
    kd(b, b.g.end());
    kd(b, a);
  }
  var ru = function (a, b) {
    var c = new mu();
    a = D(c, 1, fe(a), 0);
    b = D(a, 2, te(b), "");
    a = b.K;
    c = Ed(a);
    this.g = c & 2 ? b : Ae(b.constructor, af(a, c, !0));
  };
  var tu = function (a) {
    this.K = B(a);
  };
  v(tu, F);
  var uu = [1, 2, 3],
    vu = [0, uu, wg, og, tg];
  var wu = function (a) {
    this.K = B(a);
  };
  v(wu, F);
  var xu = [2, 4],
    yu = [0, xu, 1, og, 1, kg];
  var zu = function (a) {
    this.K = B(a);
  };
  v(zu, F);
  zu.na = [4];
  var Au = Dg([0, vg, 1, yu, yg, vu]);
  var Bu = function (a) {
    this.K = B(a);
  };
  v(Bu, F);
  Bu.prototype.getTagSessionCorrelator = function () {
    return Gf(this, 1);
  };
  var Cu = function (a, b) {
      return D(a, 1, le(b), "0");
    },
    Du = function (a, b) {
      return D(a, 2, le(b), "0");
    },
    Eu = Dg([0, ng, -1]);
  var Fu = function (a) {
    this.K = B(a);
  };
  v(Fu, F);
  var Gu = function (a) {
    this.K = B(a);
  };
  v(Gu, F);
  Gu.prototype.getEscapedQemQueryId = function () {
    return E(this, 4);
  };
  Gu.na = [2, 23, 29];
  var Hu = function (a) {
    this.K = B(a);
  };
  v(Hu, F);
  var Iu = function (a) {
    this.K = B(a);
  };
  v(Iu, F);
  Iu.prototype.getEscapedQemQueryId = function () {
    return E(this, 2);
  };
  Iu.na = [28];
  var Ku = function (a) {
      this.Fg = new Ju(a);
    },
    Ju = function (a) {
      this.Jg = new Lu(a);
    },
    Lu = function (a) {
      this.Ef = new Mu(a);
    },
    Mu = function (a) {
      this.qd = function (b) {
        var c = b.Rd,
          d = b.fd;
        b = b.status;
        var e = new zu();
        e = D(e, 1, te("SOomke"), "");
        var f = new tu();
        d = qf(f, 1, uu, te(d));
        d = zf(e, 4, tu, d);
        e = new tu();
        b = qf(e, 1, uu, te(b));
        b = zf(d, 4, tu, b);
        d = new wu();
        c = qf(d, 2, xu, le(Math.round(c)));
        c = wf(b, 3, c);
        a(c);
      };
    },
    Nu = function () {
      ru.apply(this, arguments);
      var a = this;
      this.kg = new Ku(function (b) {
        return a.B(b);
      });
    };
  v(Nu, ru);
  var Ou = function () {
    Nu.apply(this, arguments);
  };
  v(Ou, Nu);
  Ou.prototype.o = function () {
    this.j.apply(
      this,
      ha(
        Ia.apply(0, arguments).map(function (a) {
          return { wd: !0, Pe: 16, Je: Eu(a) };
        })
      )
    );
  };
  Ou.prototype.B = function () {
    this.j.apply(
      this,
      ha(
        Ia.apply(0, arguments).map(function (a) {
          return { wd: !1, Pe: 1, Je: Au(a) };
        })
      )
    );
  };
  var Pu = function () {};
  var Qu = function () {
      this.g = Math.random();
    },
    Ru = function () {
      var a = $t,
        b = window.google_srt;
      0 <= b && 1 >= b && (a.g = b);
    },
    cu = function (a, b, c, d, e) {
      if (((void 0 === d ? 0 : d) ? a.g : Math.random()) < (e || 0.01))
        try {
          if (c instanceof Dl) var f = c;
          else
            (f = new Dl()),
              si(c, function (h, k) {
                var n = f,
                  m = n.A++;
                Hl(n, m, El(k, h));
              });
          var g = Kl(f, "https:", "/pagead/gen_204?id=" + b + "&");
          g && Oi(x, g);
        } catch (h) {}
    };
  var $t,
    Su,
    Zt = new fj(1, window);
  (function (a) {
    $t = null != a ? a : new Qu();
    "number" !== typeof window.google_srt &&
      (window.google_srt = Math.random());
    Ru();
    Su = new au();
    Su.Wc(function () {});
    Su.Qd(!0);
    "complete" == window.document.readyState
      ? window.google_measure_js_timing || Zt.B()
      : Zt.l &&
        Ng(window, "load", function () {
          window.google_measure_js_timing || Zt.B();
        });
  })();
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  var Tu = function (a) {
    this.K = B(a);
  };
  v(Tu, F);
  Tu.na = [3];
  var Uu = function (a) {
    this.K = B(a);
  };
  v(Uu, F);
  var Vu = function (a, b) {
      return pf(a, 1, b, ee);
    },
    Wu = function (a, b) {
      return pf(a, 2, b, ee);
    },
    Xu = function (a, b) {
      return pf(a, 3, b, he);
    },
    Yu = function (a, b) {
      pf(a, 4, b, he);
    };
  Uu.na = [1, 2, 3, 4];
  var Zu = function (a) {
    this.K = B(a);
  };
  v(Zu, F);
  var $u = function (a) {
    this.K = B(a);
  };
  v($u, F);
  $u.prototype.getVersion = function () {
    return Ef(this, 1);
  };
  var av = function (a, b) {
      return D(a, 1, ie(b), 0);
    },
    bv = function (a, b) {
      return wf(a, 2, b);
    },
    cv = function (a, b) {
      return wf(a, 3, b);
    },
    dv = function (a, b) {
      return D(a, 4, ie(b), 0);
    },
    ev = function (a, b) {
      return D(a, 5, ie(b), 0);
    },
    fv = function (a, b) {
      return D(a, 6, ie(b), 0);
    },
    gv = function (a, b) {
      return D(a, 7, te(b), "");
    },
    hv = function (a, b) {
      return D(a, 8, ie(b), 0);
    },
    iv = function (a, b) {
      return D(a, 9, ie(b), 0);
    },
    jv = function (a, b) {
      return D(a, 10, ae(b), !1);
    },
    kv = function (a, b) {
      return D(a, 11, ae(b), !1);
    },
    lv = function (a, b) {
      return pf(a, 12, b, ee);
    },
    mv = function (a, b) {
      return pf(a, 13, b, ee);
    },
    nv = function (a, b) {
      return pf(a, 14, b, ee);
    },
    ov = function (a, b) {
      return D(a, 15, ae(b), !1);
    },
    pv = function (a, b) {
      return D(a, 16, te(b), "");
    },
    qv = function (a, b) {
      return pf(a, 17, b, he);
    },
    rv = function (a, b) {
      return pf(a, 18, b, he);
    },
    tv = function (a, b) {
      return xf(a, 19, b);
    };
  $u.na = [12, 13, 14, 17, 18, 19];
  var uv = function (a) {
    this.K = B(a);
  };
  v(uv, F);
  var vv = "a".charCodeAt(),
    wv = Tg({
      Fh: 0,
      Eh: 1,
      Bh: 2,
      wh: 3,
      Ch: 4,
      xh: 5,
      Dh: 6,
      zh: 7,
      Ah: 8,
      vh: 9,
      yh: 10,
      Gh: 11,
    }),
    xv = Tg({ Ih: 0, Jh: 1, Hh: 2 });
  var yv = function (a) {
      if (/[^01]/.test(a))
        throw Error("Input bitstring " + a + " is malformed!");
      this.j = a;
      this.g = 0;
    },
    Av = function (a) {
      a = zv(a, 36);
      var b = new Zu();
      b = D(b, 1, le(Math.floor(a / 10)), "0");
      return D(b, 2, ie((a % 10) * 1e8), 0);
    },
    Bv = function (a) {
      return (
        String.fromCharCode(vv + zv(a, 6)) + String.fromCharCode(vv + zv(a, 6))
      );
    },
    Ev = function (a) {
      var b = zv(a, 16);
      return !0 === !!zv(a, 1)
        ? ((a = Cv(a)),
          a.forEach(function (c) {
            if (c > b)
              throw Error("ID " + c + " is past MaxVendorId " + b + "!");
          }),
          a)
        : Dv(a, b);
    },
    Fv = function (a) {
      for (var b = [], c = zv(a, 12); c--; ) {
        var d = zv(a, 6),
          e = zv(a, 2),
          f = Cv(a),
          g = b,
          h = g.push,
          k = new Tu();
        d = D(k, 1, fe(d), 0);
        e = D(d, 2, fe(e), 0);
        f = pf(e, 3, f, he);
        h.call(g, f);
      }
      return b;
    },
    Cv = function (a) {
      for (var b = zv(a, 12), c = []; b--; ) {
        var d = !0 === !!zv(a, 1),
          e = zv(a, 16);
        if (d) for (d = zv(a, 16); e <= d; e++) c.push(e);
        else c.push(e);
      }
      c.sort(function (f, g) {
        return f - g;
      });
      return c;
    },
    Dv = function (a, b, c) {
      for (var d = [], e = 0; e < b; e++)
        if (zv(a, 1)) {
          var f = e + 1;
          if (c && -1 === c.indexOf(f))
            throw Error("ID: " + f + " is outside of allowed values!");
          d.push(f);
        }
      return d;
    },
    zv = function (a, b) {
      if (a.g + b > a.j.length)
        throw Error("Requested length " + b + " is past end of string.");
      var c = a.j.substring(a.g, a.g + b);
      a.g += b;
      return parseInt(c, 2);
    };
  yv.prototype.skip = function (a) {
    this.g += a;
  };
  var Gv = function (a) {
    try {
      var b = Kc(a)
          .map(function (f) {
            return f.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new yv(b);
      if (3 !== zv(c, 3)) return null;
      var d = Wu(Vu(new Uu(), Dv(c, 24, wv)), Dv(c, 24, wv)),
        e = zv(c, 6);
      0 !== e && Yu(Xu(d, Dv(c, e)), Dv(c, e));
      return d;
    } catch (f) {
      return null;
    }
  };
  var Hv = function (a) {
    try {
      var b = Kc(a)
          .map(function (d) {
            return d.toString(2).padStart(8, "0");
          })
          .join(""),
        c = new yv(b);
      return tv(
        rv(
          qv(
            pv(
              ov(
                nv(
                  mv(
                    lv(
                      kv(
                        jv(
                          iv(
                            hv(
                              gv(
                                fv(
                                  ev(
                                    dv(
                                      cv(
                                        bv(av(new $u(), zv(c, 6)), Av(c)),
                                        Av(c)
                                      ),
                                      zv(c, 12)
                                    ),
                                    zv(c, 12)
                                  ),
                                  zv(c, 6)
                                ),
                                Bv(c)
                              ),
                              zv(c, 12)
                            ),
                            zv(c, 6)
                          ),
                          !!zv(c, 1)
                        ),
                        !!zv(c, 1)
                      ),
                      Dv(c, 12, xv)
                    ),
                    Dv(c, 24, wv)
                  ),
                  Dv(c, 24, wv)
                ),
                !!zv(c, 1)
              ),
              Bv(c)
            ),
            Ev(c)
          ),
          Ev(c)
        ),
        Fv(c)
      );
    } catch (d) {
      return null;
    }
  };
  var Jv = function (a) {
      if (!a) return null;
      var b = a.split(".");
      if (4 < b.length) return null;
      a = Hv(b[0]);
      if (!a) return null;
      var c = new uv();
      a = wf(c, 1, a);
      b.shift();
      b = u(b);
      for (c = b.next(); !c.done; c = b.next())
        switch (((c = c.value), Iv(c))) {
          case 1:
          case 2:
            break;
          case 3:
            c = Gv(c);
            if (!c) return null;
            wf(a, 2, c);
            break;
          default:
            return null;
        }
      return a;
    },
    Iv = function (a) {
      try {
        var b = Kc(a)
          .map(function (c) {
            return c.toString(2).padStart(8, "0");
          })
          .join("");
        return zv(new yv(b), 3);
      } catch (c) {
        return -1;
      }
    };
  var Kv = function (a, b) {
    var c = {};
    if (Array.isArray(b) && 0 !== b.length) {
      b = u(b);
      for (var d = b.next(); !d.done; d = b.next())
        (d = d.value), (c[d] = -1 !== a.indexOf(d));
    } else for (a = u(a), b = a.next(); !b.done; b = a.next()) c[b.value] = !0;
    delete c[0];
    return c;
  };
  var Lv = function (a, b, c, d) {
    Ou.call(this, a, b);
    this.A = c;
    this.l = d;
  };
  v(Lv, Ou);
  Lv.prototype.j = function () {
    var a = Ia.apply(0, arguments);
    try {
      var b = encodeURIComponent(Ic(ou(a, this.g), 3));
      this.l(this.A + "?e=4&d=" + b);
    } catch (c) {
      qu(c, this.g);
    }
  };
  var Mv = new (function (a, b) {
      this.g = a;
      this.defaultValue = void 0 === b ? 0 : b;
    })(494575051),
    Nv = new Gg(489560439),
    Ov = new Gg(505762507);
  var Pv = function (a) {
    this.K = B(a);
  };
  v(Pv, F);
  var Qv = function (a) {
    var b = new Pv(),
      c = b.K,
      d = Dd(c);
    Td(Ed(b.K));
    var e = d & 2;
    b = cf(c, d, 1, !1);
    Array.isArray(b) || (b = Rd);
    var f = !!(d & 32),
      g = Dd(b);
    0 === g && f && !e ? ((g |= 33), Fd(b, g)) : g & 1 || ((g |= 1), Fd(b, g));
    if (e) g & 2 || Gd(b), Object.freeze(b);
    else if (2 & g || 2048 & g)
      (b = ud(b)), (e = 1), f && (e |= 32), Fd(b, e), ff(c, d, 1, b, !1);
    c = b;
    d = Dd(c);
    d = !!(4 & d) && !!(4096 & d);
    if (Array.isArray(a)) for (b = 0; b < a.length; b++) c.push(ee(a[b], d));
    else
      for (a = u(a), b = a.next(); !b.done; b = a.next())
        c.push(ee(b.value, d));
  };
  Pv.na = [1];
  var Rv = /^((market|itms|intent|itms-appss):\/\/)/i;
  var Sv = "ad_type vpos mridx pos vad_type videoad_start_delay".split(" ");
  var Tv = function (a) {
    var b = a.Za,
      c = a.height,
      d = a.width,
      e = void 0 === a.Ea ? !1 : a.Ea;
    this.pb = a.pb;
    this.Za = b;
    this.height = c;
    this.width = d;
    this.Ea = e;
  };
  Tv.prototype.getHeight = function () {
    return this.height;
  };
  Tv.prototype.getWidth = function () {
    return this.width;
  };
  var Uv = function (a) {
    var b = a.Qg,
      c = a.Df,
      d = a.Pg,
      e = a.Cf;
    Tv.call(this, {
      pb: a.pb,
      Za: a.Za,
      height: a.height,
      width: a.width,
      Ea: void 0 === a.Ea ? !1 : a.Ea,
    });
    this.A = b;
    this.j = c;
    this.l = d;
    this.g = e;
  };
  v(Uv, Tv);
  var Vv = function (a) {
    var b = a.jg;
    Tv.call(this, {
      pb: a.pb,
      Za: a.Za,
      height: a.height,
      width: a.width,
      Ea: void 0 === a.Ea ? !1 : a.Ea,
    });
    this.g = b;
  };
  v(Vv, Tv);
  Vv.prototype.getMediaUrl = function () {
    return this.g;
  };
  function Wv(a) {
    return new (Function.prototype.bind.apply(
      a,
      [null].concat(ha(Ia.apply(1, arguments)))
    ))();
  }
  var Xv = function (a, b, c, d) {
    Q.call(this);
    this.G = b;
    this.F = c;
    this.C = d;
    this.o = new Map();
    this.H = 0;
    this.A = new Map();
    this.B = new Map();
    this.l = void 0;
    this.j = a;
  };
  v(Xv, Q);
  Xv.prototype.M = function () {
    delete this.g;
    this.o.clear();
    this.A.clear();
    this.B.clear();
    this.l && (Og(this.j, "message", this.l), delete this.l);
    delete this.j;
    delete this.C;
    Q.prototype.M.call(this);
  };
  var Yv = function (a) {
      if (a.g) return a.g;
      a.F && a.F(a.j) ? (a.g = a.j) : (a.g = xi(a.j, a.G));
      var b;
      return null != (b = a.g) ? b : null;
    },
    $v = function (a, b, c) {
      if (Yv(a))
        if (a.g === a.j) (b = a.o.get(b)) && b(a.g, c);
        else {
          var d = a.A.get(b);
          if (d && d.Yb) {
            Zv(a);
            var e = ++a.H;
            a.B.set(e, { Gb: d.Gb, Kf: d.Hc(c), vg: "addEventListener" === b });
            a.g.postMessage(d.Yb(c, e), "*");
          }
        }
    },
    Zv = function (a) {
      a.l ||
        ((a.l = function (b) {
          try {
            var c = a.C ? a.C(b) : void 0;
            if (c) {
              var d = c.Ae,
                e = a.B.get(d);
              if (e) {
                e.vg || a.B.delete(d);
                var f;
                null == (f = e.Gb) || f.call(e, e.Kf, c.payload);
              }
            }
          } catch (g) {}
        }),
        Ng(a.j, "message", a.l));
    };
  var aw = function (a, b) {
      b = b.listener;
      (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0);
    },
    bw = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    cw = function (a, b) {
      (0, a.__gpp)(
        "getSection",
        function (c) {
          b.wa({ vc: null != c ? c : void 0, xc: c ? void 0 : 4 });
        },
        b.apiPrefix
      );
    },
    dw = {
      Hc: function (a) {
        return a.listener;
      },
      Yb: function (a, b) {
        a = {};
        return (
          (a.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          a
        );
      },
      Gb: function (a, b) {
        b = b.__gppReturn;
        a(b.returnValue, b.success);
      },
    },
    ew = {
      Hc: function (a) {
        return a.listener;
      },
      Yb: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      Gb: function (a, b) {
        b = b.__gppReturn;
        var c = b.returnValue.data;
        null == a || a(c, b.success);
      },
    },
    fw = {
      Hc: function (a) {
        return a.wa;
      },
      Yb: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "getSection",
            version: "1.1",
            parameter: a.apiPrefix,
          }),
          c
        );
      },
      Gb: function (a, b) {
        b = b.__gppReturn;
        var c;
        a({
          vc: null != (c = b.returnValue) ? c : void 0,
          xc: b.success ? void 0 : 2,
        });
      },
    };
  function gw(a) {
    var b = {};
    "string" === typeof a.data ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, Ae: b.__gppReturn.callId };
  }
  var hw = function (a, b) {
    var c = void 0 === b ? {} : b;
    b = c.timeoutMs;
    c = c.allowEmptyApplicableSection;
    Q.call(this);
    this.caller = new Xv(
      a,
      "__gppLocator",
      function (d) {
        return "function" === typeof d.__gpp;
      },
      gw
    );
    this.caller.o.set("addEventListener", aw);
    this.caller.A.set("addEventListener", dw);
    this.caller.o.set("removeEventListener", bw);
    this.caller.A.set("removeEventListener", ew);
    this.caller.o.set("getDataWithCallback", cw);
    this.caller.A.set("getDataWithCallback", fw);
    this.timeoutMs = null != b ? b : 500;
    this.allowEmptyApplicableSection = c;
  };
  v(hw, Q);
  hw.prototype.M = function () {
    this.caller.X();
    Q.prototype.M.call(this);
  };
  hw.prototype.addEventListener = function (a) {
    var b = this,
      c = Jg(function () {
        a(iw, !0);
      }),
      d =
        -1 === this.timeoutMs
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    $v(this.caller, "addEventListener", {
      listener: function (e, f) {
        clearTimeout(d);
        try {
          var g;
          if (
            void 0 === (null == (g = e.pingData) ? void 0 : g.gppVersion) ||
            "1" === e.pingData.gppVersion ||
            "1.0" === e.pingData.gppVersion
          ) {
            b.removeEventListener(e.listenerId);
            var h = {
              eventName: "signalStatus",
              data: "ready",
              pingData: {
                internalErrorState: 1,
                gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                applicableSections: [-1],
              },
            };
          } else
            !Array.isArray(e.pingData.applicableSections) ||
            (0 === e.pingData.applicableSections.length &&
              !b.allowEmptyApplicableSection)
              ? (b.removeEventListener(e.listenerId),
                (h = {
                  eventName: "signalStatus",
                  data: "ready",
                  pingData: {
                    internalErrorState: 2,
                    gppString:
                      "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                    applicableSections: [-1],
                  },
                }))
              : (h = e);
          a(h, f);
        } catch (k) {
          if (null == e ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (n) {
              a(jw, !0);
              return;
            }
          a(kw, !0);
        }
      },
    });
  };
  hw.prototype.removeEventListener = function (a) {
    $v(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var kw = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    iw = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    jw = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  var lw = function (a) {
      void 0 !== a.addtlConsent &&
        "string" !== typeof a.addtlConsent &&
        (a.addtlConsent = void 0);
      void 0 !== a.gdprApplies &&
        "boolean" !== typeof a.gdprApplies &&
        (a.gdprApplies = void 0);
      return (void 0 !== a.tcString && "string" !== typeof a.tcString) ||
        (void 0 !== a.listenerId && "number" !== typeof a.listenerId)
        ? 2
        : a.cmpStatus && "error" !== a.cmpStatus
        ? 0
        : 3;
    },
    mw = function (a, b) {
      b = void 0 === b ? {} : b;
      Q.call(this);
      this.j = a;
      this.g = null;
      this.B = {};
      this.C = 0;
      var c;
      this.A = null != (c = b.timeoutMs) ? c : 500;
      var d;
      this.o = null != (d = b.xi) ? d : !1;
      this.l = null;
    };
  v(mw, Q);
  mw.prototype.M = function () {
    this.B = {};
    this.l && (Og(this.j, "message", this.l), delete this.l);
    delete this.B;
    delete this.j;
    delete this.g;
    Q.prototype.M.call(this);
  };
  var ow = function (a) {
      return "function" === typeof a.j.__tcfapi || null != nw(a);
    },
    rw = function (a, b) {
      var c = { internalErrorState: 0, internalBlockOnErrors: a.o },
        d = Jg(function () {
          return b(c);
        }),
        e = 0;
      -1 !== a.A &&
        (e = setTimeout(function () {
          e = 0;
          c.tcString = "tcunavailable";
          c.internalErrorState = 1;
          d();
        }, a.A));
      pw(a, "addEventListener", function (f) {
        f &&
          ((c = f),
          (c.internalErrorState = lw(c)),
          (c.internalBlockOnErrors = a.o),
          qw(c)
            ? (0 != c.internalErrorState && (c.tcString = "tcunavailable"),
              pw(a, "removeEventListener", null, c.listenerId),
              (f = e) && clearTimeout(f),
              d())
            : ("error" === c.cmpStatus || 0 !== c.internalErrorState) &&
              (f = e) &&
              clearTimeout(f));
      });
    };
  mw.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.o },
      d = Jg(function () {
        return a(c);
      }),
      e = 0;
    -1 !== this.A &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.A));
    var f = function (g, h) {
      clearTimeout(e);
      g
        ? ((c = g),
          (c.internalErrorState = lw(c)),
          (c.internalBlockOnErrors = b.o),
          (h && 0 === c.internalErrorState) ||
            ((c.tcString = "tcunavailable"), h || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      pw(this, "addEventListener", f);
    } catch (g) {
      (c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d();
    }
  };
  mw.prototype.removeEventListener = function (a) {
    a && a.listenerId && pw(this, "removeEventListener", null, a.listenerId);
  };
  var uw = function (a, b, c) {
      var d = void 0 === d ? "755" : d;
      a: {
        if (a.publisher && a.publisher.restrictions) {
          var e = a.publisher.restrictions[b];
          if (void 0 !== e) {
            e = e[void 0 === d ? "755" : d];
            break a;
          }
        }
        e = void 0;
      }
      if (0 === e) return !1;
      var f = c;
      2 === c
        ? ((f = 0), 2 === e && (f = 1))
        : 3 === c && ((f = 1), 1 === e && (f = 0));
      a =
        0 === f
          ? a.purpose && a.vendor
            ? (c = tw(a.vendor.consents, void 0 === d ? "755" : d)) &&
              "1" === b &&
              a.purposeOneTreatment &&
              "CH" === a.publisherCC
              ? !0
              : c && tw(a.purpose.consents, b)
            : !0
          : 1 === f
          ? a.purpose && a.vendor
            ? tw(a.purpose.legitimateInterests, b) &&
              tw(a.vendor.legitimateInterests, void 0 === d ? "755" : d)
            : !0
          : !0;
      return a;
    },
    tw = function (a, b) {
      return !(!a || !a[b]);
    },
    pw = function (a, b, c, d) {
      c || (c = function () {});
      if ("function" === typeof a.j.__tcfapi) (a = a.j.__tcfapi), a(b, 2, c, d);
      else if (nw(a)) {
        vw(a);
        var e = ++a.C;
        a.B[e] = c;
        a.g &&
          ((c = {}),
          a.g.postMessage(
            ((c.__tcfapiCall = {
              command: b,
              version: 2,
              callId: e,
              parameter: d,
            }),
            c),
            "*"
          ));
      } else c({}, !1);
    },
    nw = function (a) {
      if (a.g) return a.g;
      a.g = xi(a.j, "__tcfapiLocator");
      return a.g;
    },
    vw = function (a) {
      a.l ||
        ((a.l = function (b) {
          try {
            var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data)
              .__tcfapiReturn;
            a.B[c.callId](c.returnValue, c.success);
          } catch (d) {}
        }),
        Ng(a.j, "message", a.l));
    },
    qw = function (a) {
      if (!1 === a.gdprApplies) return !0;
      void 0 === a.internalErrorState && (a.internalErrorState = lw(a));
      return "error" === a.cmpStatus || 0 !== a.internalErrorState
        ? a.internalBlockOnErrors
          ? (Qi({ e: String(a.internalErrorState) }, "tcfe"), !1)
          : !0
        : "loaded" !== a.cmpStatus ||
          ("tcloaded" !== a.eventStatus &&
            "useractioncomplete" !== a.eventStatus)
        ? !1
        : !0;
    },
    ww = function (a) {
      var b = ["2", "7", "9", "10"];
      return !1 === a.gdprApplies
        ? !0
        : b.every(function (c) {
            return uw(a, c, 1);
          });
    };
  Qv([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16]);
  Qv([1, 6, 7, 9, 10, 11, 12, 2, 3, 4, 5, 13, 14]);
  Qv([1, 6, 7, 9, 10, 11, 12, 2, 3, 4, 5, 13, 14]);
  new Pv();
  var T = function (a, b) {
    this.j = this.B = this.A = "";
    this.I = null;
    this.N = this.l = "";
    this.o = !1;
    var c;
    a instanceof T
      ? ((this.o = void 0 !== b ? b : a.o),
        xw(this, a.A),
        (this.B = a.B),
        (this.j = a.j),
        yw(this, a.I),
        (this.l = a.l),
        zw(this, Aw(a.g)),
        (this.N = a.F()))
      : a && (c = String(a).match(hi))
      ? ((this.o = !!b),
        xw(this, c[1] || "", !0),
        (this.B = Bw(c[2] || "")),
        (this.j = Bw(c[3] || "", !0)),
        yw(this, c[4]),
        (this.l = Bw(c[5] || "", !0)),
        zw(this, c[6] || "", !0),
        (this.N = Bw(c[7] || "")))
      : ((this.o = !!b), (this.g = new Cw(null, this.o)));
  };
  T.prototype.toString = function () {
    var a = [],
      b = this.A;
    b && a.push(Dw(b, Ew, !0), ":");
    var c = this.j;
    if (c || "file" == b)
      a.push("//"),
        (b = this.B) && a.push(Dw(b, Ew, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.I),
        null != c && a.push(":", String(c));
    if ((c = this.l))
      this.j && "/" != c.charAt(0) && a.push("/"),
        a.push(Dw(c, "/" == c.charAt(0) ? Fw : Gw, !0));
    (c = this.g.toString()) && a.push("?", c);
    (c = this.F()) && a.push("#", Dw(c, Hw));
    return a.join("");
  };
  T.prototype.resolve = function (a) {
    var b = this.G(),
      c = !!a.A;
    c ? xw(b, a.A) : (c = !!a.B);
    c ? (b.B = a.B) : (c = !!a.j);
    c ? (b.j = a.j) : (c = null != a.I);
    var d = a.l;
    if (c) yw(b, a.I);
    else if ((c = !!a.l)) {
      if ("/" != d.charAt(0))
        if (this.j && !this.l) d = "/" + d;
        else {
          var e = b.l.lastIndexOf("/");
          -1 != e && (d = b.l.slice(0, e + 1) + d);
        }
      e = d;
      if (".." == e || "." == e) d = "";
      else if (pb(e, "./") || pb(e, "/.")) {
        d = 0 == e.lastIndexOf("/", 0);
        e = e.split("/");
        for (var f = [], g = 0; g < e.length; ) {
          var h = e[g++];
          "." == h
            ? d && g == e.length && f.push("")
            : ".." == h
            ? ((1 < f.length || (1 == f.length && "" != f[0])) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(h), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.l = d) : (c = "" !== a.g.toString());
    c ? zw(b, Aw(a.g)) : (c = !!a.N);
    c && (b.N = a.F());
    return b;
  };
  T.prototype.G = function () {
    return new T(this);
  };
  var xw = function (a, b, c) {
      a.A = c ? Bw(b, !0) : b;
      a.A && (a.A = a.A.replace(/:$/, ""));
    },
    yw = function (a, b) {
      if (b) {
        b = Number(b);
        if (isNaN(b) || 0 > b) throw Error("Bad port number " + b);
        a.I = b;
      } else a.I = null;
    },
    zw = function (a, b, c) {
      b instanceof Cw
        ? ((a.g = b), Iw(a.g, a.o))
        : (c || (b = Dw(b, Jw)), (a.g = new Cw(b, a.o)));
    },
    Kw = function (a, b, c) {
      a.g.set(b, c);
      return a;
    };
  T.prototype.F = function () {
    return this.N;
  };
  var Lw = function (a) {
      return a instanceof T ? a.G() : new T(a, void 0);
    },
    Bw = function (a, b) {
      return a
        ? b
          ? decodeURI(a.replace(/%25/g, "%2525"))
          : decodeURIComponent(a)
        : "";
    },
    Dw = function (a, b, c) {
      return "string" === typeof a
        ? ((a = encodeURI(a).replace(b, Mw)),
          c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
          a)
        : null;
    },
    Mw = function (a) {
      a = a.charCodeAt(0);
      return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
    },
    Ew = /[#\/\?@]/g,
    Gw = /[#\?:]/g,
    Fw = /[#\?]/g,
    Jw = /[#\?@]/g,
    Hw = /#/g,
    Cw = function (a, b) {
      this.j = this.g = null;
      this.l = a || null;
      this.A = !!b;
    },
    Nw = function (a) {
      a.g ||
        ((a.g = new Map()),
        (a.j = 0),
        a.l &&
          ji(a.l, function (b, c) {
            a.add(Hh(b), c);
          }));
    };
  Cw.prototype.add = function (a, b) {
    Nw(this);
    this.l = null;
    a = Ow(this, a);
    var c = this.g.get(a);
    c || this.g.set(a, (c = []));
    c.push(b);
    this.j += 1;
    return this;
  };
  Cw.prototype.remove = function (a) {
    Nw(this);
    a = Ow(this, a);
    return this.g.has(a)
      ? ((this.l = null), (this.j -= this.g.get(a).length), this.g.delete(a))
      : !1;
  };
  Cw.prototype.clear = function () {
    this.g = this.l = null;
    this.j = 0;
  };
  Cw.prototype.isEmpty = function () {
    Nw(this);
    return 0 == this.j;
  };
  var Pw = function (a, b) {
    Nw(a);
    b = Ow(a, b);
    return a.g.has(b);
  };
  l = Cw.prototype;
  l.forEach = function (a, b) {
    Nw(this);
    this.g.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  l.zc = function () {
    Nw(this);
    for (
      var a = Array.from(this.g.values()),
        b = Array.from(this.g.keys()),
        c = [],
        d = 0;
      d < b.length;
      d++
    )
      for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c;
  };
  l.Db = function (a) {
    Nw(this);
    var b = [];
    if ("string" === typeof a)
      Pw(this, a) && (b = b.concat(this.g.get(Ow(this, a))));
    else {
      a = Array.from(this.g.values());
      for (var c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  l.set = function (a, b) {
    Nw(this);
    this.l = null;
    a = Ow(this, a);
    Pw(this, a) && (this.j -= this.g.get(a).length);
    this.g.set(a, [b]);
    this.j += 1;
    return this;
  };
  l.get = function (a, b) {
    if (!a) return b;
    a = this.Db(a);
    return 0 < a.length ? String(a[0]) : b;
  };
  l.toString = function () {
    if (this.l) return this.l;
    if (!this.g) return "";
    for (var a = [], b = Array.from(this.g.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = this.Db(d);
      for (var f = 0; f < d.length; f++) {
        var g = e;
        "" !== d[f] && (g += "=" + encodeURIComponent(String(d[f])));
        a.push(g);
      }
    }
    return (this.l = a.join("&"));
  };
  var Aw = function (a) {
      var b = new Cw();
      b.l = a.l;
      a.g && ((b.g = new Map(a.g)), (b.j = a.j));
      return b;
    },
    Ow = function (a, b) {
      b = String(b);
      a.A && (b = b.toLowerCase());
      return b;
    },
    Iw = function (a, b) {
      b &&
        !a.A &&
        (Nw(a),
        (a.l = null),
        a.g.forEach(function (c, d) {
          var e = d.toLowerCase();
          d != e &&
            (this.remove(d),
            this.remove(e),
            0 < c.length &&
              ((this.l = null),
              this.g.set(Ow(this, e), bc(c)),
              (this.j += c.length)));
        }, a));
      a.A = b;
    };
  var Qw,
    Rw,
    Sw,
    Tw = function () {
      return x.navigator ? x.navigator.userAgent : "";
    },
    Uw =
      pb(Tw(), "(iPad") ||
      pb(Tw(), "(Macintosh") ||
      pb(Tw(), "(iPod") ||
      pb(Tw(), "(iPhone");
  var Vw =
      "ad.doubleclick.net bid.g.doubleclick.net ggpht.com google.co.uk google.com googleads.g.doubleclick.net googleads4.g.doubleclick.net googleadservices.com googlesyndication.com googleusercontent.com gstatic.com gvt1.com prod.google.com pubads.g.doubleclick.net s0.2mdn.net static.doubleclick.net surveys.g.doubleclick.net youtube.com ytimg.com".split(
        " "
      ),
    Ww = ["c.googlesyndication.com"];
  function Xw(a, b) {
    b = void 0 === b ? window.location.protocol : b;
    var c = !1;
    null == a ||
    !a.startsWith("http") ||
    (null == a ? 0 : a.startsWith("https"))
      ? (c = !1)
      : Yw(a, Ww)
      ? (c = !1)
      : b.includes("https") && Yw(a, Vw) && (c = !0);
    return c
      ? ((a = new T(a)),
        K(J.getInstance(), "htp", "1"),
        xw(a, "https"),
        a.toString())
      : a;
  }
  function Zw(a) {
    if (!a) return !1;
    try {
      var b = "string" === typeof a ? new T(a) : a;
      return "gcache" == b.A && !!b.g.get("url");
    } catch (c) {
      return !1;
    }
  }
  function $w(a) {
    try {
      var b = "string" === typeof a ? new T(a) : a;
      if (Zw(b)) {
        var c = b.g.get("url");
        return "undefined" === typeof c ? null : c;
      }
    } catch (d) {}
    return null;
  }
  function Yw(a, b) {
    return new RegExp(
      "^https?://([a-z0-9-]{1,63}\\.)*(" +
        b.join("|").replace(/\./g, "\\.") +
        ")(:[0-9]+)?([/?#]|$)",
      "i"
    ).test(a);
  }
  var ax = -1;
  function bx(a, b) {
    b = null != b ? b : "";
    lc && (b = "");
    if (!nb(Kh(a))) {
      var c = a instanceof jh || !Rv.test(a) ? a : new jh(a);
      if (c instanceof jh) var d = c;
      else {
        d = void 0 === d ? ph : d;
        a: if (((d = void 0 === d ? ph : d), !(a instanceof jh))) {
          for (c = 0; c < d.length; ++c) {
            var e = d[c];
            if (e instanceof lh && e.gg(a)) {
              a = new jh(a);
              break a;
            }
          }
          a = void 0;
        }
        d = a || kh;
      }
      a = window;
      if (d instanceof jh)
        if (d instanceof jh) d = d.g;
        else throw Error("");
      else d = rh.test(d) ? d : void 0;
      void 0 !== d && a.open(d, "_blank", b);
    }
  }
  function cx(a, b) {
    for (var c; !(c = a.next()).done; ) b(c.value);
  }
  var dx = function (a, b) {
    this.g = a[x.Symbol.iterator]();
    this.j = b;
  };
  dx.prototype[Symbol.iterator] = function () {
    return this;
  };
  dx.prototype.next = function () {
    var a = this.g.next();
    return {
      value: a.done ? void 0 : this.j.call(void 0, a.value),
      done: a.done,
    };
  };
  var ex = function (a, b) {
    return new dx(a, b);
  };
  var fx = function (a, b) {
    var c = new Set(a);
    cx(b[Symbol.iterator](), function (d) {
      return c.add(d);
    });
    return c;
  };
  var gx = new Map(),
    hx = function () {
      this.j = this.g = null;
    };
  function ix(a, b, c, d) {
    var e = Qm(a);
    Ch(b, e)
      ? ((e = setTimeout(function () {
          return ix(a, b, c, d);
        }, 200)),
        (d.j = e))
      : (jx(d), c(e));
  }
  function kx(a) {
    var b = new hx(),
      c = new Promise(function (f) {
        var g = Qm(a);
        if ("ResizeObserver" in window) {
          var h = new ResizeObserver(function (k) {
            window.requestAnimationFrame(function () {
              for (
                var n = new Bh(0, 0), m = u(k), r = m.next();
                !r.done;
                r = m.next()
              )
                if (
                  ((r = r.value),
                  r.contentBoxSize
                    ? ((r = Array.isArray(r.contentBoxSize)
                        ? r.contentBoxSize[0]
                        : r.contentBoxSize),
                      (n.width = Math.floor(r.inlineSize)),
                      (n.height = Math.floor(r.blockSize)))
                    : ((n.width = Math.floor(r.contentRect.width)),
                      (n.height = Math.floor(r.contentRect.height))),
                  !Ch(g, n))
                )
                  return jx(b), f(n);
            });
          });
          b.g = h;
          h.observe(a);
        } else ix(a, g, f, b);
      }),
      d,
      e = null != (d = gx.get(c)) ? d : new Set();
    e.add(b);
    gx.set(c, e);
    return c;
  }
  function lx(a, b) {
    b = void 0 === b ? new Bh(1, 1) : b;
    var c = function (g) {
        var h = kx(a),
          k,
          n = null != (k = gx.get(g)) ? k : new Set(),
          m;
        k = null != (m = gx.get(h)) ? m : new Set();
        gx.set(g, fx(n, k));
        return h;
      },
      d = function (g, h) {
        c(g).then(function (k) {
          return b.width <= k.width && b.height <= k.height
            ? (mx(g), h(k))
            : d(g, h);
        });
      },
      e,
      f = new Promise(function (g) {
        e = g;
      });
    d(f, e);
    return f;
  }
  function mx(a) {
    a = gx.get(a);
    a = u(a);
    for (var b = a.next(); !b.done; b = a.next()) jx(b.value);
  }
  function jx(a) {
    a.j && window.clearTimeout(a.j);
    a.g && (a.g.disconnect(), (a.g = null));
  }
  function nx(a, b) {
    return a && (a[b] || (a[b] = {}));
  }
  function ox(a, b) {
    var c;
    if (
      (c =
        void 0 === c
          ? "undefined" === typeof omidExports
            ? null
            : omidExports
          : c)
    )
      (a = a.split(".")),
        (a.slice(0, a.length - 1).reduce(nx, c)[a[a.length - 1]] = b);
  }
  var px = new Map([
    [2, [/^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.moatads\.com\/.*$/]],
    [
      3,
      [
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.doubleverify\.com\/.*$/,
        /^(https?:\/\/|\/\/)?c\.[\w\-]+\.com\/vfw\/dv\/.*$/,
        /^(https?:\/\/|\/\/)?(www\.)?[\w]+\.tv\/r\/s\/d\/.*$/,
        /^(https?:\/\/|\/\/)?(\w\.?)+\.dv\.tech\/.*$/,
      ],
    ],
    [4, [/^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.adsafeprotected\.com\/.*$/]],
    [
      5,
      [
        /^https?:\/\/(q|cdn)\.adrta\.com\/s\/.*\/(aa|aanf)\.js.*$/,
        /^https:\/\/cdn\.rta247\.com\/s\/.*\/(aa|aanf)\.js.*$/,
      ],
    ],
    [6, []],
    [
      7,
      [
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.voicefive\.com\/.*$/,
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.measuread\.com\/.*$/,
        /^(https?:\/\/|\/\/)?[-a-zA-Z0-9.]+\.scorecardresearch\.com\/.*$/,
      ],
    ],
    [
      8,
      [/^(https?:\/\/|\/\/)?s418\.mxcdn\.net\/bb-serve\/omid-meetrics.*\.js$/],
    ],
    [
      9,
      [
        /^(https?:\/\/|\/\/)?pagead2\.googlesyndication\.com\/.*$/,
        /^(https?:\/\/|\/\/)?www\.googletagservices\.com\/.*$/,
      ],
    ],
  ]);
  ox("OmidSessionClient.verificationVendorIdForScriptUrl", function (a) {
    for (var b = u(px.keys()), c = b.next(); !c.done; c = b.next()) {
      c = c.value;
      for (var d = u(px.get(c)), e = d.next(); !e.done; e = d.next())
        if (e.value.test(a)) return c;
    }
    return 1;
  });
  ox("OmidSessionClient.VerificationVendorId", {
    OTHER: 1,
    MOAT: 2,
    DOUBLEVERIFY: 3,
    INTEGRAL_AD_SCIENCE: 4,
    PIXELATE: 5,
    NIELSEN: 6,
    COMSCORE: 7,
    MEETRICS: 8,
    GOOGLE: 9,
  });
  var qx = /OS (\S+) like/,
    rx = /Android ([\d\.]+)/;
  function sx(a, b) {
    a = (a = a.exec(wb())) ? a[1] : "";
    a = a.replace(/_/g, ".");
    return 0 <= sb(a, b);
  }
  var tx = function () {
      return sc || (pc && "ontouchstart" in document.documentElement);
    },
    ux = function (a) {
      return uc && sx(qx, a);
    },
    vx = function (a) {
      return (a = void 0 === a ? null : a) &&
        "function" === typeof a.getAttribute
        ? a.getAttribute("playsinline")
          ? !0
          : !1
        : !1;
    };
  var wx = function (a) {
    S.call(this);
    this.j = a;
    this.o = this.B = !1;
    this.C = this.F = 0;
    this.g = new Qs(1e3);
    In(this, this.g);
    as(this.g, "tick", this.G, !1, this);
    as(this.j, "pause", this.l, !1, this);
    as(this.j, "playing", this.l, !1, this);
    as(this.j, "ended", this.l, !1, this);
    as(this.j, "timeupdate", this.l, !1, this);
  };
  v(wx, S);
  var xx = function (a) {
    var b;
    return null != (b = a.j.currentTime) ? b : a.j.getCurrentTime();
  };
  wx.prototype.l = function (a) {
    switch (a.type) {
      case "playing":
        yx(this);
        break;
      case "pause":
      case "ended":
        this.g.enabled && this.g.stop();
        break;
      case "timeupdate":
        !this.B && 0 < xx(this) && ((this.B = !0), yx(this));
    }
  };
  var yx = function (a) {
    !a.g.enabled &&
      a.B &&
      ((a.F = 1e3 * xx(a)), (a.C = Date.now()), (a.o = !1), a.g.start());
  };
  wx.prototype.G = function () {
    var a = Date.now(),
      b = a - this.C,
      c = 1e3 * xx(this);
    c - this.F < 0.5 * b
      ? this.o || ((this.o = !0), this.dispatchEvent("playbackStalled"))
      : (this.o = !1);
    this.F = c;
    this.C = a;
  };
  var zx =
      "://secure-...imrworldwide.com/ ://cdn.imrworldwide.com/ ://aksecure.imrworldwide.com/ ://[^.]*.moatads.com ://youtube[0-9]+.moatpixel.com ://pm.adsafeprotected.com/youtube ://pm.test-adsafeprotected.com/youtube ://e[0-9]+.yt.srs.doubleverify.com www.google.com/pagead/xsul www.youtube.com/pagead/slav".split(
        " "
      ),
    Ax = /\bocr\b/;
  function Bx(a) {
    if (nb(Kh(a)) || (lc && 2048 < a.length)) return !1;
    try {
      if (new T(a).F().match(Ax)) return !0;
    } catch (b) {}
    return (
      null !=
      zx.find(function (b) {
        return null != a.match(b);
      })
    );
  }
  function Cx(a, b) {
    return nb(b) ? !1 : new RegExp(a).test(b);
  }
  function Dx(a) {
    var b = {};
    a.split(",").forEach(function (c) {
      var d = c.split("=");
      2 == d.length &&
        ((c = ob(d[0])), (d = ob(d[1])), 0 < c.length && (b[c] = d));
    });
    return b;
  }
  function Ex(a) {
    var b =
      "af am ar_eg ar_sa ar_xb ar be bg bn ca cs da de_at de_cn de el en_au en_ca en_gb en_ie en_in en_sg en_xa en_xc en_za en es_419 es_ar es_bo es_cl es_co es_cr es_do es_ec es_gt es_hn es_mx es_ni es_pa es_pe es_pr es_py es_sv es_us es_uy es_ve es et eu fa fi fil fr_ca fr_ch fr gl gsw gu he hi hr hu id in is it iw ja kn ko ln lo lt lv ml mo mr ms nb ne nl no pl pt_br pt_pt pt ro ru sk sl sr_latn sr sv sw ta te th tl tr uk ur vi zh_cn zh_hk zh_tw zh zu".split(
        " "
      );
    if (!a) return null;
    a = a.toLowerCase().replace("-", "_");
    if (b.includes(a)) return a;
    a = (a = a.match(/^\w{2,3}([-_]|$)/)) ? a[0].replace(/[_-]/g, "") : "";
    return b.includes(a) ? a : null;
  }
  var Fx = function () {
    this.g = Date.now();
  };
  Fx.prototype.reset = function () {
    this.g = Date.now();
  };
  var Gx = function (a) {
    a = a.g + 5e3 - Date.now();
    return 0 < a ? a : 0;
  };
  var Hx = function (a, b) {
    this.url = a;
    this.g = void 0 === b ? null : b;
  };
  var Ix = function (a) {
    switch (a) {
      case 0:
        return "No Error";
      case 1:
        return "Access denied to content document";
      case 2:
        return "File not found";
      case 3:
        return "Firefox silently errored";
      case 4:
        return "Application custom error";
      case 5:
        return "An exception occurred";
      case 6:
        return "Http response at 400 or 500 level";
      case 7:
        return "Request was aborted";
      case 8:
        return "Request timed out";
      case 9:
        return "The resource is not available offline";
      default:
        return "Unrecognized error code";
    }
  };
  var Jx = function (a) {
    var b = Error.call(this, a);
    this.message = b.message;
    "stack" in b && (this.stack = b.stack);
    this.errorCode = a;
  };
  v(Jx, Error);
  var Kx = function (a) {
    Q.call(this);
    this.A = a;
    this.j = {};
  };
  bb(Kx, Q);
  var Lx = [];
  Kx.prototype.O = function (a, b, c, d) {
    return Mx(this, a, b, c, d);
  };
  var Mx = function (a, b, c, d, e, f) {
    Array.isArray(c) || (c && (Lx[0] = c.toString()), (c = Lx));
    for (var g = 0; g < c.length; g++) {
      var h = as(b, c[g], d || a.handleEvent, e || !1, f || a.A || a);
      if (!h) break;
      a.j[h.key] = h;
    }
    return a;
  };
  Kx.prototype.Xb = function (a, b, c, d) {
    return Nx(this, a, b, c, d);
  };
  var Nx = function (a, b, c, d, e, f) {
    if (Array.isArray(c))
      for (var g = 0; g < c.length; g++) Nx(a, b, c[g], d, e, f);
    else {
      b = $r(b, c, d || a.handleEvent, e, f || a.A || a);
      if (!b) return a;
      a.j[b.key] = b;
    }
    return a;
  };
  Kx.prototype.ob = function (a, b, c, d, e) {
    if (Array.isArray(b))
      for (var f = 0; f < b.length; f++) this.ob(a, b[f], c, d, e);
    else
      (c = c || this.handleEvent),
        (d = Ra(d) ? !!d.capture : !!d),
        (e = e || this.A || this),
        (c = bs(c)),
        (d = !!d),
        (b = Qr(a)
          ? a.Rb(b, c, d, e)
          : a
          ? (a = ds(a))
            ? a.Rb(b, c, d, e)
            : null
          : null),
        b && (is(b), delete this.j[b.key]);
  };
  var Ox = function (a) {
    Pg(
      a.j,
      function (b, c) {
        this.j.hasOwnProperty(c) && is(b);
      },
      a
    );
    a.j = {};
  };
  Kx.prototype.M = function () {
    Kx.Fa.M.call(this);
    Ox(this);
  };
  Kx.prototype.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  var Px = function () {};
  Px.prototype.g = null;
  var Qx = function (a) {
    var b;
    (b = a.g) || (b = a.g = {});
    return b;
  };
  var Rx,
    Sx = function () {};
  bb(Sx, Px);
  Rx = new Sx();
  var Tx = function (a) {
    S.call(this);
    this.headers = new Map();
    this.Y = a || null;
    this.j = !1;
    this.F = this.g = null;
    this.J = "";
    this.o = 0;
    this.l = this.H = this.B = this.G = !1;
    this.L = 0;
    this.C = null;
    this.W = "";
    this.P = !1;
  };
  bb(Tx, S);
  var Ux = /^https?$/i,
    Vx = ["POST", "PUT"],
    Yx = function (a, b, c, d) {
      if (a.g)
        throw Error(
          "[goog.net.XhrIo] Object is active with another request=" +
            a.J +
            "; newUri=" +
            b
        );
      c = c ? c.toUpperCase() : "GET";
      a.J = b;
      a.o = 0;
      a.G = !1;
      a.j = !0;
      a.g = new XMLHttpRequest();
      a.F = a.Y ? Qx(a.Y) : Qx(Rx);
      a.g.onreadystatechange = Za(a.U, a);
      try {
        (a.H = !0), a.g.open(c, String(b), !0), (a.H = !1);
      } catch (g) {
        Wx(a);
        return;
      }
      b = d || "";
      d = new Map(a.headers);
      var e = Array.from(d.keys()).find(function (g) {
          return "content-type" == g.toLowerCase();
        }),
        f = x.FormData && b instanceof x.FormData;
      !Xb(Vx, c) ||
        e ||
        f ||
        d.set(
          "Content-Type",
          "application/x-www-form-urlencoded;charset=utf-8"
        );
      c = u(d);
      for (d = c.next(); !d.done; d = c.next())
        (e = u(d.value)),
          (d = e.next().value),
          (e = e.next().value),
          a.g.setRequestHeader(d, e);
      a.W && (a.g.responseType = a.W);
      "withCredentials" in a.g &&
        a.g.withCredentials !== a.P &&
        (a.g.withCredentials = a.P);
      try {
        Xx(a),
          0 < a.L && (a.C = Rs(a.ba, a.L, a)),
          (a.B = !0),
          a.g.send(b),
          (a.B = !1);
      } catch (g) {
        Wx(a);
      }
    };
  Tx.prototype.ba = function () {
    "undefined" != typeof La &&
      this.g &&
      ((this.o = 8), this.dispatchEvent("timeout"), this.abort(8));
  };
  var Wx = function (a) {
      a.j = !1;
      a.g && ((a.l = !0), a.g.abort(), (a.l = !1));
      a.o = 5;
      Zx(a);
      $x(a);
    },
    Zx = function (a) {
      a.G ||
        ((a.G = !0), a.dispatchEvent("complete"), a.dispatchEvent("error"));
    };
  Tx.prototype.abort = function (a) {
    this.g &&
      this.j &&
      ((this.j = !1),
      (this.l = !0),
      this.g.abort(),
      (this.l = !1),
      (this.o = a || 7),
      this.dispatchEvent("complete"),
      this.dispatchEvent("abort"),
      $x(this));
  };
  Tx.prototype.M = function () {
    this.g &&
      (this.j && ((this.j = !1), (this.l = !0), this.g.abort(), (this.l = !1)),
      $x(this, !0));
    Tx.Fa.M.call(this);
  };
  Tx.prototype.U = function () {
    this.Ca() || (this.H || this.B || this.l ? ay(this) : this.Z());
  };
  Tx.prototype.Z = function () {
    ay(this);
  };
  var ay = function (a) {
      if (
        a.j &&
        "undefined" != typeof La &&
        (!a.F[1] || 4 != by(a) || 2 != cy(a))
      )
        if (a.B && 4 == by(a)) Rs(a.U, 0, a);
        else if ((a.dispatchEvent("readystatechange"), 4 == by(a))) {
          a.j = !1;
          try {
            var b = cy(a);
            a: switch (b) {
              case 200:
              case 201:
              case 202:
              case 204:
              case 206:
              case 304:
              case 1223:
                var c = !0;
                break a;
              default:
                c = !1;
            }
            var d;
            if (!(d = c)) {
              var e;
              if ((e = 0 === b)) {
                var f = String(a.J).match(hi)[1] || null;
                !f &&
                  x.self &&
                  x.self.location &&
                  (f = x.self.location.protocol.slice(0, -1));
                e = !Ux.test(f ? f.toLowerCase() : "");
              }
              d = e;
            }
            d
              ? (a.dispatchEvent("complete"), a.dispatchEvent("success"))
              : ((a.o = 6), Zx(a));
          } finally {
            $x(a);
          }
        }
    },
    $x = function (a, b) {
      if (a.g) {
        Xx(a);
        var c = a.g,
          d = a.F[0] ? function () {} : null;
        a.g = null;
        a.F = null;
        b || a.dispatchEvent("ready");
        try {
          c.onreadystatechange = d;
        } catch (e) {}
      }
    },
    Xx = function (a) {
      a.C && (x.clearTimeout(a.C), (a.C = null));
    };
  Tx.prototype.isActive = function () {
    return !!this.g;
  };
  var by = function (a) {
      return a.g ? a.g.readyState : 0;
    },
    cy = function (a) {
      try {
        return 2 < by(a) ? a.g.status : -1;
      } catch (b) {
        return -1;
      }
    },
    dy = function (a) {
      if (a.g) {
        a: {
          a = a.g.responseText;
          if (x.JSON)
            try {
              var b = x.JSON.parse(a);
              break a;
            } catch (c) {}
          b = wj(a);
        }
        return b;
      }
    };
  var ey = function () {};
  ey.prototype.get = function (a) {
    return fy({
      url: a.url,
      timeout: a.timeout,
      withCredentials: void 0 === a.withCredentials ? !0 : a.withCredentials,
      method: "GET",
      headers: void 0 === a.headers ? {} : a.headers,
    });
  };
  var fy = function (a) {
      var b = a.url,
        c = a.timeout,
        d = a.withCredentials,
        e = a.method,
        f = void 0 === a.content ? void 0 : a.content,
        g = void 0 === a.headers ? {} : a.headers;
      return gy({
        url: b,
        timeout: c,
        withCredentials: d,
        method: e,
        content: f,
        headers: g,
      }).then(
        function (h) {
          return Promise.resolve(h);
        },
        function (h) {
          return h instanceof Error && 6 == h.message && d
            ? gy({
                url: b,
                timeout: c,
                withCredentials: !d,
                method: e,
                content: f,
                headers: g,
              })
            : Promise.reject(h);
        }
      );
    },
    gy = function (a) {
      var b = a.url,
        c = a.timeout,
        d = a.withCredentials,
        e = a.method,
        f = void 0 === a.content ? void 0 : a.content;
      a = void 0 === a.headers ? {} : a.headers;
      var g = new Tx();
      g.P = d;
      g.L = Math.max(0, Gx(c));
      for (var h in a) g.headers.set(h, a[h]);
      var k = new Kx();
      return new Promise(function (n, m) {
        k.Xb(g, "success", function () {
          a: {
            if (an())
              try {
                dy(g);
                var r = "application/json";
                break a;
              } catch (w) {
                r = "application/xml";
                break a;
              }
            g.g && 4 == by(g)
              ? ((r = g.g.getResponseHeader("Content-Type")),
                (r = null === r ? void 0 : r))
              : (r = void 0);
            r = r || "";
          }
          if (-1 != r.indexOf("application/json"))
            try {
              n(dy(g) || {});
            } catch (w) {
              m(new Jx(5, cy(g)));
            }
          else {
            try {
              var p = g.g ? g.g.responseXML : null;
            } catch (w) {
              p = null;
            }
            if (null == p) {
              try {
                var t = g.g ? g.g.responseText : "";
              } catch (w) {
                t = "";
              }
              if ("undefined" != typeof DOMParser)
                (p = new DOMParser()),
                  (t = ij(t)),
                  (p = p.parseFromString(xh(t), "application/xml"));
              else
                throw Error(
                  "Your browser does not support loading xml documents"
                );
            }
            n(p);
          }
          k.X();
          g.X();
        });
        k.Xb(g, ["error", "timeout"], function () {
          m(new Jx(g.o, cy(g)));
          k.X();
          g.X();
        });
        Yx(g, Xw(b), e, f);
      });
    };
  z("google.javascript.ads.imalib.common.UrlLoader", ey);
  var hy = [
    "A9AxgGSwmnfgzzkyJHILUr3H8nJ/3D+57oAsL4DBt4USlng4jZ0weq+fZtHC/Qwwn6gd4QSa5DzT3OBif+kXVA0AAAB4eyJvcmlnaW4iOiJodHRwczovL2ltYXNkay5nb29nbGVhcGlzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9",
    "AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
  ];
  function iy() {
    var a = void 0 === a ? document : a;
    var b;
    return !(
      null == (b = a.featurePolicy) ||
      !b.features().includes("attribution-reporting")
    );
  }
  function jy(a, b) {
    b = void 0 === b ? document : b;
    var c;
    return !(null == (c = b.featurePolicy) || !c.allowedFeatures().includes(a));
  }
  function ny() {
    var a = window.navigator,
      b = window.document;
    return !!(
      window.isSecureContext &&
      "runAdAuction" in a &&
      a.runAdAuction instanceof Function &&
      jy("run-ad-auction", b)
    );
  }
  var oy = RegExp("ad\\.doubleclick\\.net/ddm/track(imp|clk)"),
    sy = function (a, b, c, d, e) {
      c = void 0 === c ? !1 : c;
      e = void 0 === e ? null : e;
      try {
        if (
          ((b = (void 0 === d ? 0 : d) ? Xw(b, "https") : Xw(b)),
          oy.test(b) && ((b = b.replace("?", ";tpsrc=ima?")), (e = e || "")),
          (c = c || Bx(b)),
          a.j || null != e)
        )
          py(a, b, c, e);
        else {
          var f = iy() ? e : null;
          an() ? qy(b) : ry(a, b, c, f);
        }
      } catch (g) {}
    },
    ty = function (a, b) {
      var c = { keepalive: !0, method: "get", redirect: "follow" };
      a && (c.referrerPolicy = "no-referrer");
      b
        ? ((c.credentials = "include"),
          "setAttributionReporting" in XMLHttpRequest.prototype
            ? ((c.attributionReporting = {
                eventSourceEligible: !0,
                triggerEligible: !1,
              }),
              (c.mode = "no-cors"))
            : (c.headers = {
                "Attribution-Reporting-Eligible": "event-source",
              }))
        : (c.mode = "no-cors");
      return c;
    },
    py = function (a, b, c, d) {
      d = void 0 === d ? null : d;
      K(J.getInstance(), "faa", "1");
      K(J.getInstance(), "alp", null === d ? "0" : "1");
      var e = iy();
      K(J.getInstance(), "arpa", e ? "1" : "0");
      fetch(b, ty(c, "" === d && e))
        .then(function () {
          K(J.getInstance(), "fas", "1");
        })
        .catch(function () {
          K(J.getInstance(), "faf", "1");
          a.j = !1;
          var f = d;
          f = iy() ? f : null;
          an() ? qy(b) : ry(a, b, c, f);
        });
      e && d && fetch(d, ty(c, !0));
    },
    ry = function (a, b, c, d) {
      var e = new Image(),
        f = (a.l++).toString();
      a.g.set(f, e);
      e.onload = e.onerror = function () {
        a.g.delete(f);
      };
      c && (e.referrerPolicy = "no-referrer");
      null != d && (e.attributionSrc = d);
      e.src = b;
    },
    qy = function (a) {
      new ey().get({ url: a, timeout: new Fx() });
    };
  var uy = {
    AUTOPLAY_DISALLOWED: "autoplayDisallowed",
    Wg: "beginFullscreen",
    CAN_PLAY: "canPlay",
    CAN_PLAY_THROUGH: "canPlayThrough",
    CLICK: "click",
    DURATION_CHANGE: "durationChange",
    jh: "end",
    kh: "endFullscreen",
    ERROR: "error",
    oh: "focusSkipButton",
    LOAD_START: "loadStart",
    LOADED: "loaded",
    Mh: "mediaLoadTimeout",
    Nh: "mediaPlaybackTimeout",
    PAUSE: "pause",
    PLAY: "play",
    PLAYING: "playing",
    SEEKED: "seeked",
    SEEKING: "seeking",
    Zh: "skip",
    wf: "skipShown",
    STALLED: "stalled",
    ee: "start",
    TIME_UPDATE: "timeUpdate",
    ci: "timedMetadata",
    mi: "volumeChange",
    WAITING: "waiting",
    pi: "windowFocusChanged",
    ph: "fullyLoaded",
  };
  var vy = function () {
    S.apply(this, arguments);
  };
  v(vy, S);
  vy.prototype.C = function () {
    return !1;
  };
  vy.prototype.F = function () {
    return -1;
  };
  vy.prototype.G = function () {};
  var wy = {},
    yy =
      ((wy[18] = -1),
      (wy[22] = -1),
      (wy[43] = 350),
      (wy[44] = 350),
      (wy[45] = 350),
      (wy[59] = -1),
      (wy[133] = 350),
      (wy[134] = 350),
      (wy[135] = 350),
      (wy[136] = 350),
      (wy[139] = 50),
      (wy[140] = 50),
      (wy[141] = 50),
      (wy[160] = 350),
      (wy[242] = 150),
      (wy[243] = 150),
      (wy[244] = 150),
      (wy[245] = 150),
      (wy[247] = 150),
      (wy[249] = 50),
      (wy[250] = 50),
      (wy[251] = 50),
      (wy[278] = 150),
      (wy[342] = -1),
      (wy[343] = -1),
      (wy[344] = -1),
      (wy[345] = -1),
      (wy[346] = -1),
      (wy[347] = -1),
      wy),
    zy = {},
    Ay =
      ((zy[18] = !1),
      (zy[22] = !1),
      (zy[43] = !0),
      (zy[44] = !0),
      (zy[45] = !0),
      (zy[59] = !1),
      (zy[133] = !0),
      (zy[134] = !0),
      (zy[135] = !0),
      (zy[136] = !0),
      (zy[139] = !0),
      (zy[140] = !0),
      (zy[141] = !0),
      (zy[160] = !0),
      (zy[242] = !0),
      (zy[243] = !0),
      (zy[244] = !0),
      (zy[245] = !0),
      (zy[247] = !0),
      (zy[249] = !0),
      (zy[250] = !0),
      (zy[251] = !0),
      (zy[278] = !0),
      (zy[342] = !1),
      (zy[343] = !1),
      (zy[344] = !1),
      (zy[345] = !1),
      (zy[346] = !1),
      (zy[347] = !1),
      zy),
    By = {},
    Cy =
      ((By[18] = "video/mp4"),
      (By[22] = "video/mp4"),
      (By[43] = "video/webm"),
      (By[44] = "video/webm"),
      (By[45] = "video/webm"),
      (By[59] = "video/mp4"),
      (By[133] = "video/mp4"),
      (By[134] = "video/mp4"),
      (By[135] = "video/mp4"),
      (By[136] = "video/mp4"),
      (By[139] = "audio/mp4"),
      (By[140] = "audio/mp4"),
      (By[141] = "audio/mp4"),
      (By[160] = "video/mp4"),
      (By[242] = "video/webm"),
      (By[243] = "video/webm"),
      (By[244] = "video/webm"),
      (By[245] = "video/webm"),
      (By[247] = "video/webm"),
      (By[249] = "audio/webm"),
      (By[250] = "audio/webm"),
      (By[251] = "audio/webm"),
      (By[278] = "video/webm"),
      (By[342] = "video/mp4"),
      (By[343] = "video/mp4"),
      (By[344] = "video/mp4"),
      (By[345] = "video/mp4"),
      (By[346] = "video/mp4"),
      (By[347] = "video/mp4"),
      By),
    Dy = {},
    Ey =
      ((Dy[18] = "avc1.42001E, mp4a.40.2"),
      (Dy[22] = "avc1.64001F, mp4a.40.2"),
      (Dy[43] = "vp8, vorbis"),
      (Dy[44] = "vp8, vorbis"),
      (Dy[45] = "vp8, vorbis"),
      (Dy[59] = "avc1.4D001F, mp4a.40.2"),
      (Dy[133] = "avc1.4D401E"),
      (Dy[134] = "avc1.4D401E"),
      (Dy[135] = "avc1.4D401E"),
      (Dy[136] = "avc1.4D401E"),
      (Dy[139] = "mp4a.40.2"),
      (Dy[140] = "mp4a.40.2"),
      (Dy[141] = "mp4a.40.2"),
      (Dy[160] = "avc1.4D401E"),
      (Dy[242] = "vp9"),
      (Dy[243] = "vp9"),
      (Dy[244] = "vp9"),
      (Dy[245] = "vp9"),
      (Dy[247] = "vp9"),
      (Dy[249] = "opus"),
      (Dy[250] = "opus"),
      (Dy[251] = "opus"),
      (Dy[278] = "vp9"),
      (Dy[342] = "avc1.42E01E, mp4a.40.2"),
      (Dy[343] = "avc1.42E01E, mp4a.40.2"),
      (Dy[344] = "avc1.42E01E, mp4a.40.2"),
      (Dy[345] = "avc1.42E01E, mp4a.40.2"),
      (Dy[346] = "avc1.42E01E, mp4a.40.2"),
      (Dy[347] = "avc1.4D001F, mp4a.40.2"),
      Dy);
  var Fy = RegExp("/itag/(\\d+)/");
  function Gy(a) {
    var b = Number(li(a, "itag"));
    return b ? b : (a = a.match(Fy)) && 2 === a.length ? Number(a[1]) : null;
  }
  function Hy(a) {
    var b = Cy[a];
    a = Ey[a];
    b
      ? ((b = Kh(b).toLowerCase()),
        (b = a ? b + '; codecs="' + Kh(a) + '"' : b))
      : (b = "");
    return b;
  }
  function Iy(a, b) {
    if ("function" === typeof CustomEvent)
      return new CustomEvent(a, { detail: b });
    var c = document.createEvent("CustomEvent");
    c.initCustomEvent(a, !1, !0, b);
    return c;
  }
  var Jy = function (a, b) {
    vy.call(this);
    var c = this;
    this.j = b;
    this.B = this.l = this.g = 0;
    this.o = null;
    this.uri = new T(a);
    this.state = 0;
    var d;
    this.H = null == (d = this.j) ? void 0 : d.initialize();
    Hn(this, function () {
      Gn(c.j);
    });
  };
  v(Jy, vy);
  Jy.prototype.F = function () {
    return this.g;
  };
  Jy.prototype.C = function () {
    return 3 === this.state;
  };
  Jy.prototype.G = function (a) {
    1 === this.state
      ? ((this.g += a), (this.state = 2))
      : 0 === this.state && ((this.g += a), (this.state = 1), Ky(this));
  };
  var Ky = function (a) {
      Ha(function (b) {
        if (1 == b.g) return 2 === a.state && (a.state = 1), ya(b, Ly(a), 4);
        var c = 3 < a.B;
        if (c) {
          null === a.o && (a.o = 400);
          var d = Iy("media_source_error", {
            code:
              0 < a.l
                ? MediaError.MEDIA_ERR_NETWORK
                : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
            message:
              'Response code "' +
              a.o +
              '" with ' +
              a.g +
              " bytes requested and " +
              a.l +
              " bytes loaded",
          });
          a.dispatchEvent(d);
        }
        a.l < a.g && 3 !== a.state && !c
          ? (b.g = 1)
          : (3 !== a.state && (a.state = 0), (b.g = 0));
      });
    },
    Ly = function (a) {
      var b;
      return Ha(function (c) {
        switch (c.g) {
          case 1:
            b = a.l + "-" + (a.g - 1);
            Kw(a.uri, "range", b);
            if (!a.j) {
              c.g = 2;
              break;
            }
            return ya(c, a.H, 3);
          case 3:
            return c.return(My(a));
          case 2:
            return (c.l = 4), ya(c, Ny(a), 6);
          case 6:
            za(c);
            break;
          case 4:
            Aa(c), a.B++, (c.g = 0);
        }
      });
    },
    My = function (a) {
      var b;
      return Ha(function (c) {
        switch (c.g) {
          case 1:
            return a.j ? ya(c, a.j.Sb(a.uri), 2) : c.return(Promise.reject());
          case 2:
            if ((b = c.j))
              return b.xa && (a.state = 3), Oy(a, b.video), c.return();
            c.l = 3;
            return ya(c, Ny(a), 5);
          case 5:
            za(c);
            break;
          case 3:
            Aa(c), a.B++, (c.g = 0);
        }
      });
    },
    Ny = function (a) {
      var b, c, d, e, f, g, h;
      return Ha(function (k) {
        if (1 == k.g)
          return (b = 0), (c = a.g - a.l), ya(k, fetch(a.uri.toString()), 2);
        d = k.j;
        if (400 <= d.status)
          return (
            K(J.getInstance(), "lvlfes", d.status.toString()),
            (a.o = d.status),
            k.return(Promise.reject())
          );
        f = null == (e = d.body) ? void 0 : e.getReader();
        if (!f) return L("lvlmr"), (a.o = d.status), k.return(Promise.reject());
        g = [];
        h = function () {
          var n, m, r, p, t, w;
          return Ha(function (y) {
            if (1 == y.g) return ya(y, f.read(), 2);
            n = y.j;
            m = n.done;
            r = n.value;
            if (m) return (p = b < c), Py(a, g, p), y.return();
            g.push(r);
            b += null == (t = r) ? void 0 : t.length;
            Oy(a, null == (w = r) ? void 0 : w.buffer);
            return ya(y, h(), 0);
          });
        };
        return ya(k, h(), 0);
      });
    },
    Py = function (a, b, c) {
      c && ((a.state = 3), Oy(a, new ArrayBuffer(0)));
      var d = new Uint8Array(
          b.reduce(function (g, h) {
            return g + h.length;
          }, 0)
        ),
        e = 0;
      b = u(b);
      for (var f = b.next(); !f.done; f = b.next())
        (f = f.value), d.set(f, e), (e += f.length);
      a.j && 0 < d.buffer.byteLength && a.j.kc(d.buffer, a.uri, 0, c);
    },
    Oy = function (a, b) {
      null !== b &&
        ((b = b.slice(0)),
        (a.l += b.byteLength),
        a.dispatchEvent({ type: "progress", hd: b }));
    };
  Jy.prototype.M = function () {
    var a;
    (null == (a = this.j) ? 0 : a.Sa()) && this.j.close();
    vy.prototype.M.call(this);
  };
  var Ry = function (a) {
      this.uri = a;
      this.g = Qy(a);
    },
    Qy = function (a) {
      return new Map(
        a.l.split("/").reduce(function (b, c, d, e) {
          d % 2 && b.set(e[d - 1], c);
          return b;
        }, new Map())
      );
    };
  Ry.prototype.getId = function () {
    return Sy(this, "id");
  };
  var Ty = function (a) {
      a = a.uri.g.get("range");
      if (!a) return null;
      a = a.split("-")[0];
      return !a || isNaN(Number(a)) ? null : Number(a);
    },
    Sy = function (a, b) {
      var c = a.uri.g.get(b);
      return c ? c : (a = a.g.get(b)) ? a : null;
    };
  var Uy = function () {};
  var Vy = ["doubleclick.net"];
  function Wy() {
    if (Kb() || A("iPad") || A("iPod")) return !1;
    if (Hb()) {
      if (void 0 === Sw) {
        a: {
          if (void 0 === Qw) {
            if (Uw) {
              var a = pb(Tw(), "Safari");
              var b = new T(window.location.href).g.Db("js");
              b: {
                if (
                  (b = b.length ? b[0] : "") &&
                  0 == b.lastIndexOf("afma-", 0)
                ) {
                  var c = b.lastIndexOf("v");
                  if (
                    -1 < c &&
                    (b = b
                      .substr(c + 1)
                      .match(/^(\d+\.\d+\.\d+|^\d+\.\d+|^\d+)(-.*)?$/))
                  ) {
                    b = b[1];
                    break b;
                  }
                }
                b = "0.0.0";
              }
              if (!a || "0.0.0" !== b) {
                a = Qw = !0;
                break a;
              }
            }
            Qw = !1;
          }
          a = Qw;
        }
        a ||
          (void 0 === Rw && (Rw = pb(Tw(), "afma-sdk-a") ? !0 : !1), (a = Rw));
        Sw = a;
      }
      return Sw ? !0 : fi() ? !1 : Xy();
    }
    a =
      Lb() ||
      (Gb() ? "Linux" === xb.platform : A("Linux")) ||
      (Gb() ? "Windows" === xb.platform : A("Windows")) ||
      (Gb() ? "Chrome OS" === xb.platform : A("CrOS"));
    return (M(tk) || M(rk) || M(sk)) && a && Fb() ? Xy() : !1;
  }
  function Xy() {
    var a = !1,
      b = new T(window.location.href).j;
    Vy.forEach(function (c) {
      b.includes(c) && (a = !0);
    });
    return a;
  }
  var Yy,
    az = function (a, b, c) {
      if ("number" === typeof a) var d = { name: Zy(a) };
      else (d = a), (a = $y(a.name));
      this.code = a;
      this.g = d;
      b = "Error " + b + ": " + this.getName();
      c && (b += ", " + c);
      db.call(this, b);
    };
  bb(az, db);
  az.prototype.getName = function () {
    return this.g.name || "";
  };
  var bz = {
      yf: 1,
      Rh: 2,
      NOT_FOUND_ERR: 3,
      bf: 4,
      ff: 5,
      Sh: 6,
      xf: 7,
      ABORT_ERR: 8,
      uf: 9,
      fi: 10,
      TIMEOUT_ERR: 11,
      tf: 12,
      INVALID_ACCESS_ERR: 13,
      INVALID_STATE_ERR: 14,
    },
    cz = (x.g || x.j || bz).yf,
    dz = (x.g || x.j || bz).NOT_FOUND_ERR,
    ez = (x.g || x.j || bz).bf,
    fz = (x.g || x.j || bz).ff,
    gz = (x.g || x.j || bz).xf,
    hz = (x.g || x.j || bz).ABORT_ERR,
    iz = (x.g || x.j || bz).uf,
    jz = (x.g || x.j || bz).TIMEOUT_ERR,
    kz = (x.g || x.j || bz).tf,
    lz = (x.DOMException || bz).INVALID_ACCESS_ERR,
    mz = (x.DOMException || bz).INVALID_STATE_ERR,
    $y = function (a) {
      switch (a) {
        case "UnknownError":
          return cz;
        case "NotFoundError":
          return dz;
        case "ConstraintError":
          return ez;
        case "DataError":
          return fz;
        case "TransactionInactiveError":
          return gz;
        case "AbortError":
          return hz;
        case "ReadOnlyError":
          return iz;
        case "TimeoutError":
          return jz;
        case "QuotaExceededError":
          return kz;
        case "InvalidAccessError":
          return lz;
        case "InvalidStateError":
          return mz;
        default:
          return cz;
      }
    },
    Zy = function (a) {
      switch (a) {
        case cz:
          return "UnknownError";
        case dz:
          return "NotFoundError";
        case ez:
          return "ConstraintError";
        case fz:
          return "DataError";
        case gz:
          return "TransactionInactiveError";
        case hz:
          return "AbortError";
        case iz:
          return "ReadOnlyError";
        case jz:
          return "TimeoutError";
        case kz:
          return "QuotaExceededError";
        case lz:
          return "InvalidAccessError";
        case mz:
          return "InvalidStateError";
        default:
          return "UnknownError";
      }
    },
    nz = function (a, b) {
      return "error" in a
        ? new az(a.error, b)
        : new az({ name: "UnknownError" }, b);
    },
    oz = function (a, b) {
      return "name" in a
        ? new az(a, b + ": " + a.message)
        : new az({ name: "UnknownError" }, b);
    };
  var pz = function (a) {
      this.g = a;
    },
    qz = x.IDBKeyRange || x.webkitIDBKeyRange;
  function rz() {} /*

 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: MIT
*/
  var sz = function (a, b) {
    this.o = [];
    this.H = a;
    this.G = b || null;
    this.A = this.l = !1;
    this.j = void 0;
    this.N = this.J = this.C = !1;
    this.B = 0;
    this.g = null;
    this.I = 0;
  };
  bb(sz, rz);
  sz.prototype.cancel = function (a) {
    if (this.l) this.j instanceof sz && this.j.cancel();
    else {
      if (this.g) {
        var b = this.g;
        delete this.g;
        a ? b.cancel(a) : (b.I--, 0 >= b.I && b.cancel());
      }
      this.H ? this.H.call(this.G, this) : (this.N = !0);
      this.l || tz(this, new uz(this));
    }
  };
  sz.prototype.F = function (a, b) {
    this.C = !1;
    vz(this, a, b);
  };
  var vz = function (a, b, c) {
      a.l = !0;
      a.j = c;
      a.A = !b;
      wz(a);
    },
    yz = function (a) {
      if (a.l) {
        if (!a.N) throw new xz(a);
        a.N = !1;
      }
    };
  sz.prototype.wa = function (a) {
    yz(this);
    vz(this, !0, a);
  };
  var tz = function (a, b) {
      yz(a);
      vz(a, !1, b);
    },
    Az = function (a, b) {
      return zz(a, b, null);
    },
    zz = function (a, b, c, d) {
      a.o.push([b, c, d]);
      a.l && wz(a);
      return a;
    };
  sz.prototype.then = function (a, b, c) {
    var d,
      e,
      f = new Bs(function (g, h) {
        e = g;
        d = h;
      });
    zz(
      this,
      e,
      function (g) {
        g instanceof uz ? f.cancel() : d(g);
        return Bz;
      },
      this
    );
    return f.then(a, b, c);
  };
  sz.prototype.$goog_Thenable = !0;
  var Cz = function (a) {
      return Sb(a.o, function (b) {
        return "function" === typeof b[1];
      });
    },
    Bz = {},
    wz = function (a) {
      if (a.B && a.l && Cz(a)) {
        var b = a.B,
          c = Dz[b];
        c && (x.clearTimeout(c.g), delete Dz[b]);
        a.B = 0;
      }
      a.g && (a.g.I--, delete a.g);
      b = a.j;
      for (var d = (c = !1); a.o.length && !a.C; ) {
        var e = a.o.shift(),
          f = e[0],
          g = e[1];
        e = e[2];
        if ((f = a.A ? g : f))
          try {
            var h = f.call(e || a.G, b);
            h === Bz && (h = void 0);
            void 0 !== h &&
              ((a.A = a.A && (h == b || h instanceof Error)), (a.j = b = h));
            if (
              zs(b) ||
              ("function" === typeof x.Promise && b instanceof x.Promise)
            )
              (d = !0), (a.C = !0);
          } catch (k) {
            (b = k), (a.A = !0), Cz(a) || (c = !0);
          }
      }
      a.j = b;
      d &&
        ((h = Za(a.F, a, !0)),
        (d = Za(a.F, a, !1)),
        b instanceof sz ? (zz(b, h, d), (b.J = !0)) : b.then(h, d));
      c && ((b = new Ez(b)), (Dz[b.g] = b), (a.B = b.g));
    },
    xz = function () {
      db.call(this);
    };
  bb(xz, db);
  xz.prototype.message = "Deferred has already fired";
  xz.prototype.name = "AlreadyCalledError";
  var uz = function () {
    db.call(this);
  };
  bb(uz, db);
  uz.prototype.message = "Deferred was canceled";
  uz.prototype.name = "CanceledError";
  var Ez = function (a) {
    this.g = x.setTimeout(Za(this.l, this), 0);
    this.j = a;
  };
  Ez.prototype.l = function () {
    delete Dz[this.g];
    throw this.j;
  };
  var Dz = {};
  var Fz = function () {
    S.call(this);
  };
  bb(Fz, S);
  Fz.prototype.g = null;
  Fz.prototype.next = function (a) {
    if (a) this.g["continue"](a);
    else this.g["continue"]();
  };
  Fz.prototype.remove = function () {
    var a = new sz();
    try {
      var b = this.g["delete"]();
    } catch (c) {
      return tz(a, oz(c, "deleting via cursor")), a;
    }
    b.onsuccess = function () {
      a.wa();
    };
    b.onerror = function (c) {
      tz(a, nz(c.target, "deleting via cursor"));
    };
    return a;
  };
  Fz.prototype.getValue = function () {
    return this.g.value;
  };
  var Gz = function (a, b) {
    var c = new Fz();
    try {
      var d = a.openCursor(b ? b.g : null);
    } catch (e) {
      throw (c.X(), oz(e, a.name));
    }
    d.onsuccess = function (e) {
      c.g = e.target.result || null;
      c.g ? c.dispatchEvent("n") : c.dispatchEvent("c");
    };
    d.onerror = function () {
      c.dispatchEvent("e");
    };
    return c;
  };
  var Hz = function (a) {
    this.g = a;
  };
  Hz.prototype.getName = function () {
    return this.g.name;
  };
  var Iz = function (a, b, c) {
    var d = new sz();
    try {
      var e = a.g.get(c);
    } catch (f) {
      return (b += " with key " + Fh(c)), tz(d, oz(f, b)), d;
    }
    e.onsuccess = function (f) {
      d.wa(f.target.result);
    };
    e.onerror = function (f) {
      b += " with key " + Fh(c);
      tz(d, nz(f.target, b));
    };
    return d;
  };
  Hz.prototype.get = function (a) {
    return Iz(this, "getting from index " + this.getName(), a);
  };
  var Jz = function (a, b) {
    return Gz(a.g, b);
  };
  var Kz = function (a) {
    this.g = a;
  };
  Kz.prototype.getName = function () {
    return this.g.name;
  };
  var Lz = function (a, b, c, d, e) {
      var f = new sz();
      try {
        var g = e ? a.g[b](d, e) : a.g[b](d);
      } catch (h) {
        return (
          (c += Fh(d)), e && (c += ", with key " + Fh(e)), tz(f, oz(h, c)), f
        );
      }
      g.onsuccess = function (h) {
        f.wa(h.target.result);
      };
      g.onerror = function (h) {
        c += Fh(d);
        e && (c += ", with key " + Fh(e));
        tz(f, nz(h.target, c));
      };
      return f;
    },
    Mz = function (a, b) {
      return Lz(a, "put", "putting into " + a.getName() + " with value", b);
    };
  Kz.prototype.add = function (a, b) {
    return Lz(
      this,
      "add",
      "adding into " + this.getName() + " with value ",
      a,
      b
    );
  };
  Kz.prototype.remove = function (a) {
    var b = new sz();
    try {
      var c = this.g["delete"](a instanceof pz ? a.g : a);
    } catch (e) {
      return (
        (c = "removing from " + this.getName() + " with key " + Fh(a)),
        tz(b, oz(e, c)),
        b
      );
    }
    c.onsuccess = function () {
      b.wa();
    };
    var d = this;
    c.onerror = function (e) {
      var f = "removing from " + d.getName() + " with key " + Fh(a);
      tz(b, nz(e.target, f));
    };
    return b;
  };
  Kz.prototype.get = function (a) {
    var b = new sz();
    try {
      var c = this.g.get(a);
    } catch (e) {
      return (
        (c = "getting from " + this.getName() + " with key " + Fh(a)),
        tz(b, oz(e, c)),
        b
      );
    }
    c.onsuccess = function (e) {
      b.wa(e.target.result);
    };
    var d = this;
    c.onerror = function (e) {
      var f = "getting from " + d.getName() + " with key " + Fh(a);
      tz(b, nz(e.target, f));
    };
    return b;
  };
  Kz.prototype.clear = function () {
    var a = "clearing store " + this.getName(),
      b = new sz();
    try {
      var c = this.g.clear();
    } catch (d) {
      return tz(b, oz(d, a)), b;
    }
    c.onsuccess = function () {
      b.wa();
    };
    c.onerror = function (d) {
      tz(b, nz(d.target, a));
    };
    return b;
  };
  var Nz = function (a) {
    try {
      return new Hz(a.g.index("timestamp"));
    } catch (b) {
      throw oz(b, "getting index timestamp");
    }
  };
  var Oz = function (a, b) {
    S.call(this);
    this.g = a;
    this.l = b;
    this.j = new Kx(this);
    this.j.O(this.g, "complete", Za(this.dispatchEvent, this, "complete"));
    this.j.O(this.g, "abort", Za(this.dispatchEvent, this, "abort"));
    this.j.O(this.g, "error", this.hf);
  };
  bb(Oz, S);
  l = Oz.prototype;
  l.hf = function (a) {
    a.target instanceof az
      ? this.dispatchEvent({ type: "error", target: a.target })
      : this.dispatchEvent({
          type: "error",
          target: nz(a.target, "in transaction"),
        });
  };
  l.objectStore = function (a) {
    try {
      return new Kz(this.g.objectStore(a));
    } catch (b) {
      throw oz(b, "getting object store " + a);
    }
  };
  l.commit = function (a) {
    if (this.g.commit || !a)
      try {
        this.g.commit();
      } catch (b) {
        throw oz(b, "cannot commit the transaction");
      }
  };
  l.wait = function () {
    var a = new sz();
    $r(this, "complete", Za(a.wa, a));
    var b = $r(this, "abort", function () {
      is(c);
      tz(a, new az(hz, "waiting for transaction to complete"));
    });
    var c = $r(this, "error", function (e) {
      is(b);
      tz(a, e.target);
    });
    var d = this.l;
    return Az(a, function () {
      return d;
    });
  };
  l.abort = function () {
    this.g.abort();
  };
  l.M = function () {
    Oz.Fa.M.call(this);
    this.j.X();
  };
  var Pz = function (a) {
    S.call(this);
    this.g = a;
    this.j = new Kx(this);
    this.j.O(this.g, "abort", Za(this.dispatchEvent, this, "abort"));
    this.j.O(this.g, "error", this.jf);
    this.j.O(this.g, "versionchange", this.Lf);
    this.j.O(this.g, "close", Za(this.dispatchEvent, this, "close"));
  };
  bb(Pz, S);
  l = Pz.prototype;
  l.Cd = !0;
  l.jf = function (a) {
    a = (a = a.target) && a.error;
    this.dispatchEvent({ type: "error", errorCode: a && a.severity });
  };
  l.Lf = function (a) {
    this.dispatchEvent(new Qz(a.oldVersion, a.newVersion));
  };
  l.close = function () {
    this.Cd && (this.g.close(), (this.Cd = !1));
  };
  l.Sa = function () {
    return this.Cd;
  };
  l.getName = function () {
    return this.g.name;
  };
  l.getVersion = function () {
    return Number(this.g.version);
  };
  var Rz = function (a) {
    var b = ["MediaSourceVideoChunk"];
    try {
      var c = a.g.transaction(b, "readwrite");
      return new Oz(c, a);
    } catch (d) {
      throw oz(d, "creating transaction");
    }
  };
  Pz.prototype.M = function () {
    Pz.Fa.M.call(this);
    this.j.X();
  };
  var Qz = function (a, b) {
    Lr.call(this, "versionchange");
    this.oldVersion = a;
    this.newVersion = b;
  };
  bb(Qz, Lr);
  var Sz = function (a) {
    var b = new sz();
    void 0 == Yy &&
      (Yy =
        x.indexedDB || x.mozIndexedDB || x.webkitIndexedDB || x.moz_indexedDB);
    var c = Yy.open("IndexedDbVideoChunkPersistentStorage", 6);
    c.onsuccess = function (d) {
      d = new Pz(d.target.result);
      b.wa(d);
    };
    c.onerror = function (d) {
      tz(
        b,
        nz(d.target, "opening database IndexedDbVideoChunkPersistentStorage")
      );
    };
    c.onupgradeneeded = function (d) {
      if (a) {
        var e = new Pz(d.target.result);
        a(
          new Qz(d.oldVersion, d.newVersion),
          e,
          new Oz(d.target.transaction, e)
        );
      }
    };
    c.onblocked = function () {};
    return b;
  };
  var Tz = function () {
    S.apply(this, arguments);
    this.g = null;
  };
  v(Tz, S);
  Tz.prototype.initialize = function () {
    var a = this;
    return Promise.resolve(Sz(this.j)).then(
      function (b) {
        a.g = b;
      },
      function (b) {
        K(J.getInstance(), "codf", b.message);
      }
    );
  };
  Tz.prototype.Sa = function () {
    return null !== this.g && this.g.Sa();
  };
  Tz.prototype.close = function () {
    var a = this;
    return new Promise(function (b) {
      Uz(a, b);
    })
      .then(function () {
        return Vz();
      })
      .then(function () {
        a.g.close();
      });
  };
  var Vz = function () {
    var a;
    return (null == (a = navigator.storage) ? 0 : a.estimate)
      ? navigator.storage.estimate().then(function (b) {
          K(J.getInstance(), "csue", String(b.usage));
        })
      : Promise.resolve(void 0);
  };
  Tz.prototype.Sb = function (a) {
    return (a = Wz(a, 0)) ? Xz(this, Yz(a), a.Ec) : Promise.resolve(null);
  };
  Tz.prototype.kc = function (a, b, c, d) {
    (b = Wz(b, c))
      ? ((c = b.startIndex),
        Zz(this, {
          yi: Yz(b),
          startIndex: c,
          wc: c + a.byteLength - 1,
          Ec: b.Ec,
          timestamp: new Date(Date.now()),
          xa: d,
          vb: b.vb,
          video: a,
        }))
      : Promise.resolve(void 0);
  };
  Tz.prototype.j = function (a, b) {
    if (b.g.objectStoreNames.contains("MediaSourceVideoChunk"))
      try {
        b.g.deleteObjectStore("MediaSourceVideoChunk");
      } catch (d) {
        throw oz(d, "deleting object store MediaSourceVideoChunk");
      }
    a = { keyPath: "cacheId" };
    try {
      var c = new Kz(b.g.createObjectStore("MediaSourceVideoChunk", a));
    } catch (d) {
      throw oz(d, "creating object store MediaSourceVideoChunk");
    }
    b = { unique: !1 };
    try {
      c.g.createIndex("timestamp", "timestamp", b);
    } catch (d) {
      throw oz(d, "creating new index timestamp with key path timestamp");
    }
  };
  var Uz = function (a, b) {
      var c = new Date(Date.now());
      c.setDate(c.getDate() - 30);
      c = new pz(qz.upperBound(c, void 0));
      var d = Jz(Nz(Rz(a.g).objectStore("MediaSourceVideoChunk")), c),
        e = d.O("n", function () {
          d.remove();
          d.next();
        });
      $r(d, "c", function () {
        is(e);
        b();
      });
    },
    Wz = function (a, b) {
      var c = new Ry(a);
      a = c.getId();
      var d = Sy(c, "itag"),
        e = Sy(c, "source"),
        f = Sy(c, "lmt");
      c = Ty(c);
      var g = [];
      a
        ? d
          ? e
            ? f
              ? null === c && g.push("startIndex")
              : g.push("lmt")
            : g.push("source")
          : g.push("itag")
        : g.push("videoId");
      return 0 < g.length
        ? (K(J.getInstance(), "civp", g.join("-")), null)
        : { Og: a, vb: d, source: e, Ec: f, startIndex: c + b };
    },
    Yz = function (a) {
      for (
        var b = [a.Og, a.source, a.startIndex].join(), c = 0, d = 0;
        d < b.length;
        d++
      )
        c = (Math.imul(31, c) + b.charCodeAt(d)) | 0;
      return c.toString() + "," + a.vb;
    },
    Xz = function (a, b, c) {
      var d = Rz(a.g).objectStore("MediaSourceVideoChunk");
      return Promise.resolve(d.get(b)).then(
        function (e) {
          if (!e) return K(J.getInstance(), "cenf", "1"), null;
          if (e.Ec !== c)
            return (
              K(J.getInstance(), "cdl", "1"),
              d.remove(b).then(null, function (f) {
                K(J.getInstance(), "crdlvf", f.message);
              }),
              null
            );
          K(J.getInstance(), "cefml", "1");
          return { vb: e.vb, wc: e.wc, xa: e.xa, video: e.video };
        },
        function (e) {
          K(J.getInstance(), "cgvf", e.message);
          return null;
        }
      );
    },
    Zz = function (a, b) {
      a = Rz(a.g).objectStore("MediaSourceVideoChunk");
      Promise.resolve(Mz(a, b)).then(
        function () {
          K(J.getInstance(), "cavs", "1");
        },
        function (c) {
          K(J.getInstance(), "cavf", c.message);
        }
      );
    };
  var $z = function (a) {
    vy.call(this);
    var b = this;
    this.H = this.j = this.g = 0;
    this.o = this.J = null;
    this.uri = new T(a);
    this.state = 0;
    this.l = (this.B = Wy() && !Zw(this.uri)) ? Wv(Tz) : null;
    Hn(this, function () {
      Gn(b.l);
    });
    this.J = this.B ? this.l.initialize() : null;
  };
  v($z, vy);
  $z.prototype.F = function () {
    return this.g;
  };
  $z.prototype.C = function () {
    return 3 === this.state;
  };
  $z.prototype.G = function (a) {
    1 === this.state
      ? ((this.g += a), (this.state = 2))
      : 0 === this.state && ((this.g += a), (this.state = 1), aA(this));
  };
  var aA = function (a) {
      Ha(function (b) {
        if (1 == b.g) return 2 === a.state && (a.state = 1), ya(b, bA(a), 4);
        var c = 3 < a.H;
        if (c && null !== a.o) {
          var d = Iy("media_source_error", {
            code:
              0 < a.j
                ? MediaError.MEDIA_ERR_NETWORK
                : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
            message:
              'Response code "' +
              a.o +
              '" with ' +
              a.g +
              " bytes requested and " +
              a.j +
              " bytes loaded",
          });
          a.dispatchEvent(d);
        }
        a.j < a.g && 3 !== a.state && !c
          ? (b.g = 1)
          : (3 !== a.state && (a.state = 0), (b.g = 0));
      });
    },
    bA = function (a) {
      var b;
      return Ha(function (c) {
        switch (c.g) {
          case 1:
            b = a.j + "-" + (a.g - 1);
            Kw(a.uri, "range", b);
            if (!a.B) {
              c.g = 2;
              break;
            }
            return ya(c, a.J, 3);
          case 3:
            return c.return(cA(a));
          case 2:
            return (c.l = 4), ya(c, dA(a), 6);
          case 6:
            za(c);
            break;
          case 4:
            Aa(c), eA(a), (c.g = 0);
        }
      });
    },
    cA = function (a) {
      var b;
      return Ha(function (c) {
        switch (c.g) {
          case 1:
            return ya(c, a.l.Sb(a.uri), 2);
          case 2:
            if ((b = c.j)) {
              b.xa && (a.state = 3);
              fA(a, b.video, 0);
              c.g = 0;
              break;
            }
            c.l = 4;
            return ya(c, dA(a), 6);
          case 6:
            za(c);
            break;
          case 4:
            Aa(c), eA(a), (c.g = 0);
        }
      });
    },
    eA = function (a) {
      if (M(Nk)) {
        a: {
          var b = new Ry(a.uri);
          var c, d;
          if (
            null == (c = b.uri)
              ? 0
              : null == (d = c.l)
              ? 0
              : d.startsWith("/videoplayback")
          ) {
            var e = (c = Sy(b, "mn")) ? c.split(",") : null;
            d = Sy(b, "fvip");
            c = b.uri.G();
            if (e && d) {
              var f = (Number(Sy(b, "fallback_count")) || 0) + 1;
              if ((e = e[f])) {
                c.j = "r" + d + "---" + e + ".googlevideo.com";
                Kw(c, "fallback_count", f);
                b = c;
                break a;
              }
            }
            var g, h;
            d =
              Number(
                (null !=
                (h = null == (g = c.g.get("cmo")) ? void 0 : g.split("="))
                  ? h
                  : [])[1]
              ) || 0;
            b.uri.j.match(/^r{1,2}(\d+)---(.+)\.googlevideo.com$/) &&
              (c.j = "redirector.googlevideo.com");
            Kw(c, "cmo", "pf=" + (d + 1));
            b = c;
          } else b = b.uri;
        }
        a.uri = b;
        a.dispatchEvent(Iy("bandaid_fallback_count"));
      }
      a.H++;
    },
    dA = function (a) {
      return new Promise(function (b, c) {
        var d = new XMLHttpRequest(),
          e = 0,
          f = a.g - a.j;
        d.addEventListener("load", function () {
          L("lvlcl");
          if (400 <= d.status)
            K(J.getInstance(), "lvlxes", d.status.toString()),
              (a.o = d.status),
              c();
          else {
            var g = d.response;
            g.byteLength < f && (a.state = 3);
            var h = fA(a, g, e);
            e += h;
            a.B && 0 < g.byteLength && a.l.kc(g, a.uri, 0, g.byteLength < f);
            b();
          }
        });
        d.addEventListener("timeout", function () {
          L("lvlct");
          a.o = d.status;
          c();
        });
        d.addEventListener("error", function () {
          L("lvlce");
          a.o = d.status;
          c();
        });
        d.addEventListener("progress", function () {
          if (400 <= d.status) a.o = d.status;
          else {
            var g = fA(a, d.response, e);
            e += g;
          }
        });
        d.responseType = "arraybuffer";
        d.open("get", a.uri.toString());
        d.send(null);
      });
    },
    fA = function (a, b, c) {
      if (null === b) return 0;
      b = b.slice(c);
      a.j += b.byteLength;
      a.dispatchEvent({ type: "progress", hd: b });
      return b.byteLength;
    };
  $z.prototype.M = function () {
    this.B && this.l.Sa() && this.l.close();
    vy.prototype.M.call(this);
  };
  var gA = { Ii: 2e5, Gi: 7e4, Ia: 3e5, Fi: 5e3, Pi: 5e3, Hi: 6e3 };
  function hA() {
    return !!window.MediaSource;
  }
  function iA(a) {
    return [43, 44, 45].includes(a) && Cc
      ? !1
      : Ay[a]
      ? ((a = Hy(a)), !!a && hA() && MediaSource.isTypeSupported(a))
      : !1;
  }
  var jA = function () {};
  jA.prototype.mg = function (a, b, c) {
    return 0 === c ? 1e6 : 5e3 > b - a ? 3e5 : 0;
  };
  var lA = function (a, b) {
      var c = this;
      this.g = a;
      this.index = b;
      this.j = [];
      this.g || L("msms_sbf" + this.index);
      this.g.addEventListener("updateend", function () {
        kA(c);
      });
      this.g.addEventListener("error", function () {
        L("msms_sbe" + c.index);
      });
    },
    kA = function (a) {
      if (0 < a.j.length && !a.g.updating) {
        var b = a.j.shift();
        a.g.appendBuffer(b);
      }
    };
  var mA = function () {
    this.g = this.cache = null;
  };
  l = mA.prototype;
  l.initialize = function () {
    var a = this;
    return window.caches.open("CACHE_VIDEO_CHUNK_PERSISTENT_STORAGE").then(
      function (b) {
        a.cache = b;
      },
      function (b) {
        K(J.getInstance(), "codf", b.message);
      }
    );
  };
  l.Sa = function () {
    return null !== this.cache;
  };
  l.close = function () {
    return Promise.resolve();
  };
  l.Sb = function (a) {
    var b = this;
    a = nA(this, a);
    return this.Sa() && a
      ? this.cache.match(a).then(
          function (c) {
            if (!c)
              return K(J.getInstance(), "cenf", "1"), Promise.resolve(null);
            K(J.getInstance(), "cef", "1");
            return c.arrayBuffer().then(function (d) {
              var e = Ty(b.g),
                f;
              (f = b.g.uri.g.get("range"))
                ? ((f = f.split("-")[1]),
                  (f = !f || isNaN(Number(f)) ? null : Number(f)))
                : (f = null);
              e = e + d.byteLength - 1;
              f = f > e;
              return { vb: Sy(b.g, "itag"), wc: e, xa: f, video: d };
            });
          },
          function (c) {
            K(J.getInstance(), "cgvf", c.message);
            return Promise.resolve(null);
          }
        )
      : (K(J.getInstance(), "cgvf", "1"), Promise.resolve(null));
  };
  l.kc = function (a, b) {
    b = nA(this, b);
    a = new Response(a);
    this.Sa() && b
      ? this.cache.put(b, a).then(
          function () {
            K(J.getInstance(), "cavs", "1");
          },
          function (c) {
            K(J.getInstance(), "cavf", c.message);
          }
        )
      : (K(J.getInstance(), "cavf", "1"), Promise.resolve());
  };
  var nA = function (a, b) {
    a.g = new Ry(b);
    b = a.g.getId();
    var c = Sy(a.g, "itag"),
      d = Sy(a.g, "source"),
      e = Sy(a.g, "lmt");
    a = Sy(a.g, "range");
    if (b && c && d && a)
      return new Request(
        "http://url/videoplayback?id=" +
          b +
          "&itag=" +
          c +
          "&source=" +
          d +
          "&lmt=" +
          e +
          "&range=" +
          a
      );
    K(J.getInstance(), "civp", "1");
    return null;
  };
  var qA = function (a) {
    S.call(this);
    var b = this;
    this.l = a;
    this.g = [];
    this.B = null;
    this.C = 0;
    this.L = !1;
    this.G = 0;
    this.F = [];
    if (M(yk)) {
      var c = null;
      Wy() && (M(Ak) ? (c = Wv(mA)) : (c = Wv(Tz)));
      this.o = this.l.map(function (d) {
        return Wv(Jy, d.url, Zw(d.url) ? null : c);
      });
    } else
      this.o = this.l.map(function (d) {
        return Wv($z, d.url);
      });
    this.j = Wv(MediaSource);
    this.H = function () {
      oA(b);
    };
    this.j.addEventListener("sourceopen", this.H);
    this.J = pA(this);
  };
  v(qA, S);
  var pA = function (a) {
      for (var b = [], c = 0; c < a.l.length; ++c) b.push(new jA());
      return b;
    },
    oA = function (a) {
      L("msms_oso");
      for (
        var b = { za: 0 };
        b.za < a.l.length;
        b = { Id: void 0, Fc: void 0, nb: void 0, za: b.za, Gc: void 0 }, ++b.za
      ) {
        var c = a.l[b.za];
        K(J.getInstance(), "msms_mime" + b.za, c.mimeType);
        K(J.getInstance(), "msms_cs" + b.za, c.Ia.toString());
        M(zk)
          ? ((b.Id = new lA(a.j.addSourceBuffer(c.mimeType), b.za)),
            (b.Fc = a.o[b.za]),
            b.Fc.O(
              "progress",
              (function (d) {
                return function (e) {
                  var f = d.Id,
                    g = d.Fc;
                  e = e.hd;
                  0 !== e.byteLength && (f.j.push(e), kA(f));
                  g.C() && (a.C++, a.C === a.g.length && rA(a));
                };
              })(b)
            ),
            b.Fc.O("media_source_error", function (d) {
              a.dispatchEvent(d);
            }),
            a.g.push(b.Id.g))
          : ((b.nb = a.j.addSourceBuffer(c.mimeType)),
            b.nb
              ? ((b.Gc = a.o[b.za]),
                M(yk) &&
                  b.nb.addEventListener(
                    "updateend",
                    (function (d) {
                      return function () {
                        if (0 < a.F.length && !d.nb.updating) {
                          var e = a.F.shift();
                          d.nb.appendBuffer(e);
                        }
                      };
                    })(b)
                  ),
                b.nb.addEventListener(
                  "error",
                  (function (d) {
                    return function () {
                      L("msms_sbe" + d.za);
                    };
                  })(b)
                ),
                b.Gc.O(
                  "progress",
                  (function (d) {
                    return function (e) {
                      var f = d.nb,
                        g = d.Gc;
                      e = e.hd;
                      0 !== e.byteLength &&
                        (M(yk)
                          ? f.updating
                            ? a.F.push(e)
                            : f.appendBuffer(e)
                          : f.appendBuffer(e));
                      g.C() && (a.C++, a.C === a.g.length && rA(a));
                    };
                  })(b)
                ),
                b.Gc.O("media_source_error", function (d) {
                  a.dispatchEvent(d);
                }),
                a.g.push(b.nb))
              : L("msms_sbf" + b.za));
      }
      K(J.getInstance(), "msms_ns", a.g.length.toString());
      a.L = !0;
      sA(a);
    },
    rA = function (a) {
      Promise.all(
        a.g.map(function (b) {
          return new Promise(function (c) {
            b.updating
              ? b.addEventListener("updateend", function () {
                  c();
                })
              : c();
          });
        })
      ).then(function () {
        a.j.endOfStream();
      });
    },
    sA = function (a) {
      if (a.L)
        for (var b = 0; b < a.l.length; ++b) {
          var c = a.o[b],
            d = a.g[b];
          d = 0 === d.buffered.length ? 0 : 1e3 * d.buffered.end(0);
          d = a.J[b].mg(a.G, d, c.F());
          0 !== d && c.G(d);
        }
    },
    tA = function (a) {
      a.B = qh(a.j).toString();
      return a.B;
    };
  qA.prototype.M = function () {
    this.B && window.URL.revokeObjectURL(this.B);
    for (var a = u(this.o), b = a.next(); !b.done; b = a.next()) b.value.X();
    this.j.removeEventListener("sourceopen", this.H);
    S.prototype.M.call(this);
  };
  qA.prototype.Xc = function (a) {
    this.J.filter(function () {
      return !1;
    })
      .map(function (b) {
        return b;
      })
      .forEach(function (b) {
        b.g = Object.assign({}, gA, b.g, a);
      });
  };
  var uA = RegExp(
      "/pagead/conversion|/pagead/adview|/pagead/gen_204|/activeview?|csi.gstatic.com/csi|google.com/pagead/xsul|google.com/ads/measurement/l|googleads.g.doubleclick.net/pagead/ide_cookie|googleads.g.doubleclick.net/xbbe/pixel"
    ),
    vA = RegExp("outstream.min.js"),
    wA = RegExp("outstream.min.css"),
    xA = RegExp("fonts.gstatic.com"),
    yA = RegExp(
      "googlevideo.com/videoplayback|c.2mdn.net/videoplayback|gcdn.2mdn.net/videoplayback"
    ),
    zA = RegExp("custom.elements.min.js");
  function AA(a, b) {
    var c = 0,
      d = 0,
      e = 0,
      f = 0,
      g = 0,
      h = 0,
      k = 0,
      n = !1,
      m = !1;
    if (
      "function" === typeof Na("performance.getEntriesByType", x) &&
      "transferSize" in x.PerformanceResourceTiming.prototype
    ) {
      var r = x.performance.getEntriesByType("resource");
      r = u(r);
      for (var p = r.next(); !p.done; p = r.next())
        (p = p.value),
          uA.test(p.name) ||
            ((f += 1),
            p.transferSize
              ? ((c += p.transferSize),
                p.encodedBodySize &&
                  p.transferSize < p.encodedBodySize &&
                  ((h += 1),
                  (e += p.encodedBodySize),
                  vA.test(p.name) && (n = !0),
                  wA.test(p.name) && (m = !0)),
                yA.test(p.name) && (d += p.transferSize))
              : 0 === p.transferSize && 0 === p.encodedBodySize
              ? zA.test(p.name)
                ? (c += 6686)
                : xA.test(p.name) ||
                  ((k += 1),
                  uj(J.getInstance(), {
                    event_name: "unmeasurable_asset",
                    resource_name: p.name,
                    encoded_body_size: p.encodedBodySize,
                    transfer_size: p.transferSize,
                  }))
              : ((g += 1),
                (e += p.encodedBodySize),
                vA.test(p.name) && (n = !0),
                wA.test(p.name) && (m = !0)));
      r = 0;
      if (a.duration) {
        for (p = 0; p < a.buffered.length; p++)
          r += a.buffered.end(p) - a.buffered.start(p);
        r = Math.min(r, a.duration);
      }
      uj(J.getInstance(), {
        event_name: b,
        asset_bytes: c,
        video_bytes: d,
        cached_data_bytes: e,
        js_cached: n,
        css_cached: m,
        num_assets: f,
        num_assets_cached: g,
        num_assets_cache_validated: h,
        num_assets_unmeasurable: k,
        video_played_seconds: a.currentTime.toFixed(2),
        video_muted: a.muted,
        video_seconds_loaded: r.toFixed(2),
      });
    } else K(J.getInstance(), "error", "reporting_timing_not_supported");
  }
  var BA = function (a, b, c, d) {
    this.url = a;
    this.mimeType = b;
    this.Ia = c;
    this.g = void 0 === d ? null : d;
  };
  function CA(a) {
    var b = J.getInstance(),
      c = a.getVideoPlaybackQuality && a.getVideoPlaybackQuality();
    c
      ? ((a = a.currentTime),
        K(b, "vqdf", String(c.droppedVideoFrames)),
        K(b, "vqtf", String(c.totalVideoFrames)),
        K(b, "vqfr", String(Math.round(c.totalVideoFrames / a))))
      : K(b, "vqu", "1");
  }
  var DA = function (a) {
    this.g = a;
  };
  DA.prototype.toString = function () {
    return this.g;
  };
  var EA = new DA("video_mute"),
    FA = new DA("video_caption_visibility");
  var GA = function (a) {
    Q.call(this);
    this.B = 1;
    this.l = [];
    this.A = 0;
    this.g = [];
    this.j = {};
    this.F = !!a;
  };
  bb(GA, Q);
  var HA = function (a, b, c) {
      var d = FA.toString(),
        e = a.j[d];
      e || (e = a.j[d] = []);
      var f = a.B;
      a.g[f] = d;
      a.g[f + 1] = b;
      a.g[f + 2] = c;
      a.B = f + 3;
      e.push(f);
    },
    IA = function (a, b, c) {
      var d = a.j[FA.toString()];
      if (d) {
        var e = a.g;
        (d = d.find(function (f) {
          return e[f + 1] == b && e[f + 2] == c;
        })) && a.o(d);
      }
    };
  GA.prototype.o = function (a) {
    var b = this.g[a];
    if (b) {
      var c = this.j[b];
      0 != this.A
        ? (this.l.push(a), (this.g[a + 1] = function () {}))
        : (c && Yb(c, a),
          delete this.g[a],
          delete this.g[a + 1],
          delete this.g[a + 2]);
    }
    return !!b;
  };
  GA.prototype.C = function (a, b) {
    var c = this.j[a];
    if (c) {
      for (
        var d = Array(arguments.length - 1), e = 1, f = arguments.length;
        e < f;
        e++
      )
        d[e - 1] = arguments[e];
      if (this.F)
        for (e = 0; e < c.length; e++) {
          var g = c[e];
          JA(this.g[g + 1], this.g[g + 2], d);
        }
      else {
        this.A++;
        try {
          for (e = 0, f = c.length; e < f && !this.Ca(); e++)
            (g = c[e]), this.g[g + 1].apply(this.g[g + 2], d);
        } finally {
          if ((this.A--, 0 < this.l.length && 0 == this.A))
            for (; (c = this.l.pop()); ) this.o(c);
        }
      }
    }
  };
  var JA = function (a, b, c) {
    xs(function () {
      a.apply(b, c);
    });
  };
  GA.prototype.clear = function (a) {
    if (a) {
      var b = this.j[a];
      b && (b.forEach(this.o, this), delete this.j[a]);
    } else (this.g.length = 0), (this.j = {});
  };
  GA.prototype.M = function () {
    GA.Fa.M.call(this);
    this.clear();
    this.l.length = 0;
  };
  var KA = function (a) {
    Q.call(this);
    this.g = new GA(a);
    In(this, this.g);
  };
  bb(KA, Q);
  KA.prototype.clear = function (a) {
    this.g.clear(void 0 !== a ? a.toString() : void 0);
  };
  var LA = function (a) {
    a = void 0 === a ? null : a;
    Q.call(this);
    this.g = new Kx(this);
    In(this, this.g);
    this.xb = a;
  };
  v(LA, Q);
  var MA = function (a, b, c) {
    a.xb &&
      (HA(a.xb.g, b, c),
      Hn(a, function () {
        IA(a.xb.g, b, c);
      }));
  };
  var NA = function (a, b) {
    LA.call(this, b);
    MA(
      this,
      function (c) {
        c ? (a.g.mode = "showing") : a.ib();
      },
      this
    );
  };
  v(NA, LA);
  var OA = function () {
    S.call(this);
    this.l = new Kx(this);
    In(this, this.l);
  };
  v(OA, S);
  var QA = function (a, b, c) {
    c = void 0 === c ? !0 : c;
    OA.call(this);
    a.setAttribute("crossorigin", "anonymous");
    var d = $h("TRACK");
    d.setAttribute("kind", "captions");
    d.setAttribute("src", b);
    d.setAttribute("default", "");
    a.appendChild(d);
    this.j = document.createElement("style");
    a.appendChild(this.j);
    this.g = a.textTracks[0];
    PA(this);
    c ? (this.g.mode = "showing") : this.ib();
  };
  v(QA, OA);
  var PA = function (a) {
    var b = a.g;
    document.addEventListener(
      "updateCueStyles",
      function (c) {
        a.j.textContent = c.detail.style;
      },
      !0
    );
    b.addEventListener(
      "cuechange",
      function () {
        for (var c = b.cues, d = 0; d < c.length; d++) {
          var e = c[d];
          e.align = "center";
          e.position = "auto";
        }
      },
      { once: !0 }
    );
  };
  QA.prototype.ib = function () {
    this.g.mode = "hidden";
  };
  function RA(a, b) {
    if ("undefined" !== typeof ReportingObserver) {
      var c = function (e) {
          e = u(e);
          for (var f = e.next(); !f.done; f = e.next())
            (f = f.value), a(f) && b(f);
        },
        d = new ReportingObserver(c, { buffered: !0 });
      x.addEventListener("pagehide", function () {
        c(d.takeRecords(), d);
        d.disconnect();
      });
      d.observe();
    }
  }
  function SA(a) {
    a = void 0 === a ? null : a;
    RA(
      function (b) {
        return b.body && "HeavyAdIntervention" === b.body.id;
      },
      function (b) {
        var c = b.body.message,
          d = J.getInstance();
        K(d, "ham", c);
        c.includes("CPU")
          ? K(d, "hacpu", "true")
          : c.includes("network") && K(d, "habytes", "true");
        a && a(b);
      }
    );
  }
  var TA =
      "autoplay controls crossorigin demuxedaudiosrc demuxedvideosrc loop muted playsinline poster preload src webkit-playsinline x-webkit-airplay".split(
        " "
      ),
    UA =
      "autoplay buffered controls crossOrigin currentSrc currentTime defaultMuted defaultPlaybackRate disablePictureInPicture disableRemotePlayback duration ended loop muted networkState onerror onwaitingforkey paused played playsinline poster preload preservesPitch mozPreservesPitch webkitPreservesPitch readyState seekable videoWidth videoHeight volume textTracks canPlayType captureStream getVideoPlaybackQuality load pause play requestPictureInPicture setSinkId oncanplay oncanplaythrough onload onplay onpause onended onfullscreenchange onfullscreenerror addEventListener dispatchEvent removeEventListener requestFullscreen".split(
        " "
      ),
    VA = { childList: !0 },
    WA = !RegExp("^\\s*class\\s*\\{\\s*\\}\\s*$").test(
      function () {}.toString()
    ),
    XA = HTMLElement;
  WA &&
    ((XA = function () {
      var a = Object.getPrototypeOf(this).constructor;
      return x.Reflect.construct(HTMLElement, [], a);
    }),
    Object.setPrototypeOf(XA, HTMLElement),
    Object.setPrototypeOf(XA.prototype, HTMLElement.prototype));
  var YA = function (a) {
      if (null !== a) {
        a = u(a);
        for (var b = a.next(); !b.done; b = a.next())
          if (((b = b.value), b.nodeName === "TRACK".toString())) return b;
      }
      return null;
    },
    ZA = function (a, b) {
      this.code = a;
      this.message = void 0 === b ? "" : b;
    },
    $A = function (a) {
      ZA.call(
        this,
        MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
        void 0 === a ? "" : a
      );
    };
  v($A, ZA);
  var dB = function (a, b) {
    b = void 0 === b ? !1 : b;
    var c = XA.call(this) || this;
    K(J.getInstance(), "ulv", "1");
    c.Lg = b;
    c.sa = null;
    c.Be = null;
    c.ge = null;
    c.T = $h("VIDEO");
    aB(c);
    c.xb = a || new KA();
    bB(c);
    c.sc = null;
    cB(c);
    c.attachShadow({ mode: "open" });
    c.shadowRoot.appendChild(c.T);
    SA(function () {
      K(J.getInstance(), "has", c.src || c.bb);
      K(J.getInstance(), "hat", String(c.T.currentTime));
    });
    c.Vc = !1;
    c.Fe = !1;
    c.Zb = null;
    c.cd = null;
    c.Mg = !1;
    c.Le = !1;
    c.Ci = null;
    c.Nb = null;
    return c;
  };
  v(dB, XA);
  var eB = function (a) {
    a.T.load();
    M(Pk) && a.T.dispatchEvent(new Event("canplaythrough"));
  };
  dB.prototype.attributeChangedCallback = function (a, b, c) {
    switch (a) {
      case "src":
        fB(this, c);
        break;
      case "demuxedaudiosrc":
      case "demuxedvideosrc":
        gB(this);
        break;
      case "muted":
        this.T[a] = "" === c ? !0 : !!c;
        hB(this, a, c);
        break;
      default:
        hB(this, a, c);
    }
  };
  dB.prototype.Xc = function (a) {
    this.Nb = a;
    var b;
    null == (b = this.sa) || b.Xc(a);
  };
  var hB = function (a, b, c) {
      c !== a.T.getAttribute(b) &&
        (null === c ? a.T.removeAttribute(b) : a.T.setAttribute(b, c));
    },
    iB = function (a) {
      a.sa &&
        (a.T.removeEventListener("timeupdate", a.Zb), a.sa.X(), (a.sa = null));
    },
    jB = function (a, b) {
      a.ge = b;
      a.T.dispatchEvent(new Event("error"));
    },
    aB = function (a) {
      kB(a);
      lB(a);
      a.T.addEventListener("loadedmetadata", function () {
        a.cd = lx(a);
        a.cd.then(function (b) {
          var c = a.T.videoWidth;
          var d = a.T.videoHeight,
            e = b.width,
            f = b.height;
          0 < c && 0 < d && 0 < e && 0 < f
            ? ((b = b.width / b.height),
              (c /= d),
              (c =
                0.97 <= Math.min(c, b) / Math.max(c, b) ? "cover" : "contain"))
            : (c = null);
          null !== c && Hm(a.T, { "object-fit": c });
        });
      });
      a.T.addEventListener("play", function () {
        a.Fe || (AA(a.T, "first_play"), (a.Fe = !0));
      });
      a.T.addEventListener("pause", function () {
        a.Vc || (AA(a.T, "first_pause"), CA(a.T), (a.Vc = !0));
      });
      as(x, "pagehide", function () {
        a.Vc || (AA(a.T, "first_pause"), CA(a.T), (a.Vc = !0));
      });
      a.T.addEventListener("stalled", function () {
        K(J.getInstance(), "ves", "1");
      });
      new wx(a.T).O("playbackStalled", function () {
        return K(J.getInstance(), "pbs", "1");
      });
      a.T.addEventListener("media_source_error", function (b) {
        iB(a);
        b = b.detail;
        jB(a, new ZA(b.code, b.message));
      });
      mB(a);
    },
    cB = function (a) {
      var b = YA(a.childNodes);
      b && nB(a, b);
      null === a.sc && oB(a);
    },
    oB = function (a) {
      if (x.MutationObserver) {
        var b = new MutationObserver(function (c) {
          c = u(c);
          for (var d = c.next(); !d.done; d = c.next())
            if (
              ((d = d.value), "childList" === d.type && (d = YA(d.addedNodes)))
            ) {
              nB(a, d);
              b.disconnect();
              break;
            }
        });
        b.observe(a, VA);
      }
    },
    bB = function (a) {
      a.T.addEventListener("volumechange", function () {
        a.xb.g.C(EA.toString(), a.T.muted);
        a.Lg || a.xb.g.C(FA.toString(), a.T.muted);
      });
    },
    nB = function (a, b) {
      if (null === a.sc && b.hasAttribute("src")) {
        var c = b.getAttribute("src");
        a.sc = new QA(a.T, c, b.hasAttribute("default"));
        new NA(a.sc, a.xb);
        c.includes("kind=asr") && K(J.getInstance(), "act", "1");
      }
    },
    fB = function (a, b) {
      if (b !== a.Be) {
        a.Be = b;
        a.Mg && b && Zw(b) && (b = $w(b));
        var c = b ? Gy(b) : null,
          d = !!c && iA(c);
        K(J.getInstance(), "umsem", d ? "1" : "0");
        d
          ? ((b = Wv(BA, b, Hy(c), 1e3 * yy[c], null)),
            (a.sa = Wv(qA, [b])),
            a.Nb && a.sa.Xc(a.Nb),
            a.sa.O("media_source_error", function (e) {
              e = Iy("media_source_error", e.detail);
              a.T.dispatchEvent(e);
            }),
            (a.Zb = function () {
              var e = a.sa;
              e.G = 1e3 * a.T.currentTime;
              sA(e);
            }),
            a.T.addEventListener("timeupdate", a.Zb),
            hB(a, "src", tA(a.sa)))
          : (iB(a), hB(a, "src", b));
        a.Le || eB(a);
      }
    },
    gB = function (a) {
      a.src &&
        jB(
          a,
          new ZA(
            MediaError.MEDIA_ERR_ABORTED,
            "Setting demuxed src after src is already set."
          )
        );
      if (!a.rb && !a.bb && a.sa) iB(a), hB(a, "src", null), eB(a);
      else if (a.rb && a.bb) {
        var b = Gy(Zw(a.bb) ? $w(a.bb) : a.bb),
          c = Gy(Zw(a.rb) ? $w(a.rb) : a.rb);
        if (b && iA(b))
          if (c && iA(c)) {
            var d = !!b && iA(b) && !!c && iA(c);
            K(J.getInstance(), "umsed", d ? "1" : "0");
            b = Wv(BA, a.bb, Hy(b), -1, null);
            c = Wv(BA, a.rb, Hy(c), -1, null);
            a.sa = Wv(qA, [b, c]);
            a.Nb && a.sa.Xc(a.Nb);
            a.sa.O("media_source_error", function (e) {
              e = Iy("media_source_error", e.detail);
              a.T.dispatchEvent(e);
            });
            a.Zb = function () {
              var e = a.sa;
              e.G = 1e3 * a.T.currentTime;
              sA(e);
            };
            a.T.addEventListener("timeupdate", a.Zb);
            hB(a, "src", tA(a.sa));
            a.Le || eB(a);
          } else jB(a, new $A('Audio itag "' + c + '" not supported.'));
        else jB(a, new $A('Video itag "' + b + '" not supported.'));
      }
    },
    kB = function (a) {
      for (
        var b = u(UA), c = b.next(), d = {};
        !c.done;
        d = { Xa: void 0, getValue: void 0 }, c = b.next()
      )
        (d.Xa = c.value),
          d.Xa in a.T &&
            ("function" === typeof a.T[d.Xa]
              ? ((d.getValue = a.T[d.Xa].bind(a.T)),
                Object.defineProperty(a, d.Xa, {
                  set: (function (e) {
                    return function (f) {
                      a.T[e.Xa] = f;
                    };
                  })(d),
                  get: (function (e) {
                    return function () {
                      return e.getValue;
                    };
                  })(d),
                }))
              : Object.defineProperty(a, d.Xa, {
                  set: (function (e) {
                    return function (f) {
                      a.T[e.Xa] = f;
                    };
                  })(d),
                  get: (function (e) {
                    return function () {
                      return a.T[e.Xa];
                    };
                  })(d),
                }));
    },
    lB = function (a) {
      Object.defineProperty(a, "error", {
        set: function () {},
        get: function () {
          return a.T.error ? a.T.error : a.ge;
        },
      });
    },
    mB = function (a) {
      a.T.style.width = Om();
      a.T.style.height = Om();
    };
  dB.prototype.disconnectedCallback = function () {
    this.cd && mx(this.cd);
    XA.prototype.disconnectedCallback &&
      XA.prototype.disconnectedCallback.call(this);
  };
  da.Object.defineProperties(dB.prototype, {
    rb: {
      configurable: !0,
      enumerable: !0,
      set: function (a) {
        this.setAttribute("demuxedaudiosrc", a);
      },
      get: function () {
        return this.getAttribute("demuxedaudiosrc");
      },
    },
    bb: {
      configurable: !0,
      enumerable: !0,
      set: function (a) {
        this.setAttribute("demuxedvideosrc", a);
      },
      get: function () {
        return this.getAttribute("demuxedvideosrc");
      },
    },
    src: {
      configurable: !0,
      enumerable: !0,
      set: function (a) {
        this.setAttribute("src", a);
      },
      get: function () {
        return this.getAttribute("src");
      },
    },
  });
  da.Object.defineProperties(dB, {
    observedAttributes: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return TA;
      },
    },
  });
  x.customElements &&
    (x.customElements.get("lima-video") ||
      x.customElements.define("lima-video", dB));
  function pB() {
    var a = Wv(Tz);
    a.initialize().then(function () {
      var b = Iy("initialized");
      a.dispatchEvent(b);
    });
    return a;
  }
  var rB = function (a, b, c, d, e) {
    Q.call(this);
    this.G = a;
    this.j = c;
    this.A = e;
    this.Z = this.U = this.Ab = this.F = this.l = this.Pa = 0;
    this.C = [];
    this.L = !1;
    this.ba = this.ga = this.fa = null;
    this.Ga = !1;
    this.Bb = this.J = this.o = this.Ha = this.Oa = null;
    this.xa = !1;
    this.H = new T(b.url);
    this.Ia = b.Ia;
    this.ka = d;
    (this.P = b.g) || this.H.g.remove("alr");
    K(J.getInstance(), "sl_dv" + this.A, (null !== this.P).toString());
    this.W = !this.P;
    this.g = new XMLHttpRequest();
    this.Y = 0.1;
    if ((this.B = Wy() && !Zw(this.H))) (this.o = pB()), In(this, this.o);
    qB(this);
  };
  v(rB, Q);
  var sB = function (a, b) {
      b = Iy("media_source_error", b);
      a.G.dispatchEvent(b);
    },
    tB = function (a, b) {
      sB(a, {
        code:
          1 < a.l
            ? MediaError.MEDIA_ERR_NETWORK
            : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
        message: b,
      });
    },
    qB = function (a) {
      a.fa = function () {
        uB(a);
        if (a.W) {
          var b = a.g.responseText;
          a.L = !b || b.length < a.Ia;
          a.U = 0;
          L("sl_cc" + a.A + "_" + a.l);
          a.F++;
          vB(a);
        }
      };
      a.ga = function () {
        uB(a);
      };
      a.ba = function () {
        L("sl_ec" + a.A + "_" + a.l);
        tB(a, "Failed to load chunk " + a.l + " for stream " + a.A);
      };
      a.g.addEventListener("load", a.fa);
      a.g.addEventListener("progress", a.ga);
      a.g.addEventListener("error", a.ba);
      a.j.addEventListener("updateend", function () {
        a.j.buffered.length &&
          ((a.Ab = a.j.buffered.end(0)),
          a.B
            ? a.xa && !a.j.updating && a.l === a.F && (L("sl_lc" + a.A), a.ka())
            : a.L &&
              !a.j.updating &&
              a.l === a.F &&
              (L("sl_lc" + a.A), a.ka()));
        !a.Ga &&
          1 < a.G.buffered.length &&
          (K(J.getInstance(), "dbr", "1"), (a.Ga = !0));
      });
      a.j.addEventListener("update", function () {
        a.C.length && !a.j.updating && a.j.appendBuffer(a.C.shift());
      });
      a.j.addEventListener("error", function () {
        L("msb_err" + a.A);
        sB(a, {
          code: MediaError.MEDIA_ERR_DECODE,
          message: "Error on SourceBuffer " + a.A,
        });
      });
      a.B
        ? (a.o.Sa()
            ? wB(a)
            : (a.Oa = as(a.o, "initialized", function () {
                wB(a);
              })),
          (a.Ha = as(a.o, "get_video_succeeded", function () {
            vB(a);
          })))
        : wB(a);
    },
    yB = function (a) {
      L("sl_rc" + a.A + "_" + a.l);
      var b = xB(a);
      a.g.open("get", b);
      a.g.overrideMimeType("text/plain; charset=x-user-defined");
      a.g.send(null);
      a.B && ((a.J = null), (a.Bb = b));
    },
    uB = function (a) {
      if (400 <= a.g.status)
        tB(
          a,
          'Response code "' +
            a.g.status +
            '" on loading chunk ' +
            a.l +
            " for stream " +
            a.A
        );
      else {
        if (!a.W) {
          var b = a.g.getResponseHeader("content-type");
          if (b && 0 <= b.indexOf("text/plain")) {
            a.g.readyState === XMLHttpRequest.DONE &&
              ((a.H = new T(a.g.response)),
              (a.l = 0),
              (a.F = 0),
              a.Pa++,
              wB(a));
            return;
          }
          a.W = !0;
          L("sl_redc" + a.A);
          K(J.getInstance(), "sl_tr" + a.A, a.Pa.toString());
        }
        a.H.g.remove("alr");
        if (
          a.g.readyState === XMLHttpRequest.LOADING ||
          a.g.readyState === XMLHttpRequest.DONE
        )
          (b = zB(a, a.U)),
            (a.U = a.g.response.length),
            (a.Z += b.byteLength),
            AB(a, b);
        if (
          a.B &&
          a.g.readyState === XMLHttpRequest.DONE &&
          ((b = zB(a, 0)), 0 < b.byteLength)
        ) {
          var c = a.g.responseText;
          a.xa = !c || c.length < a.Ia;
          a.o.kc(b, new T(a.Bb), 0, a.xa);
        }
      }
    },
    AB = function (a, b) {
      0 < b.byteLength &&
        (a.j.updating || a.C.length ? a.C.push(b) : a.j.appendBuffer(b));
    },
    zB = function (a, b) {
      a = a.g.response;
      for (var c = new Uint8Array(a.length - b), d = 0; d < c.length; d++)
        c[d] = a.charCodeAt(d + b) & 255;
      return c.buffer;
    },
    vB = function (a) {
      var b = ax;
      -1 !== b && b < a.Z + a.Ia
        ? (a.G.pause(), (ax = -1), (b = !1))
        : ((b = a.F === a.l && !a.j.updating && !a.C.length),
          (b = a.B
            ? !a.xa && b && a.G.currentTime >= a.Y
            : !a.L && b && a.G.currentTime >= a.Y));
      b && ((a.Y = a.Ab + 0.1), wB(a));
    },
    xB = function (a) {
      var b = a.B && a.J ? a.J + 1 : a.l * a.Ia;
      return Kw(a.H, "range", b + "-" + (b + a.Ia - 1)).toString();
    },
    wB = function (a) {
      if (a.B) {
        var b = new T(xB(a));
        a.o.Sb(b).then(function (c) {
          c
            ? ((a.J = Number(c.wc)),
              (a.xa = c.xa),
              AB(a, c.video),
              (c = Iy("get_video_succeeded")),
              a.o.dispatchEvent(c),
              a.F++)
            : yB(a);
          a.l++;
        });
      } else yB(a), a.l++;
    };
  rB.prototype.M = function () {
    this.B && this.o.Sa() && this.o.close();
    this.g.removeEventListener("load", this.fa);
    this.g.removeEventListener("progress", this.ga);
    this.g.removeEventListener("error", this.ba);
    is(this.Oa);
    is(this.Ha);
    Q.prototype.M.call(this);
  };
  var CB = function (a, b) {
    Q.call(this);
    var c = this;
    this.o = a;
    this.G = b;
    this.g = new MediaSource();
    this.F = [];
    this.l = [];
    this.j = this.A = null;
    this.B = !1;
    this.C = function () {
      BB(c);
    };
    this.g.addEventListener("sourceopen", this.C);
  };
  v(CB, Q);
  var DB = function (a) {
      a.A && a.o.removeEventListener("timeupdate", a.A);
    },
    BB = function (a) {
      L("msmsw_oso");
      a.A = function () {
        if (!a.B)
          for (var e = u(a.l), f = e.next(); !f.done; f = e.next()) vB(f.value);
      };
      a.o.addEventListener("timeupdate", a.A);
      for (var b = 0; b < a.G.length; b++) {
        var c = a.G[b];
        K(J.getInstance(), "msmsw_mime" + b, c.mimeType);
        K(J.getInstance(), "msmsw_cs" + b, c.Ia.toString());
        var d = a.g.addSourceBuffer(c.mimeType);
        d
          ? (a.F.push(d),
            (c = Wv(
              rB,
              a.o,
              c,
              d,
              function () {
                a: if (!a.B) {
                  for (var e = u(a.l), f = e.next(); !f.done; f = e.next())
                    if (
                      ((f = f.value),
                      f.B
                        ? !f.xa || f.j.updating || f.C.length
                        : !f.L || f.j.updating || f.C.length)
                    )
                      break a;
                  a.g.endOfStream();
                  a.B = !0;
                  DB(a);
                }
              },
              b
            )),
            a.l.push(c))
          : L("msmsw_sbf" + b);
      }
      K(J.getInstance(), "msmsw_ns", a.F.length.toString());
    };
  CB.prototype.M = function () {
    this.j && window.URL.revokeObjectURL(this.j);
    for (var a = u(this.l), b = a.next(); !b.done; b = a.next()) b.value.X();
    DB(this);
    this.g.removeEventListener("sourceopen", this.C);
    Q.prototype.M.call(this);
  };
  RegExp.prototype.hasOwnProperty("sticky"); /*

Math.uuid.js (v1.4)
http://www.broofa.com
mailto:robert@broofa.com
Copyright (c) 2010 Robert Kieffer
Dual licensed under the MIT and GPL licenses.
*/
  var EB =
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(
        ""
      ),
    FB = function () {
      for (var a = Array(36), b = 0, c, d = 0; 36 > d; d++)
        8 == d || 13 == d || 18 == d || 23 == d
          ? (a[d] = "-")
          : 14 == d
          ? (a[d] = "4")
          : (2 >= b && (b = (33554432 + 16777216 * Math.random()) | 0),
            (c = b & 15),
            (b >>= 4),
            (a[d] = EB[19 == d ? (c & 3) | 8 : c]));
      return a.join("");
    };
  var HB = function (a) {
    T.call(this, a);
    this.C = new Map();
    a = this.l;
    var b = a.indexOf(";"),
      c = null;
    0 <= b
      ? ((this.l = a.substring(0, b)), (c = a.substring(b + 1)))
      : (this.l = a);
    GB(this, c);
  };
  v(HB, T);
  HB.prototype.toString = function () {
    return IB(this, T.prototype.toString.call(this));
  };
  HB.prototype.F = function () {
    return "";
  };
  var GB = function (a, b) {
      nb(Kh(b)) ||
        b.split(";").forEach(function (c) {
          var d = c.indexOf("=");
          if (!(0 >= d)) {
            var e = Hh(c.substring(0, d));
            c = Hh(c.substring(d + 1));
            d = a.C.get(e);
            null != d ? d.includes(c) || d.push(c) : (d = [Kh(c)]);
            a.C.set(e, d);
          }
        }, a);
    },
    JB = function (a) {
      if (nb(Kh("ord"))) return null;
      a = a.C.get("ord");
      return null != a ? a : null;
    },
    KB = function (a, b) {
      nb(Kh("ord")) || ((b = b.map(Kh)), a.C.set("ord", b));
    },
    IB = function (a, b) {
      b = [Kh(b)];
      b.push.apply(b, ha(LB(a)));
      return b.join(";");
    },
    LB = function (a) {
      var b = JB(a);
      null == b ? (b = [Kh(Date.now())]) : nb(Kh("ord")) || a.C.delete("ord");
      var c = [];
      a.C.forEach(function (d, e) {
        d.forEach(function (f) {
          c.push(e + "=" + f);
        });
      });
      c.push("ord=" + b[0]);
      KB(a, b);
      return c;
    };
  HB.prototype.G = function () {
    return new HB(this.toString());
  };
  function MB(a) {
    var b = new HB(a);
    a = b.j;
    b = IB(b, b.l);
    return (
      !lb(a, ".g.doubleclick.net") &&
      (lb(a, "doubleclick.net") || lb(a, "pagead2.googlesyndication.com")) &&
      Cx("/(ad|pfad)[x|i|j]?/", b)
    );
  }
  function NB(a) {
    return "bid.g.doubleclick.net" == new T(a).j;
  }
  function OB(a) {
    a = new T(a);
    var b = a.l;
    return (
      lb(a.j, "googleads.g.doubleclick.net") && Cx("/pagead/(live/)?ads", b)
    );
  }
  function PB(a) {
    a = new T(a);
    var b = a.l;
    return lb(a.j, "doubleclick.net") && Cx("/gampad/(live/)?ads", b);
  }
  function QB(a) {
    a = new T(a);
    var b = a.l;
    return "ad.doubleclick.net" === a.j && Cx("/dv3/adv", b);
  }
  var U = {
    DEPRECATED_ERROR_CODE: -1,
    VAST_MALFORMED_RESPONSE: 100,
    VAST_SCHEMA_VALIDATION_ERROR: 101,
    VAST_UNSUPPORTED_VERSION: 102,
    VAST_TRAFFICKING_ERROR: 200,
    VAST_UNEXPECTED_LINEARITY: 201,
    VAST_UNEXPECTED_DURATION_ERROR: 202,
    VAST_WRAPPER_ERROR: 300,
    VAST_LOAD_TIMEOUT: 301,
    VAST_TOO_MANY_REDIRECTS: 302,
    VAST_NO_ADS_AFTER_WRAPPER: 303,
    VIDEO_PLAY_ERROR: 400,
    VAST_MEDIA_LOAD_TIMEOUT: 402,
    VAST_LINEAR_ASSET_MISMATCH: 403,
    VAST_PROBLEM_DISPLAYING_MEDIA_FILE: 405,
    OVERLAY_AD_PLAYING_FAILED: 500,
    NONLINEAR_DIMENSIONS_ERROR: 501,
    OVERLAY_AD_LOADING_FAILED: 502,
    VAST_NONLINEAR_ASSET_MISMATCH: 503,
    COMPANION_REQUIRED_ERROR: 602,
    COMPANION_AD_LOADING_FAILED: 603,
    UNKNOWN_ERROR: 900,
    VPAID_ERROR: 901,
    FAILED_TO_REQUEST_ADS: 1005,
    VAST_ASSET_NOT_FOUND: 1007,
    VAST_EMPTY_RESPONSE: 1009,
    UNKNOWN_AD_RESPONSE: 1010,
    UNSUPPORTED_LOCALE: 1011,
    ADS_REQUEST_NETWORK_ERROR: 1012,
    INVALID_AD_TAG: 1013,
    PROTECTED_AUDIENCE_API_ERROR: 1014,
    STREAM_INITIALIZATION_FAILED: 1020,
    ASSET_FALLBACK_FAILED: 1021,
    INVALID_ARGUMENTS: 1101,
    NATIVE_MESSAGE_ERROR: 1204,
    AUTOPLAY_DISALLOWED: 1205,
    CONSENT_MANAGEMENT_PROVIDER_NOT_READY: 1300,
    ai: 2002,
  };
  U[-1] = "DEPRECATED_ERROR_CODE";
  U[100] = "VAST_MALFORMED_RESPONSE";
  U[101] = "VAST_SCHEMA_VALIDATION_ERROR";
  U[102] = "VAST_UNSUPPORTED_VERSION";
  U[200] = "VAST_TRAFFICKING_ERROR";
  U[201] = "VAST_UNEXPECTED_LINEARITY";
  U[202] = "VAST_UNEXPECTED_DURATION_ERROR";
  U[300] = "VAST_WRAPPER_ERROR";
  U[301] = "VAST_LOAD_TIMEOUT";
  U[302] = "VAST_TOO_MANY_REDIRECTS";
  U[303] = "VAST_NO_ADS_AFTER_WRAPPER";
  U[400] = "VIDEO_PLAY_ERROR";
  U[402] = "VAST_MEDIA_LOAD_TIMEOUT";
  U[403] = "VAST_LINEAR_ASSET_MISMATCH";
  U[405] = "VAST_PROBLEM_DISPLAYING_MEDIA_FILE";
  U[500] = "OVERLAY_AD_PLAYING_FAILED";
  U[501] = "NONLINEAR_DIMENSIONS_ERROR";
  U[502] = "OVERLAY_AD_LOADING_FAILED";
  U[503] = "VAST_NONLINEAR_ASSET_MISMATCH";
  U[602] = "COMPANION_REQUIRED_ERROR";
  U[603] = "COMPANION_AD_LOADING_FAILED";
  U[900] = "UNKNOWN_ERROR";
  U[901] = "VPAID_ERROR";
  U[1005] = "FAILED_TO_REQUEST_ADS";
  U[1007] = "VAST_ASSET_NOT_FOUND";
  U[1009] = "VAST_EMPTY_RESPONSE";
  U[1010] = "UNKNOWN_AD_RESPONSE";
  U[1011] = "UNSUPPORTED_LOCALE";
  U[1012] = "ADS_REQUEST_NETWORK_ERROR";
  U[1013] = "INVALID_AD_TAG";
  U[1014] = "PROTECTED_AUDIENCE_API_ERROR";
  U[1020] = "STREAM_INITIALIZATION_FAILED";
  U[1021] = "ASSET_FALLBACK_FAILED";
  U[1101] = "INVALID_ARGUMENTS";
  U[1204] = "NATIVE_MESSAGE_ERROR";
  U[1205] = "AUTOPLAY_DISALLOWED";
  U[1300] = "CONSENT_MANAGEMENT_PROVIDER_NOT_READY";
  U[2002] = "SUPPORTED_ADS_NOT_FOUND";
  var RB = function (a, b, c) {
    var d = Error.call(this);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.type = a;
    this.errorMessage = b;
    this.errorCode = c;
    this.ad = this.g = null;
  };
  v(RB, Error);
  l = RB.prototype;
  l.getAd = function () {
    return this.ad;
  };
  l.getInnerError = function () {
    return this.g;
  };
  l.getMessage = function () {
    return this.errorMessage;
  };
  l.getErrorCode = function () {
    return this.errorCode;
  };
  l.getVastErrorCode = function () {
    return 1e3 > this.errorCode ? this.errorCode : 900;
  };
  l.getType = function () {
    return this.type;
  };
  l.toString = function () {
    return (
      "AdError " +
      this.getErrorCode() +
      ": " +
      this.getMessage() +
      (null != this.getInnerError()
        ? " Caused by: " + this.getInnerError()
        : "")
    );
  };
  var SB = fa(["https://imasdk.googleapis.com/js/sdkloader/car.js"]),
    TB = yh(SB);
  function UB(a) {
    return a
      ? OB(a)
        ? "adsense"
        : NB(a)
        ? "dbm"
        : MB(a)
        ? "dcm"
        : QB(a)
        ? "dv3"
        : PB(a)
        ? "xfp"
        : "thirdparty"
      : "";
  }
  function VB(a) {
    if ("" === a) return [];
    var b = new T(a);
    if (PB(a)) {
      var c;
      c = (c = b.g.get("slotname") || b.g.get("iu"))
        ? (c = /\/(\d+)(?:,\d+){0,2}\//.exec(c)) && 2 === c.length
          ? c.slice(1)
          : []
        : [];
      return c;
    }
    return OB(a)
      ? (c = (a = null != (c = b.g.get("client")) ? c : "") ? a : null)
        ? [c]
        : []
      : [];
  }
  function WB(a, b) {
    try {
      var c = new URL(a);
      return c.searchParams.get("slotname") || c.searchParams.get("iu") || "";
    } catch (d) {
      null == b || b(d);
    }
    return "";
  }
  var XB = function (a) {
    var b = {};
    b =
      ((b.IABUSPrivacy_String = "uspString"),
      (b.IABTCF_gdprApplies = "gdprApplies"),
      (b.IABTCF_TCString = "tcString"),
      (b.IABTCF_AddtlConsent = "addtlConsent"),
      (b.IABGPP_HDR_GppString = "gppString"),
      (b.IABGPP_GppSID = "gppSid"),
      b);
    for (var c in b) null != a[c] && ((a[b[c]] = a[c]), delete a[c]);
    c = a.uspString;
    this.uspString = "string" === typeof c ? c : "";
    c = a.gdprApplies;
    this.j =
      "boolean" === typeof c
        ? c
          ? "1"
          : "0"
        : "number" !== typeof c || (1 !== c && 0 !== c)
        ? "string" !== typeof c || ("1" !== c && "0" !== c)
          ? ""
          : "1" === c
          ? "1"
          : "0"
        : 1 === c
        ? "1"
        : "0";
    c = a.tcString;
    this.g = "string" === typeof c ? c : "";
    /^[\.\w_-]*$/.test(this.g) || (this.g = encodeURIComponent(this.g));
    a = a.gppString;
    this.gppString = "string" === typeof a ? a : "";
  };
  var YB = function (a) {
      this.g = a;
    },
    ZB = function (a, b) {
      return Wg(a.g, b) && ((a = a.g[b]), "boolean" === typeof a) ? a : !1;
    },
    $B = function (a) {
      return Wg(a.g, "videoElementFakeDuration") &&
        ((a = a.g.videoElementFakeDuration), "number" === typeof a)
        ? a
        : NaN;
    },
    aC = function (a) {
      if (Wg(a.g, "forceExperimentIds")) {
        a = a.g.forceExperimentIds;
        var b = [],
          c = 0;
        Array.isArray(a) &&
          a.forEach(function (d) {
            "number" === typeof d && (b[c++] = d);
          });
        return b;
      }
      return null;
    };
  var V = function () {
      this.J = "always";
      this.Y = 4;
      this.F = null;
      this.o = 1;
      this.g = 0;
      this.A = !0;
      this.locale = "en";
      this.l = null;
      this.j = !1;
      this.ba = this.Z = "";
      this.C = null;
      this.H = this.N = -1;
      this.B = "";
      this.U = !1;
      this.P = !0;
      this.G = FB();
      this.W = {};
      this.I = "";
      this.L = 0;
      try {
        this.fa = Nl()[0];
      } catch (a) {}
    },
    bC = function (a) {
      a = Kh(a);
      nb(a) || (a = a.substring(0, 20));
      return a;
    };
  l = V.prototype;
  l.setCompanionBackfill = function (a) {
    this.J = a;
  };
  l.getCompanionBackfill = function () {
    return this.J;
  };
  l.setNumRedirects = function (a) {
    this.Y = a;
  };
  l.getNumRedirects = function () {
    return this.Y;
  };
  l.setPpid = function (a) {
    this.F = a;
  };
  l.getPpid = function () {
    return this.F;
  };
  l.setVpaidAllowed = function (a) {
    "boolean" === typeof a && (this.o = a ? 1 : 0);
  };
  l.setVpaidMode = function (a) {
    this.o = a;
  };
  l.Rf = function () {
    return this.o;
  };
  l.setAutoPlayAdBreaks = function (a) {
    this.A = a;
  };
  l.cg = function () {
    return this.A;
  };
  l.zg = function (a) {
    this.j = a;
  };
  l.Qf = function () {
    return this.j;
  };
  l.setLocale = function (a) {
    if ((a = Ex(a))) this.locale = a;
  };
  l.getLocale = function () {
    return this.locale;
  };
  l.setPlayerType = function (a) {
    this.Z = bC(a);
  };
  l.getPlayerType = function () {
    return this.Z;
  };
  l.setPlayerVersion = function (a) {
    this.ba = bC(a);
  };
  l.getPlayerVersion = function () {
    return this.ba;
  };
  var cC = function (a) {
    if (null == a.C) {
      var b = {};
      var c = new T(G().location.href).g;
      if (Pw(c, "tcnfp"))
        try {
          b = JSON.parse(c.get("tcnfp"));
        } catch (d) {}
      a.C = new YB(b);
    }
    return a.C;
  };
  l = V.prototype;
  l.Ag = function (a) {
    this.N = a;
  };
  l.Bg = function (a) {
    this.H = a;
  };
  l.setDisableCustomPlaybackForIOS10Plus = function (a) {
    this.U = a;
  };
  l.getDisableCustomPlaybackForIOS10Plus = function () {
    return this.U;
  };
  l.isCookiesEnabled = function () {
    return this.P;
  };
  l.setCookiesEnabled = function (a) {
    null != a && (this.P = a);
  };
  l.setSessionId = function (a) {
    this.G = a;
  };
  l.yg = function () {};
  l.Pf = function () {
    return !0;
  };
  l.setFeatureFlags = function (a) {
    this.W = a;
  };
  l.getFeatureFlags = function () {
    return this.W;
  };
  var dC = function (a, b) {
    b = void 0 === b ? null : b;
    var c = {};
    null != b && (c.activeViewPushUpdates = b);
    c.activityMonitorMode = a.g;
    c.adsToken = a.B;
    c.autoPlayAdBreaks = a.A;
    c.companionBackfill = a.getCompanionBackfill();
    c.cookiesEnabled = a.isCookiesEnabled();
    c.disableCustomPlaybackForIOS10Plus =
      a.getDisableCustomPlaybackForIOS10Plus();
    c.engagementDetection = !0;
    c.isFunctionalTest = !1;
    c.isVpaidAdapter = a.j;
    c["1pJar"] = "";
    c.numRedirects = a.getNumRedirects();
    c.pageCorrelator = a.N;
    c.persistentStateCorrelator = Li();
    c.playerType = a.getPlayerType();
    c.playerVersion = a.getPlayerVersion();
    c.ppid = a.getPpid();
    c.privacyControls = "";
    c.reportMediaRequests = !1;
    c.sessionId = a.G;
    c.streamCorrelator = a.H;
    c.testingConfig = cC(a).g;
    c.urlSignals = a.fa;
    c.vpaidMode = a.o;
    c.featureFlags = a.getFeatureFlags();
    c.cookieDeprecationLabel = a.I;
    c.cookieDeprecationLabelStatus = a.L;
    return c;
  };
  V.prototype.getFeatureFlags = V.prototype.getFeatureFlags;
  V.prototype.setFeatureFlags = V.prototype.setFeatureFlags;
  V.prototype.getDisableFlashAds = V.prototype.Pf;
  V.prototype.setDisableFlashAds = V.prototype.yg;
  V.prototype.setSessionId = V.prototype.setSessionId;
  V.prototype.setCookiesEnabled = V.prototype.setCookiesEnabled;
  V.prototype.isCookiesEnabled = V.prototype.isCookiesEnabled;
  V.prototype.getDisableCustomPlaybackForIOS10Plus =
    V.prototype.getDisableCustomPlaybackForIOS10Plus;
  V.prototype.setDisableCustomPlaybackForIOS10Plus =
    V.prototype.setDisableCustomPlaybackForIOS10Plus;
  V.prototype.setStreamCorrelator = V.prototype.Bg;
  V.prototype.setPageCorrelator = V.prototype.Ag;
  V.prototype.getPlayerVersion = V.prototype.getPlayerVersion;
  V.prototype.setPlayerVersion = V.prototype.setPlayerVersion;
  V.prototype.getPlayerType = V.prototype.getPlayerType;
  V.prototype.setPlayerType = V.prototype.setPlayerType;
  V.prototype.getLocale = V.prototype.getLocale;
  V.prototype.setLocale = V.prototype.setLocale;
  V.prototype.getIsVpaidAdapter = V.prototype.Qf;
  V.prototype.setIsVpaidAdapter = V.prototype.zg;
  V.prototype.isAutoPlayAdBreaks = V.prototype.cg;
  V.prototype.setAutoPlayAdBreaks = V.prototype.setAutoPlayAdBreaks;
  V.prototype.getVpaidMode = V.prototype.Rf;
  V.prototype.setVpaidMode = V.prototype.setVpaidMode;
  V.prototype.setVpaidAllowed = V.prototype.setVpaidAllowed;
  V.prototype.getPpid = V.prototype.getPpid;
  V.prototype.setPpid = V.prototype.setPpid;
  V.prototype.getNumRedirects = V.prototype.getNumRedirects;
  V.prototype.setNumRedirects = V.prototype.setNumRedirects;
  V.prototype.getCompanionBackfill = V.prototype.getCompanionBackfill;
  V.prototype.setCompanionBackfill = V.prototype.setCompanionBackfill;
  var eC = new V();
  var fC = function (a) {
    this.K = B(a);
  };
  v(fC, F);
  fC.na = [10];
  function gC(a) {
    var b = {};
    new T(a).g.forEach(function (c, d) {
      b[d] = c;
    });
    return b;
  }
  var hC = function (a, b) {
      a = void 0 === a ? {} : a;
      b = void 0 === b ? {} : b;
      var c = {};
      a = u(Object.entries(a));
      for (var d = a.next(); !d.done; d = a.next()) {
        var e = u(d.value);
        d = e.next().value;
        e = e.next().value;
        null != e && (c[d] = String(e));
      }
      this.g = c;
      this.j = new XB(b);
    },
    iC = function (a, b) {
      if (!(OB(a) || MB(a) || PB(a) || NB(a) || QB(a))) {
        var c = new T(a),
          d = c.l;
        "pubads.g.doubleclick.net" === c.j &&
          (Cx("/ssai/", d) || Cx("/ondemand/", d));
      }
      return new hC(gC(a), b);
    },
    lC = function (a) {
      var b = a.j.g;
      var c = jC(a, "gdpr_consent");
      b =
        b && "tcunavailable" !== b
          ? b
          : "tcunavailable" === b
          ? c || b
          : c || "";
      if ("tcunavailable" === b) return null;
      var d;
      a = kC(a);
      if ((c = Jv(b)) && b) {
        var e = tf(c, $u, 1);
        c = tf(c, Uu, 2) || new Uu();
        var f = Ef(e, 9),
          g = Ef(e, 4),
          h = Ef(e, 5),
          k = Df(e, 10),
          n = Df(e, 11),
          m = E(e, 16),
          r = Df(e, 15),
          p = {
            consents: Kv(gf(e, 13, ge), wv),
            legitimateInterests: Kv(gf(e, 14, ge), wv),
          },
          t = {
            consents: Kv(gf(e, 17, je)),
            legitimateInterests: Kv(gf(e, 18, je)),
          },
          w = Kv(gf(e, 12, ge), xv),
          y = vf(e, Tu, 19);
        e = {};
        y = u(y);
        for (var R = y.next(); !R.done; R = y.next()) {
          R = R.value;
          var ka = Hf(R, 1);
          e[ka] = e[ka] || {};
          var ua = gf(R, 3, je);
          ua = u(ua);
          for (var pa = ua.next(); !pa.done; pa = ua.next())
            e[ka][pa.value] = Hf(R, 2);
        }
        b = {
          tcString: b,
          tcfPolicyVersion: f,
          gdprApplies: a,
          cmpId: g,
          cmpVersion: h,
          isServiceSpecific: k,
          useNonStandardStacks: n,
          publisherCC: m,
          purposeOneTreatment: r,
          purpose: p,
          vendor: t,
          specialFeatureOptins: w,
          publisher: {
            restrictions: e,
            consents: Kv(gf(c, 1, ge), wv),
            legitimateInterests: Kv(gf(c, 2, ge), wv),
            customPurposes: {
              consents: Kv(gf(c, 3, je)),
              legitimateInterests: Kv(gf(c, 4, je)),
            },
          },
        };
      } else b = null;
      return null != (d = b) ? d : null;
    },
    jC = function (a, b) {
      if (a.g.hasOwnProperty(b)) return a.g[b];
    },
    nC = function (a) {
      var b;
      if (!(b = mC(a))) {
        if (kC(a)) {
          a = lC(a);
          if ((b = !!a)) {
            var c = void 0 === c ? {} : c;
            b = qw(a)
              ? !1 === a.gdprApplies
                ? !0
                : "tcunavailable" === a.tcString
                ? !c.ve
                : (c.ve || void 0 !== a.gdprApplies || c.Ei) &&
                  (c.ve ||
                    ("string" === typeof a.tcString && a.tcString.length))
                ? uw(a, "1", 0)
                : !0
              : !1;
          }
          c = b;
        } else c = !0;
        b = !c;
      }
      return b;
    },
    mC = function (a) {
      a = jC(a, "ltd");
      return "1" === a || "true" === a;
    },
    kC = function (a) {
      var b = jC(a, "gdpr");
      a = a.j.j;
      b = ("1" === a || "0" === a ? a : void 0 !== b ? b : "").toLowerCase();
      return "true" === b || "1" === b;
    },
    oC = function (a) {
      var b = new fC();
      var c = !nC(a);
      c = Jf(b, 5, c);
      kC(a) ? ((a = lC(a)), (a = !!a && !ww(a))) : (a = !1);
      Jf(c, 8, a);
      return b;
    };
  var pC = function (a) {
    this.K = B(a);
  };
  v(pC, F);
  pC.prototype.getVersion = function () {
    return E(this, 2);
  };
  var qC = function (a) {
    this.K = B(a);
  };
  v(qC, F);
  var rC = function (a, b) {
      return Kf(a, 2, b);
    },
    sC = function (a, b) {
      return Kf(a, 3, b);
    },
    tC = function (a, b) {
      return Kf(a, 4, b);
    },
    uC = function (a, b) {
      return Kf(a, 5, b);
    },
    vC = function (a, b) {
      return Kf(a, 9, b);
    },
    wC = function (a, b) {
      return xf(a, 10, b);
    },
    xC = function (a, b) {
      return Jf(a, 11, b);
    },
    yC = function (a, b) {
      return Kf(a, 1, b);
    },
    zC = function (a, b) {
      return Jf(a, 7, b);
    };
  qC.na = [10, 6];
  var AC =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function BC(a) {
    var b;
    return null != (b = a.google_tag_data) ? b : (a.google_tag_data = {});
  }
  function CC(a) {
    var b, c;
    return (
      "function" ===
      typeof (null == (b = a.navigator)
        ? void 0
        : null == (c = b.userAgentData)
        ? void 0
        : c.getHighEntropyValues)
    );
  }
  function DC() {
    var a = window;
    if (!CC(a)) return null;
    var b = BC(a);
    if (b.uach_promise) return b.uach_promise;
    a = a.navigator.userAgentData.getHighEntropyValues(AC).then(function (c) {
      null != b.uach || (b.uach = c);
      return c;
    });
    return (b.uach_promise = a);
  }
  function EC(a) {
    var b;
    return xC(
      wC(
        uC(
          rC(
            yC(
              tC(
                zC(
                  vC(sC(new qC(), a.architecture || ""), a.bitness || ""),
                  a.mobile || !1
                ),
                a.model || ""
              ),
              a.platform || ""
            ),
            a.platformVersion || ""
          ),
          a.uaFullVersion || ""
        ),
        (null == (b = a.fullVersionList)
          ? void 0
          : b.map(function (c) {
              var d = new pC();
              d = Kf(d, 1, c.brand);
              return Kf(d, 2, c.version);
            })) || []
      ),
      a.wow64 || !1
    );
  }
  function FC() {
    var a, b;
    return null !=
      (b =
        null == (a = DC())
          ? void 0
          : a.then(function (c) {
              return EC(c);
            }))
      ? b
      : null;
  }
  var HC = function () {
      this.appName = null;
      new hC();
      this.secureSignals = null;
      FB();
      this.deviceId = "";
      this.lg = null;
      this.g = Math.floor(4503599627370496 * Math.random());
      this.j = this.referrer = null;
      new Fu();
      GC(this);
    },
    IC = function () {
      HC.getInstance();
      var a = "h.3.637.1";
      eC.j && (a += "/vpaid_adapter");
      return a;
    },
    GC = function (a) {
      var b = FC();
      b &&
        b.then(function (c) {
          if (null == c) c = null;
          else {
            c = Mf(c);
            for (var d = [], e = 0, f = 0; f < c.length; f++) {
              var g = c.charCodeAt(f);
              255 < g && ((d[e++] = g & 255), (g >>= 8));
              d[e++] = g;
            }
            c = Ic(d, 3);
          }
          a.j = c;
        });
    };
  HC.getInstance = function () {
    return I(HC);
  };
  var KC = function (a) {
      a = void 0 === a ? !1 : a;
      var b = cC(eC);
      if ((b && ZB(b, "forceCustomPlayback")) || eC.j) return !0;
      if (tx() && a) return !1;
      a = a && (tx() || ux(10)) && eC.getDisableCustomPlaybackForIOS10Plus();
      return ((rc || tc) && !a) || (qc && (!qc || !sx(rx, 4))) || JC()
        ? !0
        : !1;
    },
    LC = function (a) {
      return null === a
        ? !1
        : eC.j
        ? !0
        : uc || tx()
        ? vx(a)
          ? tx() || (ux(10) && eC.getDisableCustomPlaybackForIOS10Plus())
            ? !1
            : !0
          : !0
        : (qc && (!qc || !sx(rx, 4))) || JC()
        ? !0
        : !1;
    },
    MC = function () {
      var a = cC(eC);
      return a && ZB(a, "disableOnScreenDetection") ? !1 : !an();
    },
    JC = function () {
      return 1 === NC() || 2 === NC();
    },
    NC = function () {
      switch ((HC.getInstance(), 0)) {
        case 1:
          return 3;
        case 2:
          return 1;
      }
      return (HC.getInstance(),
      HC.getInstance(),
      "tvos" === (HC.getInstance(), null))
        ? 1
        : bn()
        ? 2
        : 0;
    };
  var OC = function (a, b) {
    return 0 == a.indexOf(b) ? a.substr(b.length) : null;
  };
  function PC() {
    if (an()) return window.location.href;
    var a = Cl(),
      b = a.j,
      c = a.g;
    a = a.l;
    var d = null;
    if (a)
      try {
        var e = Lw(a.url),
          f = e.l,
          g = OC(f, "/v/");
        g || (g = OC(f, "/a/"));
        if (!g) throw Error("Can not extract standalone amp url.");
        var h = OC("/" + g, "/s/"),
          k = Aw(e.g);
        k.remove("amp_js_v");
        k.remove("amp_lite");
        var n = h ? Lw("https://" + h) : Lw("http://" + g);
        zw(n, k);
        d = n.toString();
      } catch (m) {
        d = null;
      }
    return d ? d : b && b.url ? b.url : c && c.url ? c.url : "";
  }
  function QC() {
    var a = zl();
    a = u(a);
    for (var b = a.next(); !b.done; b = a.next())
      if (((b = b.value), b.url && b.url.includes("amp=1"))) return !0;
    return null != window.context
      ? ((a = Number(window.context.ampcontextVersion)),
        isNaN(a) ? !1 : 0 < Math.floor(a))
      : null != Cl().l;
  }
  function RC() {
    var a = G().location.ancestorOrigins;
    return a ? (0 < a.length ? [].concat(ha(a)).join(",") : "") : "";
  }
  function SC() {
    var a = G(),
      b = document;
    return new T(a.parent === a ? a.location.href : b.referrer);
  }
  function TC(a, b) {
    Kw(a, "url", "");
    try {
      var c = 2083 - a.toString().length - 1;
      if (0 >= c) return a.toString();
      for (
        var d = b.slice(0, c), e = encodeURIComponent(d), f = c;
        0 < f && e.length > c;

      )
        (d = b.slice(0, f--)), (e = encodeURIComponent(d));
      Kw(a, "url", d);
    } catch (g) {}
    return a.toString();
  }
  var W = {},
    UC =
      ((W.creativeView = "creativeview"),
      (W.start = "start"),
      (W.midpoint = "midpoint"),
      (W.firstQuartile = "firstquartile"),
      (W.thirdQuartile = "thirdquartile"),
      (W.complete = "complete"),
      (W.mute = "mute"),
      (W.unmute = "unmute"),
      (W.pause = "pause"),
      (W.rewind = "rewind"),
      (W.resume = "resume"),
      (W.fullscreen = "fullscreen"),
      (W.exitFullscreen = "exitfullscreen"),
      (W.expand = "expand"),
      (W.collapse = "collapse"),
      (W.close = "close"),
      (W.acceptInvitation = "acceptinvitation"),
      (W.adCanPlay = "adCanPlay"),
      (W.adStarted = "adStarted"),
      (W.abandon = "abandon"),
      (W.acceptInvitationLinear = "acceptinvitationlinear"),
      (W.engagedView = "engagedview"),
      (W.instreamAdComplete = "instreamAdComplete"),
      (W.skipShown = "skipshown"),
      (W.skippableStateChanged = "skippableStateChanged"),
      (W.skip = "skip"),
      (W.progress = "progress"),
      (W.publisher_invoked_skip = "PUBLISHER_INVOKED_SKIP"),
      (W.annotation_start = "annotation_start"),
      (W.annotation_click = "annotation_click"),
      (W.annotation_close = "annotation_close"),
      (W.cta_annotation_shown = "cta_annotation_shown"),
      (W.cta_annotation_clicked = "cta_annotation_clicked"),
      (W.cta_annotation_closed = "cta_annotation_closed"),
      (W.replay = "replay"),
      (W.stop = "stop"),
      (W.autoplayDisallowed = "autoplayDisallowed"),
      (W.error = "error"),
      (W.mediaLoadTimeout = "mediaLoadTimeout"),
      (W.linearChanged = "linearChanged"),
      (W.click = "click"),
      (W.contentPauseRequested = "contentPauseRequested"),
      (W.contentResumeRequested = "contentResumeRequested"),
      (W.discardAdBreak = "discardAdBreak"),
      (W.updateAdsRenderingSettings = "updateAdsRenderingSettings"),
      (W.durationChange = "durationChange"),
      (W.expandedChanged = "expandedChanged"),
      (W.autoClose = "autoClose"),
      (W.userClose = "userClose"),
      (W.userRecall = "userRecall"),
      (W.prefetched = "prefetched"),
      (W.loaded = "loaded"),
      (W.init = "init"),
      (W.allAdsCompleted = "allAdsCompleted"),
      (W.adMetadata = "adMetadata"),
      (W.adBreakReady = "adBreakReady"),
      (W.adBreakFetchError = "adBreakFetchError"),
      (W.log = "log"),
      (W.volumeChange = "volumeChange"),
      (W.companionBackfill = "companionBackfill"),
      (W.companionInitialized = "companionInitialized"),
      (W.companionImpression = "companionImpression"),
      (W.companionClick = "companionClick"),
      (W.impression = "impression"),
      (W.interaction = "interaction"),
      (W.adProgress = "adProgress"),
      (W.adBuffering = "adBuffering"),
      (W.trackingUrlPinged = "trackingUrlPinged"),
      (W.measurable_impression = "measurable_impression"),
      (W.custom_metric_viewable = "custom_metric_viewable"),
      (W.viewable_impression = "viewable_impression"),
      (W.fully_viewable_audible_half_duration_impression =
        "fully_viewable_audible_half_duration_impression"),
      (W.audio_audible = "audio_audible"),
      (W.audio_measurable = "audio_measurable"),
      (W.overlay_resize = "overlay_resize"),
      (W.overlay_unmeasurable_impression = "overlay_unmeasurable_impression"),
      (W.overlay_unviewable_impression = "overlay_unviewable_impression"),
      (W.overlay_viewable_immediate_impression =
        "overlay_viewable_immediate_impression"),
      (W.overlay_viewable_end_of_session_impression =
        "overlay_viewable_end_of_session_impression"),
      (W.externalActivityEvent = "externalActivityEvent"),
      (W.adEvent = "adEvent"),
      (W.configure = "configure"),
      (W.remainingTime = "remainingTime"),
      (W.destroy = "destroy"),
      (W.resize = "resize"),
      (W.volume = "volume"),
      (W.authorIconClicked = "videoAuthorIconClicked"),
      (W.authorNameClicked = "videoAuthorClicked"),
      (W.videoClicked = "videoClicked"),
      (W.videoIconClicked = "videoIconClicked"),
      (W.learnMoreClicked = "videoLearnMoreClicked"),
      (W.muteClicked = "videoMuteClicked"),
      (W.titleClicked = "videoTitleClicked"),
      (W.videoSkipClicked = "SKIPPED"),
      (W.unmuteClicked = "videoUnmuteClicked"),
      (W.vpaidEvent = "vpaidEvent"),
      (W.show_ad = "show_ad"),
      (W.video_card_endcap_collapse = "video_card_endcap_collapse"),
      (W.video_card_endcap_dismiss = "video_card_endcap_dismiss"),
      (W.video_card_endcap_impression = "video_card_endcap_impression"),
      (W.mediaUrlPinged = "mediaUrlPinged"),
      (W.breakStart = "breakstart"),
      (W.breakEnd = "breakend"),
      (W.omidReady = "omidReady"),
      (W.omidUnavailable = "omidUnavailable"),
      (W.omidAdSessionCompleted = "omidAdSessionCompleted"),
      (W.omidAdSessionAbandoned = "omidAdSessionAbandoned"),
      (W.verificationNotExecuted = "verificationNotExecuted"),
      (W.loadStart = "loadStart"),
      (W.seeked = "seeked"),
      (W.seeking = "seeking"),
      W);
  var VC = new (function () {
    this.g = new Map();
    this.l = 0;
    this.j = null != window.fetch;
  })();
  function WC(a) {
    var b = void 0 === b ? VC : b;
    var c = void 0 === c ? null : c;
    a = new Hx(a, c ? c : c);
    var d = void 0 === d ? !1 : d;
    var e = void 0 === e ? !1 : e;
    null != a.g || e ? sy(b, a.url, d, e, a.g) : sy(b, a.url, d);
  }
  var X = function () {
    this.l = 0.01 > Math.random();
    this.j = Math.floor(4503599627370496 * Math.random());
    this.g = null;
  };
  X.prototype.report = function (a, b, c) {
    b = void 0 === b ? {} : b;
    if (null == x.G_testRunner && (this.l || (void 0 === c ? 0 : c))) {
      b.lid = a;
      IC() && (b.sdkv = IC());
      this.g && (b.palv = this.g);
      a = Mj().sort().join(",");
      nb(Kh(a)) || (b.e = a);
      b = XC(this, b);
      var d = new T("http://pagead2.googlesyndication.com/pagead/gen_204");
      Pg(
        b,
        function (e, f) {
          null != e &&
            Kw(
              d,
              f,
              null == e ? "" : "boolean" === typeof e ? (e ? "t" : "f") : "" + e
            );
        },
        this
      );
      b = SC().A;
      ("http" !== b && "https" !== b) || xw(d, b);
      b = d.toString();
      a = d.g.get("url");
      null != a && Cb() && 2083 < b.length && (b = TC(d, a));
      WC(b);
    }
  };
  var XC = function (a, b) {
    b.id = "ima_html5";
    var c = SC();
    b.c = a.j;
    b.domain = c.j;
    return b;
  };
  X.getInstance = function () {
    return I(X);
  };
  function YC(a) {
    var b = Date.now(),
      c = {};
    a = ((c["x-afma-token-requester-type"] = a), c);
    c =
      "https://pubads.g.doubleclick.net/adsid/integrator.json?aos=" +
      encodeURIComponent(RC());
    return new ey()
      .get({ url: c, withCredentials: !0, timeout: new Fx(), headers: a })
      .then(function (d) {
        var e = Date.now();
        d = d.newToken || "";
        var f = {};
        X.getInstance().report(182, ((f.t = e - b), (f.aos = RC()), f));
        return new ZC(d);
      })
      .catch(function (d) {
        var e = "not instanceof Error";
        d instanceof Error && (e = Ix(Number(d.message)));
        d = Date.now();
        var f = {};
        X.getInstance().report(182, ((f.except = e), (f.t = d - b), f));
        return Promise.resolve($C);
      });
  }
  var aD = function () {
    S.call(this);
    this.g = null;
    this.o = new Kx(this);
    In(this, this.o);
    this.j = new Qs(72e5);
    this.l = Promise.resolve($C);
  };
  v(aD, S);
  var bD = function (a) {
    var b = "requester_type_8";
    b = void 0 === b ? "requester_type_9" : b;
    var c = function (d) {
      a.g = d;
      return a.g;
    };
    a.l = YC(b).then(c);
    a.j = new Qs(72e5);
    a.o.O(a.j, "tick", function () {
      a.l = YC(b).then(c);
    });
    a.j.start();
    Hn(a, function () {
      a.j.stop();
    });
  };
  aD.prototype.getId = function () {
    var a = this;
    return Ha(function (b) {
      if (1 == b.g)
        return (
          null != a.g && a.g !== $C
            ? ((b.g = 2), (b = void 0))
            : (b = ya(b, a.l, 3)),
          b
        );
      2 != b.g && (a.g = b.j);
      return b.return(a.g);
    });
  };
  var ZC = function (a) {
      this.id = a;
    },
    $C = new ZC("");
  var cD = function (a, b, c, d, e) {
      this.name = a;
      this.type = b;
      this.data = c;
      this.id = d;
      this.g = e;
    },
    dD = function (a) {
      S.call(this);
      this.o = [];
      this.j = !1;
      this.l = a || "goog_" + Lh++;
    };
  v(dD, S);
  dD.prototype.connect = function () {
    for (this.j = !0; 0 !== this.o.length; ) {
      var a = this.o.shift();
      a && this.sendMessage(a);
    }
  };
  var eD = function (a, b, c, d, e, f) {
    a.j
      ? a.sendMessage(new cD(b, c, d, e, f))
      : a.o.push(new cD(b, c, d, e, f));
  };
  dD.prototype.sendMessage = function () {};
  var fD = function (a, b, c, d, e, f) {
    e = void 0 === e ? "" : e;
    f = void 0 === f ? "" : f;
    Lr.call(this, a);
    this.messageType = b;
    this.oa = c;
    this.fc = d;
    this.origin = e;
    this.id = f;
  };
  v(fD, Lr);
  fD.prototype.getId = function () {
    return this.id;
  };
  fD.prototype.toString = function () {
    return "";
  };
  var gD = { IMAGE: "Image", FLASH: "Flash", ALL: "All" },
    hD = { HTML: "Html", IFRAME: "IFrame", STATIC: "Static", ALL: "All" },
    iD = {
      IGNORE: "IgnoreSize",
      SELECT_EXACT_MATCH: "SelectExactMatch",
      SELECT_NEAR_MATCH: "SelectNearMatch",
      SELECT_FLUID: "SelectFluid",
    },
    jD = function () {
      this.allowCustom = !0;
      this.creativeType = this.resourceType = "All";
      this.sizeCriteria = "SelectExactMatch";
      this.nearMatchPercent = 90;
      this.adSlotIds = [];
    };
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$companion_ad_selection_settings.CompanionAdSelectionSettings.CreativeType",
    gD
  );
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$companion_ad_selection_settings.CompanionAdSelectionSettings.ResourceType",
    hD
  );
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$companion_ad_selection_settings.CompanionAdSelectionSettings.SizeCriteria",
    iD
  );
  var lD = function (a, b) {
      b = void 0 === b ? new jD() : b;
      this.g = a;
      this.settings = b ? b : new jD();
      this.resourceType = kD(hD, this.settings.resourceType)
        ? this.settings.resourceType
        : "All";
      this.creativeType = kD(gD, this.settings.creativeType)
        ? this.settings.creativeType
        : "All";
      this.sizeCriteria = kD(iD, this.settings.sizeCriteria)
        ? this.settings.sizeCriteria
        : "SelectExactMatch";
      this.adSlotIds =
        null != this.settings.adSlotIds ? this.settings.adSlotIds : [];
      this.nearMatchPercent =
        "number" === typeof this.settings.nearMatchPercent &&
        0 < this.settings.nearMatchPercent &&
        100 >= this.settings.nearMatchPercent
          ? this.settings.nearMatchPercent
          : 90;
    },
    oD = function (a, b) {
      var c = [];
      b.forEach(function (d) {
        a.settings.allowCustom &&
          (!nb(d.getContent()) &&
          (isNaN(d.data.sequenceNumber) ||
            isNaN(d.data.mainAdSequenceNumber) ||
            d.data.mainAdSequenceNumber === d.data.sequenceNumber) &&
          mD(a, d)
            ? c.push(d)
            : ((d = nD(a, d)), null != d && !nb(d.getContent()) && c.push(d)));
      });
      return c;
    };
  lD.prototype.se = function () {
    return this.resourceType;
  };
  var mD = function (a, b) {
      var c;
      if ((c = "Flash" !== b.getContentType())) {
        if ((c = "All" === a.resourceType || a.resourceType === b.se()))
          (c = b.getContentType()),
            (c =
              null == c
                ? !0
                : "All" === a.creativeType || a.creativeType === c);
        c &&
          ((c = b.getAdSlotId()),
          (c =
            0 === a.adSlotIds.length
              ? !0
              : null != c
              ? a.adSlotIds.includes(c)
              : !1));
      }
      if (c)
        if (((c = b.getSize()), (b = !!b.data.fluidSize) || a.g.qe))
          a = b && a.g.qe;
        else if ("IgnoreSize" === a.sizeCriteria || Ch(a.g.size, c)) a = !0;
        else {
          if ((b = "SelectNearMatch" === a.sizeCriteria))
            (b = c.width),
              (c = c.height),
              (b =
                b > a.g.size.width ||
                c > a.g.size.height ||
                b < (a.nearMatchPercent / 100) * a.g.size.width ||
                c < (a.nearMatchPercent / 100) * a.g.size.height
                  ? !1
                  : !0);
          a = b;
        }
      else a = !1;
      return a;
    },
    nD = function (a, b) {
      b = pD(b);
      return null == b
        ? null
        : b.find(function (c) {
            return mD(a, c);
          }) || null;
    },
    kD = function (a, b) {
      return null != b && Xg(a, b);
    };
  var qD = function (a, b) {
    this.message = a;
    this.errorCode = b;
  };
  qD.prototype.getErrorCode = function () {
    return this.errorCode;
  };
  qD.prototype.getMessage = function () {
    return this.message;
  };
  var rD = new qD(
      "Failed to initialize ad playback element before starting ad playback.",
      400
    ),
    sD = new qD("The provided {0} information: {1} is invalid.", 1101);
  function tD(a, b) {
    var c = void 0 === b ? null : b;
    var d = Ia.apply(2, arguments);
    if (!(c instanceof RB)) {
      var e = a.getErrorCode(),
        f = a.getMessage();
      if (0 < d.length)
        for (var g = 0; g < d.length; g++)
          f = f.replace(new RegExp("\\{" + g + "\\}", "ig"), d[g]);
      d = new RB("adPlayError", f, e);
      d.g = c;
      c = d;
    }
    return c;
  }
  var uD = function () {};
  uD.getInstance = function () {
    throw Error("Must be overridden");
  };
  var vD = function () {
    this.g = 0;
  };
  v(vD, uD);
  vD.tb = void 0;
  vD.getInstance = function () {
    return vD.tb ? vD.tb : (vD.tb = new vD());
  };
  function wD(a, b, c, d) {
    c = void 0 === c ? null : c;
    d = void 0 === d ? {} : d;
    var e = vD.getInstance();
    0 === e.g && (e.g = 0.001 > Math.random() ? 2 : 1);
    if (2 === e.g) {
      e = {};
      var f = Object,
        g = f.assign;
      e.c = String(a);
      a = String;
      var h = window;
      if ("number" !== typeof h.goog_pvsid)
        try {
          var k = Object,
            n = k.defineProperty,
            m = void 0;
          m = void 0 === m ? Math.random : m;
          var r = Math.floor(m() * Math.pow(2, 52));
          n.call(k, h, "goog_pvsid", { value: r, configurable: !1 });
        } catch (p) {}
      e.pc = a(Number(h.goog_pvsid) || -1);
      e.em = c;
      e.lid = b;
      I(Pu);
      Qi(g.call(f, {}, ((e.eids = ""), e), d), "esp");
    }
  }
  function xD() {
    var a = window;
    var b = void 0 === b ? function () {} : b;
    return new Promise(function (c) {
      var d = function () {
        c(b());
        Og(a, "load", d);
      };
      Ng(a, "load", d);
    });
  }
  var yD = function () {
      this.cache = {};
    },
    AD = function () {
      zD || (zD = new yD());
      return zD;
    },
    BD = function (a) {
      if (void 0 !== a)
        for (var b = u(Object.keys(a)), c = b.next(); !c.done; c = b.next())
          if (((c = c.value), c.startsWith("_GESPSK")))
            try {
              a.removeItem(c);
            } catch (d) {}
      zD = new yD();
    },
    CD = function (a) {
      var b = Af(a, 3);
      if (!b) return 3;
      if (void 0 === Bf(a, 2)) return 4;
      a = Date.now();
      return a > b + 2592e5 ? 2 : a > b + 432e5 ? 1 : 0;
    };
  yD.prototype.get = function (a, b) {
    if (this.cache[a]) return { Hb: this.cache[a], success: !0 };
    var c = "";
    try {
      c = b.getItem("_GESPSK-" + a);
    } catch (g) {
      var d;
      wD(6, a, null == (d = g) ? void 0 : d.message);
      return { Hb: null, success: !1 };
    }
    if (!c) return { Hb: null, success: !0 };
    try {
      var e = Vt(c);
      this.cache[a] = e;
      return { Hb: e, success: !0 };
    } catch (g) {
      var f;
      wD(5, a, null == (f = g) ? void 0 : f.message);
      return { Hb: null, success: !1 };
    }
  };
  yD.prototype.set = function (a, b) {
    var c = Bf(a, 1),
      d = "_GESPSK-" + c;
    Ut(a);
    try {
      b.setItem(d, Mf(a));
    } catch (f) {
      var e;
      wD(7, c, null == (e = f) ? void 0 : e.message);
      return !1;
    }
    this.cache[c] = a;
    return !0;
  };
  yD.prototype.remove = function (a, b) {
    a = Bf(a, 1);
    try {
      b.removeItem("_GESPSK-" + a), delete this.cache[a];
    } catch (d) {
      var c;
      wD(8, a, null == (c = d) ? void 0 : c.message);
    }
  };
  var zD = null;
  var DD = function () {
    Q.apply(this, arguments);
    this.g = [];
    this.j = [];
    this.l = [];
  };
  v(DD, Q);
  var ED = function (a, b) {
    a.j.push({ he: !1, ne: b });
  };
  DD.prototype.M = function () {
    this.g.length = 0;
    this.l.length = 0;
    this.j.length = 0;
    Q.prototype.M.call(this);
  };
  var FD = function () {
    var a = this;
    this.promise = new Promise(function (b, c) {
      a.resolve = b;
      a.reject = c;
    });
  };
  var GD = function (a) {
    a = Error.call(this, a);
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
    Object.setPrototypeOf(this, GD.prototype);
    this.name = "InputError";
  };
  v(GD, Error);
  var HD = function () {
      this.jb = !1;
    },
    ID = function () {
      HD.apply(this, arguments);
      this.Tc = new FD();
    };
  v(ID, HD);
  var JD = function (a, b) {
    a.jb || ((a.jb = !0), (a.Sc = b), a.Tc.resolve(b));
  };
  da.Object.defineProperties(ID.prototype, {
    promise: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.Tc.promise;
      },
    },
    Ge: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.jb;
      },
    },
    error: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.Dd;
      },
    },
  });
  var KD = function () {
    ID.apply(this, arguments);
  };
  v(KD, ID);
  var LD = function (a, b) {
      JD(a, b);
    },
    MD = function (a, b) {
      b.then(function (c) {
        JD(a, c);
      });
    };
  KD.prototype.Ya = function (a) {
    this.jb ||
      ((this.jb = !0), (this.Sc = null), (this.Dd = a), this.Tc.reject(a));
  };
  var ND = function (a) {
    this.jb = !1;
    this.g = a;
  };
  v(ND, HD);
  ND.prototype.Ge = function () {
    return this.g.jb;
  };
  da.Object.defineProperties(ND.prototype, {
    error: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.g.Dd;
      },
    },
  });
  var OD = function (a) {
    ND.call(this, a);
    this.g = a;
  };
  v(OD, ND);
  da.Object.defineProperties(OD.prototype, {
    value: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.g.Sc;
      },
    },
  });
  var PD = function (a) {
    ND.call(this, a);
    this.g = a;
  };
  v(PD, ND);
  da.Object.defineProperties(PD.prototype, {
    value: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        var a;
        return null != (a = this.g.Sc) ? a : null;
      },
    },
  });
  var QD = function () {
    ID.apply(this, arguments);
  };
  v(QD, ID);
  QD.prototype.notify = function () {
    JD(this, null);
  };
  function RD(a, b) {
    var c, d;
    return Ha(function (e) {
      if (1 == e.g)
        return (
          (c = b
            ? a.filter(function (f) {
                return !f.he;
              })
            : a),
          ya(
            e,
            Promise.all(
              c.map(function (f) {
                return f.ne.promise;
              })
            ),
            2
          )
        );
      if (a.length === c.length) return e.return();
      d = a.filter(function (f) {
        return f.he;
      });
      return ya(
        e,
        Promise.race([
          Promise.all(
            d.map(function (f) {
              return f.ne.promise;
            })
          ),
          new Promise(function (f) {
            return void setTimeout(f, b);
          }),
        ]),
        0
      );
    });
  }
  var SD = function (a, b, c) {
    Q.call(this);
    this.id = a;
    this.timeoutMs = b;
    this.A = c;
    this.B = !1;
    this.g = new DD();
    In(this, this.g);
  };
  v(SD, Q);
  SD.prototype.start = function () {
    var a = this,
      b;
    return Ha(function (c) {
      if (1 == c.g) {
        if (a.B) return c.return();
        a.B = !0;
        c.l = 2;
        return ya(c, RD(a.g.j, a.timeoutMs), 4);
      }
      if (2 != c.g) {
        if (!a.Ca()) {
          for (var d = 0, e = u(a.g.l), f = e.next(); !f.done; f = e.next()) {
            if (null == f.value.g.Sc)
              throw Error("missing input: " + a.id + "/" + d);
            ++d;
          }
          a.j();
        }
        return za(c);
      }
      b = Aa(c);
      if (a.Ca()) return c.return();
      if (
        !(b instanceof GD) &&
        b instanceof Error &&
        (a.A ? a.A(a.id, b) : a.C(a.id, b), !a.A && a.g.g.length)
      )
        for (
          d = new GD(b.message), e = u(a.g.g), f = e.next();
          !f.done;
          f = e.next()
        )
          if (((f = f.value), !f.Ge)) {
            var g = d;
            f.jb = !0;
            f.Dd = g;
            f.Tc.reject(g);
          }
      c.g = 0;
    });
  };
  var TD = function (a) {
      var b = void 0 === b ? new KD() : b;
      a.g.g.push(b);
      return b;
    },
    UD = function (a) {
      var b = void 0 === b ? new QD() : b;
      a.g.g.push(b);
      return b;
    },
    VD = function (a, b) {
      ED(a.g, b);
      b = new OD(b);
      a.g.l.push(b);
      return b;
    },
    WD = function (a, b) {
      ED(a.g, b);
      return new PD(b);
    };
  var XD = function (a, b) {
    SD.call(this, a);
    this.id = a;
    this.C = b;
  };
  v(XD, SD);
  function YD(a, b) {
    return vf(a, St, 2).some(function (c) {
      return Bf(c, 1) === b && null != Bf(c, 2);
    });
  }
  function ZD(a) {
    var b = new Yt();
    if (a) {
      var c = [],
        d = RegExp("^_GESPSK-(.+)$");
      try {
        for (var e = 0; e < a.length; e++) {
          var f = (d.exec(a.key(e)) || [])[1];
          f && c.push(f);
        }
      } catch (k) {}
      c = u(c);
      e = c.next();
      for (d = {}; !e.done; d = { Ub: void 0 }, e = c.next())
        if (
          ((d.Ub = e.value),
          (e = AD().get(d.Ub, a).Hb) &&
            !YD(b, d.Ub) &&
            ((f = CD(e)), 2 !== f && 3 !== f))
        ) {
          Jf(e, 9, !1);
          if ((f = Bf(e, 2)) && 1024 < f.length) {
            var g = {};
            wD(55, d.Ub, null, ((g.sl = String(f.length)), g));
            f = e.Ya(Qt(108));
            C(f, 2);
          }
          zf(b, 2, St, e);
          e = Bf(e, 2);
          g = f = void 0;
          var h = {};
          wD(
            19,
            d.Ub,
            null,
            ((h.hs = e ? "1" : "0"),
            (h.sl = String(
              null != (g = null == (f = e) ? void 0 : f.length) ? g : -1
            )),
            h)
          );
        }
    }
    if (!vf(b, St, 2).length) return null;
    a = {};
    wD(50, "", null, ((a.ns = String(vf(b, St, 2).length)), a));
    return Ic(b.g(), 3);
  }
  var $D = { Re: !1 };
  var aE = function () {
    var a = {};
    this.j = function () {
      var b = Mv.g,
        c = Mv.defaultValue;
      return null != a[b] ? a[b] : c;
    };
    this.g = function (b, c) {
      return null != a[b] ? a[b] : c;
    };
  };
  var bE = function () {
    Q.call(this);
    this.A = [];
    this.B = [];
    this.o = {};
    this.g = [];
    this.j = new FD();
    this.l = {};
  };
  v(bE, Q);
  var cE = function (a, b) {
      In(a, b);
      a.A.push(b);
    },
    dE = function (a, b) {
      b = u(b);
      for (var c = b.next(); !c.done; c = b.next()) cE(a, c.value);
    },
    eE = function (a) {
      var b, c, d, e, f, g, h, k, n, m, r, p;
      Ha(function (t) {
        switch (t.g) {
          case 1:
            if (!a.g.length) {
              t.g = 2;
              break;
            }
            return ya(
              t,
              Promise.all(
                a.g.map(function (w) {
                  return w.j.promise;
                })
              ),
              2
            );
          case 2:
            b = u(a.A);
            for (c = b.next(); !c.done; c = b.next()) (d = c.value), d.start();
            e = u(a.B);
            for (f = e.next(); !f.done; f = e.next()) (g = f.value), eE(g);
            if (!a.l) {
              t.g = 4;
              break;
            }
            h = Object.keys(a.l);
            if (!h.length) {
              t.g = 4;
              break;
            }
            return ya(
              t,
              Promise.all(
                Object.values(a.l).map(function (w) {
                  return w.promise;
                })
              ),
              6
            );
          case 6:
            for (k = t.j, n = 0, m = u(h), r = m.next(); !r.done; r = m.next())
              (p = r.value), (a.o[p] = k[n++]);
          case 4:
            return a.j.resolve(a.o), t.return(a.j.promise);
        }
      });
    };
  bE.prototype.run = function () {
    eE(this);
  };
  bE.prototype.M = function () {
    Q.prototype.M.call(this);
    this.A.length = 0;
    this.B.length = 0;
    this.g.length = 0;
  };
  var fE = function (a, b, c, d) {
    XD.call(this, 1041, d);
    this.storage = b;
    this.o = VD(this, a);
    c && (this.l = WD(this, c));
  };
  v(fE, XD);
  fE.prototype.j = function () {
    var a = this.o.value,
      b,
      c,
      d =
        null != (c = this.storage)
          ? c
          : null == (b = this.l)
          ? void 0
          : b.value;
    d && AD().set(a, d) && null != Bf(a, 2) && wD(27, Bf(a, 1));
  };
  var gE = function (a, b) {
    XD.call(this, 1094, b);
    this.l = UD(this);
    this.o = VD(this, a);
  };
  v(gE, XD);
  gE.prototype.j = function () {
    var a = this.o.value;
    a && (BD(a), this.l.notify());
  };
  var hE = function (a, b) {
    XD.call(this, 1048, b);
    this.l = TD(this);
    this.o = TD(this);
    this.F = VD(this, a);
  };
  v(hE, XD);
  hE.prototype.j = function () {
    var a = this.F.value,
      b = function (c) {
        var d = {};
        wD(
          c,
          Bf(a, 1),
          null,
          ((d.tic = String(Math.round((Date.now() - Af(a, 3)) / 6e4))), d)
        );
      };
    switch (CD(a)) {
      case 0:
        b(24);
        break;
      case 1:
        b(25);
        JD(this.o, a);
        break;
      case 2:
        b(26);
        JD(this.l, a);
        break;
      case 3:
        wD(9, Bf(a, 1));
        JD(this.l, a);
        break;
      case 4:
        b(23), JD(this.l, a);
    }
  };
  var iE = function (a, b, c) {
    XD.call(this, 1027, c);
    this.tc = a;
    this.storage = b;
    this.l = TD(this);
    this.o = TD(this);
  };
  v(iE, XD);
  iE.prototype.j = function () {
    var a = AD().get(this.tc, this.storage).Hb;
    if (!a) {
      a = Ut(Tt(this.tc));
      var b = this.o,
        c = a.Ya(Qt(100));
      JD(b, c);
    }
    JD(this.l, a);
  };
  var jE = function (a, b, c) {
    XD.call(this, 1046, c);
    this.output = UD(this);
    this.l = TD(this);
    this.o = VD(this, b);
    ED(this.g, a);
  };
  v(jE, XD);
  jE.prototype.j = function () {
    JD(this.l, this.o.value);
  };
  var kE = function (a, b, c) {
    XD.call(this, 1047, c);
    this.collectorFunction = a;
    this.l = TD(this);
    this.o = TD(this);
    this.F = TD(this);
    this.G = VD(this, b);
  };
  v(kE, XD);
  kE.prototype.j = function () {
    var a = this,
      b = this.G.value,
      c = Bf(b, 1);
    wD(18, c);
    try {
      var d = Yi();
      this.collectorFunction()
        .then(function (e) {
          wD(29, c, null, { delta: String(Yi() - d) });
          var f = a.l,
            g = Kf(b, 2, e);
          JD(f, g);
          JD(a.F, null != e ? e : null);
        })
        .catch(function (e) {
          wD(28, c, lE(e));
          e = a.o;
          var f = b.Ya(Qt(106));
          JD(e, f);
        });
    } catch (e) {
      wD(1, c, lE(e)), LD(this.o, b.Ya(Qt(107)));
    }
  };
  function lE(a) {
    return "string" === typeof a ? a : a instanceof Error ? a.message : null;
  }
  var mE = function (a, b) {
    XD.call(this, 1028, b);
    this.l = TD(this);
    this.o = VD(this, a);
  };
  v(mE, XD);
  mE.prototype.j = function () {
    var a = this.o.value,
      b = Bf(a, 1);
    null != Af(a, 3) || wD(35, b);
    JD(this.l, a);
  };
  var nE = function (a, b, c, d, e) {
    XD.call(this, 1050, e);
    this.G = c;
    this.F = d;
    this.l = TD(this);
    this.o = VD(this, a);
    this.H = WD(this, b);
  };
  v(nE, XD);
  nE.prototype.j = function () {
    var a = this.o.value,
      b = Bf(a, 1),
      c = this.H.value;
    if (null == c) wD(41, b), a.Ya(Qt(111)), JD(this.l, a);
    else if ("string" !== typeof c)
      wD(21, b), (b = this.l), (a = a.Ya(Qt(113))), JD(b, a);
    else {
      if (c.length > (/^(\d+)$/.test(b) ? this.F : this.G)) {
        var d = {};
        wD(12, b, null, ((d.sl = String(c.length)), d));
        b = a.Ya(Qt(108));
        C(b, 2);
      } else c.length || wD(20, b), C(a, 10);
      JD(this.l, a);
    }
  };
  var oE = function (a) {
    XD.call(this, 1046, a);
    this.output = UD(this);
  };
  v(oE, XD);
  oE.prototype.j = function () {
    var a = this;
    xD().then(function () {
      a.output.notify();
    });
  };
  function pE(a, b, c, d, e, f) {
    f = void 0 === f ? $D : f;
    var g, h, k, n, m, r, p, t, w, y, R, ka, ua;
    return Ha(function (pa) {
      return 1 == pa.g
        ? ((g = new bE()),
          (h = new iE(a, c, e)),
          cE(g, h),
          cE(g, new fE(h.o, void 0, d, e)),
          (k = new mE(h.l, e)),
          cE(g, k),
          (n = new hE(k.l, e)),
          cE(g, n),
          (m = new kE(b, n.l, e)),
          cE(g, m),
          cE(g, new fE(m.o, void 0, d, e)),
          (r = new nE(m.l, m.F, f.Re ? 1024 : 300, f.Re ? 1024 : 1e3, e)),
          cE(g, r),
          cE(g, new fE(r.l, void 0, d, e)),
          (p = new oE(e)),
          cE(g, p),
          (t = new jE(p.output, n.o, e)),
          cE(g, t),
          (w = new kE(b, t.l, e)),
          cE(g, w),
          (y = new fE(w.l, void 0, d, e)),
          cE(g, y),
          g.run(),
          (ua = a),
          ya(pa, r.l.promise, 2))
        : pa.return({
            id: ua,
            collectorGeneratedData:
              null != (ka = null == (R = pa.j) ? void 0 : Bf(R, 2)) ? ka : null,
          });
    });
  }
  var qE = function (a, b, c, d, e) {
    e = void 0 === e ? $D : e;
    XD.call(this, 1059, d);
    this.H = b;
    this.G = c;
    this.o = e;
    this.l = TD(this);
    this.J = VD(this, a);
    this.F = WD(this, c);
  };
  v(qE, XD);
  qE.prototype.j = function () {
    var a = this.F.value;
    if (a) {
      var b = this.J.value,
        c = b.id,
        d = b.collectorFunction,
        e;
      b = null != (e = b.networkCode) ? e : c;
      c = {};
      wD(42, b, null, ((c.ea = String(Number(this.H))), c));
      MD(this.l, pE(b, d, a, this.G, this.C, this.o));
    }
  };
  var rE = function (a, b) {
    XD.call(this, 1057, b);
    this.l = a;
    this.o = TD(this);
    this.F = TD(this);
  };
  v(rE, XD);
  rE.prototype.j = function () {
    if (this.l)
      if ("object" !== typeof this.l)
        wD(46, "UNKNOWN_COLLECTOR_ID"), sE(this, "UNKNOWN_COLLECTOR_ID", 112);
      else {
        var a = this.l.id,
          b = this.l.networkCode;
        a && b && (delete this.l.id, wD(47, a + ";" + b));
        a = null != b ? b : a;
        "string" !== typeof a
          ? ((b = {}),
            wD(
              37,
              "INVALID_COLLECTOR_ID",
              null,
              ((b.ii = JSON.stringify(a)), b)
            ),
            sE(this, "INVALID_COLLECTOR_ID", 102))
          : "function" !== typeof this.l.collectorFunction
          ? (wD(14, a), sE(this, a, 105))
          : I(aE).g(Ov.g, Ov.defaultValue).includes(a)
          ? (wD(22, a), sE(this, a, 104))
          : JD(this.F, this.l);
      }
    else wD(39, "UNKNOWN_COLLECTOR_ID"), sE(this, "UNKNOWN_COLLECTOR_ID", 110);
  };
  var sE = function (a, b, c) {
    a = a.o;
    b = Tt(b).Ya(Qt(c));
    JD(a, b);
  };
  var tE = function (a, b, c, d, e) {
    var f = document;
    f = void 0 === f ? document : f;
    e = void 0 === e ? $D : e;
    this.g = b;
    this.l = c;
    this.A = f;
    this.N = d;
    this.I = e;
    this.C = [];
    this.B = [];
    this.o = [];
    this.j = 0;
    a = u(a);
    for (b = a.next(); !b.done; b = a.next()) this.push(b.value);
  };
  tE.prototype.push = function (a) {
    var b = this;
    this.l || this.N();
    var c = function (f, g) {
      return void uE(b, f, g);
    };
    a = new rE(a, c);
    var d = new fE(a.o, void 0, this.g, c);
    c = new qE(a.F, this.l, this.g, c, this.I);
    var e = new bE();
    dE(e, [a, d, c]);
    e.run();
    a = c.l.promise;
    this.C.push(a);
    d = u(this.B);
    for (c = d.next(); !c.done; c = d.next()) a.then(c.value);
  };
  tE.prototype.addOnSignalResolveCallback = function (a) {
    this.B.push(a);
    for (var b = u(this.C), c = b.next(); !c.done; c = b.next())
      c.value.then(a);
  };
  tE.prototype.addErrorHandler = function (a) {
    this.o.push(a);
  };
  tE.prototype.clearAllCache = function () {
    var a = this,
      b =
        this.A.currentScript instanceof HTMLScriptElement
          ? this.A.currentScript.src
          : "";
    if (1 === this.j) {
      var c = {};
      wD(49, "", null, ((c.url = b), c));
    } else if (
      ((c = String(ti(null != b ? b : ""))),
      I(aE).g(Nv.g, Nv.defaultValue).includes(c))
    )
      (c = {}), wD(48, "", null, ((c.url = b), c));
    else {
      var d = new bE();
      c = new gE(this.g, function (e, f) {
        return void uE(a, e, f);
      });
      cE(d, c);
      d.run();
      this.j = 1;
      setTimeout(function () {
        a.j = 0;
      }, 1e3 * I(aE).j());
      d = {};
      wD(43, "", null, ((d.url = b), d));
      return c.l.promise;
    }
  };
  var uE = function (a, b, c) {
      a = u(a.o);
      for (var d = a.next(); !d.done; d = a.next()) (d = d.value), d(b, c);
    },
    vE = function (a) {
      this.push = function (b) {
        a.push(b);
      };
      this.addOnSignalResolveCallback = function (b) {
        a.addOnSignalResolveCallback(b);
      };
      this.addErrorHandler = function (b) {
        a.addErrorHandler(b);
      };
      this.clearAllCache = function () {
        a.clearAllCache();
      };
    };
  function wE(a, b, c, d, e, f) {
    f = void 0 === f ? $D : f;
    pi() !== qi()
      ? wD(16, "")
      : (xE(a, "encryptedSignalProviders", c, e) &&
          xE(a, "secureSignalProviders", c, e)) ||
        (wD(38, ""),
        yE(a, "encryptedSignalProviders", b, f, c, d, e),
        yE(a, "secureSignalProviders", b, f, c, function () {}, e));
  }
  function xE(a, b, c, d) {
    if (void 0 === a[b] || a[b] instanceof Array) return !1;
    a = a[b];
    d && a.addOnSignalResolveCallback(d);
    a.addErrorHandler(c);
    return !0;
  }
  function yE(a, b, c, d, e, f, g) {
    var h,
      k = new tE(
        null != (h = a[b]) ? h : [],
        c,
        "secureSignalProviders" === b,
        f,
        d
      );
    a[b] = new vE(k);
    g && k.addOnSignalResolveCallback(g);
    k.addErrorHandler(e);
  }
  function zE(a, b, c, d, e) {
    var f = void 0 === f ? $D : f;
    var g = new KD();
    JD(g, b);
    wE(a, g, c, d, e, f);
  }
  function AE(a, b, c, d) {
    var e = BE,
      f = new Map();
    b = b.map(function (g) {
      var h = g.tc;
      return new Promise(function (k) {
        f.set(h, k);
      });
    });
    zE(a, c, d, e, function (g) {
      var h = g.collectorGeneratedData;
      g = g.id;
      var k;
      return void (null == (k = f.get(g))
        ? void 0
        : k({ collectorGeneratedData: h, id: g }));
    });
    return b;
  }
  function CE() {
    var a;
    return null != (a = x.googletag) ? a : (x.googletag = { cmd: [] });
  }
  function DE(a) {
    if (!a || nC(a)) return null;
    try {
      return window.localStorage;
    } catch (b) {
      return null;
    }
  }
  function EE(a, b) {
    (a = DE(a)) && zE(CE(), a, function () {}, BE, b);
  }
  function FE(a, b) {
    return (b = DE(b)) && 0 !== a.length
      ? AE(CE(), a, b, function () {})
      : null;
  }
  function BE() {}
  function GE(a, b, c, d) {
    var e = new FD(),
      f = "",
      g = function (k) {
        try {
          var n = "object" === typeof k.data ? k.data : JSON.parse(k.data);
          f === n.paw_id &&
            (Og(a, "message", g),
            n.error ? e.reject(Error(n.error)) : e.resolve(d(n)));
        } catch (m) {}
      },
      h = HE(a);
    return h
      ? (Ng(a, "message", g), (f = c(h)), e.promise)
      : (c = IE(a))
      ? ((f = String(Math.floor(2147483647 * ri()))),
        Ng(a, "message", g),
        b(c, f),
        e.promise)
      : null;
  }
  function JE(a) {
    return GE(
      a,
      function (b, c) {
        var d, e;
        return void (null ==
        (d = null != (e = b.getGmaQueryInfo) ? e : b.getGmaSig)
          ? void 0
          : d.postMessage(c));
      },
      function (b) {
        return b.getQueryInfo();
      },
      function (b) {
        return b.signal;
      }
    );
  }
  function KE() {
    var a = window;
    return !!HE(a) || !!IE(a);
  }
  function HE(a) {
    var b;
    if (
      "function" === typeof (null == (b = a.gmaSdk) ? void 0 : b.getQueryInfo)
    )
      return a.gmaSdk;
  }
  function IE(a) {
    var b, c, d, e, f, g;
    if (
      "function" ===
        typeof (null == (b = a.webkit)
          ? void 0
          : null == (c = b.messageHandlers)
          ? void 0
          : null == (d = c.getGmaQueryInfo)
          ? void 0
          : d.postMessage) ||
      "function" ===
        typeof (null == (e = a.webkit)
          ? void 0
          : null == (f = e.messageHandlers)
          ? void 0
          : null == (g = f.getGmaSig)
          ? void 0
          : g.postMessage)
    )
      return a.webkit.messageHandlers;
  }
  var LE = function () {
      this.timeoutMs = 500;
      this.j = JE;
      this.signal = null;
      this.g = 0;
    },
    ME = function (a) {
      if (M(xk) || !KE()) return Promise.resolve(null);
      var b;
      return (null != (b = a.j(window)) ? b : Promise.resolve(null)).catch(
        function () {
          return "0";
        }
      );
    },
    OE = function (a) {
      var b;
      return Ha(function (c) {
        if (1 == c.g)
          return (
            (b = Date.now() - a.g),
            !a.signal || 3e5 < b
              ? (c = ya(c, NE(a), 3))
              : ((c.g = 2), (c = void 0)),
            c
          );
        2 != c.g && ((a.signal = c.j), (a.g = Date.now()));
        return c.return(a.signal);
      });
    },
    NE = function (a) {
      return Promise.race([
        ME(a).then(function (b) {
          if (null == b) return null;
          a.signal = 1e4 < b.length ? "0" : b;
          a.g = Date.now();
          return a.signal;
        }),
        Ss(a.timeoutMs, "0"),
      ]);
    };
  function xj(a, b) {
    return b instanceof RegExp ? "__REGEXP" + b.toString() : b;
  }
  function PE(a, b) {
    return b && 0 === b.toString().indexOf("__REGEXP")
      ? ((a = b.split("__REGEXP")[1].match(/\/(.*)\/(.*)?/)),
        new RegExp(a[1], a[2] || ""))
      : b;
  }
  var QE = function (a, b) {
    dD.call(this, b);
    this.B = a;
    this.g = null;
    this.C = new Kx(this);
    this.C.O(G(), "message", this.F);
  };
  v(QE, dD);
  var RE = function (a) {
    if (null == a || "string" !== typeof a || !a.startsWith("ima://"))
      return null;
    a = a.substr(6);
    try {
      return JSON.parse(a, PE);
    } catch (b) {
      return null;
    }
  };
  QE.prototype.sendMessage = function (a) {
    if (null != this.g && null != this.g.postMessage) {
      var b = this.g,
        c = b.postMessage,
        d = {};
      d.name = a.name;
      d.type = a.type;
      null != a.data && (d.data = a.data);
      a.id && (d.id = a.id);
      a.g && (d.replyToMessageId = a.g);
      d.sid = this.l;
      d.channel = this.B;
      a = [];
      zj(new yj(), d, a);
      c.call(b, "ima://" + a.join(""), "*");
    }
    null != this.g && null == this.g.postMessage && X.getInstance().report(11);
  };
  QE.prototype.M = function () {
    Gn(this.C);
    this.g = null;
    dD.prototype.M.call(this);
  };
  QE.prototype.F = function (a) {
    a = a.g;
    var b = RE(a.data);
    if (SE(this, b)) {
      if (null === this.g) (this.g = a.source), this.j || this.connect();
      else if (this.g !== a.source) return;
      SE(this, b) &&
        this.dispatchEvent(
          new fD(
            b.name,
            b.type,
            b.data || {},
            b.sid,
            a.origin,
            b.id,
            b.replyToMessageId
          )
        );
    }
  };
  var SE = function (a, b) {
    if (null == b) return !1;
    var c = b.channel;
    if (null == c || c !== a.B) return !1;
    b = b.sid;
    return null == b || ("*" !== a.l && b !== a.l) ? !1 : !0;
  };
  var TE = function () {
    S.call(this);
    this.G = !1;
    this.g = null;
    this.B = this.F = this.L = !1;
    this.j = 0;
    this.o = [];
    this.C = !1;
    this.U = this.P = Infinity;
    this.l = 0;
    this.H = {};
    this.J = new Kx(this);
    In(this, this.J);
  };
  v(TE, S);
  var VE = function (a, b) {
      null == b || a.G || ((a.g = b), UE(a), (a.G = !0));
    },
    XE = function (a) {
      null != a.g &&
        a.G &&
        (WE(a),
        (a.G = !1),
        (a.F = !1),
        (a.B = !1),
        (a.j = 0),
        (a.o = []),
        (a.C = !1));
    },
    UE = function (a) {
      WE(a);
      !(a.g instanceof S) && "ontouchstart" in document.documentElement && uc
        ? ((a.H = {
            touchstart: function (b) {
              a.F = !0;
              a.j = b.touches.length;
              a.l && (window.clearTimeout(a.l), (a.l = 0), (a.L = !0));
              a.C = YE(a, b.touches) || 1 !== b.touches.length;
              a.C
                ? ((a.P = Infinity), (a.U = Infinity))
                : ((a.P = b.touches[0].clientX), (a.U = b.touches[0].clientY));
              b = b.touches;
              a.o = [];
              for (var c = 0; c < b.length; c++) a.o.push(b[c].identifier);
            },
            touchmove: function (b) {
              a.j = b.touches.length;
              if (
                !ux(8) ||
                Math.pow(b.changedTouches[0].clientX - a.P, 2) +
                  Math.pow(b.changedTouches[0].clientY - a.U, 2) >
                  Math.pow(5, 2)
              )
                a.B = !0;
            },
            touchend: function (b) {
              return void ZE(a, b);
            },
          }),
          Pg(a.H, function (b, c) {
            a.g.addEventListener(c, b, !1);
          }))
        : a.J.O(a.g, "click", a.W);
    },
    WE = function (a) {
      a.J.ob(a.g, "click", a.W);
      Pg(
        a.H,
        function (b, c) {
          this.g.removeEventListener(c, b, !1);
        },
        a
      );
      a.H = {};
    },
    ZE = function (a, b) {
      !a.F ||
        1 !== a.j ||
        a.B ||
        a.L ||
        a.C ||
        !YE(a, b.changedTouches) ||
        (a.l = window.setTimeout(function () {
          return void $E(a);
        }, 300));
      a.j = b.touches.length;
      0 === a.j && ((a.F = !1), (a.B = !1), (a.o = []));
      a.L = !1;
    };
  TE.prototype.W = function () {
    $E(this);
  };
  var YE = function (a, b) {
      for (var c = 0; c < b.length; c++)
        if (a.o.includes(b[c].identifier)) return !0;
      return !1;
    },
    $E = function (a) {
      a.l = 0;
      a.dispatchEvent(new Lr("click"));
    };
  TE.prototype.M = function () {
    XE(this);
    S.prototype.M.call(this);
  };
  var aF = function () {
    this.l = function () {
      return new XMLHttpRequest();
    };
    this.g = new FD();
    this.j = this.config = null;
  };
  aF.prototype.getConfig = function () {
    var a = this;
    return Ha(function (b) {
      return 1 == b.g ? ya(b, a.g.promise, 2) : b.return(a.config);
    });
  };
  var eF = function () {
      var a = bF,
        b = cF,
        c = a.l();
      c.timeout = 6e4;
      c.open("GET", b, !0);
      c.onload = function () {
        if (200 > c.status || 300 <= c.status)
          dF(a, Error("status: " + c.status));
        else {
          var d = c.responseText,
            e = null;
          try {
            e = Ot(d);
          } catch (f) {
            dF(a, Error("per-pub config could not be deserialized"));
            return;
          }
          a.g.resolve();
          a.config = e;
        }
      };
      c.onerror = function () {
        dF(a, Error("status: " + c.status));
      };
      c.send();
    },
    dF = function (a, b) {
      a.j = b;
      a.g.resolve();
    },
    fF = new aF();
  function gF() {
    var a = hF,
      b = a.appName,
      c = a.lg;
    a = a.pageUrl;
    var d = new URL(
      ""
    );
    return b && c
      ? ("android" === c
          ? d.searchParams.set("msid", b)
          : "ios" === c && d.searchParams.set("an", b),
        d.toString())
      : a
      ? (d.searchParams.set("ippd", a), d.toString())
      : null;
  }
  function iF(a, b) {
    var c,
      d,
      e,
      f =
        null !=
        (e =
          null == (c = tf(a, Mt, 2))
            ? void 0
            : null == (d = vf(c, Lt, 1))
            ? void 0
            : d.map(function (g) {
                return E(g, 1);
              }))
          ? e
          : [];
    a = VB(b).every(function (g) {
      return f.includes(g);
    });
    b = UB(b);
    X.getInstance().report(190, { fm: a, rt: b });
  }
  var jF = function (a, b) {
    Q.call(this);
    var c = this;
    this.g = a;
    this.j = new Map();
    this.l = function (d) {
      var e = c.j.get(d.messageType);
      if (e) {
        var f = "goog_" + Lh++,
          g = d.getId();
        e(d.oa).then(function (h) {
          eD(c.g, d.type, d.messageType, h, f, g);
        });
      }
    };
    this.g.O(b, this.l);
    Hn(this, function () {
      c.j.clear();
      c.g.ob(b, c.l);
    });
  };
  v(jF, Q);
  var kF =
    "abort canplay canplaythrough durationchange emptied loadstart loadeddata loadedmetadata progress ratechange seeked seeking stalled suspend waiting".split(
      " "
    );
  var lF = function (a, b) {
    Q.call(this);
    this.g = a;
    this.timeoutMs = b;
    In(this, this.g);
  };
  v(lF, Q);
  var nF = function (a) {
      if (!Yv(a.g.caller)) return Promise.resolve(null);
      var b = new FD(),
        c = null;
      a.g.addEventListener(function (e) {
        if (1 === e.pingData.internalErrorState) b.resolve(null);
        else if ("listenerRegistered" === e.eventName)
          (c = e.listenerId),
            1 === e.pingData.applicableSections.length &&
              -1 === e.pingData.applicableSections[0] &&
              b.resolve(new mF("", "-1"));
        else if ("signalStatus" === e.eventName && "ready" === e.data) {
          e = e.pingData;
          var f,
            g = (null != (f = e.applicableSections) ? f : []).join("_");
          b.resolve(new mF(e.gppString, g));
        }
      });
      var d = new Promise(function (e) {
        setTimeout(function () {
          e(null);
        }, a.timeoutMs);
      });
      d = Promise.race([b.promise, d]);
      d.then(function () {
        null !== c && a.g.removeEventListener(c);
      });
      return d;
    },
    mF = function (a, b) {
      this.gppString = a;
      this.sid = b;
    };
  var oF = fa(["omsdk/releases/live/omweb-v1.js"]),
    pF = fa(["omsdk/releases/control/omweb-v1.js"]),
    qF = fa(["omsdk/releases/canary/omweb-v1.js"]),
    rF = fa(["omsdk/releases/experimental/omweb-v1.js"]),
    sF = yh(oF),
    tF = yh(pF),
    uF = yh(qF),
    vF = yh(rF);
  function wF(a) {
    return (a = di(a)) && a.omidSessionInterface
      ? a.omidSessionInterface
      : null;
  }
  function xF(a) {
    var b, c, d, e, f, g;
    return Ha(function (h) {
      if (1 == h.g)
        return (
          (b = $h("IFRAME", {
            style: "display: none",
            title: "Advertisement",
          })),
          (c = new Promise(function (k) {
            b.addEventListener("load", function () {
              k();
            });
          })),
          a.appendChild(b),
          ya(h, c, 2)
        );
      d = $h("SCRIPT");
      e = sF;
      M(ok) ? (e = tF) : M(pk) ? (e = uF) : M(qk) && (e = vF);
      Eh(d, e);
      f = new Promise(function (k, n) {
        d.addEventListener("load", function () {
          wF(b) ? k(b) : n();
        });
      });
      g = b.contentDocument || b.contentWindow.document;
      g.head.appendChild(d);
      return h.return(f);
    });
  }
  var yF = function (a, b) {
    S.call(this);
    this.j = b;
    this.g = wF(a);
  };
  v(yF, S);
  var AF = function (a) {
      try {
        a.g &&
          a.g.registerSessionObserver(function (b) {
            "sessionStart" === b.type
              ? zF(a, a.j)
              : "sessionFinish" === b.type && AF(a);
          });
      } catch (b) {
        a.dispatchEvent(new Event("error"));
      }
    },
    zF = function (a, b) {
      b instanceof dB && (b = b.T);
      var c;
      if ("AUDIO" !== (null == (c = b.tagName) ? void 0 : c.toUpperCase()))
        try {
          a.g && a.g.setVideoElement(b);
        } catch (d) {
          a.dispatchEvent(new Event("error"));
        }
    },
    BF = function (a, b) {
      try {
        a.g && a.g.setSessionClientWindow(b);
      } catch (c) {
        a.dispatchEvent(new Event("error"));
      }
    };
  var CF = function (a) {
    this.data = a;
  };
  l = CF.prototype;
  l.getTotalAds = function () {
    return this.data.totalAds;
  };
  l.getMaxDuration = function () {
    return this.data.maxDuration;
  };
  l.getAdPosition = function () {
    return this.data.adPosition;
  };
  l.getPodIndex = function () {
    return this.data.podIndex;
  };
  l.getTimeOffset = function () {
    return this.data.timeOffset;
  };
  l.getIsBumper = function () {
    return this.data.isBumper;
  };
  CF.prototype.getIsBumper = CF.prototype.getIsBumper;
  CF.prototype.getTimeOffset = CF.prototype.getTimeOffset;
  CF.prototype.getPodIndex = CF.prototype.getPodIndex;
  CF.prototype.getAdPosition = CF.prototype.getAdPosition;
  CF.prototype.getMaxDuration = CF.prototype.getMaxDuration;
  CF.prototype.getTotalAds = CF.prototype.getTotalAds;
  var DF = function (a) {
    this.data = a;
  };
  l = DF.prototype;
  l.getContent = function () {
    return this.data.content;
  };
  l.getContentType = function () {
    return this.data.contentType;
  };
  l.getWidth = function () {
    return this.getSize().width;
  };
  l.getHeight = function () {
    return this.getSize().height;
  };
  l.getAdSlotId = function () {
    return this.data.adSlotId;
  };
  l.getSize = function () {
    return this.data.size;
  };
  l.se = function () {
    return this.data.resourceType;
  };
  var pD = function (a) {
    return (a = a.data.backupCompanions)
      ? a.map(function (b) {
          return new DF(b);
        })
      : [];
  };
  DF.prototype.getAdSlotId = DF.prototype.getAdSlotId;
  DF.prototype.getHeight = DF.prototype.getHeight;
  DF.prototype.getWidth = DF.prototype.getWidth;
  DF.prototype.getContentType = DF.prototype.getContentType;
  DF.prototype.getContent = DF.prototype.getContent;
  var EF = function (a, b) {
    this.j = a;
    this.g = b;
  };
  EF.prototype.getAdIdValue = function () {
    return this.j;
  };
  EF.prototype.getAdIdRegistry = function () {
    return this.g;
  };
  EF.prototype.getAdIdRegistry = EF.prototype.getAdIdRegistry;
  EF.prototype.getAdIdValue = EF.prototype.getAdIdValue;
  var Y = function (a) {
    this.data = a;
  };
  Y.prototype.getAdId = function () {
    return this.data.adId;
  };
  Y.prototype.getCreativeAdId = function () {
    return this.data.creativeAdId;
  };
  Y.prototype.getCreativeId = function () {
    return this.data.creativeId;
  };
  var FF = function (a) {
    return a.data.adQueryId;
  };
  l = Y.prototype;
  l.getAdSystem = function () {
    return this.data.adSystem;
  };
  l.getAdvertiserName = function () {
    return this.data.advertiserName;
  };
  l.getApiFramework = function () {
    return this.data.apiFramework;
  };
  l.getWrapperAdIds = function () {
    return this.data.adWrapperIds;
  };
  l.getWrapperCreativeIds = function () {
    return this.data.adWrapperCreativeIds;
  };
  l.getWrapperAdSystems = function () {
    return this.data.adWrapperSystems;
  };
  l.isLinear = function () {
    return this.data.linear;
  };
  l.isSkippable = function () {
    return this.data.skippable;
  };
  l.getContentType = function () {
    return this.data.contentType;
  };
  l.getDescription = function () {
    return this.data.description;
  };
  l.getTitle = function () {
    return this.data.title;
  };
  l.getDuration = function () {
    return this.data.duration;
  };
  l.getVastMediaWidth = function () {
    return this.data.vastMediaWidth;
  };
  l.getVastMediaHeight = function () {
    return this.data.vastMediaHeight;
  };
  l.getWidth = function () {
    return this.data.width;
  };
  l.getHeight = function () {
    return this.data.height;
  };
  l.getUiElements = function () {
    return this.data.uiElements;
  };
  l.getMinSuggestedDuration = function () {
    return this.data.minSuggestedDuration;
  };
  l.getAdPodInfo = function () {
    return new CF(this.data.adPodInfo);
  };
  l.getCompanionAds = function (a, b, c) {
    if (!this.data.companions) return [];
    var d = this.data.companions.map(function (e) {
      return new DF(e);
    });
    return oD(
      new lD(
        { size: new Bh(a, b), qe: c ? "SelectFluid" === c.sizeCriteria : !1 },
        c
      ),
      d
    );
  };
  l.getTraffickingParameters = function () {
    return Dx(Kh(this.data.traffickingParameters));
  };
  l.getTraffickingParametersString = function () {
    return this.data.traffickingParameters;
  };
  l.getVastMediaBitrate = function () {
    return this.data.vastMediaBitrate;
  };
  l.getMediaUrl = function () {
    return this.data.mediaUrl;
  };
  l.getSurveyUrl = function () {
    return this.data.surveyUrl;
  };
  l.getDealId = function () {
    return this.data.dealId;
  };
  l.getUniversalAdIds = function () {
    return (this.data.universalAdIds || []).map(function (a) {
      return new EF(a.adIdValue, a.adIdRegistry);
    });
  };
  l.getUniversalAdIdValue = function () {
    return this.data.universalAdIdValue;
  };
  l.getUniversalAdIdRegistry = function () {
    return this.data.universalAdIdRegistry;
  };
  l.getSkipTimeOffset = function () {
    return this.data.skipTimeOffset;
  };
  l.ye = function () {
    return this.data.disableUi;
  };
  Y.prototype.isUiDisabled = Y.prototype.ye;
  Y.prototype.getSkipTimeOffset = Y.prototype.getSkipTimeOffset;
  Y.prototype.getUniversalAdIdRegistry = Y.prototype.getUniversalAdIdRegistry;
  Y.prototype.getUniversalAdIdValue = Y.prototype.getUniversalAdIdValue;
  Y.prototype.getUniversalAdIds = Y.prototype.getUniversalAdIds;
  Y.prototype.getDealId = Y.prototype.getDealId;
  Y.prototype.getSurveyUrl = Y.prototype.getSurveyUrl;
  Y.prototype.getMediaUrl = Y.prototype.getMediaUrl;
  Y.prototype.getVastMediaBitrate = Y.prototype.getVastMediaBitrate;
  Y.prototype.getTraffickingParametersString =
    Y.prototype.getTraffickingParametersString;
  Y.prototype.getTraffickingParameters = Y.prototype.getTraffickingParameters;
  Y.prototype.getCompanionAds = Y.prototype.getCompanionAds;
  Y.prototype.getAdPodInfo = Y.prototype.getAdPodInfo;
  Y.prototype.getMinSuggestedDuration = Y.prototype.getMinSuggestedDuration;
  Y.prototype.getUiElements = Y.prototype.getUiElements;
  Y.prototype.getHeight = Y.prototype.getHeight;
  Y.prototype.getWidth = Y.prototype.getWidth;
  Y.prototype.getVastMediaHeight = Y.prototype.getVastMediaHeight;
  Y.prototype.getVastMediaWidth = Y.prototype.getVastMediaWidth;
  Y.prototype.getDuration = Y.prototype.getDuration;
  Y.prototype.getTitle = Y.prototype.getTitle;
  Y.prototype.getDescription = Y.prototype.getDescription;
  Y.prototype.getContentType = Y.prototype.getContentType;
  Y.prototype.isSkippable = Y.prototype.isSkippable;
  Y.prototype.isLinear = Y.prototype.isLinear;
  Y.prototype.getWrapperAdSystems = Y.prototype.getWrapperAdSystems;
  Y.prototype.getWrapperCreativeIds = Y.prototype.getWrapperCreativeIds;
  Y.prototype.getWrapperAdIds = Y.prototype.getWrapperAdIds;
  Y.prototype.getApiFramework = Y.prototype.getApiFramework;
  Y.prototype.getAdvertiserName = Y.prototype.getAdvertiserName;
  Y.prototype.getAdSystem = Y.prototype.getAdSystem;
  Y.prototype.getCreativeId = Y.prototype.getCreativeId;
  Y.prototype.getCreativeAdId = Y.prototype.getCreativeAdId;
  Y.prototype.getAdId = Y.prototype.getAdId;
  var GF = function (a) {
    this.g = a;
  };
  GF.prototype.getCuePoints = function () {
    return this.g;
  };
  GF.prototype.getCuePoints = GF.prototype.getCuePoints;
  var IF = function () {
      this.useLearnMoreButton = this.disableUi = this.disableClickThrough = !1;
      this.autoAlign = this.useVideoAdUi = !0;
      this.bitrate = -1;
      this.enablePreloading = !1;
      this.loadVideoTimeout = HF;
      this.mimeTypes = null;
      this.playAdsAfterTime = -1;
      this.restoreCustomPlaybackStateOnAdBreakComplete = !1;
      this.uiElements = null;
      this.useStyledNonLinearAds = this.useStyledLinearAds = !1;
    },
    JF = function (a, b) {
      var c = {};
      Object.assign(c, a);
      b && (c.disableClickThrough = !0);
      return c;
    };
  IF.prototype.append = function (a) {
    if (a) {
      var b = a.autoAlign;
      null != b && (this.autoAlign = b);
      b = Ph(a.bitrate);
      "number" === typeof b && !isNaN(b) && 0 < b && (this.bitrate = b);
      this.disableClickThrough =
        a.disableClickThrough || this.disableClickThrough;
      this.disableUi = a.disableUi || this.disableUi;
      this.enablePreloading = a.enablePreloading || this.enablePreloading;
      (b = a.mimeTypes) && 0 !== b.length && (this.mimeTypes = b);
      b = Ph(a.playAdsAfterTime);
      "number" === typeof b &&
        !isNaN(b) &&
        0 < b &&
        (this.playAdsAfterTime = b);
      this.restoreCustomPlaybackStateOnAdBreakComplete =
        a.restoreCustomPlaybackStateOnAdBreakComplete ||
        this.restoreCustomPlaybackStateOnAdBreakComplete;
      b = Ph(a.loadVideoTimeout);
      "number" === typeof b &&
        !isNaN(b) &&
        0 < b &&
        (this.loadVideoTimeout = b);
      this.uiElements = a.uiElements || this.uiElements;
      this.useLearnMoreButton = a.useLearnMoreButton || this.useLearnMoreButton;
      this.useStyledLinearAds = a.useStyledLinearAds || this.useStyledLinearAds;
      this.useStyledNonLinearAds =
        a.useStyledNonLinearAds || this.useStyledNonLinearAds;
      this.useVideoAdUi = !1 === a.useVideoAdUi ? !1 : this.useVideoAdUi;
    }
  };
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ads_rendering_settings.AdsRenderingSettings.AUTO_SCALE",
    -1
  );
  var HF = M(Bk) ? 4e3 : M(Ck) ? 6500 : M(Dk) ? 12e3 : 8e3;
  var KF = function (a) {
    this.K = B(a);
  };
  v(KF, F);
  var LF = function (a) {
    this.K = B(a);
  };
  v(LF, F);
  var MF = function (a) {
    this.K = B(a);
  };
  v(MF, F);
  var NF = function (a) {
    this.K = B(a);
  };
  v(NF, F);
  var OF = function (a) {
    this.K = B(a);
  };
  v(OF, F);
  var PF = function (a) {
    return sf(a, Iu);
  };
  OF.prototype.getWidth = function () {
    return Ef(this, 9);
  };
  OF.prototype.getHeight = function () {
    return Ef(this, 10);
  };
  var QF = Fg(OF);
  OF.na = [3, 7, 27, 11, 32];
  function RF(a) {
    var b = a.Kg,
      c = a.zi,
      d = a.Ji,
      e = a.auctionNonce,
      f = void 0 === a.Bf ? 0 : a.Bf,
      g = a.Ki,
      h = a.ri;
    a = !Df(b, 14);
    for (var k = {}, n = u(vf(b, LF, 7)), m = n.next(); !m.done; m = n.next()) {
      m = m.value;
      var r = {},
        p = void 0,
        t = null == (p = d) ? void 0 : p.kg.Fg.Jg.Ef;
      p = E(m, 1);
      if (E(m, 2).length)
        try {
          if (((r = JSON.parse(E(m, 2))), 1 > 100 * ri())) {
            var w = void 0;
            null == (w = t) || w.qd({ fd: p, status: "SUCCESS", Rd: 100 });
          }
        } catch (Ma) {
          (w = void 0),
            null == (w = t) || w.qd({ fd: p, status: "ERROR", Rd: 1 });
        }
      else
        (w = void 0),
          null == (w = t) || w.qd({ fd: p, status: "EMPTY", Rd: 1 });
      k[E(m, 1)] = r;
    }
    if ((d = tf(b, Gu, 6)))
      (k["https://googleads.g.doubleclick.net"] = d.toJSON()),
        (k["https://td.doubleclick.net"] = d.toJSON());
    n = {};
    d = vf(b, NF, 11);
    d = u(d);
    for (m = d.next(); !m.done; m = d.next())
      (m = m.value), (n[E(m, 1)] = Ef(m, 2));
    m = {};
    0 !== Ef(b, 21) && (m["*"] = Ef(b, 21));
    if (0 < vf(b, MF, 32).length) {
      var y = {};
      d = u(vf(b, MF, 32));
      for (r = d.next(); !r.done; r = d.next())
        (r = r.value), (y[E(r, 1)] = Ef(r, 2));
    }
    r = {};
    null != ke(df(b, 18)) &&
      ((r["https://googleads.g.doubleclick.net"] = Ff(b, 18)),
      (r["https://td.doubleclick.net"] = Ff(b, 18)));
    d = b.K;
    t = Ed(d);
    d = nf(d, t, cf(d, t, 24), 24, KF);
    d = u(d);
    for (t = d.next(); !t.done; t = d.next())
      (p = t.value), Ff(p[1], 4) && ((t = p[0]), (p = Ff(p[1], 4)), (r[t] = p));
    d = E(b, 1).split("/td/")[0];
    null == (t = tf(b, Iu, 5))
      ? (t = void 0)
      : ((p = t.K), (t = Ae(t.constructor, af(p, Ed(p), !1))));
    var R;
    null != t && null != (R = tf(t, Hu, 5)) && C(R, 2);
    R = Object;
    p = R.assign;
    w = E(b, 1);
    var ka = E(b, 2);
    var ua = gf(b, 3, ue);
    y = p.call(
      R,
      {},
      {
        seller: d,
        decisionLogicUrl: w,
        trustedScoringSignalsUrl: ka,
        interestGroupBuyers: ua,
        sellerExperimentGroupId: Ff(b, 17),
        auctionSignals: JSON.parse(E(b, 4) || "{}"),
        sellerSignals: (null == t ? void 0 : t.toJSON()) || [],
        sellerTimeout: Ef(b, 15) || 50,
        perBuyerExperimentGroupIds: r,
        perBuyerSignals: k,
        perBuyerTimeouts: n,
        perBuyerCumulativeTimeouts: m,
      },
      y ? { perBuyerGroupLimits: y } : {},
      a ? { resolveToConfig: a } : {}
    );
    if (null == b ? 0 : Df(PF(b), 25))
      (y.sellerCurrency = "USD"),
        (k = Object),
        (R = k.fromEntries),
        (n = of(b, 22, ye)),
        (y.perBuyerCurrencies = R.call(k, n));
    E(b, 28) && (y.directFromSellerSignalsHeaderAdSlot = E(b, 28));
    if (SF(y.interestGroupBuyers, h)) {
      y.auctionReportBuyerKeys = y.interestGroupBuyers.map(TF);
      y.auctionReportBuyers = {
        interestGroupCount: { bucket: BigInt(0), scale: 1 },
        bidCount: { bucket: BigInt(1), scale: 1 },
        totalGenerateBidLatency: { bucket: BigInt(2), scale: 1 },
        totalSignalsFetchLatency: { bucket: BigInt(3), scale: 1 },
      };
      var pa = void 0 === pa ? BigInt(0) : pa;
      y.auctionReportBuyerDebugModeConfig = { enabled: !0, debugKey: pa };
    }
    e && ((y.auctionNonce = e), (y.additionalBids = Promise.resolve()));
    of(b, 33, ye).size &&
      ((y.deprecatedRenderURLReplacements = Object.fromEntries(
        of(b, 33, ye).entries()
      )),
      (e =
        y.deprecatedRenderURLReplacements[
          "${RENDER_DATA_td.doubleclick.net_GDA}"
        ]) && (y.deprecatedRenderURLReplacements["${RENDER_DATA}"] = e));
    switch (f) {
      case 1:
        y.allSlotsRequestedSizes = [
          { width: b.getWidth(), height: b.getHeight() },
        ];
    }
    g && (y.reportingTimeout = g);
    f = Object;
    g = f.assign;
    e = E(b, 1);
    pa = Ff(b, 17);
    h = new Iu();
    k = PF(b);
    void 0 !== rf(k, Hu, 5, !1) &&
      ((k = new Hu()),
      (R = If(sf(PF(b), Hu), 2)),
      (k = D(k, 2, le(R), "0")),
      (R = If(sf(PF(b), Hu), 4)),
      (k = D(k, 4, le(R), "0")),
      wf(h, 5, k));
    PF(b).getEscapedQemQueryId() &&
      ((k = PF(b).getEscapedQemQueryId()), D(h, 2, te(k), ""));
    E(PF(b), 6) && ((k = E(PF(b), 6)), D(h, 6, te(k), ""));
    Df(PF(b), 21) && D(h, 21, ae(!0), !1);
    Df(PF(b), 4) && D(h, 4, ae(!0), !1);
    E(PF(b), 11) && ((k = E(PF(b), 11)), D(h, 11, te(k), ""));
    h = h.toJSON();
    k = Ef(b, 15) || 50;
    if (Df(b, 30)) {
      if (null == c || !c.length)
        throw Error("top_td_without_component_auction");
    } else c = [y].concat(ha(null != c ? c : []));
    c = g.call(
      f,
      {},
      {
        seller: d,
        decisionLogicUrl: e,
        sellerExperimentGroupId: pa,
        sellerSignals: h,
        sellerTimeout: k,
        interestGroupBuyers: [],
        auctionSignals: {},
        perBuyerExperimentGroupIds: {},
        perBuyerSignals: {},
        perBuyerTimeouts: {},
        perBuyerCumulativeTimeouts: {},
        componentAuctions: c,
      },
      a ? { resolveToConfig: a } : {}
    );
    E(b, 28) && (c.directFromSellerSignalsHeaderAdSlot = E(b, 28));
    return c;
  }
  function SF(a, b) {
    return (
      a.some(function (c) {
        return TF(c) !== BigInt(100);
      }) && (null != b ? b : !1)
    );
  }
  function TF(a) {
    var b;
    return null !=
      (b = new Map([
        ["https://googleads.g.doubleclick.net", BigInt(200)],
        ["https://td.doubleclick.net", BigInt(300)],
        ["https://f.creativecdn.com", BigInt(400)],
        ["https://fledge.us.criteo.com", BigInt(500)],
        ["https://fledge.eu.criteo.com", BigInt(600)],
        ["https://fledge.as.criteo.com", BigInt(700)],
      ]).get(a))
      ? b
      : BigInt(100);
  }
  var VF = function (a, b) {
    Q.call(this);
    var c = this;
    this.j = b;
    this.l = function (d) {
      return UF(c, d.tdconfig).then(function (e) {
        var f = {};
        return (
          (f.ffconfig =
            ("string" === typeof e ? e : null == e ? void 0 : e.url) || ""),
          f
        );
      });
    };
    this.g = new jF(a, "fledge");
    In(this, this.g);
  };
  v(VF, Q);
  var UF = function (a, b) {
      try {
        return WF(a, b).catch(function () {
          return null;
        });
      } catch (c) {
        return Promise.resolve(null);
      }
    },
    WF = function (a, b) {
      b = QF(b);
      var c = RF({ Kg: b });
      b = Ss(500, null);
      a = a.j.runAdAuction(c).then(function (d) {
        return d;
      });
      return Promise.race([b, a]);
    };
  var YF = function (a, b, c) {
    Q.call(this);
    this.C = a;
    this.o = b;
    this.B = c;
    this.g = this.j = this.l = null;
    this.A = 0;
    a = new Kx(this);
    In(this, a);
    XF(this);
    a.O(this.o, "adsManager", this.F);
  };
  v(YF, Q);
  var ZF = function (a, b) {
      a.l = b;
      a.g && a.l && BF(a.g, a.l);
    },
    XF = function (a) {
      xF(a.C)
        .then(function (b) {
          return void $F(a, b);
        })
        .catch(function () {
          return void aG(a);
        });
    };
  YF.prototype.F = function (a) {
    if (["complete", "skip", "error"].includes(a.messageType)) {
      this.A++;
      if (10 === this.A) {
        this.A = 0;
        var b;
        null == (b = this.g) || b.X();
        XF(this);
      }
      a = di(this.j);
      var c;
      (a && (null == (c = a.frames) ? 0 : c.omid_v1_present)) ||
        X.getInstance().report(188, {});
    }
  };
  var $F = function (a, b) {
      a.j = b;
      a.g = new yF(b, a.B);
      a.g.O("error", function () {
        return void aG(a);
      });
      AF(a.g);
      a.g && a.l && BF(a.g, a.l);
    },
    aG = function (a) {
      eD(a.o, "omid", "iframeFailed");
      a.X();
    };
  YF.prototype.M = function () {
    this.j && (ai(this.j), (this.j = null));
    Q.prototype.M.call(this);
  };
  var bG = function (a, b, c, d) {
    Q.call(this);
    this.A = a;
    this.l = b;
    this.g = c;
    this.C = d;
    this.j = new Kx(this);
    In(this, this.j);
    this.j.O(this.A, d, this.B);
  };
  v(bG, Q);
  var cG = function (a, b) {
    var c = b.oa;
    switch (b.messageType) {
      case "showVideo":
        a.l.Zc();
        break;
      case "hide":
        a.l.ib();
        break;
      case "resizeAndPositionVideo":
        b = c.resizeAndPositionVideo;
        a.l.Kd(new Ci(b.x, b.y, b.width, b.height));
        break;
      case "restoreSizeAndPositionVideo":
        a.l.Ld();
    }
  };
  bG.prototype.B = function (a) {
    var b = a.oa;
    switch (a.messageType) {
      case "activate":
        this.l.jc(this.g);
        break;
      case "startTracking":
        a = this.g;
        var c = this.o;
        this.j.O(a, Tg(uy), c);
        this.j.O(a, kF, c);
        a = this.g;
        dG(a);
        a.j.O(a.g, kF, a.Oa);
        a.j.O(a.g, "ended", a.ng);
        a.j.O(a.g, "webkitbeginfullscreen", a.Pa);
        a.j.O(a.g, "webkitendfullscreen", a.ga);
        a.j.O(a.g, "loadedmetadata", a.pg);
        a.j.O(a.g, "pause", a.rg);
        a.j.O(a.g, "playing", a.ze);
        a.j.O(a.g, "timeupdate", a.sg);
        a.j.O(a.g, "volumechange", a.ug);
        a.j.O(a.g, "error", a.Y);
        a.j.O(a.g, Dc || (uc && !ux(8)) ? "loadeddata" : "canplay", a.og);
        a.o = new TE();
        a.j.O(a.o, "click", a.ka);
        VE(a.o, a.g);
        a.G = new Qs(1e3);
        a.j.O(a.G, "tick", a.Ha);
        a.G.start();
        break;
      case "stopTracking":
        a = this.g;
        c = this.o;
        this.j.ob(a, Tg(uy), c);
        this.j.ob(a, kF, c);
        dG(this.g);
        break;
      case "exitFullscreen":
        a = this.g;
        (rc || tc) &&
          a.g.webkitDisplayingFullscreen &&
          a.g.webkitExitFullscreen();
        break;
      case "play":
        eG(this.g);
        break;
      case "pause":
        this.g.pause();
        break;
      case "load":
        a = this.g;
        c = b.videoUrl;
        var d = b.muxedMediaUrl,
          e = b.muxedMimeType,
          f = b.muxedAudioCodec,
          g = b.muxedVideoCodec,
          h = b.demuxedAudioUrl,
          k = b.demuxedVideoUrl,
          n = b.demuxedAudioMimeType,
          m = b.demuxedVideoMimeType,
          r = b.demuxedAudioCodec,
          p = b.demuxedVideoCodec;
        b = b.mseCompatible;
        var t = null;
        k &&
          h &&
          b &&
          m &&
          n &&
          p &&
          r &&
          (t = new Uv({
            Qg: k,
            Df: h,
            Oi: null,
            ti: null,
            Pg: m,
            Cf: n,
            pb: p,
            Za: r,
            height: null,
            width: null,
            Ea: b,
            Ni: null,
            si: null,
          }));
        h = null;
        d &&
          e &&
          g &&
          f &&
          (h = new Vv({
            jg: d,
            vb: null,
            mimeType: e,
            pb: g,
            Za: f,
            height: null,
            width: null,
            Ea: b,
            Bi: null,
          }));
        t ? a.load(c, t) : h ? a.load(c, h) : a.load(c, null);
        break;
      case "unload":
        a = this.g;
        fG(a);
        a.U = !1;
        "removeAttribute" in a.g ? a.g.removeAttribute("src") : (a.g.src = "");
        a.g.load();
        break;
      case "setCurrentTime":
        this.g.g.currentTime = b.currentTime;
        break;
      case "setVolume":
        this.g.setVolume(b.volume);
    }
  };
  bG.prototype.o = function (a) {
    var b = {};
    switch (a.type) {
      case "autoplayDisallowed":
        a = "autoplayDisallowed";
        break;
      case "beginFullscreen":
        a = "fullscreen";
        break;
      case "endFullscreen":
        a = "exitFullscreen";
        break;
      case "click":
        a = "click";
        break;
      case "end":
        a = "end";
        break;
      case "error":
        a = "error";
        break;
      case "loaded":
        a = "loaded";
        break;
      case "mediaLoadTimeout":
        a = "mediaLoadTimeout";
        break;
      case "pause":
        a = "pause";
        b.ended = this.g.g.ended;
        break;
      case "play":
        a = "play";
        break;
      case "skip":
        a = "skip";
        break;
      case "start":
        a = "start";
        b.volume = this.g.getVolume();
        break;
      case "timeUpdate":
        a = "timeupdate";
        b.currentTime = this.g.getCurrentTime();
        b.duration = this.g.getDuration();
        break;
      case "volumeChange":
        a = "volumeChange";
        b.volume = this.g.getVolume();
        break;
      case "loadedmetadata":
        a = a.type;
        b.duration = this.g.getDuration();
        break;
      case "abort":
      case "canplay":
      case "canplaythrough":
      case "durationchange":
      case "emptied":
      case "loadstart":
      case "loadeddata":
      case "progress":
      case "ratechange":
      case "seeked":
      case "seeking":
      case "stalled":
      case "suspend":
      case "waiting":
        a = a.type;
        break;
      default:
        return;
    }
    eD(this.A, this.C, a, b);
  };
  var gG = function (a, b) {
    Q.call(this);
    this.j = b;
    this.g = null;
    this.l = new bG(a, b, this.j.da, "videoDisplay1");
    In(this, this.l);
    var c = this.j.Aa;
    null != c &&
      ((this.g = new bG(a, b, c, "videoDisplay2")), In(this, this.g));
  };
  v(gG, Q);
  var hG = function (a, b, c, d) {
    var e = yi("IFRAME");
    e.id = b;
    e.name = b;
    e.width = String(c);
    e.height = String(d);
    e.allowTransparency = "true";
    e.scrolling = "no";
    e.marginWidth = "0";
    e.marginHeight = "0";
    e.frameBorder = "0";
    e.style.border = "0";
    e.style.verticalAlign = "bottom";
    e.src = "about:blank";
    e.setAttribute("aria-label", "Advertisement");
    e.title = "3rd party ad content";
    e.tabIndex = 0;
    a.appendChild(e);
    return e;
  };
  function iG() {
    var a,
      b,
      c,
      d = G();
    d = void 0 === d ? window : d;
    d = (null != (c = void 0 === d ? null : d) ? c : window).googletag;
    c = (null == d ? 0 : d.apiReady) ? d : void 0;
    return null !=
      (b =
        null == c ? void 0 : null == (a = c.companionAds) ? void 0 : a.call(c))
      ? b
      : null;
  }
  function jG(a) {
    var b = {};
    b.slotId = a.getSlotId().getId();
    var c = [];
    a = u(a.getSizes() || []);
    for (var d = a.next(); !d.done; d = a.next())
      if (((d = d.value), "string" !== typeof d)) {
        var e = {};
        c.push(((e.adWidth = d.getWidth()), (e.adHeight = d.getHeight()), e));
      } else "fluid" === d && ((d = {}), c.push(((d.fluidSize = !0), d)));
    return (b.adSizes = c), b;
  }
  function kG(a) {
    var b = iG();
    if (b && a && Array.isArray(a)) {
      var c = new Map(
        b.getSlots().map(function (p) {
          return [p.getSlotId().getId(), p];
        })
      );
      a = u(a);
      for (var d = a.next(); !d.done; d = a.next()) {
        var e = d.value,
          f = c.get(e.slotId);
        if (f && !b.isSlotAPersistentRoadblock(f)) {
          var g = e.adContent;
          if (g && (d = Th(f.getSlotId().getDomId()))) {
            d.style.display = "";
            var h = e.adWidth,
              k = e.adHeight;
            e.fluidSize && ((k = Rm(d)), (h = k.width), (k = k.height));
            d.textContent = "";
            if (e.friendlyIframeRendering)
              try {
                var n = "google_companion_" + f.getSlotId().getId(),
                  m = hG(d, n, h, k),
                  r = m.contentWindow
                    ? m.contentWindow.document
                    : m.contentDocument;
                nc && r.open("text/html", "replace");
                Gh(r, ij(g));
                r.close();
              } catch (p) {}
            else
              Dh(d, ij(g)),
                (d.style.width = h + "px"),
                (d.style.height = k + "px");
            b.slotRenderEnded(f, h, k);
            (e = e.onAdContentSet) && e(d);
          }
        }
      }
    }
  }
  var lG = function (a, b, c, d, e, f) {
    fD.call(this, a, b, c, d, e);
    this.g = f;
  };
  v(lG, fD);
  var mG = function (a, b) {
    S.call(this);
    this.B = a;
    this.o = b;
    this.g = {};
    this.j = new Kx(this);
    In(this, this.j);
    this.j.O(G(), "message", this.l);
  };
  v(mG, S);
  var nG = function (a, b) {
      var c = b.g;
      a.g.hasOwnProperty(c) && eD(a.g[c], b.type, b.messageType, b.oa);
    },
    oG = function (a, b, c, d) {
      a.g.hasOwnProperty(b) ||
        ((c = new QE(b, c)),
        a.j.O(c, a.B, function (e) {
          this.dispatchEvent(
            new lG(e.type, e.messageType, e.oa, e.fc, e.origin, b)
          );
        }),
        (c.g = d),
        c.connect(),
        (a.g[b] = c));
    };
  mG.prototype.M = function () {
    for (var a = u(Object.values(this.g)), b = a.next(); !b.done; b = a.next())
      Gn(b.value);
    S.prototype.M.call(this);
  };
  mG.prototype.l = function (a) {
    a = a.g;
    var b = RE(a.data);
    if (null != b) {
      var c = b.channel;
      if (this.o && !this.g.hasOwnProperty(c)) {
        var d = b.sid;
        oG(this, c, d, a.source);
        this.dispatchEvent(
          new lG(b.name, b.type, b.data || {}, d, a.origin, c)
        );
      }
    }
  };
  function pG() {
    return !!Na("googletag.cmd", G());
  }
  function qG() {
    var a = Na("googletag.console", G());
    return null != a ? a : null;
  }
  var rG = function () {
    Kx.call(this);
    this.g = null;
    this.l = new mG("gpt", !0);
    In(this, this.l);
    this.O(this.l, "gpt", this.B);
    pG() ||
      G().top === G() ||
      ((this.g = new mG("gpt", !1)),
      In(this, this.g),
      this.O(this.g, "gpt", this.o));
  };
  v(rG, Kx);
  rG.prototype.B = function (a) {
    var b = a.origin,
      c = "//imasdk.googleapis.com".match(hi);
    b = b.match(hi);
    if (c[3] == b[3] && c[4] == b[4])
      if (null != this.g)
        oG(this.g, a.g, a.fc, G().parent), null != this.g && nG(this.g, a);
      else if (((c = a.oa), null != c && void 0 !== c.scope)) {
        b = c.scope;
        c = c.args;
        var d;
        if ("proxy" === b) {
          var e = a.messageType;
          "isGptPresent" === e
            ? (d = pG())
            : "isConsolePresent" === e && (d = null != qG());
        } else if (pG())
          if ("pubads" === b || "companionAds" === b) {
            d = a.messageType;
            var f = G().googletag;
            if (
              null != f &&
              null != f[b] &&
              ((b = f[b]()), null != b && ((d = b[d]), null != d))
            )
              try {
                e = d.apply(b, c);
              } catch (g) {}
            d = e;
          } else if ("console" === b) {
            if (((e = qG()), null != e && ((b = e[a.messageType]), null != b)))
              try {
                b.apply(e, c);
              } catch (g) {}
          } else
            null === b &&
              ((e = a.messageType),
              "googleGetCompanionAdSlots" === e
                ? (e = iG())
                  ? ((e = e.getSlots().map(jG)), (d = e.length ? e : null))
                  : (d = null)
                : ("googleSetCompanionAdContents" === e &&
                    kG(null == c ? void 0 : c[0]),
                  (d = null)));
        void 0 !== d && ((a.oa.returnValue = d), nG(this.l, a));
      }
  };
  rG.prototype.o = function (a) {
    nG(this.l, a);
  };
  var sG = function (a, b) {
    if (a.g) {
      var c = a.g;
      Gn(c.g[b]);
      delete c.g[b];
    }
    a.l && ((a = a.l), Gn(a.g[b]), delete a.g[b]);
  };
  var tG = fa([""]),
    uG = yh(tG);
  function vG(a) {
    for (var b = [], c = 0; 8 > c; ++c) {
      var d = new Lv(7, "", "pagead/ping", function (f) {
          b.push({ url: f });
        }),
        e = Du(Cu(new Bu(), a), c);
      d.o(e);
    }
    return b;
  }
  function wG(a, b) {
    var c = TB;
    c = void 0 === c ? uG : c;
    var d, e;
    Ha(function (f) {
      switch (f.g) {
        case 1:
          d = a;
          if (d.sharedStorage) {
            var g = d.sharedStorage.set("ps_cct", String(Yi()), {
              ignoreIfPresent: !0,
            });
            f = ya(f, g, 2);
          } else f = f.return();
          return f;
        case 2:
          return ya(f, d.sharedStorage.worklet.addModule(c.toString()), 3);
        case 3:
          return ya(
            f,
            d.sharedStorage.selectURL("ps_caus", vG(b), {
              resolveToConfig: !0,
            }),
            4
          );
        case 4:
          e = f.j;
          g = d.document.body;
          var h = document.createElement("fencedframe");
          h.id = "ps_caff";
          h.name = "ps_caff";
          h.mode = "opaque-ads";
          h.config = e;
          g.appendChild(h);
          f.g = 0;
      }
    });
  }
  var yG = function (a, b) {
      var c = Array.prototype.slice.call(arguments),
        d = c.shift();
      if ("undefined" == typeof d)
        throw Error("[goog.string.format] Template required");
      return d.replace(
        /%([0\- \+]*)(\d+)?(\.(\d+))?([%sfdiu])/g,
        function (e, f, g, h, k, n, m, r) {
          if ("%" == n) return "%";
          var p = c.shift();
          if ("undefined" == typeof p)
            throw Error("[goog.string.format] Not enough arguments");
          arguments[0] = p;
          return xG[n].apply(null, arguments);
        }
      );
    },
    xG = {
      s: function (a, b, c) {
        return isNaN(c) || "" == c || a.length >= Number(c)
          ? a
          : (a =
              -1 < b.indexOf("-", 0)
                ? a + Jh(" ", Number(c) - a.length)
                : Jh(" ", Number(c) - a.length) + a);
      },
      f: function (a, b, c, d, e) {
        d = a.toString();
        isNaN(e) || "" == e || (d = parseFloat(a).toFixed(e));
        var f =
          0 > Number(a)
            ? "-"
            : 0 <= b.indexOf("+")
            ? "+"
            : 0 <= b.indexOf(" ")
            ? " "
            : "";
        0 <= Number(a) && (d = f + d);
        if (isNaN(c) || d.length >= Number(c)) return d;
        d = isNaN(e)
          ? Math.abs(Number(a)).toString()
          : Math.abs(Number(a)).toFixed(e);
        a = Number(c) - d.length - f.length;
        return (d =
          0 <= b.indexOf("-", 0)
            ? f + d + Jh(" ", a)
            : f + Jh(0 <= b.indexOf("0", 0) ? "0" : " ", a) + d);
      },
      d: function (a, b, c, d, e, f, g, h) {
        return xG.f(parseInt(a, 10), b, c, d, 0, f, g, h);
      },
    };
  xG.i = xG.d;
  xG.u = xG.d;
  function zG() {
    return ["autoplay", "attribution-reporting"]
      .filter(function (a) {
        var b = document.featurePolicy;
        return (
          void 0 !== b &&
          "function" == typeof b.allowedFeatures &&
          "object" == typeof b.allowedFeatures() &&
          b.allowedFeatures().includes(a)
        );
      })
      .join(";");
  }
  var BG = function (a, b) {
    S.call(this);
    this.F = b;
    this.L = this.J = null;
    this.H = !1;
    this.G = "goog_" + Lh++;
    this.B = new Map();
    this.j = null;
    var c = G();
    var d = Na("google.ima.gptProxyInstance", c);
    null != d
      ? (c = d)
      : ((d = new rG()), z("google.ima.gptProxyInstance", d, c), (c = d));
    this.Y = c;
    this.C = null;
    this.o = new Kx(this);
    In(this, this.o);
    c = this.G;
    d =
      (vi() ? "https:" : "http:") +
      yG(
        "//imasdk.googleapis.com/js/core/bridge3.637.1_%s.html",
        eC.getLocale()
      );
    a: {
      var e = window;
      try {
        do {
          try {
            if (
              0 === e.location.href.indexOf(d) ||
              0 === e.document.referrer.indexOf(d)
            ) {
              var f = !0;
              break a;
            }
          } catch (k) {}
          e = e.parent;
        } while (e !== e.top);
      } catch (k) {}
      f = !1;
    }
    f && (d += "?f=" + c);
    f = window.document;
    if (hy.length && f.head) {
      e = u(hy);
      for (var g = e.next(); !g.done; g = e.next())
        if ((g = g.value) && f.head) {
          var h = yi("META");
          f.head.appendChild(h);
          h.httpEquiv = "origin-trial";
          h.content = g;
        }
    }
    f = zG();
    c = $h("IFRAME", {
      src: d + "#" + c,
      allowFullscreen: !0,
      allow: f,
      id: c,
      style:
        "border:0; opacity:0; margin:0; padding:0; position:relative; color-scheme: light;",
      title: "Advertisement",
    });
    this.o.Xb(c, "load", this.ga);
    a.appendChild(c);
    this.g = c;
    this.l = AG(this);
    this.P = new VF(this.l, navigator);
    In(this, this.P);
    c = this.P;
    c.g.j.set("auction", c.l);
    this.U = new gG(this.l, this.F);
    In(this, this.U);
    this.F.da && this.o.O(this.l, "displayContainer", this.W);
    this.o.O(this.l, "mouse", this.Z);
    this.o.O(this.l, "touch", this.ba);
    JC() || ((this.C = new YF(a, this.l, b.da.P.g)), In(this, this.C));
  };
  v(BG, S);
  var AG = function (a, b) {
    b = void 0 === b ? "*" : b;
    var c = a.B.get(b);
    null == c &&
      ((c = new QE(a.G, b)),
      a.H && ((c.g = di(a.g)), c.connect()),
      a.B.set(b, c));
    return c;
  };
  BG.prototype.jc = function (a) {
    var b;
    null != (b = this.C) &&
      ((a = a.P.g), (b.B = a), b.g && ((b = b.g), (b.j = a), zF(b, a)));
  };
  BG.prototype.M = function () {
    null !== this.j && (this.j.X(), (this.j = null));
    this.B.forEach(function (a) {
      Gn(a);
    });
    this.B.clear();
    sG(this.Y, this.G);
    ai(this.g);
    S.prototype.M.call(this);
  };
  BG.prototype.Z = function (a) {
    var b = a.oa,
      c = Mm(this.g),
      d = document.createEvent("MouseEvent");
    d.initMouseEvent(
      a.messageType,
      !0,
      !0,
      window,
      b.detail,
      b.screenX,
      b.screenY,
      b.clientX + c.x,
      b.clientY + c.y,
      b.ctrlKey,
      b.altKey,
      b.shiftKey,
      b.metaKey,
      b.button,
      null
    );
    this.g.dispatchEvent(d);
  };
  var CG = function (a, b) {
    var c = Mm(a.g),
      d = !!("TouchEvent" in window && 0 < TouchEvent.length);
    b = b.map(function (f) {
      return d
        ? new Touch({
            identifier: f.identifier,
            target: a.g,
            clientX: f.clientX,
            clientY: f.clientY,
            screenX: f.screenX,
            screenY: f.screenY,
            pageX: f.pageX + c.x,
            pageY: f.pageY + c.y,
          })
        : document.createTouch(
            window,
            a.g,
            f.identifier,
            f.pageX + c.x,
            f.pageY + c.y,
            f.screenX,
            f.screenY
          );
    });
    if (d) return b;
    var e;
    return null == (e = document.createTouchList)
      ? void 0
      : e.apply(document, b);
  };
  BG.prototype.ba = function (a) {
    var b = a.oa,
      c = Mm(this.g);
    if ("TouchEvent" in window && 0 < TouchEvent.length)
      (b = {
        bubbles: !0,
        cancelable: !0,
        view: window,
        detail: b.detail,
        ctrlKey: b.ctrlKey,
        altKey: b.altKey,
        shiftKey: b.shiftKey,
        metaKey: b.metaKey,
        touches: CG(this, b.touches),
        targetTouches: CG(this, b.targetTouches),
        changedTouches: CG(this, b.changedTouches),
      }),
        (a = new TouchEvent(a.messageType, b)),
        this.g.dispatchEvent(a);
    else {
      var d = document.createEvent("TouchEvent");
      d.initTouchEvent(
        a.messageType,
        !0,
        !0,
        window,
        b.detail,
        b.screenX,
        b.screenY,
        b.clientX + c.x,
        b.clientY + c.y,
        b.ctrlKey,
        b.altKey,
        b.shiftKey,
        b.metaKey,
        CG(this, b.touches),
        CG(this, b.targetTouches),
        CG(this, b.changedTouches),
        b.scale,
        b.rotation
      );
      this.g.dispatchEvent(d);
    }
  };
  BG.prototype.W = function (a) {
    switch (a.messageType) {
      case "showVideo":
        null == this.j
          ? ((this.j = new TE()), this.o.O(this.j, "click", this.ka))
          : XE(this.j);
        VE(this.j, this.F.Qb());
        break;
      case "hide":
        null !== this.j && (this.j.X(), (this.j = null));
    }
    var b = this.U;
    cG(b.l, a);
    b.g && cG(b.g, a);
  };
  BG.prototype.ka = function () {
    eD(this.l, "displayContainer", "videoClick");
  };
  BG.prototype.ga = function () {
    this.J = aj();
    this.L = Yi();
    var a = di(this.g);
    this.B.forEach(function (c) {
      c.g = a;
      c.connect();
    });
    var b;
    null == (b = this.C) || ZF(b, a);
    this.H = !0;
  };
  var DG = fa(["https://s0.2mdn.net/instream/video/client.js"]),
    EG = null,
    FG = function () {
      S.call(this);
      this.g = null;
      this.j = new Map();
      this.l = new Map();
      this.va = this.C = !1;
      this.o = null;
      this.B = new Kx(this);
      In(this, this.B);
    };
  v(FG, S);
  var GG = function () {
      null == EG && (EG = new FG());
      return EG;
    },
    Dr = function (a, b, c) {
      var d = {};
      d.queryId = b;
      d.viewabilityData = c;
      a.g && eD(a.g, "activityMonitor", "viewabilityMeasurement", d);
    };
  FG.prototype.destroy = function () {
    this.B.ob(this.g, "activityMonitor", this.F);
    this.va = !1;
    this.j.clear();
  };
  FG.prototype.M = function () {
    this.destroy();
    S.prototype.M.call(this);
  };
  FG.prototype.init = function (a) {
    if (!this.va) {
      if ((this.g = a || null))
        this.B.O(this.g, "activityMonitor", this.F), HG(this);
      if (
        !(
          x.ima &&
          x.ima.video &&
          x.ima.video.client &&
          x.ima.video.client.tagged
        )
      ) {
        z("ima.video.client.sdkTag", !0);
        var b = x.document;
        a = Yh(document, "SCRIPT");
        var c = yh(DG);
        Eh(a, c);
        a.async = !0;
        a.type = "text/javascript";
        b = b.getElementsByTagName("script")[0];
        b.parentNode.insertBefore(a, b);
      }
      pl();
      I(tr).H = eC.g;
      this.C = !0;
      I(tr).l = !0;
      this.o = null;
      a = I(tr);
      b = "h" == er(a) || "b" == er(a);
      c = !(O(), !1);
      b && c && ((a.N = !0), (a.G = new zp()));
      this.va = !0;
    }
  };
  var JG = function (a) {
      if (null == a) return !1;
      if ((rc || tc) && null !== a.webkitDisplayingFullscreen)
        return a.webkitDisplayingFullscreen;
      a = IG(a);
      var b = window.screen.availHeight || window.screen.height;
      return (
        0 >= (window.screen.availWidth || window.screen.width) - a.width &&
        42 >= b - a.height
      );
    },
    IG = function (a) {
      var b = {
        left: a.offsetLeft,
        top: a.offsetTop,
        width: a.offsetWidth,
        height: a.offsetHeight,
      };
      try {
        "function" === typeof a.getBoundingClientRect &&
          ci(Rh(a), a) &&
          (b = a.getBoundingClientRect());
      } catch (c) {}
      return b;
    },
    KG = function (a, b, c, d, e) {
      e = void 0 === e ? {} : e;
      if (a.va) {
        d && null == e.opt_osdId && (e.opt_osdId = d);
        if (a.o) return a.o(b, c, e);
        if ((a = d ? a.l.get(d) : eC.l))
          null == e.opt_fullscreen && (e.opt_fullscreen = JG(a)),
            null == e.opt_adElement && (e.opt_adElement = a);
        return Su.wb(469, $a(Fr, b, c, e)) || {};
      }
      return {};
    },
    LG = function (a) {
      var b;
      0 !== eC.g ? (b = I(tr).l) : (b = a.C);
      return b;
    },
    MG = function (a, b) {
      var c = String(Math.floor(1e9 * Math.random()));
      a.l.set(c, b);
      0 !== eC.g && (I(tr).A[c] = a);
      return c;
    },
    NG = function (a, b, c) {
      if (c) a.j.get(c) === b && a.j.delete(c);
      else {
        var d = [];
        a.j.forEach(function (e, f) {
          e === b && d.push(f);
        });
        d.forEach(a.j.delete, a.j);
      }
    },
    zr = function (a, b) {
      a = a.j.get(b);
      return "function" === typeof a ? a() : {};
    },
    HG = function (a) {
      if ("function" === typeof window.Goog_AdSense_Lidar_getUrlSignalsArray) {
        var b = {};
        b.pageSignals = window.Goog_AdSense_Lidar_getUrlSignalsArray();
        var c;
        null == (c = a.g) || eD(c, "activityMonitor", "pageSignals", b);
      }
    };
  FG.prototype.F = function (a) {
    var b = a.oa,
      c = b.queryId,
      d = {},
      e = null;
    d.eventId = b.eventId;
    switch (a.messageType) {
      case "getPageSignals":
        HG(this);
        break;
      case "reportVastEvent":
        e = b.vastEvent;
        a = b.osdId;
        var f = {};
        f.opt_fullscreen = b.isFullscreen;
        b.isOverlay && (f.opt_bounds = b.overlayBounds);
        d.viewabilityData = KG(this, e, c, a, f);
        var g;
        null == (g = this.g) || eD(g, "activityMonitor", "viewability", d);
        break;
      case "fetchAdTagUrl":
        (c = {}),
          (c.eventId = b.eventId),
          (a = b.osdId),
          Wg(b, "isFullscreen") && (e = b.isFullscreen),
          Wg(b, "loggingId") &&
            ((b = b.loggingId),
            (c.loggingId = b),
            X.getInstance().report(43, {
              step: "beforeLookup",
              logid: b,
              time: Date.now(),
            })),
          (c.engagementString = OG(this, a, e)),
          this.g && eD(this.g, "activityMonitor", "engagement", c);
    }
  };
  var OG = function (a, b, c) {
    var d,
      e = b ? (null != (d = a.l.get(b)) ? d : null) : eC.l;
    a = {};
    null != c && (a.fullscreen = c);
    c = "";
    try {
      c = ht(function () {
        return e;
      }, a);
    } catch (f) {
      (c = f), (c = "sdktle;" + Ih(c.name, 12) + ";" + Ih(c.message, 40));
    }
    return c;
  };
  z("ima.common.getVideoMetadata", function (a) {
    return zr(GG(), a);
  });
  z("ima.common.triggerViewabilityMeasurementUpdate", function (a, b) {
    Dr(GG(), a, b);
  });
  var PG = function (a) {
      this.g = a;
      this.l = "";
      this.j = -1;
      this.A = !1;
    },
    RG = function (a, b) {
      if (0 <= a.j) {
        var c = null == b ? function () {} : b,
          d = function () {
            QG(a, c);
            a.g.removeEventListener("loadedmetadata", d, !1);
          };
        a.g.addEventListener("loadedmetadata", d, !1);
        a.g.src = a.l;
        a.g.load();
      } else null != b && b();
    },
    QG = function (a, b) {
      var c = 0 < a.g.seekable.length;
      a.A
        ? c
          ? ((a.g.currentTime = a.j), SG(a), b())
          : setTimeout(function () {
              return void QG(a, b);
            }, 100)
        : (SG(a), b());
    },
    SG = function (a) {
      a.j = -1;
      a.l = "";
      a.A = !1;
    };
  var TG = new Bh(5, 5),
    UG = function (a) {
      S.call(this);
      this.g = a;
      this.o = this.ba = null;
      this.C = 0;
      this.J = this.F = this.U = this.loaded = this.H = !1;
      this.W = this.G = this.L = this.l = null;
      this.Z = !1;
      this.B = null;
      this.P = new PG(a);
      this.j = new Kx(this);
      In(this, this.j);
      this.size = this.getSize();
      this.fullscreen = JG(this.g);
    };
  v(UG, S);
  l = UG.prototype;
  l.ce = function () {
    var a = this.P;
    a.l = a.g.currentSrc;
    a.A = 0 < a.g.seekable.length;
    a.j = a.g.ended ? -1 : a.g.currentTime;
  };
  l.hc = function (a) {
    RG(this.P, a);
  };
  l.load = function (a, b) {
    var c = J.getInstance().g;
    c.P = !0;
    lj(c);
    L("hvd_lc");
    fG(this);
    this.U = !1;
    if (b)
      if ((L("hvd_ad"), b instanceof Vv)) {
        if ((L("hvd_mad"), (c = b.getMediaUrl()))) {
          L("hvd_admu");
          L("hvd_src");
          this.g.src = c;
          this.g.load();
          return;
        }
      } else if (b instanceof Uv) {
        L("hvd_dad");
        c = b.A;
        var d = b.j,
          e = b.l,
          f = b.g,
          g = b.pb,
          h = b.Za;
        if (c && d && e && f && g && h && (L("hvd_addu"), b.Ea)) {
          L("hvd_admse");
          b = e + '; codecs="' + g + '"';
          f = f + '; codecs="' + h + '"';
          if (
            hA() &&
            hA() &&
            MediaSource.isTypeSupported(b) &&
            hA() &&
            MediaSource.isTypeSupported(f)
          ) {
            L("hvd_ymse");
            L("hvd_mse");
            a = !1;
            try {
              -1 !== window.location.search.indexOf("goog_limavideo=true") &&
                (a = !0);
            } catch (k) {}
            x.customElements
              ? a
                ? (a = !0)
                : (M(uk) && X.getInstance().report(153, { limvid: "vd" }),
                  (a = M(uk) || M(tk) || M(rk) || M(sk) ? !0 : !1))
              : (a = !1);
            a && this.g instanceof dB
              ? ((this.g.bb = c), (this.g.rb = d))
              : ((this.ba = new CB(this.g, [
                  new BA(c, b, 35e4, new Uy()),
                  new BA(d, f, 82e3, new Uy()),
                ])),
                In(this, this.ba),
                (a = this.g),
                (c = this.ba),
                c.j || (c.j = qh(c.g).toString()),
                (c = c.j),
                (a.src = c));
            this.g.load();
            return;
          }
          L("hvd_nmse");
        }
      } else L("hvd_uad");
    a ? (L("hvd_src"), (this.g.src = a)) : L("hvd_vn");
    this.g.load();
  };
  l.setVolume = function (a) {
    this.g.volume = Math.max(a, 0);
    this.g.muted = 0 === a ? !0 : !1;
  };
  l.Kd = function (a) {
    this.g.style.left = String(a.left) + "px";
    this.g.style.top = String(a.top) + "px";
    this.g.style.width = String(a.width) + "px";
    this.g.style.height = String(a.height) + "px";
  };
  l.Ld = function () {
    this.g.style.width = "100%";
    this.g.style.height = "100%";
    this.g.style.left = "0";
    this.g.style.right = "0";
  };
  l.getVolume = function () {
    return this.g.muted ? 0 : this.g.volume;
  };
  var eG = function (a) {
    a.Z = !1;
    a.U || Cb()
      ? ((a.J = !1),
        (a.l = a.g.play()),
        null != a.l &&
          ((a.L = null),
          a.l
            .then(function () {
              a.l = null;
              a.ze(a.L);
              a.L = null;
            })
            .catch(function (b) {
              a.l = null;
              var c = "";
              null != b && null != b.name && (c = b.name);
              "AbortError" === c || "NotAllowedError" === c
                ? a.dispatchEvent("autoplayDisallowed")
                : a.Y();
            })))
      : (a.J = !0);
  };
  l = UG.prototype;
  l.pause = function () {
    null == this.l && ((this.Z = !0), this.g.pause());
  };
  l.getCurrentTime = function () {
    return this.g.currentTime;
  };
  l.getDuration = function () {
    return isNaN(this.g.duration) ? -1 : this.g.duration;
  };
  l.getSize = function () {
    return new Bh(this.g.offsetWidth, this.g.offsetHeight);
  };
  l.M = function () {
    this.W && mx(this.W);
    dG(this);
    S.prototype.M.call(this);
  };
  var dG = function (a) {
      null != a.o && (XE(a.o), (a.o = null));
      null != a.G && a.G.X();
      Ox(a.j);
      fG(a);
    },
    fG = function (a) {
      a.loaded = !1;
      a.F = !1;
      a.H = !1;
      a.J = !1;
      a.C = 0;
      a.l = null;
      a.L = null;
      Gn(a.B);
    };
  UG.prototype.Oa = function (a) {
    this.dispatchEvent(a.type);
  };
  var WG = function (a) {
    if (!a.F) {
      a.F = !0;
      a.dispatchEvent("start");
      try {
        if (M(uk) && x.customElements) {
          var b = x.customElements.get("lima-video");
          a.g instanceof b
            ? X.getInstance().report(153, { limvid: "limastart" })
            : X.getInstance().report(153, { limvid: "videostart" });
        }
      } catch (c) {
        X.getInstance().report(153, { limvid: "startfail" });
      }
      b =
        "function" === typeof a.g.getAttribute &&
        null != a.g.getAttribute("playsinline");
      b = void 0 === b ? !1 : b;
      ((!tx() && !ux(10)) || (!b && (HC.getInstance(), !1))
        ? (HC.getInstance(), qb(wb(), "Xbox")) ||
          (rc || tc
            ? 0
            : (!qc || (qc && sx(rx, 4))) &&
              (an() ? (HC.getInstance(), !1) : !JC()))
        : 1) ||
        !qc ||
        (qc && sx(rx, 3)) ||
        ((rc || tc) && !ux(4)) ||
        VG(a);
    }
  };
  l = UG.prototype;
  l.pg = function () {
    this.U = !0;
    this.J && eG(this);
    this.J = !1;
    XG(this);
  };
  l.og = function () {
    this.loaded || ((this.loaded = !0), this.dispatchEvent("loaded"));
  };
  l.ze = function (a) {
    null != this.l
      ? (this.L = a)
      : (this.dispatchEvent("play"), uc || tx() || Dc || WG(this));
  };
  l.sg = function (a) {
    if (!this.F && (uc || tx() || Dc)) {
      if (0 >= this.getCurrentTime()) return;
      if (Dc && this.g.ended && 1 === this.getDuration()) {
        this.Y(a);
        return;
      }
      WG(this);
    }
    if (uc || qb(wb(), "Nintendo WiiU")) {
      if (1.5 < this.getCurrentTime() - this.C) {
        this.H = !0;
        this.g.currentTime = this.C;
        return;
      }
      this.H = !1;
      this.getCurrentTime() > this.C && (this.C = this.getCurrentTime());
    }
    this.dispatchEvent("timeUpdate");
  };
  l.ug = function () {
    this.dispatchEvent("volumeChange");
  };
  l.rg = function () {
    if (this.F && uc && !this.Z && (2 > YG(this) || this.H)) {
      this.B = new Qs(250);
      this.j.O(this.B, "tick", this.Ga);
      this.B.start();
      var a = !0;
    } else a = !1;
    a || this.l || this.dispatchEvent("pause");
  };
  l.ng = function () {
    var a = !0;
    if (uc || qb(wb(), "Nintendo WiiU")) a = this.C >= this.g.duration - 1.5;
    !this.H && a && this.dispatchEvent("end");
  };
  var VG = function (a) {
    a.dispatchEvent("beginFullscreen");
  };
  UG.prototype.ga = function () {
    this.dispatchEvent("endFullscreen");
  };
  UG.prototype.Y = function () {
    this.dispatchEvent("error");
  };
  UG.prototype.ka = function () {
    this.dispatchEvent("click");
  };
  var XG = function (a) {
    a.g instanceof HTMLElement &&
      ((a.W = lx(a.g, TG)),
      a.W.then(function (b) {
        a.Ca() || K(J.getInstance(), "ps", b.width + "x" + b.height);
      }));
  };
  UG.prototype.Ha = function () {
    var a = this.getSize(),
      b = JG(this.g);
    if (a.width !== this.size.width || a.height !== this.size.height)
      !this.fullscreen && b ? VG(this) : this.fullscreen && !b && this.ga(),
        (this.size = a),
        (this.fullscreen = b);
  };
  UG.prototype.Ga = function () {
    if (
      !this.g.ended &&
      this.g.paused &&
      (uc || Ec ? this.g.currentTime < this.g.duration : 1)
    ) {
      var a = this.g.duration - this.g.currentTime,
        b = YG(this);
      0 < b && (2 <= b || 2 > a) && (Gn(this.B), eG(this));
    } else Gn(this.B);
  };
  var YG = function (a) {
    var b;
    a: {
      for (b = a.g.buffered.length - 1; 0 <= b; ) {
        if (a.g.buffered.start(b) <= a.g.currentTime) {
          b = a.g.buffered.end(b);
          break a;
        }
        b--;
      }
      b = 0;
    }
    return b - a.g.currentTime;
  };
  UG.prototype.Pa = function () {
    X.getInstance().report(139);
    VG(this);
  };
  var bH = function (a) {
      if (a instanceof ZG || a instanceof $G || a instanceof aH) return a;
      if ("function" == typeof a.next)
        return new ZG(function () {
          return a;
        });
      if ("function" == typeof a[Symbol.iterator])
        return new ZG(function () {
          return a[Symbol.iterator]();
        });
      if ("function" == typeof a.zb)
        return new ZG(function () {
          return a.zb();
        });
      throw Error("Not an iterator or iterable.");
    },
    ZG = function (a) {
      this.g = a;
    };
  ZG.prototype.zb = function () {
    return new $G(this.g());
  };
  ZG.prototype[Symbol.iterator] = function () {
    return new aH(this.g());
  };
  ZG.prototype.j = function () {
    return new aH(this.g());
  };
  var $G = function (a) {
    this.g = a;
  };
  v($G, vo);
  $G.prototype.next = function () {
    return this.g.next();
  };
  $G.prototype[Symbol.iterator] = function () {
    return new aH(this.g);
  };
  $G.prototype.j = function () {
    return new aH(this.g);
  };
  var aH = function (a) {
    ZG.call(this, function () {
      return a;
    });
    this.l = a;
  };
  v(aH, ZG);
  aH.prototype.next = function () {
    return this.l.next();
  };
  var cH = function (a, b) {
    this.j = {};
    this.g = [];
    this.l = this.size = 0;
    var c = arguments.length;
    if (1 < c) {
      if (c % 2) throw Error("Uneven number of arguments");
      for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1]);
    } else if (a)
      if (a instanceof cH)
        for (c = a.zc(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
      else for (d in a) this.set(d, a[d]);
  };
  l = cH.prototype;
  l.Db = function () {
    dH(this);
    for (var a = [], b = 0; b < this.g.length; b++) a.push(this.j[this.g[b]]);
    return a;
  };
  l.zc = function () {
    dH(this);
    return this.g.concat();
  };
  l.has = function (a) {
    return eH(this.j, a);
  };
  l.isEmpty = function () {
    return 0 == this.size;
  };
  l.clear = function () {
    this.j = {};
    this.l = this.size = this.g.length = 0;
  };
  l.remove = function (a) {
    return this.delete(a);
  };
  l.delete = function (a) {
    return eH(this.j, a)
      ? (delete this.j[a],
        --this.size,
        this.l++,
        this.g.length > 2 * this.size && dH(this),
        !0)
      : !1;
  };
  var dH = function (a) {
    if (a.size != a.g.length) {
      for (var b = 0, c = 0; b < a.g.length; ) {
        var d = a.g[b];
        eH(a.j, d) && (a.g[c++] = d);
        b++;
      }
      a.g.length = c;
    }
    if (a.size != a.g.length) {
      var e = {};
      for (c = b = 0; b < a.g.length; )
        (d = a.g[b]), eH(e, d) || ((a.g[c++] = d), (e[d] = 1)), b++;
      a.g.length = c;
    }
  };
  l = cH.prototype;
  l.get = function (a, b) {
    return eH(this.j, a) ? this.j[a] : b;
  };
  l.set = function (a, b) {
    eH(this.j, a) || ((this.size += 1), this.g.push(a), this.l++);
    this.j[a] = b;
  };
  l.forEach = function (a, b) {
    for (var c = this.zc(), d = 0; d < c.length; d++) {
      var e = c[d],
        f = this.get(e);
      a.call(b, f, e, this);
    }
  };
  l.keys = function () {
    return bH(this.zb(!0)).j();
  };
  l.values = function () {
    return bH(this.zb(!1)).j();
  };
  l.entries = function () {
    var a = this;
    return ex(this.keys(), function (b) {
      return [b, a.get(b)];
    });
  };
  l.zb = function (a) {
    dH(this);
    var b = 0,
      c = this.l,
      d = this,
      e = new vo();
    e.next = function () {
      if (c != d.l)
        throw Error("The map has changed since the iterator was created");
      if (b >= d.g.length) return wo;
      var f = d.g[b++];
      return { value: a ? f : d.j[f], done: !1 };
    };
    return e;
  };
  var eH = function (a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  };
  var gH = function () {
    S.call(this);
    this.currentTime = 0;
    this.duration = NaN;
    this.l = !0;
    this.volume = 1;
    this.muted = !1;
    this.C = 1;
    this.playbackRate = 0;
    this.j = this.g = this.G = null;
    this.buffered = new fH();
    this.F = new fH();
    this.B = "";
    this.tagName = "VIDEO";
    this.height = this.width = 0;
    this.canPlayType = function () {
      return "";
    };
    this.o = new Kx(this);
    In(this, this.o);
    var a = cC(eC);
    a && (this.duration = $B(a));
  };
  v(gH, S);
  var hH = function () {
    var a = ["video/mp4"],
      b = ["video/ogg"],
      c = new gH();
    c.canPlayType = function (d) {
      return a.includes(d) ? "probably" : b.includes(d) ? "maybe" : "";
    };
    return c;
  };
  l = gH.prototype;
  l.pause = function () {
    if (!this.l) {
      var a;
      null == (a = this.G) || a.stop();
      this.l = !0;
      this.dispatchEvent("timeupdate");
      this.dispatchEvent("pause");
    }
  };
  l.load = function () {
    this.l = !0;
    this.dispatchEvent("loadstart");
    var a;
    isNaN(this.duration) ? (a = 10 + 20 * Math.random()) : (a = this.duration);
    this.duration = Number(a);
    this.dispatchEvent("durationchange");
    a = this.F;
    a.g.push(new iH(this.duration));
    a.length = a.g.length;
    a = this.buffered;
    a.g.push(new iH(this.duration));
    a.length = a.g.length;
    this.dispatchEvent("loadedmetadata");
    0 < this.currentTime && this.dispatchEvent("timeupdate");
    this.dispatchEvent("loadeddata");
    this.dispatchEvent("canplay");
    this.dispatchEvent("canplaythrough");
    this.dispatchEvent("progress");
    this.playbackRate = this.C;
  };
  l.setVolume = function (a) {
    this.volume = a;
    this.dispatchEvent("volumechange");
  };
  l.setAttribute = function (a, b) {
    null != a && jH.set(a, b);
  };
  l.getAttribute = function (a) {
    return jH.get(a);
  };
  l.tg = function (a) {
    var b = null,
      c = null;
    switch (a.type) {
      case "loadeddata":
        b = "Loaded";
        break;
      case "playing":
        b = "Playing";
        c = "#00f";
        break;
      case "pause":
        b = "Paused";
        break;
      case "ended":
        (b = "Ended"), (c = "#000");
    }
    b && this.j && (this.j.innerText = b);
    c && this.g && (this.g.style.backgroundColor = c);
  };
  da.Object.defineProperties(gH.prototype, {
    src: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.B;
      },
      set: function (a) {
        this.B = a;
      },
    },
  });
  var jH = new cH(),
    iH = function (a) {
      this.startTime = 0;
      this.endTime = a;
    },
    fH = function () {
      this.length = 0;
      this.g = [];
    };
  fH.prototype.start = function (a) {
    return this.g[a].startTime;
  };
  fH.prototype.end = function (a) {
    return this.g[a].endTime;
  };
  var lH = function (a) {
    Q.call(this);
    this.A = a;
    this.l = this.g = null;
    this.j = kH(this);
    this.g = $h("DIV", { style: "display:none;" });
    this.A.appendChild(this.g);
    this.g.appendChild(this.j);
    this.l = $h("DIV", {
      style: "position:absolute;width:100%;height:100%;left:0px;top:0px",
    });
    this.g.appendChild(this.l);
    SA(function () {
      K(J.getInstance(), "haob", "1");
    });
  };
  v(lH, Q);
  lH.prototype.initialize = function () {
    this.j && this.j.load();
  };
  lH.prototype.M = function () {
    ai(this.g);
    Q.prototype.M.call(this);
  };
  var kH = function (a) {
      var b = cC(eC);
      if (ZB(b, "useVideoElementFake"))
        (a = hH()),
          (b = $h("DIV", {
            style: "position:absolute;width:100%;height:100%;top:0px;left:0px;",
          })),
          Object.assign(b, a),
          (a.g = $h("DIV", {
            style:
              "position:absolute;width:100%;height:100%;top:0px;left:0px;background-color:#000",
          })),
          (a.j = $h("P", {
            style:
              "position:absolute;top:25%;margin-left:10px;font-size:24px;color:#fff;",
          })),
          a.g.appendChild(a.j),
          b.appendChild(a.g),
          a.o.O(a, ["loadeddata", "playing", "pause", "ended"], a.tg),
          (a = b);
      else {
        b = !1;
        try {
          -1 !== window.location.search.indexOf("goog_limavideo=true") &&
            (b = !0);
        } catch (c) {}
        if (mH(a, b)) {
          b && console.log("force lima video in wrapper");
          a = null;
          try {
            a = new dB();
          } catch (c) {
            (a = $h("lima-video")),
              M(uk) && X.getInstance().report(153, { limvid: "firefail" });
          }
          a.style.backgroundColor = "#000";
          a.style.height = "100%";
          a.style.width = "100%";
          a.style.position = "absolute";
          a.style.left = "0";
          a.style.top = "0";
        } else
          a = $h("VIDEO", {
            style:
              "background-color:#000;position:absolute;width:100%;height:100%;left:0;top:0;",
            title: "Advertisement".toString(),
          });
      }
      a.setAttribute("webkit-playsinline", "true");
      a.setAttribute("playsinline", "true");
      return a;
    },
    mH = function (a, b) {
      if (!x.customElements) return !1;
      if (b) return !0;
      if (Db() && Rh(a.A) !== document) return !1;
      M(uk) && X.getInstance().report(153, { limvid: "vw" });
      return M(tk) || M(uk) || M(rk) || M(sk) ? !0 : !1;
    };
  lH.prototype.Qb = function () {
    return this.l;
  };
  lH.prototype.ib = function () {
    var a = this.g;
    null != a && (a.style.display = "none");
  };
  var qH = function (a, b, c) {
    var d = a && a.getRootNode ? a.getRootNode({ composed: !0 }) : a;
    if (null == a || !ci(Rh(d), d))
      throw tD(sD, null, "containerElement", "element");
    this.j = b;
    this.P = LC(this.j || null);
    this.L = vx(this.j || null);
    this.J = String(Math.floor(1e9 * Math.random()));
    this.F = !1;
    this.Uc = a;
    this.H = null != b;
    eC.g = 2;
    this.I = nH(b ? b : null);
    d = $h("DIV", { style: "position:absolute" });
    a.insertBefore(d, a.firstChild);
    this.A = d;
    this.g = null;
    oH(this) && b
      ? (a = new UG(b))
      : ((this.g = new lH(this.A)), (a = new UG(this.g.j)));
    this.da = a;
    this.Aa = this.l = null;
    if ((a = this.g && eC.A))
      a = !(oH(this) || rc || tc || bn() || (qc && (!qc || !sx(rx, 4))));
    a && ((this.l = new lH(this.A)), (this.Aa = new UG(this.l.j)));
    this.o = c || null;
    this.G = null != this.o;
    oH(this) && b
      ? "function" !== typeof b.getBoundingClientRect
        ? ((c = this.A), (eC.l = c))
        : (c = b)
      : (c = this.A);
    this.C = c;
    this.B = new BG(this.A, this);
    this.size = new Bh(0, 0);
    this.N = "";
    b &&
      ((b = Lw(b.src || b.currentSrc)),
      200 > b.toString().length
        ? (this.N = b.toString())
        : 200 > b.j.length && (this.N = b.j));
    this.Xd = new Map();
    this.Xd.set("videoDisplay1", this.da);
    this.Aa && this.Xd.set("videoDisplay2", this.Aa);
    pH(this) &&
      !eC.j &&
      console.warn(
        "Custom media element must be a <video> or <audio> element. Viewability/audibility measurement will fail."
      );
  };
  l = qH.prototype;
  l.initialize = function () {
    this.F = !0;
    null != this.g && this.g.initialize();
    null != this.l && this.l.initialize();
  };
  l.va = function () {
    return this.F;
  };
  l.destroy = function () {
    var a = this;
    this.j = null;
    Gn(this.g);
    Gn(this.l);
    Gn(this.B);
    this.da.hc(function () {
      return Gn(a.da);
    });
    null != this.Aa &&
      this.Aa.hc(function () {
        return Gn(a.Aa);
      });
    ai(this.A);
  };
  l.Zc = function () {
    if (null != this.g) {
      var a = this.g.g;
      null != a && (a.style.display = "block");
    }
  };
  l.jc = function (a) {
    this.da !== a &&
      this.g &&
      this.l &&
      this.Aa &&
      (a.setVolume(this.da.getVolume()),
      (a = this.da),
      (this.da = this.Aa),
      (this.Aa = a),
      (a = this.g),
      (this.g = this.l),
      (this.l = a),
      this.l.ib(),
      this.B.jc(this.da));
  };
  l.ib = function () {
    null != this.g && this.g.ib();
  };
  l.Qb = function () {
    return this.G && this.o ? this.o : null != this.g ? this.g.Qb() : null;
  };
  var oH = function (a) {
      return KC(a.I) && a.H;
    },
    pH = function (a) {
      var b = ["VIDEO", "AUDIO"],
        c;
      return (
        oH(a) &&
        !!a.j &&
        !b.includes(null == (c = a.j.tagName) ? void 0 : c.toUpperCase())
      );
    };
  qH.prototype.getSize = function () {
    return this.size;
  };
  var nH = function (a) {
    return null != a &&
      "function" === typeof a.getAttribute &&
      null != a.getAttribute("playsinline")
      ? !0
      : !1;
  };
  qH.prototype.Kd = function (a) {
    this.da.Kd(a);
  };
  qH.prototype.Ld = function () {
    this.da.Ld();
  };
  qH.prototype.destroy = qH.prototype.destroy;
  qH.prototype.initialize = qH.prototype.initialize;
  var rH = { AD_LOAD: "adLoadError", AD_PLAY: "adPlayError" },
    sH = function (a) {
      var b = Error.call(this);
      this.message = b.message;
      "stack" in b && (this.stack = b.stack);
      this.data = a;
    };
  v(sH, Error);
  l = sH.prototype;
  l.getInnerError = function () {
    var a = this.data.innerError;
    return a instanceof Object ? new sH(a) : null != a ? Error(a) : null;
  };
  l.getMessage = function () {
    return this.data.errorMessage;
  };
  l.getErrorCode = function () {
    return this.data.errorCode;
  };
  l.getVastErrorCode = function () {
    var a = this.getErrorCode();
    return 1e3 > a ? a : 900;
  };
  l.getType = function () {
    return this.data.type;
  };
  l.toString = function () {
    return (
      "AdError " +
      this.getErrorCode() +
      ": " +
      this.getMessage() +
      (null != this.getInnerError()
        ? " Caused by: " + this.getInnerError()
        : "")
    );
  };
  sH.prototype.getType = sH.prototype.getType;
  sH.prototype.getVastErrorCode = sH.prototype.getVastErrorCode;
  sH.prototype.getErrorCode = sH.prototype.getErrorCode;
  sH.prototype.getMessage = sH.prototype.getMessage;
  sH.prototype.getInnerError = sH.prototype.getInnerError;
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_error.AdError.Type",
    rH
  );
  var tH = { AD_ERROR: "adError" },
    uH = function (a, b) {
      b = void 0 === b ? null : b;
      Lr.call(this, "adError");
      this.error = a;
      this.g = b;
    };
  v(uH, Lr);
  uH.prototype.getError = function () {
    return this.error;
  };
  uH.prototype.getUserRequestContext = function () {
    return this.g;
  };
  uH.prototype.getUserRequestContext = uH.prototype.getUserRequestContext;
  uH.prototype.getError = uH.prototype.getError;
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_error_event.AdErrorEvent.Type",
    tH
  );
  var vH = {
      AD_CAN_PLAY: "adCanPlay",
      Ug: "adStarted",
      CONTENT_PAUSE_REQUESTED: "contentPauseRequested",
      CONTENT_RESUME_REQUESTED: "contentResumeRequested",
      CLICK: "click",
      VIDEO_CLICKED: "videoClicked",
      VIDEO_ICON_CLICKED: "videoIconClicked",
      Yd: "engagedView",
      EXPANDED_CHANGED: "expandedChanged",
      STARTED: "start",
      AD_PROGRESS: "adProgress",
      AD_BUFFERING: "adBuffering",
      IMPRESSION: "impression",
      de: "measurable_impression",
      VIEWABLE_IMPRESSION: "viewable_impression",
      Zd: "fully_viewable_audible_half_duration_impression",
      mf: "overlay_resize",
      nf: "overlay_unmeasurable_impression",
      qf: "overlay_unviewable_impression",
      sf: "overlay_viewable_immediate_impression",
      rf: "overlay_viewable_end_of_session_impression",
      nh: "externalActivityEvent",
      PAUSED: "pause",
      RESUMED: "resume",
      FIRST_QUARTILE: "firstQuartile",
      MIDPOINT: "midpoint",
      THIRD_QUARTILE: "thirdQuartile",
      COMPLETE: "complete",
      DURATION_CHANGE: "durationChange",
      USER_CLOSE: "userClose",
      gi: "userRecall",
      Uh: "prefetched",
      LOADED: "loaded",
      ALL_ADS_COMPLETED: "allAdsCompleted",
      SKIPPED: "skip",
      wf: "skipShown",
      LINEAR_CHANGED: "linearChanged",
      SKIPPABLE_STATE_CHANGED: "skippableStateChanged",
      AD_METADATA: "adMetadata",
      AD_BREAK_FETCH_ERROR: "adBreakFetchError",
      AD_BREAK_READY: "adBreakReady",
      LOG: "log",
      VOLUME_CHANGED: "volumeChange",
      VOLUME_MUTED: "mute",
      INTERACTION: "interaction",
      Zg: "companionBackfill",
      ei: "trackingUrlPinged",
      hi: "video_card_endcap_collapse",
      ji: "video_card_endcap_dismiss",
      ki: "video_card_endcap_impression",
      eh: "companionInitialized",
      bh: "companionImpression",
      ah: "companionClick",
      Oh: "mediaUrlPinged",
      LOAD_START: "loadStart",
      Qh: "navigationRequested",
    },
    wH = function (a, b, c) {
      b = void 0 === b ? null : b;
      c = void 0 === c ? null : c;
      Lr.call(this, a);
      this.ad = b;
      this.l = c;
    };
  v(wH, Lr);
  wH.prototype.getAd = function () {
    return this.ad;
  };
  wH.prototype.getAdData = function () {
    return this.l;
  };
  wH.prototype.getAdData = wH.prototype.getAdData;
  wH.prototype.getAd = wH.prototype.getAd;
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ad_event.AdEvent.Type",
    vH
  );
  var xH = function (a, b) {
    b = void 0 === b ? null : b;
    wH.call(this, "adMetadata", a);
    this.g = b;
  };
  v(xH, wH);
  xH.prototype.Nf = function () {
    return this.g;
  };
  xH.prototype.getAdCuePoints = xH.prototype.Nf;
  var yH = function (a) {
    this.adBreakDuration = a.adBreakDuration;
    this.adPosition = a.adPosition;
    this.currentTime = a.currentTime;
    this.duration = a.duration;
    this.totalAds = a.totalAds;
  };
  var zH = function (a, b) {
    S.call(this);
    this.l = a;
    this.B = b;
    this.j = this.l.currentTime;
    this.g = new Qs(250);
    In(this, this.g);
    this.o = new Kx(this);
    In(this, this.o);
    Mx(this.o, this.g, "tick", this.C, !1, this);
  };
  v(zH, S);
  zH.prototype.sb = function () {
    return this.j;
  };
  zH.prototype.start = function () {
    AH(this);
    this.g.start();
  };
  zH.prototype.stop = function () {
    this.g.stop();
  };
  zH.prototype.C = function () {
    var a = this.l.currentTime;
    a !== this.sb() && ((this.j = a), AH(this));
  };
  var AH = function (a) {
    var b = {};
    b.currentTime = a.sb();
    eD(a.B, "contentTimeUpdate", "contentTimeUpdate", b);
  };
  var BH = oc && "srcdoc" in Yh(document, "IFRAME"),
    CH = function (a, b) {
      a.open("text/html", "replace");
      Gh(a, ij(String(b)));
      a.close();
    };
  var DH = {
      rgb: !0,
      rgba: !0,
      alpha: !0,
      rect: !0,
      image: !0,
      "linear-gradient": !0,
      "radial-gradient": !0,
      "repeating-linear-gradient": !0,
      "repeating-radial-gradient": !0,
      "cubic-bezier": !0,
      matrix: !0,
      perspective: !0,
      rotate: !0,
      rotate3d: !0,
      rotatex: !0,
      rotatey: !0,
      steps: !0,
      rotatez: !0,
      scale: !0,
      scale3d: !0,
      scalex: !0,
      scaley: !0,
      scalez: !0,
      skew: !0,
      skewx: !0,
      skewy: !0,
      translate: !0,
      translate3d: !0,
      translatex: !0,
      translatey: !0,
      translatez: !0,
    },
    EH = function (a) {
      a = ob(a);
      if ("" == a) return null;
      var b = String(a.slice(0, 4)).toLowerCase();
      if (0 == ("url(" < b ? -1 : "url(" == b ? 0 : 1)) return null;
      if (0 < a.indexOf("(")) {
        if (/"|'/.test(a)) return null;
        b = /([\-\w]+)\(/g;
        for (var c; (c = b.exec(a)); )
          if (!(c[1].toLowerCase() in DH)) return null;
      }
      return a;
    };
  function FH(a, b) {
    a = x[a];
    return a && a.prototype
      ? ((b = Object.getOwnPropertyDescriptor(a.prototype, b)) && b.get) || null
      : null;
  }
  function GH(a) {
    var b = x.CSSStyleDeclaration;
    return (b && b.prototype && b.prototype[a]) || null;
  }
  FH("Element", "attributes") || FH("Node", "attributes");
  FH("Element", "innerHTML") || FH("HTMLElement", "innerHTML");
  FH("Node", "nodeName");
  FH("Node", "nodeType");
  FH("Node", "parentNode");
  FH("Node", "childNodes");
  FH("HTMLElement", "style") || FH("Element", "style");
  FH("HTMLStyleElement", "sheet");
  var HH = GH("getPropertyValue"),
    IH = GH("setProperty");
  FH("Element", "namespaceURI") || FH("Node", "namespaceURI");
  function JH(a, b, c, d) {
    if (a) return a.apply(b, d);
    if (lc && 10 > document.documentMode) {
      if (!b[c].call) throw Error("IE Clobbering detected");
    } else if ("function" != typeof b[c]) throw Error("Clobbering detected");
    return b[c].apply(b, d);
  }
  var KH = {
      "-webkit-border-horizontal-spacing": !0,
      "-webkit-border-vertical-spacing": !0,
    },
    MH = function (a) {
      if (!a) return uh;
      var b = document.createElement("div").style;
      LH(a).forEach(function (c) {
        var d =
          oc && c in KH
            ? c
            : c.replace(
                /^-(?:apple|css|epub|khtml|moz|mso?|o|rim|wap|webkit|xv)-(?=[a-z])/i,
                ""
              );
        0 != d.lastIndexOf("--", 0) &&
          0 != d.lastIndexOf("var", 0) &&
          ((c =
            JH(
              HH,
              a,
              a.getPropertyValue ? "getPropertyValue" : "getAttribute",
              [c]
            ) || ""),
          (c = EH(c)),
          null != c &&
            JH(IH, b, b.setProperty ? "setProperty" : "setAttribute", [d, c]));
      });
      return new th(b.cssText || "", sh);
    },
    LH = function (a) {
      Qa(a) ? (a = bc(a)) : ((a = Ug(a)), Yb(a, "cssText"));
      return a;
    };
  var NH = fa([""]),
    OH = function (a, b, c) {
      S.call(this);
      this.j = a;
      this.o = b;
      this.F = c;
      this.g = null;
      this.G = "";
      this.H = zh(NH);
      this.J = 0;
      this.B = this.slot = this.l = null;
      this.C = "";
    };
  v(OH, S);
  OH.prototype.init = function (a) {
    this.C = a;
    a = "about:blank";
    lc && (a = "");
    this.l = $h("IFRAME", {
      src: a,
      allowtransparency: !0,
      background: "transparent",
      title: "Advertisement",
    });
    Hm(this.l, { display: "none", width: "0", height: "0" });
    a = this.j.Uc;
    a.appendChild(this.l);
    a = a.ownerDocument;
    a = a.defaultView || a.parentWindow;
    null == this.B && (this.B = new Kx(this));
    this.B.O(a, "message", this.L);
    a =
      '<body><script src="//imasdk.googleapis.com/js/sdkloader/loader.js">\x3c/script><script>loader = new VPAIDLoader(false, "' +
      (this.C + '");\x3c/script></body>');
    if (Ec || Cc || mc) {
      var b = this.l.contentWindow;
      b && CH(b.document, a);
    } else
      (b = this.l),
        BH
          ? ((a = ij(a)), (b.srcdoc = xh(a)))
          : (b = b.contentWindow) && CH(b.document, a);
  };
  OH.prototype.L = function (a) {
    try {
      var b = a.g.data;
      try {
        var c = JSON.parse(b);
      } catch (t) {
        return;
      }
      var d = c.session;
      if (null != d && this.C === d)
        switch (c.type) {
          case "friendlyReady":
            var e = PH(this);
            if (null != e) {
              this.g = e;
              this.G = e.currentSrc;
              var f = e.style.cssText,
                g = document.implementation
                  .createHTMLDocument("")
                  .createElement("DIV");
              g.style.cssText = f;
              this.H = MH(g.style);
              this.J = e.currentTime;
            } else {
              var h = this.j.Uc,
                k = "border: 0; margin: 0; padding: 0; position: absolute; ",
                n = this.j.getSize();
              k += "width:" + n.width + "px;";
              k += "height:" + n.height + "px;";
              this.g = $h("VIDEO", { style: k, autoplay: !0 });
              h.appendChild(this.g);
            }
            var m = this.j.Uc;
            h = "border: 0; margin: 0; padding: 0;position: absolute; ";
            var r = Qm(this.g);
            h += "width:" + r.width + "px;";
            h += "height:" + r.height + "px;";
            this.slot = $h("DIV", { style: h });
            m.appendChild(this.slot);
            try {
              this.l.contentWindow.loader.initFriendly(this.g, this.slot);
            } catch (t) {
              QH(this);
            }
            eD(this.o, "vpaid", "", b);
            break;
          case "becameLinear":
            this.g && !gi() && !fi() && Hm(this.g, { visibility: "visible" });
            eD(this.o, "vpaid", "", b);
            break;
          case "becameNonlinear":
            RH(this);
            eD(this.o, "vpaid", "", b);
            break;
          case "startAd":
            m = {};
            if (this.g) {
              k = this.g.paused;
              var p = 0 < this.g.currentTime;
              m.apl = p && !k ? "1" : "0";
              m.ip = k ? "1" : "0";
              m.iavp = p ? "1" : "0";
            } else m.apl = "n";
            X.getInstance().report(99, m);
            eD(this.o, "vpaid", "", b);
            this.Zc();
            break;
          default:
            eD(this.o, "vpaid", "", b);
        }
    } catch (t) {
      QH(this);
    }
  };
  var QH = function (a) {
    var b = { type: "error" };
    b.session = a.C;
    b = JSON.stringify(b);
    a.postMessage(b);
  };
  OH.prototype.postMessage = function (a) {
    window.postMessage(a, "*");
  };
  var PH = function (a) {
    return ("videoDisplayUnknown" === a.F ? a.j.da : a.j.Xd.get(a.F)).P.g;
  };
  OH.prototype.Zc = function () {
    null != PH(this) && this.j.Zc();
  };
  var RH = function (a) {
    a.g && !gi() && !fi() && Hm(a.g, { visibility: "hidden" });
  };
  OH.prototype.M = function () {
    Gn(this.B);
    this.B = null;
    ai(this.slot);
    this.slot = null;
    ai(this.l);
    this.l = null;
    var a = PH(this);
    if (null != a) {
      var b = this.H;
      a.style.cssText =
        b instanceof th && b.constructor === th ? b.g : "type_error:SafeStyle";
      gi() || fi()
        ? ((a.src = this.G), (a.currentTime = this.J))
        : (a.removeAttribute("src"), this.j.ib());
    } else ai(this.g), (this.g = null);
    S.prototype.M.call(this);
  };
  var SH = function (a, b) {
    Q.call(this);
    this.j = a;
    this.l = b;
    this.g = new Map();
  };
  v(SH, Q);
  var TH = function (a, b) {
    try {
      var c = b.oa,
        d = c.session;
      switch (c.vpaidEventType) {
        case "createFriendlyIframe":
          b = "videoDisplayUnknown";
          c.videoDisplayName && (b = c.videoDisplayName);
          var e = c.session,
            f = new OH(a.j, a.l, b);
          a.g.set(e, f);
          f.init(e);
          break;
        case "vpaidNonLinear":
          var g = a.g.get(d);
          g && RH(g);
          break;
        case "destroyFriendlyIframe":
          var h = a.g.get(d);
          h && (h.X(), a.g.delete(d));
      }
    } catch (k) {
      X.getInstance().report(125, { msg: k.message });
    }
  };
  SH.prototype.M = function () {
    this.g.forEach(function (a) {
      a.X();
    });
  };
  var UH = function (a) {
    this.K = B(a);
  };
  v(UH, F);
  UH.prototype.getValue = function () {
    return E(this, 1);
  };
  UH.prototype.getVersion = function () {
    return Hf(this, 5);
  };
  var VH = Fg(UH);
  var WH = function () {
      this.g = window;
      this.j = 0;
    },
    XH = function (a, b) {
      if (0 === a.j) {
        if (b && hu("__gads", b, a.g)) b = !0;
        else {
          var c = a.g;
          Df(b, 5) &&
            "null" !== c.origin &&
            gu(c).set("GoogleAdServingTest", "Good", void 0);
          if ((c = "Good" === hu("GoogleAdServingTest", b, a.g))) {
            var d = a.g;
            Df(b, 5) &&
              "null" !== d.origin &&
              gu(d).remove("GoogleAdServingTest", void 0, void 0);
          }
          b = c;
        }
        a.j = b ? 2 : 1;
      }
      return 2 === a.j;
    },
    YH = function (a, b, c, d) {
      if (d) {
        var e = Gf(c, 2) - Date.now() / 1e3;
        e = { Ic: Math.max(e, 0), path: E(c, 3), domain: E(c, 4), Ie: !1 };
        c = c.getValue();
        a = a.g;
        Df(d, 5) && "null" !== a.origin && gu(a).set(b, c, e);
      }
    },
    ZH = function (a, b, c) {
      if (c && hu(b, c, a.g)) {
        var d = a.g.location.hostname;
        if ("localhost" === d) d = ["localhost"];
        else if (((d = d.split(".")), 2 > d.length)) d = [];
        else {
          for (var e = [], f = 0; f < d.length - 1; ++f)
            e.push(d.slice(f).join("."));
          d = e;
        }
        d = u(d);
        for (var g = d.next(); !g.done; g = d.next())
          (e = b),
            (f = a.g),
            (g = g.value),
            Df(c, 5) && "null" !== f.origin && gu(f).remove(e, "/", g);
      }
    };
  var $H = function () {
    this.g = [];
    this.j = [];
  };
  l = $H.prototype;
  l.isEmpty = function () {
    return 0 === this.g.length && 0 === this.j.length;
  };
  l.clear = function () {
    this.g = [];
    this.j = [];
  };
  l.contains = function (a) {
    return Xb(this.g, a) || Xb(this.j, a);
  };
  l.remove = function (a) {
    var b = this.g;
    b: {
      var c = b.length - 1;
      0 > c && (c = Math.max(0, b.length + c));
      if ("string" === typeof b)
        c = "string" !== typeof a || 1 != a.length ? -1 : b.lastIndexOf(a, c);
      else {
        for (; 0 <= c; c--) if (c in b && b[c] === a) break b;
        c = -1;
      }
    }
    0 <= c ? (Zb(b, c), (b = !0)) : (b = !1);
    return b || Yb(this.j, a);
  };
  l.Db = function () {
    for (var a = [], b = this.g.length - 1; 0 <= b; --b) a.push(this.g[b]);
    var c = this.j.length;
    for (b = 0; b < c; ++b) a.push(this.j[b]);
    return a;
  };
  var Z = function (a, b, c, d, e, f, g, h) {
    S.call(this);
    var k = this;
    this.H = a;
    this.g = b;
    this.adTagUrl = c;
    this.ga = d;
    this.Pa = e;
    this.F = g;
    this.Oa = h;
    this.o = new IF();
    this.L = !1;
    this.volume = 1;
    this.ga = d;
    this.ba = -1;
    this.C = this.l = this.j = null;
    this.B = new zH({ currentTime: 0 }, this.F);
    this.G = new $H();
    this.ka = this.W = !1;
    this.Y = new Map();
    this.Z = this.Ga = !1;
    this.Ha = new SH(b, g);
    In(this, this.Ha);
    this.J = f && null != this.g.o;
    this.P = function () {
      var n = k.g.da,
        m = n.getCurrentTime();
      n = n.getDuration();
      return { currentTime: m, duration: n, isPlaying: !0, volume: k.volume };
    };
    this.U = new Kx(this);
    this.U.O(this.F, "adsManager", this.Bb);
  };
  v(Z, S);
  Z.prototype.Bb = function (a) {
    var b = this,
      c = a.messageType,
      d = a.oa,
      e = {};
    switch (c) {
      case "error":
        aI(this);
        bI(this, d);
        break;
      case "contentPauseRequested":
        X.getInstance().report(130);
        cI(this);
        this.B.stop();
        dI(this, c, d);
        break;
      case "contentResumeRequested":
        eI(this, function () {
          dI(b, c, d);
        });
        break;
      case "remainingTime":
        this.ba = d.remainingTime;
        break;
      case "skip":
        dI(this, c, d);
        break;
      case "log":
        dI(this, c, d, d.logData);
        break;
      case "companionBackfill":
        a = Na("window.google_show_companion_ad");
        null != a && a();
        break;
      case "skipShown":
        this.L = !0;
        dI(this, c, d);
        break;
      case "interaction":
        dI(this, c, d, d.interactionData);
        break;
      case "vpaidEvent":
        TH(this.Ha, a);
        break;
      case "skippableStateChanged":
        e = d.adData;
        null != e.skippable && (this.L = e.skippable);
        dI(this, c, d);
        break;
      case "volumeChange":
        e = d.adData;
        null != e && "number" === typeof e.volume && (this.volume = e.volume);
        dI(this, c, d);
        break;
      case "firstQuartile":
        dI(this, UC.firstQuartile, d);
        dI(this, c, d);
        break;
      case "thirdQuartile":
        dI(this, UC.thirdQuartile, d);
        dI(this, c, d);
        break;
      case "updateGfpCookie":
        fI(this, d);
        break;
      default:
        dI(this, c, d);
    }
  };
  var dI = function (a, b, c, d) {
      if (null == c.companions) {
        var e = a.Y.get(c.adId);
        c.companions = null != e ? e : [];
      }
      var f = c.adData;
      if ((e = null == f ? null : new Y(f))) a.j = e;
      switch (b) {
        case "adBreakReady":
        case "mediaUrlPinged":
          b = new wH(b, null, c);
          break;
        case "adMetadata":
          b = null;
          null != c.adCuePoints && (b = new GF(c.adCuePoints));
          b = new xH(e, b);
          break;
        case "allAdsCompleted":
          a.j = null;
          a.Ga = !0;
          b = new wH(b, e);
          break;
        case "contentPauseRequested":
          a.Z = !1;
          b = new wH(b, e);
          break;
        case "contentResumeRequested":
          a.j = null;
          a.Z = !0;
          b = new wH(b, e);
          break;
        case "loaded":
          a.ba = e.getDuration();
          a.L = !1;
          MC() &&
            ((d = a.H),
            (c = a.Pa),
            d.j.set(FF(e), a.P),
            LG(d) && KG(d, "loaded", FF(e), c));
          b = new wH(b, e, f);
          break;
        case "start":
          a.Y.set(c.adId, c.companions);
          null != a.g.Qb() &&
            (null == a.l
              ? ((a.l = new TE()), a.U.O(a.l, "click", a.qg))
              : XE(a.l),
            VE(a.l, a.g.Qb()));
          b = new wH(b, e);
          break;
        case "complete":
          null != a.l && XE(a.l);
          MC() && NG(a.H, a.P, FF(e));
          a.j = null;
          a.Y.delete(c.adId);
          b = new wH(b, e);
          break;
        case "log":
          c = null;
          null != d && null != d.type
            ? ((f = d.type), (f = "adLoadError" === f || "adPlayError" === f))
            : (f = !1);
          f && (c = { adError: new sH(d) });
          b = new wH(b, e, c);
          break;
        case "interaction":
          b = new wH(b, e, d);
          break;
        case "adProgress":
          b = new wH(b, e, new yH(c));
          break;
        default:
          b = new wH(b, e);
      }
      a.dispatchEvent(b);
      a.Ga && a.Z && a.destroy();
    },
    bI = function (a, b) {
      var c = new uH(new sH(b));
      a.W
        ? (a.dispatchEvent(c),
          MC() && a.j && NG(a.H, a.P, FF(a.j)),
          (a.j = null))
        : a.G.j.push(c);
      a = { error: b.errorCode, vis: Vi(document) };
      X.getInstance().report(7, a);
    },
    gI = function (a, b, c) {
      eD(a.F, "adsManager", b, c);
    },
    eI = function (a, b) {
      X.getInstance().report(131);
      aI(a, b);
      a.Ca() || a.B.start();
    },
    cI = function (a) {
      var b = a.g.da;
      oH(a.g) &&
        a.o.restoreCustomPlaybackStateOnAdBreakComplete &&
        null != b.ce &&
        b.ce();
    },
    aI = function (a, b) {
      var c = a.g.da;
      oH(a.g) && a.o.restoreCustomPlaybackStateOnAdBreakComplete && null != c.hc
        ? c.hc(b)
        : b && b();
    };
  l = Z.prototype;
  l.configureAdsManager = function (a, b) {
    this.C = a;
    null != a.currentTime && ((this.B = new zH(a, this.F)), this.B.start());
    null != b && (this.o = hI(b));
  };
  l.init = function (a, b, c, d) {
    if (this.G.isEmpty()) {
      var e = this.g,
        f = null;
      e.j && null == d && (f = { vd: "setnull" });
      e.j && e.j === d && (f = { vd: "match" });
      if (e.j && e.j !== d) {
        f = LC(d || null);
        var g = vx(d || null);
        f = { vd: "diff", oc: e.P, nc: f, oi: e.L, ni: g };
      }
      !e.j && d && (f = { vd: "new" });
      f && ((f.custVid = e.J), X.getInstance().report(93, f));
      null != d &&
        ((e.I = nH(d)),
        KC(e.I) &&
          ((e.H = !0),
          Gn(e.g),
          Gn(e.l),
          Gn(e.Aa),
          (e.g = null),
          (e.l = null),
          (e.Aa = null),
          Gn(e.da),
          (e.da = new UG(d)),
          "function" !== typeof d.getBoundingClientRect
            ? ((e.C = e.A), (eC.l = e.C))
            : (e.C = d),
          e.B.jc(e.da)));
      this.W = !0;
      this.resize(a, b, c);
      d = JF(this.o, this.J);
      e = {};
      a =
        ((e.adsRenderingSettings = d),
        (e.width = a),
        (e.height = b),
        (e.viewMode = c),
        e);
      gI(this, "init", a);
    } else {
      for (; !this.G.isEmpty(); )
        (b = a = this.G),
          0 === b.g.length && ((b.g = b.j), b.g.reverse(), (b.j = [])),
          (a = a.g.pop()),
          this.dispatchEvent(a);
      this.X();
    }
  };
  l.isCustomPlaybackUsed = function () {
    return oH(this.g);
  };
  l.isCustomClickTrackingUsed = function () {
    return this.J;
  };
  l.getRemainingTime = function () {
    return this.ba;
  };
  l.getAdSkippableState = function () {
    return this.L;
  };
  l.discardAdBreak = function () {
    gI(this, "discardAdBreak");
  };
  l.updateAdsRenderingSettings = function (a) {
    if (null != a) {
      a = hI(a);
      var b = this.o.bitrate,
        c = a.bitrate;
      X.getInstance().report(96, {
        init: this.W ? "1" : "0",
        start: this.ka ? "1" : "0",
        old: b,
        new: c,
        changed: b !== c ? "1" : "0",
      });
      this.o = a;
      a = JF(this.o, this.J);
      b = {};
      a = ((b.adsRenderingSettings = a), b);
      gI(this, "updateAdsRenderingSettings", a);
    }
  };
  l.skip = function () {
    gI(this, "skip");
  };
  l.start = function () {
    if (this.adTagUrl) {
      (rc || tc) && X.getInstance().report(50, { customPlayback: oH(this.g) });
      this.g.va() ||
        X.getInstance().report(26, {
          adtagurl: this.adTagUrl,
          customPlayback: oH(this.g),
        });
      Wm(this.g.A) &&
        X.getInstance().report(30, {
          adtagurl: this.adTagUrl,
          customPlayback: oH(this.g),
        });
      var a = this.g.o,
        b = this.g.A,
        c;
      if ((c = a && b && !Wm(a)))
        (a = IG(a)),
          (b = IG(b)),
          (c =
            0 < a.width &&
            0 < a.height &&
            0 < b.width &&
            0 < b.height &&
            a.left <= b.left + b.width &&
            b.left <= a.left + a.width &&
            a.top <= b.top + b.height &&
            b.top <= a.top + a.height);
      b = c;
      X.getInstance().report(31, {
        adtagurl: this.adTagUrl,
        customPlayback: oH(this.g),
        covers: b,
      });
    }
    if (!this.g.va() && !oH(this.g)) throw tD(rD);
    b = this.g;
    b.G = this.J && null != b.o;
    this.g.B.g.style.opacity = "1";
    if (null != this.C && 1 === this.getVolume()) {
      var d, e;
      if (
        "boolean" === typeof (null == (d = this.C) ? void 0 : d.muted) &&
        (null == (e = this.C) ? 0 : e.muted)
      )
        this.setVolume(0);
      else {
        var f;
        if ("number" === typeof (null == (f = this.C) ? void 0 : f.volume)) {
          var g;
          d = null == (g = this.C) ? void 0 : g.volume;
          if (0 <= d && 1 >= d) {
            var h;
            this.setVolume(null == (h = this.C) ? void 0 : h.volume);
          }
        }
      }
    }
    this.ka = !0;
    gI(this, "start");
  };
  l.qg = function () {
    if (!this.o.disableClickThrough && null != this.j) {
      var a = this.j.data.clickThroughUrl;
      null != a && bx(a, this.j.data.attributionParams);
    }
  };
  l.resize = function (a, b, c) {
    var d = this.g,
      e = d.A;
    null != e &&
      (-1 === a
        ? ((e.style.right = "0"), (e.style.left = "0"))
        : (e.style.width = a + "px"),
      -1 === b
        ? ((e.style.bottom = "0"), (e.style.top = "0"))
        : (e.style.height = b + "px"));
    e = d.B;
    e.g.width = -1 === a ? "100%" : String(a);
    e.g.height = -1 === b ? "100%" : String(b);
    try {
      e.g.offsetTop = e.g.offsetTop;
    } catch (f) {}
    d.size = new Bh(a, b);
    d = {};
    a = ((d.width = a), (d.height = b), (d.viewMode = c), d);
    gI(this, "resize", a);
  };
  l.stop = function () {
    gI(this, "stop");
  };
  l.expand = function () {
    gI(this, "expand");
  };
  l.collapse = function () {
    gI(this, "collapse");
  };
  l.getVolume = function () {
    return this.volume;
  };
  l.setVolume = function (a) {
    this.volume = a;
    this.g.da.setVolume(a);
    var b = {};
    a = ((b.volume = a), b);
    gI(this, "volume", a);
  };
  l.pause = function () {
    gI(this, "pause");
  };
  l.resume = function () {
    gI(this, "resume");
  };
  l.destroy = function () {
    this.X();
  };
  l.getCuePoints = function () {
    return this.ga;
  };
  l.Of = function () {
    return this.j;
  };
  l.M = function () {
    gI(this, "destroy");
    null != this.l && this.l.X();
    this.U.X();
    this.G.clear();
    this.B && (this.B.stop(), this.B.X());
    MC() && NG(this.H, this.P);
    S.prototype.M.call(this);
  };
  l.Gf = function () {
    X.getInstance().report(124, { api: "clicked" });
    var a = this.j && this.j.data.clickThroughUrl,
      b;
    if (a && (null == (b = this.j) ? 0 : b.ye())) {
      var c;
      bx(a, null == (c = this.j) ? void 0 : c.data.attributionParams);
    }
    gI(this, "click");
  };
  l.focus = function () {
    eD(this.F, "userInteraction", "focusUiElement");
  };
  var fI = function (a, b) {
    var c = b.gfpCookieUserEnabled;
    b = b.gfpCookieClearData;
    var d = new UH();
    d = Kf(d, 1, c ? "0" : "1");
    d = C(d, 2, le(2147483647));
    d = Kf(d, 3, "/");
    d = Kf(d, 4, window.location.hostname);
    var e = new WH(),
      f,
      g;
    a = null != (g = null == (f = a.Oa) ? void 0 : oC(f)) ? g : null;
    YH(e, "__gpi_opt_out", d, a);
    if (!c || b) ZH(e, "__gads", a), ZH(e, "__gpi", a);
  };
  Z.prototype.clicked = Z.prototype.Gf;
  Z.prototype.getCurrentAd = Z.prototype.Of;
  Z.prototype.getCuePoints = Z.prototype.getCuePoints;
  Z.prototype.destroy = Z.prototype.destroy;
  Z.prototype.resume = Z.prototype.resume;
  Z.prototype.pause = Z.prototype.pause;
  Z.prototype.setVolume = Z.prototype.setVolume;
  Z.prototype.getVolume = Z.prototype.getVolume;
  Z.prototype.collapse = Z.prototype.collapse;
  Z.prototype.expand = Z.prototype.expand;
  Z.prototype.stop = Z.prototype.stop;
  Z.prototype.resize = Z.prototype.resize;
  Z.prototype.start = Z.prototype.start;
  Z.prototype.skip = Z.prototype.skip;
  Z.prototype.updateAdsRenderingSettings =
    Z.prototype.updateAdsRenderingSettings;
  Z.prototype.discardAdBreak = Z.prototype.discardAdBreak;
  Z.prototype.getAdSkippableState = Z.prototype.getAdSkippableState;
  Z.prototype.getRemainingTime = Z.prototype.getRemainingTime;
  Z.prototype.isCustomClickTrackingUsed = Z.prototype.isCustomClickTrackingUsed;
  Z.prototype.isCustomPlaybackUsed = Z.prototype.isCustomPlaybackUsed;
  Z.prototype.init = Z.prototype.init;
  function hI(a) {
    if (a instanceof IF) return X.getInstance().report(174, { valid: !0 }), a;
    X.getInstance().report(174, { valid: !1 });
    var b = new IF();
    b.append(a);
    return b;
  }
  var iI = { ADS_MANAGER_LOADED: "adsManagerLoaded" },
    jI = function (a, b) {
      Lr.call(this, "adsManagerLoaded");
      this.g = a;
      this.l = b;
    };
  v(jI, Lr);
  jI.prototype.getAdsManager = function (a, b) {
    a = a || { currentTime: null };
    this.g.configureAdsManager(a, b);
    return this.g;
  };
  jI.prototype.getUserRequestContext = function () {
    return this.l;
  };
  jI.prototype.getUserRequestContext = jI.prototype.getUserRequestContext;
  jI.prototype.getAdsManager = jI.prototype.getAdsManager;
  z(
    "module$exports$google3$javascript$ads$interactivemedia$sdk$clientside$api$ads_manager_loaded_event.AdsManagerLoadedEvent.Type",
    iI
  );
  var kI = function (a, b) {
      (0, a.__uspapi)("getUSPData", 1, function (c, d) {
        b.wa({ vc: null != c ? c : void 0, xc: d ? void 0 : 2 });
      });
    },
    lI = {
      Hc: function (a) {
        return a.wa;
      },
      Yb: function (a, b) {
        a = {};
        return (
          (a.__uspapiCall = { callId: b, command: "getUSPData", version: 1 }), a
        );
      },
      Gb: function (a, b) {
        b = b.__uspapiReturn;
        var c;
        a({
          vc: null != (c = b.returnValue) ? c : void 0,
          xc: b.success ? void 0 : 2,
        });
      },
    };
  function mI(a) {
    var b = {};
    "string" === typeof a.data ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, Ae: b.__uspapiReturn.callId };
  }
  var nI = function (a, b) {
    b = void 0 === b ? {} : b;
    Q.call(this);
    var c;
    this.timeoutMs = null != (c = b.timeoutMs) ? c : 500;
    this.caller = new Xv(
      a,
      "__uspapiLocator",
      function (d) {
        return "function" === typeof d.__uspapi;
      },
      mI
    );
    this.caller.o.set("getDataWithCallback", kI);
    this.caller.A.set("getDataWithCallback", lI);
  };
  v(nI, Q);
  nI.prototype.M = function () {
    this.caller.X();
    Q.prototype.M.call(this);
  };
  var oI = function (a, b) {
    var c = {};
    if (Yv(a.caller)) {
      var d = Jg(function () {
        b(c);
      });
      $v(a.caller, "getDataWithCallback", {
        wa: function (e) {
          e.xc || (c = e.vc);
          d();
        },
      });
      setTimeout(d, a.timeoutMs);
    } else b(c);
  };
  var lu = function () {
    this.g = window;
  };
  function pI() {
    var a = window,
      b,
      c;
    return null !=
      (c = ["pbjs"]
        .concat(null != (b = a._pbjsGlobals) ? b : [])
        .map(function (d) {
          return a[d];
        })
        .find(function (d) {
          return Array.isArray(null == d ? void 0 : d.que);
        }))
      ? c
      : null;
  }
  function qI(a, b) {
    var c, d, e;
    null == b ? (e = void 0) : (e = b.get.call(b, a));
    return null != (d = null != (c = e) ? c : null == b ? void 0 : b.get(ti(a)))
      ? d
      : 0;
  }
  var rI = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
    sI = new Map();
  function tI(a, b, c, d, e) {
    var f = e.getBidResponsesForAdUnitCode;
    if (f) {
      var g,
        h,
        k,
        n,
        m,
        r =
          null !=
          (m = null == (g = f(null != (k = b.Ob) ? k : "")) ? void 0 : g.bids)
            ? m
            : null == (h = f(null != (n = b.adUnitCode) ? n : ""))
            ? void 0
            : h.bids;
      if (
        null != r &&
        r.length &&
        ((g = r.filter(function (w) {
          var y = w.adId;
          return (
            w.auctionId !== c &&
            Object.values(d).some(function (R) {
              return R.includes(y);
            })
          );
        })),
        g.length)
      ) {
        var p, t;
        f =
          null == (p = e.adUnits)
            ? void 0
            : null ==
              (t = p.find(function (w) {
                w = w.code;
                return w === b.Ob || w === b.adUnitCode;
              }))
            ? void 0
            : t.mediaTypes;
        p = u(g);
        for (t = p.next(); !t.done; t = p.next())
          (t = t.value),
            (g = uI(t, d, f)),
            (g = Et(a, yt(Jf(zt(xt(new wt(), t.bidder), 1), 6, !0), g))),
            vI(t.bidder, e, g),
            "number" === typeof t.timeToRespond &&
              C(g, 2, le(Math.round(t.timeToRespond)));
      }
    }
  }
  function vI(a, b, c) {
    for (var d = []; a && !d.includes(a); ) {
      d.unshift(a);
      var e = void 0,
        f = void 0;
      a =
        null == (e = b)
          ? void 0
          : null == (f = e.aliasRegistry)
          ? void 0
          : f[a];
    }
    pf(c, 10, d, se);
  }
  function wI(a, b, c) {
    null != ge(df(a, 3)) ||
      (c === b.adUnitCode ? C(a, 3, fe(1)) : c === b.Ob && C(a, 3, fe(2)));
  }
  function xI(a, b, c, d, e, f, g) {
    f = f.get(
      null != g
        ? g
        : function () {
            return null;
          }
    );
    1 !== (null == f ? void 0 : Hf(f, 1)) && wf(b, 5, f);
    void 0 !== rf(a, qt, 5, !1) ||
      (f
        ? 1 === Hf(f, 1)
          ? Ft(a, f)
          : Ft(a, ut(rt(tt(new qt(), e), 1), qI(c, d)))
        : Ft(a, rt(tt(new qt(), e), qI(c, d) ? 2 : 3)));
  }
  function uI(a, b, c) {
    var d = a.cpm,
      e = a.originalCpm,
      f = a.currency,
      g = a.originalCurrency,
      h = a.dealId,
      k = a.adserverTargeting,
      n = a.bidder,
      m = a.adId,
      r = a.mediaType,
      p = a.height,
      t = a.width,
      w = new ot();
    "number" === typeof d &&
      (C(w, 2, le(Math.round(1e6 * d))),
      (g && g !== f) ||
        ((d = Math.round(1e6 * Number(e))),
        isNaN(d) || d === Gf(w, 2) || C(w, 8, le(d))));
    "string" === typeof f && Kf(w, 3, f);
    ["string", "number"].includes(typeof h) &&
      ((f = new it()), (h = Kf(f, 1, String(h))), wf(w, 6, h));
    if ("object" === typeof k)
      for (h = u(["", "_" + n]), f = h.next(); !f.done; f = h.next()) {
        d = f.value;
        f = [];
        e = u(Object.entries(k));
        for (g = e.next(); !g.done; g = e.next()) {
          g = u(g.value);
          var y = g.next().value;
          g = g.next().value;
          y = ("" + y + d).slice(0, 20);
          var R = void 0;
          if (null != (R = b[y]) && R.length)
            if (b[y][0] === String(g)) f.push(y);
            else {
              f = [];
              break;
            }
        }
        d = gf(w, 4, ue);
        pf(w, 4, d.concat(f), se);
      }
    switch (r || "banner") {
      case "banner":
        C(w, 5, fe(1));
        break;
      case "native":
        C(w, 5, fe(2));
        break;
      case "video":
        C(w, 5, fe(3));
        b = new mt();
        var ka;
        if (
          "adpod" ===
          (null == c ? void 0 : null == (ka = c.video) ? void 0 : ka.context)
        ) {
          var ua,
            pa =
              null == c
                ? void 0
                : null == (ua = c.video)
                ? void 0
                : ua.adPodDurationSec;
          C(b, 1, le(pa));
        } else
          (ua =
            null == c
              ? void 0
              : null == (pa = c.video)
              ? void 0
              : pa.maxduration),
            C(b, 1, le(ua));
        var Ma;
        if (
          "number" ===
          typeof (null == c
            ? void 0
            : null == (Ma = c.video)
            ? void 0
            : Ma.skip)
        ) {
          var Ta;
          c = !!(null == c ? 0 : null == (Ta = c.video) ? 0 : Ta.skip);
          Jf(b, 2, c);
        }
        var Oc;
        a = null == (Oc = a.meta) ? void 0 : Oc.adServerCatId;
        Oc = Kf(b, 3, a);
        if ("object" !== typeof k) k = null;
        else {
          var vb, Ib;
          a = String(
            null !=
              (Ib =
                null != (vb = k["hb_pb_cat_dur_" + n]) ? vb : k.hb_pb_cat_dur)
              ? Ib
              : ""
          );
          var Wb, Pc, mh, nh;
          vb = String(
            null !=
              (nh =
                null !=
                (mh =
                  null !=
                  (Pc =
                    null != (Wb = k["hb_cache_id_" + n])
                      ? Wb
                      : k["hb_uuid_" + n])
                    ? Pc
                    : k.hb_cache_id)
                  ? mh
                  : k.hb_uuid)
              ? nh
              : ""
          );
          k = a && vb ? a + "_" + vb : vb ? vb : null;
        }
        Kf(Oc, 4, k);
        wf(w, 9, b);
    }
    Number.isFinite(p) &&
      Number.isFinite(t) &&
      ((k = new kt()),
      (t = C(k, 1, ie(Math.round(t)))),
      (p = C(t, 2, ie(Math.round(p)))),
      wf(w, 7, p));
    "string" === typeof m && Kf(w, 1, m);
    return w;
  }
  function yI(a, b) {
    var c = new Map(),
      d = function (k) {
        var n = c.get(k);
        n || ((n = {}), c.set(k, n));
        return n;
      },
      e = [];
    a = u(a);
    for (var f = a.next(); !f.done; f = a.next()) {
      f = f.value;
      var g = f.args,
        h = f.eventType;
      f = f.elapsedTime;
      "bidTimeout" === h && e.push.apply(e, ha(g));
      switch (h) {
        case "bidRequested":
          if (g.auctionId !== b) continue;
          if (!Array.isArray(g.bids)) continue;
          g = u(g.bids);
          for (h = g.next(); !h.done; h = g.next())
            if ((h = h.value.bidId)) d(h).requestTime = f;
          break;
        case "noBid":
          g.auctionId === b && g.bidId && (d(g.bidId).xg = f);
      }
    }
    d = new Map();
    a = u(c.entries());
    for (f = a.next(); !f.done; f = a.next())
      (g = u(f.value)),
        (f = g.next().value),
        (h = g.next().value),
        (g = h.requestTime),
        (h = h.xg),
        g && h && d.set(f, { latency: h - g, xe: !1 });
    e = u(e);
    for (a = e.next(); !a.done; a = e.next())
      if (
        ((f = a.value),
        (a = f.bidId),
        (f = f.auctionId),
        a && f === b && (a = d.get(a)))
      )
        a.xe = !0;
    return d;
  }
  function zI(a, b) {
    var c = {};
    c = void 0 === c ? {} : c;
    var d = void 0 === d ? new Map() : d;
    var e = void 0 === e ? !1 : e;
    var f = void 0 === f ? new Map() : f;
    var g = void 0 === g ? new Bt() : g;
    var h = void 0 === h ? 0 : h;
    var k = new Map(),
      n = (0, a.getEvents)(),
      m = n.filter(function (ab) {
        var Jb = ab.args;
        return "auctionEnd" === ab.eventType && Jb.auctionId;
      }),
      r = new It(),
      p = function (ab) {
        return ab === b.Ob || ab === b.adUnitCode;
      },
      t,
      w,
      y,
      R =
        null !=
        (y = sI.get(
          (null != (t = b.Ob) ? t : "") + (null != (w = b.adUnitCode) ? w : "")
        ))
          ? y
          : 0,
      ka;
    m =
      null !=
      (ka = m.filter(function (ab) {
        var Jb, ky, ly;
        return (
          Number(null == (Jb = ab.args) ? void 0 : Jb.timestamp) > R &&
          (null == (ky = ab.args)
            ? void 0
            : null == (ly = ky.adUnitCodes)
            ? void 0
            : ly.find(p))
        );
      }))
        ? ka
        : [];
    if (!m.length) return null;
    var ua;
    if (
      (m =
        null ==
        (ua = m.reduce(function (ab, Jb) {
          return Number(Jb.args.timestamp) > Number(ab.args.timestamp)
            ? Jb
            : ab;
        }))
          ? void 0
          : ua.args)
    ) {
      ka = void 0 === m.bidderRequests ? [] : m.bidderRequests;
      ua = void 0 === m.bidsReceived ? [] : m.bidsReceived;
      var pa = m.auctionId;
      m = m.timestamp;
      if (pa && null != m && ka.length) {
        var Ma, Ta;
        sI.set(
          (null != (Ma = b.Ob) ? Ma : "") +
            (null != (Ta = b.adUnitCode) ? Ta : ""),
          m
        );
        Ma = Jt(r);
        a.version && rI.test(a.version) && Kf(Ma, 6, a.version);
        var Oc, vb, Ib;
        if (
          null == (Oc = a.getConfig)
            ? 0
            : null == (vb = Oc.call(a).cache)
            ? 0
            : null == (Ib = vb.url)
            ? 0
            : Ib.length
        ) {
          var Wb, Pc;
          Gt(
            Ma,
            null == (Wb = a.getConfig)
              ? void 0
              : null == (Pc = Wb.call(a).cache)
              ? void 0
              : Pc.url
          );
        }
        wf(Ma, 9, g);
        g = Ig(function () {
          return yI(n, pa);
        });
        Oc = u(ka);
        Ib = Oc.next();
        for (
          vb = {};
          !Ib.done;
          vb = { bidderCode: void 0, Me: void 0 }, Ib = Oc.next()
        )
          for (
            Wb = Ib.value,
              vb.bidderCode = Wb.bidderCode,
              Pc = Wb.bids,
              Ib = Wb.timeout,
              vb.Me = Wb.src,
              Wb = Wb.auctionStart,
              Pc = u(Pc),
              ka = Pc.next(),
              Ta = {};
            !ka.done;
            Ta = { lc: void 0 }, ka = Pc.next()
          )
            if (
              ((y = ka.value),
              (Ta.lc = y.bidId),
              (w = y.transactionId),
              (ka = y.adUnitCode),
              (m = y.getFloor),
              (t = y.mediaTypes),
              (y = y.ortb2Imp),
              Ta.lc && p(ka))
            ) {
              wI(Ma, b, ka);
              var mh = void 0,
                nh = void 0;
              h &&
                null == Bf(Ma, 11) &&
                "string" ===
                  typeof (null == (mh = y)
                    ? void 0
                    : null == (nh = mh.ext)
                    ? void 0
                    : nh.gpid) &&
                Kf(Ma, 11, y.ext.gpid.substring(0, h));
              w &&
                (null != Bf(Ma, 4) || Kf(Ma, 4, w), k.has(w) || k.set(w, Wb));
              null == je(df(Ma, 8)) && Number.isFinite(Ib) && C(Ma, 8, ie(Ib));
              y = ua.find(
                (function (ab) {
                  return function (Jb) {
                    return Jb.requestId === ab.lc;
                  };
                })(Ta)
              );
              w = Et(
                Ma,
                (function (ab) {
                  return function () {
                    var Jb = xt(new wt(), ab.bidderCode);
                    vI(ab.bidderCode, a, Jb);
                    switch (ab.Me) {
                      case "client":
                        C(Jb, 7, fe(1));
                        break;
                      case "s2s":
                        C(Jb, 7, fe(2));
                    }
                    return Jb;
                  };
                })(vb)()
              );
              xI(Ma, w, ka, d, e, f, m);
              y
                ? (zt(w, 1),
                  "number" === typeof y.timeToRespond &&
                    Number.isFinite(y.timeToRespond) &&
                    C(w, 2, le(Math.round(y.timeToRespond))),
                  (Ta = uI(y, c, t)),
                  yt(w, Ta))
                : (Ta = g().get(Ta.lc)) && !Ta.xe
                ? (zt(w, 2),
                  Number.isFinite(Ta.latency) &&
                    C(w, 2, le(Math.round(Ta.latency))))
                : ((Ta = zt(w, 3)),
                  Number.isFinite(Ib) && C(Ta, 2, le(Math.round(Ib))));
            }
        var my;
        (null == (my = a.getConfig) ? 0 : my.call(a).useBidCache) &&
          tI(Ma, b, pa, c, a);
        return r;
      }
    }
  }
  var AI = function (a) {
    S.call(this);
    var b = this;
    this.G = !1;
    var c = aC(cC(this.getSettings()));
    c && 0 < c.length && (Lj.reset(), Nj(new Rj(c)));
    this.C = new WH();
    this.B = null;
    this.j = a;
    this.H = new Map();
    this.l = this.j.B;
    this.L = new Kx(this);
    In(this, this.L);
    this.W = new mw(window, { timeoutMs: 500 });
    this.Y = new nI(window, { timeoutMs: 500 });
    this.P = new LE();
    OE(this.P);
    a = new hw(window, { timeoutMs: 500 });
    this.U = new lF(a, 500);
    In(this, this.U);
    this.g = null;
    this.J = {};
    0 !== eC.g ? ((this.o = new FG()), In(this, this.o)) : (this.o = GG());
    MC() &&
      (this.o.init(AG(this.l)),
      (this.F = MG(this.o, this.j.C)),
      Hn(this, function () {
        var d = b.F;
        b.o.l.delete(d);
        0 !== eC.g && (I(tr).A[d] = null);
      }));
  };
  v(AI, S);
  AI.prototype.destroy = function () {
    this.X();
  };
  AI.prototype.getVersion = function () {
    return "h.3.637.1";
  };
  AI.prototype.requestAds = function (a, b) {
    var c = this,
      d = [],
      e = null;
    ow(this.W) &&
      d.push(
        new Promise(function (h) {
          rw(c.W, function (k) {
            e = k;
            h();
          });
        })
      );
    var f = null;
    Yv(this.Y.caller) &&
      d.push(
        new Promise(function (h) {
          oI(c.Y, function (k) {
            f = k;
            h();
          });
        })
      );
    var g = null;
    d.push(
      nF(this.U).then(function (h) {
        g = h;
      })
    );
    Promise.all(d).then(function () {
      BI(c, a, b, { Sd: e, Vd: f, od: g });
    });
  };
  var BI = function (a, b, c, d) {
    var e = b.adTagUrl,
      f = "goog_" + Lh++;
    a.H.set(f, c || null);
    var g = CI({ adTagUrl: e, Sd: d.Sd, Vd: d.Vd, od: d.od });
    a.g = iC(e, g || {});
    EE(a.g, function () {
      DI(a);
    });
    c = Promise.resolve();
    M(Ek) &&
      (c = new Promise(function (p) {
        setTimeout(function () {
          p();
        }, 50);
      }));
    var h,
      k =
        null == (h = b.adTagUrl)
          ? void 0
          : h.includes("GOOGLE_INSTREAM_VIDEO_NONCE"),
      n = nC(a.g);
    h = EI(a, n, k);
    d = OE(a.P);
    var m = Promise.resolve(null);
    if (M(Jk) || M(Kk) || M(Lk) || M(Ok)) {
      m = 0;
      M(Jk) ? (m = 50) : M(Kk) || M(Ok) ? (m = 500) : M(Lk) && (m = 5e3);
      var r = fF.getConfig().then(function (p) {
        p && iF(p, null != e ? e : "");
        var t = fF.j;
        t && ((t = t.message), X.getInstance().report(189, { message: t }));
        return p;
      });
      m = Promise.race([r, Ss(m, null)]);
    }
    FI(a);
    Promise.all([c, h, d, m]).then(function (p) {
      var t = u(p);
      t.next();
      t.next();
      p = t.next().value;
      t = t.next().value;
      var w = {};
      X.getInstance().report(
        182,
        ((w.aid = !!eC.B), (w.aidf = !!a.B), (w.hsc = !n && k), w)
      );
      t = GI(a, b, g, p, t);
      w = AG(a.l, f);
      a.L.O(w, "adsLoader", a.Z);
      eD(w, "adsLoader", "requestAds", t);
      t = {};
      X.getInstance().report(
        155,
        ((t.ws = KE()), (t.blob = null != p ? p : "undef"), t)
      );
    });
  };
  AI.prototype.getSettings = function () {
    return eC;
  };
  AI.prototype.contentComplete = function () {
    eD(AG(this.l), "adsLoader", "contentComplete");
  };
  AI.prototype.Z = function (a) {
    var b = a.messageType;
    switch (b) {
      case "adsLoaded":
        var c = a.oa,
          d = a.fc;
        c = new Z(
          this.o,
          this.j,
          c.adTagUrl || "",
          c.adCuePoints,
          this.F,
          c.isCustomClickTrackingAllowed,
          AG(this.l, d),
          this.g
        );
        this.dispatchEvent(new jI(c, HI(this, d)));
        break;
      case "error":
        c = a.oa;
        this.dispatchEvent(new uH(new sH(c), HI(this, a.fc)));
        c = { error: c.errorCode, vis: Vi(document) };
        X.getInstance().report(7, c);
        break;
      case "cookieUpdate":
        a = a.oa;
        if (null == a) break;
        if (eC.isCookiesEnabled()) {
          b = new fC();
          Jf(b, 5, !0);
          var e = a.gfpCookie;
          e && YH(this.C, "__gads", VH(e), b);
          (e = a.gfpCookieV2) && YH(this.C, "__gpi", VH(e), b);
        }
        b = a.eoidCookie;
        if (M(Ok) && b) {
          e = new lu();
          try {
            c = VH(b);
            d = void 0 === d ? !1 : d;
            var f = Gf(c, 2) - Date.now() / 1e3,
              g = {
                Ic: Math.max(f, 0),
                path: E(c, 3),
                domain: E(c, 4),
                Ie: !1,
              };
            if (d) {
              var h = c.getValue(),
                k = e.g;
              "null" !== k.origin && gu(k).set("__eoi", h, g);
            } else gu(e.g).set("__eoi", c.getValue(), g);
          } catch (m) {
            var n;
            X.getInstance().report(
              198,
              {
                action: "write",
                message: null == (n = m) ? void 0 : n.message,
              },
              !0
            );
          }
        }
        II(this, a.encryptedSignalBidderIds || []);
        break;
      case "trackingUrlPinged":
        this.dispatchEvent(new wH(b, null, a.oa));
    }
  };
  var II = function (a, b) {
      0 !== b.length &&
        (b = FE(
          b.map(function (c) {
            return { tc: c };
          }),
          a.g
        )) &&
        b.forEach(function (c) {
          c.then(function (d) {
            d && DI(a);
          });
        });
    },
    DI = function (a) {
      var b = ZD(DE(a.g));
      b &&
        ((a.J.espSignals = b), eD(AG(a.l), "adsLoader", "signalsRefresh", a.J));
    },
    HI = function (a, b) {
      var c = a.H.get(b);
      a.H.delete(b);
      return null != c ? c : null;
    },
    CI = function (a) {
      var b = a.Sd,
        c = a.Vd;
      a = a.od;
      var d,
        e,
        f,
        g,
        h,
        k,
        n = {};
      var m = void 0 === m ? x : m;
      return (
        (n.gfcLoaded = wi(m.top, "googlefcLoaded")),
        (n.addtlConsent =
          null != (d = null == b ? void 0 : b.addtlConsent) ? d : null),
        (n.gdprApplies =
          null != (e = null == b ? void 0 : b.gdprApplies) ? e : null),
        (n.tcString = null != (f = null == b ? void 0 : b.tcString) ? f : null),
        (n.uspString =
          null != (g = null == c ? void 0 : c.uspString) ? g : null),
        (n.gppString =
          null != (h = null == a ? void 0 : a.gppString) ? h : null),
        (n.gppSid = null != (k = null == a ? void 0 : a.sid) ? k : null),
        n
      );
    },
    JI = function (a, b) {
      var c = {};
      c.contentMediaUrl = a.j.N;
      c.customClickTrackingProvided = null != a.j.o;
      c.isAmp = QC();
      a: {
        try {
          var d = window.top.location.href;
        } catch (R) {
          d = 2;
          break a;
        }
        d = null == d ? 2 : d == window.document.location.href ? 0 : 1;
      }
      c.iframeState = d;
      c.imaHostingDomain = window.document.domain;
      c.imaHostingPageUrl = window.document.URL;
      c.topAccessiblePageUrl = PC();
      c.referrer = window.document.referrer;
      c.domLoadTime = a.l.J;
      c.sdkImplLoadTime = a.l.L;
      c.supportsResizing = !oH(a.j);
      d = G().location.ancestorOrigins;
      c.topOrigin = d
        ? 0 < d.length && 200 > d[d.length - 1].length
          ? d[d.length - 1]
          : ""
        : null;
      c.osdId = a.F;
      c.usesCustomVideoPlayback = oH(a.j);
      c.usesProxyMediaElement = pH(a.j);
      c.usesInlinePlayback = a.j.I;
      d = a.j.Uc;
      a = [];
      var e = "",
        f = "";
      if (null != d) {
        e = d;
        f = !0;
        f = void 0 === f ? !1 : f;
        for (var g = [], h = 0; e && 25 > h; ++h) {
          var k = "";
          (void 0 !== f && f) ||
            (k = (k = 9 !== e.nodeType && e.id) ? "/" + k : "");
          a: {
            if (e && e.nodeName && e.parentElement) {
              var n = e.nodeName.toString().toLowerCase();
              for (
                var m = e.parentElement.childNodes, r = 0, p = 0;
                p < m.length;
                ++p
              ) {
                var t = m[p];
                if (t.nodeName && t.nodeName.toString().toLowerCase() === n) {
                  if (e === t) {
                    n = "." + r;
                    break a;
                  }
                  ++r;
                }
              }
            }
            n = "";
          }
          g.push((e.nodeName && e.nodeName.toString().toLowerCase()) + k + n);
          e = e.parentElement;
        }
        e = g.join();
        if (d) {
          d =
            ((d = d.ownerDocument) && (d.defaultView || d.parentWindow)) ||
            null;
          f = [];
          if (d)
            try {
              var w = d.parent;
              for (g = 0; w && w !== d && 25 > g; ++g) {
                var y = w.frames;
                for (h = 0; h < y.length; ++h)
                  if (d === y[h]) {
                    f.push(h);
                    break;
                  }
                d = w;
                w = d.parent;
              }
            } catch (R) {}
          f = f.join();
        } else f = "";
      }
      a.push(e, f);
      if (null != b) {
        for (w = 0; w < Sv.length - 1; ++w) a.push(li(b, Sv[w]) || "");
        b = li(b, "videoad_start_delay");
        w = "";
        b &&
          ((b = parseInt(b, 10)),
          (w = 0 > b ? "postroll" : 0 == b ? "preroll" : "midroll"));
        a.push(w);
      } else for (b = 0; b < Sv.length; ++b) a.push("");
      return (c.videoAdKey = ti(a.join(":")).toString()), c;
    },
    KI = function (a, b, c) {
      a = mC(a);
      b = b.adTagUrl ? VB(b.adTagUrl) : [];
      a: if (c && 0 !== b.length) {
        c = tf(c, Kt, 3);
        b = u(b);
        for (var d = b.next(); !d.done; d = b.next()) {
          d = d.value;
          var e = void 0,
            f = void 0,
            g =
              !!d &&
              (null == (e = c)
                ? void 0
                : null == (f = of(e, 1, xe))
                ? void 0
                : f.get(d));
          X.getInstance().report(196, { status: g, network: d });
          if (!g) {
            c = !0;
            break a;
          }
        }
        c = !1;
      } else c = !0;
      return { Ce: a, De: c };
    },
    LI = function (a, b, c) {
      var d = oC(a);
      b = KI(a, b, c);
      a = b.Ce;
      b = b.De;
      return !ku() || Df(d, 8) || ((a || !Df(d, 5)) && b) ? !1 : !0;
    },
    MI = function (a, b, c) {
      var d = oC(a);
      a = KI(a, b, c);
      b = new lu();
      c = void 0;
      try {
        var e = a.Ce,
          f = a.De;
        var g = void 0 === g ? !1 : g;
        if (Df(d, 8) || ((e || !Df(d, 5)) && f)) c = void 0;
        else if (g) {
          var h;
          c = null != (h = iu("__eoi", b.g)) ? h : void 0;
        } else c = new du(b.g.document).get("__eoi") || "";
      } catch (n) {
        var k;
        X.getInstance().report(
          198,
          { action: "read", message: null == (k = n) ? void 0 : k.message },
          !0
        );
      }
      return c;
    },
    EI = function (a, b, c) {
      if (b) return (a.B = null), Promise.resolve([]);
      b = [];
      b.push(NI());
      c && b.push(OI(a));
      return Promise.all(b);
    },
    OI = function (a) {
      var b;
      return Ha(function (c) {
        if (1 == c.g)
          return a.B || ((a.B = new aD()), bD(a.B)), ya(c, a.B.getId(), 2);
        b = c.j;
        eC.B = b.id || "";
        c.g = 0;
      });
    },
    NI = function () {
      return Fb() && (M(Ik) || M(Hk))
        ? M(Hk)
          ? new Promise(function (a) {
              setTimeout(function () {
                a();
              }, 50);
            })
          : PI().then(function (a) {
              var b,
                c = null != (b = a.label) ? b : "";
              eC.I = c;
              eC.L = a.status;
            })
        : Promise.resolve();
    },
    PI = function () {
      if (navigator.cookieDeprecationLabel) {
        var a = navigator.cookieDeprecationLabel
            .getValue()
            .then(function (c) {
              return { label: c, status: 1 };
            })
            .catch(function () {
              return { label: "", status: 2 };
            }),
          b = new Promise(function (c) {
            setTimeout(function () {
              c({ label: "", status: 5 });
            }, 50);
          });
        return Promise.race([b, a]);
      }
      return Promise.resolve({ label: "", status: 3 });
    },
    GI = function (a, b, c, d, e) {
      var f = {};
      f = ((f.limaExperimentIds = Mj().sort().join(",")), f);
      var g = dC(a.getSettings(), LG(a.o)),
        h = JI(a, b.adTagUrl),
        k = ny(),
        n = {};
      c =
        ((n.consentSettings = c),
        (n.imalibExperiments = f),
        (n.settings = g),
        (n.videoEnvironment = h),
        (n.isFledgeEligible = k),
        n);
      Object.assign(c, QI(b));
      a.g &&
        eC.isCookiesEnabled() &&
        ((f = oC(a.g)),
        (c.isBrowserCookieEnabled = XH(a.C, f)),
        (g = f ? hu("__gads", f, a.C.g) : null),
        null !== g && (c.gfpCookieValue = g),
        (g = f ? hu("__gpi", f, a.C.g) : null),
        null !== g && (c.gfpCookieV2Id = g),
        (f = f ? hu("__gpi_opt_out", f, a.C.g) : null),
        null !== f && (c.gfpCookieV2OptOut = f));
      a.g &&
        M(Ok) &&
        ((f = LI(a.g, b, e)),
        (c.eoidCookieEnabled = f),
        (e = MI(a.g, b, e)) && (c.eoidCookieValue = e));
      if ((e = ZD(DE(a.g)))) (a.J.espSignals = e), (c.espSignals = e);
      d && (c.gmaSignals = d);
      c.isEapLoader = !1;
      if (M(Qk)) {
        a = function (t) {
          X.getInstance().report(195, {
            message: null == t ? void 0 : t.message,
          });
        };
        try {
          var m = pI();
          if (m) {
            var r = WB(b.adTagUrl, a);
            if (r) {
              var p = zI(m, { adUnitCode: r });
              c.clientBidsProto = p ? Ic(p.g(), 3) : void 0;
            }
          }
        } catch (t) {
          a(t);
        }
      }
      return c;
    },
    FI = function (a) {
      var b = G(),
        c,
        d = null == (c = a.g) ? void 0 : nC(c);
      c = b.isSecureContext;
      var e = b.document;
      e = void 0 === e ? b.document : e;
      b = !!(
        c &&
        "sharedStorage" in b &&
        b.sharedStorage &&
        jy("shared-storage", e)
      );
      c = a.G || d || !b;
      M(Mk) &&
        (X.getInstance().report(191, {
          enabled: !c,
          clientAgePingCalled: a.G,
          isIdless: d,
          isSharedStorageEnabled: b,
        }),
        c ||
          ((a.G = !0),
          (d = a.l),
          (a = HC.getInstance().g),
          (d = di(d.g)) && wG(d, a)));
    };
  AI.prototype.contentComplete = AI.prototype.contentComplete;
  AI.prototype.getSettings = AI.prototype.getSettings;
  AI.prototype.requestAds = AI.prototype.requestAds;
  AI.prototype.getVersion = AI.prototype.getVersion;
  AI.prototype.destroy = AI.prototype.destroy;
  var RI = function () {
      this.l = this.j = "unknown";
      this.g = "0";
      this.adsResponse = null;
      this.adTagUrl = "";
      this.contentTitle = this.contentKeywords = this.contentDuration = null;
      this.forceNonLinearFullSlot = !1;
      this.nonLinearAdSlotWidth =
        this.nonLinearAdSlotHeight =
        this.liveStreamPrefetchSeconds =
        this.linearAdSlotWidth =
        this.linearAdSlotHeight =
          0;
      this.omidAccessModeRules = {};
      this.pageUrl = null;
      this.vastLoadTimeout = 5e3;
    },
    QI = function (a) {
      var b = {};
      b.adsResponse = a.adsResponse;
      b.videoPlayActivation = a.j;
      b.videoPlayMuted = a.l;
      b.videoContinuousPlay = a.g;
      b.adTagUrl = a.adTagUrl;
      b.contentDuration = a.contentDuration;
      b.contentKeywords = a.contentKeywords;
      b.contentTitle = a.contentTitle;
      b.linearAdSlotWidth = a.linearAdSlotWidth;
      b.linearAdSlotHeight = a.linearAdSlotHeight;
      b.nonLinearAdSlotWidth = a.nonLinearAdSlotWidth;
      b.nonLinearAdSlotHeight = a.nonLinearAdSlotHeight;
      b.forceNonLinearFullSlot = a.forceNonLinearFullSlot;
      b.liveStreamPrefetchSeconds = a.liveStreamPrefetchSeconds;
      b.vastLoadTimeout = a.vastLoadTimeout;
      b.omidAccessModeRules = a.omidAccessModeRules;
      b.pageUrl = a.pageUrl;
      return b;
    };
  RI.prototype.setAdWillAutoPlay = function (a) {
    this.j = a ? "auto" : "click";
  };
  RI.prototype.setAdWillPlayMuted = function (a) {
    this.l = a ? "muted" : "unmuted";
  };
  RI.prototype.setContinuousPlayback = function (a) {
    this.g = a ? "2" : "1";
  };
  RI.prototype.setContinuousPlayback = RI.prototype.setContinuousPlayback;
  RI.prototype.setAdWillPlayMuted = RI.prototype.setAdWillPlayMuted;
  RI.prototype.setAdWillAutoPlay = RI.prototype.setAdWillAutoPlay;
  z("google.ima.AdCuePoints.POSTROLL", -1, window);
  z("google.ima.AdCuePoints.PREROLL", 0, window);
  z("google.ima.AdDisplayContainer", qH, window);
  z("google.ima.AdError.ErrorCode", U, window);
  z("google.ima.AdError.ErrorCode.VIDEO_ELEMENT_USED", -1, window);
  z("google.ima.AdError.ErrorCode.VIDEO_ELEMENT_REQUIRED", -1, window);
  z("google.ima.AdError.ErrorCode.VAST_MEDIA_ERROR", -1, window);
  z("google.ima.AdError.ErrorCode.ADSLOT_NOT_VISIBLE", -1, window);
  z("google.ima.AdError.ErrorCode.OVERLAY_AD_LOADING_FAILED", -1, window);
  z("google.ima.AdError.ErrorCode.VAST_MALFORMED_RESPONSE", -1, window);
  z("google.ima.AdError.ErrorCode.COMPANION_AD_LOADING_FAILED", -1, window);
  z("google.ima.AdError.Type", rH, window);
  z("google.ima.AdErrorEvent.Type", tH, window);
  z("google.ima.AdEvent.Type", vH, window);
  z("google.ima.AdsLoader", AI, window);
  z("google.ima.AdsManagerLoadedEvent.Type", iI, window);
  z("google.ima.CompanionAdSelectionSettings", jD, window);
  z("google.ima.CompanionAdSelectionSettings.CreativeType", gD);
  z("google.ima.CompanionAdSelectionSettings.ResourceType", hD);
  z("google.ima.CompanionAdSelectionSettings.SizeCriteria", iD);
  z(
    "google.ima.CustomContentLoadedEvent.Type.CUSTOM_CONTENT_LOADED",
    "deprecated-event",
    window
  );
  z("ima.ImaSdkSettings", V, window);
  z("google.ima.settings", eC, window);
  z("google.ima.ImaSdkSettings.CompanionBackfillMode", {
    ALWAYS: "always",
    ON_MASTER_AD: "on_master_ad",
  });
  z("google.ima.ImaSdkSettings.VpaidMode", {
    DISABLED: 0,
    ENABLED: 1,
    INSECURE: 2,
    0: "DISABLED",
    1: "ENABLED",
    2: "INSECURE",
  });
  z("google.ima.AdsRenderingSettings", IF, window);
  z("google.ima.AdsRenderingSettings.AUTO_SCALE", -1, window);
  z("google.ima.AdsRequest", RI, window);
  z("google.ima.VERSION", "3.637.1");
  z("google.ima.OmidAccessMode", {
    LIMITED: "limited",
    DOMAIN: "domain",
    FULL: "full",
  });
  z("google.ima.OmidVerificationVendor", {
    COMSCORE: 7,
    DOUBLEVERIFY: 3,
    GOOGLE: 9,
    INTEGRAL_AD_SCIENCE: 4,
    MEETRICS: 8,
    MOAT: 2,
    NIELSEN: 6,
    PIXELATE: 5,
    OTHER: 1,
    7: "COMSCORE",
    3: "DOUBLEVERIFY",
    9: "GOOGLE",
    4: "INTEGRAL_AD_SCIENCE",
    8: "MEETRICS",
    2: "MOAT",
    6: "NIELSEN",
    5: "PIXELATE",
    1: "OTHER",
  });
  z("google.ima.UiElements", {
    AD_ATTRIBUTION: "adAttribution",
    COUNTDOWN: "countdown",
  });
  z("google.ima.ViewMode", { NORMAL: "normal", FULLSCREEN: "fullscreen" });
  z("google.ima.secureSignals", {
    clearAllCache: function () {
      BD(window.localStorage);
    },
  });
  var SI = function (a, b, c) {
      this.j = c;
      0 === b.length && (b = [[]]);
      this.g = b.map(function (d) {
        d = a.concat(d);
        for (var e = [], f = 0, g = 0; f < d.length; ) {
          var h = d[f++];
          if (128 > h) e[g++] = String.fromCharCode(h);
          else if (191 < h && 224 > h) {
            var k = d[f++];
            e[g++] = String.fromCharCode(((h & 31) << 6) | (k & 63));
          } else if (239 < h && 365 > h) {
            k = d[f++];
            var n = d[f++],
              m = d[f++];
            h =
              (((h & 7) << 18) |
                ((k & 63) << 12) |
                ((n & 63) << 6) |
                (m & 63)) -
              65536;
            e[g++] = String.fromCharCode(55296 + (h >> 10));
            e[g++] = String.fromCharCode(56320 + (h & 1023));
          } else
            (k = d[f++]),
              (n = d[f++]),
              (e[g++] = String.fromCharCode(
                ((h & 15) << 12) | ((k & 63) << 6) | (n & 63)
              ));
        }
        return new RegExp(e.join(""));
      });
    },
    TI = function (a, b) {
      return b
        ? a.g.some(function (c) {
            c = b.match(c);
            return null == c
              ? !1
              : !a.j ||
                (1 <= c.length && "3.637.1" === c[1]) ||
                (2 <= c.length && "3.637.1" === c[2])
              ? !0
              : !1;
          })
        : !1;
    },
    UI = [
      94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 105, 109,
      97, 115, 100, 107, 92, 46, 103, 111, 111, 103, 108, 101, 97, 112, 105,
      115, 92, 46, 99, 111, 109, 47, 106, 115, 47, 40, 115, 100, 107, 108, 111,
      97, 100, 101, 114, 124, 99, 111, 114, 101, 41, 47,
    ],
    VI = [
      94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 115, 48,
      92, 46, 50, 109, 100, 110, 92, 46, 110, 101, 116, 47, 105, 110, 115, 116,
      114, 101, 97, 109, 47, 104, 116, 109, 108, 53, 47,
    ],
    WI = [
      94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 105, 109,
      97, 115, 100, 107, 92, 46, 103, 111, 111, 103, 108, 101, 97, 112, 105,
      115, 92, 46, 99, 111, 109, 47, 112, 97, 108, 47, 115, 100, 107, 108, 111,
      97, 100, 101, 114, 47,
    ],
    XI = [
      [105, 109, 97, 51, 92, 46, 106, 115],
      [105, 109, 97, 51, 95, 100, 101, 98, 117, 103, 92, 46, 106, 115],
      [105, 109, 97, 51, 95, 101, 97, 112, 46, 106, 115],
    ],
    YI = [
      [
        98, 114, 105, 100, 103, 101, 40, 91, 48, 45, 57, 93, 43, 92, 46, 91, 48,
        45, 57, 92, 46, 93, 43, 41, 40, 95, 40, 91, 97, 45, 122, 48, 45, 57, 93,
        41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125, 92, 46, 104, 116,
        109, 108,
      ],
      [
        98, 114, 105, 100, 103, 101, 40, 91, 48, 45, 57, 93, 43, 92, 46, 91, 48,
        45, 57, 92, 46, 93, 43, 41, 95, 100, 101, 98, 117, 103, 40, 95, 40, 91,
        97, 45, 122, 48, 45, 57, 93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44,
        50, 125, 92, 46, 104, 116, 109, 108,
      ],
      [
        98, 114, 105, 100, 103, 101, 40, 95, 40, 91, 97, 45, 122, 48, 45, 57,
        93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125, 92, 46, 104,
        116, 109, 108,
      ],
    ],
    ZI = [
      [111, 117, 116, 115, 116, 114, 101, 97, 109, 92, 46, 106, 115],
      [
        111, 117, 116, 115, 116, 114, 101, 97, 109, 95, 100, 101, 98, 117, 103,
        92, 46, 106, 115,
      ],
    ],
    $I = new SI(UI, XI, !1);
  new SI(UI, YI, !0);
  var aJ = new SI(VI, XI, !1);
  new SI(VI, YI, !0);
  var bJ = new SI(
      [
        94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 105,
        109, 97, 115, 100, 107, 92, 46, 103, 111, 111, 103, 108, 101, 97, 112,
        105, 115, 92, 46, 99, 111, 109, 47, 112, 114, 101, 114, 101, 108, 101,
        97, 115, 101, 47, 106, 115, 47, 91, 48, 45, 57, 93, 43, 46, 91, 48, 45,
        57, 46, 93, 43, 47,
      ],
      XI,
      !1
    ),
    cJ = new SI(
      [
        94, 40, 63, 58, 104, 116, 116, 112, 115, 63, 58, 41, 63, 47, 47, 40,
        112, 97, 103, 101, 97, 100, 50, 124, 116, 112, 99, 41, 92, 46, 103, 111,
        111, 103, 108, 101, 115, 121, 110, 100, 105, 99, 97, 116, 105, 111, 110,
        92, 46, 99, 111, 109, 47, 112, 97, 103, 101, 97, 100, 47, 40, 103, 97,
        100, 103, 101, 116, 115, 124, 106, 115, 41, 47,
      ],
      [],
      !1
    );
  new SI(
    UI,
    [
      [
        100, 97, 105, 95, 105, 102, 114, 97, 109, 101, 40, 91, 48, 45, 57, 93,
        43, 92, 46, 91, 48, 45, 57, 92, 46, 93, 43, 41, 40, 95, 40, 91, 97, 45,
        122, 48, 45, 57, 93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125,
        92, 46, 104, 116, 109, 108,
      ],
      [
        100, 97, 105, 95, 105, 102, 114, 97, 109, 101, 40, 91, 48, 45, 57, 93,
        43, 92, 46, 91, 48, 45, 57, 92, 46, 93, 43, 41, 95, 100, 101, 98, 117,
        103, 40, 95, 40, 91, 97, 45, 122, 48, 45, 57, 93, 41, 123, 50, 44, 51,
        125, 41, 123, 48, 44, 50, 125, 92, 46, 104, 116, 109, 108,
      ],
      [
        100, 97, 105, 95, 105, 102, 114, 97, 109, 101, 40, 95, 40, 91, 97, 45,
        122, 48, 45, 57, 93, 41, 123, 50, 44, 51, 125, 41, 123, 48, 44, 50, 125,
        92, 46, 104, 116, 109, 108,
      ],
    ],
    !0
  );
  var dJ = new SI(UI, ZI, !1),
    eJ = new SI(UI, ZI, !1);
  new SI(WI, [[112, 97, 108, 46, 106, 115]], !1);
  new SI(WI, [[99, 97, 115, 116, 95, 112, 97, 108, 46, 106, 115]], !1);
  new SI(WI, [[99, 116, 118, 95, 112, 97, 108, 46, 106, 115]], !1);
  function fJ(a, b) {
    for (var c = {}, d = 0; d < b.length; c = { Md: void 0 }, d++)
      if (
        ((c.Md = b[d]),
        a.some(
          (function (e) {
            return function (f) {
              return TI(f, e.Md.src);
            };
          })(c)
        ))
      )
        return c.Md;
    return null;
  }
  if (
    !(function (a) {
      if (
        a.some(function (c) {
          return TI(c, G().location.href);
        })
      )
        return !0;
      var b = fJ(
        a,
        document.querySelectorAll && document.querySelector
          ? document.querySelectorAll("SCRIPT")
          : document.getElementsByTagName("SCRIPT")
      );
      null == b &&
        document.querySelectorAll &&
        (b = fJ(a, document.querySelectorAll("script")));
      return null != b;
    })([$I, bJ, aJ, cJ, dJ, eJ])
  )
    throw Error(
      "IMA SDK is either not loaded from a google domain or is not a supported version."
    );
  if (M(Jk) || M(Kk) || M(Lk) || M(Ok)) {
    var bF = fF,
      hF = { pageUrl: PC() },
      cF = gF();
    if (cF)
      try {
        eF();
      } catch (a) {
        dF(bF, a);
      }
    else dF(bF, Error("Could not generate config URL"));
  }
})();
