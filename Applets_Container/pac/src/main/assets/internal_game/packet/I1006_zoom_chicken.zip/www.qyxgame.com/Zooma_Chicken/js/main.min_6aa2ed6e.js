function getOrCreateInst(t) {
    var e = t;
    return null == e.__inst && (e.__inst = new t), e.__inst
}

function singleton(t) {
    Object.defineProperty(t, "Instance", {
        get: function() {
            return getOrCreateInst(t)
        },
        enumerable: !0,
        configurable: !0
    })
}

function applyMixins(t, e) {
    e.forEach(function(e) {
        Object.getOwnPropertyNames(e.prototype).forEach(function(i) {
            0 != i.indexOf("__") && "constructor" != i && (t.prototype[i] = e.prototype[i])
        })
    })
}

function isFirstType(t, e) {
    return e(t)
}

function asType(t, e) {
    return e(t)
}

function p2v(t) {
    return {
        u: t.x,
        v: t.y
    }
}

function vNormalize(t) {
    var e = Math.sqrt(t.u * t.u + t.v * t.v);
    return {
        u: t.u / e,
        v: t.v / e
    }
}

function vAdd(t, e) {
    return {
        u: t.u + e.u,
        v: t.v + e.v
    }
}

function vSub(t, e) {
    return {
        u: t.u - e.u,
        v: t.v - e.v
    }
}

function vMul(t, e) {
    return {
        u: t.u * e.u,
        v: t.v * e.v
    }
}

function gRound(t) {
    t.x = Math.round(t.x), t.y = Math.round(t.y), t.width = Math.round(t.width), t.height = Math.round(t.height)
}

function cloneRect(t) {
    return {
        x: t.x,
        y: t.y,
        width: t.width,
        height: t.height
    }
}

function asignRect(t, e) {
    return e.x = t.x, e.y = t.y, e.width = t.width, e.height = t.height, e
}
var __reflect = this && this.__reflect || function(t, e, i) {
        t.__class__ = e, i ? i.push(e) : i = [e], t.__types__ = t.__types__ ? i.concat(t.__types__) : i
    },
    __extends = this && this.__extends || function(t, e) {
        function i() {
            this.constructor = t
        }
        for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
        i.prototype = e.prototype, t.prototype = new i
    },
    __decorate = this && this.__decorate || function(t, e, i, n) {
        var a, o = arguments.length,
            s = 3 > o ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(t, e, i, n);
        else
            for (var r = t.length - 1; r >= 0; r--)(a = t[r]) && (s = (3 > o ? a(s) : o > 3 ? a(e, i, s) : a(e, i)) || s);
        return o > 3 && s && Object.defineProperty(e, i, s), s
    },
    __awaiter = this && this.__awaiter || function(t, e, i, n) {
        return new(i || (i = Promise))(function(a, o) {
            function s(t) {
                try {
                    h(n.next(t))
                } catch (e) {
                    o(e)
                }
            }

            function r(t) {
                try {
                    h(n["throw"](t))
                } catch (e) {
                    o(e)
                }
            }

            function h(t) {
                t.done ? a(t.value) : new i(function(e) {
                    e(t.value)
                }).then(s, r)
            }
            h((n = n.apply(t, e || [])).next())
        })
    },
    __generator = this && this.__generator || function(t, e) {
        function i(t) {
            return function(e) {
                return n([t, e])
            }
        }

        function n(i) {
            if (a) throw new TypeError("Generator is already executing.");
            for (; h;) try {
                if (a = 1, o && (s = o[2 & i[0] ? "return" : i[0] ? "throw" : "next"]) && !(s = s.call(o, i[1])).done) return s;
                switch (o = 0, s && (i = [0, s.value]), i[0]) {
                    case 0:
                    case 1:
                        s = i;
                        break;
                    case 4:
                        return h.label++, {
                            value: i[1],
                            done: !1
                        };
                    case 5:
                        h.label++, o = i[1], i = [0];
                        continue;
                    case 7:
                        i = h.ops.pop(), h.trys.pop();
                        continue;
                    default:
                        if (s = h.trys, !(s = s.length > 0 && s[s.length - 1]) && (6 === i[0] || 2 === i[0])) {
                            h = 0;
                            continue
                        }
                        if (3 === i[0] && (!s || i[1] > s[0] && i[1] < s[3])) {
                            h.label = i[1];
                            break
                        }
                        if (6 === i[0] && h.label < s[1]) {
                            h.label = s[1], s = i;
                            break
                        }
                        if (s && h.label < s[2]) {
                            h.label = s[2], h.ops.push(i);
                            break
                        }
                        s[2] && h.ops.pop(), h.trys.pop();
                        continue
                }
                i = e.call(t, h)
            } catch (n) {
                i = [6, n], o = 0
            } finally {
                a = s = 0
            }
            if (5 & i[0]) throw i[1];
            return {
                value: i[0] ? i[1] : void 0,
                done: !0
            }
        }
        var a, o, s, r, h = {
            label: 0,
            sent: function() {
                if (1 & s[0]) throw s[1];
                return s[1]
            },
            trys: [],
            ops: []
        };
        return r = {
            next: i(0),
            "throw": i(1),
            "return": i(2)
        }, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
            return this
        }), r
    },
    Core;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this) || this;
            if (i._active = !1, i._active = !0, i.skinName = t, null == i.skinName) throw new Error(t.name);
            return i._skinResName = i.skinName.name, i
        }
        return __extends(i, e), i.prototype.destroy = function() {
            this._active && (App.CallbackMappingCenter.unRegisterByThisObj(this), App.MessageCenter.removeByThisObj(this), this.skinName = null, this._skinResName = null, this._active = !1, App.MessageCenter.dispatch(t.AppMessageType.EUI_VIEW_DESTROY, this))
        }, i.prototype.childrenCreated = function() {
            e.prototype.childrenCreated.call(this), App.Display.moveToStageCenter(this), App.MessageCenter.dispatch(t.AppMessageType.EUI_VIEW_READY, this)
        }, i.prototype.callbackProccessor = function(t, e) {
            void 0 === e && (e = null), App.CallbackMappingCenter.doCallback(this, t, e)
        }, i.prototype.bindingCallbackProccessWith = function(t) {
            App.CallbackMappingCenter.register(this.callbackProccessor, this, t)
        }, Object.defineProperty(i.prototype, "skinResName", {
            get: function() {
                return this._skinResName
            },
            enumerable: !0,
            configurable: !0
        }), i
    }(eui.Component);
    t.ZmBaseEuiView = e, __reflect(e.prototype, "Core.ZmBaseEuiView")
}(Core || (Core = {})), eui.Component.prototype.getUICoord = function(t, e) {
    e ? t.localToGlobal(0, 0, e) : e = t.localToGlobal(0, 0);
    var i = e.x,
        n = e.y;
    return this.localToGlobal(0, 0, e), e.x = i - e.x, e.y = n - e.y, e
};
var Core;
! function(t) {
    var e = function(e) {
        function i(t, i, n) {
            void 0 === i && (i = !0), void 0 === n && (n = 0);
            var a = e.call(this, t) || this;
            return a._isModal = i, a._bgMask = null, a._showTransitionType = n, a
        }
        return __extends(i, e), i.prototype.destroy = function() {
            this._active && (egret.Tween.removeTweens(this), App.MessageCenter.removeListener(t.AppMessageType.CLIENT_RESIZE, this.lockViewWithinWindow, this), this.btnClose && this.btnClose.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtnCloseTap, this), this.hideBgMask(), this.btnClose = null, e.prototype.destroy.call(this))
        }, i.prototype.init = function(t) {}, i.prototype.childrenCreated = function() {
            this.btnClose && this.btnClose.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtnCloseTap, this), this._isModal && this.parent && this.showBgMask(), e.prototype.childrenCreated.call(this), this.doTransition()
        }, i.prototype.doTransition = function() {
            switch (this._showTransitionType) {
                case 1:
                    var t = this.y;
                    this.alpha = 0, this.y += 100, egret.Tween.get(this).to({
                        alpha: 1,
                        y: t
                    }, 600, egret.Ease.backInOut).call(this.onViewStay, this);
                    break;
                case 0:
                    this.onViewStay()
            }
        }, i.prototype.onViewStay = function() {}, i.prototype.showBgMask = function() {
            null == this._bgMask && (this._bgMask = new t.Views.BgMask(this.parent, !0, .8), this._bgMask.show(this.parent.getChildIndex(this)))
        }, i.prototype.hideBgMask = function() {
            this._bgMask && (this._bgMask.destroy(), this._bgMask = null)
        }, i.prototype.onBtnCloseTap = function(e) {
            App.MessageCenter.dispatch(t.AppMessageType.CLOSE_EUI_VIEW, this)
        }, i.prototype.lockViewWithinWindow = function() {
            if (this.parent) {
                var t = App.LayoutSyncManager.clientWidth,
                    e = App.LayoutSyncManager.clientHeight;
                if (t < this.width || e < this.height) {
                    var i = Math.min(t / this.width, e / this.height);
                    this.scaleX = this.scaleY = i, this.x = App.LayoutSyncManager.clientLeft + (t - this.width * i) / 2, this.y = App.LayoutSyncManager.clientTop + (e - this.height * i) / 2
                }
            }
        }, Object.defineProperty(i.prototype, "visible", {
            get: function() {
                return this.visible
            },
            set: function(t) {
                e.prototype.$setVisible.call(this, t), this._bgMask && (this._bgMask.visible = t)
            },
            enumerable: !0,
            configurable: !0
        }), i.prototype.close = function() {
            App.MessageCenter.dispatch(t.AppMessageType.CLOSE_EUI_VIEW, this)
        }, i
    }(t.ZmBaseEuiView);
    t.ZmBaseEuiWindow = e, __reflect(e.prototype, "Core.ZmBaseEuiWindow")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {
            this._keyList = [], this._valueList = []
        }
        return t.prototype.clear = function() {
            this._keyList.length > 0 && this._keyList.splice(0, this._keyList.length), this._valueList.length > 0 && this._valueList.splice(0, this._valueList.length)
        }, t.prototype.getValue = function(t) {
            var e = this._keyList.indexOf(t);
            return e >= 0 ? this._valueList[e] : null
        }, t.prototype.getKey = function(t) {
            var e = this._valueList.indexOf(t);
            return e >= 0 ? this._keyList[e] : null
        }, t.prototype.has = function(t) {
            var e = this._keyList.indexOf(t);
            return e >= 0 ? !0 : !1
        }, t.prototype.add = function(t, e, i) {
            void 0 === i && (i = !1), null != t && (this.remove(t), i ? (this._keyList.unshift(t), this._valueList.unshift(e)) : (this._keyList.push(t), this._valueList.push(e)))
        }, t.prototype.remove = function(t) {
            var e = this._keyList.indexOf(t);
            if (e >= 0) {
                this._keyList.splice(e, 1);
                var i = this._valueList.splice(e, 1)[0];
                return i
            }
            return null
        }, Object.defineProperty(t.prototype, "length", {
            get: function() {
                return this._keyList.length
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "keyList", {
            get: function() {
                return this._keyList
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "valueList", {
            get: function() {
                return this._valueList
            },
            enumerable: !0,
            configurable: !0
        }), t
    }();
    t.ZmHashMap = e, __reflect(e.prototype, "Core.ZmHashMap")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {
            this._resMap = new t.ZmHashMap
        }
        return e.prototype.getRes = function(t) {
            var e = this._resMap.getValue(t);
            return null == e && (e = RES.getRes(t), e && this._resMap.add(t, e)), e
        }, e.prototype.clear = function() {
            this._resMap.clear(), this._resMap = null
        }, e
    }();
    t.ZmResPool = e, __reflect(e.prototype, "Core.ZmResPool")
}(Core || (Core = {}));
var DebugPlatform = function() {
    function t() {}
    return t.prototype.getSystemInfoSync = function() {
        return {
            platform: "debug",
            windowWidth: 640,
            windowHeight: 1136,
            pixelRatio: 1
        }
    }, t.prototype.showModal = function(t, e, i) {
        return new Promise(function(t, e) {
            t(!0)
        })
    }, t.prototype.showToast = function(t) {}, t.prototype.authorize = function(t) {
        return new Promise(function(t, e) {
            t(!0)
        })
    }, t.prototype.openSetting = function() {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.getUserInfo = function(t) {
        return new Promise(function(t, e) {
            t({
                errMsg: "getUserInfo:ok",
                userInfo: {
                    nickName: "Mock",
                    avatarUrl: "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTI0zqKXaRf5oxpM3Av4Y4RHiaQNSc50wssofibzsKxhjADZks2uLPRXk8bJSzlf56uRALXupScDnyYw/0"
                }
            })
        })
    }, t.prototype.login = function() {
        return new Promise(function(t, e) {
            t({
                code: "MockCode"
            })
        })
    }, t.prototype.checkSession = function() {
        return new Promise(function(t, e) {
            t(!0)
        })
    }, t.prototype.setUserCloudStorage = function(t) {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.shareAppMessage = function(t, e, i, n) {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.showShareMenu = function() {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.getLaunchOptionsSync = function() {
        return {}
    }, t.prototype.onShow = function(t) {}, t.prototype.offShow = function(t) {}, t.prototype.onHide = function(t) {}, t.prototype.offHide = function(t) {}, t.prototype.getOpenDataContext = function() {}, t.prototype.createInnerAudioContext = function() {}, t.prototype.connectSocket = function(t) {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.closeSocket = function() {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.sendSocketMessage = function(t) {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.onSocketOpen = function(t) {}, t.prototype.onSocketClose = function(t) {}, t.prototype.onSocketError = function(t) {}, t.prototype.onSocketMessage = function(t) {}, t.prototype.triggerGC = function() {}, t.prototype.request = function(t, e, i) {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.onShareAppMsg = function(t, e) {}, t.prototype.clearStorage = function() {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.removeStorage = function(t) {
        return new Promise(function(t, e) {
            t()
        })
    }, t.prototype.getStorage = function(t) {
        return new Promise(function(t, e) {
            t("")
        })
    }, t.prototype.setStorage = function(t, e) {
        return new Promise(function(t, e) {
            t(!1)
        })
    }, t.prototype.createUserInfoButton = function(t, e, i, n) {}, t.prototype.previewImage = function(t, e) {
        void 0 === e && (e = "")
    }, t.prototype.createRewardedVideoAd = function(t) {}, t.prototype.playRewardedVideoAd = function(t) {}, t.prototype.addRewardedVideoClose = function(t, e) {}, t.prototype.addRewardedVideoError = function(t, e) {}, t.prototype.removeRewardedVideoClose = function(t, e) {}, t.prototype.removeRewardedVideoError = function(t, e) {}, t.prototype.createBannerAd = function(t, e) {}, t.prototype.navigateToMiniProgram = function(t, e) {}, t.prototype.createFeedbackButton2 = function(t, e, i, n) {}, t.prototype.saveCanvasToTempFilePath = function(t) {
        return new Promise(function(t, e) {
            t()
        })
    }, t
}();
__reflect(DebugPlatform.prototype, "DebugPlatform", ["Platform"]), window.platform || (window.platform = new DebugPlatform), window.wx || (window.wx = {}), window.GameStatusInfo || (window.GameStatusInfo = null), window.BK || (window.BK = null);
var PlatType;
! function(t) {
    t[t.windows = 0] = "windows", t[t.wx = 1] = "wx", t[t.limi = 2] = "limi"
}(PlatType || (PlatType = {}));
var gamePlat;
gamePlat = null != wx.getOpenDataContext ? PlatType.wx : GameStatusInfo ? PlatType.limi : PlatType.windows;
var IsWxPlat = null != wx.getOpenDataContext,
    Views;
! function(t) {
    var e;
    ! function(t) {
        t[t.diamond = 0] = "diamond", t[t.bomb = 1] = "bomb", t[t.heidong = 2] = "heidong", t[t.suipian = 3] = "suipian", t[t.chest = 4] = "chest"
    }(e = t.WupinType || (t.WupinType = {}));
    var i = function() {
        function t() {}
        return t
    }();
    t.WupinData = i, __reflect(i.prototype, "Views.WupinData");
    var n = function(i) {
        function n(t) {
            var e = i.call(this, HuodeWupinSkin, t) || this;
            return e.score = 0, e.width = App.LayerManager.stage.stageWidth, e.height = App.LayerManager.stage.stageHeight, e.addEventListener(egret.TouchEvent.TOUCH_TAP, function() {
                e.data.cb && e.data.cb.apply(e.data.cbObj), e.close()
            }, e), e
        }
        return __extends(n, i), n.huoqu = function(i) {
            i.wpType == e.chest ? App.WindowViewManager.showWin(t.GameChest) : App.WindowViewManager.showWithData(t.HuodeWupin, i)
        }, n.prototype.init = function(i) {
            if (null != i) {
                this.data = i;
                for (var n = 0; 4 > n; n++) this["imgWupin" + (n + 1)].visible = n == i.wpType;
                if (this.txtNum.text = "+" + i.num, null == App.WindowViewManager.getWindowInstance(t.ZmHomePage) && "chest" == i.from) {
                    this.grpScore.visible = !0;
                    var a = LevelData.getData(ZmData.Instance.getPassLevel());
                    this.score = Math.ceil(Util.random(4, 8) * a.passScore / 100), this.txtScore.text = this.score.toString()
                }
                i.wpType == e.diamond ? ZmData.Instance.addDiamond(i.num) : i.wpType == e.bomb ? ZmData.Instance.gainBomb(i.num) : i.wpType == e.heidong ? ZmData.Instance.gainHeidong(i.num) : i.wpType == e.suipian && ZmData.Instance.setSuipianCnt(ZmData.Instance.getSvrData().suipianCnt + i.num), Util.playAnim(this.anim1, !0)
            }
        }, n.prototype.destroy = function() {
            this.anim1.stop(), this.score > 0 && t.ZmPlayScene.ins.huodeScore(this.score)
        }, n
    }(Core.ZmBaseEuiWindow);
    t.HuodeWupin = n, __reflect(n.prototype, "Views.HuodeWupin")
}(Views || (Views = {}));
var ZmMessageType = function() {
    function t() {}
    return t.START_GAME = "start_game", t.LUANCH_CHALLENGE = "luanch_challenge", t.DATA_READY = "data_ready", t.SVRCFG_ONLOAD = "svrCfg_onLoad", t.DATA_BOMB_CHANGED = "data_bomb_changed", t.DATA_HEIDONG_CHANGED = "data_heidong_changed", t.DATA_SKIN_CHANGED = "data_skin_changed", t.DATA_MEDICALKITCNT_CHANGED = "data_medicalKitCnt_changed", t.DATA_DIAMOND_CHANGED = "data_diamond_changed", t.DATA_YAOSHI_CHANGED = "data_yaoshi_changed", t.DATA_SUIPIANCNT_CHANGED = "data_suipianCnt_changed", t.DATA_MONEY_CHANGED = "data_money_changed", t.DATA_TILI_CHANGED = "data_tili_changed", t.RELIVE = "relive", t.USEPROP = "useProp", t.USERGUID_COMPLETE = "userGuidComplete", t.REWARDVIDEOTIP_CLOSE = "RewardVideoTip_close", t.SDK_INIT = "sdk_init", t.SHOW_ANIAD = "show_aniad", t
}();
__reflect(ZmMessageType.prototype, "ZmMessageType");
var Core;
! function(t) {
    var e = function() {
        function t(t, e) {
            this._delegateMethod = t, this._theObj = e
        }
        return t.prototype.run = function() {
            for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
            t ? this._delegateMethod.apply(this._theObj, t) : this._delegateMethod.apply(this._theObj)
        }, t
    }();
    t.Delegate = e, __reflect(e.prototype, "Core.Delegate")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.PoolCreate = function(t) {
            return ZmSeqFrameAnimatPlayer.Instance.create(t)
        }, t
    }();
    t.Effect = e, __reflect(e.prototype, "Core.Effect")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.prototype.onPickUp = function() {
            for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e]
        }, t.prototype.onPutDown = function() {}, t
    }();
    t.IPoolableObj = e, __reflect(e.prototype, "Core.IPoolableObj");
    var i = function() {
        function t() {
            this._classList = []
        }
        return t.prototype.pickUp = function(t) {
            for (var e = [], i = 1; i < arguments.length; i++) e[i - 1] = arguments[i];
            var n = t.__objPool;
            n || (n = new Utility.ZmHandyArray(10, !0), t.__objPool = n, this._classList.push(t));
            var a = void 0;
            return n.length > 0 && (a = n.pop()), a || (a = new t), "function" == typeof a.onPickUp && a.onPickUp.apply(a, e), a
        }, t.prototype.putDown = function(t) {
            var e = t.constructor;
            if (e) {
                var i = e.__objPool;
                i || (i = new Utility.ZmHandyArray(10, !0), e.__objPool = i, this._classList.push(e)), asType(t, function(t) {
                    return void 0 != t.onPutDown
                }) && t.onPutDown(), i.push(t)
            }
        }, t.prototype.clear = function() {
            for (var t = 0; t < this._classList.length; t++) {
                var e = this._classList[t],
                    i = e.__objPool;
                i && i.reset()
            }
        }, t = __decorate([singleton], t)
    }();
    t.ZmObjectPool = i, __reflect(i.prototype, "Core.ZmObjectPool");
    var n = function() {
        function t() {
            this._cache = new Utility.ZmDictionary
        }
        return t.prototype.getObj = function(t) {
            var e = this._cache.get(t);
            return e
        }, t.prototype.cacheObj = function(t, e) {
            this._cache.add(t, e)
        }, t = __decorate([singleton], t)
    }();
    t.NamedCache = n, __reflect(n.prototype, "Core.NamedCache");
    var a = function() {
        function t() {
            this._pool = new Utility.ZmDictionary
        }
        return t.prototype.pickUp = function(t, e) {
            void 0 === e && (e = null);
            for (var i = [], n = 2; n < arguments.length; n++) i[n - 2] = arguments[n];
            var a = this._pool.get(t);
            a || (a = new Utility.ZmHandyArray(10, !0), this._pool.add(t, a));
            var o = void 0;
            if (a.length > 0 && (o = a.pop()), !o) {
                if (!e) return null;
                o = new e, o.__pool_key__ = t
            }
            return "function" == typeof o.onPickUp && o.onPickUp.apply(o, i), o
        }, t.prototype.putDown = function(t, e) {
            if (void 0 === e && (e = null), e && "" != e || (e = t.__pool_key__), e && "" != e) {
                var i = this._pool.get(e);
                i || (i = new Utility.ZmHandyArray(10, !0), this._pool.add(e, i)), asType(t, function(t) {
                    return void 0 != t.onPutDown
                }) && t.onPutDown(), i.push(t)
            }
        }, t.prototype.clear = function() {
            for (var t = this._pool.keys, e = 0; e < t.length; e++) {
                var i = this._pool.get(t[e]);
                i && i.reset()
            }
        }, t = __decorate([singleton], t)
    }();
    t.NamedObjectPool = a, __reflect(a.prototype, "Core.NamedObjectPool")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {
            this.objDics = new Utility.ZmDictionary
        }
        return e.getObj = function(t, i) {
            void 0 === i && (i = "0");
            for (var n = [], a = 2; a < arguments.length; a++) n[a - 2] = arguments[a];
            return n && 0 != n.length ? e.getPool(t).getObj(i, n) : e.getPool(t).getObj(i)
        }, e.delObj = function(t, i) {
            return e.getPool(t).delObj(i)
        }, e.getPool = function(t) {
            var i;
            return e.poolMap.has(t) ? i = e.poolMap.getValue(t) : (i = new e, i.t = t, e.poolMap.add(t, i)), i
        }, e.prototype.getObj = function(t) {
            void 0 === t && (t = "0");
            for (var e = [], i = 1; i < arguments.length; i++) e[i - 1] = arguments[i];
            (null == t || "" == t) && (t = "0");
            var n = this.objDics.get(t);
            n || (n = new Utility.ZmHandyArray(10, !0), this.objDics.add(t, n));
            var a = null;
            return n.length > 0 && (a = n.pop()), a || (null != this.t.PoolCreate ? a = this.t.PoolCreate(e) : null != this.t.constructor && (a = e && 0 != e.length ? new this.t(e) : new this.t), null != a && (a.__pool_key__ = t)), a
        }, e.prototype.delObj = function(t) {
            var e = t.__pool_key__;
            if (e && "" != e) {
                var i = this.objDics.get(e);
                null != i && i.push(t)
            }
        }, e.prototype.clear = function() {
            for (var t = this.objDics.keys, e = 0; e < t.length; e++) {
                var i = this.objDics.get(t[e]);
                i && i.reset()
            }
        }, e.poolMap = new t.ZmHashMap, e
    }();
    t.ObjPool = e, __reflect(e.prototype, "Core.ObjPool")
}(Core || (Core = {}));
var App = function() {
    function t() {}
    return t.getConfig = function(t) {
        return RES.getRes(t)
    }, Object.defineProperty(t, "NamedObjectPool", {
        get: function() {
            return Core.NamedObjectPool.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "NamedCache", {
        get: function() {
            return Core.NamedCache.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "ObjectPool", {
        get: function() {
            return Core.ZmObjectPool.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "DisplayUtilMod", {
        get: function() {
            return Core.DisplayUtilMod.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "MessageCenter", {
        get: function() {
            return Core.MessageCenter.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "CallbackMappingCenter", {
        get: function() {
            return Core.CallbackMappingCenter.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "GlobalRepeatTigger", {
        get: function() {
            return Core.GlobalRepeatTigger.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "Display", {
        get: function() {
            return Core.DisplayUtilMod.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "Dialog", {
        get: function() {
            return Core.DialogMod.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "LayerManager", {
        get: function() {
            return Core.LayerManager.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "LayoutSyncManager", {
        get: function() {
            return Core.LayoutSyncManager.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "SceneViewManager", {
        get: function() {
            return Core.SceneViewManager.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "WindowViewManager", {
        get: function() {
            return Core.WindowViewManager.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "Device", {
        get: function() {
            return Core.DeviceMod.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "Tool", {
        get: function() {
            return Core.ToolMod.Instance
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "LoopLoading", {
        get: function() {
            return t._loopLoading
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "FullLoading", {
        get: function() {
            return t._fullLoading
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t, "LocalStorageData", {
        get: function() {
            return Core.LocalStorageData.Instance
        },
        enumerable: !0,
        configurable: !0
    }), t.init = function() {
        t.SetupMessageProxy(), t.SceneViewManager.init(t.LayerManager.sceneLayer), t.WindowViewManager.init(t.LayerManager.uiLayer, t.LayerManager.sceneLayer)
    }, t.SetupLoading = function(e, i) {
        e && (t._fullLoading && t._fullLoading.destroy(), t._fullLoading = e), i && (t._loopLoading && t._loopLoading.destroy(), t._loopLoading = i)
    }, t.SetupMessageProxy = function() {
        t.MessageCenter.addListener(Core.AppMessageType.CLOSE_EUI_VIEW, function(e) {
            t.WindowViewManager.close(e)
        }, this), RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, function(t) {
            Log.trace("资源包加载完成 " + t.groupName)
        }, this), RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, function(t) {
            Log.trace("！资源包加载失败 " + t.groupName)
        }, this), RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, function(t) {
            Log.trace("！加载资源失败：" + t.resItem.url)
        }, this)
    }, t
}();
__reflect(App.prototype, "App");
var AppConfig = function() {
    function t() {}
    return t.isDebug = !1, t.traceHttp = !0, t.traceHttpUrl = !1, t
}();
__reflect(AppConfig.prototype, "AppConfig");
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.SKIN_PATH = "resource/skins/", t
    }();
    t.AppConst = e, __reflect(e.prototype, "Core.AppConst")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.APP_START = "app_start", t.APP_HIDE = "app_hide", t.APP_RESUME = "app_resume", t.CLIENT_RESIZE = "app_client_resize", t.EUI_VIEW_READY = "app_eui_view_ready", t.EUI_VIEW_DESTROY = "app_eui_view_destroy", t.CLOSE_EUI_VIEW = "app_close_eui_view", t
    }();
    t.AppMessageType = e, __reflect(e.prototype, "Core.AppMessageType")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.LOGIN_NAME = "login_name", t.LOGIN_PASSWORD = "login_password", t.LOGIN_CRYPT = "login_crypt", t.SOUND_FX_ENABLE = "sound_fx_enable", t.SOUND_BG_ENABLE = "sound_bg_enable", t.SOUND_FX_VOLUME = "sound_fx_volume", t.SOUND_BG_VOLUME = "sound_bg_volume", t.SHOW_SYS_MESSAGE = "show_sys_message", t.DEFAULT_VALUE = {
            sound_fx_enable: "true",
            sound_bg_enable: "true",
            sound_fx_volume: "50",
            sound_bg_volume: "50",
            mobile_bound: "false",
            show_sys_message: "true"
        }, t
    }();
    t.LocalStorageType = e, __reflect(e.prototype, "Core.LocalStorageType")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.SOCKET_OPEN = "SOCKET_OPEN", t.SOCKET_RECONNECT = "SOCKET_RECONNECT", t.SOCKET_CLOSE = "SOCKET_CLOSE", t.SOCKET_DATA = "SOCKET_DATA", t.SOCKET_IOERROR = "SOCKET_IOERROR", t.SOCKET_DEBUG_INFO = "SOCKET_DEBUG_INFO", t
    }();
    t.SocketEventType = e, __reflect(e.prototype, "Core.SocketEventType")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {
            this._callbackFunctionList = [], this._callbackThisList = [], this._vClassList = []
        }
        return t.prototype.register = function(t, e, i) {
            this._callbackFunctionList.push(t), this._callbackThisList.push(e), this._vClassList.push(i)
        }, t.prototype.unRegister = function(t) {
            for (var e = this._callbackFunctionList.length - 1; e >= 0; e--) this._callbackFunctionList[e] == t && (this._callbackFunctionList.splice(e, 1), this._callbackThisList.splice(e, 1), this._vClassList.splice(e, 1))
        }, t.prototype.unRegisterByThisObj = function(t) {
            for (var e = this._callbackThisList.length - 1; e >= 0; e--) this._callbackThisList[e] == t && (this._callbackFunctionList.splice(e, 1), this._callbackThisList.splice(e, 1), this._vClassList.splice(e, 1))
        }, t.prototype.doCallback = function(t, e, i) {
            void 0 === i && (i = null);
            var n = App.CallbackMappingCenter.getCallFunctionList(t);
            if (n.length > 0)
                for (var a, o, s = 0; s < n.length; s++) a = n[s], o = App.CallbackMappingCenter.getCallFunctionThis(t, a), null != a && null != o && a.call(o, e, i)
        }, t.prototype.getCallFunctionList = function(t) {
            for (var e = [], i = 0; i < this._vClassList.length; i++) t instanceof this._vClassList[i] && e.push(this._callbackFunctionList[i]);
            return e
        }, t.prototype.getCallFunctionThis = function(t, e) {
            for (var i = 0; i < this._vClassList.length; i++)
                if (this._callbackFunctionList[i] == e && t instanceof this._vClassList[i]) return this._callbackThisList[i];
            return null
        }, t = __decorate([singleton], t)
    }();
    t.CallbackMappingCenter = e, __reflect(e.prototype, "Core.CallbackMappingCenter")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return Object.defineProperty(t.prototype, "isWeiXin", {
            get: function() {
                return navigator.userAgent.toLowerCase().indexOf("micromessenger") >= 0
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsHtml5", {
            get: function() {
                return egret.Capabilities.runtimeType == egret.RuntimeType.WEB
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsNative", {
            get: function() {
                return egret.Capabilities.runtimeType == egret.RuntimeType.NATIVE
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsMobile", {
            get: function() {
                return egret.Capabilities.isMobile
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsPC", {
            get: function() {
                return !egret.Capabilities.isMobile
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsQQBrowser", {
            get: function() {
                return this.IsHtml5 && -1 != navigator.userAgent.indexOf("MQQBrowser")
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsIEBrowser", {
            get: function() {
                return this.IsHtml5 && -1 != navigator.userAgent.indexOf("MSIE")
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsFirefoxBrowser", {
            get: function() {
                return this.IsHtml5 && -1 != navigator.userAgent.indexOf("Firefox")
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsChromeBrowser", {
            get: function() {
                return this.IsHtml5 && navigator.userAgent.indexOf("Chrome") >= 0 && navigator.userAgent.indexOf("Safari") < 0
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsSafariBrowser", {
            get: function() {
                return this.IsHtml5 && navigator.userAgent.indexOf("Safari") >= 0 && navigator.userAgent.indexOf("Chrome") < 0
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "IsOperaBrowser", {
            get: function() {
                return this.IsHtml5 && -1 != navigator.userAgent.indexOf("Opera")
            },
            enumerable: !0,
            configurable: !0
        }), t = __decorate([singleton], t)
    }();
    t.DeviceMod = e, __reflect(e.prototype, "Core.DeviceMod")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {}
        return e.prototype.removeFromParent = function(t, e) {
            void 0 === e && (e = !1), t && t.parent && (t.parent && t.parent.removeChild(t), e && (t.scaleX = t.scaleY = t.rotation = t.skewY = t.skewY = 0, t.alpha = 1))
        }, e.prototype.clearDisplayContainer = function(t, e, i, n) {
            void 0 === e && (e = !1), void 0 === i && (i = !1), void 0 === n && (n = !1);
            for (var a, o = t.numChildren - 1; o >= 0; o--) a = t.removeChildAt(o), e && a.destroy && a.destroy(), i && (a.texture && (a.texture = null), a.source && (a.source = null), a.text && (a.text = null)), n && a.numChildren && this.clearDisplayContainer(a, i, n)
        }, e.prototype.createBitmap = function(t, e, i, n) {
            void 0 === e && (e = !1), void 0 === i && (i = 0), void 0 === n && (n = 0);
            var a = RES.getRes(t);
            if (!a) return null;
            var o = new egret.Bitmap;
            return o.texture = a, o.name = t, e && (o.anchorOffsetX = o.texture.textureWidth / 2, o.anchorOffsetY = o.texture.textureHeight / 2), 0 != i && (o.x = i), 0 != n && (o.y = n), o
        }, e.prototype.loadBitmapTexture = function(t, e) {
            RES.getResAsync(e, function(e) {
                t.texture = e
            }, null)
        }, e.prototype.loadImageSource = function(t, e) {
            RES.getResAsync(e, function(e) {
                t.source = e
            }, null)
        }, e.prototype.loadImageByUrl = function(t, e) {
            var i = new egret.ImageLoader;
            i.addEventListener(egret.Event.COMPLETE, function(e) {
                var i = new egret.Texture;
                i._setBitmapData(e.currentTarget.data), t.texture && t.texture.dispose(), t.texture = i
            }, this), i.load(e)
        }, e.prototype.addLableStroke = function(t, e, i) {
            t.strokeColor = e, t.stroke = i
        }, e.prototype.addGrayFlilter = function(e) {
            e.filters = [t.DisplayUtilMod.GrayMatrixFilter]
        }, e.prototype.removeGrayFlilter = function(t) {
            t.filters = []
        }, e.prototype.moveToStageCenter = function(t) {
            if (t && t.stage) {
                var e = t.localToGlobal(t.x, t.y),
                    i = (App.LayerManager.stage.stageWidth - e.x - e.x - t.width) / 2,
                    n = (App.LayerManager.stage.stageHeight - e.y - e.y - t.height) / 2;
                t.x += i, t.y += n
            }
        }, e.prototype.pushTop = function(t) {
            if (t) {
                var e = t.parent;
                e && e.setChildIndex(t, e.numChildren)
            }
        }, e.prototype.localToLocal = function(t, e, i, n) {
            for (void 0 === n && (n = !1); t && t.parent;) n ? (i.x += t.x, i.y += t.y) : (i.x += t.x / t.scaleX, i.y += t.y / t.scaleY), t = t.parent;
            for (; e && e.parent;) n ? (i.x -= e.x, i.y -= e.y) : (i.x -= e.x / e.scaleX, i.y -= e.y / e.scaleY), e = e.parent;
            n && (i.x -= App.LayoutSyncManager.clientLeft, i.y -= App.LayoutSyncManager.clientTop)
        }, e.prototype.isChildOf = function(t, e) {
            for (; t;) {
                if (t == e) return !0;
                t = t.parent
            }
            return !1
        }, e.prototype.addAutoScaleEffect = function(t, e) {
            void 0 === e && (e = .01), t && (t.ssSpeed = e * t.scaleX, t.oscaleX = t.scaleX, t.oscaleY = t.scaleY, App.GlobalRepeatTigger.addTime(30, this.updateAutoScale, t))
        }, e.prototype.removeAutoScaleEffect = function(t) {
            t && (App.GlobalRepeatTigger.removeTime(this.updateAutoScale, t), t.scaleX = t.oscaleX, t.scaleY = t.oscaleY, delete t.ssSpeed, delete t.oscaleX, delete t.oscaleY)
        }, e.prototype.updateAutoScale = function() {
            this.scaleX += this.ssSpeed, this.scaleY += this.ssSpeed, (this.scaleX > 1.1 * this.oscaleX || this.scaleX < .9 * this.oscaleX) && (this.ssSpeed = -this.ssSpeed)
        }, e.prototype.addAutoFlashEffect = function(t, e) {
            void 0 === e && (e = .05), t && (t.sfSpeed = e, t.alpha = 1, App.GlobalRepeatTigger.addTime(30, this.updateAutoFlash, t))
        }, e.prototype.removeAutoFlashEffect = function(t) {
            t && (App.GlobalRepeatTigger.removeTime(this.updateAutoFlash, t), t.alpha = 1, delete t.sfSpeed)
        }, e.prototype.updateAutoFlash = function() {
            this.alpha += this.sfSpeed, (this.alpha > 1.1 || this.alpha < -.1) && (this.sfSpeed = -this.sfSpeed)
        }, e.prototype.tweenLabelNumber = function(t, e, i, n, a) {
            if (void 0 === i && (i = .2), void 0 === n && (n = ""), void 0 === a && (a = ""), i > 1 && (i = 1), .01 > i && (i = .01), 1 == i) return void(t.text = n + e + a);
            var o = parseInt(t.text);
            isNaN(o) && (o = 0);
            var s = function() {
                o += (e - o) * i, t.text = n + Math.round(o) + a, Math.abs(e - o) <= 1 && (App.GlobalRepeatTigger.removeFrame(s, t), t.text = n + e + a)
            };
            App.GlobalRepeatTigger.addFrame(s, t)
        }, e.prototype.addButtonPushEffect = function(t, e, i, n, a) {
            void 0 === i && (i = null), void 0 === n && (n = !1), void 0 === a && (a = .9), null != e && (t.pushCallback = e), null != i && (t.pushCallbackThis = i), t.pushEffect = !0, t.isWait = n, t.pushScale = a, t.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBtnPush, this)
        }, e.prototype.removeButtonPushEffect = function(t) {
            delete t.pushCallback, delete t.pushCallbackThis, t.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBtnPush, this)
        }, e.prototype.addButton = function(t, e, i) {
            void 0 === i && (i = null), null != e && (t.pushCallback = e), null != i && (t.pushCallbackThis = i), t.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBtnPush, this)
        }, e.prototype.removeButton = function(t) {
            delete t.pushCallback, delete t.pushCallbackThis, t.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onBtnPush, this)
        }, e.prototype.onBtnPush = function(t) {
            var e = t.currentTarget;
            if (e) {
                ZmSoundManager.Instance.playSound("button");
                var i = e.isWait,
                    n = e.pushEffect;
                if (!n) return void egret.Tween.get(e).wait(150).call(function() {
                    !i && e && e.pushCallback && e.pushCallbackThis && e.pushCallback.call(e.pushCallbackThis, e, t)
                }, this).wait(200).call(function() {
                    i && e && e.pushCallback && e.pushCallbackThis && e.pushCallback.call(e.pushCallbackThis, e, t)
                }, this);
                egret.Tween.get(e).to({
                    scaleX: e.pushScale,
                    scaleY: e.pushScale
                }, 150, egret.Ease.quadIn).call(function() {
                    !i && e && e.pushCallback && e.pushCallbackThis && e.pushCallback.call(e.pushCallbackThis, e, t)
                }, this).to({
                    scaleX: 1,
                    scaleY: 1
                }, 200, egret.Ease.bounceOut).call(function() {
                    i && e && e.pushCallback && e.pushCallbackThis && e.pushCallback.call(e.pushCallbackThis, e, t)
                }, this)
            }
        }, e.prototype.playHeartBeatEffect = function(t, e, i) {
            void 0 === e && (e = 1.2), void 0 === i && (i = 500), egret.Tween.get(t).to({
                scaleX: e,
                scaleY: e
            }, .4 * i, egret.Ease.quadIn).to({
                scaleX: 1,
                scaleY: 1
            }, .6 * i, egret.Ease.bounceOut)
        }, e.GrayMatrixFilter = new egret.ColorMatrixFilter([.3, .6, 0, 0, 0, .3, .6, 0, 0, 0, .3, .6, 0, 0, 0, 0, 0, 0, 1, 0]), e = __decorate([singleton], e)
    }();
    t.DisplayUtilMod = e, __reflect(e.prototype, "Core.DisplayUtilMod")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {
            this._timeHandleList = [], this._frameHandleList = [], this._currTime = egret.getTimer(), this._count = 0, egret.startTick(this.onEnterFrame, this)
        }
        return t.prototype.onEnterFrame = function(t) {
            if (this._timeHandleList.length > 0)
                for (var e, i = egret.getTimer(), n = 0; n < this._timeHandleList.length; n++) e = this._timeHandleList[n], i - e.lastTime >= e.interval && (e.lastTime = i, e.method.apply(e.thisObj));
            if (this._frameHandleList.length > 0)
                for (var n = 0; n < this._frameHandleList.length; n++) e = this._frameHandleList[n], e.method.apply(e.thisObj);
            return !1
        }, t.prototype.addTime = function(t, e, i, n) {
            void 0 === n && (n = !1), this.removeTime(e, i);
            var a = {
                interval: t,
                method: e,
                thisObj: i,
                lastTime: egret.getTimer()
            };
            this._timeHandleList.push(a), n && e.apply(i)
        }, t.prototype.removeTime = function(t, e) {
            for (var i, n = this._timeHandleList.length - 1; n >= 0; n--) i = this._timeHandleList[n], i.method == t && i.thisObj == e && this._timeHandleList.splice(n, 1)
        }, t.prototype.addFrame = function(t, e, i) {
            void 0 === i && (i = !1), this.removeFrame(t, e);
            var n = {
                method: t,
                thisObj: e
            };
            this._frameHandleList.push(n), i && t.apply(e)
        }, t.prototype.removeFrame = function(t, e) {
            for (var i, n = this._frameHandleList.length - 1; n >= 0; n--) i = this._frameHandleList[n], i.method == t && i.thisObj == e && this._frameHandleList.splice(n, 1)
        }, t = __decorate([singleton], t)
    }();
    t.GlobalRepeatTigger = e, __reflect(e.prototype, "Core.GlobalRepeatTigger")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {}
        return e.prototype.load = function(e) {
            var i = egret.localStorage.getItem(e);
            return null == i && (i = t.LocalStorageType.DEFAULT_VALUE[e]), ("undefined" == i || void 0 == i) && (i = null), i
        }, e.prototype.save = function(t, e) {
            egret.localStorage.setItem(t, e)
        }, e = __decorate([singleton], e)
    }();
    t.LocalStorageData = e, __reflect(e.prototype, "Core.LocalStorageData")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {
            this._listeners = {}
        }
        return e.prototype.addListener = function(e, i, n) {
            var a = null;
            if (e && i) {
                var o = this._listeners[e];
                if (o) {
                    if (a = this._getDelegate(e, i, n, o)) return
                } else o = [], this._listeners[e] = o;
                a = new t.Delegate(i, n), o.push(a)
            }
        }, e.prototype._getDelegate = function(t, e, i, n) {
            if (void 0 === n && (n = null), n || (n = this._listeners[t]), n)
                for (var a = 0, o = n.length; o > a; a++)
                    if (n[a]._theObj == i && n[a]._delegateMethod == e) return n[a];
            return null
        }, e.prototype.removeListener = function(t, e, i) {
            if (t) {
                var n = this._listeners[t];
                if (!n) return;
                for (var a = 0, o = n.length; o > a; a++)
                    if (n[a]._theObj == i && n[a]._delegateMethod == e) {
                        n.splice(a, 1);
                        break
                    }
                n.length <= 0 && delete this._listeners[t]
            }
        }, e.prototype.removeByType = function(t) {
            if (t) {
                var e = this._listeners[t];
                if (!e) return;
                App.Tool.clearArray(e), delete this._listeners[t]
            }
        }, e.prototype.removeByThisObj = function(t) {
            if (t)
                for (var e in this._listeners) {
                    var i = this._listeners[e];
                    if (i && !(i.length <= 0)) {
                        for (var n = 0; n < i.length; n++) i[n]._theObj == t && (i.splice(n, 1), n--);
                        i.length <= 0 && delete this._listeners[e]
                    }
                }
        }, e.prototype.dispatch = function(t, e) {
            if (void 0 === e && (e = null), t) {
                var i = [],
                    n = this._listeners[t];
                if (n && !(n.length <= 0)) {
                    for (var a = 0, o = n.length; o > a; a++) i.push(n[a]);
                    if (i.length > 0) {
                        for (a = 0, o = i.length; o > a; a++) i[a].run(e);
                        App.Tool.clearArray(i)
                    }
                }
            }
        }, e = __decorate([singleton], e)
    }();
    t.MessageCenter = e, __reflect(e.prototype, "Core.MessageCenter")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {
            this._delayGroupMap = new t.ZmHashMap
        }
        return e.prototype.delayApply = function(t, e, i, n, a, o) {
            if (void 0 === n && (n = null), void 0 === a && (a = !1), void 0 === o && (o = null), null != i)
                if (a) i.apply(e, n);
                else {
                    var s = egret.setTimeout(function(t) {
                        (void 0 == t.active || 1 == t.active) && i.apply(t, n)
                    }, e, t, n);
                    if (o) {
                        var r = this._delayGroupMap.getValue(o);
                        null == r && (r = [], this._delayGroupMap.add(o, r)), r.push(s)
                    }
                }
        }, e.prototype.clearDelayByGroup = function(t) {
            if (t) {
                var e = this._delayGroupMap.remove(t);
                if (e) {
                    for (var i = 0; i < e.length; i++) clearTimeout(e[i]);
                    App.Tool.clearArray(e)
                }
            }
        }, e.prototype.convertAmount = function(t) {
            if (void 0 == t || 0 > t) return "0";
            for (var e = t.toString(), i = "", n = 0, a = e.length - 1; a >= 0; a--) i = e.charAt(a) + i, n++, 3 == n && (a > 0 && (i = "," + i), n = 0);
            return i
        }, e.prototype.convertIntegerNum = function(t) {
            var e;
            return e = t / 1e8, e >= 1 && Math.floor(e) == e ? Math.floor(e) + "亿" : (e = t / 1e4, e >= 1 && Math.floor(e) == e ? Math.floor(e) + "万" : (e = t / 1e3, e >= 1 && 9 >= e && Math.floor(e) == e ? Math.floor(e) + "千" : App.Tool.convertAmountToWan(t)))
        }, e.prototype.convertAmountToWan = function(t, e) {
            if (void 0 === e && (e = 1), void 0 == t) return "0";
            var i, n, a, o, s = Math.pow(10, e);
            if (Math.abs(t) >= 99999999) {
                if (i = Math.floor(t / 1e8), n = Math.floor(t / (1e8 / s)) - i * s, 0 == n || 0 >= e) return i + "亿";
                for (a = ".", o = 0; o < e - n.toString().length; o++) a += "0";
                return i + a + n + "亿"
            }
            if (Math.abs(t) > 9999) {
                if (i = Math.floor(t / 1e4), n = Math.floor(t / (1e4 / s)) - i * s, 0 == n || 0 >= e) return i + "万";
                for (a = ".", o = 0; o < e - n.toString().length; o++) a += "0";
                return i + a + n + "万"
            }
            return t.toString()
        }, e.prototype.addArrayItem = function(t, e) {
            t && t.indexOf(e) < 0 && t.push(e)
        }, e.prototype.deleteArrayItem = function(t, e) {
            if (t) {
                var i = t.indexOf(e);
                i >= 0 && t.splice(i, 1)
            }
        }, e.prototype.clearArray = function(t) {
            t && t.splice(0, t.length)
        }, e.prototype.megerResGroups = function() {
            for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
            for (var i, n = [], a = 0; a < t.length; a++) i = RES.getGroupByName(t[a]), i && i.length > 0 && (n = n.concat(i));
            return n
        }, e.prototype.megerProtoFiles = function() {
            function t(t) {
                for (var e = t.indexOf("//", 0), i = t.indexOf("\n", e + 1); e >= 0 && i > e;) {
                    var n = t.slice(e, i);
                    t = t.replace(n, ""), e = t.indexOf("//", 0), i = t.indexOf("\n", e + 1)
                }
                return t
            }
            for (var e = [], i = 0; i < arguments.length; i++) e[i] = arguments[i];
            for (var n, a, o, s = "", r = 0; r < e.length; r++) {
                if (n = RES.getRes(e[r]), !n) throw Error("没有找到Proto文件：" + e[r]);
                for (a = n.indexOf("\nenum", 0), o = n.indexOf("}", a + 6); a >= 0 && o > a;) s += t(n.slice(a, o + 1)) + "\n", a = n.indexOf("\nenum", o + 2), o = n.indexOf("}", a + 6);
                for (a = n.indexOf("\nmessage", 0), o = n.indexOf("}", a + 9); a >= 0 && o > a;) s += t(n.slice(a, o + 1)) + "\n", a = n.indexOf("\nmessage", o + 2), o = n.indexOf("}", a + 9)
            }
            return s
        }, e.prototype.getUnixTime = function() {
            return Math.floor((new Date).getTime() / 1e3)
        }, e.prototype.getCurrentTime = function() {
            var t = new Date(1e3 * App.Tool.getUnixTime()).toString();
            return t = t.substring(t.indexOf(":") - 2), t = t.substring(0, t.lastIndexOf(":") + 3)
        }, e.prototype.convertResName = function(t) {
            return t.replace(".", "_")
        }, e.prototype.initLabelPrompt = function(t, e) {
            void 0 === e && (e = null), t && (t.textColor = 11184810, e && (t.text = e))
        }, e.prototype.doLabelPrompt = function(t, e, i, n) {
            var a = this;
            void 0 === i && (i = null), void 0 === n && (n = 0), this.delayApply(50, this, function() {
                if (t) {
                    var o, s = t.text;
                    o = 11184810 == t.textColor ? "" : s, s = prompt(e, o), s && s.length > 0 && (n > 0 && (s = s.substr(0, n)), t.textColor = 0, i && i.length > 0 ? t.text = a.filterChars(s, i) : t.text = s)
                }
            })
        }, e.prototype.filterChars = function(t, e) {
            for (var i, n = "", a = 0; a < t.length; a++) i = t.charAt(a), e.indexOf(i) >= 0 && (n += i);
            return n
        }, e.prototype.getUrlParam = function(t, e) {
            if (t && e) {
                var i = t.indexOf("?" + e + "=");
                if (-1 == i && (i = t.indexOf("&" + e + "=")), i >= 0) {
                    i += e.length + 2;
                    var n, a = t.indexOf("&", i);
                    return n = 0 > a ? t.substring(i) : t.substring(i, a)
                }
            }
            return null
        }, e.prototype.getHostAddress = function(t, e) {
            var i = t.indexOf(e);
            return i > 0 ? t.substring(0, i) : t
        }, e.prototype.getResPath = function() {
            var t, e = location.href;
            return t = e.indexOf("?"), t > 0 && (e = e.substring(0, t)), t = e.indexOf("index."), t > 0 && (e = e.substring(0, t)), "/" == e.substr(e.length - 1, 1) && (e = e.substr(0, e.length - 1)), e += "/resource/"
        }, e.prototype.objectToStr = function(t) {
            var e, i = "[";
            for (var n in t) e = t[n], i += e instanceof Object || e instanceof Array ? this.objectToStr(e) : n + "=" + t[n] + " ";
            return i += "]"
        }, e.prototype.trimStr = function(t, e, i) {
            void 0 === i && (i = !1);
            var n = t;
            return n.length > e && (n = n.substr(0, e), i && (n += "...")), n
        }, e.prototype.deepCopy = function(t) {
            if (null == t || {} == t || [] == t) return t;
            var e, i = !1;
            t.length ? (e = [], i = !0) : (e = {}, i = !1);
            for (var n = 0, a = Object.keys(t); n < a.length; n++) {
                var o = a[n];
                if (null == t[o]) i ? e.push(null) : e[o] = null;
                else {
                    var s = "object" == typeof t[o] ? this.deepCopy(t[o]) : t[o];
                    i ? e.push(s) : e[o] = s
                }
            }
            return e
        }, e = __decorate([singleton], e)
    }();
    t.ToolMod = e, __reflect(e.prototype, "Core.ToolMod")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {}
        return e.prototype.Pop = function(e) {
            var i = new t.Views.ZmPopView;
            i.show(e, App.LayerManager.tipLayer)
        }, e.prototype.Alert = function(e, i, n, a) {
            void 0 === i && (i = null), void 0 === n && (n = null), void 0 === a && (a = !0);
            var o = new t.Views.ZmAlertView(a);
            o.show(e, i, n, App.LayerManager.dialogLayer)
        }, e.prototype.Confirm = function(e, i, n, a, o) {
            void 0 === a && (a = "Cancel"), void 0 === o && (o = "O K");
            var s = new t.Views.ZmConfirmView;
            s.show(e, i, n, a, o, App.LayerManager.dialogLayer)
        }, e.prototype.Prompt = function(e, i, n, a, o, s) {
            void 0 === a && (a = null), void 0 === o && (o = null), void 0 === s && (s = !0);
            var r = new t.Views.ZmPromptView;
            r.show(e, i, n, a, o, App.LayerManager.dialogLayer)
        }, e = __decorate([singleton], e)
    }();
    t.DialogMod = e, __reflect(e.prototype, "Core.DialogMod")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e(e, i, n, a, o, s, r) {
            this._euiComponentClass = e, this._resGroupName = i, this._isModal = n, this._hideScene = a, this._hideOtherView = o, this._freeRes = s, this._initData = r, t.EuiViewData.idSeed++, this._id = t.EuiViewData.idSeed
        }
        return e.prototype.destroy = function() {
            this._euiComponentClass = null, this._view = null, this._resGroupName = "", this._initData = null
        }, e.prototype.setView = function(t) {
            this._view = t
        }, Object.defineProperty(e.prototype, "euiComponentClass", {
            get: function() {
                return this._euiComponentClass
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "view", {
            get: function() {
                return this._view
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "resGroupName", {
            get: function() {
                return this._resGroupName
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "isModal", {
            get: function() {
                return this._isModal
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "hideScene", {
            get: function() {
                return this._hideScene
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "hideOtherView", {
            get: function() {
                return this._hideOtherView
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "freeRes", {
            get: function() {
                return this._freeRes
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "initData", {
            get: function() {
                return this._initData
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "ID", {
            get: function() {
                return this._id
            },
            enumerable: !0,
            configurable: !0
        }), e.idSeed = 0, e
    }();
    t.EuiViewData = e, __reflect(e.prototype, "Core.EuiViewData")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.prototype.init = function(t) {
            this.stage = t, this.container = new eui.UILayer, this.setTouch(this.container, !1, !0), this.sceneLayer = new egret.DisplayObjectContainer, this.setTouch(this.sceneLayer, !1, !0), this.textLineSliderLayer = new egret.DisplayObjectContainer, this.setTouch(this.textLineSliderLayer, !1, !0), this.animationLayer = new egret.DisplayObjectContainer, this.setTouch(this.animationLayer, !1, !1), this.uiLayer = new egret.DisplayObjectContainer, this.setTouch(this.uiLayer, !1, !0), this.tipLayer = new egret.DisplayObjectContainer, this.setTouch(this.tipLayer, !1, !1), this.dialogLayer = new egret.DisplayObjectContainer, this.setTouch(this.dialogLayer, !1, !0), this.debugLayer = new egret.DisplayObjectContainer, this.setTouch(this.debugLayer, !1, !0), this.stage.addChild(this.container), this.container.addChild(this.sceneLayer), this.container.addChild(this.textLineSliderLayer), this.container.addChild(this.animationLayer), this.container.addChild(this.uiLayer), this.container.addChild(this.tipLayer), this.container.addChild(this.dialogLayer), this.container.addChild(this.debugLayer)
        }, t.prototype.setTouch = function(t, e, i) {
            t.touchEnabled = e, t.touchChildren = i
        }, t = __decorate([singleton], t)
    }();
    t.LayerManager = e, __reflect(e.prototype, "Core.LayerManager")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {
            i.self = this, this._clientSizeSyncList = [], this._autoLayoutMap = new t.ZmHashMap, this._childScaleRatio = 1, this._autoScaleDisplayContainerMap = new t.ZmHashMap
        }
        return i = e, e.prototype.init = function(t) {
            void 0 === t && (t = !1), this._stageW = App.LayerManager.stage.stageWidth, this._stageH = App.LayerManager.stage.stageHeight, this._isLandscape = this._stageW > this._stageH
        }, e.prototype.register = function(t, e) {
            void 0 === e && (e = null), this.registAutoLayout(t, e), this.registSyncToClientSize(t)
        }, e.prototype.unRegister = function(t) {
            this.unRegistSyncToClientSize(t), this.unRegistAutoLayout(t)
        }, e.prototype.addLayoutItemToDc = function(e, i) {
            if (e && i && i.parent == e) {
                var n = this._autoLayoutMap.getValue(e);
                null == n && (n = new t.ZmHashMap, this._autoLayoutMap.add(e, n)), n.add(i, [i.x, i.y])
            }
        }, e.prototype.removeLayoutItemFromDc = function(t, e) {
            if (t && e) {
                var i = this._autoLayoutMap.getValue(t);
                i && (i.remove(e), 0 == i.keyList.length && this._autoLayoutMap.remove(t))
            }
        }, e.prototype.updateLayoutItemLoc = function(t, e, i, n) {
            if (void 0 === i && (i = 0 / 0), void 0 === n && (n = 0 / 0), t && e) {
                var a = this._autoLayoutMap.getValue(t);
                if (a) {
                    var o = a.getValue(e);
                    o && 2 == o.length && (0 / 0 != i ? o[0] = i : o[0] = e.x, 0 / 0 != n ? o[1] = n : o[1] = e.y)
                }
            }
        }, e.prototype.addAutoScaleDisplayContainer = function(t, e) {
            void 0 === e && (e = 1.5), this._autoScaleDisplayContainerMap.add(t, e)
        }, e.prototype.removeAutoScaleDisplayContainer = function(t) {
            this._autoScaleDisplayContainerMap.remove(t)
        }, e.prototype.registSyncToClientSize = function(t) {
            t && this._clientSizeSyncList.indexOf(t) < 0 && (this._clientSizeSyncList.push(t), this.syncToClientSize())
        }, e.prototype.unRegistSyncToClientSize = function(t) {
            if (t) {
                var e = this._clientSizeSyncList.indexOf(t);
                e >= 0 && this._clientSizeSyncList.splice(e, 1)
            }
        }, e.prototype.registAutoLayout = function(e, i) {
            if (e) {
                var n = this._autoLayoutMap.getValue(e);
                n && this.unRegistAutoLayout(e), n = new t.ZmHashMap;
                var a, o;
                if (i)
                    for (o = 0; o < i.length; o++) a = i[o], a.parent == e && n.add(a, [a.x, a.y]);
                else
                    for (o = 0; o < e.numChildren; o++) a = e.getChildAt(o), n.add(a, [a.x, a.y]);
                this._autoLayoutMap.add(e, n)
            }
        }, e.prototype.unRegistAutoLayout = function(t) {
            if (t) {
                var e = this._autoLayoutMap.remove(t);
                e && e.clear()
            }
        }, e.prototype.onClientWindowResize = function() {
            i.self.update(), App.MessageCenter.dispatch(t.AppMessageType.CLIENT_RESIZE)
        }, e.prototype.updateScrollTop = function() {
            var t = Math.round((document.body.clientHeight - window.innerHeight) / 2);
            document.body.scrollTop != t && (document.body.scrollTop = t, this.update())
        }, e.prototype.update = function() {
            i.self.getClientWindowSize(), i.self._clientSizeSyncList.length > 0 && i.self.syncToClientSize(), i.self._autoScaleDisplayContainerMap.length > 0 && i.self.autoScaleDisplayContainer()
        }, e.prototype.getClientWindowSize = function() {
            if (this.windowWidth = window.innerWidth, this.windowHeight = window.innerHeight, (null == this.windowWidth || null == this.windowHeight) && (document.body && (this.windowWidth = document.body.clientWidth, this.windowHeight = document.body.clientHeight), (null == this.windowWidth || null == this.windowHeight) && document.documentElement && (this.windowWidth = document.documentElement.clientWidth, this.windowHeight = document.documentElement.clientHeight)), this.windowHeight > this.windowWidth) {
                var t = this.windowWidth;
                this.windowWidth = this.windowHeight, this.windowHeight = t
            }
            this.scaleX = this.windowWidth / this._stageW, this.scaleY = this.windowHeight / this._stageH, this.displayScale = Math.max(this.scaleX, this.scaleY), this.scaleX = this.scaleX / this.displayScale, this.scaleY = this.scaleY / this.displayScale, this.clientWidth = Math.round(this.windowWidth / this.displayScale), this.clientHeight = Math.round(this.windowHeight / this.displayScale), this.clientLeft = Math.round((this._stageW - this.windowWidth / this.displayScale) / 2), this.clientTop = Math.round((this._stageH - this.windowHeight / this.displayScale) / 2);
            var e = this.windowWidth / this.windowHeight;
            e < i.aspectRatioLimitLow ? this._childScaleRatio = e / i.aspectRatioLimitLow : e > i.aspectRatioLimitHigh ? this._childScaleRatio = i.aspectRatioLimitHigh / e : this._childScaleRatio = 1
        }, e.prototype.syncToClientSize = function() {
            for (var t, e = 0; e < this._clientSizeSyncList.length; e++) t = this._clientSizeSyncList[e], t.width = this.clientWidth, t.height = this.clientHeight, t.x = this.clientLeft, t.y = this.clientTop, this._autoLayoutMap.has(t) && this.autoLayoutChildren(t)
        }, e.prototype.autoLayoutChildren = function(t) {
            var e = this._autoLayoutMap.getValue(t);
            if (e)
                for (var i, n, a = this._isLandscape ? this.scaleY : this.scaleX, o = 0; o < e.keyList.length; o++) i = e.keyList[o], n = e.getValue(i), i.x = n[0] * this.scaleX, i.y = n[1] * this.scaleY, i.scaleX = i.scaleY = a
        }, e.prototype.autoScaleDisplayContainer = function() {
            for (var t, e, i = App.LayoutSyncManager.windowWidth / App.LayoutSyncManager.windowHeight, n = 0; n < this._autoScaleDisplayContainerMap.length; n++) t = this._autoScaleDisplayContainerMap.keyList[n], e = this._autoScaleDisplayContainerMap.valueList[n], e > i ? t.scaleX = t.scaleY = i / e : t.scaleX = t.scaleY = 1
        }, Object.defineProperty(e.prototype, "stageCenterX", {
            get: function() {
                return this._stageW / 2 - this.clientLeft
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(e.prototype, "stageCenterY", {
            get: function() {
                return this._stageH / 2 - this.clientTop
            },
            enumerable: !0,
            configurable: !0
        }), e.aspectRatioLimitLow = 1.5, e.aspectRatioLimitHigh = 2, e = i = __decorate([singleton], e);
        var i
    }();
    t.LayoutSyncManager = e, __reflect(e.prototype, "Core.LayoutSyncManager")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {}
        return e.prototype.init = function(t) {
            this._layer = t
        }, e.prototype["switch"] = function(t, e, i, n, a) {
            void 0 === e && (e = null), void 0 === i && (i = !0), void 0 === n && (n = !1), void 0 === a && (a = !1), this._curEuiComponentClass = t, this._resGroupName = e, this._autoSyncToClient = i, this._freeRes = n, "" == e && (e = null), null == e || RES.isGroupLoaded(e) ? this.doSwitch() : (RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this), RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), 0 == a && App.LoopLoading.show(e), RES.loadGroup(e))
        }, e.prototype.release = function() {
            this._curSceneView && (this._curSceneView.freeRes && this._curSceneView.skinResName && RES.destroyRes(this._curSceneView.skinResName), this._curSceneView.destroy(), delete this._curSceneView.autoSyncToClient, delete this._curSceneView.freeRes, App.Display.removeFromParent(this._curSceneView), App.MessageCenter.dispatch(t.AppMessageType.CLOSE_EUI_VIEW, this._curSceneView), this._curSceneView = null)
        }, e.prototype.lockCurrentScene = function() {
            this._curSceneView && (this._curSceneView.touchEnabled = this._curSceneView.touchChildren = !1)
        }, e.prototype.unLockCurrentScene = function() {
            this._curSceneView && (this._curSceneView.touchEnabled = this._curSceneView.touchChildren = !0)
        }, e.prototype.onResourceLoadComplete = function(t) {
            this._curEuiComponentClass && this._resGroupName == t.groupName && (RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this), RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), App.LoopLoading.hide(), this.doSwitch(), this._curEuiComponentClass = null, this._resGroupName = null)
        }, e.prototype.onResourceLoadError = function(t) {
            this._curEuiComponentClass && this._resGroupName == t.groupName && (RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this), RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), App.LoopLoading.hide(), this._curEuiComponentClass = null, this._resGroupName = null)
        }, e.prototype.doSwitch = function() {
            var e = this._curSceneView;
            this._curSceneView = new this._curEuiComponentClass, this._curSceneView.autoSyncToClient = this._autoSyncToClient, this._curSceneView.freeRes = this._freeRes, e && (e.freeRes && e.skinResName && RES.destroyRes(e.skinResName), e.destroy(), delete e.autoSyncToClient, delete e.freeRes, App.Display.removeFromParent(e), App.MessageCenter.dispatch(t.AppMessageType.CLOSE_EUI_VIEW, e)), this._layer.addChild(this._curSceneView), this._curSceneView.autoSyncToClient
        }, Object.defineProperty(e.prototype, "curSceneView", {
            get: function() {
                return this._curSceneView
            },
            enumerable: !0,
            configurable: !0
        }), e = __decorate([singleton], e)
    }();
    t.SceneViewManager = e, __reflect(e.prototype, "Core.SceneViewManager")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e = function() {
        function e() {
            this._viewDataMap = new t.ZmHashMap, this._autoHideViewMap = new t.ZmHashMap, this._windowList = []
        }
        return e.prototype.init = function(t, e) {
            this._uiLayer = t, this._sceneLayer = e
        }, e.prototype.showWin = function(t, e) {
            e = e || {
                resGroupName: null,
                initData: null,
                isModal: !1,
                hideScene: !1,
                hideOtherView: !1,
                freeRes: !1,
                hideLoadProgress: !1
            }, this.show(t, e.resGroupName, e.initData, e.isModal, e.hideScene, e.hideOtherView, e.freeRes, e.hideLoadProgress)
        }, e.prototype.showWithData = function(t, e) {
            var i = {
                resGroupName: null,
                initData: e,
                isModal: !1,
                hideScene: !1,
                hideOtherView: !1,
                freeRes: !1,
                hideLoadProgress: !1
            };
            App.WindowViewManager.showWin(t, i)
        }, e.prototype.show = function(e, i, n, a, o, s, r, h) {
            void 0 === i && (i = null), void 0 === n && (n = null), void 0 === a && (a = !0), void 0 === o && (o = !1), void 0 === s && (s = !1), void 0 === r && (r = !1), void 0 === h && (h = !1);
            var l = this.getData(e);
            if (l) {
                var p = l.view;
                this._uiLayer.addChild(p), p.init && p.init(l.initData)
            } else "" == i && (i = null), l = new t.EuiViewData(e, i, a, o, s, r, n), null == i || RES.isGroupLoaded(i) ? this.createView(l) : (this._curData = l, RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this), RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), 0 == h && App.LoopLoading.show(i), RES.loadGroup(i, 2), Log.trace("WindowViewManager开始加载资源包 " + i))
        }, e.prototype.onResourceLoadComplete = function(t) {
            this._curData && this._curData.resGroupName == t.groupName && (Log.trace("WindowViewManager加载资源包完成 " + t.groupName), RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this), RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), App.LoopLoading.hide(), this.createView(this._curData), this._curData = null)
        }, e.prototype.onResourceLoadError = function(t) {
            this._curData && this._curData.resGroupName == t.groupName && (RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this), RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), App.LoopLoading.hide(), this._curData = null)
        }, e.prototype.createView = function(t) {
            var e = t.euiComponentClass;
            this._viewDataMap.add(e, t);
            var i = new e(t.isModal);
            t.setView(i), t.hideScene && this._sceneLayer.visible && (this._sceneLayer.visible = !1), this._uiLayer.addChild(i), i.init && i.init(t.initData), t.hideOtherView && this.addToAutoHideViews(t), this._windowList.push(i)
        }, e.prototype.close = function(t) {
            var e = this.getData(t);
            e && (App.Tool.deleteArrayItem(this._windowList, e.view), App.Display.removeFromParent(e.view), e.view.destroy(), this._viewDataMap.remove(e.euiComponentClass), e.hideScene && 0 == this._sceneLayer.visible && (this._sceneLayer.visible = !0), e.freeRes && e.resGroupName && RES.destroyRes(e.resGroupName), e.hideOtherView && this.removeFromAutoHideViews(e), e.destroy())
        }, e.prototype.closeAll = function() {
            for (; this._viewDataMap.keyList.length > 0;) this.close(this._viewDataMap.keyList[0])
        }, e.prototype.hide = function(t) {
            var e = this.getData(t);
            e && App.Display.removeFromParent(e.view)
        }, e.prototype.addToAutoHideViews = function(t) {
            for (var e, i = [], n = 0; n < this._viewDataMap.valueList.length; n++) e = this._viewDataMap.valueList[n], e.view && e.view.visible && e.euiComponentClass != t.euiComponentClass && (i.push(e), e.view.visible = !1);
            i.length > 0 && this._autoHideViewMap.add(t, i)
        }, e.prototype.removeFromAutoHideViews = function(t) {
            var e = this._autoHideViewMap.remove(t);
            if (e) {
                for (var i, n = 0; n < e.length; n++) i = e[n], i && i.view && (i.view.visible = !0);
                e.splice(0, e.length)
            }
        }, e.prototype.getData = function(t) {
            var e = this._viewDataMap.getValue(t);
            if (e) return e;
            for (var i = 0; i < this._viewDataMap.valueList.length; i++)
                if (e = this._viewDataMap.valueList[i], e.view == t) return e;
            return null
        }, e.prototype.getWindowInstance = function(t) {
            for (var e = 0, i = this._windowList; e < i.length; e++) {
                var n = i[e];
                if (n instanceof t) return n
            }
            return null
        }, e.prototype.getViewCnt = function() {
            return this._windowList.length
        }, e = __decorate([singleton], e)
    }();
    t.WindowViewManager = e, __reflect(e.prototype, "Core.WindowViewManager")
}(Core || (Core = {}));
var Core;
! function(t) {
    var e;
    ! function(e) {
        var i = function(t) {
            function e() {
                var e = t.call(this, "BaseLoadingSkin.exml", !0) || this;
                return e._layer = App.LayerManager.tipLayer, e.imgProgressBar.scrollRect = new egret.Rectangle(0, 0, e.imgProgressBar.width, e.imgProgressBar.height), e
            }
            return __extends(e, t), e.prototype.destroy = function() {
                this._active && (this.hide(), this.imgProgressBar.scrollRect = null, this._layer = null, this._groupName = null, t.prototype.destroy.call(this))
            }, e.prototype.show = function(t) {
                this.setProgress(0), this._layer.addChild(this), this.showBgMask(), t && t.length > 0 && (this._groupName = t, RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this))
            }, e.prototype.hide = function() {
                RES.removeEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this), App.Display.removeFromParent(this), this.hideBgMask(), this._groupName = null
            }, e.prototype.setProgress = function(t) {
                0 > t && (t = 0), t > 100 && (t = 100);
                var e = this.imgProgressBar.scrollRect;
                e.x = this.imgProgressBar.width * (100 - t) / 100, this.imgProgressBar.scrollRect = e
            }, e.prototype.onResourceProgress = function(t) {
                if (this._groupName == t.groupName) {
                    var e = Math.floor(100 * t.itemsLoaded / t.itemsTotal);
                    this.setProgress(e)
                }
            }, e
        }(t.ZmBaseEuiWindow);
        e.BaseLoadingView = i, __reflect(i.prototype, "Core.Views.BaseLoadingView", ["Core.IBaseLoading"])
    }(e = t.Views || (t.Views = {}))
}(Core || (Core = {}));
var Core;
! function(t) {
    var e;
    ! function(t) {
        var e = function() {
            function t(t, e, i) {
                void 0 === e && (e = !0), void 0 === i && (i = .5), this._dc = t, this._alpha = i, this._bgMaskShape = new egret.Shape, this._bgMaskShape.touchEnabled = e, this._showing = !1
            }
            return t.prototype.destroy = function() {
                this._bgMaskShape && (this.hide(), this._bgMaskShape = null), this._dc = null, this._showing = !1
            }, t.prototype.show = function(t) {
                void 0 === t && (t = -1), this._showing = !0, this.drawGraphics(t)
            }, t.prototype.drawGraphics = function(t) {
                this._showing && this._bgMaskShape && (this._bgMaskShape.graphics.clear(), this._bgMaskShape.graphics.beginFill(0, this._alpha), this._bgMaskShape.graphics.drawRect(-this._dc.x, -this._dc.y, App.LayerManager.stage.stageWidth, App.LayerManager.stage.stageHeight), this._bgMaskShape.graphics.endFill(), t >= 0 ? this._dc.addChildAt(this._bgMaskShape, t) : this._dc.addChild(this._bgMaskShape))
            }, t.prototype.hide = function() {
                this._showing = !1, this._bgMaskShape.graphics.clear(), App.Display.removeFromParent(this._bgMaskShape)
            }, Object.defineProperty(t.prototype, "showing", {
                get: function() {
                    return this._showing
                },
                enumerable: !0,
                configurable: !0
            }), Object.defineProperty(t.prototype, "visible", {
                get: function() {
                    return this._bgMaskShape.visible
                },
                set: function(t) {
                    this._bgMaskShape.visible = t
                },
                enumerable: !0,
                configurable: !0
            }), t
        }();
        t.BgMask = e, __reflect(e.prototype, "Core.Views.BgMask")
    }(e = t.Views || (t.Views = {}))
}(Core || (Core = {}));
var Loading = function(t) {
    function e(e) {
        var i = t.call(this, LoadingSkin, e) || this;
        return i.state = 0, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, i
    }
    return __extends(e, t), Object.defineProperty(e, "ins", {
        get: function() {
            return null == e._ins && (e._ins = new e(!1)), e._ins
        },
        enumerable: !0,
        configurable: !0
    }), e.show = function(t, i) {
        void 0 === t && (t = ""), void 0 === i && (i = .3), e.ins.doShow(t, i), e.showType = 1
    }, e.hide = function() {
        e.ins.doHide(), e.showType = 0
    }, e.showNet = function() {
        1 != e.showType && (e.ins.doShow(), e.showType = 2)
    }, e.hideNet = function() {
        2 == e.showType && (e.ins.doHide(), e.showType = 0)
    }, e.prototype.isShow = function() {
        return this.state > 0
    }, e.prototype.doShow = function(t, e) {
        void 0 === t && (t = ""), void 0 === e && (e = .3), 0 == this.state && (console.log("loading show"), this.imgBk.alpha = e, this.txtTitle.text = t, App.LayerManager.dialogLayer.addChild(this), this.state = 1, egret.setTimeout(function() {
            1 == this.state && (this.state = 2, this.grpView.visible = !0, App.GlobalRepeatTigger.addTime(100, this.updateLoading, this))
        }, this, 500))
    }, e.prototype.doHide = function() {
        0 != this.state && (console.log("loading hide"), 2 == this.state && (this.grpView.visible = !1, App.GlobalRepeatTigger.removeTime(this.updateLoading, this)), App.LayerManager.dialogLayer.removeChild(this), this.state = 0)
    }, e.prototype.updateLoading = function() {
        this.imgLoading.rotation = (this.imgLoading.rotation + 45) % 360
    }, e.prototype.destroy = function() {
        this._active, this.doHide(), t.prototype.destroy.call(this)
    }, e._ins = null, e.showType = 0, e
}(Core.ZmBaseEuiWindow);
__reflect(Loading.prototype, "Loading");
var Core;
! function(t) {
    var e;
    ! function(e) {
        var i = function() {
            function e() {
                this._layer = App.LayerManager.tipLayer, this._bmpLoading = new egret.Bitmap, this._bmpLoading.texture = RES.getRes("dt_base_loading_png"), this._bmpLoading.anchorOffsetX = Math.ceil(this._bmpLoading.texture.textureWidth / 2), this._bmpLoading.anchorOffsetY = Math.ceil(this._bmpLoading.texture.textureHeight / 2), this._bmpLoading.x = App.LayerManager.stage.stageWidth / 2, this._bmpLoading.y = App.LayerManager.stage.stageHeight / 2, this._bgMask = new t.Views.BgMask(this._layer, !1), this._showState = 0
            }
            return e.prototype.destroy = function() {
                this.hide(), this._bmpLoading.texture = null, this._bmpLoading = null, this._bgMask.destroy(), this._bgMask = null, this._layer = null
            }, e.prototype.show = function(t) {
                return wx.showLoading ? void wx.showLoading({
                    title: t
                }) : void(0 == this._showState && (this._showState = 1, this._curAngle = this._bmpLoading.rotation, this._bgMask.show(), this._layer.addChild(this._bmpLoading), App.GlobalRepeatTigger.addTime(100, this.updateFrame, this)))
            }, e.prototype.hide = function() {
                return wx.hideLoading ? void wx.hideLoading({}) : void(1 == this._showState && (this._showState = 0, App.GlobalRepeatTigger.removeTime(this.updateFrame, this), App.Display.removeFromParent(this._bmpLoading), this._bgMask.hide()))
            }, e.prototype.setProgress = function(t) {}, e.prototype.updateFrame = function() {
                this._curAngle += 45, this._curAngle >= 360 && (this._curAngle -= 360), this._bmpLoading.rotation = this._curAngle
            }, e
        }();
        e.ZmLoopLoadingView = i, __reflect(i.prototype, "Core.Views.ZmLoopLoadingView", ["Core.IBaseLoading"])
    }(e = t.Views || (t.Views = {}))
}(Core || (Core = {}));
var ProLoading = function(t) {
    function e(e) {
        var i = t.call(this, ProLoadingSkin, e) || this;
        return i.state = 0, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, i.proLoading.minimum = 0, i.proLoading.maximum = 100, i.proLoading.value = 0, i
    }
    return __extends(e, t), Object.defineProperty(e, "ins", {
        get: function() {
            return null == e._ins && (e._ins = new e(!1)), e._ins
        },
        enumerable: !0,
        configurable: !0
    }), e.show = function(t) {
        void 0 === t && (t = ""), e.ins.doShow(t)
    }, e.hide = function() {
        e.ins.doHide()
    }, e.onPercent = function(t) {
        e.ins.setPercent(t)
    }, e.onAddPercent = function(t) {
        var i = Math.min(100, e.ins.proLoading.value + t);
        e.ins.setPercent(i)
    }, e.prototype.doShow = function(t) {
        void 0 === t && (t = ""), 0 == this.state && (console.log("proloading show"), this.state = 1, this.txtLoading.text = t, this.proLoading.value = 0, App.LayerManager.dialogLayer.addChild(this))
    }, e.prototype.doHide = function() {
        0 != this.state && (console.log("proloading hide"), App.LayerManager.dialogLayer.removeChild(this), this.state = 0)
    }, e.prototype.setPercent = function(t) {
        this.proLoading.value = t
    }, e.prototype.destroy = function() {
        this._active, this.doHide(), t.prototype.destroy.call(this)
    }, e._ins = null, e
}(Core.ZmBaseEuiWindow);
__reflect(ProLoading.prototype, "ProLoading");
var Core;
! function(t) {
    var e;
    ! function(e) {
        var i = function(e) {
            function i(i) {
                void 0 === i && (i = !1);
                var n = e.call(this) || this;
                return n.skinName = t.AppConst.SKIN_PATH + "assets/AlertSkin.exml", n.btnOK.addEventListener(egret.TouchEvent.TOUCH_TAP, n.onBtnOKTap, n), i ? n.btnClose.visible = !1 : n.btnClose.addEventListener(egret.TouchEvent.TOUCH_TAP, n.onBtnCloseTap, n), n
            }
            return __extends(i, e), i.prototype.destroy = function() {
                this.btnOK.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtnOKTap, this), this.btnClose.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtnCloseTap, this), this._bgMask && (this._bgMask.destroy(), this._bgMask = null), this.skinName = null, this.txt1.text = "", this._callBackFunc = null, this._thisObj = null
            }, i.prototype.show = function(e, i, n, a, o) {
                void 0 === o && (o = !0), null == e && (e = ""), this.txt1.text = e, this._callBackFunc = i, this._thisObj = n, a.addChild(this), o && App.Display.moveToStageCenter(this), this._bgMask = new t.Views.BgMask(this, !0), this._bgMask.show(0), this.alpha = 0, egret.Tween.get(this).to({
                    alpha: 1
                }, 200)
            }, i.prototype.hide = function() {
                var t = this;
                egret.Tween.get(this).to({
                    alpha: 0
                }, 300).call(function() {
                    App.Display.removeFromParent(t), t.destroy()
                }, this)
            }, i.prototype.onBtnOKTap = function(t) {
                this._callBackFunc && this._callBackFunc.apply(this._thisObj, [!0]), this.hide()
            }, i.prototype.onBtnCloseTap = function(t) {
                this._callBackFunc && this._callBackFunc.apply(this._thisObj, [!1]), this.hide()
            }, i
        }(eui.Component);
        e.ZmAlertView = i, __reflect(i.prototype, "Core.Views.ZmAlertView")
    }(e = t.Views || (t.Views = {}))
}(Core || (Core = {}));
var Core;
! function(t) {
    var e;
    ! function(e) {
        var i = function(e) {
            function i() {
                var i = e.call(this) || this;
                return i.skinName = t.AppConst.SKIN_PATH + "assets/ConfirmSkin.exml", i.btn1.addEventListener(egret.TouchEvent.TOUCH_TAP, i.onBtn1Tap, i), i.btn2.addEventListener(egret.TouchEvent.TOUCH_TAP, i.onBtn2Tap, i), i
            }
            return __extends(i, e), i.prototype.destroy = function() {
                this.btn1.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtn1Tap, this), this.btn2.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtn2Tap, this), this._bgMask && (this._bgMask.destroy(), this._bgMask = null), this.skinName = null, this.txt1.text = "", this._callBackFunc = null, this._thisObj = null
            }, i.prototype.show = function(e, i, n, a, o, s, r) {
                void 0 === r && (r = !0), null == e && (e = ""), this.txt1.text = e, this._callBackFunc = i, this._thisObj = n, this.btn1.label = a, this.btn2.label = o, s.addChild(this), r && App.Display.moveToStageCenter(this), this._bgMask = new t.Views.BgMask(this, !0), this._bgMask.show(0), this.alpha = 0, egret.Tween.get(this).to({
                    alpha: 1
                }, 200)
            }, i.prototype.hide = function() {
                var t = this;
                egret.Tween.get(this).to({
                    alpha: 0
                }, 300).call(function() {
                    App.Display.removeFromParent(t), t.destroy()
                }, this)
            }, i.prototype.onBtn1Tap = function(t) {
                this._callBackFunc && this._callBackFunc.apply(this._thisObj, [0]), this.hide()
            }, i.prototype.onBtn2Tap = function(t) {
                this._callBackFunc && this._callBackFunc.apply(this._thisObj, [1]), this.hide()
            }, i
        }(eui.Component);
        e.ZmConfirmView = i, __reflect(i.prototype, "Core.Views.ZmConfirmView")
    }(e = t.Views || (t.Views = {}))
}(Core || (Core = {}));
var Core;
! function(t) {
    var e;
    ! function(e) {
        var i = function(e) {
            function i() {
                var i = e.call(this) || this;
                return i.skinName = t.AppConst.SKIN_PATH + "assets/PopSkin.exml", i
            }
            return __extends(i, e), i.prototype.destroy = function() {
                this.txt1.text = ""
            }, i.prototype.show = function(t, e, n) {
                void 0 === n && (n = !0), null == t && (t = ""), this.txt1.text = t, this.imgBk.width = this.txt1.width + 30, this.imgBk.height = this.txt1.height + 30;
                var a = Math.floor(t.length / 30);
                a > 0 && (this.height += 32 * a), e.addChild(this), n && App.Display.moveToStageCenter(this), this.alpha = 0, egret.Tween.get(this).to({
                    alpha: 1
                }, 200), i.viewList.push(this), this.arrangeViews();
                var o = this;
                egret.setTimeout(function() {
                    App.Display.removeFromParent(o), o.destroy(), App.Tool.deleteArrayItem(i.viewList, o)
                }, this, 3e3)
            }, i.prototype.hide = function() {
                var t = this;
                egret.Tween.get(this).to({
                    alpha: 0
                }, 500).call(function() {
                    App.Display.removeFromParent(t), t.destroy(), App.Tool.deleteArrayItem(i.viewList, t)
                }, this)
            }, i.prototype.arrangeViews = function() {
                if (i.viewList.length > 0) {
                    this.y -= i.viewList.length * (this.skin.height + 5);
                    for (var t = i.viewList[0].skin.height, e = 6, n = (App.LayerManager.stage.stageHeight - ((t + e) * i.viewList.length - e)) / 2, a = 0; a < i.viewList.length; a++) i.viewList[a].y = n, n += t + e
                }
            }, i.viewList = [], i
        }(eui.Component);
        e.ZmPopView = i, __reflect(i.prototype, "Core.Views.ZmPopView")
    }(e = t.Views || (t.Views = {}))
}(Core || (Core = {}));
var Core;
! function(t) {
    var e;
    ! function(e) {
        var i = function(e) {
            function i() {
                var i = e.call(this) || this;
                return i.skinName = t.AppConst.SKIN_PATH + "assets/PromptSkin.exml", i.input1.addEventListener(egret.TouchEvent.TOUCH_TAP, i.onInputTap, i), i.btnOK.addEventListener(egret.TouchEvent.TOUCH_TAP, i.onBtnOKTap, i), i
            }
            return __extends(i, e), i.prototype.destroy = function() {
                this.input1.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onInputTap, this), this.btnOK.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onBtnOKTap, this), this._bgMask && (this._bgMask.destroy(), this._bgMask = null), this.skinName = null, this.txt1.text = "", this.input1.prompt = "", this.input1.text = "", this._callBackFunc = null, this._thisObj = null
            }, i.prototype.show = function(e, i, n, a, o, s, r) {
                void 0 === r && (r = !0), null == e && (e = ""), null == i && (i = ""), this.txt1.text = e, n && n.length > 0 ? this.input1.text = n : this.input1.prompt = i, this._callBackFunc = a, this._thisObj = o, s.addChild(this), r && App.Display.moveToStageCenter(this), this._bgMask = new t.Views.BgMask(this, !0), this._bgMask.show(0), this.alpha = 0, egret.Tween.get(this).to({
                    alpha: 1
                }, 200)
            }, i.prototype.hide = function() {
                var t = this;
                egret.Tween.get(this).to({
                    alpha: 0
                }, 300).call(function() {
                    App.Display.removeFromParent(t), t.destroy()
                }, this)
            }, i.prototype.onInputTap = function(t) {
                this.input1.textDisplay.size = 30, this.input1.textDisplay.height = 30, this.input1.textDisplay.setFocus();
                var e = document.documentElement.clientWidth,
                    i = document.documentElement.clientHeight;
                document.body.style.width = e + "px", document.body.style.height = i + "px"
            }, i.prototype.onBtnOKTap = function(t) {
                this._callBackFunc && this._callBackFunc.apply(this._thisObj, [this.input1.text]), this.hide()
            }, i
        }(eui.Component);
        e.ZmPromptView = i, __reflect(i.prototype, "Core.Views.ZmPromptView")
    }(e = t.Views || (t.Views = {}))
}(Core || (Core = {}));
var ZmAssetAdapter = function() {
    function t() {}
    return t.prototype.getAsset = function(t, e, i) {
        function n(n) {
            e.call(i, n, t)
        }
        if (RES.hasRes(t)) {
            var a = RES.getRes(t);
            a ? n(a) : RES.getResAsync(t, n, this)
        } else RES.getResByUrl(t, n, this, RES.ResourceItem.TYPE_IMAGE)
    }, t
}();
__reflect(ZmAssetAdapter.prototype, "ZmAssetAdapter", ["eui.IAssetAdapter"]);
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.getFormatBySecond = function(e, i) {
            void 0 === i && (i = 1);
            var n = "";
            switch (i) {
                case 1:
                    n = t.getFormatBySecond1(e);
                    break;
                case 2:
                    n = t.getFormatBySecond2(e);
                    break;
                case 3:
                    n = t.getFormatBySecond3(e);
                    break;
                case 4:
                    n = t.getFormatBySecond4(e);
                    break;
                case 5:
                    n = t.getFormatBySecond5(e)
            }
            return n
        }, t.getFormatBySecond1 = function(t) {
            void 0 === t && (t = 0);
            var e, i = Math.floor(t / 3600);
            e = 0 == i ? "00" : 10 > i ? "0" + i : "" + i;
            var n, a, o = Math.floor((t - 3600 * i) / 60),
                s = Math.floor((t - 3600 * i) % 60);
            return n = 0 == o ? "00" : 10 > o ? "0" + o : "" + o, a = 0 == s ? "00" : 10 > s ? "0" + s : "" + s, e + ":" + n + ":" + a
        }, t.getFormatBySecond3 = function(t) {
            void 0 === t && (t = 0);
            var e, i, n = Math.floor(t / 3600),
                a = Math.floor((t - 3600 * n) / 60),
                o = Math.floor((t - 3600 * n) % 60);
            return e = 0 == a ? "00" : 10 > a ? "0" + a : "" + a, i = 0 == o ? "00" : 10 > o ? "0" + o : "" + o, e + ":" + i
        }, t.getFormatBySecond2 = function(t) {
            var e = new Date(t),
                i = e.getFullYear(),
                n = e.getMonth() + 1,
                a = e.getDate(),
                o = e.getHours(),
                s = e.getMinutes(),
                r = e.getSeconds();
            return i + "-" + n + "-" + a + " " + o + ":" + s + ":" + r
        }, t.getFormatBySecond4 = function(t) {
            var e = Math.floor(t / 3600);
            return e > 0 ? e > 24 ? Math.floor(e / 24) + "天前" : e + "小时前" : Math.floor(t / 60) + "分钟前"
        }, t.getFormatBySecond5 = function(t) {
            var e = 86400,
                i = 3600,
                n = 60,
                a = Math.floor(t / e),
                o = Math.floor(t % e / i),
                s = Math.floor((t - o * i) / n),
                r = Math.floor((t - o * i) % n),
                h = "",
                l = "",
                p = "",
                u = "";
            return t > 0 ? 0 == a ? (h = "", 0 == o ? (l = "", 0 == s ? (p = "", u = 0 == r ? "" : 10 > r ? "0" + r + "秒" : "" + r + "秒") : (p = "" + s + "分", u = 0 == r ? "" : 10 > r ? "0" + r + "秒" : "" + r + "秒", p + u)) : (l = o + "小时", 0 == s ? (p = "", u = 0 == r ? "" : 10 > r ? "0" + r + "秒" : "" + r + "秒") : (p = 10 > s ? "0" + s + "分" : "" + s + "分", l + p))) : (h = a + "天", l = 0 == o ? "" : 10 > o ? "0" + o + "小时" : "" + o + "小时", h + l) : ""
        }, t
    }();
    t.ZmDateFormat = e, __reflect(e.prototype, "Core.ZmDateFormat")
}(Core || (Core = {}));
var Main = function(t) {
    function e() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e._isInLoading = !1, e
    }
    return __extends(e, t), e.prototype.createChildren = function() {
        t.prototype.createChildren.call(this), e.Instance = this, this.init()
    }, e.prototype.init = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e, i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        return ZmData.Instance.stage = this.stage, console.log("Main init"), gamePlat == PlatType.limi && console.log("GameStatusInfo:" + JSON.stringify(GameStatusInfo)), App.LayerManager.init(this.stage), App.LayoutSyncManager.init(), ZmShare.Instance.init(), this.stage.registerImplementation("eui.IAssetAdapter", new ZmAssetAdapter), this.stage.registerImplementation("eui.IThemeAdapter", new ThemeAdapter), RES.addEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this), RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceLoadProgress, this), App.MessageCenter.addListener(Core.AppMessageType.APP_START, this.onAppStart, this), this._isInLoading = !0, [4, this.loadBase()];
                    case 1:
                        return n.sent(), App.SetupLoading(null, new Core.Views.ZmLoopLoadingView), ProLoading.show("Loading, please wait..."), ZmSession.Instance.init(ZmData.Instance.gameAppId, ZmData.Instance.host + (Util.isQQ() ? "/zmjqq" : ZmData.Instance.appUri)), t = this.showGameBoxFlash(1e3), ProLoading.onPercent(5), Log.trace("开始加载分包"), [4, this.loadSubPackage()];
                    case 2:
                        return n.sent(), ProLoading.onPercent(30), Log.trace("开始加载资源包 ppl"), RES.createGroup("ppl", ["common", "preload"]), RES.loadGroup("ppl"), Log.trace("init Group ppl"), ProLoading.onPercent(45), [4, Utility.ZmAsync.FromEvent(RES, RES.ResourceEvent.GROUP_COMPLETE)];
                    case 3:
                        return n.sent(), Log.trace("init effAnim"), e = RES.getRes("effAnim_json"), ZmSeqFrameAnimatPlayer.Instance.loadAnimations(e), ProLoading.onPercent(55), this._isInLoading = !1, RES.removeEventListener(RES.ResourceEvent.GROUP_LOAD_ERROR, this.onResourceLoadError, this), RES.removeEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, this.onItemLoadError, this), RES.removeEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceLoadProgress, this), Log.trace("init sound"), [4, ZmSoundManager.Instance.loadSoundConfig("sound_json")];
                    case 4:
                        return n.sent(), ProLoading.onPercent(65), [4, ZmData.Instance.loadData()];
                    case 5:
                        return n.sent(), [4, ZmSvrCfg.Instance.loadCfg()];
                    case 6:
                        return n.sent(), ProLoading.onPercent(80), ZmLoading.Instance.attachUI(new Core.Views.ZmLoopLoadingView), platform.onShow && (platform.onShow(this.onShow), platform.onHide(this.onHide)), gamePlat == PlatType.limi && (BK && BK.onEnterForeground ? (BK.onEnterForeground(this.onShow), BK.onEnterBackground(this.onHide)) : (i = this, new BK.Game({
                            onEnterBackground: function(t) {
                                i.onHide()
                            },
                            onEnterForeground: function(t) {
                                i.onShow()
                            }
                        })), BK.onMinimize && BK.onMinimize(function() {
                            console.log("onMinimize"), BkBannerAd.Instance.onAppHide()
                        })), Log.trace("init startGame"), window._stage = this.stage, [4, this.startGame()];
                    case 7:
                        return n.sent(), [2]
                }
            })
        })
    }, e.prototype.onShow = function(t) {
        Log.trace("wx.onShow"), App.MessageCenter.dispatch(Core.AppMessageType.APP_RESUME, t)
    }, e.prototype.onHide = function() {
        Log.trace("wx.onHide"), App.MessageCenter.dispatch(Core.AppMessageType.APP_HIDE)
    }, e.prototype.onAppStart = function() {
        this.hideGameBoxFlash(), ProLoading.onPercent(100), ProLoading.hide()
    }, e.prototype.loadBase = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t;
            return __generator(this, function(e) {
                switch (e.label) {
                    case 0:
                        return Log.trace("开始加载 default.res.json"), RES.loadConfig("resource/default.res.json", "resource/"), [4, Utility.ZmAsync.FromEvent(RES, RES.ResourceEvent.CONFIG_COMPLETE)];
                    case 1:
                        return e.sent(), Log.trace("开始加载 default.thm.json"), t = new eui.Theme("resource/default.thm.json", this.stage), [4, Utility.ZmAsync.FromEvent(t, eui.UIEvent.COMPLETE)];
                    case 2:
                        return e.sent(), RES.loadGroup("base"), Log.trace("开始加载资源包 base"), [4, Utility.ZmAsync.FromEvent(RES, RES.ResourceEvent.GROUP_COMPLETE)];
                    case 3:
                        return e.sent(), [2]
                }
            })
        })
    }, e.prototype.showGameBoxFlash = function(t) {
        return void 0 === t && (t = 1e3), __awaiter(this, void 0, void 0, function() {
            var e, i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        this._gameBoxFlash || (this._gameBoxFlash = new eui.Component, this._gameBoxFlash.skinName = GameBoxFlash), e = this.width / this.height, e > 640 / 1136 ? (this._gameBoxFlash.width = this.width, this._gameBoxFlash.height = 1136 * this.width / 640) : (this._gameBoxFlash.width = 640 * this.height / 1136, this._gameBoxFlash.height = this.height, this._gameBoxFlash.x = .5 * (this.width - this._gameBoxFlash.width)), this.addChild(this._gameBoxFlash), i = Utility.ZmTime.Ticks, 0 >= t && (t = 50), n.label = 1;
                    case 1:
                        return this._isInLoading || Utility.ZmTime.Ticks - i < t ? [4, Utility.ZmAsync.Defer(50)] : [3, 3];
                    case 2:
                        return n.sent(), [3, 1];
                    case 3:
                        return [2]
                }
            })
        })
    }, e.prototype.hideGameBoxFlash = function() {
        this._gameBoxFlash.parent && this._gameBoxFlash.parent.removeChild(this._gameBoxFlash)
    }, e.prototype.loadSubPackage = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return [4, this.doLoadSubPackage(function(t) {
                            t && t.totalBytesWritten && t.totalBytesExpectedToWrite && t.totalBytesExpectedToWrite > 0 && ProLoading.onPercent(5 + 25 * t.totalBytesWritten / t.totalBytesExpectedToWrite)
                        })];
                    case 1:
                        return t.sent(), [2]
                }
            })
        })
    }, e.prototype.doLoadSubPackage = function(t) {
        return void 0 === t && (t = null), __awaiter(this, void 0, void 0, function() {
            var e, i, n, a, o, s;
            return __generator(this, function(r) {
                switch (r.label) {
                    case 0:
                        if (!wx.loadSubpackage) return [2];
                        if (e = {
                                name: "sub"
                            }, i = Utility.ZmAsync.FromSFCAsync(e), n = wx.loadSubpackage(e), !n) return Log.trace("XX failed to load sub package"), [2];
                        a = 5, n.onProgressUpdate(t), o = 0, r.label = 1;
                    case 1:
                        if (!(a > o)) return [3, 8];
                        r.label = 2;
                    case 2:
                        return r.trys.push([2, 4, , 5]), [4, i];
                    case 3:
                        return r.sent(), Log.trace(">> subpackage load done."), [3, 8];
                    case 4:
                        return s = r.sent(), Log.trace("XX loadSubpackage err: " + JSON.stringify(s)), [3, 5];
                    case 5:
                        return [4, Utility.ZmAsync.Defer(50 + 50 * o)];
                    case 6:
                        r.sent(), i = Utility.ZmAsync.FromSFCAsync(e), n = wx.loadSubpackage(e), n.onProgressUpdate(t), r.label = 7;
                    case 7:
                        return o++, [3, 1];
                    case 8:
                        return [2]
                }
            })
        })
    }, e.prototype.onResourceLoadError = function(t) {
        Log.trace(t.groupName + " 加载失败")
    }, e.prototype.onItemLoadError = function(t) {
        Log.trace("！加载资源失败：" + t.resItem.url)
    }, e.prototype.onResourceLoadProgress = function(t) {}, e.prototype.startGame = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return App.init(), [4, Game.Instance.init()];
                    case 1:
                        return t.sent(), Log.trace("初始化完成"), App.MessageCenter.dispatch(Core.AppMessageType.APP_START), [2]
                }
            })
        })
    }, e
}(eui.UILayer);
__reflect(Main.prototype, "Main"), gamePlat == PlatType.limi && (global.Main = Main);
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.toByteArray = function(t) {
            t = t.replace(/\s|:/gm, "");
            var e = new egret.ByteArray;
            1 == (1 & t.length) && (t = "0" + t);
            for (var i, n = 0; n < t.length; n += 2) i = parseInt(t.substr(n, 2), 16), e.writeByte(0), e.dataView.setUint8(n / 2, i);
            return e.position = 0, e
        }, t.fromByteArray = function(t, e) {
            void 0 === e && (e = !1);
            for (var i, n = "", a = 0; a < t.length; a++) i = t.dataView.getUint8(a), n += ("0" + i.toString(16)).substr(-2, 2), e && a < t.length - 1 && (n += ":");
            return n
        }, t.toString = function(t) {
            var e = this.toByteArray(t);
            return e.readUTFBytes(e.length)
        }, t.fromString = function(t, e) {
            void 0 === e && (e = !1);
            var i = new egret.ByteArray;
            return i.writeUTFBytes(t), this.fromByteArray(i, e)
        }, t
    }();
    t.ZmHex = e, __reflect(e.prototype, "Core.ZmHex")
}(Core || (Core = {}));
var Log = function() {
    function t() {}
    return t.trace = function() {
        for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
        var i = t.join(", ");
        console.log("[Log]" + i)
    }, t
}();
__reflect(Log.prototype, "Log");
var Core;
! function(t) {
    var e = function() {
        function t() {}
        return t.hex_md5 = function(t) {
            return this.rstr2hex(this.rstr_md5(this.str2rstr_utf8(t))).toUpperCase()
        }, t.b64_md5 = function(t) {
            return this.rstr2b64(this.rstr_md5(this.str2rstr_utf8(t)))
        }, t.any_md5 = function(t, e) {
            return this.rstr2any(this.rstr_md5(this.str2rstr_utf8(t)), e)
        }, t.hex_hmac_md5 = function(t, e) {
            return this.rstr2hex(this.rstr_hmac_md5(this.str2rstr_utf8(t), this.str2rstr_utf8(e)))
        }, t.b64_hmac_md5 = function(t, e) {
            return this.rstr2b64(this.rstr_hmac_md5(this.str2rstr_utf8(t), this.str2rstr_utf8(e)))
        }, t.any_hmac_md5 = function(t, e, i) {
            return this.rstr2any(this.rstr_hmac_md5(this.str2rstr_utf8(t), this.str2rstr_utf8(e)), i)
        }, t.md5_vm_test = function() {
            return "900150983cd24fb0d6963f7d28e17f72" == this.hex_md5("abc").toLowerCase()
        }, t.rstr_md5 = function(t) {
            return this.binl2rstr(this.binl_md5(this.rstr2binl(t), 8 * t.length))
        }, t.rstr_hmac_md5 = function(t, e) {
            var i = this.rstr2binl(t);
            i.length > 16 && (i = this.binl_md5(i, 8 * t.length));
            for (var n = Array(16), a = Array(16), o = 0; 16 > o; o++) n[o] = 909522486 ^ i[o], a[o] = 1549556828 ^ i[o];
            var s = this.binl_md5(n.concat(this.rstr2binl(e)), 512 + 8 * e.length);
            return this.binl2rstr(this.binl_md5(a.concat(s), 640))
        }, t.rstr2hex = function(t) {
            try {
                this.hexcase
            } catch (e) {
                this.hexcase = 0
            }
            for (var i, n = this.hexcase ? "0123456789ABCDEF" : "0123456789abcdef", a = "", o = 0; o < t.length; o++) i = t.charCodeAt(o), a += n.charAt(i >>> 4 & 15) + n.charAt(15 & i);
            return a
        }, t.rstr2b64 = function(t) {
            try {
                this.b64pad
            } catch (e) {
                this.b64pad = ""
            }
            for (var i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", n = "", a = t.length, o = 0; a > o; o += 3)
                for (var s = t.charCodeAt(o) << 16 | (a > o + 1 ? t.charCodeAt(o + 1) << 8 : 0) | (a > o + 2 ? t.charCodeAt(o + 2) : 0), r = 0; 4 > r; r++) n += 8 * o + 6 * r > 8 * t.length ? this.b64pad : i.charAt(s >>> 6 * (3 - r) & 63);
            return n
        }, t.rstr2any = function(t, e) {
            var i, n, a, o, s, r = e.length,
                h = Array(Math.ceil(t.length / 2));
            for (i = 0; i < h.length; i++) h[i] = t.charCodeAt(2 * i) << 8 | t.charCodeAt(2 * i + 1);
            var l = Math.ceil(8 * t.length / (Math.log(e.length) / Math.log(2))),
                p = Array(l);
            for (n = 0; l > n; n++) {
                for (s = Array(), o = 0, i = 0; i < h.length; i++) o = (o << 16) + h[i], a = Math.floor(o / r), o -= a * r, (s.length > 0 || a > 0) && (s[s.length] = a);
                p[n] = o, h = s
            }
            var u = "";
            for (i = p.length - 1; i >= 0; i--) u += e.charAt(p[i]);
            return u
        }, t.str2rstr_utf8 = function(t) {
            for (var e, i, n = "", a = -1; ++a < t.length;) e = t.charCodeAt(a), i = a + 1 < t.length ? t.charCodeAt(a + 1) : 0, e >= 55296 && 56319 >= e && i >= 56320 && 57343 >= i && (e = 65536 + ((1023 & e) << 10) + (1023 & i), a++), 127 >= e ? n += String.fromCharCode(e) : 2047 >= e ? n += String.fromCharCode(192 | e >>> 6 & 31, 128 | 63 & e) : 65535 >= e ? n += String.fromCharCode(224 | e >>> 12 & 15, 128 | e >>> 6 & 63, 128 | 63 & e) : 2097151 >= e && (n += String.fromCharCode(240 | e >>> 18 & 7, 128 | e >>> 12 & 63, 128 | e >>> 6 & 63, 128 | 63 & e));
            return n
        }, t.str2rstr_utf16le = function(t) {
            for (var e = "", i = 0; i < t.length; i++) e += String.fromCharCode(255 & t.charCodeAt(i), t.charCodeAt(i) >>> 8 & 255);
            return e
        }, t.str2rstr_utf16be = function(t) {
            for (var e = "", i = 0; i < t.length; i++) e += String.fromCharCode(t.charCodeAt(i) >>> 8 & 255, 255 & t.charCodeAt(i));
            return e
        }, t.rstr2binl = function(t) {
            for (var e = Array(t.length >> 2), i = 0; i < e.length; i++) e[i] = 0;
            for (var i = 0; i < 8 * t.length; i += 8) e[i >> 5] |= (255 & t.charCodeAt(i / 8)) << i % 32;
            return e
        }, t.binl2rstr = function(t) {
            for (var e = "", i = 0; i < 32 * t.length; i += 8) e += String.fromCharCode(t[i >> 5] >>> i % 32 & 255);
            return e
        }, t.binl_md5 = function(t, e) {
            t[e >> 5] |= 128 << e % 32, t[(e + 64 >>> 9 << 4) + 14] = e;
            for (var i = 1732584193, n = -271733879, a = -1732584194, o = 271733878, s = 0; s < t.length; s += 16) {
                var r = i,
                    h = n,
                    l = a,
                    p = o;
                i = this.md5_ff(i, n, a, o, t[s + 0], 7, -680876936), o = this.md5_ff(o, i, n, a, t[s + 1], 12, -389564586), a = this.md5_ff(a, o, i, n, t[s + 2], 17, 606105819), n = this.md5_ff(n, a, o, i, t[s + 3], 22, -1044525330), i = this.md5_ff(i, n, a, o, t[s + 4], 7, -176418897), o = this.md5_ff(o, i, n, a, t[s + 5], 12, 1200080426), a = this.md5_ff(a, o, i, n, t[s + 6], 17, -1473231341), n = this.md5_ff(n, a, o, i, t[s + 7], 22, -45705983), i = this.md5_ff(i, n, a, o, t[s + 8], 7, 1770035416), o = this.md5_ff(o, i, n, a, t[s + 9], 12, -1958414417), a = this.md5_ff(a, o, i, n, t[s + 10], 17, -42063), n = this.md5_ff(n, a, o, i, t[s + 11], 22, -1990404162), i = this.md5_ff(i, n, a, o, t[s + 12], 7, 1804603682), o = this.md5_ff(o, i, n, a, t[s + 13], 12, -40341101), a = this.md5_ff(a, o, i, n, t[s + 14], 17, -1502002290), n = this.md5_ff(n, a, o, i, t[s + 15], 22, 1236535329), i = this.md5_gg(i, n, a, o, t[s + 1], 5, -165796510), o = this.md5_gg(o, i, n, a, t[s + 6], 9, -1069501632), a = this.md5_gg(a, o, i, n, t[s + 11], 14, 643717713), n = this.md5_gg(n, a, o, i, t[s + 0], 20, -373897302), i = this.md5_gg(i, n, a, o, t[s + 5], 5, -701558691), o = this.md5_gg(o, i, n, a, t[s + 10], 9, 38016083), a = this.md5_gg(a, o, i, n, t[s + 15], 14, -660478335), n = this.md5_gg(n, a, o, i, t[s + 4], 20, -405537848), i = this.md5_gg(i, n, a, o, t[s + 9], 5, 568446438), o = this.md5_gg(o, i, n, a, t[s + 14], 9, -1019803690), a = this.md5_gg(a, o, i, n, t[s + 3], 14, -187363961), n = this.md5_gg(n, a, o, i, t[s + 8], 20, 1163531501), i = this.md5_gg(i, n, a, o, t[s + 13], 5, -1444681467), o = this.md5_gg(o, i, n, a, t[s + 2], 9, -51403784), a = this.md5_gg(a, o, i, n, t[s + 7], 14, 1735328473), n = this.md5_gg(n, a, o, i, t[s + 12], 20, -1926607734), i = this.md5_hh(i, n, a, o, t[s + 5], 4, -378558), o = this.md5_hh(o, i, n, a, t[s + 8], 11, -2022574463), a = this.md5_hh(a, o, i, n, t[s + 11], 16, 1839030562), n = this.md5_hh(n, a, o, i, t[s + 14], 23, -35309556), i = this.md5_hh(i, n, a, o, t[s + 1], 4, -1530992060), o = this.md5_hh(o, i, n, a, t[s + 4], 11, 1272893353), a = this.md5_hh(a, o, i, n, t[s + 7], 16, -155497632), n = this.md5_hh(n, a, o, i, t[s + 10], 23, -1094730640), i = this.md5_hh(i, n, a, o, t[s + 13], 4, 681279174), o = this.md5_hh(o, i, n, a, t[s + 0], 11, -358537222), a = this.md5_hh(a, o, i, n, t[s + 3], 16, -722521979), n = this.md5_hh(n, a, o, i, t[s + 6], 23, 76029189), i = this.md5_hh(i, n, a, o, t[s + 9], 4, -640364487), o = this.md5_hh(o, i, n, a, t[s + 12], 11, -421815835), a = this.md5_hh(a, o, i, n, t[s + 15], 16, 530742520), n = this.md5_hh(n, a, o, i, t[s + 2], 23, -995338651), i = this.md5_ii(i, n, a, o, t[s + 0], 6, -198630844), o = this.md5_ii(o, i, n, a, t[s + 7], 10, 1126891415), a = this.md5_ii(a, o, i, n, t[s + 14], 15, -1416354905), n = this.md5_ii(n, a, o, i, t[s + 5], 21, -57434055), i = this.md5_ii(i, n, a, o, t[s + 12], 6, 1700485571), o = this.md5_ii(o, i, n, a, t[s + 3], 10, -1894986606), a = this.md5_ii(a, o, i, n, t[s + 10], 15, -1051523), n = this.md5_ii(n, a, o, i, t[s + 1], 21, -2054922799), i = this.md5_ii(i, n, a, o, t[s + 8], 6, 1873313359), o = this.md5_ii(o, i, n, a, t[s + 15], 10, -30611744), a = this.md5_ii(a, o, i, n, t[s + 6], 15, -1560198380), n = this.md5_ii(n, a, o, i, t[s + 13], 21, 1309151649), i = this.md5_ii(i, n, a, o, t[s + 4], 6, -145523070), o = this.md5_ii(o, i, n, a, t[s + 11], 10, -1120210379), a = this.md5_ii(a, o, i, n, t[s + 2], 15, 718787259), n = this.md5_ii(n, a, o, i, t[s + 9], 21, -343485551), i = this.safe_add(i, r), n = this.safe_add(n, h), a = this.safe_add(a, l), o = this.safe_add(o, p)
            }
            return [i, n, a, o]
        }, t.md5_cmn = function(t, e, i, n, a, o) {
            return this.safe_add(this.bit_rol(this.safe_add(this.safe_add(e, t), this.safe_add(n, o)), a), i)
        }, t.md5_ff = function(t, e, i, n, a, o, s) {
            return this.md5_cmn(e & i | ~e & n, t, e, a, o, s)
        }, t.md5_gg = function(t, e, i, n, a, o, s) {
            return this.md5_cmn(e & n | i & ~n, t, e, a, o, s)
        }, t.md5_hh = function(t, e, i, n, a, o, s) {
            return this.md5_cmn(e ^ i ^ n, t, e, a, o, s)
        }, t.md5_ii = function(t, e, i, n, a, o, s) {
            return this.md5_cmn(i ^ (e | ~n), t, e, a, o, s)
        }, t.safe_add = function(t, e) {
            var i = (65535 & t) + (65535 & e),
                n = (t >> 16) + (e >> 16) + (i >> 16);
            return n << 16 | 65535 & i
        }, t.bit_rol = function(t, e) {
            return t << e | t >>> 32 - e
        }, t.hexcase = 0, t.b64pad = "", t
    }();
    t.MD5 = e, __reflect(e.prototype, "Core.MD5")
}(Core || (Core = {}));
var ZmSeqFrameAnimatPlayer = function() {
    function t() {
        this._playerList = {}
    }
    return t.prototype.create = function(t) {
        var e = this._playerList[t];
        return e.clone()
    }, t.prototype.destroy = function(t) {
        t.destroy()
    }, t.prototype.loadAnimations = function(t) {
        var e = t.animations;
        if (e)
            for (var i = 0; i < e.length; i++) {
                var n = e[i],
                    a = n.name,
                    o = n.frames;
                if (!a || !o || o.length <= 0) Log.trace("invalid seqAnimation desc");
                else {
                    var s = 1,
                        r = 0,
                        h = 1,
                        l = 0,
                        p = !1,
                        u = 1e3 / 60;
                    n.scale && (s = n.scale, h = n.scale), n.scaleX && (s = n.scaleX), n.offsetX && (r = n.offsetX), n.scaleY && (h = n.scaleY), n.offsetY && (l = n.offsetY), n.frameBase && (p = n.frameBase), n.duration && (u = n.duration);
                    var c = new ZmFrameListPlayer;
                    c.name = a, c.addFrameList(o, r, l), c.scaleX = s, c.scaleY = h, c.frameBase = p, c.duration = u, this._playerList[a] = c
                }
            }
    }, t = __decorate([singleton], t)
}();
__reflect(ZmSeqFrameAnimatPlayer.prototype, "ZmSeqFrameAnimatPlayer"), String.isNullOrEmpty = function(t) {
    return void 0 == t || null == t ? !0 : "" == t ? !0 : !1
}, String.digestMD5 = function(t) {
    return String.isNullOrEmpty(t) ? t : Core.MD5.hex_md5(t)
}, String.prototype.formatUnicorn = String.prototype.formatUnicorn || function() {
    "use strict";
    var t = this.toString();
    if (arguments.length) {
        var e, i = typeof arguments[0],
            n = "string" === i || "number" === i ? Array.prototype.slice.call(arguments) : arguments[0];
        for (e in n) t = t.replace(new RegExp("\\{" + e + "\\}", "gi"), n[e])
    }
    return t
}, String.prototype.digestMD5 = String.prototype.digestMD5 || function() {
    return String.digestMD5(this)
};
var ThemeAdapter = function() {
    function t() {}
    return t.prototype.getTheme = function(t, e, i, n) {
        function a(t) {
            e.call(n, t)
        }

        function o(e) {
            e.resItem.url == t && (RES.removeEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, o, null), i.call(n))
        }
        "undefined" != typeof generateEUI ? egret.callLater(function() {
            e.call(n, generateEUI)
        }, this) : (RES.addEventListener(RES.ResourceEvent.ITEM_LOAD_ERROR, o, null), RES.getResByUrl(t, a, this, RES.ResourceItem.TYPE_TEXT))
    }, t
}();
__reflect(ThemeAdapter.prototype, "ThemeAdapter", ["eui.IThemeAdapter"]);
var Util = function() {
    function t() {}
    return t.clamp = function(t, e, i) {
        return e > t ? t = e : t > i && (t = i), t
    }, t.playEff = function(t, e, i, n, a, o) {
        void 0 === a && (a = 1), void 0 === o && (o = !1);
        var s = Core.ObjPool.getObj(Core.Effect, t, t);
        return s.x = i, s.y = n, s.scaleX = s.scaleY = a, e.addChild(s), s.play(o, -1, 0), s.addCompleteCallback(function(t) {
            e.removeChild(t), Core.ObjPool.delObj(Core.Effect, t)
        }, e), s
    }, t.playAnim = function(t, e) {
        if (void 0 === e && (e = !0), e)
            for (var i in t.items) t.items[i].props = {
                loop: !0
            };
        t.play()
    }, t.popText = function(t, e) {
        void 0 === e && (e = null), null == e && (e = App.LayerManager.tipLayer);
        var i = new eui.Label;
        i.x = App.LayerManager.stage.stageWidth / 2, i.y = App.LayerManager.stage.stageHeight / 2, i.text = t, i.textColor = 16644857, i.fontFamily = "Microsoft YaHei", i.textAlign = "center", i.size = 42, i.stroke = 2, i.strokeColor = 16231172, i.alpha = 0, e.addChild(i), egret.Tween.get(i).to({
            alpha: 1,
            y: App.LayerManager.stage.stageHeight / 2 - 150
        }, 200).wait(1e3).to({
            alpha: 0,
            y: App.LayerManager.stage.stageHeight / 2 - 200
        }, 200, egret.Ease.quadOut).call(function() {
            i.parent.removeChild(i)
        })
    }, t.setUserHeadImg = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return [4, ZmHelper.loadRemoteTexture(ZmSession.Instance.avatar)];
                    case 1:
                        return e = i.sent(), e && (t.texture = e), [2]
                }
            })
        })
    }, t.random = function(t, e) {
        return Math.floor(Math.random() * (e - t + 1)) + t
    }, t.getArrItem = function(e, i) {
        return e[t.clamp(i, 0, e.length - 1)]
    }, t.randList = function(e) {
        for (var i = e.length, n = 1; n < e.length / 2; n++) {
            var a = t.random(n, i),
                o = e[n];
            e[n] = e[a], e[a] = o
        }
    }, t.randIndex = function(t) {
        for (var e = 0, i = 0; i < t.length; i++) e += t[i];
        if (0 == e) return -1;
        for (var n = Math.random() * e, i = 0; i < t.length; i++) {
            if (n < t[i]) return i;
            n -= t[i]
        }
        return -1
    }, t.getDataStr = function(t) {
        var e = t.getFullYear().toString() + (t.getMonth() < 9 ? "0" + (t.getMonth() + 1) : t.getMonth() + 1).toString() + (t.getDate() < 10 ? "0" + t.getDate() : t.getDate()).toString();
        return e
    }, t.getKvStr = function(t) {
        var e = "";
        if (t)
            for (var i = 0, n = Object.keys(t); i < n.length; i++) {
                var a = n[i];
                "" != e && (e += "&"), e += a + "=" + t[a]
            }
        return e
    }, t.getRes = function(e) {
        return t.resPool.getRes(e)
    }, t.isIphoneX = function() {
        var t = platform.getSystemInfoSync();
        return t && t.model && 0 == t.model.indexOf("iPhone X")
    }, t.isQQ = function() {
        return !1
    }, t.getClientWindowWidth = function() {
        var t = window.innerWidth;
        return null == t && (document.body && (t = document.body.clientWidth), null == t && document.documentElement && (t = document.documentElement.clientWidth)), t
    }, t.getClientWindowHeight = function() {
        var t = window.innerHeight;
        return null == t && (document.body && (t = document.body.clientHeight), null == t && document.documentElement && (t = document.documentElement.clientHeight)), t
    }, t.resPool = new Core.ZmResPool, t
}();
__reflect(Util.prototype, "Util");
var Game = function() {
    function t() {
        this.isInitSdk = !1
    }
    return t.prototype.onAppStart = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                return ZmSoundManager.Instance.playSound("bgm"), this.challenge = null, App.SceneViewManager["switch"](Views.ZmPlayScene), Views.Lixianjiangli.initLixian(), [2]
            })
        })
    }, t.prototype.onAppHide = function() {
        Log.trace("app hide"), ZmSoundManager.Instance.stopSound("bgm")
    }, t.prototype.onAppResume = function(t) {
        Log.trace("app resumed"), gamePlat == PlatType.limi && Views.ZmRewardVideoTip.isPlayReward || ZmSoundManager.Instance.playSound("bgm"), this.challenge = null, this.checkOnResume(t)
    }, t.prototype.initGameData = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return [4, ZmSession.Instance.assureSession()];
                    case 1:
                        return t.sent(), App.MessageCenter.dispatch(ZmMessageType.DATA_READY), [2]
                }
            })
        })
    }, t.prototype.init = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return App.MessageCenter.addListener(Core.AppMessageType.APP_START, this.onAppStart, this), App.MessageCenter.addListener(Core.AppMessageType.APP_HIDE, this.onAppHide, this), App.MessageCenter.addListener(Core.AppMessageType.APP_RESUME, this.onAppResume, this), this.checkLuanch(), [4, this.initGameData()];
                    case 1:
                        return t.sent(), this.checkLaunchShareInfo(), ProLoading.onPercent(90), [2]
                }
            })
        })
    }, t.prototype.checkLuanch = function() {
        console.log("platform:" + JSON.stringify(platform)), gamePlat == PlatType.limi ? this.checkLuanch_sq() : this.checkLuanch_wx()
    }, t.prototype.checkLuanch_sq = function() {
        if (console.log("gameParam:", GameStatusInfo.gameParam), GameStatusInfo.gameParam) {
            var t = JSON.parse(GameStatusInfo.gameParam);
            console.log("params:" + t), t && (t.d && (ZmSession.Instance.invid = t.d.invid, GameSvrLog.Instance.SendShareInfo(t.d.shareStr, t.d.shareUri, t.d.shareOpenId)), t.channelId && (ZmSession.Instance.channel = GameStatusInfo.gameParam.channelId))
        }
        ZmData.Instance.setLastShareType(ShareType.none)
    }, t.prototype.checkLuanch_wx = function() {
        var t = platform.getLaunchOptionsSync();
        console.log("luanchOp:", t), this.checkLuanchData_Wx(t)
    }, t.prototype.checkLuanchData_Wx = function(t) {
        if (t && t.query) {
            if (console.log("luanchOp.query.d:", t.query.d), t.query.d) {
                var e = JSON.parse(t.query.d);
                console.log("query data:", e), e && (ZmSession.Instance.invid = e.invid)
            }
            t.query.channel && (ZmSession.Instance.channel = t.query.channel)
        }
        ZmData.Instance.setLastShareType(ShareType.none)
    }, t.prototype.checkOnResume = function(t) {
        gamePlat == PlatType.limi ? this.checkLuanch_sq() : (this.checkOnResume_wx(t), this.checkLuanchData_Wx(t))
    }, t.prototype.checkOnResume_wx = function(t) {
        console.log("resumeOp:", t), t && t.query && (console.log("resumeOp.query.d:", t.query.d), t.query.d && ZmShare.Instance.checkShare(t))
    }, t.prototype.checkLaunchShareInfo = function() {
        if (gamePlat == PlatType.limi);
        else {
            var t = platform.getLaunchOptionsSync();
            if (t && t.query && t.query.d) {
                var e = JSON.parse(t.query.d);
                e && GameSvrLog.Instance.SendShareInfo(e.shareStr, e.shareUri, e.shareOpenId)
            }
        }
    }, t = __decorate([singleton], t)
}();
__reflect(Game.prototype, "Game");
var ZmData = function() {
    function t() {
        this.appName = "祖玛鸡", this.gameBoxAppId = "wxd84c4af1e5b98fbe", this.gameBoxPath = "/pages/game/index", this.host = "wxgame.chiji-h5.com", this.appUri = "/wxgs_zmj", this.gameAppId = "zmj", this.noNet = !1, this.hisTotalScore = -1, this.levelScore = 0, this.bombCnt = 0, this.heidongCnt = 0, this.medicalKitCnt = 0, this.userSkinIds = [1], this.curSkinId = 1, this.isRandSkin = 0, this.isSoundOpen = 1, this.guidStep = 0, this.diamondCnt = 0, this.yaoshiCnt = 0, this.reliveCnt = 0, this.levelReliveCnt = 0, this.levelFail = 0, this.lixianTime = 0, this.tiliCnt = 0, this.maxTiliCnt = 5, this.tiliLastTime = 0, this.yaoqinIds = [], this.diamondLingquCnt = 0, this.curLevelScore = 0, this.passLevel = 0, this.shareCnt = 0, this.openId = "", this.svrData = new ZmSvrData, this.shareData = new ZmShareData, this.localTimeOff = 0, this.isSaveData = !1, this.version = 190123
    }
    return e = t, t.prototype.loadData = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return this.systemInfo = platform.getSystemInfoSync(), console.log("systemInfo:", this.systemInfo), [4, this.loadLocalData()];
                    case 1:
                        return t.sent(), [2]
                }
            })
        })
    }, t.prototype.loadLocalData = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e, i, n, a, o, s, r, h, l, p, u, c, d, g, f, m, y, v, _, S, b, w, C, A, D, T, x, I, P, L, B, M, E, R, O, k, Z, N, H, V, G;
            return __generator(this, function(W) {
                switch (W.label) {
                    case 0:
                        return t = this, e = parseInt, [4, this.loadStorage("hisTotalScore")];
                    case 1:
                        return t.hisTotalScore = e.apply(void 0, [W.sent()]), isNaN(this.hisTotalScore) && (this.hisTotalScore = 0), i = this, n = parseInt, [4, this.loadStorage("levelScore")];
                    case 2:
                        return i.levelScore = n.apply(void 0, [W.sent()]), isNaN(this.levelScore) && (this.levelScore = 0), a = this, o = parseInt, [4, this.loadStorage("passLevel")];
                    case 3:
                        return a.passLevel = o.apply(void 0, [W.sent()]), isNaN(this.passLevel) && (this.passLevel = 0), s = this, r = parseInt, [4, this.loadStorage("bombCnt")];
                    case 4:
                        return s.bombCnt = r.apply(void 0, [W.sent()]), isNaN(this.bombCnt) && (this.bombCnt = 1, this.setBombCnt(this.bombCnt)), h = this, l = parseInt, [4, this.loadStorage("heidongCnt")];
                    case 5:
                        return h.heidongCnt = l.apply(void 0, [W.sent()]), isNaN(this.heidongCnt) && (this.heidongCnt = 1, this.setHeidongCnt(this.heidongCnt)), p = this, u = parseInt, [4, this.loadStorage("medicalKitCnt")];
                    case 6:
                        return p.medicalKitCnt = u.apply(void 0, [W.sent()]), isNaN(this.medicalKitCnt) && (this.medicalKitCnt = 0, this.setMedicalKitCnt(this.medicalKitCnt)), c = this, d = parseInt, [4, this.loadStorage("curSkinId")];
                    case 7:
                        return c.curSkinId = d.apply(void 0, [W.sent()]), isNaN(this.curSkinId) && (this.curSkinId = 1, this.setCurSkinId(this.curSkinId)), g = this, f = parseInt, [4, this.loadStorage("reliveCnt")];
                    case 8:
                        return g.reliveCnt = f.apply(void 0, [W.sent()]), isNaN(this.reliveCnt) && (this.reliveCnt = 0, this.setReliveCnt(this.reliveCnt)), m = this, y = parseInt, [4, this.loadStorage("levelReliveCnt")];
                    case 9:
                        return m.levelReliveCnt = y.apply(void 0, [W.sent()]), isNaN(this.levelReliveCnt) && (this.levelReliveCnt = 0, this.setLevelReliveCnt(this.levelReliveCnt)), v = this, _ = parseInt, [4, this.loadStorage("levelFail")];
                    case 10:
                        return v.levelFail = _.apply(void 0, [W.sent()]), isNaN(this.levelFail) && (this.levelFail = 0, this.setLevelFail(!1)), [4, this.loadStorage("userSkinIds")];
                    case 11:
                        return S = W.sent(), S ? this.userSkinIds = JSON.parse(S) : (this.userSkinIds = [1], this.saveStorage("userSkinIds", JSON.stringify(this.userSkinIds))), [4, this.loadStorage("yaoqinIds")];
                    case 12:
                        return b = W.sent(), b && (this.yaoqinIds = JSON.parse(b)), [4, this.loadStorage("shareData")];
                    case 13:
                        return w = W.sent(), w && (this.shareData = JSON.parse(w)), C = this, A = parseInt, [4, this.loadStorage("isSoundOpen")];
                    case 14:
                        return C.isSoundOpen = A.apply(void 0, [W.sent()]), isNaN(this.isSoundOpen) && (this.isSoundOpen = 1, this.setIsSoundOpen(!0)), D = this, T = parseInt, [4, this.loadStorage("isRandSkin")];
                    case 15:
                        return D.isRandSkin = T.apply(void 0, [W.sent()]), isNaN(this.isRandSkin) && (this.isRandSkin = 0), x = this, I = parseInt, [4, this.loadStorage("guidStep")];
                    case 16:
                        return x.guidStep = I.apply(void 0, [W.sent()]), isNaN(this.guidStep) && (this.guidStep = 1, this.setGuidStep(this.guidStep)), P = this, [4, this.loadStorage("openId")];
                    case 17:
                        return P.openId = W.sent(), L = this, B = parseInt, [4, this.loadStorage("lixianTime")];
                    case 18:
                        return L.lixianTime = B.apply(void 0, [W.sent()]), isNaN(this.lixianTime) && (this.lixianTime = 0, this.setLixianTime(this.lixianTime)), M = this, E = parseInt, [4, this.loadStorage("shareCnt")];
                    case 19:
                        return M.shareCnt = E.apply(void 0, [W.sent()]), isNaN(this.shareCnt) && (this.shareCnt = 0, this.setShareCnt(this.shareCnt)), R = this, O = parseInt, [4, this.loadStorage("tiliCnt")];
                    case 20:
                        return R.tiliCnt = O.apply(void 0, [W.sent()]), isNaN(this.tiliCnt) && (this.tiliCnt = this.maxTiliCnt, this.setTiliCnt(this.tiliCnt)), k = this, Z = parseInt, [4, this.loadStorage("tiliLastTime")];
                    case 21:
                        return k.tiliLastTime = Z.apply(void 0, [W.sent()]), isNaN(this.tiliLastTime) && (this.tiliLastTime = 0, this.setTiliLastTime(this.tiliLastTime)), N = this, H = parseInt, [4, this.loadStorage("diamondCnt")];
                    case 22:
                        return N.diamondCnt = H.apply(void 0, [W.sent()]), isNaN(this.diamondCnt) && (this.diamondCnt = 0, this.setDiamondCnt(this.diamondCnt)), [4, this.loadStorage("svrData")];
                    case 23:
                        return V = W.sent(), String.isNullOrEmpty(V) || (G = JSON.parse(V), G && this.svrData.setValue(G)), [2]
                }
            })
        })
    }, t.prototype.getHisTotalScore = function() {
        return this.hisTotalScore
    }, t.prototype.getLevelScore = function() {
        return this.levelScore
    }, Object.defineProperty(t.prototype, "curScore", {
        get: function() {
            return this.curLevelScore + this.levelScore
        },
        enumerable: !0,
        configurable: !0
    }), t.prototype.getPassLevel = function() {
        return this.passLevel
    }, t.prototype.getBombCnt = function() {
        return this.bombCnt
    }, t.prototype.getHeidongCnt = function() {
        return this.heidongCnt
    }, t.prototype.getSkinCnt = function() {
        return this.userSkinIds.length
    }, t.prototype.getCurSkinId = function() {
        return this.curSkinId
    }, t.prototype.getMedicalKitCnt = function() {
        return this.medicalKitCnt
    }, t.prototype.getIsSoundOpen = function() {
        return 1 == this.isSoundOpen
    }, t.prototype.getIsRandSkin = function() {
        return 1 == this.isRandSkin
    }, t.prototype.getGuidStep = function() {
        return this.guidStep
    }, t.prototype.getOpenId = function() {
        return this.openId
    }, t.prototype.getDiamondCnt = function() {
        return this.diamondCnt
    }, t.prototype.getYaoshiCnt = function() {
        return this.yaoshiCnt
    }, t.prototype.getReliveCnt = function() {
        return this.reliveCnt
    }, t.prototype.getShareData = function() {
        return this.shareData
    }, t.prototype.getLastShareType = function() {
        return this.shareData.lastShareType
    }, t.prototype.hasUserSkin = function(t) {
        return -1 != this.userSkinIds.indexOf(t)
    }, t.prototype.hasYaoqinId = function(t) {
        return -1 != this.yaoqinIds.indexOf(t)
    }, t.prototype.getRandSkin = function() {
        var t = Util.random(0, this.userSkinIds.length - 1);
        return this.userSkinIds[t]
    }, t.prototype.addYaoqinId = function(t) {
        this.yaoqinIds.push(t), this.saveStorage("yaoqinIds", JSON.stringify(this.yaoqinIds))
    }, t.prototype.setLastShareType = function(t) {
        this.shareData.lastShareType = t, this.saveShareData()
    }, t.prototype.setBombCnt = function(t) {
        t > 3 && (t = 3), this.bombCnt = t, this.saveStorage("bombCnt", this.bombCnt), App.MessageCenter.dispatch(ZmMessageType.DATA_BOMB_CHANGED)
    }, t.prototype.setYaoshiCnt = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(e) {
                return this.yaoshiCnt = t, App.MessageCenter.dispatch(ZmMessageType.DATA_YAOSHI_CHANGED), [2]
            })
        })
    }, t.prototype.useYaoshi = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return t > 0 && this.getYaoshiCnt() - t < 0 ? [2, !1] : this.noNet ? [2, !1] : [4, ZmSession.Instance.requestApp("/usekey.action", "post", {
                            openid: ZmSession.Instance.openId,
                            count: t
                        })];
                    case 1:
                        return e = i.sent(), e && null != e.keys ? (this.setYaoshiCnt(e.keys), [2, !0]) : [2, !1]
                }
            })
        })
    }, t.prototype.setHeidongCnt = function(t) {
        t > 3 && (t = 3), this.heidongCnt = t, this.saveStorage("heidongCnt", this.heidongCnt), App.MessageCenter.dispatch(ZmMessageType.DATA_HEIDONG_CHANGED)
    }, t.prototype.setCurSkinId = function(t) {
        this.curSkinId = t, this.saveStorage("curSkinId", this.curSkinId), App.MessageCenter.dispatch(ZmMessageType.DATA_SKIN_CHANGED)
    }, t.prototype.setReliveCnt = function(t) {
        this.reliveCnt = t, this.saveStorage("reliveCnt", this.reliveCnt)
    }, t.prototype.newSkin = function(t) {
        var e = this.userSkinIds.indexOf(t);
        e >= 0 || (this.userSkinIds.push(t), this.userSkinIds.sort(), this.saveStorage("userSkinIds", JSON.stringify(this.userSkinIds)))
    }, t.prototype.setMedicalKitCnt = function(t) {
        this.medicalKitCnt = t, this.saveStorage("medicalKitCnt", this.medicalKitCnt), App.MessageCenter.dispatch(ZmMessageType.DATA_MEDICALKITCNT_CHANGED)
    }, t.prototype.setIsSoundOpen = function(t) {
        this.isSoundOpen = t ? 1 : 0, this.saveStorage("isSoundOpen", this.isSoundOpen)
    }, t.prototype.setIsRandSkin = function(t) {
        this.isRandSkin = t ? 1 : 0, this.saveStorage("isRandSkin", this.isRandSkin)
    }, t.prototype.setGuidStep = function(t) {
        this.guidStep = t, this.saveStorage("guidStep", this.guidStep)
    }, t.prototype.setOpenId = function(t) {
        this.openId = t, this.saveStorage("openId", this.openId)
    }, t.prototype.setDiamondCnt = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(e) {
                return this.diamondCnt = Math.floor(t), this.noNet && this.saveStorage("diamondCnt", this.diamondCnt), App.MessageCenter.dispatch(ZmMessageType.DATA_DIAMOND_CHANGED), [2]
            })
        })
    }, t.prototype.addDiamond = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return e = Math.floor(t), 0 > e && this.getDiamondCnt() + e < 0 ? [2, !1] : this.noNet ? (this.setDiamondCnt(this.getDiamondCnt() + e), [2, !0]) : (this.diamondCnt += t, this.setDiamondCnt(this.diamondCnt), [4, this.saveStorage("diamondCnt", this.diamondCnt)]);
                    case 1:
                        return i.sent(), [4, ZmSession.Instance.uploadData(this.svrData)];
                    case 2:
                        return i.sent(), [2, !0]
                }
            })
        })
    }, t.prototype.savaData = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return [4, ZmSession.Instance.uploadData(this.svrData)];
                    case 1:
                        return t.sent(), [2]
                }
            })
        })
    }, t.prototype.gainBomb = function(t) {
        void 0 === t && (t = 1), this.setBombCnt(this.bombCnt + t)
    }, t.prototype.gainHeidong = function(t) {
        void 0 === t && (t = 1), this.setHeidongCnt(this.heidongCnt + t)
    }, t.prototype.gainMedicalKit = function(t) {
        void 0 === t && (t = 1), this.setMedicalKitCnt(this.medicalKitCnt + t)
    }, t.prototype.getShareCnt = function() {
        return this.shareCnt
    }, t.prototype.setShareCnt = function(t) {
        this.shareCnt = t, this.saveStorage("shareCnt", this.shareCnt)
    }, t.prototype.saveShareData = function() {
        this.saveStorage("shareData", JSON.stringify(this.shareData))
    }, t.prototype.updateScore = function(t, i, n) {
        return void 0 === i && (i = !0), void 0 === n && (n = 0), __awaiter(this, void 0, void 0, function() {
            var a;
            return __generator(this, function(o) {
                switch (o.label) {
                    case 0:
                        return t > this.hisTotalScore ? (this.hisTotalScore = t, this.saveStorage("hisTotalScore", t), a = {
                            score: this.hisTotalScore,
                            time: Utility.ZmTime.Now.getTime
                        }, this.saveUserCloudStorage([{
                            key: "score",
                            value: JSON.stringify(a)
                        }]), Log.trace("updateScore " + t), i ? (this.svrData.score = t, this.saveSvrData(), [4, this.sendScore()]) : [3, 2]) : [3, 2];
                    case 1:
                        o.sent(), o.label = 2;
                    case 2:
                        return i && (n > 0 ? (this.setLevelScore(t), this.setPassLevel(n), e.Instance.setLevelFail(!1)) : this.getLevelReliveCnt() > 2 ? (this.setLevelScore(t), this.setPassLevel(n), this.setLevelReliveCnt(0)) : this.setLevelFail(!0)), [2]
                }
            })
        })
    }, t.prototype.sendScore = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t;
            return __generator(this, function(e) {
                switch (e.label) {
                    case 0:
                        return String.isNullOrEmpty(ZmSession.Instance.nickName) ? [2] : [4, ZmSession.Instance.requestApp("/updatescore.action", "post", {
                            openid: ZmSession.Instance.openId,
                            score: this.hisTotalScore
                        })];
                    case 1:
                        return t = e.sent(), [2]
                }
            })
        })
    }, t.prototype.getLocalTime = function() {
        return (new Date).getTime() + this.localTimeOff
    }, t.prototype.getLocalSec = function() {
        return ((new Date).getTime() + this.localTimeOff) / 1e3
    }, t.prototype.getLocalDate = function() {
        return new Date(this.getLocalTime())
    }, t.prototype.updateTime = function(t) {
        this.localTimeOff = t - (new Date).getTime(), this.checkDayAward()
    }, t.prototype.checkDayAward = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                return [2]
            })
        })
    }, t.prototype.getSvrData = function() {
        return this.svrData
    }, t.prototype.setSvrData = function(t) {
        this.svrData.setValue(t), this.svrData.score > this.hisTotalScore ? this.updateScore(this.svrData.score, !1) : (this.svrData.score = this.hisTotalScore, this.saveSvrData())
    }, t.prototype.getLevelReliveCnt = function() {
        return this.levelReliveCnt
    }, t.prototype.setLevelReliveCnt = function(t) {
        this.levelReliveCnt = t, this.saveStorage("levelReliveCnt", this.levelReliveCnt)
    }, t.prototype.setPassLevel = function(t) {
        this.passLevel = t, this.saveStorage("passLevel", t)
    }, t.prototype.setLevelScore = function(t) {
        this.levelScore = t, this.saveStorage("levelScore", t)
    }, t.prototype.isLevelFail = function() {
        return 1 == this.levelFail
    }, t.prototype.setLevelFail = function(t) {
        this.levelFail = t ? 1 : 0, this.saveStorage("levelFail", this.levelFail)
    }, t.prototype.getSuipianCnt = function() {
        return this.svrData.suipianCnt
    }, t.prototype.setSuipianCnt = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(e) {
                switch (e.label) {
                    case 0:
                        return this.svrData.suipianCnt = t, [4, this.saveSvrData(1)];
                    case 1:
                        return e.sent(), App.MessageCenter.dispatch(ZmMessageType.DATA_SUIPIANCNT_CHANGED), [2]
                }
            })
        })
    }, t.prototype.getLixianTime = function() {
        return this.lixianTime
    }, t.prototype.setLixianTime = function(t) {
        this.lixianTime = t, this.saveStorage("lixianTime", this.lixianTime)
    }, t.prototype.getTiliCnt = function() {
        return this.tiliCnt
    }, t.prototype.setTiliCnt = function(t) {
        this.tiliCnt = t, this.saveStorage("tiliCnt", this.tiliCnt), App.MessageCenter.dispatch(ZmMessageType.DATA_TILI_CHANGED)
    }, t.prototype.getTiliLastTime = function() {
        return this.tiliLastTime
    }, t.prototype.setTiliLastTime = function(t) {
        this.tiliLastTime = t, this.saveStorage("tiliLastTime", this.tiliLastTime)
    }, t.prototype.addTili = function(t) {
        if (t > 0) this.setTiliCnt(Math.min(this.maxTiliCnt, this.tiliCnt + t));
        else if (0 > t) {
            if (this.tiliCnt == this.maxTiliCnt) {
                var e = this.getLocalSec();
                this.setTiliLastTime(e)
            }
            this.setTiliCnt(Math.max(0, this.tiliCnt + t))
        }
    }, t.prototype.checkTili = function() {
        if (!(this.getTiliCnt() >= this.maxTiliCnt)) {
            var t = this.getLocalSec(),
                e = this.getTiliLastTime(),
                i = Math.floor((t - e) / 1200);
            1 > i || (this.addTili(i), this.tiliCnt < this.maxTiliCnt && this.setTiliLastTime(e + 1200 * i))
        }
    }, t.prototype.clearScore = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return t = 0, this.hisTotalScore = t, [4, this.saveStorage("hisTotalScore", t)];
                    case 1:
                        return i.sent(), e = {
                            score: this.hisTotalScore,
                            time: Utility.ZmTime.Now.getTime
                        }, this.saveUserCloudStorage([{
                            key: "score",
                            value: JSON.stringify(e)
                        }]), this.svrData.score = t, [4, ZmSession.Instance.uploadData(this.svrData)];
                    case 2:
                        return i.sent(), [4, this.sendScore()];
                    case 3:
                        return i.sent(), [2]
                }
            })
        })
    }, t.prototype.saveSvrData = function(t) {
        return void 0 === t && (t = 0), __awaiter(this, void 0, void 0, function() {
            var e = this;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return this.noNet ? (this.saveStorage("svrData", JSON.stringify(this.svrData)), [2]) : 1 != t ? [3, 2] : [4, ZmSession.Instance.uploadData(this.svrData)];
                    case 1:
                        return i.sent(), [3, 3];
                    case 2:
                        this.isSaveData || (this.isSaveData = !0, Utility.ZmAsync.NextFrame(egret).then(function() {
                            ZmSession.Instance.uploadData(e.svrData), e.isSaveData = !1
                        })), i.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, t.prototype.saveUserCloudStorage = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return t || (t = [{
                            key: "score",
                            value: String(this.hisTotalScore)
                        }]), [4, platform.setUserCloudStorage(t)];
                    case 1:
                        return e = i.sent(), [2]
                }
            })
        })
    }, t.prototype.loadStorage = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(e) {
                switch (e.label) {
                    case 0:
                        return gamePlat == PlatType.wx && platform.getStorage ? [4, platform.getStorage(t)] : [3, 2];
                    case 1:
                        return [2, e.sent()];
                    case 2:
                        return [2, App.LocalStorageData.load(t)]
                }
            })
        })
    }, t.prototype.saveStorage = function(t, e) {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return gamePlat == PlatType.wx && platform.setStorage ? [4, platform.setStorage(t, e)] : [3, 2];
                    case 1:
                        return i.sent(), [3, 3];
                    case 2:
                        App.LocalStorageData.save(t, String(e)), i.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, t = e = __decorate([singleton], t);
    var e
}();
__reflect(ZmData.prototype, "ZmData");
var ShareType;
! function(t) {
    t[t.none = 0] = "none", t[t.lingquDiammond = 1] = "lingquDiammond", t[t.lingquYaoshi = 2] = "lingquYaoshi", t[t.zhadan = 3] = "zhadan", t[t.heidong = 4] = "heidong", t[t.fuhuo = 5] = "fuhuo", t[t.passDiammond = 6] = "passDiammond", t[t.levelFuhuo = 7] = "levelFuhuo", t[t.suipian = 8] = "suipian", t[t.lixianzuanshi = 9] = "lixianzuanshi", t[t.redPack = 10] = "redPack", t[t.tili = 11] = "tili"
}(ShareType || (ShareType = {}));
var ZmShareData = function() {
    function t() {
        this.lastShareType = ShareType.none, this.qunInfos = {}, this.shareKeyCnt = 0, this.shareKeyDay = ""
    }
    return t
}();
__reflect(ZmShareData.prototype, "ZmShareData");
var ZmShare = function() {
    function t() {
        this.curShareType = ShareType.none, this.delayShareCheckQun = !0, this.delayShareTime = 0, this.delayShareCnt = 0, this.delayShareRate = 1, this.delayShareData = {}, this.shareCancel = !1
    }
    return e = t, t.prototype.init = function() {
        wx.showShareMenu && wx.showShareMenu({
            withShareTicket: !0
        }), App.MessageCenter.addListener(Core.AppMessageType.APP_RESUME, this.onAppResume, this)
    }, t.prototype.shareDelay = function(t, e, i, n, a) {
        return void 0 === i && (i = !0), void 0 === n && (n = null), void 0 === a && (a = null), __awaiter(this, void 0, void 0, function() {
            var o, s, r = this;
            return __generator(this, function(h) {
                switch (h.label) {
                    case 0:
                        return this.delayCbObj = t, this.delayCbFun = e, this.delayCbFailFun = a, this.delayShareCheckQun = i, this.delayShareTime = egret.getTimer(), o = ZmSvrCfg.Instance.getShareStr(), s = ZmSvrCfg.Instance.getShareUri(), n || (n = {}), n.shareStr = o, n.shareUri = s, n.shareOpenId = ZmSession.Instance.openId, n.invid = ZmSession.Instance.uid, this.delayShareData = n, ZmSvrCfg.Instance.getShareIsOpen() ? [4, this.doDelayShare()] : (Views.ZmRewardVideoTip.showWithShare(0, this.curShareType, function(t) {
                            r.onShareComplete(1)
                        }, function() {
                            r.onShareComplete(0)
                        }, !0), [2, !0]);
                    case 1:
                        return h.sent(), [2, !0]
                }
            })
        })
    }, t.prototype.doDelayShare = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t;
            return __generator(this, function(e) {
                return t = "d=" + JSON.stringify(this.delayShareData), console.log("shareAppMessage query=" + t), this.shareAppMessage(this.delayShareData.shareStr, this.delayShareData.shareUri, t), [2]
            })
        })
    }, t.prototype.onShareComplete = function(t) {
        if (this.delayCbObj && this.delayCbFun) {
            var e = this.delayCbObj,
                i = this.delayCbFun,
                n = this.delayCbFailFun,
                a = this.delayShareCheckQun;
            1 != t && a ? this.delayShareCnt > 0 ? (this.delayShareCnt--, this.doDelayShare()) : 2 == t ? this.doDelayShare() : (n && n.apply(e), this.clearShareDelay()) : (i && i.apply(e), this.clearShareDelay())
        }
    }, t.prototype.clearShareDelay = function() {
        this.delayCbObj = null, this.delayCbFun = null, this.delayCbFailFun = null
    }, t.prototype.onAppResume = function(t) {
        var e = this;
        ZmSvrCfg.Instance.getShareIsOpen() && Utility.ZmAsync.NextFrame(egret).then(function() {
            e.checkShare1()
        })
    }, t.prototype.checkShare1 = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        return console.log("checkShare ", this), this.delayCbObj && this.delayCbFun ? (t = 0, this.delayShareCheckQun ? (i = egret.getTimer(), console.log("checkShare curTime=", i, this.delayShareTime), i - this.delayShareTime > e.shareSucTime ? (console.log("checkShare 1"), Math.random() > this.delayShareRate ? (console.log("share DialogMod 请分享到不同群"), [4, platform.showModal("分享失败", "分享失败", !1)]) : [3, 2]) : [3, 4]) : [3, 7]) : [2];
                    case 1:
                        return n.sent(), this.delayShareRate = 1, [3, 3];
                    case 2:
                        t = 1, this.delayShareRate = 1, n.label = 3;
                    case 3:
                        return [3, 6];
                    case 4:
                        return console.log("share DialogMod 请分享到群"), [4, platform.showModal("分享失败", "分享失败", !1)];
                    case 5:
                        n.sent(), n.label = 6;
                    case 6:
                        return [3, 8];
                    case 7:
                        t = 1, n.label = 8;
                    case 8:
                        return 1 == t && Core.DialogMod.Instance.Pop("分享成功"), this.onShareComplete(t), [2]
                }
            })
        })
    }, t.prototype.onShareZhadan = function() {
        App.WindowViewManager.close(Views.GameDaojuZhadan), Views.HuodeWupin.huoqu({
            wpType: Views.WupinType.bomb,
            num: 1
        }), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareZhadan)
    }, t.prototype.onShareHeidong = function() {
        App.WindowViewManager.close(Views.GameDaojuHeidong), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareHeidong), Views.ZmPlayScene.ins.useHeidong()
    }, t.prototype.onShareFuhuo = function() {
        var t = App.WindowViewManager.getWindowInstance(Views.GameOver);
        t && (t.doRelive(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareRelive))
    }, t.prototype.onShareLevelFuhuo = function() {
        var t = App.WindowViewManager.getWindowInstance(Views.LevelSel);
        t && (t.doRelive(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareLevelRelive))
    }, t.prototype.onShareSuipian = function() {
        var t = App.WindowViewManager.getWindowInstance(Views.Suipianbuzu);
        t && (t.doSuipian(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareSuipian))
    }, t.prototype.onSharePassDiammond = function() {
        var t = App.WindowViewManager.getWindowInstance(Views.GamePass);
        t && (t.doShuangbei(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_sharePassDiamond))
    }, t.prototype.onShareLixianzuanshi = function() {
        var t = App.WindowViewManager.getWindowInstance(Views.Lixianjiangli);
        t && (t.doShuangbeilingqu(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareLixianzuanshi))
    }, t.prototype.onShareRedPack = function() {
        var t = App.WindowViewManager.getWindowInstance(Views.FudaiOpen);
        t && (t.doRedPack(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareRedPack))
    }, t.prototype.onShareTili = function() {
        var t = App.WindowViewManager.getWindowInstance(Views.Tilibuzu);
        t && (t.doTili(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareTili))
    }, t.prototype.onShareYaoshi = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t;
            return __generator(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, ZmData.Instance.useYaoshi(-1)];
                    case 1:
                        return t = e.sent(), t && (ZmData.Instance.getShareData().shareKeyCnt++, ZmData.Instance.saveShareData(), console.log("share DialogMod 恭喜获得钥匙x1\n好友点击链接可以获得更多！"), Core.DialogMod.Instance.Pop("恭喜获得钥匙x1\n好友点击链接可以获得更多！"), (1 == ZmData.Instance.getShareData().shareKeyCnt || 5 == ZmData.Instance.getShareData().shareKeyCnt) && this.delayYaoshi()), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareChest), [2]
                }
            })
        })
    }, t.prototype.delayYaoshi = function() {
        egret.setTimeout(function() {
            this.dianjiyaoshi()
        }, this, 1e4)
    }, t.prototype.dianjiyaoshi = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t;
            return __generator(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, ZmData.Instance.useYaoshi(-4)];
                    case 1:
                        return t = e.sent(), t && (console.log("share DialogMod 有好友帮你点击，赠送你钥匙x4！"), Core.DialogMod.Instance.Pop("有好友帮你点击，赠送你钥匙x4！")), [2]
                }
            })
        })
    }, t.prototype.share = function(t) {
        return void 0 === t && (t = ShareType.none), __awaiter(this, void 0, void 0, function() {
            var e, i, n, a, o, s, r;
            return __generator(this, function(h) {
                switch (h.label) {
                    case 0:
                        return this.curShareType = t, t == ShareType.zhadan ? (this.shareDelay(this, this.onShareZhadan), [2]) : t == ShareType.heidong ? (this.shareDelay(this, this.onShareHeidong), [2]) : t == ShareType.fuhuo ? (this.shareDelay(this, this.onShareFuhuo), [2]) : t == ShareType.levelFuhuo ? (this.shareDelay(this, this.onShareLevelFuhuo), [2]) : t == ShareType.suipian ? (this.shareDelay(this, this.onShareSuipian), [2]) : t == ShareType.passDiammond ? (this.shareDelay(this, this.onSharePassDiammond), [2]) : t == ShareType.lixianzuanshi ? (this.shareDelay(this, this.onShareLixianzuanshi), [2]) : t == ShareType.redPack ? (this.shareDelay(this, this.onShareRedPack), [2]) : t == ShareType.tili ? (this.shareDelay(this, this.onShareTili), [2]) : t == ShareType.lingquYaoshi ? (i = Util.getDataStr(ZmData.Instance.getLocalDate()), n = ZmData.Instance.getShareData().shareKeyDay, (String.isNullOrEmpty(n) || i > n) && (ZmData.Instance.getShareData().shareKeyCnt = 0, ZmData.Instance.getShareData().shareKeyDay = i, ZmData.Instance.saveShareData()), this.shareDelay(this, this.onShareYaoshi), [2]) : (console.log("share sType=" + t), [4, ZmSession.Instance.assureSession()]);
                    case 1:
                        return h.sent(), t == ShareType.lingquDiammond && (e = {
                            f: "diamond",
                            invid: ZmSession.Instance.uid
                        }, GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareDiamond)), ZmData.Instance.setLastShareType(t), a = ZmSvrCfg.Instance.getShareStr(), o = this.getShareUri(), e || (e = {}), e.shareStr = a, e.shareUri = o, e.shareOpenId = ZmSession.Instance.openId, e.invid = ZmSession.Instance.uid, s = gamePlat == PlatType.limi ? '{"d":' + JSON.stringify(e) + "}" : "d=" + JSON.stringify(e), [4, this.shareAppMessage(a, o, s)];
                    case 2:
                        return r = h.sent(), console.log("shareAppMessage ret=" + JSON.stringify(r)), this.onShareComplete(r ? 1 : 0), [2, !0]
                }
            })
        })
    }, t.prototype.checkShare_sq = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return e = JSON.parse(t), console.log("query data:", e), e ? ZmSession.Instance.invid == e.invid ? [3, 2] : (ZmSession.Instance.invid = e.invid, [4, ZmSession.Instance._wxSessionLogin()]) : [2];
                    case 1:
                        i.sent(), i.label = 2;
                    case 2:
                        return GameSvrLog.Instance.SendShareInfo(e.shareStr, e.shareUri, e.shareOpenId), App.WindowViewManager.close(Views.FenxiangTip), ZmData.Instance.setLastShareType(ShareType.none), [2]
                }
            })
        })
    }, t.prototype.checkShare = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e, i, n, a;
            return __generator(this, function(o) {
                switch (o.label) {
                    case 0:
                        return t && t.query && t.query.d ? (e = JSON.parse(t.query.d), console.log("query data:", e), ZmSession.Instance.invid == e.invid ? [3, 2] : (ZmSession.Instance.invid = e.invid, [4, ZmSession.Instance._wxSessionLogin()])) : [2];
                    case 1:
                        o.sent(), o.label = 2;
                    case 2:
                        if (GameSvrLog.Instance.SendShareInfo(e.shareStr, e.shareUri, e.shareOpenId), i = ZmData.Instance.getLastShareType(), i == ShareType.none || !ZmSession.Instance.uid) return [2];
                        if (!e) return [2];
                        if (i == ShareType.zhadan) {
                            if ("zhadan" != e.f) return [2];
                            this.checkQun(t) ? (App.WindowViewManager.close(Views.GameDaojuZhadan), Views.HuodeWupin.huoqu({
                                wpType: Views.WupinType.bomb,
                                num: 1
                            })) : Views.FenxiangErrTip.show(i)
                        } else if (i == ShareType.heidong) {
                            if ("heidong" != e.f) return [2];
                            this.checkQun(t) ? (App.WindowViewManager.close(Views.GameDaojuHeidong), Views.HuodeWupin.huoqu({
                                wpType: Views.WupinType.heidong,
                                num: 1
                            })) : Views.FenxiangErrTip.show(i)
                        } else if (i == ShareType.fuhuo) {
                            if ("fuhuo" != e.f) return [2];
                            n = App.WindowViewManager.getWindowInstance(Views.GameOver), n && (this.checkQun(t) ? n.doRelive() : Views.FenxiangErrTip.show(i))
                        } else if (i == ShareType.passDiammond) {
                            if ("passDiammond" != e.f) return [2];
                            a = App.WindowViewManager.getWindowInstance(Views.GamePass), a && (this.checkQun(t) ? a.doShuangbei() : Views.FenxiangErrTip.show(i))
                        }
                        return App.WindowViewManager.close(Views.FenxiangTip), ZmData.Instance.setLastShareType(ShareType.none), [2]
                }
            })
        })
    }, t.prototype.checkSelf = function(t) {
        return t.invid == ZmSession.Instance.uid
    }, t.prototype.checkQun = function(t) {
        var e = this.getQunId(t);
        if (String.isNullOrEmpty(e)) return Views.FenxiangErrTip.errType = 0, !1;
        var i = ZmData.Instance.getShareData(),
            n = i.qunInfos[e];
        n || (n = 0);
        var a = ZmData.Instance.getLocalSec();
        return 7200 > a - n ? (Views.FenxiangErrTip.errType = 1, !1) : (i.qunInfos[e] = a, ZmData.Instance.saveShareData(), !0)
    }, t.prototype.getQunId = function(t) {
        var e = t.prescene_note;
        if (String.isNullOrEmpty(e)) return "";
        var i = e.indexOf("@");
        return 0 >= i ? "" : e.substr(0, i)
    }, t.prototype.getShareUri = function() {
        var t = ZmSvrCfg.Instance.getShareUri();
        return String.isNullOrEmpty(t) ? "resource/assets/social/wxshare/share1.jpg" : t
    }, t.prototype.shareAppMessage = function(t, e, i) {
        return console.log("shareAppMessage query=" + i), gamePlat == PlatType.limi ? this.shareAppMessage_sq(t, e, i) : this.shareAppMessage_wx(t, e, i)
    }, t.prototype.shareAppMessage_sq = function(t, e, i) {
        return new Promise(function(n, a) {
            BK.QQ.shareToArk(0, t, e, !0, i, function(t, e, i) {
                0 == t ? (console.log(1, 1, "shareToArk ret:" + i.ret + ",aioType:" + i.aioType + ",gameId:" + i.gameId), n(0 == i.ret ? !0 : !1)) : n(!1)
            })
        })
    }, t.prototype.shareAppMessage_wx = function(t, i, n) {
        return wx.shareAppMessage ? DDSDK && DDSDK.ShareAppMessage ? (console.log("使用sdk分享"), DDSDK.ShareAppMessage({
            title: t,
            imageUrl: i
        }), !0) : (console.log("使用wx分享"), this.shareCancel = !1, new Promise(function(a, o) {
            wx.shareAppMessage({
                title: t,
                imageUrl: i,
                query: n,
                success: function(t) {
                    console.log("------ shareAppMessage ok.")
                },
                fail: function(t) {
                    console.log("------ shareAppMessage failed, res: " + JSON.stringify(t))
                },
                complete: function(t) {
                    console.log("------ shareAppMessage complete, res: " + JSON.stringify(t));
                    var e = t.shareTickets;
                    e && e[0] && (t.shareTicket = e[0]), a(t)
                },
                cancel: function(t) {
                    console.log("------ shareAppMessage cancel, res: " + JSON.stringify(t)), e.Instance.shareCancel = !0, a(!1)
                }
            })
        })) : !0
    }, t.prototype.getShareInfo = function(t) {
        return new Promise(function(e, i) {
            wx.getShareInfo({
                shareTicket: t,
                success: function(t) {
                    console.log("------ getShareInfo ok.")
                },
                fail: function(t) {
                    console.log("------ getShareInfo failed, res: " + JSON.stringify(t))
                },
                complete: function(t) {
                    console.log("------ getShareInfo complete, res: " + JSON.stringify(t)), e(t)
                }
            })
        })
    }, t.prototype.doShareAndGetInfo = function(t, e, i, n) {
        return void 0 === i && (i = ""), void 0 === n && (n = !0), __awaiter(this, void 0, void 0, function() {
            var a, o, s;
            return __generator(this, function(r) {
                switch (r.label) {
                    case 0:
                        return [4, this.shareAppMessage(t, e, i)];
                    case 1:
                        return a = r.sent(), a && "shareAppMessage:ok" == a.errMsg && n ? (o = a.shareTicket, o ? [4, this.getShareInfo(o)] : [3, 3]) : [3, 3];
                    case 2:
                        s = r.sent(), s && s.encryptedData && (a.encryptedData = s.encryptedData, a.iv = s.iv), r.label = 3;
                    case 3:
                        return [2, a]
                }
            })
        })
    }, t.prototype.doShareAppMessage = function(t, i, n, a, o) {
        return void 0 === i && (i = "share1"), void 0 === n && (n = ""), void 0 === a && (a = !0), void 0 === o && (o = !0), __awaiter(this, void 0, void 0, function() {
            var s, r;
            return __generator(this, function(h) {
                switch (h.label) {
                    case 0:
                        return o && !ZmSvrCfg.Instance.getShareIsOpen() ? [2, !0] : (String.isNullOrEmpty(t) && (t = ZmSvrCfg.Instance.getShareStr(), String.isNullOrEmpty(t) && (t = "经典祖玛游戏我10秒就能过一关！你敢来挑战我吗？")), [4, ZmSession.Instance.assureSession()]);
                    case 1:
                        return h.sent(), s = e.getShareImgePath(i + ".jpg"), [4, this.doShareAndGetInfo(t, s, n, a)];
                    case 2:
                        return r = h.sent(), Log.trace(JSON.stringify(r)), console.log("res:", r), r && "shareAppMessage:ok" == r.errMsg ? [2, !0] : [2, null]
                }
            })
        })
    }, t.getShareImgePath = function(t) {
        var e = ZmSvrCfg.Instance.getShareUri();
        return String.isNullOrEmpty(e) ? "resource/assets/social/wxshare/" + t : e
    }, t.shareSucTime = 3e3, t = e = __decorate([singleton], t);
    var e
}();
__reflect(ZmShare.prototype, "ZmShare");
var ZmSvrCfg = function() {
    function t() {
        this.maxReqCnt = 3, this.shareIndex = 0
    }
    return t.prototype.loadCfg = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return t = gamePlat == PlatType.limi ? "https://jsonconfig.chiji-h5.com/json/zmj/cfgsq.json?num=" + Math.random() : Util.isQQ() ? "https://jsonconfig.chiji-h5.com/json/zmj/cfgqq.json?num=" + Math.random() : "resource/config/config.json", [4, ZmHttpNet.request(t, "get", "", "application/json")];
                    case 1:
                        return (e = i.sent()) ? (console.log("svrCfg:", e), this.svrCfg = e, this.setConstData(), App.MessageCenter.dispatch(ZmMessageType.SVRCFG_ONLOAD), [3, 4]) : [3, 2];
                    case 2:
                        return console.log("请求svrCfg失败"), this.maxReqCnt-- > 0 ? [4, this.loadCfg()] : [3, 4];
                    case 3:
                        i.sent(), i.label = 4;
                    case 4:
                        return [2]
                }
            })
        })
    }, t.prototype.setConstData = function() {
        this.svrCfg && (this.svrCfg.levelData && this.svrCfg.levelData.length > 1 && (console.log("set levelData"), LevelData.datas = this.svrCfg.levelData), this.svrCfg.fudaiData && this.svrCfg.fudaiData.length > 0 && (console.log("set fudaiData"), Views.FudaiDataItem.datas = this.svrCfg.fudaiData), this.svrCfg.tiliShareVideoCnt && this.svrCfg.tiliShareVideoCnt > 0 && (console.log("set tiliShareVideoCnt"), Views.Tilibuzu.shareVideoCnt = this.svrCfg.tiliShareVideoCnt), this.svrCfg.shareSucTime && this.svrCfg.shareSucTime > 0 && (console.log("set shareSucTime"), ZmShare.shareSucTime = this.svrCfg.shareSucTime))
    }, t.prototype.getSvrCfg = function() {
        return this.svrCfg
    }, t.prototype.getValue = function(t) {
        return this.svrCfg && this.svrCfg[t] ? this.svrCfg[t] : 1
    }, t.prototype.getShareIsOpen = function() {
        if (!this.svrCfg) return !1;
        if (ZmData.Instance.version > this.getVersion()) return !1;
        var t = this.svrCfg.share;
        return "open" == t ? !0 : !1
    }, t.prototype.isTs = function() {
        return this.svrCfg ? ZmData.Instance.version > this.getVersion() ? !0 : !1 : !0
    }, t.prototype.getBannerAdIsOpen = function() {
        if (!this.svrCfg) return !0;
        var t = this.svrCfg.bannerAd;
        return "close" == t ? !1 : !0
    }, t.prototype.getRewardVideoIsOpen = function() {
        if (!this.svrCfg) return !0;
        var t = this.svrCfg.rewardVideo;
        return "close" == t ? !1 : "open" == t ? !0 : ZmData.Instance.version > this.getVersion() ? !1 : !0
    }, t.prototype.getShareStr = function(t, e) {
        return void 0 === t && (t = 0), void 0 === e && (e = -1), this.svrCfg && this.svrCfg.shareStr && this.svrCfg.shareStr.length ? (t > this.svrCfg.shareStr.length - 1 && (t = this.svrCfg.shareStr.length), -1 == e ? e = this.svrCfg.shareStr.length - 1 : t > e && (e = t), this.shareIndex = Util.random(t, e), Util.getArrItem(this.svrCfg.shareStr, this.shareIndex)) : "经典祖玛游戏我10秒就能过一关！你敢来挑战我吗？"
    }, t.prototype.getShareUri = function(t, e) {
        return void 0 === t && (t = 0), void 0 === e && (e = -1), this.svrCfg && this.svrCfg.shareUri && this.svrCfg.shareUri.length ? (t > this.svrCfg.shareUri.length - 1 && (t = this.svrCfg.shareUri.length), -1 == e ? e = this.svrCfg.shareUri.length - 1 : t > e && (e = t), Util.getArrItem(this.svrCfg.shareUri, this.shareIndex)) : "resource/assets/social/wxshare/share1.jpg"
    }, t.prototype.getVersion = function() {
        if (!this.svrCfg) return 0;
        var t = parseInt(this.svrCfg.version);
        return isNaN(t) && (t = 0), t
    }, t.prototype.getRedPackRate = function(t) {
        if (!this.svrCfg || !this.svrCfg.redPackRate || !this.svrCfg.redPackRate.length || 2 > t) return 0;
        var e = Math.min(this.svrCfg.redPackRate.length - 1, t - 1);
        return this.svrCfg.redPackRate[e]
    }, t.prototype.getRedPackIsOpen = function() {
        return !1
    }, t.prototype.getFudaiIsOpen = function() {
        if (!this.svrCfg || Util.isQQ()) return !1;
        if (ZmData.Instance.version > this.getVersion()) return !1;
        var t = this.svrCfg.fudai;
        return "open" == t ? !0 : !1
    }, t = __decorate([singleton], t)
}();
__reflect(ZmSvrCfg.prototype, "ZmSvrCfg");
var GameSvrLog = function() {
    function t() {}
    return e = t, t.prototype.LogEventByShareType = function(t) {
        var e = this.GetEvtType(t);
        this.SendLog({
            event: e
        })
    }, t.prototype.LogEvent = function(t) {
        return;
        this.SendLog({
            event: t
        }), t == e.evt_login && wx.aldSendEvent && wx.aldSendEvent("login", {
            openid: ZmSession.Instance.openId,
            channel: ZmSession.Instance.channel
        })
    }, t.prototype.SendLog = function(t) {}, t.prototype.SendShareInfo = function(t, e, i) {}, t.prototype.GetEvtType = function(t) {
        return t == ShareType.lingquDiammond ? e.evt_shareDiamond : t == ShareType.lingquYaoshi ? e.evt_shareChest : t == ShareType.zhadan ? e.evt_shareZhadan : t == ShareType.heidong ? e.evt_shareHeidong : t == ShareType.fuhuo ? e.evt_shareRelive : t == ShareType.passDiammond ? e.evt_sharePassDiamond : t == ShareType.levelFuhuo ? e.evt_shareLevelRelive : t == ShareType.suipian ? e.evt_shareSuipian : t == ShareType.lixianzuanshi ? e.evt_shareLixianzuanshi : t == ShareType.redPack ? e.evt_shareRedPack : t == ShareType.tili ? e.evt_shareTili : e.evt_shareHomePage
    }, t.evt_shareDiamond = "shareDiamond", t.evt_sharePassDiamond = "sharePassDiamond", t.evt_shareQiandao = "shareQiandao", t.evt_shareHeidong = "shareHeidong", t.evt_shareZhadan = "shareZhadan", t.evt_shareRank = "shareRank", t.evt_shareChest = "shareChest", t.evt_shareRelive = "shareRelive", t.evt_shareSkin = "shareSkin", t.evt_shareKaijudaoju = "shareKaijudaoju", t.evt_shareQiandaoShuangbei = "shareQiandaoShuangbei", t.evt_shareHomePage = "shareHomePage", t.evt_shareTiaozhanhaoyou = "shareTiaozhanhaoyou", t.evt_shareHaoyoujieli = "shareHaoyoujieli", t.evt_shareLevelRelive = "shareLevelRelive", t.evt_shareSuipian = "shareSuipian", t.evt_shareLixianzuanshi = "shareLixianzuanshi", t.evt_shareRedPack = "shareRedPack", t.evt_shareTili = "shareTili", t.evt_login = "login", t = e = __decorate([singleton], t);
    var e
}();
__reflect(GameSvrLog.prototype, "GameSvrLog");
var ZmHelper = function() {
    function t() {}
    return t.buildRectShape = function(t, e, i) {
        void 0 === i && (i = 65280);
        var n = new egret.Shape;
        return n.graphics.beginFill(i, 1), n.graphics.drawRect(0, 0, t, e), n.graphics.endFill(), n
    }, t.loadRemoteImg = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e, i, n, a, o, s;
            return __generator(this, function(r) {
                switch (r.label) {
                    case 0:
                        return e = App.ObjectPool.pickUp(egret.ImageLoader), i = Utility.ZmAsync.FromEvent(e, egret.Event.COMPLETE), e.load(t), [4, i];
                    case 1:
                        return n = r.sent(), App.ObjectPool.putDown(e), n.target.data ? (a = String.digestMD5(t), o = n.target.data, App.NamedCache.cacheObj(a, o), s = new egret.BitmapData(o.source), [2, s]) : [2, null]
                }
            })
        })
    }, t.loadRemoteTexture = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e, i, n, a;
            return __generator(this, function(o) {
                switch (o.label) {
                    case 0:
                        return e = String.digestMD5(t), i = App.NamedCache.getObj(e), null != i ? [3, 2] : [4, this.loadRemoteImg(t)];
                    case 1:
                        return i = o.sent(), [3, 3];
                    case 2:
                        n = new egret.BitmapData(i.source), i = n, o.label = 3;
                    case 3:
                        return i ? (a = new egret.Texture, a._setBitmapData(i), a.disposeBitmapData = !0, [2, a]) : [2, null]
                }
            })
        })
    }, t.loadRemoteImgIntoBitmap = function(t, e) {
        var i = String.digestMD5(e),
            n = App.NamedCache.getObj(i);
        if (null != n) {
            var a = new egret.BitmapData(n.source),
                o = new egret.Texture;
            return t.texture && t.texture.dispose(), o._setBitmapData(a), o.disposeBitmapData = !0, void(t.texture = o)
        }
        this.loadRemoteImg(e).then(function(e) {
            var i = new egret.Texture;
            t.texture && t.texture.dispose(), i._setBitmapData(e), i.disposeBitmapData = !0, t.texture = i
        })
    }, t
}();
__reflect(ZmHelper.prototype, "ZmHelper");
var SkinData = function() {
    function t() {}
    return t
}();
__reflect(SkinData.prototype, "SkinData");
var QiandaoData = function() {
    function t() {
        this.reset()
    }
    return t.prototype.reset = function() {
        this.lastAwardDate = "", this.dayIndex = 0, this.lingqus = [!1, !1, !1, !1, !1, !1, !1]
    }, t.prototype.setValue = function(t) {
        this.lastAwardDate = t.lastAwardDate, this.dayIndex = t.dayIndex, this.lingqus = t.lingqus
    }, t.prototype.canLingqu = function() {
        var t = Util.getDataStr(ZmData.Instance.getLocalDate());
        return String.isNullOrEmpty(this.lastAwardDate) || t > this.lastAwardDate
    }, t
}();
__reflect(QiandaoData.prototype, "QiandaoData");
var RedPackData = function() {
    function t() {
        this.money = 0, this.bDailingqu = !1, this.dayIndex = 0, this.rpNum = 0, this.money.toFixed(2), this.reset()
    }
    return t.prototype.reset = function() {
        this.lastCreateDate = "", this.hbNum = 0
    }, t.prototype.setValue = function(t) {
        this.money = t.money, this.lastCreateDate = t.lastCreateDate, this.hbNum = t.hbNum, this.bDailingqu = t.bDailingqu, this.dayIndex = t.dayIndex, t.rpNum && (this.rpNum = t.rpNum), this.updateState(), App.MessageCenter.dispatch(ZmMessageType.DATA_MONEY_CHANGED)
    }, t.prototype.setDailingqu = function() {}, t.prototype.createRedPack = function() {
        var t = this.getState();
        if (1 == t) return 0;
        if (2 == t) return App.MessageCenter.dispatch(ZmMessageType.DATA_MONEY_CHANGED), 0;
        var e = Math.min(RedPackCfg.moneys.length - 1, Math.floor(this.rpNum / 10)),
            i = this.rpNum % 10,
            n = RedPackCfg.moneys[e][i];
        return this.money > 18 ? n = .01 : this.money + n > 18 && (n = .1), this.money + n >= 19.9 ? 0 : n
    }, t.prototype.canCreateRedPack = function() {
        var t = this.getState();
        return 1 == t ? !1 : !0
    }, t.prototype.getState = function() {
        return this.updateState(), this.money >= 19.9 || !ZmSvrCfg.Instance.getFudaiIsOpen() ? 1 : this.hbNum > 9 ? 1 : 0
    }, t.prototype.updateState = function() {
        var t = Util.getDataStr(ZmData.Instance.getLocalDate());
        t > this.lastCreateDate && (this.hbNum > 0 && (this.dayIndex = Math.min(RedPackCfg.moneys.length - 1, this.dayIndex + 1), this.hbNum = 0), this.lastCreateDate = t)
    }, t.prototype.lingqu = function(t, e) {
        void 0 === e && (e = !1), this.money += t, this.money.toFixed(2), this.money >= 20 && (this.money = 19.9), this.hbNum++, this.rpNum++, e && (this.bDailingqu = !1), App.MessageCenter.dispatch(ZmMessageType.DATA_MONEY_CHANGED)
    }, t.prototype.getMoneyStr = function() {
        var t = this.money.toString(),
            e = t.indexOf(".");
        if (-1 == e) t += ".00";
        else if (t.length - e > 3) t = t.substr(0, e + 3);
        else
            for (; t.length - e < 3;) t += "0";
        return t
    }, t
}();
__reflect(RedPackData.prototype, "RedPackData");
var ZmSvrData = function() {
    function t() {
        this.score = 0, this.chestCnt = 0, this.suipianCnt = 0, this.qiandao = new QiandaoData, this.redPack = new RedPackData
    }
    return t.prototype.setValue = function(t) {
        t.score && (this.score = t.score), t.qiandao && this.qiandao.setValue(t.qiandao), t.chestCnt && (this.chestCnt = Math.max(0, t.chestCnt)), t.suipianCnt && (this.suipianCnt = Math.max(0, t.suipianCnt)), t.redPack && this.redPack.setValue(t.redPack)
    }, t
}();
__reflect(ZmSvrData.prototype, "ZmSvrData");
var ZmFrameListPlayer = function(t) {
    function e() {
        var e = t.call(this) || this;
        return e._sourceDataList = [], e._curFrameIdx = 0, e.frameBase = !1, e.duration = 1e3 / 60, e._frameCount = 0, e.timeScale = 1, e
    }
    return __extends(e, t), e.prototype.clone = function() {
        for (var t = new e, i = 0; i < this._sourceDataList.length; i++) {
            var n = this._sourceDataList[i];
            t._sourceDataList.push({
                source: n.source,
                offsetX: n.offsetX,
                offsetY: n.offsetY,
                texture: n.texture
            })
        }
        return t.frameBase = this.frameBase, t.duration = this.duration, t.scaleX = this.scaleX, t.scaleY = this.scaleY, t
    }, e.prototype.destroy = function() {
        this.stop();
        for (var t = 0; t < this._sourceDataList.length; t++) this._sourceDataList[t].texture && (this._sourceDataList[t].texture = null);
        App.Tool.clearArray(this._sourceDataList), this._sourceDataList = null, this._completeCallFunc = null, this._completeCallthisObj = null, App.Display.removeFromParent(this), this.texture = null
    }, e.prototype.addFrame = function(t, e, i) {
        var n = {
            source: t,
            offsetX: e,
            offsetY: i,
            texture: null
        };
        this._sourceDataList.push(n)
    }, e.prototype.addFrameList = function(t, e, i) {
        void 0 === e && (e = 0), void 0 === i && (i = 0);
        for (var n = 0; n < t.length; n++) this.addFrame(t[n], e, i)
    }, e.prototype.addCompleteCallback = function(t, e) {
        void 0 === e && (e = null), this._completeCallFunc = t, this._completeCallthisObj = e
    }, e.prototype.play = function(t, e, i) {
        void 0 === t && (t = !1), void 0 === e && (e = -1), void 0 === i && (i = -1), i >= 0 && (this._curFrameIdx = i), this._loop = t, 0 >= e && (e = this.duration), this._frameDuration = e, this.visible = !0, this.frameBase ? App.GlobalRepeatTigger.addFrame(this.updateFrame, this, !0) : App.GlobalRepeatTigger.addTime(e, this.updateFrame, this, !0)
    }, e.prototype.stop = function(t, e) {
        void 0 === t && (t = !1), void 0 === e && (e = !1), this.frameBase ? App.GlobalRepeatTigger.removeFrame(this.updateFrame, this) : App.GlobalRepeatTigger.removeTime(this.updateFrame, this), t && (this.visible = !1), e && (this.texture = null), this._completeCallFunc = null, this._completeCallthisObj = null
    }, e.prototype.updateFrame = function() {
        if (this._frameCount++, this.frameBase) {
            if (this._frameCount < this._frameDuration) return;
            this._frameCount = 0
        }
        if (this._curFrameIdx < 0 && (this._curFrameIdx = 0), this._curFrameIdx >= this._sourceDataList.length) {
            if (!this._loop) return this.frameBase ? App.GlobalRepeatTigger.removeFrame(this.updateFrame, this) : App.GlobalRepeatTigger.removeTime(this.updateFrame, this), void(this._completeCallFunc && this._completeCallFunc.call(this._completeCallthisObj, this));
            this._curFrameIdx = 0
        }
        var t = this._sourceDataList[this._curFrameIdx];
        if (!t.texture) {
            var e = t.source;
            t.texture = RES.getRes(e), null == t.texture && Log.trace("FrameList: Can NOT read resource [" + e + "]")
        }
        t.texture != this.texture && (this.texture = t.texture, this.anchorOffsetX = t.offsetX, this.anchorOffsetY = t.offsetY), this._curFrameIdx++
    }, e
}(egret.Bitmap);
__reflect(ZmFrameListPlayer.prototype, "ZmFrameListPlayer");
var LevelData = function() {
    function t() {}
    return t.getData = function(e) {
        return e = Util.clamp(e, 0, t.datas.length - 1), t.datas[e]
    }, t.datas = [{
        startNum: 30,
        mapIndex: 0,
        maxColorNum: 3,
        ballBornRate: [0, 100, 100, 100, 100, 100],
        speed: 20,
        passScore: 200,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: 1,
        maxColorNum: 3,
        ballBornRate: [10, 30, 70, 80, 90, 100],
        speed: 20,
        passScore: 210,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: 2,
        maxColorNum: 4,
        ballBornRate: [10, 30, 70, 80, 90, 100],
        speed: 20,
        passScore: 220,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: 3,
        maxColorNum: 4,
        ballBornRate: [10, 30, 70, 80, 90, 100],
        speed: 19,
        passScore: 230,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: 4,
        maxColorNum: 4,
        ballBornRate: [10, 30, 70, 80, 90, 100],
        speed: 19,
        passScore: 240,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [10, 40, 70, 90, 100, 0],
        speed: 19,
        passScore: 250,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [10, 40, 70, 90, 100, 0],
        speed: 19,
        passScore: 260,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [10, 40, 70, 90, 100, 0],
        speed: 19,
        passScore: 270,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [10, 40, 70, 90, 100, 0],
        speed: 18,
        passScore: 280,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 30,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [10, 40, 70, 90, 100, 0],
        speed: 18,
        passScore: 290,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 18,
        passScore: 300,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 18,
        passScore: 310,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 18,
        passScore: 320,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 17,
        passScore: 330,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 4,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 17,
        passScore: 340,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 17,
        passScore: 350,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 17,
        passScore: 360,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 35,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 17,
        passScore: 370,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 16,
        passScore: 380,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [20, 50, 80, 100, 0, 0],
        speed: 16,
        passScore: 390,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 16,
        passScore: 400,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 16,
        passScore: 410,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 16,
        passScore: 420,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 15,
        passScore: 430,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 15,
        passScore: 440,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 15,
        passScore: 450,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 15,
        passScore: 460,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 38,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 15,
        passScore: 470,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 13,
        passScore: 480,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 13,
        passScore: 490,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [30, 70, 90, 100, 0, 0],
        speed: 13,
        passScore: 500,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 12,
        passScore: 510,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 12,
        passScore: 520,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 12,
        passScore: 530,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 5,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 12,
        passScore: 540,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 11,
        passScore: 550,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 11,
        passScore: 560,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 10,
        passScore: 570,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 10,
        passScore: 580,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 10,
        passScore: 590,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [40, 80, 90, 100, 0, 0],
        speed: 10,
        passScore: 600,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 610,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 620,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 630,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 640,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 650,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 660,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 670,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 40,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 680,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }, {
        startNum: 36,
        mapIndex: -1,
        maxColorNum: 6,
        ballBornRate: [60, 95, 96, 97, 98, 100],
        speed: 10,
        passScore: 690,
        hullRate: 0,
        propBallRate: [1, 1, 1, 1, 1],
        maxShootBallNum: -1
    }], t
}();
__reflect(LevelData.prototype, "LevelData");
var MapData = function() {
    function t() {}
    return t.getData = function(e) {
        return e = Util.clamp(e, 0, t.datas.length - 1), t.datas[e]
    }, t.datas = [{
        pathPoint: [
            [846, 91],
            [222, 90],
            [182, 115],
            [176, 146],
            [177, 722],
            [193, 756],
            [235, 772],
            [644, 710],
            [674, 682],
            [677, 631],
            [648, 196],
            [630, 163],
            [584, 156],
            [307, 173],
            [268, 190],
            [265, 228],
            [264, 627],
            [277, 655],
            [313, 682],
            [603, 520],
            [608, 486],
            [595, 457],
            [431, 248]
        ]
    }, {
        pathPoint: [
            [1, 746],
            [370, 768],
            [508, 756],
            [643, 670],
            [679, 563],
            [689, 428],
            [656, 255],
            [602, 165],
            [583, 127],
            [466, 67],
            [363, 56],
            [260, 105],
            [195, 238],
            [171, 346],
            [170, 459],
            [211, 616],
            [246, 668],
            [323, 691],
            [487, 674],
            [576, 624],
            [588, 564],
            [537, 541],
            [366, 560],
            [298, 554],
            [273, 516],
            [254, 460],
            [254, 327],
            [287, 224],
            [326, 172],
            [377, 145],
            [437, 144],
            [489, 177],
            [546, 238],
            [610, 353],
            [599, 427],
            [542, 450],
            [481, 410]
        ]
    }, {
        pathPoint: [
            [1, 767],
            [148, 767],
            [195, 758],
            [237, 724],
            [278, 691],
            [323, 677],
            [374, 692],
            [436, 721],
            [524, 742],
            [583, 743],
            [619, 730],
            [657, 695],
            [682, 604],
            [699, 497],
            [705, 398],
            [699, 335],
            [678, 285],
            [656, 281],
            [632, 313],
            [578, 460],
            [503, 618],
            [465, 640],
            [436, 633],
            [421, 592],
            [431, 541],
            [504, 433],
            [533, 375],
            [572, 299],
            [592, 218],
            [599, 172],
            [583, 135],
            [542, 108],
            [472, 82],
            [413, 74],
            [336, 72],
            [256, 78],
            [206, 88],
            [175, 119],
            [184, 166],
            [221, 198],
            [272, 204],
            [345, 191],
            [466, 181],
            [498, 208],
            [492, 249],
            [443, 290],
            [345, 275],
            [267, 255],
            [218, 260],
            [191, 281],
            [172, 322],
            [165, 378],
            [165, 458],
            [174, 516],
            [195, 573],
            [236, 599],
            [269, 596],
            [312, 560],
            [365, 498],
            [401, 410]
        ]
    }, {
        pathPoint: [
            [848, 71],
            [731, 68],
            [687, 76],
            [672, 124],
            [676, 370],
            [674, 701],
            [669, 751],
            [629, 777],
            [507, 774],
            [374, 774],
            [248, 773],
            [204, 762],
            [186, 728],
            [186, 575],
            [186, 137],
            [192, 85],
            [233, 64],
            [318, 66],
            [506, 66],
            [560, 76],
            [577, 117],
            [577, 237],
            [577, 497],
            [581, 617],
            [569, 651],
            [537, 671],
            [439, 669],
            [343, 671],
            [305, 656],
            [290, 616],
            [289, 498],
            [290, 346],
            [289, 227],
            [299, 179],
            [337, 164],
            [396, 165],
            [453, 165]
        ]
    }, {
        pathPoint: [
            [848, 757],
            [731, 760],
            [564, 764],
            [430, 764],
            [349, 760],
            [297, 747],
            [251, 719],
            [218, 673],
            [193, 624],
            [176, 572],
            [168, 519],
            [166, 462],
            [167, 390],
            [173, 320],
            [184, 244],
            [216, 163],
            [268, 109],
            [335, 76],
            [412, 66],
            [503, 80],
            [578, 122],
            [622, 174],
            [657, 241],
            [673, 309],
            [681, 383],
            [673, 463],
            [662, 529],
            [649, 571],
            [630, 606],
            [593, 643],
            [525, 677],
            [451, 694],
            [358, 669],
            [295, 617],
            [259, 550],
            [248, 464],
            [248, 389],
            [252, 323],
            [267, 267],
            [292, 220],
            [322, 189],
            [365, 176],
            [417, 176],
            [468, 187],
            [516, 217],
            [543, 261],
            [565, 324],
            [572, 389],
            [564, 446],
            [542, 505],
            [495, 543],
            [440, 541],
            [399, 512],
            [377, 480]
        ]
    }, {
        pathPoint: [
            [848, 84],
            [519, 83],
            [221, 81],
            [189, 85],
            [175, 108],
            [171, 140],
            [177, 174],
            [207, 191],
            [412, 191],
            [603, 192],
            [635, 201],
            [649, 239],
            [645, 278],
            [610, 304],
            [404, 300],
            [229, 296],
            [192, 308],
            [175, 338],
            [176, 374],
            [177, 425],
            [187, 454],
            [223, 469],
            [359, 464],
            [504, 462],
            [531, 487],
            [543, 524],
            [536, 573],
            [499, 597],
            [350, 594],
            [215, 593],
            [187, 602],
            [174, 623],
            [172, 652],
            [180, 686],
            [209, 703],
            [284, 705],
            [408, 704],
            [599, 705]
        ]
    }, {
        pathPoint: [
            [848, 99],
            [693, 96],
            [656, 102],
            [639, 131],
            [641, 172],
            [642, 379],
            [643, 680],
            [633, 713],
            [609, 730],
            [576, 732],
            [546, 721],
            [532, 694],
            [530, 658],
            [532, 405],
            [532, 151],
            [524, 121],
            [496, 97],
            [465, 96],
            [432, 106],
            [417, 134],
            [414, 170],
            [418, 286],
            [417, 393],
            [411, 421],
            [383, 433],
            [363, 412],
            [360, 383],
            [360, 249],
            [361, 123],
            [354, 99],
            [334, 88],
            [310, 95],
            [301, 116],
            [300, 154],
            [301, 431],
            [301, 672],
            [296, 706],
            [269, 725],
            [237, 731],
            [199, 711],
            [192, 682],
            [192, 466],
            [190, 142]
        ]
    }, {
        pathPoint: [
            [10, 772],
            [159, 773],
            [285, 761],
            [418, 734],
            [567, 663],
            [613, 416],
            [555, 176],
            [411, 49],
            [277, 33],
            [163, 72],
            [81, 207],
            [52, 376],
            [87, 566],
            [132, 656],
            [225, 686],
            [435, 653],
            [509, 572],
            [462, 526],
            [206, 555],
            [144, 478],
            [137, 330],
            [174, 186],
            [252, 125],
            [331, 120],
            [411, 159],
            [531, 353],
            [501, 430],
            [423, 429],
            [374, 385]
        ]
    }], t
}();
__reflect(MapData.prototype, "MapData");
var RedPackCfg = function() {
    function t() {}
    return t.getDayIndex = function(e) {
        if (0 == e) return 0;
        for (var i = 29, n = 0; n < t.dayMaxMoneys.length; n++)
            if (e < t.dayMaxMoneys[n]) {
                i = n, n > 0 && e > t.dayMaxMoneys[n - 1] && i++;
                break
            }
        return Math.min(t.moneys.length - 1, i)
    }, t.getNumIndex = function(e) {
        if (0 >= e) return 0;
        for (var i = 0, n = 0, a = 0; a < t.moneys.length; a++)
            for (var o = 0; o < t.moneys[a].length; o++) {
                if (n += t.moneys[a][o], n > e) return i;
                i++
            }
        return i
    }, t.moneys = [
        [1.5, .85, .78, .56, .43, .41, .49, .6, .45, .53],
        [1, .52, .48, .42, .34, .28, .25, .56, .3, .4],
        [.5, .35, .3, .28, .22, .15, .14, .2, .18, .25],
        [.5, .16, .12, .1, .1, .1, .1, .12, .1, .1],
        [.15, .1, .12, .1, .1, .1, .1, .15, .1, .1],
        [.12, .08, .06, .06, .04, .03, .04, .1, .02, .1],
        [.1, .06, .04, .03, .02, .03, .04, .04, .02, .02],
        [.1, .04, .03, .02, .02, .02, .02, .02, .02, .01],
        [.08, .02, .01, .01, .01, .01, .01, .02, .01, .02],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01],
        [.01, .01, .01, .01, .01, .01, .01, .01, .01, .01]
    ], t.dayMaxMoneys = [6.6, 11.15, 13.72, 15.22, 16.34, 16.99, 17.39, 17.69, 17.89, 17.99, 18.09, 18.19, 18.29, 18.39, 18.49, 18.59, 18.69, 18.79, 18.89, 18.99, 19.09, 19.19, 19.29, 19.39, 19.49, 19.59, 19.69, 19.79, 19.89, 19.99], t
}();
__reflect(RedPackCfg.prototype, "RedPackCfg");
var Bezier = function() {
    function t() {}
    return t.init = function(e, i, n, a) {
        return t.p0 = e, t.p1 = i, t.p2 = n, t.ax = t.p0.x - 2 * t.p1.x + t.p2.x, t.ay = t.p0.y - 2 * t.p1.y + t.p2.y, t.bx = 2 * t.p1.x - 2 * t.p0.x, t.by = 2 * t.p1.y - 2 * t.p0.y, t.A = 4 * (t.ax * t.ax + t.ay * t.ay), t.B = 4 * (t.ax * t.bx + t.ay * t.by), t.C = t.bx * t.bx + t.by * t.by, t.len = t.L(1), t.step = Math.floor(t.len / a), t.len % a > a / 2 && t.step++, t.step
    }, t.getAnchorPoint = function(e) {
        if (e >= 0 && e <= t.step) {
            var i = e / t.step,
                n = i * t.len;
            i = t.InvertL(i, n);
            var a = (1 - i) * (1 - i) * t.p0.x + 2 * (1 - i) * i * t.p1.x + i * i * t.p2.x,
                o = (1 - i) * (1 - i) * t.p0.y + 2 * (1 - i) * i * t.p1.y + i * i * t.p2.y,
                s = new egret.Point((1 - i) * t.p0.x + i * t.p1.x, (1 - i) * t.p0.y + i * t.p1.y),
                r = new egret.Point((1 - i) * t.p1.x + i * t.p2.x, (1 - i) * t.p1.y + i * t.p2.y),
                h = r.x - s.x,
                l = r.y - s.y,
                p = Math.atan2(l, h),
                u = 180 * p / Math.PI;
            return new Array(a, o, u)
        }
        return []
    }, t.s = function(e) {
        return Math.sqrt(t.A * e * e + t.B * e + t.C)
    }, t.L = function(e) {
        var i = Math.sqrt(t.C + e * (t.B + t.A * e)),
            n = 2 * t.A * e * i + t.B * (i - Math.sqrt(t.C)),
            a = Math.log(t.B + 2 * Math.sqrt(t.A) * Math.sqrt(t.C)),
            o = Math.log(t.B + 2 * t.A * e + 2 * Math.sqrt(t.A) * i),
            s = 2 * Math.sqrt(t.A) * n,
            r = (t.B * t.B - 4 * t.A * t.C) * (a - o);
        return (s + r) / (8 * Math.pow(t.A, 1.5))
    }, t.InvertL = function(e, i) {
        for (var n, a = e;;) {
            if (n = a - (t.L(a) - i) / t.s(a), Math.abs(a - n) < 1e-6) break;
            a = n
        }
        return n
    }, t
}();
__reflect(Bezier.prototype, "Bezier");
var BallState;
! function(t) {
    t[t.none = 0] = "none", t[t.eliminate = 1] = "eliminate", t[t.destroy = 2] = "destroy"
}(BallState || (BallState = {}));
var BallPropType;
! function(t) {
    t[t.none = 0] = "none", t[t.diamond = 1] = "diamond", t[t.chest = 2] = "chest", t[t.pause = 3] = "pause", t[t.back = 4] = "back", t[t.bomb = 5] = "bomb", t[t.heidong = 6] = "heidong"
}(BallPropType || (BallPropType = {}));
var GameBall = function(t) {
    function e() {
        var i = t.call(this) || this;
        i.colorIndex = 0, i.hasHull = !1, i.propType = BallPropType.none, i.pos = 0, i.state = BallState.none, i.toPos = 0, i.toPosDui = 0, i.toPosSpeed = 0, i.bBomb = !1, i.bDebug = !1;
        var n = new egret.Bitmap;
        return n.texture = e.resPool.getRes("play_json.ball_yinying"), n.anchorOffsetX = n.width / 2, n.anchorOffsetY = n.height / 2, i.addChild(n), i.img = new egret.Bitmap, i.addChild(i.img), i.y = 5e3, i.alpha = 1, i.pos = 0, i
    }
    return __extends(e, t), e.create = function(t, i) {
        void 0 === i && (i = 0);
        var n = Core.ObjPool.getObj(e);
        return n.hasHull = t, n.colorIndex = i, n.alpha = 1, n.bBomb = !1, n
    }, e.prototype.clone = function(t) {
        void 0 === t && (t = !1);
        var i = Core.ObjPool.getObj(e);
        return i.hasHull = t, i.colorIndex = this.colorIndex, i.bBomb = this.bBomb, i.alpha = 1, i
    }, e.prototype.updateImg = function() {
        this.img.texture = e.resPool.getRes(this.getImgName()), this.img.anchorOffsetX = this.img.width / 2, this.img.anchorOffsetY = this.img.height / 2, this.hasHull && (this.imgHull = new egret.Bitmap, this.imgHull.texture = e.resPool.getRes("play_json.hull"), this.imgHull.anchorOffsetX = this.imgHull.width / 2, this.imgHull.anchorOffsetY = this.imgHull.height / 2, this.addChild(this.imgHull)), this.bBomb ? this.scaleX = this.scaleY = .6 : this.scaleX = this.scaleY = 1
    }, e.prototype.getImgName = function() {
        if (this.bBomb) return "play_json.zmj_icon_15";
        var t = 6 * (e.skinId - 1) + (this.colorIndex + 1);
        return "play_json.ball_1_" + (10 > t ? "0" : "") + t
    }, e.prototype.setPropType = function(t) {
        if (this.propType = t, this.propType > BallPropType.none && this.propType <= BallPropType.heidong) {
            var i = e.propIcon[this.propType - 1];
            this.imgProp = Core.ObjPool.getObj(egret.Bitmap), this.imgProp.texture = e.resPool.getRes(i), this.imgProp.x = 0, this.imgProp.y = 0, this.imgProp.anchorOffsetX = this.imgProp.width / 2, this.imgProp.anchorOffsetY = this.imgProp.height / 2, this.imgProp.alpha = 1, this.addChild(this.imgProp), this.imgProp.scaleX = this.imgProp.scaleY = 5, egret.Tween.get(this.imgProp).to({
                scaleX: 1,
                scaleY: 1
            }, 200).call(function() {}, this)
        } else this.propType == BallPropType.none && null != this.imgProp && (this.removeChild(this.imgProp), Core.ObjPool.delObj(egret.Bitmap, this.imgProp), this.imgProp = null)
    }, e.prototype.getPropType = function() {
        return this.propType
    }, e.prototype.setState = function(t) {
        this.state = t
    }, e.prototype.getState = function() {
        return this.state
    }, e.prototype.isActiveState = function(t) {
        return this.state == BallState.none || this.state == BallState.destroy ? !1 : !0
    }, Object.defineProperty(e.prototype, "Pos", {
        get: function() {
            return Math.floor(this.pos)
        },
        set: function(t) {
            this.setPos(t), this.toPos = this.pos
        },
        enumerable: !0,
        configurable: !0
    }), e.prototype.getPos = function() {
        return this.pos
    }, e.prototype.setPos = function(t, i) {
        if (void 0 === i && (i = !0), this.bDebug) {
            if (t - this.pos >= 25);
        }
        t > Zuma.pathPoints.length - 1 && (t = Zuma.pathPoints.length - 1), this.pos = t, i && (this.toPos = this.pos);
        var n = e.getPathPos(this.pos);
        this.x = n.x, this.y = n.y
    }, e.prototype.addPos = function(t) {
        this.setPos(this.getPos() + t)
    }, e.prototype.getToPos = function() {
        return this.toPos
    }, e.getPathPos = function(t) {
        e.tempPos.x = 0, e.tempPos.y = 0;
        var i = Math.floor(t);
        if (i >= Zuma.pathPoints.length) return console.log("err tpos=" + i), e.tempPos;
        var n = Zuma.pathPoints[i][0],
            a = Zuma.pathPoints[i][1],
            o = t - i;
        if (0 != o) {
            var s = o > 0 ? 1 : -1;
            if (i + s >= 0 && i + s < Zuma.pathPoints.length) {
                var r = Zuma.pathPoints[i + s][0],
                    h = Zuma.pathPoints[i + s][1];
                n += (r - n) * Math.abs(o), a += (h - a) * Math.abs(o)
            } else;
        }
        return e.tempPos.x = n, e.tempPos.y = a, e.tempPos
    }, e.prototype.moveTo = function(t, e) {
        void 0 === e && (e = 0), t > Zuma.pathPoints.length - 1 && (t = Zuma.pathPoints.length - 1), this.toPos = t, e > 0 ? (this.toPosDui = e, this.toPosSpeed = Math.abs(this.toPos - this.pos) / e) : this.setPos(t, !1)
    }, e.prototype.update = function(t) {
        this.updatePos(t)
    }, e.prototype.updatePos = function(t) {
        if (this.toPos != this.pos) {
            if (this.toPosDui = Math.max(0, this.toPosDui - t), 0 == this.toPosDui) return void this.setPos(this.toPos);
            var e = Math.abs(this.toPos - this.pos) - this.toPosSpeed * this.toPosDui;
            e > 0 && this.setPos(this.pos + e * (this.toPos > this.pos ? 1 : -1), !1)
        }
    }, e.prototype.eliminate = function(t) {
        var e = this;
        void 0 === t && (t = !1), this.hasHull && !t ? (Util.playEff("qipaosuilie", this.parent, this.x - 80, this.y - 80), this.removeChild(this.imgHull), this.hasHull = !1) : (Util.playEff("xiaochu", this.parent, this.x - 100, this.y - 100), egret.Tween.get(this).to({
            alpha: 0
        }, 100).call(function() {
            e.setState(BallState.destroy), e.destroy()
        }, this))
    }, e.prototype.disappear = function() {
        var t = this;
        egret.Tween.get(this).to({
            alpha: 0
        }, 100).call(function() {
            t.setState(BallState.destroy), t.destroy()
        }, this)
    }, e.prototype.dis = function(t) {
        return Math.sqrt((this.x - t.x) * (this.x - t.x) + (this.y - t.y) * (this.y - t.y))
    }, e.prototype.disPoint = function(t, e) {
        return Math.sqrt((this.x - t) * (this.x - t) + (this.y - e) * (this.y - e))
    }, e.prototype.destroy = function() {
        this.parent && this.parent.removeChild(this), this.hasHull && (this.removeChild(this.imgHull), this.hasHull = !1), this.setPropType(BallPropType.none), Core.ObjPool.delObj(e, this)
    }, e.skinId = 1, e.resPool = new Core.ZmResPool, e.propIcon = ["play_json.zmj_icon_30", "play_json.zmj_icon_31", "play_json.zmj_icon_33", "play_json.zmj_icon_35", "play_json.icon_zhadan", "play_json.icon_heidong"], e.tempPos = new egret.Point, e
}(egret.DisplayObjectContainer);
__reflect(GameBall.prototype, "GameBall");
var Shooter = function(t) {
    function e() {
        var e = t.call(this) || this;
        e.ballColors = [], e.bombCnt = 0, e.bNexting = !1, e.ballNum = -1;
        var i = new egret.Bitmap(RES.getRes("play_json.ji_dianzi"));
        i.anchorOffsetX = 72, i.anchorOffsetY = 72, e.addChild(i);
        var n = new egret.DisplayObjectContainer;
        n.x = -32, n.y = 82, n.scaleX = .9, n.scaleY = .9, e.addChild(n);
        var a = new egret.Bitmap(RES.getRes("play_json.zmj_frame_37"));
        n.addChild(a);
        var o = new egret.TextField;
        o.x = 11, o.bold = !0, o.strokeColor = 990271, o.stroke = 2, o.y = 10, o.text = "999", o.fontFamily = "Microsoft YaHei", o.width = 64, o.textAlign = "center", n.addChild(o), e.grp = new egret.DisplayObjectContainer, e.grp.anchorOffsetX = 72, e.grp.anchorOffsetY = 72, e.addChild(e.grp);
        var s = new egret.Bitmap(RES.getRes("play_json.ji_pao"));
        s.x = 92, s.y = 49, e.grp.addChild(s);
        var r = GameBall.create(!1);
        r.x = 113, r.y = 84, e.grp.addChild(r), e.ball = r, e.ball.visible = !1;
        var h = new egret.Bitmap(RES.getRes("play_json.ji"));
        e.grp.addChild(h), e.imgJiBiyan = new egret.Bitmap(RES.getRes("play_json.ji_biyan")), e.imgJiBiyan.x = 39, e.imgJiBiyan.y = 26, e.imgJiBiyan.visible = !1, e.grp.addChild(e.imgJiBiyan), e.imgJizhengyan = new egret.Bitmap(RES.getRes("play_json.ji_zhengyan")), e.imgJizhengyan.x = 39, e.imgJizhengyan.y = 26, e.grp.addChild(e.imgJizhengyan);
        var l = new egret.DisplayObjectContainer;
        l.x = 6, l.anchorOffsetX = 152, l.anchorOffsetY = 102, l.y = 76, e.addChild(l);
        var p = new egret.Bitmap(RES.getRes("play_json.zmj_frame_36"));
        l.addChild(p);
        var u = new egret.TextField;
        return u.x = 26, u.textColor = 0, u.fontFamily = "Microsoft YaHei", u.size = 24, u.text = "在用完这些球之前通关~", u.y = 26, l.addChild(u), e.grpTip = l, e.grpBallNum = n, e.txtBallNum = o, e.grpTip.visible = !1, e.grpBallNum.visible = !1, e
    }
    return __extends(e, t), e.prototype.init = function(t) {
        this.lData = t, this.setMaxColorNum(this.lData.maxColorNum), this.ball.visible = !1, this.lData.maxShootBallNum && this.lData.maxShootBallNum > 0 && (this.grpTip.visible = !0, this.grpBallNum.visible = !0, this.ballNum = this.lData.maxShootBallNum, this.txtBallNum.text = this.ballNum + "", this.grpTip.alpha = 0, this.grpTip.scaleX = 0, this.grpTip.scaleY = 0, this.grpBallNum.alpha = 0, egret.Tween.get(this.grpTip).to({
            alpha: 1,
            scaleX: 1,
            scaleY: 1
        }, 200, egret.Ease.backOut).wait(2e3).to({
            alpha: 0
        }, 200), egret.Tween.get(this.grpBallNum).to({
            alpha: 1
        }, 500))
    }, e.prototype.canShoot = function() {
        return this.lData ? !this.lData.maxShootBallNum || -1 == this.lData.maxShootBallNum || this.ballNum > 0 : !1
    }, Object.defineProperty(e.prototype, "Angle", {
        get: function() {
            return this.grp.rotation
        },
        set: function(t) {
            this.grp.rotation = t
        },
        enumerable: !0,
        configurable: !0
    }), e.prototype.shoot = function(t) {
        var e = this,
            i = this.ball.clone();
        return i.x = this.x + 60 * Math.cos(t), i.y = this.y + 60 * Math.sin(t), i.radian = t, i.updateImg(), this.ball.visible = !1, this.imgJiBiyan.visible = !0, this.imgJizhengyan.visible = !1, this.bNexting = !0, egret.Tween.get(this.grp).to({
            x: -25 * Math.cos(t),
            y: -25 * Math.sin(t)
        }, 200, egret.Ease.quadInOut).to({
            x: 0,
            y: 0
        }, 200, egret.Ease.quadInOut).call(function() {
            e.imgJiBiyan.visible = !1, e.imgJizhengyan.visible = !0, e.nextBall(), e.bNexting = !1
        }, this), ZmSoundManager.Instance.playSound("fashe"), this.ballNum > 0 && (this.ballNum--, this.txtBallNum.text = this.ballNum + ""), i
    }, e.prototype.nextBall = function() {
        return this.bombCnt > 0 ? (this.ball.visible = !0, void this.bombCnt--) : (0 == this.ballColors.length && (console.log("err shoot color"), this.ballColors.push(0)), this.ball.colorIndex = this.ballColors[Util.random(0, this.ballColors.length - 1)], this.ball.bBomb = !1, this.ball.updateImg(), void(this.ball.visible = !0))
    }, e.prototype.useBomb = function() {
        this.bombCnt = 0, this.ball.bBomb = !0, this.ball.updateImg(), this.bNexting && this.bombCnt++
    }, e.prototype.setMaxColorNum = function(t) {
        this.ballColors = [];
        for (var e = 0; t > e; ++e) this.ballColors.push(e)
    }, e.prototype.removeColor = function(t) {
        for (var e = 0; e < this.ballColors.length; e++) this.ballColors[e] == t && this.ballColors.splice(e, 1)
    }, e.prototype.relive = function() {
        this.lData.maxShootBallNum && this.lData.maxShootBallNum > 0 && (this.ballNum = Math.min(this.lData.maxShootBallNum, this.ballNum + 10), this.txtBallNum.text = this.ballNum + "")
    }, e
}(egret.DisplayObjectContainer);
__reflect(Shooter.prototype, "Shooter");
var ZumaState;
! function(t) {
    t[t.none = 0] = "none", t[t.pause = 1] = "pause", t[t.rollIn = 2] = "rollIn", t[t.rollBack = 3] = "rollBack", t[t.rollStar = 4] = "rollStar", t[t.rollOver = 5] = "rollOver", t[t.over = 6] = "over", t[t.pass = 7] = "pass"
}(ZumaState || (ZumaState = {}));
var LevelPropType;
! function(t) {
    t[t.none = 0] = "none", t[t.wudi = 1] = "wudi", t[t.jiansu = 2] = "jiansu", t[t.diamond = 3] = "diamond", t[t.pifu = 4] = "pifu", t[t.doubleScore = 5] = "doubleScore"
}(LevelPropType || (LevelPropType = {}));
var Zuma = function() {
    function t(e) {
        this.balls = [], this.state = ZumaState.none, this.shooter = new Shooter, this.stars = [], this.waitBallNum = 0, this.lastForwardTime = 0, this.forwardSpeed = 50, this.lastTime = 0, this.lastPropBallTime = 0, this.multHit = 0, this.maxMultHit = 0, this.colorFoldBalls = [], this.shootedBalls = [], this.colledBalls = [], this.backPos = 0, this.level = 1, this.mapIndex = 0, this.pauseForwadTimeLen = 0, this.toPass = !1, this.touchCd = 0, this.forcePropBall = !0, this.bWarning = !1, this.bDanger = !1, this.levelSpeed = 50, this.mianyiBallCnt = 0, this.insertAdd = 0, this.bUseHeidong = !1, this.startNum = 10, this.scoreTimes = 1, this.bInserting = !1, this.starMoveCnt = 0, this.starDelayCnt = 0, this.coColorNum = 1, this.lastColorIndex = 0, this.bHull = !1, this.container = e, this.container.addChild(this.shooter), this.mapOut = new egret.Bitmap, this.mapOut.texture = RES.getRes("play_json.map_out"), this.mapOut.anchorOffsetX = this.mapOut.width / 2, this.mapOut.anchorOffsetY = this.mapOut.height / 2, egret.Tween.get(this.mapOut, {
            loop: !0
        }).to({
            rotation: 360
        }, 3e3), this.container.addChild(this.mapOut), t.diamondLandPos.x = 146, t.diamondLandPos.y = 32 - this.container.y, this.buildStars(), this.container.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this), this.container.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this), this.container.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this), this.container.addEventListener(egret.TouchEvent.TOUCH_CANCEL, this.onTouchEnd, this), this.container.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouchEnd, this), this.container.addEventListener(egret.Event.ENTER_FRAME, this.update, this)
    }
    return t.prototype.buildStars = function() {
        for (var t = RES.getRes("star01_png"), e = RES.getRes("star02_png"), i = RES.getRes("star03_png"), n = [t, t, t, t, t, t, t, e, e, e, e, e, i, i], a = [.4, .5, .6, .7, .8, .9, 1, 1, .9, .8, .7, .6, .5, .4], o = 0; 14 > o; o++) {
            var s = new egret.Bitmap;
            s.texture = n[o], s.scaleX = s.scaleY = a[o], s.anchorOffsetX = 64, s.anchorOffsetY = 64, s.visible = !1, s.blendMode = egret.BlendMode.ADD, this.stars.push(s)
        }
    }, t.prototype.resetStars = function() {
        for (var t = 0; t < this.stars.length; t++) {
            var e = this.stars[t];
            e.visible && (e.visible = !1)
        }
        this.starMoveCnt = 0, this.starDelayCnt = 0
    }, t.prototype.start = function(e, i) {
        this.level = e, this.lData = LevelData.getData(this.level - 1), this.waitBallNum = 1e6, this.lastForwardTime = 0, this.lastTime = 0, this.multHit = 0, this.maxMultHit = 0, this.backPos = 0, this.pauseForwadTimeLen = 0, this.lastPropBallTime = egret.getTimer(), this.toPass = !1, this.touchCd = 0, this.bWarning = !1, this.bDanger = !1, this.bUseHeidong = !1, this.bInserting = !1, this.startNum = this.lData.startNum, this.levelSpeed = this.lData.speed, this.mianyiBallCnt = 0, this.mapIndex = i, this.initPath(), this.initBall(), this.shooter.x = t.ShooterPoss[this.mapIndex][0], this.shooter.y = t.ShooterPoss[this.mapIndex][1], this.shooter.init(this.lData), console.log("this.shooter=", this.shooter), this.mapOut.x = t.pathPoints[t.pathPoints.length - 1][0], this.mapOut.y = t.pathPoints[t.pathPoints.length - 1][1], this.resetStars(), this.checkWarning(), this.setState(ZumaState.rollIn)
    }, t.prototype.relive = function(t) {
        t ? (this.setState(ZumaState.rollBack), this.shooter.relive()) : this.setState(ZumaState.rollOver)
    }, t.prototype.initPath = function() {
        t.pathPoints.length = 0;
        for (var e = MapData.getData(this.mapIndex).pathPoint, i = 0; i < e.length - 2; ++i)
            for (var n = 0 == i ? new egret.Point(e[0][0], e[0][1]) : new egret.Point((e[i][0] + e[i + 1][0]) / 2, (e[i][1] + e[i + 1][1]) / 2), a = new egret.Point(e[i + 1][0], e[i + 1][1]), o = i <= e.length - 4 ? new egret.Point((e[i + 1][0] + e[i + 2][0]) / 2, (e[i + 1][1] + e[i + 2][1]) / 2) : new egret.Point(e[i + 2][0], e[i + 2][1]), s = Bezier.init(n, a, o, 2), r = 1; s >= r; ++r) {
                var h = Bezier.getAnchorPoint(r);
                t.pathPoints.push(h)
            }
    }, t.prototype.initBall = function() {
        for (var t = 0; t < this.balls.length; t++) this.balls[t].destroy();
        this.balls.length = 0;
        for (var t = 0; t < this.shootedBalls.length; t++) this.shootedBalls[t].destroy();
        this.shootedBalls.length = 0, this.colorFoldBalls.length = 0, this.colledBalls.length = 0;
        var e = ZmData.Instance.getCurSkinId();
        this.level > 1 && ZmData.Instance.getIsRandSkin() && (e = ZmData.Instance.getRandSkin()), GameBall.skinId = e
    }, t.prototype.bornBall = function() {
        if (this.state != ZumaState.rollOver && this.state != ZumaState.over) {
            if (this.waitBallNum > 0 && (0 == this.balls.length || this.balls[0].getPos() >= 2 * t.ballWidth)) {
                var e = this.balls.length > 0 && this.balls[0].getPos() < t.ballWidth + 1 ? this.balls[0].getPos() - t.ballWidth : t.ballWidth,
                    i = this.createBall();
                this.balls.unshift(i), this.container.addChild(i), i.setPos(e), this.waitBallNum--
            }
            1 == this.balls.length && (this.balls[0].bDebug = !0)
        }
    }, t.prototype.update = function(e) {
        var i = this.updateDelta();
        if (this.touchCd > 0 && (this.touchCd = Math.max(0, this.touchCd - i)), this.state != ZumaState.pause && this.state != ZumaState.over && this.state != ZumaState.pass && (null == t.actOnCanTouch || t.actOnCanTouch()) && (this.updateBalls(i), this.isAllNotActive()))
            if (this.state == ZumaState.rollIn) this.updateRollIn();
            else if (this.state == ZumaState.rollBack) this.updateRollBack();
        else if (this.state == ZumaState.rollOver) this.updateRollOver();
        else if (this.state == ZumaState.rollStar) this.updateRollStar();
        else if (this.pauseForwadTimeLen > 0 && (0 == this.balls.length ? this.pauseForwadTimeLen = 0 : this.pauseForwadTimeLen -= i), this.updateShootBall(i), !this.updateCollision() && !this.updateColorFold() && this.pauseForwadTimeLen <= 0)
            if (this.toPass) this.starMoveCnt = 0, this.setState(ZumaState.rollStar);
            else if (this.bUseHeidong) this.useHeidong(), this.bUseHeidong = !1;
        else {
            if (0 == this.shootedBalls.length && !this.checkShoot()) return;
            this.goForward(), this.checkPropBall()
        }
    }, t.prototype.updateDelta = function() {
        var t = egret.getTimer(),
            e = t - this.lastTime;
        return this.lastTime = t, e
    }, t.prototype.updateBalls = function(t) {
        for (var e = 0; e < this.balls.length; e++) this.balls[e].update(t)
    }, t.prototype.updateRollIn = function() {
        if (this.balls.length < this.startNum) {
            for (var e = 0; e < this.balls.length; e++) {
                var i = this.balls[e];
                i.addPos(t.ballWidth / 3)
            }
            this.bornBall()
        } else this.shooter.nextBall(), this.setState(ZumaState.none), this.startNum > 10 && (this.startNum = 10)
    }, t.prototype.updateRollBack = function() {
        if (this.backPos <= 0) return void this.setState(ZumaState.none);
        if (0 == this.balls.length) return this.setState(ZumaState.rollIn), void(this.backPos = 0);
        var e = 8,
            i = this.balls.length - 1;
        if (this.balls[i].getPos() - e < t.ballWidth) return this.balls[i].destroy(), this.balls.splice(i, 1), this.setState(ZumaState.rollIn), void(this.backPos = 0);
        for (this.balls[i].setPos(this.balls[i].getPos() - e), i--; i >= 0; i--) {
            var n = this.balls[i + 1].getPos() - this.balls[i].getToPos();
            n < t.ballWidth && this.balls[i].setPos(this.balls[i + 1].getToPos() - t.ballWidth), this.balls[i].getPos() < t.ballWidth && (this.balls[i].destroy(), this.balls.splice(i, 1))
        }
        this.backPos -= e
    }, t.prototype.goForward = function(t) {
        void 0 === t && (t = 0), t || (t = this.forwardSpeed), t != 1 / 0 && (0 != this.balls.length && this.pushBallForward(0, 16 / t), this.bornBall(), this.checkWarning())
    }, t.prototype.checkWarning = function() {
        var e = this.getFirstBallDis();
        8 > e ? this.bWarning || (this.bWarning = !0, this.setForwardTimeSpace(3 * this.levelSpeed), t.actOnWarning && t.actOnWarning(this.bWarning)) : this.bWarning && (this.bWarning = !1, this.setForwardTimeSpace(this.levelSpeed), t.actOnWarning && t.actOnWarning(this.bWarning)), 4.5 > e ? this.bDanger || (this.bDanger = !0, t.actOnDanger && t.actOnDanger(this.bDanger)) : this.bDanger && (this.bDanger = !1, t.actOnDanger && t.actOnDanger(this.bDanger))
    }, t.prototype.pushBallForward = function(e, i) {
        if (!(e > this.balls.length - 1)) {
            this.balls[e].setPos(this.balls[e].getPos() + i);
            for (var n = e; n < this.balls.length - 1; ++n) {
                var a = this.balls[n + 1].getPos() - this.balls[n].getPos();
                a < t.ballWidth && this.balls[n + 1].setPos(this.balls[n].getPos() + t.ballWidth)
            }
            this.balls[this.balls.length - 1].getPos() >= t.pathPoints.length - (t.ballWidth + 1) && (this.mianyiBallCnt > 0 ? (this.balls[this.balls.length - 1].disappear(), this.balls.splice(this.balls.length - 1, 1), this.mianyiBallCnt--) : (this.setState(ZumaState.pause), t.actOnGameOver()))
        }
    }, t.prototype.pushBall = function(e, i, n) {
        if (void 0 === n && (n = 0), !(e > this.balls.length - 1)) {
            if (n > 0);
            this.balls[e].moveTo(this.balls[e].getPos() + i, n);
            for (var a = e; a < this.balls.length - 1; ++a) {
                var o = this.balls[a + 1].getPos() - this.balls[a].getToPos();
                o < t.ballWidth && this.balls[a + 1].moveTo(this.balls[a].getToPos() + t.ballWidth, n)
            }
        }
    }, t.prototype.pushBall1 = function(e, i, n) {
        if (void 0 === n && (n = 0), !(e >= this.balls.length)) {
            var a = new Array;
            a.push(this.balls[e]);
            for (var o = e; o < this.balls.length - 1 && this.balls[o + 1].getPos() - this.balls[o].getPos() <= t.ballWidth + .01; ++o) this.balls[o + 1].getPos() - this.balls[o].getPos() < t.ballWidth - .01 && this.balls[o + 1].setPos(this.balls[o].getPos() + t.ballWidth), a.push(this.balls[o + 1]);
            for (var o = 0; o < a.length; ++o) a[o].moveTo(a[o].getPos() + i, n)
        }
    }, t.prototype.shoot = function() {
        var t = this.shooter.Angle * Math.PI / 180,
            e = this.shooter.shoot(t);
        this.container.addChild(e), this.shootedBalls.push(e)
    }, t.prototype.updateShootBall = function(e) {
        if (0 != this.shootedBalls.length)
            for (var i = 0; i < this.shootedBalls.length; ++i) {
                var n = this.shootedBalls[i],
                    a = (this.container.width - App.LayerManager.stage.stageWidth) / 2;
                if (n.x > 0 && n.x < this.container.width && n.y > 0 && n.y < this.container.height && n.x > a && n.x < App.LayerManager.stage.stageWidth + a) {
                    var o = this.checkCollision(n, e);
                    if (-1 == o);
                    else {
                        var s = Math.max(0, this.balls[o].Pos - t.ballWidth),
                            r = t.pathPoints[s],
                            h = r ? n.disPoint(r[0], r[1]) : 0,
                            l = Math.min(t.pathPoints.length - 1, this.balls[o].Pos + t.ballWidth),
                            p = t.pathPoints[l],
                            u = p ? n.disPoint(p[0], p[1]) : 0,
                            c = h > u;
                        n.bBomb ? (this.doBomb(n, (r[0] + p[0]) / 2, (r[1] + p[1]) / 2), ZmSoundManager.Instance.playSound("zhadan")) : (this.insertBall(n, o, c), ZmSoundManager.Instance.playSound("pengzhuang")), this.shootedBalls.splice(i, 1)
                    }
                } else this.container.removeChild(n), this.shootedBalls.splice(i, 1)
            }
    }, t.prototype.checkCollision = function(e, i) {
        for (var n = -1, a = 2 * t.ballWidth, o = 1e3 * t.ballWidth, s = !0, r = 0; r < this.balls.length; ++r) {
            var h = this.balls[r],
                l = h.x - e.x,
                p = h.y - e.y,
                u = l * Math.cos(e.radian) + p * Math.sin(e.radian);
            if (!(0 > u)) {
                var c = Math.sqrt(l * l + p * p - u * u),
                    d = e.dis(h);
                c < 1 * t.ballWidth ? (o > d && (n = r, a = c, o = d), s = !1) : s && a > c && (n = r, a = c)
            }
        }
        if (-1 == n) return e.x += Math.cos(e.radian) * t.ballWidth, e.y += Math.sin(e.radian) * t.ballWidth, -1;
        for (var g = i / 16, f = 0; f < t.ballWidth; f++) {
            e.x += Math.cos(e.radian) * g, e.y += Math.sin(e.radian) * g;
            var d = e.dis(this.balls[n]);
            if (d < 1.2 * t.ballWidth || d < 2 * t.ballWidth && Math.abs(d - a) < 2) return n
        }
        return -1
    }, t.prototype.insertBall = function(e, i, n) {
        var a, o = this,
            s = -1,
            r = 0;
        n ? (a = this.balls[i].getPos() + t.ballWidth, this.balls[i + 1] && this.balls[i + 1].getPos() - this.balls[i].getPos() < 2 * t.ballWidth && (this.colledBalls.push(new Array(e, this.balls[i + 1])), s = i + 1, r = 2 * t.ballWidth - (this.balls[i + 1].getPos() - this.balls[i].getPos()))) : this.balls[i - 1] && this.balls[i].getPos() - this.balls[i - 1].getPos() < 2 * t.ballWidth ? (a = this.balls[i - 1].getPos() + t.ballWidth, this.colledBalls.push(new Array(e, this.balls[i])), s = i, r = 2 * t.ballWidth - (this.balls[i].getPos() - this.balls[i - 1].getPos())) : a = this.balls[i].getPos() - t.ballWidth, -1 != s && r > 0 && this.pushBall(s, r, 200);
        var h = GameBall.getPathPos(a),
            l = h.x,
            p = h.y;
        this.insertAdd = 0, this.bInserting = !0, egret.Tween.get(e).to({
            x: l,
            y: p
        }, 250).call(function() {
            o.insertAdd > 0, o.bInserting = !1, o.onInsertBall(e, a)
        }, this)
    }, t.prototype.isAllNotActive = function() {
        for (var t = 0; t < this.balls.length; t++) {
            var e = this.balls[t];
            if (e.isActiveState(this.state)) return !1
        }
        return !0
    }, t.prototype.adjustBalls = function() {
        for (var e = 0; e < this.balls.length - 1; ++e) this.balls[e + 1].getPos() - this.balls[e].getPos() < t.ballWidth && this.balls[e + 1].setPos(this.balls[e].getPos() + t.ballWidth)
    }, t.prototype.updateCollision = function() {
        return 0 != this.colledBalls.length || this.bInserting ? !0 : !1
    }, t.prototype.onInsertBall = function(e, i) {
        if (0 != this.balls.length) {
            for (var n, a = 0; a < this.balls.length; ++a) {
                if (this.balls[a].getPos() > i) {
                    n = a;
                    break
                }
                a == this.balls.length - 1 && (n = a + 1)
            }
            this.colledBalls.length > 0 && this.colledBalls.splice(0, 1), e.setPos(i), -1 != this.balls.indexOf(e) ? console.log("err shoot ball") : this.balls.splice(n, 0, e), this.balls[n - 1] && this.balls[n - 1].colorIndex == this.balls[n].colorIndex && this.balls[n].getPos() - this.balls[n - 1].getPos() > t.ballWidth + 1 && this.addColorFoldBall(this.balls[n]), this.balls[n + 1] && this.balls[n + 1].colorIndex == this.balls[n].colorIndex && this.balls[n + 1].getPos() - this.balls[n].getPos() > t.ballWidth + 1 && this.addColorFoldBall(this.balls[n + 1]), this.checkEliminate(n, !0)
        }
    }, t.prototype.checkEliminate = function(e, i) {
        if (e > this.balls.length - 1) return 0;
        var n = new Array;
        n.push(this.balls[e]);
        for (var a = this.balls[e].colorIndex, o = e + 1; this.balls[o] && this.balls[o].colorIndex == a && !(this.balls[o].getPos() - this.balls[o - 1].getPos() > t.ballWidth + 1 && i);) n.push(this.balls[o]), ++o;
        for (o = e - 1; this.balls[o] && this.balls[o].colorIndex == a && !(this.balls[o + 1].getPos() - this.balls[o].getPos() > t.ballWidth + 1 && i);) n.push(this.balls[o]), --o;
        return ++o, n.length > 2 && i && this.eliminate(o, n), n.length
    }, t.prototype.eliminate = function(e, i) {
        if (++this.multHit, this.multHit > 1);
        for (var n = i.length - 1; n >= 0; --n) {
            if (i[n].hasHull);
            else {
                var a = this.balls.indexOf(i[n]);
                a >= 0 && this.balls.splice(a, 1)
            }
            this.doBallEliminate(i[n])
        }
        if (0 == this.balls.length && 0 == this.waitBallNum && this.setState(ZumaState.pass), 0 == this.waitBallNum && this.checkShootColor(i[0].colorIndex), null != t.actOnEliminate) {
            for (var o = 0, s = 0, n = i.length - 1; n >= 0; --n) {
                var r = i[n];
                o += r.x, s += r.y
            }
            o /= i.length, s /= i.length, t.actOnEliminate(i.length, this.multHit, o, s)
        }
        this.multHit > 1 ? this.forcePropBall && (this.checkPropBall(!0, e), this.forcePropBall = !1) : this.forcePropBall = !0, this.balls[e - 1] && this.balls[e] && this.balls[e - 1].colorIndex == this.balls[e].colorIndex ? (this.checkEliminate(e, !1) < 3 && (this.multHit > this.maxMultHit && (this.maxMultHit = this.multHit), t.actOnEliminateEnd && t.actOnEliminateEnd(this.multHit), this.multHit = 0), this.addColorFoldBall(this.balls[e])) : (this.multHit > this.maxMultHit && (this.maxMultHit = this.multHit), t.actOnEliminateEnd && t.actOnEliminateEnd(this.multHit), this.multHit = 0)
    }, t.prototype.doBomb = function(e, i, n) {
        Util.playEff("zhadanbaozha", this.container, i - 160, n - 160);
        for (var a = 0, o = this.balls.length - 1; o >= 0; o--) {
            var s = e.dis(this.balls[o]);
            s <= 6 * t.ballWidth && (this.doBallEliminate(this.balls[o], !0), this.balls.splice(o, 1), a++)
        }
        e.destroy(), a > 0 && null != t.actOnEliminate && t.actOnEliminate(a, 1, i, n)
    }, t.prototype.checkShootColor = function(t) {
        for (var e = 0; e < this.balls.length; ++e)
            if (this.balls[e].colorIndex == t) return;
        for (var i = 0; i < this.shootedBalls.length; ++i)
            if (this.shootedBalls[i].colorIndex == t) return;
        this.shooter.removeColor(t)
    }, t.prototype.addColorFoldBall = function(t) {
        null == this.colorFoldBalls ? (this.colorFoldBalls = [], this.colorFoldBalls.push(t)) : this.colorFoldBalls.push(t)
    }, t.prototype.updateColorFold = function() {
        if (0 == this.colorFoldBalls.length) return !1;
        for (var e = 0; e < this.colorFoldBalls.length; ++e) {
            var i = this.balls.indexOf(this.colorFoldBalls[e]);
            if (-1 != i && this.balls[i - 1])
                if (this.colorFoldBalls[e].colorIndex == this.balls[i - 1].colorIndex) {
                    var n = this.colorFoldBalls[e].getPos() - this.balls[i - 1].getPos() - t.ballWidth;
                    n > 8 && (n = 8), this.pushBall1(i, -(n + .1)), this.colorFoldBalls[e].getPos() - this.balls[i - 1].getPos() <= t.ballWidth && (this.colorFoldBalls.splice(e, 1), 0 == this.colorFoldBalls.length, this.checkEliminate(i - 1, !0))
                } else this.colorFoldBalls.splice(e, 1), this.multHit > this.maxMultHit && (this.maxMultHit = this.multHit), this.multHit = 0;
            else this.colorFoldBalls.splice(e, 1)
        }
        return !0
    }, t.prototype.updateRollOver = function() {
        for (var e = this.balls.length - 1; e >= 0; --e) this.balls[e].getPos() > t.pathPoints.length - (t.ballWidth + 1) ? (this.balls[e].destroy(), this.balls.splice(e, 1), 0 == this.balls.length && this.setState(ZumaState.over)) : this.balls[e].addPos(8)
    }, t.prototype.updateRollStar = function() {
        if (!(this.starDelayCnt++ < 1)) {
            this.starDelayCnt = 0;
            for (var e = 0 == this.balls.length ? t.ballWidth : this.balls[this.balls.length - 1].Pos, i = this.stars.length, n = function(n) {
                    var o = a.stars[n];
                    if (!o.visible) return "continue";
                    var s = e + (a.starMoveCnt - n) * t.ballWidth;
                    if (s >= t.pathPoints.length) {
                        if (o.visible = !1, a.container.removeChild(o), n == i - 1) return a.setState(ZumaState.pass), t.actOnGamePass && t.actOnGamePass(a.getFirstBallDis()), a.toPass = !1, {
                            value: void 0
                        }
                    } else {
                        var r = GameBall.getPathPos(s);
                        o.x = r.x, o.y = r.y
                    }
                    if (0 == n) {
                        var h = 4 + ZmData.Instance.getSkinCnt(),
                            l = new eui.BitmapLabel;
                        l.font = "score_fnt", a.scoreTimes > 1 ? l.text = "+" + h + "*)" : l.text = "+" + h, l.x = o.x, l.y = o.y, l.anchorOffsetX = 60, l.anchorOffsetY = 50, l.scaleX = .5, l.scaleY = .5, a.container.addChild(l), egret.Tween.get(l).to({
                            alpha: 0,
                            y: o.y - 30
                        }, 600, egret.Ease.quadInOut).call(function() {
                            this.container.removeChild(l)
                        }, a), t.actOnStarScore && t.actOnStarScore(h * a.scoreTimes)
                    }
                }, a = this, o = 0; i > o && o < this.starMoveCnt; o++) {
                var s = n(o);
                if ("object" == typeof s) return s.value
            }
            if (this.starMoveCnt < i) {
                var r = this.stars[this.starMoveCnt];
                r.visible = !0, this.container.addChild(r);
                var h = GameBall.getPathPos(e);
                r.x = h.x, r.y = h.y
            }
            this.starMoveCnt++
        }
    }, t.prototype.setState = function(e) {
        if (this.state = e, this.state == ZumaState.none) {
            var i = this.bWarning ? 3 : 1;
            this.setForwardTimeSpace(this.levelSpeed * i)
        } else this.setForwardTimeSpace(1 / 0);
        this.state == ZumaState.rollBack && (this.backPos = 20 * t.ballWidth), t.actOnStateChg && t.actOnStateChg(this.state)
    }, t.prototype.getState = function() {
        return this.state
    }, t.prototype.createBall = function() {
        if (this.coColorNum--, this.coColorNum <= 0)
            for (var t = Util.random(0, 100), e = 0; e < this.lData.ballBornRate.length; ++e)
                if (t < this.lData.ballBornRate[e]) {
                    this.coColorNum = e + 1, this.lastColorIndex = (this.lastColorIndex + Util.random(1, this.lData.maxColorNum - 1)) % this.lData.maxColorNum, this.bHull = Util.random(1, 100) < this.lData.hullRate;
                    break
                }
        var i = GameBall.create(this.bHull, this.lastColorIndex);
        return i.updateImg(), i
    }, t.prototype.checkPropBall = function(t, e) {
        void 0 === t && (t = !1), void 0 === e && (e = 0);
        var i = egret.getTimer(),
            n = t || i - this.lastPropBallTime > 2e4;
        if (n) {
            if (this.lastPropBallTime = i, 0 == this.balls.length) return;
            var a = void 0,
                o = void 0;
            t ? (a = Math.max(0, e - 10), o = Math.min(this.balls.length - 1, e + 10)) : (a = Math.max(0, this.balls.length - 20), o = this.balls.length - 1);
            var s = Util.random(a, o),
                r = this.balls[s];
            if (r.getPropType() != BallPropType.none) {
                for (var h = s + 1; o >= h; ++h) {
                    var l = this.balls[h];
                    if (l.getPropType() == BallPropType.none) {
                        r = l;
                        break
                    }
                }
                if (h == o + 1)
                    for (h = s - 1; h >= 0; --h) {
                        var l = this.balls[h];
                        if (l.getPropType() == BallPropType.none) {
                            r = l;
                            break
                        }
                    }
            }
            for (var p = Math.random(), u = 0; 7 > u && !(p < this.lData.propBallRate[u]); u++);
            r.setPropType(u)
        }
    }, t.prototype.onTouchBegin = function(t) {
        this.canUserCtrl() && !this.checkShoot()
    }, t.prototype.onTouchMove = function(t) {
        this.canUserCtrl() && this.updateShooterAngle(t.stageX, t.stageY)
    }, t.prototype.onTouchEnd = function(t) {
        this.canUserCtrl() && (this.updateShooterAngle(t.stageX, t.stageY), this.shoot(), this.touchCd = 300)
    }, t.prototype.updateShooterAngle = function(t, e) {
        var i = t,
            n = e;
        i -= (App.LayerManager.stage.stageWidth - 640) / 2 + this.container.x - 106, n -= App.LayerManager.stage.stageHeight - 1136 + this.container.y;
        var a = i - this.shooter.x,
            o = n - this.shooter.y,
            s = Math.atan2(o, a);
        this.shooter.Angle = 180 * s / Math.PI;
        for (var r = 0; r < this.balls.length; r++) {
            var h = this.balls[r];
            h.disPoint(this.shooter.x, this.shooter.y)
        }
    }, t.prototype.usePause = function(t) {
        return t ? this.setState(ZumaState.pause) : ZumaState.pause == this.state && this.setState(ZumaState.none), !0
    }, t.prototype.useBomb = function() {
        return this.shooter.useBomb(), !0
    }, t.prototype.useHeidong = function() {
        if (this.state != ZumaState.none) return !1;
        if (0 == this.balls.length) return !1;
        Util.playEff("heidong", this.container, this.container.width / 2 - 256, this.container.height / 2 - 256);
        for (var t = this.balls[Util.random(0, this.balls.length - 1)].colorIndex, e = this.balls.length - 1; e >= 0; e--) {
            var i = this.balls[e];
            i.colorIndex == t && (this.doBallEliminate(i, !0), this.balls.splice(e, 1))
        }
        return ZmSoundManager.Instance.playSound("heidong"), !0
    }, t.prototype.toUseHeidiong = function() {
        this.bUseHeidong = !0
    }, t.prototype.doBallEliminate = function(t, e) {
        void 0 === e && (e = !1), this.doBallProp(t, e), t.eliminate(e)
    }, t.prototype.doBallProp = function(e, i) {
        var n = this;
        void 0 === i && (i = !1);
        var a = e.getPropType();
        if (a != BallPropType.none)
            if (a == BallPropType.diamond) {
                var o = Core.ObjPool.getObj(egret.Bitmap);
                o.texture = GameBall.resPool.getRes("play_json.zmj_icon_01"), o.anchorOffsetX = o.width / 2, o.anchorOffsetY = o.height / 2, o.x = e.x, o.y = e.y, o.alpha = 0, this.container.addChild(o), egret.Tween.get(o).to({
                    x: t.diamondLandPos.x,
                    y: t.diamondLandPos.y,
                    alpha: 1
                }, 1e3, egret.Ease.quadInOut).to({
                    alpha: 0
                }, 100).call(function() {
                    n.container.removeChild(o), ZmData.Instance.addDiamond(1), Core.ObjPool.delObj(egret.Bitmap, o)
                }, this)
            } else a == BallPropType.chest ? t.actOnChest && t.actOnChest() : a == BallPropType.bomb ? this.useBomb() : a == BallPropType.heidong ? this.toUseHeidiong() : i || (a == BallPropType.pause ? this.pauseForwadTimeLen = 5e3 : a == BallPropType.back && (this.setState(ZumaState.rollBack), this.pauseForwadTimeLen = 0))
    }, t.prototype.getFirstBallDis = function() {
        var e = 0;
        return e = 0 == this.balls.length ? t.pathPoints.length / t.ballWidth : (t.pathPoints.length - this.balls[this.balls.length - 1].Pos) / t.ballWidth
    }, t.prototype.goPass = function() {
        this.toPass = !0
    }, t.prototype.canUserCtrl = function() {
        return this.state != ZumaState.none ? !1 : this.touchCd > 0 ? !1 : !0
    }, t.prototype.setForwardTimeSpace = function(t) {
        this.forwardSpeed = t, this.lastForwardTime = egret.getTimer()
    }, t.prototype.onChest = function() {
        t.actOnChest && t.actOnChest()
    }, t.prototype.useLevelProp = function(t) {
        t == LevelPropType.jiansu ? this.levelSpeed = 2 * this.lData.speed : t == LevelPropType.wudi ? this.mianyiBallCnt = 5 : t == LevelPropType.pifu && (GameBall.skinId = Views.LevelProp.pifuId)
    }, t.prototype.checkShoot = function() {
        return this.shooter.canShoot() ? !0 : this.toPass || this.state != ZumaState.none ? !0 : (this.setState(ZumaState.pause), egret.setTimeout(function() {
            t.actOnGameOver(), Core.DialogMod.Instance.Pop("祖玛球用光了！")
        }, this, 500), !1)
    }, t.prototype.destroy = function() {
        this.container.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this), this.container.removeEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this), this.container.removeEventListener(egret.TouchEvent.TOUCH_CANCEL, this.onTouchEnd, this), this.container.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this), this.container.removeEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouchEnd, this), this.container.removeEventListener(egret.Event.ENTER_FRAME, this.update, this)
    }, t.pathPoints = [], t.ballWidth = 25, t.ShooterPoss = [
        [420, 434],
        [415, 302],
        [273, 414],
        [436, 412],
        [408, 348],
        [408, 484],
        [412, 612]
    ], t.diamondLandPos = new egret.Point, t.actOnEliminate = null, t.actOnEliminateEnd = null, t.actOnLevelUp = null, t.actOnStateChg = null, t.actOnCanTouch = null, t.actOnGameOver = null, t.actOnGamePass = null, t.actOnChest = null, t.actOnWarning = null, t.actOnDanger = null, t.actOnStarScore = null, t
}();
__reflect(Zuma.prototype, "Zuma");
var ZmOpenWrap = function() {
    function t() {
        if (wx.getOpenDataContext && !Util.isQQ()) {
            this.opDataCtx = wx.getOpenDataContext();
            var t = {
                msg: "init",
                openid: ZmData.Instance.getOpenId(),
                sWidth: App.LayerManager.stage.stageWidth.toString(),
                sHeight: App.LayerManager.stage.stageHeight.toString()
            };
            this.postMessage(t)
        }
        var e = window.sharedCanvas;
        e && (this.winWidth = e.width, this.winHeight = e.height)
    }
    return t.prototype.getCurDraw = function() {
        return this.curDrawView
    }, t.prototype.getShareBmp = function() {
        return this.sharedBmp
    }, t.prototype.draw = function(t, e, i) {
        return void 0 === e && (e = null), void 0 === i && (i = null), this.opDataCtx ? (this.stopDraw(), this.opDataCtx.postMessage({
            msg: t,
            data: JSON.stringify(i)
        }), this.curDrawView = t, null == this.sharedBmp && this.createBmp(), null != e && e.addChild(this.sharedBmp), this.sharedBmp) : null
    }, t.prototype.stopDraw = function() {
        return this.opDataCtx ? (String.isNullOrEmpty(this.curDrawView) || (this.opDataCtx.postMessage({
            msg: "clear"
        }), App.Display.removeFromParent(this.sharedBmp), this.curDrawView = ""), void this.updateCanvas()) : null
    }, t.prototype.postMessage = function(t) {
        this.opDataCtx && (this.opDataCtx.postMessage(t), this.updateCanvas())
    }, t.prototype.destroy = function() {
        this.stopDraw(), null != this.sharedBmp && this.endCopySharedCanvas()
    }, t.prototype.setWinPer = function(t, e) {
        if (this.opDataCtx) {
            var i = window.sharedCanvas;
            i && (console.log("setWinPer win:", i), i.width = this.winWidth * t, i.height = this.winHeight * e, this.sharedBmp.scaleX = t, this.sharedBmp.scaleY = e, console.log("setWinPer win2:", i))
        }
    }, t.prototype.createBmp = function() {
        var t = window.sharedCanvas;
        this.sharedBmpData && this.sharedBmpData.$dispose(), this.sharedBmpData = new egret.BitmapData(t), this.sharedBmpData.$deleteSource = !1;
        var e = new egret.Texture;
        e._setBitmapData(this.sharedBmpData), this.sharedBmp = new egret.Bitmap(e);
        var i = App.LayerManager.stage.stageWidth,
            n = App.LayerManager.stage.stageHeight,
            a = this.sharedBmp.width / this.sharedBmp.height,
            o = i / n;
        o > a ? (a = i / this.sharedBmp.width, this.sharedBmp.width = i, this.sharedBmp.height = this.sharedBmp.height * a) : (a = n / this.sharedBmp.height, this.sharedBmp.height = n, this.sharedBmp.width = this.sharedBmp.width * a), App.GlobalRepeatTigger.addFrame(this.doCopySharedCanvas, this)
    }, t.prototype.doCopySharedCanvas = function(t) {
        return this.sharedBmpData && (egret.WebGLUtils.deleteWebGLTexture(this.sharedBmpData.webGLTexture), this.sharedBmpData.webGLTexture = null), !1
    }, t.prototype.updateCanvas = function() {
        var t = this;
        Utility.ZmAsync.NextFrame(egret).then(function() {
            return t.doCopySharedCanvas(0)
        })
    }, t.prototype.endCopySharedCanvas = function() {
        App.GlobalRepeatTigger.removeFrame(this.doCopySharedCanvas, this), this.sharedBmp && (App.Display.removeFromParent(this.sharedBmp), this.sharedBmp.texture.dispose(), this.sharedBmp.texture = null, this.sharedBmp = null), this.sharedBmpData = null
    }, t = __decorate([singleton], t)
}();
__reflect(ZmOpenWrap.prototype, "ZmOpenWrap");
var BkBannerAd = function() {
    function t() {
        this.bLoading = !1, this.bHide = !0, this.bShowOnResume = !1, this.bannerHandle = null, App.MessageCenter.addListener(Core.AppMessageType.APP_HIDE, this.onAppHide, this), App.MessageCenter.addListener(Core.AppMessageType.APP_RESUME, this.onAppResume, this)
    }
    return t.prototype.onAppHide = function() {
        this.isShow() && (console.log("BkBannerAd onAppHide"), this.hide(), this.bShowOnResume = !0)
    }, t.prototype.onAppResume = function() {
        var t = this;
        Utility.ZmAsync.NextFrame(egret).then(function() {
            t.bShowOnResume && (console.log("BkBannerAd onAppResume"), t.show(190))
        })
    }, t.prototype.isShow = function() {
        return null != this.bannerHandle || this.bLoading
    }, t.prototype.show = function(t) {
        console.log("banner show "), this.bHide = !1, this.bLoading || this.bannerHandle || (this.bLoading = !0, BK.Advertisement.fetchBannerAd(function(t, e, i) {
            if (console.log("banner retCode:" + t + " msg:" + e), this.bLoading = !1, 0 == t) {
                if (this.bHide) return console.log("banner bHide"), void i.close();
                i.onClickContent(function() {
                    console.log("用户点击了落地页")
                }), i.onClickClose(function() {
                    console.log("用户点击了X关闭广告")
                }), this.showBanner(i)
            } else console.log("fetchBannerAd failed. retCode:" + t)
        }.bind(this)), console.log("banner fetchBannerAd "))
    }, t.prototype.showBanner = function(t) {
        t.show(function(e, i, n) {
            return this.bHide ? (console.log("banner bHide1"), void t.close()) : void(0 == e ? (console.log("banner展示成功 home"), this.bannerHandle = t) : (console.log("banner展示失败home msg:" + i), this.hide()))
        }.bind(this)), console.log("banner showBanner ")
    }, t.prototype.hide = function() {
        this.bannerHandle && !this.bLoading && (this.bannerHandle.close(), this.bannerHandle = null, console.log("banner hide 1")), console.log("banner hide "), this.bHide = !0
    }, t = __decorate([singleton], t)
}();
__reflect(BkBannerAd.prototype, "BkBannerAd");
var Core;
! function(t) {
    var e = function() {
        function t(t) {
            this._skin = t, this._active = !0;
            for (var e in this._skin) egret.DisplayObject.prototype.isPrototypeOf(this._skin[e]) && "hostComponent" != e && "_hostComponent" != e && (this[e] = this._skin[e])
        }
        return t.prototype.destroy = function() {
            for (var t in this._skin) egret.DisplayObject.prototype.isPrototypeOf(this._skin[t]) && "hostComponent" != t && "_hostComponent" != t && delete this[t];
            this._skin = null, this._active = !1
        }, t.prototype.getChild = function(t) {
            return this._skin[t]
        }, t.prototype.callbackProccessor = function(t, e) {
            void 0 === e && (e = null), App.CallbackMappingCenter.doCallback(this, t, e)
        }, t.prototype.bindingCallbackProccessWith = function(t) {
            App.CallbackMappingCenter.register(this.callbackProccessor, this, t)
        }, t
    }();
    t.ZmBaseUnitView = e, __reflect(e.prototype, "Core.ZmBaseUnitView")
}(Core || (Core = {}));
var BANNERAD_PERIOD = 3,
    ZmAdvertisment = function() {
        function t() {
            this._lastStartTick = 0, this.curBannerUnitId = "", this.bannerList = {}, this._bannerAdMap = new Utility.ZmDictionary, Util.isQQ() ? (this.bannerIds = ["bf2912b31d3cbec534dfb88f5aa50227"], this.videoAdUIds = ["55ee94c57e5ae2e78c7d7e4ba2ba9b23", "cc821d4a011d5c869520c7b3985add60"]) : (this.bannerIds = ["adunit-ba3e7d350d00fde0"], this.videoAdUIds = ["adunit-1ec1038b4245fbda", "adunit-b00dfbccd1618634"])
        }
        return e = t, t.prototype.isBannerAdInShowing = function(t) {
            var e = t.toLowerCase().digestMD5(),
                i = this._bannerAdMap.get(e);
            return i ? i.isInShowing : !1
        }, Object.defineProperty(t.prototype, "haveAnyShowingBanner", {
            get: function() {
                var t = this._bannerAdMap.keys;
                if (t && t.length > 0)
                    for (var e = 0, i = t.length; i > e; e++) {
                        var n = this._bannerAdMap.get(t[e]);
                        if (null != n && n.show && n.isInShowing) return n
                    }
                return null
            },
            enumerable: !0,
            configurable: !0
        }), t.prototype.showSingleBannerAd = function(t, e) {
            void 0 === e && (e = -1)
        }, t.prototype.showSingleBannerAd_wx = function(t, e) {
            void 0 === e && (e = -1), this.hideSingleBannerAd(), Util.isQQ() ? this.showBanner(t) : -1 == e ? this.curBannerAd = this.showBannerAd(t, 0, 0, ZmData.Instance.systemInfo.windowWidth, 190) : this.curBannerAd = this.showBannerAd(t, 0, 0, ZmData.Instance.systemInfo.windowWidth, e)
        }, t.prototype.hideSingleBannerAd = function() {
            gamePlat == PlatType.limi ? BkBannerAd.Instance.hide() : Util.isQQ() ? this.hideBanner(this.curBannerUnitId) : this.hideSingleBannerAd_wx()
        }, t.prototype.hideSingleBannerAd_wx = function() {
            null != this.curBannerAd && (this.curBannerAd.hide(), this.curBannerAd = null)
        }, t.prototype.isSingleBannerAdShow = function() {
            return gamePlat == PlatType.limi ? BkBannerAd.Instance.isShow() : Util.isQQ() ? !String.isNullOrEmpty(this.curBannerUnitId) : this.isSingleBannerAdShow_wx()
        }, t.prototype.isSingleBannerAdShow_wx = function() {
            return null != this.curBannerAd
        }, t.prototype.hideAllBannerAd = function() {
            this.hideSingleBannerAd();
            var t = this._bannerAdMap.keys;
            if (t && t.length > 0)
                for (var e = 0, i = t.length; i > e; e++) {
                    var n = this._bannerAdMap.get(t[e]);
                    null != n && n.show && n.hide()
                }
        }, t.prototype.showBanner = function(t) {
            if (wx.createBannerAd) {
                var e = platform.getSystemInfoSync(),
                    i = Util.getClientWindowWidth();
                i || (i = e.windowWidth);
                var n = Util.getClientWindowHeight();
                n || (n = e.windowHeight);
                var a = n - (Util.isIphoneX() ? 110 : 100);
                console.log("showBanner:", a, e.windowWidth, e.windowHeight, App.LayerManager.stage.stageWidth, App.LayerManager.stage.stageHeight, i, n, t), null == this.bannerList[t] && (this.bannerList[t] = wx.createBannerAd({
                    adUnitId: t,
                    style: {
                        left: 0,
                        top: a,
                        width: i,
                        height: 90
                    }
                })), this.bannerList[t] && (this.bannerList[t].show(), this.curBannerUnitId = t)
            }
        }, t.prototype.hideBanner = function(t) {
            console.log("hideBanner id=" + t), null != this.bannerList[t] && (this.bannerList[t].hide(), this.bannerList[t].destroy(), this.bannerList[t] = null), this.curBannerUnitId = ""
        }, t.prototype.showBannerAd = function(t, e, i, n, a, o) {
            void 0 === e && (e = void 0), void 0 === i && (i = void 0), void 0 === n && (n = void 0), void 0 === a && (a = -1), void 0 === o && (o = -1);
            var s = t.toLowerCase().digestMD5(),
                r = this._bannerAdMap.get(s);
            return r || (r = new WxBannerAdWrap(t), this._bannerAdMap.set(s, r)), r.setMaxHeight(a), o >= 0 && r.setPeriod(o), r.show(e, i, n, null), r
        }, t.prototype.hideBannerAd = function(t) {
            var e = t.toLowerCase().digestMD5(),
                i = this._bannerAdMap.get(e);
            i && i.hide()
        }, t.showRewardAd = function(t) {
            var i = Util.getArrItem(e.Instance.videoAdUIds, t);
            return gamePlat == PlatType.limi ? this.showRewardAd_sq() : this.showRewardAd_wx(i)
        }, t.showRewardAd_sq = function() {
            var t = this;
            return console.log("showRewardAd_sq"), BK.Advertisement.fetchVideoAd ? new Promise(function(e, i) {
                BK.Advertisement.fetchVideoAd(0, function(t, i, n) {
                    if (console.log("retCode:" + t + " msg:" + i), 0 == t) {
                        var a = n,
                            o = this;
                        o.bSqVideoOk = !1, a.jump(), a.setEventCallack(function(t, e) {}.bind(this), function(t, e) {
                            0 == t ? (o.bSqVideoOk = !0, console.log("达到看广告时长要求，可以下发奖励 endVide code:" + t + " msg:" + e)) : console.log("其他异常,比如播放视频是程序返回到后台")
                        }.bind(this), function(t, i) {
                            console.log("self.bSqVideoOk=" + o.bSqVideoOk), e(o.bSqVideoOk ? 1 : 0), console.log("关闭视频webview endVide code:" + t + " msg:" + i)
                        }.bind(this), function(t, e) {
                            console.log("开始播放视频 startVide code:" + t + " msg:" + e)
                        }.bind(this))
                    } else e(2), console.log("拉取视频广告失败error:" + t + " msg:" + i)
                }.bind(t))
            }) : Utility.ZmAsync.From(2)
        }, t.showRewardAd_wx = function(t) {
            if (console.log("showRewardAd rewardAdUId=" + t), !wx.createRewardedVideoAd) return Utility.ZmAsync.From(2);
            console.log("showRewardAd 1");
            var e = wx.createRewardedVideoAd({
                adUnitId: t
            });
            if (console.log("showRewardAd 2"), !e) return Log.trace("XX error create RewardedVideoAd!"), Utility.ZmAsync.From(2);
            console.log("showRewardAd 3");
            var i = Utility.ZmAsync.createAsync(),
                n = ZmLoading.Instance.showLoading(""),
                a = function(t) {
                    e.offError(a), Log.trace("reward aid error: " + JSON.stringify(t)), n.close(), Core.DialogMod.Instance.Pop("当前视频已看完，请稍后再试"), i.completion.resolve(2)
                },
                o = function(t) {
                    e.offClose(o), e.offError(a), Log.trace("reward aid result: " + JSON.stringify(t)), n.close(), i.completion.resolve(t && t.isEnded ? 1 : 0)
                };
            return e.onError(a), e.load().then(function() {
                n.close(), e.onClose(o), Log.trace("reward aid [" + t + "] loead"), e.show()
            })["catch"](function() {
                n.close(), i.completion.resolve(2)
            }), console.log("showRewardAd 4"), i.future
        }, t = e = __decorate([singleton], t);
        var e
    }();
__reflect(ZmAdvertisment.prototype, "ZmAdvertisment");
var WxBannerAdWrap = function() {
    function t(t) {
        this._refreshPeriod = BANNERAD_PERIOD, this._lastStartTick = 0, this._bHide = !1, this._curBanner = null, this._adUnitId = t, this._refreshPeriod = BANNERAD_PERIOD, this._lastStartTick = Utility.ZmTime.Ticks, this._loadingBanner = null, this._style = {
            left: 0,
            top: 0,
            width: 640,
            height: 120
        }, this._safeToDestroy = !0, this._isInloading = !1, this._maxHeight = 128
    }
    return Object.defineProperty(t.prototype, "adUnitId", {
        get: function() {
            return this._adUnitId
        },
        enumerable: !0,
        configurable: !0
    }), t.prototype.setMaxHeight = function(t) {
        this._maxHeight = t
    }, t.prototype.setPeriod = function(t) {
        this._refreshPeriod = t
    }, Object.defineProperty(t.prototype, "isInShowing", {
        get: function() {
            return this._curBanner && !this._safeToDestroy
        },
        enumerable: !0,
        configurable: !0
    }), t.prototype.checkAutoDestroy = function() {
        if (this._curBanner) {
            var t = Utility.ZmTime.Ticks,
                e = .001 * (t - this._lastStartTick);
            e >= this._refreshPeriod && (Log.trace("XXXXXX  BannerAd [" + this._adUnitId + "] destroy @tick " + .001 * t), this._curBanner.destroy(), this._curBanner = null)
        }
    }, t.prototype.onDelayToDestroy = function() {
        if (this._safeToDestroy && this._curBanner) {
            var t = .001 * Utility.ZmTime.Ticks;
            Log.trace("XXXXXX BannerAd [" + this._adUnitId + "] delay destroy @tick " + t), this._curBanner.destroy(), this._curBanner = null
        }
    }, t.prototype.onResize = function(t, e, i) {
        e.offResize(i);
        var n = platform.getSystemInfoSync();
        console.log("systemInfo:", n);
        var a = (n.windowWidth / App.LayerManager.stage.stageWidth, n.windowHeight / App.LayerManager.stage.stageHeight),
            o = this._maxHeight * a;
        console.log("adSize:", t);
        var s = n.windowHeight,
            r = n.windowWidth;
        .5 * (r - t.width);
        if (o > 0 && t.height > o) {
            var h = o / t.height;
            e.style.height = o, e.style.width = t.width * h
        }
        e.style.top = s - o, e.style.left = .5 * (r - e.style.width), Log.trace("XXXXXX BannerAd resizing Ad to " + e.style.left + ", " + e.style.top + ", w:" + e.style.width + ", h:" + e.style.height)
    }, t.prototype.show = function(t, e, i, n) {
        var a = this;
        if (void 0 === t && (t = void 0), void 0 === e && (e = void 0), void 0 === i && (i = void 0), !wx.createBannerAd) return null;
        this._loadingBanner && (this._loadingBanner.close(), this._loadingBanner = null);
        var o = this._style;
        void 0 != t && (o.left = t), void 0 != e && (o.top = e), void 0 != i && (o.width = i);
        var s = null;
        if (this.checkAutoDestroy(), this._curBanner) s = this._curBanner, Math.abs(s.style.width - o.width) < 8 ? n && n({
            width: s.style.realWidth,
            height: s.style.realHeight
        }, s) : (n && s.onResize(n), s.style.width = o.width);
        else if (Log.trace("XXXXXX BannerAd [" + this._adUnitId + "] creating at " + JSON.stringify(o)), s = wx.createBannerAd({
                adUnitId: this._adUnitId,
                style: o
            })) {
            this._isInloading = !0;
            var r = this;
            n || (n = function(t) {
                return r.onResize(t, s, n)
            }), s.onResize(n);
            var h = function(t) {
                    r._loadingBanner && (r._loadingBanner.close(), r._loadingBanner = null), s.offError(h), s.destroy(), Log.trace(JSON.stringify(t))
                },
                l = function() {
                    r._loadingBanner && (r._loadingBanner.close(), r._loadingBanner = null), s.offLoad(l), r._curBanner && r._curBanner != s && (r._curBanner.hide(), r._curBanner.destroy()), r._curBanner = s, r._lastStartTick = Utility.ZmTime.Ticks, Log.trace("XXXXXX BannerAd [" + r._adUnitId + "] loaded, @tick " + .001 * r._lastStartTick), Utility.ZmAsync.Defer(1e3 * a._refreshPeriod).then(function() {
                        return r.onDelayToDestroy()
                    }), a._bHide && a.hide()
                };
            s.onLoad(l), s.onError(h), this._bHide = !1
        } else this._loadingBanner && (this._loadingBanner.close(), this._loadingBanner = null), Log.trace("XXXXXX createBannerAd failed.");
        if (s) {
            Log.trace("XXXXXX showing BannerAd  [" + this._adUnitId + "] ");
            try {
                s.show()["catch"](function(t) {
                    Log.trace("XXXXXX BannerAd [" + a._adUnitId + "] show failed: " + t), a._curBanner == s && (a._curBanner = null), a._loadingBanner && (a._loadingBanner.close(), a._loadingBanner = null), s.destroy(), s = null
                }), this._safeToDestroy = !1
            } catch (p) {
                Log.trace("XXXXXX BannerAd [" + this._adUnitId + "] show exception: " + JSON.stringify(p)), this._curBanner == s && (this._curBanner = null), s.destroy(), s = null, this._loadingBanner && (this._loadingBanner.close(), this._loadingBanner = null)
            }
        }
        return s
    }, t.prototype.hide = function(t) {
        if (void 0 === t && (t = !0), this._curBanner) {
            if (this._curBanner.hide(), !t) return;
            this._safeToDestroy = !0, this.checkAutoDestroy()
        }
        this._bHide = !0, this._loadingBanner && (this._loadingBanner.close(), this._loadingBanner = null)
    }, t
}();
__reflect(WxBannerAdWrap.prototype, "WxBannerAdWrap");
var ZmSession = function() {
    function t() {
        this._nickName = "", this._avatar = "", this.invidtype = 0, this.channel = "", this.isInitSDK = !1
    }
    return e = t, Object.defineProperty(t.prototype, "appId", {
        get: function() {
            return this._appId
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "code", {
        get: function() {
            return this._code
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "openId", {
        get: function() {
            return this._openId
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "nickName", {
        get: function() {
            return this._nickName
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "avatar", {
        get: function() {
            return this._avatar
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "avatarPath", {
        get: function() {
            return this._avatar && this._avatar.length > 8 ? this._avatar.substr(8) : ""
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "sessionToken", {
        get: function() {
            return this._sessionToken
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "loginData", {
        get: function() {
            return this._loginData
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "sessionServer", {
        set: function(t) {
            this._sessionServer = t
        },
        enumerable: !0,
        configurable: !0
    }), Object.defineProperty(t.prototype, "isUserInfoOK", {
        get: function() {
            return !String.isNullOrEmpty(this._nickName) && !String.isNullOrEmpty(this._avatar)
        },
        enumerable: !0,
        configurable: !0
    }), t.prototype.init = function(t, e) {
        void 0 === t && (t = null), void 0 === e && (e = null), this._appId = t, this._sessionServer = e, this.resetToken()
    }, t.prototype.resetToken = function() {
        this._sessionToken = null, this._sessionTokenLease = null
    }, t.prototype.setUserInfoByServer = function(t, e) {
        this._nickName = t, this._avatar = e
    }, t.prototype.setUserInfo = function(t) {
        this._loginData = t, this._loginData && (this._nickName = this._loginData.userInfo.nickName, this._avatar = this._loginData.userInfo.avatarUrl)
    }, t.prototype.requestApp = function(t, e, i) {
        return __awaiter(this, void 0, void 0, function() {
            var n;
            return __generator(this, function(a) {
                switch (a.label) {
                    case 0:
                        return ZmData.Instance.noNet ? [2, !1] : [4, ZmHttpNet.request(this._sessionServer + t, e, i, "application/x-www-form-urlencoded")];
                    case 1:
                        return n = a.sent(), [2, n]
                }
            })
        })
    }, t.prototype.request = function(t, e, i) {
        return __awaiter(this, void 0, void 0, function() {
            var n;
            return __generator(this, function(a) {
                switch (a.label) {
                    case 0:
                        return t.indexOf("http") < 0 && (t = "https://" + t), Log.trace("session server request: \r\n    url=" + t + ",method=" + e + ",data=" + JSON.stringify(i)), [4, platform.request(t, e, i, "application/x-www-form-urlencoded")];
                    case 1:
                        return n = a.sent(), Log.trace("session server result: \r\n    " + JSON.stringify(n)), n && n.data ? "request:ok" != n.errMsg ? (Log.trace("session server error from " + t), Log.trace(' response: errMsg: "' + n.errMsg + '", status code: ' + n.statusCode), [2, null]) : (200 != n.statusCode && (Log.trace("session server unexpected result from " + t), Log.trace(' response: "' + JSON.stringify(n.errMsg) + '", status code: ' + n.statusCode)), [2, n.data]) : (Log.trace("session server net error from " + t), [2, null])
                }
            })
        })
    }, t.prototype.uploadData = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(e) {
                return t.nick = "zumaji001", t.openid = "zumaji001", console.log("缓存数据:", t), this.saveStorage("zumaji", JSON.stringify(t)), [2]
            })
        })
    }, t.prototype.loadStorage = function(t) {
        return App.LocalStorageData.load(t)
    }, t.prototype.saveStorage = function(t, e) {
        App.LocalStorageData.save(t, String(e))
    }, t.prototype.updateServerSession = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return [4, this.updateServerSession_wx()];
                    case 1:
                        return [2, t.sent()]
                }
            })
        })
    }, t.prototype.updateServerSession_wx = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        return this._sessionServer && this._code ? (console.log("this.invid:", this.invid), t = this.invid ? {
                            code: this._code,
                            channel: this.channel,
                            inviteid: this.invid,
                            invitetype: this.invidtype
                        } : {
                            code: this._code,
                            channel: this.channel
                        }, e = null, "MockCode" != this._code ? [3, 1] : (e = {
                            data: {
                                openid: "test001",
                                id: "0",
                                dataParm: {}
                            }
                        }, [3, 5])) : [2, !1];
                    case 1:
                        return Util.isQQ() ? [4, this.requestApp("/login.action", "post", t)] : [3, 3];
                    case 2:
                        return e = i.sent(), [3, 5];
                    case 3:
                        return [4, this.requestApp("/newlogin.action", "post", t)];
                    case 4:
                        e = i.sent(), i.label = 5;
                    case 5:
                        return e = this.loadStorage("zumaji"), console.log("读取缓存数据"), console.log(JSON.parse(e)), e = e ? {
                            data: {
                                udata: e
                            }
                        } : {
                            data: {
                                openid: "zumaji001",
                                id: "0",
                                dataParm: {}
                            }
                        }, [4, this.onLogin(e)];
                    case 6:
                        return i.sent(), [2, !0]
                }
            })
        })
    }, t.prototype.onLogin = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            var e, i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        this._openId = t.data.openid, this.uid = t.data.id, console.log("openid=" + this.openId), e = new Date, this._sessionTokenLease || (this._sessionTokenLease = e), t.lease ? this._sessionTokenLease.setTime(e.getTime() + 1e3 * (t.lease - 5)) : this._sessionTokenLease.setTime(e.getTime() + 999999e3), ZmData.Instance.setOpenId(this._openId), t.data.keys ? ZmData.Instance.setYaoshiCnt(t.data.keys) : ZmData.Instance.setYaoshiCnt(0);
                        try {
                            i = JSON.parse(t.data.udata)
                        } catch (a) {
                            console.log("udata err=" + a)
                        }
                        return null != i && (i.nick && (this._nickName = i.nick), i.avatar && (this._avatar = i.avatar), ZmData.Instance.setSvrData(i)), t.time && ZmData.Instance.updateTime(t.time), [4, this.updateMoney()];
                    case 1:
                        return n.sent(), [4, Views.Pifu.updateData()];
                    case 2:
                        return n.sent(), [2]
                }
            })
        })
    }, t.prototype.updateMoney = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                return [2]
            })
        })
    }, t.prototype._wxSessionLogin = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return GameStatusInfo ? [4, this._wxSessionLogin_sq()] : [3, 2];
                    case 1:
                        return t.sent(), [3, 4];
                    case 2:
                        return [4, this._wxSessionLogin_wx()];
                    case 3:
                        t.sent(), t.label = 4;
                    case 4:
                        return [2]
                }
            })
        })
    }, t.prototype._wxSessionLogin_sq = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        t = 0, i.label = 1;
                    case 1:
                        return t++, [4, this.updateServerSession()];
                    case 2:
                        return e = i.sent(), e ? [3, 6] : [4, Utility.ZmAsync.Defer(1e3)];
                    case 3:
                        return i.sent(), t % 10 != 9 ? [3, 5] : (Core.DialogMod.Instance.Pop("网络不好，请检查网络"), [4, Utility.ZmAsync.Defer(5e3)]);
                    case 4:
                        i.sent(), i.label = 5;
                    case 5:
                        return [3, 1];
                    case 6:
                        return [4, this.checkUserInfo()];
                    case 7:
                        return i.sent(), [2, !0]
                }
            })
        })
    }, t.prototype._wxSessionLogin_wx = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e, i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        return [4, platform.login()];
                    case 1:
                        if (t = n.sent(), Log.trace("WxSession login: " + JSON.stringify(t)), !t || !t.code) return [3, 8];
                        this._code = t.code, e = 0, n.label = 2;
                    case 2:
                        return e++, [4, this.updateServerSession()];
                    case 3:
                        return i = n.sent(), i ? [3, 6] : e % 10 != 9 ? [3, 5] : [4, platform.showModal(ZmData.Instance.appName, "网络不好，请检查网络", !1)];
                    case 4:
                        n.sent(), n.label = 5;
                    case 5:
                        return [3, 2];
                    case 6:
                        return [4, this.checkUserInfo()];
                    case 7:
                        return n.sent(), [2, !0];
                    case 8:
                        return [2, !1]
                }
            })
        })
    }, t.prototype._checkSessionToken = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t;
            return __generator(this, function(e) {
                return this._sessionTokenLease && (t = new Date, t.getTime() < this._sessionTokenLease.getTime()) ? [2, !0] : [2, !1]
            })
        })
    }, t.prototype.assureSession = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return ZmData.Instance.noNet ? [2, !0] : GameStatusInfo ? [4, this.assureSession_sq()] : [3, 2];
                    case 1:
                        return t.sent(), [3, 4];
                    case 2:
                        return [4, this.assureSession_wx()];
                    case 3:
                        t.sent(), t.label = 4;
                    case 4:
                        return [2]
                }
            })
        })
    }, t.prototype.assureSession_sq = function() {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return [4, this._wxSessionLogin()];
                    case 1:
                        return t.sent(), [2]
                }
            })
        })
    }, t.prototype.assureSession_wx = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t, e, i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        return console.log("assureSession"), t = !0, this._openId ? (console.log("assureSession checkSession openId=" + this._openId), [4, platform.checkSession()]) : [3, 2];
                    case 1:
                        e = n.sent(), e && (t = !1), n.label = 2;
                    case 2:
                        return console.log("assureSession needUpdate"), t ? (Log.trace("wx session need update"), [4, this._wxSessionLogin()]) : [3, 4];
                    case 3:
                        return n.sent(), [2];
                    case 4:
                        return [4, this._checkSessionToken()];
                    case 5:
                        return i = n.sent(), (t = !i) ? (Log.trace("server session need update"), [4, this._wxSessionLogin()]) : [3, 7];
                    case 6:
                        n.sent(), n.label = 7;
                    case 7:
                        return [2]
                }
            })
        })
    }, t.prototype.checkUserInfo = function() {
        return String.isNullOrEmpty(e.Instance.nickName) && wx.getSetting ? new Promise(function(t, i) {
            wx.getSetting({
                success: function(i) {
                    i.authSetting["scope.userInfo"] ? wx.getUserInfo({
                        success: function(i) {
                            console.log(i.userInfo), e.Instance.setUserInfo(i), t(i)
                        }
                    }) : t()
                }
            })
        }) : void 0
    }, t.prototype.decrypteCredentialData = function(t, e) {
        return __awaiter(this, void 0, void 0, function() {
            var i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        return this._sessionServer ? [4, this.requestApp("/wxdecode/with", "get", {
                            token: this._sessionToken,
                            data: t,
                            iv: e
                        })] : [2, null];
                    case 1:
                        return i = n.sent(), i ? [2, i.plainText] : [2, null]
                }
            })
        })
    }, t.prototype.reqShare = function(t, e) {
        return __awaiter(this, void 0, void 0, function() {
            var i;
            return __generator(this, function(n) {
                switch (n.label) {
                    case 0:
                        return this._sessionServer ? [4, this.requestApp("/share.action", "get", {
                            openid: this._openId,
                            encryptedData: t,
                            iv: e,
                            gettype: 0
                        })] : [2, !0];
                    case 1:
                        return i = n.sent(), console.log("reqShare res:", i), i ? (console.log("reqShare res.ret:", i.ret), [2, 0 != parseInt(i.ret)]) : [2, !0]
                }
            })
        })
    }, t = e = __decorate([singleton], t);
    var e
}();
__reflect(ZmSession.prototype, "ZmSession");
var ZmSoundManager = function() {
    function t() {
        this._innerAudioContextMap = new Core.ZmHashMap
    }
    return e = t, t.prototype.loadSoundConfig = function(t) {
        return __awaiter(this, void 0, void 0, function() {
            return __generator(this, function(t) {
                switch (t.label) {
                    case 0:
                        return [4, this.initSound("button", "resource/assets/sound/button.mp3", !1)];
                    case 1:
                        return t.sent(), [4, this.initSound("bgm", "resource/assets/sound/bgm.mp3", !0)];
                    case 2:
                        return t.sent(), [4, this.initSound("fashe", "resource/assets/sound/fashe.mp3", !1)];
                    case 3:
                        return t.sent(), [4, this.initSound("pengzhuang", "resource/assets/sound/pengzhuang.mp3", !1)];
                    case 4:
                        return t.sent(), [4, this.initSound("xiaochu1", "resource/assets/sound/xiaochu1.mp3", !1)];
                    case 5:
                        return t.sent(), [4, this.initSound("xiaochu2", "resource/assets/sound/xiaochu2.mp3", !1)];
                    case 6:
                        return t.sent(), [4, this.initSound("xiaochu3", "resource/assets/sound/xiaochu3.mp3", !1)];
                    case 7:
                        return t.sent(), [4, this.initSound("xiaochu4", "resource/assets/sound/xiaochu4.mp3", !1)];
                    case 8:
                        return t.sent(), [4, this.initSound("beidong", "resource/assets/sound/beidong.mp3", !1)];
                    case 9:
                        return t.sent(), [4, this.initSound("zhadan", "resource/assets/sound/zhadan.mp3", !1)];
                    case 10:
                        return t.sent(), [2]
                }
            })
        })
    }, t.prototype.initSound = function(t, e, i) {
        return __awaiter(this, void 0, void 0, function() {
            var n;
            return __generator(this, function(a) {
                switch (a.label) {
                    case 0:
                        return (n = gamePlat == PlatType.wx ? platform.createInnerAudioContext() : new SoundWrap) ? (n.name = t, n.loop = i, n.obeyMuteSwitch = !0, gamePlat == PlatType.limi ? n.src = "GameRes://" + e : n.src = e, this._innerAudioContextMap.add(t, n), gamePlat == PlatType.wx ? [3, 2] : [4, n.init()]) : [3, 2];
                    case 1:
                        a.sent(), a.label = 2;
                    case 2:
                        return [2]
                }
            })
        })
    }, t.prototype.playSound = function(t) {
        if (ZmData.Instance.getIsSoundOpen()) {
            var e = this._innerAudioContextMap.getValue(t);
            return e && (e.obeyMuteSwitch = !0, e.seek(.01), e.play()), e
        }
    }, t.prototype.stopSound = function(t) {
        var e = this._innerAudioContextMap.getValue(t);
        e && e.pause()
    }, t.prototype.stopAllSound = function() {
        for (var t = 0, e = this._innerAudioContextMap.valueList; t < e.length; t++) {
            var i = e[t];
            i.pause()
        }
    }, t.prototype.openSound = function() {
        ZmData.Instance.getIsSoundOpen() || (ZmData.Instance.setIsSoundOpen(!0), e.Instance.playSound("bgm"))
    }, t.prototype.closeSound = function() {
        ZmData.Instance.getIsSoundOpen() && (this.stopAllSound(), ZmData.Instance.setIsSoundOpen(!1))
    }, t = e = __decorate([singleton], t);
    var e
}();
__reflect(ZmSoundManager.prototype, "ZmSoundManager");
var SoundWrap = function() {
    function t() {
        this.sound = null, this.channel = null
    }
    return t.prototype.init = function() {
        return __awaiter(this, void 0, void 0, function() {
            var t;
            return __generator(this, function(e) {
                switch (e.label) {
                    case 0:
                        return t = this, console.log("sound that.src=" + t.src), [4, new Promise(function(e, i) {
                            function n(i) {
                                t.sound = i, e()
                            }
                            RES.getResByUrl(t.src, n, t, RES.ResourceItem.TYPE_SOUND)
                        })];
                    case 1:
                        return e.sent(), [2]
                }
            })
        })
    }, t.prototype.seek = function(t) {
        this.channel && (this.channel.position = t)
    }, t.prototype.play = function() {
        console.log("playsound name=" + this.name + ",this.sound=" + this.sound), this.sound && (this.channel && (this.channel.stop(), this.channel = null), this.channel = this.sound.play(0, this.loop ? -1 : 1))
    }, t.prototype.pause = function() {
        this.sound && this.channel && (this.channel.stop(), this.channel = null)
    }, t
}();
__reflect(SoundWrap.prototype, "SoundWrap");
var ZmHttpNet = function() {
    function t() {}
    return t.request = function(t, e, i, n) {
        return void 0 === e && (e = "get"), void 0 === i && (i = ""), void 0 === n && (n = "application/json"), __awaiter(this, void 0, void 0, function() {
            var a = this;
            return __generator(this, function(o) {
                return Log.trace("net request: url=" + t + ",method=" + e + ",data=" + JSON.stringify(i)), [2, new Promise(function(o, s) {
                    function r(t) {
                        var e = t.currentTarget;
                        Log.trace("net response: " + e.response);
                        var i = e.response;
                        try {
                            i = JSON.parse(e.response)
                        } catch (n) {
                            console.log("err json parse")
                        }
                        o(i)
                    }

                    function h(t) {
                        Log.trace("response: err:" + t), o(null)
                    }
                    var l = new egret.HttpRequest;
                    if (l.responseType = egret.HttpResponseType.TEXT, l.addEventListener(egret.Event.COMPLETE, r, a), 
					l.addEventListener(egret.IOErrorEvent.IO_ERROR, h, a), "get" == e) 
						l.open(t, egret.HttpMethod.GET), l.setRequestHeader("Content-Type", n), l.send();
                    else if (l.open(t, egret.HttpMethod.POST), l.setRequestHeader("Content-Type", n), i)
                        if (gamePlat == PlatType.limi)
                            if ("string" == typeof i) l.send(i);
                            else {
                                var p = Util.getKvStr(i);
                                // l.send(p)
                            }
                    // else l.send(i);
                    // else l.send()
                })]
            })
        })
    }, t.request1 = function(t, e, i, n) {
        return void 0 === e && (e = "get"), void 0 === i && (i = ""), void 0 === n && (n = "application/json"), __awaiter(this, void 0, void 0, function() {
            var a;
            return __generator(this, function(o) {
                switch (o.label) {
                    case 0:
                        return t.indexOf("http") < 0 && (t = "https://" + t), Log.trace("session server request: \r\n    url=" + t + ",method=" + e + ",data=" + JSON.stringify(i)), [4, platform.request(t, e, i, n)];
                    case 1:
                        return a = o.sent(), Log.trace("session server result: \r\n    " + JSON.stringify(a)), a && a.data ? "request:ok" != a.errMsg ? (Log.trace("HttpNet error from " + t), Log.trace(' response: errMsg: "' + a.errMsg + '", status code: ' + a.statusCode), [2, null]) : 200 != a.statusCode ? (Log.trace("HttpNet unexpected result from " + t), Log.trace(' response: "' + JSON.stringify(a.errMsg) + '", status code: ' + a.statusCode), [2, null]) : [2, a.data] : (Log.trace("HttpNet net error from " + t), [2, null])
                }
            })
        })
    }, t.prototype.setup = function(t) {
        this._host = t, this._token = null
    }, t.prototype.request = function(t, e, i) {
        function n(t) {
            var n = t.currentTarget;
            Log.trace("<<HTTP Response: " + n.response);
            var a = JSON.parse(n.response);
            void 0 != a.token && (this._token = a.token), e.call(i, a)
        }

        function a(t) {
            Log.trace("<<HTTP Response: IO_ERROR"), e.call(i, {
                result: "IO_ERROR"
            })
        }
        void 0 === e && (e = null), void 0 === i && (i = null);
        var o;
        o = 0 == t.toLowerCase().indexOf("https://") ? t : this._host + t;
        var s = new egret.HttpRequest;
        s.responseType = egret.HttpResponseType.TEXT, null != e && (s.addEventListener(egret.Event.COMPLETE, n, this), s.addEventListener(egret.IOErrorEvent.IO_ERROR, a, this)), s.open(o, egret.HttpMethod.GET), this._token && s.setRequestHeader("Token", this._token), Log.trace("  >>HTTP Request: " + o), s.send()
    }, t = __decorate([singleton], t)
}();
__reflect(ZmHttpNet.prototype, "ZmHttpNet");
var ZmSharing = function() {
    function t() {}
    return t.checkShareToSameGroup = function(t, e, i) {
        return void 0 === i && (i = 72e5), __awaiter(this, void 0, void 0, function() {
            var n, a, o, s, r, h, l, p, u, c, d;
            return __generator(this, function(g) {
                switch (g.label) {
                    case 0:
                        return ZmSession.Instance.openId ? (n = i, a = ZmSession.Instance.openId + t, o = null, platform.getStorage ? [4, platform.getStorage(a)] : [3, 2]) : [2, !1];
                    case 1:
                        return o = g.sent(), [3, 3];
                    case 2:
                        o = App.LocalStorageData.load(a), g.label = 3;
                    case 3:
                        return s = new Date, r = s.getTime(), h = e.openGId, l = null, p = !1, l = o ? JSON.parse(o) : {
                            groups: {}
                        }, u = l.groups[h], u ? 0 >= n ? p = !0 : (c = u.timeStamp, d = r - c, n > d ? p = !0 : u.timeStamp = r) : u = {
                            timeStamp: r
                        }, l.groups[h] = u, o = JSON.stringify(l), platform.setStorage ? [4, platform.setStorage(a, o)] : [3, 5];
                    case 4:
                        return g.sent(), [3, 6];
                    case 5:
                        App.LocalStorageData.save(a, o), g.label = 6;
                    case 6:
                        return [2, p]
                }
            })
        })
    }, t
}();
__reflect(ZmSharing.prototype, "ZmSharing");
var VideoReward_4399 = function() {
    function t() {
        this.videoStatus = 0
    }
    return Object.defineProperty(t, "instace", {
        get: function() {
            return this.getInstance()
        },
        enumerable: !0,
        configurable: !0
    }), t.getInstance = function() {
        var t = this;
        return null == t.__instance && (t.__instance = new t), t.__instance
    }, t.prototype.playVideo = function(t, e) {
        console.log("调用 `播放全屏广告`");
        try {
			console.log("广告场景"); 
			window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.REWARD_CLICK,"showRewardVideoAd");
			HUHU_showRewardedVideoAd(()=>{
				t.call(e);
			},()=>{
				promptTxT("No ads temporarily");
			})
            //fbSDK.showRewardVideoAd(t,e);
            // "egret_4399_h5api" in window ? egret_4399_h5api.canPlayAd() ? egret_4399_h5api.playAd(function(i) {
            //     console.log("播放广告回调数据", i), i && "10001" == i.code ? t.call(e) : i && "10000" == i.code
            // }) : (t.call(e), console.log("没有广告资源可播放"), App.Dialog.Pop("没有广告资源可播放")) : (console.log("找不到 4399HTML5 API"), App.Dialog.Pop("没有广告资源可播放"))
        } catch (i) {}
    }, t.prototype.checkVideo2 = function() {
        try {
            if ("egret_4399_h5api" in window) {
                var t = egret_4399_h5api.canPlayAd(function(t) {});
                return t ? (this.videoStatus = 1, !0) : (this.videoStatus = -1, !1)
            }
            return //console.log("找不到 4399HTML5 API"), 
			this.videoStatus = 1, !0
        } catch (e) {
            return !1
        }
    }, t
}();
__reflect(VideoReward_4399.prototype, "VideoReward_4399");
var Views;
! function(t) {
    var e = function(e) {
        function i() {
            var n = e.call(this, ZmPlaySceneSkin) || this;
            return n.isPause = !1, n.propTipFlag = 0, n.passScore = 200, n.passDiamondRate = 1, n.bShowHeidong = !0, n.lastHongbaoTime = 0, n.scoreTimes = 1, i.ins = n, App.Display.addButtonPushEffect(n.btnPause, n.onBtnPause, n), App.Display.addButtonPushEffect(n.btnBomb, n.onBtnBomb, n), App.Display.addButtonPushEffect(n.btnHeidong, n.onBtnHeidong, n), App.Display.addButtonPushEffect(n.btnChest, n.onBtnChest, n), App.Display.addButtonPushEffect(n.btnRedPack, n.onBtnRedPack, n), n.width = App.LayerManager.stage.stageWidth, n.height = App.LayerManager.stage.stageHeight, n.setTxtScore(ZmData.Instance.curScore), n.updateBomb(), n.updateHeidong(), n.updateDiamond(), n.updateYue(), n.updateTili(), n.updateTiliSec(), n.initZm(), App.MessageCenter.addListener(ZmMessageType.START_GAME, n.start, n), App.MessageCenter.addListener(ZmMessageType.DATA_BOMB_CHANGED, n.updateBomb, n), App.MessageCenter.addListener(ZmMessageType.DATA_HEIDONG_CHANGED, n.updateHeidong, n), App.MessageCenter.addListener(ZmMessageType.DATA_DIAMOND_CHANGED, n.updateDiamond, n), App.MessageCenter.addListener(ZmMessageType.USEPROP, n.onUseProp, n), App.MessageCenter.addListener(ZmMessageType.RELIVE, n.onRelive, n), App.MessageCenter.addListener(ZmMessageType.DATA_MONEY_CHANGED, n.updateYue, n), App.MessageCenter.addListener(ZmMessageType.DATA_TILI_CHANGED, n.updateTili, n), App.WindowViewManager.showWin(t.ZmHomePage), n.addEventListener(egret.Event.ENTER_FRAME, n.update, n), App.GlobalRepeatTigger.addTime(1e3, n.updateTiliSec, n), ZmSvrCfg.Instance.getFudaiIsOpen() || (n.btnRedPack.visible = !1), n
        }
        return __extends(i, e), i.prototype.initZm = function() {
            var t = this;
            this.zm = new Zuma(this.grpContent), Zuma.actOnLevelUp = function(e) {
                t.onLevelUp(e)
            }, Zuma.actOnEliminate = function(e, i, n, a) {
                t.onEliminate(e, i, n, a)
            }, Zuma.actOnEliminateEnd = function(e) {
                t.onEliminateEnd(e)
            }, Zuma.actOnStateChg = function(e) {
                t.onStateChg(e)
            }, Zuma.actOnCanTouch = function() {
                return t.onCanTouch()
            }, Zuma.actOnGameOver = function() {
                t.onGameOver()
            }, Zuma.actOnGamePass = function(e) {
                t.onGamePass(e)
            }, Zuma.actOnChest = function() {
                t.onChest()
            }, Zuma.actOnWarning = function(e) {
                t.onWarning(e)
            }, Zuma.actOnDanger = function(e) {
                t.onDanger(e)
            }, Zuma.actOnStarScore = function(e) {
                t.riseTxtScore(t.toTxtScore + e, Math.max(1, (t.toTxtScore + e - t.curTxtScore) / 30))
            }
        }, i.prototype.initBanner = function() {
            ZmAdvertisment.Instance.showSingleBannerAd(0), Util.isQQ() ? App.GlobalRepeatTigger.addTime(1e3, this.updateBannerQQ, this) : App.GlobalRepeatTigger.addTime(6e5, this.updateBanner, this)
        }, i.prototype.updateBanner = function() {
            ZmAdvertisment.Instance.showSingleBannerAd(0)
        }, i.prototype.updateBannerQQ = function() {
            var e = ZmAdvertisment.Instance.isSingleBannerAdShow(),
                i = 1 == App.WindowViewManager.getViewCnt() && (null != App.WindowViewManager.getWindowInstance(t.ZmHomePage) || null != App.WindowViewManager.getWindowInstance(t.GamePause));
            i ? e || ZmAdvertisment.Instance.showSingleBannerAd(0) : e && ZmAdvertisment.Instance.hideSingleBannerAd()
        }, i.prototype.start = function() {
            if(fbSDK.bannerInfo != null)
            {
                fbSDK.bannerInfo.showBanner("endgameView")
            }
            console.log("游戏结束-----------"),
			window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_BEGIN,ZmData.Instance.passLevel+1),
            ZmData.Instance.curLevelScore = 0, this.isPause = !1;
            var e = ZmData.Instance.getPassLevel() + 1;
            this.txtLevel.text = e.toString(), console.log("GameData.Instance:", ZmData.Instance), this.setTxtScore(ZmData.Instance.curScore);
            var i = LevelData.getData(e - 1),
                n = i.mapIndex;
            (0 > n || n > 4) && (n = Util.random(0, 4)), this.imgMap.texture = RES.getRes("map" + (n + 1) + "_png"), this.passScore = i.passScore, this.passDiamondRate = 1, this.setScoreTimes(1), this.zm.start(e, n), this.proLevel.minimum = 0, this.proLevel.maximum = this.passScore, this.proLevel.value = 0, this.txtLevelScore.text = this.passScore.toString(), this.propTipFlag = -1, this.bShowHeidong = !0, this.grpFriendOutstrip.x = Zuma.ShooterPoss[n][0] - 72, this.grpFriendOutstrip.y = Zuma.ShooterPoss[n][1] + 183;
            var a = ZmOpenWrap.Instance.getCurDraw();
            (String.isNullOrEmpty(a) || "drawFriendOutstrip" != a) && (ZmOpenWrap.Instance.draw("drawFriendOutstrip", this.grpFriendOutstrip, {
                score: ZmData.Instance.curScore
            }), ZmOpenWrap.Instance.setWinPer(.1, .1)), e > 4 && VideoReward_4399.instace.checkVideo2() && t.LevelProp.pop()
        }, i.prototype.setScoreTimes = function(t) {
            this.scoreTimes = t, this.zm.scoreTimes = t
        }, i.prototype.onLevelUp = function(t) {
            t > 1 && egret.setTimeout(function() {
                this.txtLevelUpTip.text = "Difficulty improvement scorex" + t, this.txtLevelUpTip.y = App.LayerManager.stage.stageHeight / 2 - 200, egret.Tween.get(this.txtLevelUpTip).to({
                    alpha: 1,
                    y: App.LayerManager.stage.stageHeight / 2 - 250
                }, 200).wait(1e3).to({
                    alpha: 0,
                    y: App.LayerManager.stage.stageHeight / 2 - 300
                }, 200, egret.Ease.quadOut)
            }, this, 1e3)
        }, i.prototype.onEliminate = function(t, e, i, n) {
            if (!(3 > t)) {
                var a = (t - 3 + 4 + ZmData.Instance.getSkinCnt()) * e;
                if (ZmData.Instance.curLevelScore += a * this.scoreTimes, this.tipScore(i, n, a), ZmSoundManager.Instance.playSound("xiaochu" + Math.min(4, e)), ZmOpenWrap.Instance.postMessage({
                        msg: "curPlayScoreChg",
                        score: ZmData.Instance.curScore.toString()
                    }), e > 1) {
                    var o = Math.min(2, e - 2),
                        s = [this.imgNice, this.imgGreat, this.imgPerfect];
                    s[o].y = App.LayerManager.stage.stageHeight / 2 - 200, egret.Tween.get(s[o]).to({
                        alpha: 1,
                        y: App.LayerManager.stage.stageHeight / 2 - 250
                    }, 200).wait(1e3).to({
                        alpha: 0,
                        y: App.LayerManager.stage.stageHeight / 2 - 300
                    }, 200, egret.Ease.quadOut)
                }
                this.riseTxtScore(ZmData.Instance.curScore), this.proLevel.value = ZmData.Instance.curLevelScore, ZmData.Instance.curLevelScore >= this.passScore && this.goPass()
            }
        }, i.prototype.onEliminateEnd = function(e) {
            if (ZmSvrCfg.Instance.getFudaiIsOpen()) {
                var i = ZmData.Instance.getSvrData().redPack;
                if (i.canCreateRedPack() && e > 1 && (0 == i.money || Math.random() < ZmSvrCfg.Instance.getRedPackRate(e))) {
                    var n = egret.getTimer();
                    if (this.lastHongbaoTime > 0 && n - this.lastHongbaoTime < 5e4) return;
                    this.lastHongbaoTime = n, App.WindowViewManager.showWin(t.FudaiOpen)
                }
            }
        }, i.prototype.tipScore = function(t, e, i) {
            var n = new eui.BitmapLabel;
            n.font = "score_fnt", this.scoreTimes > 1 ? (n.text = "+" + i + "*)", t -= n.width / 2 + 80) : (n.text = "+" + i, t -= n.width / 2 + 60), e -= 10, n.x = t, n.y = e, this.grpContent.addChild(n), egret.Tween.get(n).to({
                alpha: 0,
                y: e - 80
            }, 500, egret.Ease.quadInOut).call(function() {
                this.grpContent.removeChild(n)
            }, this)
        }, i.prototype.onStateChg = function(t) {
            t == ZumaState.none && -1 == this.propTipFlag
        }, i.prototype.updateBomb = function() {
            var t = ZmData.Instance.getBombCnt();
            this.txtBombNum.text = 1 > t ? "+" : (t > 3 ? 3 : t).toString()
        }, i.prototype.updateHeidong = function() {
            var t = ZmData.Instance.getHeidongCnt();
            console.log("updateHeidong cnt=" + t), this.txtHeidongNum.text = 1 > t ? "+" : (t > 3 ? 3 : t).toString()
        }, i.prototype.updateDiamond = function() {
            this.txtDiamond.text = ZmData.Instance.getDiamondCnt().toString()
        }, i.prototype.onUseProp = function(t) {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(e) {
                    return t.use ? [2] : [2]
                })
            })
        }, i.prototype.onBtnPause = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(e) {
                    return App.WindowViewManager.showWin(t.GamePause), [2]
                })
            })
        }, i.prototype.onBtnDailingqu = function() {}, i.prototype.onBtnRedPack = function() {
            App.WindowViewManager.showWin(t.Fudai)
        }, i.prototype.resume = function() {
            this.isPause = !1, this.zm.usePause(this.isPause)
        }, i.prototype.onBtnBomb = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(e) {
                    return ZmData.Instance.getBombCnt() > 0 ? this.zm.useBomb() && ZmData.Instance.setBombCnt(ZmData.Instance.getBombCnt() - 1) : App.WindowViewManager.showWin(t.GameDaojuZhadan), [2]
                })
            })
        }, i.prototype.onBtnHeidong = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(e) {
                    return ZmData.Instance.getHeidongCnt() > 0 ? this.zm.useHeidong() && ZmData.Instance.setHeidongCnt(ZmData.Instance.getHeidongCnt() - 1) : VideoReward_4399.instace.checkVideo2() || App.WindowViewManager.showWin(t.GameDaojuHeidong), [2]
                })
            })
        }, i.prototype.useHeidong = function() {
            this.zm.toUseHeidiong()
        }, i.prototype.onBtnChest = function() {
            App.WindowViewManager.showWin(t.GameChest)
        }, i.prototype.onBtnRank = function() {
            this.zm.relive(!0)
        }, i.prototype.onBtnTousu = function() {
            ZmData.Instance.setHeidongCnt(0), ZmData.Instance.setBombCnt(0), ZmData.Instance.getSvrData().chestCnt = 0
        }, i.prototype.onRelive = function(t) {
            this.zm.relive(t)
        }, i.prototype.onCanTouch = function() {
            return App.WindowViewManager.getViewCnt() <= 0
        }, i.prototype.onGameOver = function() {
			console.log("gameFail",ZmData.Instance.passLevel+1);
            App.WindowViewManager.showWin(t.GameOver), ZmOpenWrap.Instance.stopDraw()
        }, i.prototype.goPass = function() {
            this.zm.goPass()
        }, i.prototype.onGamePass = function(e) {
            console.log("onGamePass firstBallDis=" + e);
            var i = Math.ceil(e * (4 + ZmData.Instance.getSkinCnt()));
            ZmData.Instance.curLevelScore += i * this.scoreTimes, this.setTxtScore(ZmData.Instance.curScore), App.WindowViewManager.showWin(t.GamePass), ZmData.Instance.addTili(1)
        }, i.prototype.onChest = function() {
            if (ZmData.Instance.getSvrData().chestCnt < 99 && (ZmData.Instance.getSvrData().chestCnt++, ZmData.Instance.saveSvrData()), VideoReward_4399.instace.checkVideo2()) App.WindowViewManager.showWin(t.GameChest);
            else {
                console.log("直接给奖励");
                var e = Math.random();
                .4 > e ? t.HuodeWupin.huoqu({
                    wpType: t.WupinType.diamond,
                    num: Util.random(20, 40),
                    from: "chest"
                }) : t.HuodeWupin.huoqu({
                    wpType: t.WupinType.suipian,
                    num: Util.random(2, 5),
                    from: "chest"
                }), ZmData.Instance.getSvrData().chestCnt--, ZmData.Instance.saveSvrData()
            }
        }, i.prototype.onWarning = function(t) {
            this.effBombShan && (this.grpBombEff.removeChild(this.effBombShan), Core.ObjPool.delObj(Core.Effect, this.effBombShan), this.effBombShan = null), this.effHeidongShan && (this.grpHeidongEff.removeChild(this.effHeidongShan), Core.ObjPool.delObj(Core.Effect, this.effHeidongShan), this.effHeidongShan = null), t && (this.effBombShan = Util.playEff("daojishan", this.grpBombEff, -40, -40, 1, !0), this.effHeidongShan = Util.playEff("daojishan", this.grpHeidongEff, -40, -40, 1, !0))
        }, i.prototype.onDanger = function(e) {
            e && this.bShowHeidong && VideoReward_4399.instace.checkVideo2() && (App.WindowViewManager.showWin(t.GameDaojuHeidong), this.bShowHeidong = !1)
        }, i.prototype.useLevelProp = function(t) {
            this.zm.useLevelProp(t), t == LevelPropType.diamond ? this.passDiamondRate = 2 : t == LevelPropType.doubleScore && (this.scoreTimes = 2)
        }, i.prototype.checkPropTip = function(t) {
            if (void 0 === t && (t = !1), t && (this.propTipFlag = 0), 0 == this.propTipFlag && !(ZmData.Instance.getBombCnt() > 0 && ZmData.Instance.getHeidongCnt() > 0)) {
                this.propTipFlag = 1;
                var e = t ? 2e3 : 5e3;
                egret.setTimeout(function() {
                    ZmData.Instance.getBombCnt() > 0 ? this.propTipFlag = 2 : ZmData.Instance.getHeidongCnt() > 0 ? this.propTipFlag = 2 : this.propTipFlag = 0
                }, this, e)
            }
        }, i.prototype.huodeScore = function(t) {
            ZmData.Instance.curLevelScore += t, ZmOpenWrap.Instance.postMessage({
                msg: "curPlayScoreChg",
                score: ZmData.Instance.curScore.toString()
            }), this.riseTxtScore(ZmData.Instance.curScore), this.proLevel.value = ZmData.Instance.curLevelScore, ZmData.Instance.curLevelScore >= this.passScore && this.goPass()
        }, i.prototype.update = function() {
            this.updateScore()
        }, i.prototype.setTxtScore = function(t) {
            this.curTxtScore = t, this.toTxtScore = t, this.txtScore.text = this.curTxtScore.toString()
        }, i.prototype.riseTxtScore = function(t, e) {
            void 0 === e && (e = 0), this.toTxtScore = t, 0 != e ? this.stepTxtScore = e : this.stepTxtScore = Math.max(1, (this.toTxtScore - this.curTxtScore) / 60)
        }, i.prototype.updateScore = function() {
            this.curTxtScore != this.toTxtScore && (this.curTxtScore += this.stepTxtScore, Math.abs(this.curTxtScore - this.toTxtScore) <= 1 && (this.curTxtScore = this.toTxtScore), this.txtScore.text = Math.floor(this.curTxtScore).toString())
        }, i.prototype.updateYue = function() {}, i.prototype.updateTili = function() {
            this.txtTili.text = ZmData.Instance.getTiliCnt().toString()
        }, i.prototype.updateTiliSec = function() {
            ZmData.Instance.checkTili(), ZmData.Instance.getTiliCnt() > 0 ? (this.txtTili.visible = !0, this.txtTiliTime.text = "/5") : (this.txtTili.visible = !1, this.txtTiliTime.text = t.Tilibuzu.getShengyuTime())
        }, i.prototype.destroy = function() {
            this.zm.destroy(), App.Display.removeButtonPushEffect(this.btnRedPack), App.MessageCenter.removeListener(ZmMessageType.START_GAME, this.start, this), App.MessageCenter.removeListener(ZmMessageType.DATA_MONEY_CHANGED, this.updateYue, this), App.MessageCenter.removeListener(ZmMessageType.DATA_TILI_CHANGED, this.updateTili, this), App.GlobalRepeatTigger.removeTime(this.updateBanner, this), this.removeEventListener(egret.Event.ENTER_FRAME, this.update, this), App.GlobalRepeatTigger.removeTime(this.updateTiliSec, this), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiView);
    t.ZmPlayScene = e, __reflect(e.prototype, "Views.ZmPlayScene")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(t) {
        function e(e) {
            var i = t.call(this, ChaoyueSkin, e) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnZailaiyiju, i.onZailaiyiju, i, !0), App.Display.addButtonPushEffect(i.btnXuanyao, i.onXuanyao, i, !0), App.Display.addButtonPushEffect(i.btnCancel, i.onCancel, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(e, t), e.prototype.onZailaiyiju = function() {}, e.prototype.onXuanyao = function() {}, e.prototype.onCancel = function() {}, e.prototype.onGuanbi = function() {}, e.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnZailaiyiju), App.Display.removeButtonPushEffect(this.btnXuanyao), App.Display.removeButtonPushEffect(this.btnCancel), App.Display.removeButtonPushEffect(this.btnGuanbi)), t.prototype.destroy.call(this)
        }, e
    }(Core.ZmBaseEuiWindow);
    t.Chaoyue = e, __reflect(e.prototype, "Views.Chaoyue")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var n = e.call(this, FenxiangErrTipSkin, t) || this;
            return n.width = App.LayerManager.stage.stageWidth, n.height = App.LayerManager.stage.stageHeight, n.txtTip.text = i.errText[i.errType], App.Display.addButtonPushEffect(n.btnFenxiang, n.onFenxiang, n, !0), App.Display.addButtonPushEffect(n.btnSure, n.onSure, n, !0), App.Display.addButtonPushEffect(n.btnCancel, n.onCancel, n, !0), App.Display.addButtonPushEffect(n.btnGuanbi, n.onGuanbi, n, !0), n
        }
        return __extends(i, e), i.show = function(e) {
            var i = App.WindowViewManager.getWindowInstance(t.FenxiangTip);
            null != i && i.close(), t.FenxiangErrTip.sType = e, App.WindowViewManager.showWin(t.FenxiangErrTip)
        }, i.prototype.onFenxiang = function() {
            ZmShare.Instance.share(t.FenxiangErrTip.sType), this.close()
        }, i.prototype.onSure = function() {
            this.close()
        }, i.prototype.onCancel = function() {
            this.close()
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnFenxiang), App.Display.removeButtonPushEffect(this.btnSure), App.Display.removeButtonPushEffect(this.btnCancel), App.Display.removeButtonPushEffect(this.btnGuanbi)), e.prototype.destroy.call(this)
        }, i.errType = 0, i.errText = ["点击个人的分享链接不会获利哟！\n请分享到群！", "短时间内，不能点击相同群的\n分享链接！请分享到其他群吧！"], i
    }(Core.ZmBaseEuiWindow);
    t.FenxiangErrTip = e, __reflect(e.prototype, "Views.FenxiangErrTip")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(t) {
        function e(e) {
            var i = t.call(this, FenxiangTipSkin, e) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnSure, i.onSure, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(e, t), e.prototype.onSure = function() {
            this.close()
        }, e.prototype.onGuanbi = function() {
            this.close()
        }, e.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnSure), App.Display.removeButtonPushEffect(this.btnGuanbi)), t.prototype.destroy.call(this)
        }, e
    }(Core.ZmBaseEuiWindow);
    t.FenxiangTip = e, __reflect(e.prototype, "Views.FenxiangTip")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e;
    ! function(t) {
        t[t.diamond = 0] = "diamond", t[t.suipian = 1] = "suipian", t[t.huafeijuan = 2] = "huafeijuan"
    }(e = t.FudaiItemType || (t.FudaiItemType = {}));
    var i = function() {
        function t() {}
        return t.datas = [{
            index: 1,
            name: "DiamondX2000",
            num: 500,
            icon: "play_json.fud_jp7",
            itemType: e.diamond,
            itemNum: 1e3
        }, {
            index: 2,
            name: "skin fragmentsx100",
            num: 1e3,
            icon: "play_json.fud_jp8",
            itemType: e.suipian,
            itemNum: 1
        }, {
            index: 3,
            name: "20元话费充值卡",
            num: 2e3,
            icon: "play_json.fud_jp1",
            itemType: e.huafeijuan,
            itemNum: 1
        }, {
            index: 4,
            name: "100元话费充值卡",
            num: 5e3,
            icon: "play_json.fud_jp3",
            itemType: e.huafeijuan,
            itemNum: 1
        }, {
            index: 5,
            name: "美的取暖器",
            num: 1e4,
            icon: "play_json.fud_jp4",
            itemType: e.huafeijuan,
            itemNum: 1
        }, {
            index: 6,
            name: "荣耀9i 64GB",
            num: 12988,
            icon: "play_json.fud_jp5",
            itemType: e.huafeijuan,
            itemNum: 1
        }], t
    }();
    t.FudaiDataItem = i, __reflect(i.prototype, "Views.FudaiDataItem");
    var n = function(e) {
        function n(t) {
            var i = e.call(this, FudaiSkin, t) || this;
            return i.items = [], i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(n, e), n.prototype.init = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e, n, a;
                return __generator(this, function(o) {
                    for (e = 0; e < i.datas.length; e++) n = i.datas[0], a = new t.FudaiCell(this), a.init(n), this.grpItems.addChild(a), this.items.push(a);
                    return this.update(), [2]
                })
            })
        }, n.prototype.update = function() {
            this.txtYue.text = Math.floor(100 * ZmData.Instance.getSvrData().redPack.money).toString();
            for (var t = 0; t < i.datas.length; t++) {
                var e = i.datas[t],
                    n = this.items[t];
                n.init(e)
            }
        }, n.prototype.onGuanbi = function() {
            this.close()
        }, n.prototype.destroy = function() {
            this._active && App.Display.removeButtonPushEffect(this.btnGuanbi), e.prototype.destroy.call(this)
        }, n
    }(Core.ZmBaseEuiWindow);
    t.Fudai = n, __reflect(n.prototype, "Views.Fudai")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this) || this;
            return i.skinName = FudaiCellSkin, i.fudai = t, App.Display.addButtonPushEffect(i.btnDuihuan, i.onBtnDuihuan, i), i.txtItemNum.visible = !1, i
        }
        return __extends(i, e), i.prototype.init = function(e) {
            this.data = e, this.txtItemNum.visible = e.itemType != t.FudaiItemType.huafeijuan, this.txtName.text = e.name, this.txtNum.text = "x" + e.num, this.txtItemNum.text = "x" + e.itemNum, this.imgIcon.texture = Util.getRes(e.icon), 100 * ZmData.Instance.getSvrData().redPack.money < this.data.num ? Core.DisplayUtilMod.Instance.addGrayFlilter(this.btnDuihuan) : Core.DisplayUtilMod.Instance.removeGrayFlilter(this.btnDuihuan)
        }, i.prototype.onBtnDuihuan = function() {
            if (!(100 * ZmData.Instance.getSvrData().redPack.money < this.data.num)) {
                if (this.data.itemType == t.FudaiItemType.diamond) t.HuodeWupin.huoqu({
                    wpType: t.WupinType.diamond,
                    num: this.data.itemNum,
                    from: "fudai"
                });
                else {
                    if (this.data.itemType != t.FudaiItemType.suipian) return;
                    t.HuodeWupin.huoqu({
                        wpType: t.WupinType.suipian,
                        num: this.data.itemNum,
                        from: "fudai"
                    })
                }
                var e = ZmData.Instance.getSvrData().redPack;
                e.money -= this.data.num / 100, e.rpNum = RedPackCfg.getNumIndex(e.money), ZmData.Instance.saveSvrData(), this.fudai.update()
            }
        }, i.prototype.destroy = function() {
            App.Display.removeButtonPushEffect(this.btnDuihuan)
        }, i
    }(eui.Component);
    t.FudaiCell = e, __reflect(e.prototype, "Views.FudaiCell")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, FudaiHuodeSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.Display.addButtonPushEffect(i.btnQueding, i.onQueding, i, !0), App.Display.addButtonPushEffect(i.btnDuihuan, i.onDuihuan, i, !0), i
        }
        return __extends(i, e), i.prototype.init = function(t) {
            t && t.money ? (this.txtHuode.text = Math.floor(100 * t.money).toString(), "0" == this.txtHuode.text && (this.txtHuode.text = "1")) : this.txtHuode.text = ""
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.onQueding = function() {
            this.close()
        }, i.prototype.onDuihuan = function() {
            App.WindowViewManager.showWin(t.Fudai), this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButtonPushEffect(this.btnQueding), App.Display.removeButtonPushEffect(this.btnDuihuan)), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.FudaiHuode = e, __reflect(e.prototype, "Views.FudaiHuode")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, FudaiOpenSkin, t) || this;
            return i.bDailingqu = !1, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnOpen, i.onOpen, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(i, e), i.prototype.init = function(t) {
            t && t.bDailingqu && (this.bDailingqu = t.bDailingqu)
        }, i.prototype.onOpen = function() {
            var e = this;
            if (ZmSvrCfg.Instance.getFudaiIsOpen()) {
                var i = ZmData.Instance.getSvrData().redPack,
                    n = i.hbNum;
                if (n > 9) Core.DialogMod.Instance.Pop("今日福袋已领完！"), ZmData.Instance.getSvrData().redPack.setDailingqu(), ZmData.Instance.saveSvrData(), App.MessageCenter.dispatch(ZmMessageType.DATA_MONEY_CHANGED), App.MessageCenter.dispatch(ZmMessageType.SHOW_ANIAD), App.WindowViewManager.hide(this);
                else if (0 == n && 0 == i.dayIndex) this.doRedPack();
                else {
                    var a = !1;
                    a = i.money < 13.72 ? 5 > n : n >= 5, a ? ZmShare.Instance.share(ShareType.redPack) : t.ZmRewardVideoTip.showWithShare(1, ShareType.redPack, function(t) {
                        e.doRedPack()
                    }, function() {}, !0)
                }
            }
        }, i.prototype.doRedPack = function() {
            var e = ZmData.Instance.getSvrData().redPack.createRedPack();
            e > 0 && (Core.DialogMod.Instance.Pop("领取成功"), ZmData.Instance.getSvrData().redPack.lingqu(e, this.bDailingqu), ZmData.Instance.saveSvrData(), App.WindowViewManager.showWithData(t.FudaiHuode, {
                money: e
            })), this.close()
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnOpen), App.Display.removeButtonPushEffect(this.btnGuanbi)), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.FudaiOpen = e, __reflect(e.prototype, "Views.FudaiOpen")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, GameChestSkin, t) || this;
            return i.isShowBanner = !1, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.Display.addButtonPushEffect(i.btnFenxiang, i.onFenxiang, i, !0), App.Display.addButtonPushEffect(i.btnCancel, i.onGuanbi, i, !0), App.MessageCenter.addListener(ZmMessageType.DATA_YAOSHI_CHANGED, i.updateYaoshi, i), App.Display.addButtonPushEffect(i.btnKaiqibaoxiang, i.onKaiqibaoxiang, i, !0), i.txtCancel.textFlow = new Array({
                text: "狠心放弃 >>",
                style: {
                    underline: !0
                }
            }), ZmAdvertisment.Instance.showSingleBannerAd(0), i
        }
        return __extends(i, e), i.prototype.updateYaoshi = function() {
            this.txtYaoshishuliang.text = "x" + ZmData.Instance.getYaoshiCnt().toString()
        }, i.prototype.onKaiqibaoxiang = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(t) {
                    return VideoReward_4399.instace.playVideo(this.onShare, this), [2]
                })
            })
        }, i.prototype.onShare = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e, i;
                return __generator(this, function(n) {
                    return e = Math.random(), .4 > e ? t.HuodeWupin.huoqu({
                        wpType: t.WupinType.diamond,
                        num: Util.random(20, 40),
                        from: "chest"
                    }) : t.HuodeWupin.huoqu({
                        wpType: t.WupinType.suipian,
                        num: Util.random(2, 5),
                        from: "chest"
                    }), ZmData.Instance.getSvrData().chestCnt--, ZmData.Instance.saveSvrData(), i = App.WindowViewManager.getWindowInstance(t.ZmHomePage), i || this.close(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareChest), [2]
                })
            })
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.onFenxiang = function() {
            return __awaiter(this, void 0, void 0, function() {
                var t;
                return __generator(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, ZmShare.Instance.share(ShareType.lingquYaoshi)];
                        case 1:
                            return t = e.sent(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareChest), this.close(), [2]
                    }
                })
            })
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnKaiqibaoxiang), App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButtonPushEffect(this.btnFenxiang), App.Display.removeButtonPushEffect(this.btnCancel), App.MessageCenter.removeListener(ZmMessageType.DATA_YAOSHI_CHANGED, this.updateYaoshi, this)), ZmAdvertisment.Instance.hideSingleBannerAd(), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.GameChest = e, __reflect(e.prototype, "Views.GameChest")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(t) {
        function e(e) {
            var i = t.call(this, GameChestKeySkin, e) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnSuoyaoyaoshi, i.onSuoyaoyaoshi, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.MessageCenter.addListener(ZmMessageType.DATA_YAOSHI_CHANGED, i.updateYaoshi, i), i.updateYaoshi(), i
        }
        return __extends(e, t), e.prototype.onSuoyaoyaoshi = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(t) {
                    switch (t.label) {
                        case 0:
                            return [4, ZmShare.Instance.share(ShareType.lingquYaoshi)];
                        case 1:
                            return t.sent(), [2]
                    }
                })
            })
        }, e.prototype.onGuanbi = function() {
            this.close()
        }, e.prototype.updateYaoshi = function() {
            this.txtYaoshishuliang.text = "x" + ZmData.Instance.getYaoshiCnt().toString()
        }, e.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnSuoyaoyaoshi), App.Display.removeButtonPushEffect(this.btnGuanbi), App.MessageCenter.removeListener(ZmMessageType.DATA_YAOSHI_CHANGED, this.updateYaoshi, this)), t.prototype.destroy.call(this)
        }, e
    }(Core.ZmBaseEuiWindow);
    t.GameChestKey = e, __reflect(e.prototype, "Views.GameChestKey")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, GameDaojuHeidongSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, ZmData.Instance.getDiamondCnt() < 200 ? Core.DisplayUtilMod.Instance.addGrayFlilter(i.btnGoumai) : App.Display.addButtonPushEffect(i.btnGoumai, i.onGoumai, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi2, i.onGuanbi, i, !0), App.Display.addButtonPushEffect(i.btnMianfei, i.onMianfei, i, !0), i.txtCancel.textFlow = new Array({
                text: "狠心放弃 >>",
                style: {
                    underline: !0
                }
            }), i
        }
        return __extends(i, e), i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.onGoumai = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e;
                return __generator(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, ZmData.Instance.addDiamond(-200)];
                        case 1:
                            return (e = i.sent()) ? (t.HuodeWupin.huoqu({
                                wpType: t.WupinType.heidong,
                                num: 1
                            }), this.close(), [2]) : (Core.DialogMod.Instance.Pop("购买失败"), [2])
                    }
                })
            })
        }, i.prototype.onMianfei = function() {
            var e = this;
            VideoReward_4399.instace.playVideo(function() {
                t.ZmPlayScene.ins.useHeidong(), e.close()
            }, this)
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnGuanbi2), App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButtonPushEffect(this.btnGoumai), App.Display.removeButtonPushEffect(this.btnMianfei)), ZmAdvertisment.Instance.hideSingleBannerAd(), ZmShare.Instance.clearShareDelay(), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.GameDaojuHeidong = e, __reflect(e.prototype, "Views.GameDaojuHeidong")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, GameDaojuZhadanSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, ZmData.Instance.getDiamondCnt() < 100 ? Core.DisplayUtilMod.Instance.addGrayFlilter(i.btnGoumai) : App.Display.addButtonPushEffect(i.btnGoumai, i.onGoumai, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.Display.addButtonPushEffect(i.btnMianfei, i.onMianfei, i, !0), ZmAdvertisment.Instance.showSingleBannerAd(0), i
        }
        return __extends(i, e), i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.onGoumai = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e;
                return __generator(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, ZmData.Instance.addDiamond(-100)];
                        case 1:
                            return (e = i.sent()) ? (t.HuodeWupin.huoqu({
                                wpType: t.WupinType.bomb,
                                num: 1
                            }), this.close(), [2]) : (Core.DialogMod.Instance.Pop("购买失败"), [2])
                    }
                })
            })
        }, i.prototype.onMianfei = function() {
            var e = this;
            t.ZmRewardVideoTip.showWithShare(1, ShareType.zhadan, function(i) {
                t.HuodeWupin.huoqu({
                    wpType: t.WupinType.bomb,
                    num: 1
                }), e.close()
            }, function() {
                e.close()
            })
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButtonPushEffect(this.btnGoumai), App.Display.removeButtonPushEffect(this.btnMianfei)), ZmAdvertisment.Instance.hideSingleBannerAd(), ZmShare.Instance.clearShareDelay(), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.GameDaojuZhadan = e, __reflect(e.prototype, "Views.GameDaojuZhadan")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, GameDiamondSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnYQHY, i.onYQHY, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(i, e), i.canLinqu = function() {
            return __awaiter(this, void 0, void 0, function() {
                var t, e, n;
                return __generator(this, function(a) {
                    switch (a.label) {
                        case 0:
                            return [2];
                        case 1:
                            if (t = a.sent(), t && (console.log("resp:", t), e = 0, t))
                                for (i.canLinquCnt = 0, n = 0; n < t.length; n++) 0 == t[n].status && i.canLinquCnt++;
                            return [2, i.canLinquCnt > 0]
                    }
                })
            })
        }, i.prototype.init = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e, n, a, o, s, a, o, s;
                return __generator(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, ZmSession.Instance.updateMoney()];
                        case 1:
                            if (r.sent(), e = [], console.log("resp:", e), n = 0, e) {
                                for (i.canLinquCnt = 0, a = 0; a < e.length; a++) o = new t.GameDiamondDataItem, o.index = a, o.lingquFlag = 0 == e[a].status ? 1 : 2, o.inviteopenid = e[a].openid, s = new t.GameDiamondCell, s.init(o), this.grpItems.addChild(s), 0 == e[a].status && i.canLinquCnt++;
                                n = e.length
                            }
                            for (a = n; 10 > a; a++) o = new t.GameDiamondDataItem, o.index = a, o.lingquFlag = 0, s = new t.GameDiamondCell, s.init(o), this.grpItems.addChild(s);
                            return [2]
                    }
                })
            })
        }, i.prototype.onYQHY = function() {
            i.yqhy(), this.close()
        }, i.yqhy = function() {
            ZmShare.Instance.share(ShareType.lingquDiammond)
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnYQHY), App.Display.removeButtonPushEffect(this.btnGuanbi)), e.prototype.destroy.call(this)
        }, i.lastUpdateDiamondTime = 0, i.canLinquCnt = 0, i
    }(Core.ZmBaseEuiWindow);
    t.GameDiamond = e, __reflect(e.prototype, "Views.GameDiamond")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function() {
        function t() {}
        return t
    }();
    t.GameDiamondDataItem = e, __reflect(e.prototype, "Views.GameDiamondDataItem");
    var i = function(e) {
        function i() {
            var t = e.call(this) || this;
            return t.skinName = GameDiamondCellSkin, t
        }
        return __extends(i, e), i.prototype.init = function(t) {
            if (this.dItem = t, this.txtDijihaoyou.text = "第" + (t.index + 1) + "位好友", this.txtDiamond.text = i.diamondCnts[t.index].toString(), 0 == t.lingquFlag) this.btnAdd.visible = !0, this.imgHead.visible = !1, this.btnYilingqu.visible = !1, this.btnLingqu.visible = !0, Core.DisplayUtilMod.Instance.addGrayFlilter(this.btnLingqu), App.Display.addButtonPushEffect(this.btnAdd, this.onAdd, this, !0);
            else {
                this.btnAdd.visible = !1, this.imgHead.visible = !0;
                var e = 2 == t.lingquFlag;
                this.updataLingqu(e), e || App.Display.addButtonPushEffect(this.btnLingqu, this.onLingqu, this, !0)
            }
        }, i.prototype.updataLingqu = function(t, e) {
            void 0 === e && (e = !1), this.btnYilingqu.visible = t, this.btnLingqu.visible = !t
        }, i.prototype.onAdd = function() {
            t.GameDiamond.yqhy()
        }, i.prototype.onYilingqu = function() {}, i.prototype.onLingqu = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e, n;
                return __generator(this, function(a) {
                    switch (a.label) {
                        case 0:
                            return [4, ZmSession.Instance.requestApp("/invite.action", "post", {
                                openid: ZmSession.Instance.openId,
                                inviteopenid: this.dItem.inviteopenid,
                                invitetype: 3,
                                isupdatemoney: 0
                            })];
                        case 1:
                            return e = a.sent(), n = 0, e && (this.btnYilingqu.visible = !0, this.btnLingqu.visible = !1, 0 == e.ret && t.HuodeWupin.huoqu({
                                wpType: t.WupinType.diamond,
                                num: i.diamondCnts[this.dItem.index]
                            }), t.GameDiamond.canLinquCnt--), [2]
                    }
                })
            })
        }, i.prototype.destroy = function() {
            App.Display.removeButtonPushEffect(this.btnAdd), App.Display.removeButtonPushEffect(this.btnYilingqu), App.Display.removeButtonPushEffect(this.btnLingqu)
        }, i.diamondCnts = [100, 110, 120, 130, 140, 150, 160, 170, 180, 200], i
    }(eui.Component);
    t.GameDiamondCell = i, __reflect(i.prototype, "Views.GameDiamondCell")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var n = e.call(this, GameOverSkin, t) || this;
            n.width = App.LayerManager.stage.stageWidth, n.height = App.LayerManager.stage.stageHeight;
            var a = ZmData.Instance.getPassLevel();
            n.txtPassLevel.text = "lv" + a, n.txtTotalScore.text = ZmData.Instance.curLevelScore.toString();
            var o = LevelData.getData(a);
            n.btnRelive.x = 260;
			HUHU_showInterstitialAd();
			window.cy_Sdk && window.cy_Sdk.adShow();
			window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_END,"Fail");
            return n.txtTongguanScore.text = o.passScore.toString(), n.txtRelive.text = ZmData.Instance.getReliveCnt() + "/3", App.Display.addButtonPushEffect(n.btnRelive, n.onRelive, n, !0), n.txtReliveDiamond.text = i.diamondCnts[ZmData.Instance.getReliveCnt()].toString(), App.Display.addButtonPushEffect(n.btnMianfei, n.onMianfei, n, !0), App.Display.addButtonPushEffect(n.btnCancel, n.onCancel, n, !0), App.Display.addButtonPushEffect(n.btnGuanbi, n.onGuanbi, n, !0), ZmAdvertisment.Instance.showSingleBannerAd(0), n
        }
        return __extends(i, e), i.prototype.init = function() {
            //VideoReward_4399.instace.checkVideo2() || (this.btnMianfei.visible = !1)
			this.btnMianfei.visible = !0;
			this.btnRelive.visible = !1;
        }, i.prototype.onRelive = function() {
            var t = ZmData.Instance.addDiamond(-i.diamondCnts[ZmData.Instance.getReliveCnt()]);
            t && this.doRelive()
        }, i.prototype.doRelive = function() {
            App.MessageCenter.dispatch(ZmMessageType.RELIVE, !0), ZmData.Instance.setReliveCnt(ZmData.Instance.getReliveCnt() + 1), this.close()
        }, i.prototype.onMianfei = function() {
            VideoReward_4399.instace.playVideo(this.doRelive, this)
        }, i.prototype.onCancel = function() {
            App.WindowViewManager.showWin(t.ZmHomePage), App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, this), ZmData.Instance.updateScore(0)
        }, i.prototype.onGuanbi = function() {
            App.WindowViewManager.showWin(t.ZmHomePage), App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, this), ZmData.Instance.updateScore(0)
        }, i.prototype.destroy = function() {
			window.cy_Sdk && window.cy_Sdk.adHide();
            this._active && (App.Display.removeButtonPushEffect(this.btnRelive), App.Display.removeButtonPushEffect(this.btnMianfei), App.Display.removeButtonPushEffect(this.btnCancel), App.Display.removeButtonPushEffect(this.btnGuanbi)), ZmAdvertisment.Instance.hideSingleBannerAd(), ZmShare.Instance.clearShareDelay(), e.prototype.destroy.call(this)
        }, i.diamondCnts = [100, 150, 200], i
    }(Core.ZmBaseEuiWindow);
    t.GameOver = e, __reflect(e.prototype, "Views.GameOver")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
			window.cy_Sdk && window.cy_Sdk.adShow();
			window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_END,"Pass");
            var i = e.call(this, GamePassSkin, t) || this;
            return i.bLingqu = !1, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, i.txtScore.text = ZmData.Instance.curLevelScore.toString(), i.txtTotalScore.text = ZmData.Instance.curScore.toString(), i.txtDiamond.text = Math.ceil(ZmData.Instance.curLevelScore / 50).toString(), i.txtNextLevel.textFlow = new Array({
                text: "下一关 >>",
                style: {
                    underline: !0
                }
            }), ZmData.Instance.updateScore(ZmData.Instance.curScore, !0, ZmData.Instance.getPassLevel() + 1), App.Display.addButtonPushEffect(i.btnShuangbei, i.onShuangbei, i, !0), App.Display.addButtonPushEffect(i.btnNextLevel, i.onNextLevel, i, !0), App.Display.addButtonPushEffect(i.btnTiaozhanhaoyou, i.onTiaozhanhaoyou, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), ZmAdvertisment.Instance.showSingleBannerAd(0), i
        }
        return __extends(i, e), i.prototype.init = function() {
            fbSDK.showInterstitialAD();
            //this.btnShuangbei.visible = 0;
        }, i.prototype.onShuangbei = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(t) {
                    return VideoReward_4399.instace.playVideo(this.videoBack, this), [2]
                })
            })
        }, i.prototype.videoBack = function() {
            this.onNextLevel(!0)
        }, i.prototype.doShuangbei = function() {
            var e = Math.ceil(ZmData.Instance.curLevelScore / 50) * t.ZmPlayScene.ins.passDiamondRate;
            t.HuodeWupin.huoqu({
                wpType: t.WupinType.diamond,
                num: 2 * e
            }), Core.DisplayUtilMod.Instance.addGrayFlilter(this.btnShuangbei), App.Display.removeButtonPushEffect(this.btnShuangbei), this.bLingqu = !0
        }, i.prototype.onNextLevel = function(e) {
            if (void 0 === e && (e = !1), !this.bLingqu) {
                var i = Math.ceil(ZmData.Instance.curLevelScore / 50) * t.ZmPlayScene.ins.passDiamondRate;
                e === !0 && (i *= 2), ZmData.Instance.addDiamond(i), App.Dialog.Pop("Get diamonds ×" + i), this.bLingqu = !0
            }
            ZmData.Instance.getTiliCnt() > 0 ? (ZmData.Instance.addTili(-1), ZmData.Instance.setReliveCnt(0), App.MessageCenter.dispatch(ZmMessageType.START_GAME), this.close()) : App.WindowViewManager.showWin(t.Tilibuzu)
			window.cy_Sdk && window.cy_Sdk.ga(window.cy_Sdk.LEVEL_BEGIN,ZmData.Instance.passLevel + 1);
        }, i.prototype.onTiaozhanhaoyou = function() {
            egret_4399_h5api.share()
        }, i.prototype.onGuanbi = function() {
            if (!this.bLingqu) {
                var e = Math.ceil(ZmData.Instance.curLevelScore / 50) * t.ZmPlayScene.ins.passDiamondRate;
                ZmData.Instance.addDiamond(e), this.bLingqu = !0
            }
            ZmData.Instance.getTiliCnt() > 0 ? (ZmData.Instance.addTili(-1), ZmData.Instance.setReliveCnt(0), App.MessageCenter.dispatch(ZmMessageType.START_GAME), this.close()) : App.WindowViewManager.showWin(t.Tilibuzu)
        }, i.prototype.destroy = function() {
			window.cy_Sdk && window.cy_Sdk.adHide();
            this._active && (App.Display.removeButtonPushEffect(this.btnShuangbei), App.Display.removeButtonPushEffect(this.btnNextLevel), App.Display.removeButtonPushEffect(this.btnGuanbi)), ZmAdvertisment.Instance.hideSingleBannerAd(), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.GamePass = e, __reflect(e.prototype, "Views.GamePass")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, GamePauseSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.Display.addButtonPushEffect(i.btnJixuyouxi, i.onJixuyouxi, i, !0), App.Display.addButtonPushEffect(i.btnChongxinkaishi, i.onChongxinkaishi, i, !0), App.Display.addButtonPushEffect(i.btnFanhui, i.onFanhui, i, !0), App.Display.addButtonPushEffect(i.btnHaoyoujieli, i.onHaoyoujieli, i, !0), ZmAdvertisment.Instance.showSingleBannerAd(0), i
        }
        return __extends(i, e), i.prototype.onGuanbi = function() {
            t.ZmPlayScene.ins.resume(), this.close()
        }, i.prototype.onJixuyouxi = function() {
            t.ZmPlayScene.ins.resume(), this.close()
        }, i.prototype.onChongxinkaishi = function() {
            App.MessageCenter.dispatch(ZmMessageType.START_GAME), this.close()
        }, i.prototype.onFanhui = function() {
            App.WindowViewManager.showWin(t.ZmHomePage), this.close()
        }, i.prototype.onHaoyoujieli = function() {
            ZmShare.Instance.share(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareHaoyoujieli)
        }, i.prototype.destroy = function() {
            this._active && (App.MessageCenter.dispatch(ZmMessageType.SHOW_ANIAD), App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButtonPushEffect(this.btnJixuyouxi), App.Display.removeButtonPushEffect(this.btnChongxinkaishi), App.Display.removeButtonPushEffect(this.btnFanhui), App.Display.removeButtonPushEffect(this.btnHaoyoujieli)), ZmAdvertisment.Instance.hideSingleBannerAd(), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.GamePause = e, __reflect(e.prototype, "Views.GamePause")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(t) {
        function e(e) {
            var i = t.call(this, GameScoreSkin, e) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnRelive, i.onRelive, i, !0), App.Display.addButtonPushEffect(i.btnMianfei, i.onMianfei, i, !0), App.Display.addButtonPushEffect(i.btnCancel, i.onCancel, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), ZmAdvertisment.Instance.showSingleBannerAd(0), i
        }
        return __extends(e, t), e.prototype.onRelive = function() {}, e.prototype.onMianfei = function() {}, e.prototype.onCancel = function() {}, e.prototype.onGuanbi = function() {}, e.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnRelive), App.Display.removeButtonPushEffect(this.btnMianfei), App.Display.removeButtonPushEffect(this.btnCancel), App.Display.removeButtonPushEffect(this.btnGuanbi)), ZmAdvertisment.Instance.hideSingleBannerAd(), t.prototype.destroy.call(this)
        }, e
    }(Core.ZmBaseEuiWindow);
    t.GameScore = e, __reflect(e.prototype, "Views.GameScore")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(t) {
        function e(e) {
            var i = t.call(this, GameSetSkin, e) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.Display.addButtonPushEffect(i.btnYinxiao, i.onYinxiao, i, !0), App.Display.addButtonPushEffect(i.btnFanhui, i.onFanhui, i, !0), i.updateSoundBtn(), gamePlat == PlatType.limi && (i.grpKefu.visible = !1, i.grpYinxiao.x = 207, i.grpYinxiao.y = 138), Util.isQQ() && (i.grpKefu.visible = !1, i.grpYinxiao.x = 207), i
        }
        return __extends(e, t), e.prototype.updateSoundBtn = function() {
            var t = ZmData.Instance.getIsSoundOpen();
            this.imgYinxiaok.visible = t, this.imgYinxiaokai.visible = t, this.imgYinxiaog.visible = !t, this.imgYinxiaoguan.visible = !t
        }, e.prototype.onGuanbi = function() {
            this.close()
        }, e.prototype.onYinxiao = function() {
            ZmData.Instance.getIsSoundOpen() ? ZmSoundManager.Instance.closeSound() : ZmSoundManager.Instance.openSound(), this.updateSoundBtn()
        }, e.prototype.onFanhui = function() {
            wx.openCustomerServiceConversation && wx.openCustomerServiceConversation({
                sessionFrom: "zumaji"
            }), this.close()
        }, e.prototype.destroy = function() {
            this._active && (App.MessageCenter.dispatch(ZmMessageType.SHOW_ANIAD), ZmAdvertisment.Instance.hideAllBannerAd(), App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButtonPushEffect(this.btnYinxiao), App.Display.removeButtonPushEffect(this.btnFanhui)), t.prototype.destroy.call(this)
        }, e
    }(Core.ZmBaseEuiWindow);
    t.GameSet = e, __reflect(e.prototype, "Views.GameSet")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, GongzhonghaoSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, i.addEventListener(egret.TouchEvent.TOUCH_TAP, i.onTouch, i), i
        }
        return __extends(i, e), i.pop = function() {
            return App.WindowViewManager.showWin(t.Gongzhonghao), !0
        }, i.prototype.onTouch = function(t) {
            this.close()
        }, i
    }(Core.ZmBaseEuiWindow);
    t.Gongzhonghao = e, __reflect(e.prototype, "Views.Gongzhonghao")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var n = e.call(this, ZmHomePageSkin, t) || this;
            return n.isShowBanner = !1, n.width = App.LayerManager.stage.stageWidth, n.height = App.LayerManager.stage.stageHeight, n.updateDiamond(), n.updateYue(), n.updateTili(), n.updateTiliSec(), Util.playAnim(n.animYd, !0), App.Display.addButtonPushEffect(n.btnStart, n.onStart, n, !0), App.Display.addButtonPushEffect(n.btnRank, n.onRank, n, !0), App.Display.addButtonPushEffect(n.btnUserSkin, n.onUserSkin, n, !0), App.Display.addButtonPushEffect(n.btnSet, n.onSet, n, !0), App.Display.addButtonPushEffect(n.btnShare, n.onShare, n, !0), App.Display.addButtonPushEffect(n.btnQiandao, n.onQiandao, n, !0), App.Display.addButtonPushEffect(n.btnChest, n.onChest, n, !0), App.Display.addButtonPushEffect(n.btnLingquuanshi, n.onLingquuanshi, n, !0), App.Display.addButtonPushEffect(n.btnRedPack, n.onBtnRedPack, n), App.MessageCenter.addListener(ZmMessageType.DATA_DIAMOND_CHANGED, n.updateDiamond, n), App.MessageCenter.addListener(ZmMessageType.DATA_MONEY_CHANGED, n.updateYue, n), App.MessageCenter.addListener(ZmMessageType.DATA_TILI_CHANGED, n.updateTili, n), App.GlobalRepeatTigger.addTime(1e3, n.updateTiliSec, n), gamePlat == PlatType.limi ? (n.grpYindao.visible = !1, n.btnRank.visible = !1, n.btnUserSkin.horizontalCenter = -160, n.btnSet.horizontalCenter = 0, n.btnShare.horizontalCenter = 160) : Util.isQQ() ? (n.grpYindao.visible = !1, n.btnRank.visible = !1, n.btnLingquuanshi.visible = !1, n.btnRedPack.visible = !1, n.btnUserSkin.horizontalCenter = -160, n.btnSet.horizontalCenter = 0, n.btnShare.horizontalCenter = 160) : i.fankuiBtn ? i.fankuiBtn.show() : n.createFeedButton(), ZmSvrCfg.Instance.getFudaiIsOpen() || (n.btnRedPack.visible = !1), Util.isQQ() && ZmSvrCfg.Instance.isTs() && (n.btnSet.visible = !1), n
        }
        return __extends(i, e), i.prototype.init = function() {
            if(fbSDK.bannerInfo != null)
            {
                fbSDK.bannerInfo.showBanner("startgameview")
            }
            ZmAdvertisment.Instance.hideAllBannerAd(), i.isPopWin && (ZmData.Instance.getSvrData().qiandao.canLingqu() && App.WindowViewManager.showWin(t.Qiandao), i.isPopWin = !1), App.GlobalRepeatTigger.addTime(1e3, this.updateRedPot, this), this.checkVideo(), App.GlobalRepeatTigger.addTime(2e3, this.checkVideo, this),console.log("startgame1111111"),HUHU_setLoadingProgress(100)

        }, i.prototype.checkVideo = function() {
            //VideoReward_4399.instace.checkVideo2() || (this.btnChest.visible = this.btnLingquuanshi.visible = !1)
			this.btnChest.visible = this.btnLingquuanshi.visible = !0
        }, i.prototype.updateRedPot = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e;
                return __generator(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return this.imgQiandaoRedDot.visible = ZmData.Instance.getSvrData().qiandao.canLingqu(), this.imgPifuRedDot.visible = t.Pifu.canHuode(), e = this.imgZuanshiRedDot, [4, t.GameDiamond.canLinqu()];
                        case 1:
                            return e.visible = i.sent(), [2]
                    }
                })
            })
        }, i.prototype.updateDiamond = function() {
            this.txtDiamond.text = ZmData.Instance.getDiamondCnt().toString()
        }, i.prototype.updateYue = function() {}, i.prototype.updateTili = function() {
            this.txtTili.text = ZmData.Instance.getTiliCnt().toString()
        }, i.prototype.updateTiliSec = function() {
            ZmData.Instance.getTiliCnt() > 0 ? (this.txtTili.visible = !0, this.txtTiliTime.text = "/5") : (this.txtTili.visible = !1, this.txtTiliTime.text = t.Tilibuzu.getShengyuTime())
        }, i.prototype.onStart = function() {
            ZmData.Instance.getPassLevel() > 0 && VideoReward_4399.instace.checkVideo2() ? App.WindowViewManager.showWin(t.LevelSel) : ZmData.Instance.getTiliCnt() > 0 ? (ZmData.Instance.addTili(-1), ZmData.Instance.setReliveCnt(0), App.MessageCenter.dispatch(ZmMessageType.START_GAME), App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, this)) : App.WindowViewManager.showWin(t.Tilibuzu)
        }, i.prototype.onRank = function() {
            gamePlat == PlatType.limi && Core.DialogMod.Instance.Pop("该功能暂未开放！")
        }, i.prototype.onUserSkin = function() {
            App.WindowViewManager.showWin(t.Pifu)
        }, i.prototype.onSet = function() {
            App.WindowViewManager.showWin(t.GameSet)
        }, i.prototype.onShare = function() {
            ZmShare.Instance.share(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareHomePage)
        }, i.prototype.onQiandao = function() {
            App.WindowViewManager.showWin(t.Qiandao)
        }, i.prototype.onChest = function() {
            App.WindowViewManager.showWin(t.GameChest)
        }, i.prototype.onLingquuanshi = function() {
            var t = this;
            VideoReward_4399.instace.playVideo(function() {
                Core.DialogMod.Instance.Pop("Get the Diamond × 50"), ZmData.Instance.addDiamond(50), t.txtDiamond.text = ZmData.Instance.getDiamondCnt().toString()
            }, this)
        }, i.prototype.onShareDiamond = function() {
            App.WindowViewManager.showWin(t.GameDiamond), Core.DialogMod.Instance.Pop("邀请好友点击可以获得大量钻石！")
        }, i.prototype.onBtnRedPack = function() {
            App.WindowViewManager.showWin(t.Fudai)
        }, i.createTousuBtn = function() {
            if (wx.createFeedbackButton) {
                var t = 10,
                    e = App.LayerManager.stage.stageHeight - 1060,
                    i = 80,
                    n = 94,
                    a = platform.getSystemInfoSync();
                if (console.log("systemInfo:", a), a) {
                    var o = a.windowWidth / App.LayerManager.stage.stageWidth,
                        s = a.windowHeight / App.LayerManager.stage.stageHeight;
                    t *= o, e *= s, i *= o, n *= s
                }
                this.fankuiBtn = wx.createFeedbackButton({
                    type: "image",
                    text: "打开意见反馈页面",
                    image: "resource/assets/ui/imgs/zmj_buttom_15.png",
                    style: {
                        left: t,
                        top: e,
                        width: i,
                        height: n,
                        lineHeight: 40,
                        backgroundColor: "",
                        color: "#ffffff",
                        textAlign: "center",
                        fontSize: 16,
                        borderRadius: 4
                    }
                })
            }
        }, i.prototype.createFeedButton = function() {
            this.img_tousu2.visible = !1;
            var t = (this.img_tousu2.localToGlobal(0, 0), 20),
                e = 0,
                n = this.img_tousu2.width,
                a = this.img_tousu2.height;
            if (console.log(t, e, n, a, window._stage.stageWidth, window._stage.stageHeight), wx && wx.getSystemInfoSync) {
                var o = wx.getSystemInfoSync();
                o && (e = this.img_tousu2.verticalCenter + window._stage.stageHeight / 2 - 70, t = t / window._stage.stageWidth * o.screenWidth, n = n / window._stage.stageWidth * o.screenWidth, e = e / window._stage.stageHeight * o.screenHeight, a = a / window._stage.stageHeight * o.screenHeight, i.fankuiBtn ? (i.fankuiBtn.show(), console.log(1)) : (i.fankuiBtn = platform.createFeedbackButton2(t, e, n, a), window.index = this, i.fankuiBtn.show(), console.log(2)))
            } else console.log(3)
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnStart), App.Display.removeButtonPushEffect(this.btnRank), App.Display.removeButtonPushEffect(this.btnUserSkin), App.Display.removeButtonPushEffect(this.btnSet), App.Display.removeButtonPushEffect(this.btnShare), App.Display.removeButtonPushEffect(this.btnQiandao), App.Display.removeButtonPushEffect(this.btnChest), App.Display.removeButtonPushEffect(this.btnLingquuanshi), App.Display.removeButtonPushEffect(this.btnRedPack), App.MessageCenter.removeListener(ZmMessageType.DATA_DIAMOND_CHANGED, this.updateDiamond, this), App.MessageCenter.removeListener(ZmMessageType.DATA_MONEY_CHANGED, this.updateYue, this), App.MessageCenter.removeListener(ZmMessageType.DATA_TILI_CHANGED, this.updateTili, this), App.GlobalRepeatTigger.removeTime(this.updateTiliSec, this)), ZmAdvertisment.Instance.hideAllBannerAd(), i.fankuiBtn && i.fankuiBtn.hide(), App.GlobalRepeatTigger.removeTime(this.updateRedPot, this), e.prototype.destroy.call(this)
        }, i.isPopWin = !1, i.fankuiBtn = null, i
    }(Core.ZmBaseEuiWindow);
    t.ZmHomePage = e, __reflect(e.prototype, "Views.ZmHomePage")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, LevelPropSkin, t) || this;
            i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnSure, i.onSure, i, !0), App.Display.addButtonPushEffect(i.btnCancel, i.onCancel, i, !0), i.imgHead.texture = RES.getRes("head_" + Util.random(0, 35) + "_jpg");
            var n = new egret.Shape;
            return n.x = i.imgHead.x, n.y = i.imgHead.y, n.graphics.beginFill(255), n.graphics.drawRoundRect(0, 0, 100, 100, 42), n.graphics.endFill(), i.grpHead.addChild(n), i.imgHead.mask = n, i
        }
        return __extends(i, e), i.pop = function() {
            this.pifuId = i.randPifu(), i.propRate[LevelPropType.pifu] = this.pifuId < 2 ? 0 : .15;
            var e = LevelData.getData(ZmData.Instance.getPassLevel());
            i.propRate[LevelPropType.doubleScore] = e.passScore < 350 ? 0 : .15;
            var n = Util.randIndex(i.propRate);
            if (!(0 >= n)) {
                var a = n;
                return App.WindowViewManager.showWithData(t.LevelProp, {
                    lpType: a
                }), a
            }
        }, i.randPifu = function() {
            var t = ZmData.Instance.getSkinCnt();
            if (t >= 8) return 1;
            for (var e = Util.random(0, 8 - t), i = 1; 9 > i; i++)
                if (!ZmData.Instance.hasUserSkin(i) && (e--, 0 >= e)) return i;
            return 1
        }, i.prototype.init = function(t) {
            null != t && (this.lpType = t.lpType, this.lpType == LevelPropType.jiansu ? this.txtTip.textFlow = new Array({
                text: "你太厉害了！送你一个减速道具！\n使用后"
            }, {
                text: "本关减速50%",
                style: {
                    textColor: 16766537
                }
            }, {
                text: "！"
            }) : this.lpType == LevelPropType.wudi ? this.txtTip.textFlow = new Array({
                text: "你太厉害了！送你一个无敌道具！\n使用后"
            }, {
                text: "本关免疫5个球",
                style: {
                    textColor: 16766537
                }
            }, {
                text: "！"
            }) : this.lpType == LevelPropType.diamond ? this.txtTip.textFlow = new Array({
                text: "You're awesome! Give you a diamond prop!\n" +
                    "\n" +
                    "After use"
            }, {
                text: "Get double diamonds at this level",
                style: {
                    textColor: 16766537
                }
            }, {
                text: "！"
            }) : this.lpType == LevelPropType.pifu ? this.txtTip.textFlow = new Array({
                text: "你太厉害了！\n送你一次"
            }, {
                text: "新皮肤试用机会",
                style: {
                    textColor: 16766537
                }
            }, {
                text: "！"
            }) : this.lpType == LevelPropType.doubleScore && (this.txtTip.textFlow = new Array({
                text: "你太厉害了！送你一张积分翻倍卡！\n使用后"
            }, {
                text: "所有分数翻倍",
                style: {
                    textColor: 16766537
                }
            }, {
                text: "！"
            })))
        }, i.prototype.onSure = function() {
            VideoReward_4399.instace.playVideo(this.onShare, this)
        }, i.prototype.onShare = function() {
            t.ZmPlayScene.ins.useLevelProp(this.lpType), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareKaijudaoju), this.close()
        }, i.prototype.onCancel = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnSure), App.Display.removeButtonPushEffect(this.btnCancel)), ZmShare.Instance.clearShareDelay(), e.prototype.destroy.call(this)
        }, i.propRate = [.25, .15, .15, .15, .15, .15], i.pifuId = 1, i
    }(Core.ZmBaseEuiWindow);
    t.LevelProp = e, __reflect(e.prototype, "Views.LevelProp")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, LevelSelSkin, t) || this;
            i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnCxks, i.onCxks, i, !0), App.Display.addButtonPushEffect(i.btnJixu, i.onJixu, i, !0), App.Display.addButtonPushEffect(i.btnFuhuo, i.onFuhuo, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i.txtFuhuo.text = "(" + ZmData.Instance.getLevelReliveCnt() + "/3)";
            var n = ZmData.Instance.isLevelFail();
            return i.btnJixu.visible = !n, i.btnFuhuo.visible = n, i
        }
        return __extends(i, e), i.prototype.onCxks = function() {
            ZmData.Instance.setLevelScore(0), ZmData.Instance.setPassLevel(0), ZmData.Instance.setLevelReliveCnt(0), ZmData.Instance.setLevelFail(!1), App.MessageCenter.dispatch(ZmMessageType.START_GAME), this.close(), App.WindowViewManager.close(t.ZmHomePage)
        }, i.prototype.onJixu = function() {
            App.MessageCenter.dispatch(ZmMessageType.START_GAME), this.close(), App.WindowViewManager.close(t.ZmHomePage)
        }, i.prototype.onFuhuo = function() {
            var t = this;
            VideoReward_4399.instace.playVideo(function() {
                t.doRelive()
            }, this)
        }, i.prototype.doRelive = function() {
            ZmData.Instance.setLevelFail(!1), ZmData.Instance.setLevelReliveCnt(ZmData.Instance.getLevelReliveCnt() + 1), App.MessageCenter.dispatch(ZmMessageType.START_GAME), this.close(), App.WindowViewManager.close(t.ZmHomePage)
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnCxks), App.Display.removeButtonPushEffect(this.btnJixu), App.Display.removeButtonPushEffect(this.btnFuhuo), App.Display.removeButtonPushEffect(this.btnGuanbi)), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.LevelSel = e, __reflect(e.prototype, "Views.LevelSel")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, LixianjiangliSkin, t) || this;
            return i.zuanshiNum = 0, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnShuangbeilingqu, i.onShuangbeilingqu, i, !0), App.Display.addButtonPushEffect(i.btnLingqu, i.onLingqu, i, !0), egret.setTimeout(function() {
                this.btnLingqu.visible = !0
            }, i, 2e3), i
        }
        return __extends(i, e), i.initLixian = function() {
            App.MessageCenter.addListener(Core.AppMessageType.APP_HIDE, i.onAppHide, i), App.MessageCenter.addListener(Core.AppMessageType.APP_RESUME, i.onAppResume, i), i.onAppResume()
        }, i.onAppHide = function() {
            var t = ZmData.Instance.getLocalSec();
            ZmData.Instance.setLixianTime(t), Log.trace("Lixianjiangli app hide curSec=" + t)
        }, i.onAppResume = function() {
            var e = ZmData.Instance.getLixianTime();
            if (Log.trace("Lixianjiangli app resumed lixianSec=" + e), e > 1) {
                ZmData.Instance.setLixianTime(0);
                var i = ZmData.Instance.getLocalSec(),
                    n = Math.min(100, Math.floor(.33 * (i - e) / 60));
                n > 4 && (console.log("show Lixianjiangli zsNum=" + n), App.WindowViewManager.showWithData(t.Lixianjiangli, {
                    num: n
                }))
            }
        }, i.prototype.init = function(t) {
            if (t && null != t.num) {
                if (t.num <= 0) return void this.close();
                this.zuanshiNum = Math.ceil(t.num), this.txtZuanshiNum.text = "x" + this.zuanshiNum
            }
        }, i.prototype.onShuangbeilingqu = function() {
            var e = this;
            t.ZmRewardVideoTip.showWithShare(0, ShareType.lixianzuanshi, function(t) {
                e.doShuangbeilingqu()
            }, function() {})
        }, i.prototype.doShuangbeilingqu = function() {
            this.zuanshiNum > 0 && t.HuodeWupin.huoqu({
                wpType: t.WupinType.diamond,
                num: 2 * this.zuanshiNum,
                from: "lixian"
            }), this.close()
        }, i.prototype.onLingqu = function() {
            this.zuanshiNum > 0 && t.HuodeWupin.huoqu({
                wpType: t.WupinType.diamond,
                num: this.zuanshiNum,
                from: "lixian"
            }), this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnShuangbeilingqu), App.Display.removeButtonPushEffect(this.btnLingqu)), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.Lixianjiangli = e, __reflect(e.prototype, "Views.Lixianjiangli")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function() {
        function t() {}
        return t
    }();
    t.ZmMoreGameItemData = e, __reflect(e.prototype, "Views.ZmMoreGameItemData");
    var i = function(t) {
        function e() {
            var e = t.call(this) || this;
            return e.skinName = MoreGameItemSkin, e.addEventListener(egret.TouchEvent.TOUCH_TAP, e.onTouch, e), e
        }
        return __extends(e, t), e.prototype.init = function(t) {
            this.itemData = t, this.lbName.text = t.name, ZmHelper.loadRemoteImgIntoBitmap(this.imgIcon, t.skin)
        }, e.prototype.onTouch = function(t) {
            console.log("跳往小程序 appid=" + this.itemData.appid + ",path=" + this.itemData.path), platform.navigateToMiniProgram(this.itemData.appid, this.itemData.path)
        }, e
    }(eui.Component);
    t.ZmMoreGameItem = i, __reflect(i.prototype, "Views.ZmMoreGameItem")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function() {
        function t() {}
        return t.datas = [{
            index: 1,
            state: 1,
            num: 0,
            icon: "play_json.ball_1_01"
        }, {
            index: 2,
            state: 5,
            num: 10,
            icon: "play_json.ball_1_11"
        }, {
            index: 3,
            state: 5,
            num: 30,
            icon: "play_json.ball_1_17"
        }, {
            index: 4,
            state: 5,
            num: 30,
            icon: "play_json.ball_1_19"
        }, {
            index: 5,
            state: 5,
            num: 50,
            icon: "play_json.ball_1_29"
        }, {
            index: 6,
            state: 5,
            num: 50,
            icon: "play_json.ball_1_31"
        }, {
            index: 7,
            state: 5,
            num: 200,
            icon: "play_json.ball_1_41"
        }, {
            index: 8,
            state: 5,
            num: 500,
            icon: "play_json.ball_1_43"
        }], t
    }();
    t.PifuDataItem = e, __reflect(e.prototype, "Views.PifuDataItem");
    var i = function(i) {
        function n(t) {
            var e = i.call(this, PifuSkin, t) || this;
            return e.items = [], e.width = App.LayerManager.stage.stageWidth, e.height = App.LayerManager.stage.stageHeight, e.updateSuipian(), App.Display.addButtonPushEffect(e.btnGuanbi, e.onGuanbi, e, !0), App.Display.addButton(e.btnRandPifu, e.onRandPifu, e), App.MessageCenter.addListener(ZmMessageType.DATA_SUIPIANCNT_CHANGED, e.updateSuipian, e), e
        }
        return __extends(n, i), n.prototype.init = function() {
            return __awaiter(this, void 0, void 0, function() {
                var i, a, o;
                return __generator(this, function(s) {
                    switch (s.label) {
                        case 0:
                            return [4, n.updateData()];
                        case 1:
                            for (s.sent(), wx && wx.getSystemInfo && (i = wx.getSystemInfo(), i && (this.group_ad.width = i.screenWidth)), a = 0; a < e.datas.length; a++) o = new t.PifuCell(this), this.grpItems.addChild(o), this.items.push(o);
                            return this.update(), [2]
                    }
                })
            })
        }, n.prototype.update = function() {
            for (var t = 0; t < e.datas.length; t++) {
                var i = e.datas[t],
                    n = t + 1;
                n == ZmData.Instance.getCurSkinId() ? i.state = 2 : ZmData.Instance.hasUserSkin(n) && (i.state = 1);
                var a = this.items[t];
                a.init(i)
            }
            var o = ZmData.Instance.getSkinCnt();
            this.txtJiesuoPifuCnt.text = o.toString(), this.txtPifuScore.text = (4 + o).toString(), this.updateRandPifu()
        }, n.updateData = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(t) {
                    return n.ivtCnt = 0, this.updateItem(), [2]
                })
            })
        }, n.updateItem = function() {
            for (var t = 0; t < e.datas.length; t++) {
                var i = e.datas[t],
                    n = t + 1;
                n == ZmData.Instance.getCurSkinId() ? i.state = 2 : ZmData.Instance.hasUserSkin(n) && (i.state = 1)
            }
        }, n.canHuode = function() {
            for (var t = 0; t < e.datas.length; t++) {
                var i = e.datas[t];
                if (i.state > 2 && n.canHuodeItem(i)) return !0
            }
            return !1
        }, n.canHuodeItem = function(t) {
            return 3 == t.state ? ZmData.Instance.getDiamondCnt() >= t.num : 4 == t.state ? n.ivtCnt >= t.num : 5 == t.state ? ZmData.Instance.getSuipianCnt() >= t.num : !1
        }, n.prototype.updateRandPifu = function() {
            var t = ZmData.Instance.getIsRandSkin();
            this.imgRandPifuN.visible = !t, this.imgRandPifuY.visible = t
        }, n.prototype.onGuanbi = function() {
            this.close()
        }, n.prototype.onRandPifu = function() {
            ZmData.Instance.setIsRandSkin(!ZmData.Instance.getIsRandSkin()), this.updateRandPifu()
        }, n.prototype.updateSuipian = function() {
            this.txtSuipianNum.text = ZmData.Instance.getSvrData().suipianCnt.toString()
        }, n.prototype.destroy = function() {
            this._active && (ZmAdvertisment.Instance.hideAllBannerAd(), App.MessageCenter.dispatch(ZmMessageType.SHOW_ANIAD), App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButton(this.btnRandPifu), App.MessageCenter.removeListener(ZmMessageType.DATA_SUIPIANCNT_CHANGED, this.updateSuipian, this)), i.prototype.destroy.call(this)
        }, n.ivtCnt = 0, n
    }(Core.ZmBaseEuiWindow);
    t.Pifu = i, __reflect(i.prototype, "Views.Pifu")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this) || this;
            return i.skinName = PifuCellSkin, i.pifu = t, App.Display.addButtonPushEffect(i.grpState1, i.onZhuangbei, i, !0, .95), App.Display.addButtonPushEffect(i.grpState3, i.onZuanshi, i, !0, .95), App.Display.addButtonPushEffect(i.grpState4, i.onYaoqinhaoyou, i, !0, .95), App.Display.addButtonPushEffect(i.grpState5, i.onSuipian, i, !0, .95), i
        }
        return __extends(i, e), i.prototype.init = function(e) {
            for (var i = 1; 6 > i; i++) e.state == i ? this["grpState" + i].visible = !0 : this["grpState" + i].visible = !1;
            3 == e.state ? (this.txtDiamondCnt.text = e.num.toString(), this.imgRedDot3.visible = t.Pifu.canHuodeItem(e)) : 4 == e.state ? (this.txtYaoqin.text = Math.min(e.num, t.Pifu.ivtCnt) + "/" + e.num, this.imgRedDot4.visible = t.Pifu.canHuodeItem(e)) : 5 == e.state && (this.txtSuipianCnt.text = e.num.toString(), this.imgRedDot5.visible = t.Pifu.canHuodeItem(e)), this.imgIcon.texture = Util.getRes(e.icon), this.data = e
        }, i.prototype.onZhuangbei = function() {
            ZmData.Instance.setCurSkinId(this.data.index), this.pifu.update()
        }, i.prototype.onZuanshi = function() {
            return __awaiter(this, void 0, void 0, function() {
                var t;
                return __generator(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return ZmData.Instance.getDiamondCnt() < this.data.num ? (Core.DialogMod.Instance.Pop("Not enough diamonds"), [2]) : [4, ZmData.Instance.addDiamond(-this.data.num)];
                        case 1:
                            return t = e.sent(), t && (this.data.state = 1, ZmData.Instance.newSkin(this.data.index), this.init(this.data), Core.DialogMod.Instance.Pop("Unlock succeeded")), [2]
                    }
                })
            })
        }, i.prototype.onYaoqinhaoyou = function() {
            this.data.num > t.Pifu.ivtCnt ? (ZmShare.Instance.share(), GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareSkin)) : (this.data.state = 1, ZmData.Instance.newSkin(this.data.index), this.init(this.data), Core.DialogMod.Instance.Pop("解锁成功"))
        }, i.prototype.onSuipian = function() {
            return __awaiter(this, void 0, void 0, function() {
                return __generator(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return ZmData.Instance.getSuipianCnt() < this.data.num ? (App.WindowViewManager.showWithData(t.Suipianbuzu, {
                                itemData: this.data
                            }), [2]) : [4, ZmData.Instance.setSuipianCnt(ZmData.Instance.getSuipianCnt() - this.data.num)];
                        case 1:
                            return e.sent(), this.data.state = 1, ZmData.Instance.newSkin(this.data.index), this.init(this.data), Core.DialogMod.Instance.Pop("Unlock succeeded"), [2]
                    }
                })
            })
        }, i.prototype.destroy = function() {
            App.Display.removeButtonPushEffect(this.grpState1)
        }, i
    }(eui.Component);
    t.PifuCell = e, __reflect(e.prototype, "Views.PifuCell")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, QiandaoSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i.txtLingqu.textFlow = new Array({
                text: "Receive",
                style: {
                    underline: !0
                }
            }), i
        }
        return __extends(i, e), i.prototype.init = function() {
            this.update(),this.btnSure.visible = !0; //VideoReward_4399.instace.checkVideo2() || (this.btnSure.visible = !1)
        }, i.prototype.update = function() {
            var t = ZmData.Instance.getSvrData().qiandao;
            console.log("qiandao qd:", t), t.canLingqu() && t.lingqus[6] && t.reset();
            var e = t.dayIndex;
            t.canLingqu() || e--;
            for (var i = 0; 7 > i; i++) {
                var n = i + 1,
                    a = t.lingqus[i];
                this["imgJrbg" + n].visible = i == e, this["imgYilingqu" + n].visible = a, this["imgJinri" + n].visible = i == e
            }
            t.canLingqu() ? (App.Display.addButtonPushEffect(this.btnSure, this.onSure, this, !0), App.Display.addButtonPushEffect(this.btnLingqu, this.onLingqu, this, !0)) : (Core.DisplayUtilMod.Instance.addGrayFlilter(this.btnSure), App.Display.removeButtonPushEffect(this.btnSure), Core.DisplayUtilMod.Instance.addGrayFlilter(this.btnLingqu), App.Display.removeButtonPushEffect(this.btnLingqu))
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.onSure = function() {
            VideoReward_4399.instace.playVideo(this.onShare, this)
        }, i.prototype.onShare = function() {
            GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareQiandaoShuangbei), this.doLingqu(2)
        }, i.prototype.onLingqu = function() {
            this.doLingqu()
        }, i.prototype.doLingqu = function(e) {
            void 0 === e && (e = 1);
            var n = ZmData.Instance.getSvrData().qiandao;
            n.dayIndex > 6 || (this.curLingquWupin = new t.WupinData, this.curLingquWupin.wpType = i.QiandaoWupins[n.dayIndex], this.curLingquWupin.num = i.QiandaoWupinNums[n.dayIndex] * e, n.lingqus[n.dayIndex] = !0, n.dayIndex++, n.lastAwardDate = Util.getDataStr(ZmData.Instance.getLocalDate()), ZmData.Instance.saveSvrData(), this.update(), 1 == e && (this.curLingquWupin.cb = this.onHuodeWupin, this.curLingquWupin.cbObj = this), t.HuodeWupin.huoqu(this.curLingquWupin), ZmData.Instance.savaData())
        }, i.prototype.onHuodeWupin = function() {
            this.curLingquWupin.cb = null, this.curLingquWupin.cbObj = null, VideoReward_4399.instace.checkVideo2() && App.WindowViewManager.showWithData(t.Zailaiyifen, this.curLingquWupin)
        }, i.prototype.destroy = function() {
            this._active && (App.MessageCenter.dispatch(ZmMessageType.SHOW_ANIAD), App.Display.removeButtonPushEffect(this.btnGuanbi), App.Display.removeButtonPushEffect(this.btnSure), App.Display.removeButtonPushEffect(this.btnLingqu)), e.prototype.destroy.call(this)
        }, i.QiandaoWupins = [t.WupinType.diamond, t.WupinType.diamond, t.WupinType.diamond, t.WupinType.diamond, t.WupinType.diamond, t.WupinType.diamond, t.WupinType.suipian], i.QiandaoWupinNums = [50, 50, 60, 70, 80, 90, 5], i
    }(Core.ZmBaseEuiWindow);
    t.Qiandao = e, __reflect(e.prototype, "Views.Qiandao")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function() {
        function t() {}
        return t
    }();
    t.ZmRankDataItem = e, __reflect(e.prototype, "Views.ZmRankDataItem");
    var i = function(t) {
        function e() {
            var e = t.call(this) || this;
            return e.skinName = RankCellSkin, e
        }
        return __extends(e, t), e.prototype.init = function(t, e) {
            if (this.imgRankIcon.visible = !1, this.lbNick.text = t.nick, this.lbNick.width > 160) {
                for (; this.lbNick.width > 142 && this.lbNick.text.length > 5;) this.lbNick.text = this.lbNick.text.substr(0, this.lbNick.text.length - 1);
                this.lbNick.text = this.lbNick.text + "..."
            }
            this.lbRankPos.text = "" + e, this.lbRankScore.text = "" + t.score, 3 >= e && (this.imgRankIcon.visible = !0), this.imgRankIcon.texture = Util.getRes("play_json.zmj_icon_0" + (6 + e)), String.isNullOrEmpty(t.avatar) || ZmHelper.loadRemoteImgIntoBitmap(this.imgHead, t.avatar)
        }, e
    }(eui.Component);
    t.ZmRankCell = i, __reflect(i.prototype, "Views.ZmRankCell")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(t) {
        function e(e) {
            var i = t.call(this, RedPackSkin, e) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnTixian, i.onTixian, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(e, t), e.prototype.init = function(t) {
            var e = ZmData.Instance.getSvrData().redPack;
            this.txtYue.text = e.getMoneyStr() + "元", t && t.money ? (this.grpHuode.visible = !0, this.txtHuode.text = t.money + "元", this.grpYue.x = 231, this.grpYue.y = 348) : (this.grpHuode.visible = !1, this.grpYue.x = 231, this.grpYue.y = 397)
        }, e.prototype.onTixian = function() {
            Core.DialogMod.Instance.Pop("亲，满20元才能提现哦~")
        }, e.prototype.onGuanbi = function() {
            this.close()
        }, e.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnTixian), App.Display.removeButtonPushEffect(this.btnGuanbi)), t.prototype.destroy.call(this)
        }, e
    }(Core.ZmBaseEuiWindow);
    t.RedPack = e, __reflect(e.prototype, "Views.RedPack")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, RedPackOpenSkin, t) || this;
            return i.bDailingqu = !1, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnOpen, i.onOpen, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(i, e), i.prototype.init = function(t) {
            t && t.bDailingqu && (this.bDailingqu = t.bDailingqu)
        }, i.prototype.onOpen = function() {
            var e = this,
                i = ZmData.Instance.getSvrData().redPack,
                n = i.hbNum;
            if (n > 9) Core.DialogMod.Instance.Pop("今日福袋已领完！"), ZmData.Instance.getSvrData().redPack.setDailingqu(), ZmData.Instance.saveSvrData(), App.MessageCenter.dispatch(ZmMessageType.DATA_MONEY_CHANGED), this.close();
            else if (0 == n && 0 == i.dayIndex) this.doRedPack();
            else {
                var a = !1;
                a = i.money < 13.72 ? 5 > n : n >= 5, a ? ZmShare.Instance.share(ShareType.redPack) : t.ZmRewardVideoTip.showWithShare(1, ShareType.redPack, function(t) {
                    e.doRedPack()
                }, function() {}, !0)
            }
        }, i.prototype.doRedPack = function() {
            var e = ZmData.Instance.getSvrData().redPack.createRedPack();
            e > 0 && (Core.DialogMod.Instance.Pop("领取成功"), ZmData.Instance.getSvrData().redPack.lingqu(e, this.bDailingqu), ZmData.Instance.saveSvrData(), App.WindowViewManager.showWithData(t.RedPack, {
                money: e
            })), this.close()
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnOpen), App.Display.removeButtonPushEffect(this.btnGuanbi)), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.RedPackOpen = e, __reflect(e.prototype, "Views.RedPackOpen")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(t) {
        function e(e) {
            var i = t.call(this, ZmRewardVideoTipSkin, e) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnSure, i.onSure, i, !0), App.Display.addButtonPushEffect(i.btnCancel, i.onCancel, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i.imgPlay.addEventListener(egret.TouchEvent.TOUCH_TAP, i.onSure, i), ZmAdvertisment.Instance.showSingleBannerAd(0), i
        }
        return __extends(e, t), e.showWithShare = function(t, i, n, a, o) {
            return void 0 === a && (a = null), void 0 === o && (o = !1), __awaiter(this, void 0, void 0, function() {
                var s, r;
                return __generator(this, function(h) {
                    switch (h.label) {
                        case 0:
                            return s = !1, ZmSvrCfg.Instance.getRewardVideoIsOpen() ? (s = !0, gamePlat == PlatType.limi && ZmSoundManager.Instance.stopSound("bgm"), e.isPlayReward = !0, [4, ZmAdvertisment.showRewardAd(t)]) : [3, 2];
                        case 1:
                            if (r = h.sent(), gamePlat == PlatType.limi && ZmSoundManager.Instance.playSound("bgm"), e.isPlayReward = !1, 1 == r) return n && n(2), GameSvrLog.Instance.LogEventByShareType(i), [2];
                            if (0 == r) return a && a(), [2];
                            h.label = 2;
                        case 2:
                            return s && (o || gamePlat == PlatType.limi) ? [3, 6] : ZmSvrCfg.Instance.getShareIsOpen() ? Util.isQQ() ? (egret.setTimeout(function() {
                                ZmShare.Instance.share(i)
                            }, this, 200), [3, 5]) : [3, 3] : [3, 6];
                        case 3:
                            return [4, ZmShare.Instance.share(i)];
                        case 4:
                            h.sent(), h.label = 5;
                        case 5:
                            return [2];
                        case 6:
                            return a && a(), [2]
                    }
                })
            })
        }, e.prototype.onSure = function() {
            return __awaiter(this, void 0, void 0, function() {
                var t, e;
                return __generator(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, ZmAdvertisment.showRewardAd(this.rewardAdUId)];
                        case 1:
                            return (t = i.sent()) ? (this.onOk && (this.onOk(2), App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, this)), [3, 4]) : [3, 2];
                        case 2:
                            return ZmSvrCfg.Instance.getShareIsOpen() ? [4, ZmShare.Instance.doShareAppMessage("", "share1")] : [3, 4];
                        case 3:
                            e = i.sent(), e ? this.onOk(1) : this.onFail && this.onFail(), i.label = 4;
                        case 4:
                            return [2]
                    }
                })
            })
        }, e.prototype.onCancel = function() {
            App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, this)
        }, e.prototype.onGuanbi = function() {
            App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, this)
        }, e.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnSure), App.Display.removeButtonPushEffect(this.btnCancel), App.Display.removeButtonPushEffect(this.btnGuanbi), this.imgPlay.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onSure, this)), ZmAdvertisment.Instance.hideSingleBannerAd(), t.prototype.destroy.call(this), App.MessageCenter.dispatch(ZmMessageType.REWARDVIDEOTIP_CLOSE)
        }, e.isPlayReward = !1, e
    }(Core.ZmBaseEuiWindow);
    t.ZmRewardVideoTip = e, __reflect(e.prototype, "Views.ZmRewardVideoTip")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, SuipianbuzuSkin, t) || this;
            return i.zuanshiNum = 0, i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGoumai, i.onGoumai, i, !0), App.Display.addButtonPushEffect(i.btnMianfei, i.onMianfei, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), i
        }
        return __extends(i, e), i.prototype.init = function(t) {
            this.data = t.itemData;
            var e = this.data.num - ZmData.Instance.getSvrData().suipianCnt;
            this.txtSuipianCnt.text = "x" + e, this.zuanshiNum = 50 * e, this.txtZuanshiCnt.text = this.zuanshiNum + "", ZmData.Instance.getDiamondCnt() < this.zuanshiNum && Core.DisplayUtilMod.Instance.addGrayFlilter(this.btnGoumai)
        }, i.prototype.onGoumai = function() {
            return __awaiter(this, void 0, void 0, function() {
                var e;
                return __generator(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return ZmData.Instance.getDiamondCnt() < this.zuanshiNum ? (Core.DialogMod.Instance.Pop("Not enough diamonds"), [2]) : [4, ZmData.Instance.addDiamond(-this.zuanshiNum)];
                        case 1:
                            return e = i.sent(), e && (t.HuodeWupin.huoqu({
                                wpType: t.WupinType.suipian,
                                num: Math.floor(this.zuanshiNum / 50)
                            }), this.close()), [2]
                    }
                })
            })
        }, i.prototype.onMianfei = function() {
            var e = this;
            t.ZmRewardVideoTip.showWithShare(0, ShareType.suipian, function(t) {
                e.doSuipian()
            }, function() {})
        }, i.prototype.doSuipian = function() {
            t.HuodeWupin.huoqu({
                wpType: t.WupinType.suipian,
                num: 1
            })
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnGoumai), App.Display.removeButtonPushEffect(this.btnMianfei), App.Display.removeButtonPushEffect(this.btnGuanbi)), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.Suipianbuzu = e, __reflect(e.prototype, "Views.Suipianbuzu")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, TilibuzuSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, App.Display.addButtonPushEffect(i.btnGoumai, i.onGoumai, i, !0), App.Display.addButtonPushEffect(i.btnMianfei, i.onMianfei, i, !0), App.Display.addButtonPushEffect(i.btnGuanbi, i.onGuanbi, i, !0), App.GlobalRepeatTigger.addTime(1e3, i.updateTiliSec, i), i
        }
        return __extends(i, e), i.getShengyuTime = function() {
            if (ZmData.Instance.getTiliCnt() > 0) return "";
            var t = ZmData.Instance.getLocalSec(),
                e = ZmData.Instance.getTiliLastTime(),
                i = e + 1200 - t,
                n = Math.floor(i / 60),
                a = Math.floor(i - 60 * n);
            return (10 > n ? "0" : "") + n + ":" + (10 > a ? "0" : "") + a
        }, i.prototype.init = function() {}, i.prototype.onGoumai = function() {
            return __awaiter(this, void 0, void 0, function() {
                var t;
                return __generator(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return ZmData.Instance.getDiamondCnt() < 200 ? (Core.DialogMod.Instance.Pop("Not enough diamonds"), [2]) : [4, ZmData.Instance.addDiamond(-200)];
                        case 1:
                            return t = e.sent(), t && this.doTili(), [2]
                    }
                })
            })
        }, i.prototype.onMianfei = function() {
            var e = this;
            ++i.shareCnt % i.shareVideoCnt == 0 ? t.ZmRewardVideoTip.showWithShare(0, ShareType.tili, function(t) {
                e.doTili()
            }, function() {}) : ZmShare.Instance.share(ShareType.tili)
        }, i.prototype.doTili = function() {
            Core.DialogMod.Instance.Pop("体力+2"), ZmData.Instance.addTili(1), App.MessageCenter.dispatch(ZmMessageType.START_GAME), App.WindowViewManager.closeAll()
        }, i.prototype.onGuanbi = function() {
            this.close()
        }, i.prototype.updateTiliSec = function() {
            return ZmData.Instance.getTiliCnt() > 0 ? (ZmData.Instance.addTili(-1), App.MessageCenter.dispatch(ZmMessageType.START_GAME), void App.WindowViewManager.closeAll()) : void(this.txtTiliTime.text = i.getShengyuTime())
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnGoumai), App.Display.removeButtonPushEffect(this.btnMianfei), App.Display.removeButtonPushEffect(this.btnGuanbi), App.GlobalRepeatTigger.removeTime(this.updateTiliSec, this)), e.prototype.destroy.call(this)
        }, i.shareCnt = 0, i.shareVideoCnt = 3, i
    }(Core.ZmBaseEuiWindow);
    t.Tilibuzu = e, __reflect(e.prototype, "Views.Tilibuzu")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e;
    ! function(t) {
        t[t.stepDrag = 1] = "stepDrag", t[t.stepNext = 2] = "stepNext", t[t.stepBlockZise = 3] = "stepBlockZise", t[t.stepHomePage = 4] = "stepHomePage"
    }(e = t.ZmGuidStepType || (t.ZmGuidStepType = {}));
    var i = function(i) {
        function n(t) {
            var e = i.call(this, ZmUserGuidSkin, t) || this;
            return e.width = App.LayerManager.stage.stageWidth, e.height = App.LayerManager.stage.stageHeight, e.initGuid(), n.ins = e, e
        }
        return __extends(n, i), n.checkGuid = function(e) {
            var i = ZmData.Instance.getGuidStep();
            return i == e ? (App.WindowViewManager.showWin(t.ZmUserGuid), !0) : !1
        }, n.CompleteGuid = function(t) {
            var e = ZmData.Instance.getGuidStep();
            return e != t ? !1 : null == n.ins ? !1 : (ZmData.Instance.setGuidStep(ZmData.Instance.getGuidStep() + 1), App.MessageCenter.dispatch(ZmMessageType.USERGUID_COMPLETE), App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, n.ins), !0)
        }, n.prototype.initGuid = function() {
            var t = ZmData.Instance.getGuidStep();
            if (t == e.stepDrag) {
                var i = (App.LayerManager.stage.stageWidth, App.LayerManager.stage.stageHeight);
                this.imgTop.bottom = 473, this.imgBottom.top = i - 237, this.grpStepDrag.visible = !0, Util.playAnim(this.stepDragAnim, !0), this.grpTip.y = i - 436, this.imgTipBk.width = 320, this.imgTipBk.height = 40, this.txtTip.width = 320, this.txtTip.height = 40, this.txtTip.text = "按住方块，向左拖动1格后松手"
            } else if (t == e.stepNext) {
                var i = (App.LayerManager.stage.stageWidth, App.LayerManager.stage.stageHeight);
                this.imgTop.bottom = 239, this.imgBottom.top = i - 181, this.grpTip.y = i - 316, this.imgTipBk.width = 397, this.imgTipBk.height = 76, this.txtTip.width = 397, this.txtTip.height = 76, this.txtTip.text = "注意：这里是下一行将出现的方块！\n<点击开始游戏>", this.grpGuid.visible = !0, this.grpGuid.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this)
            } else if (t == e.stepBlockZise) this.imgTop.bottom = 309, this.imgBottom.top = 901, this.grpTip.y = 738, this.imgTipBk.width = 500, this.imgTipBk.height = 76, this.txtTip.width = 500, this.txtTip.height = 76, this.txtTip.text = "带闪电的紫色方块被消除时，所有与其相连的方块也会消失！尽可能的消除紫色方块吧！", this.grpGuid.visible = !0, this.grpGuid.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this);
            else if (t == e.stepHomePage) {
                var i = (App.LayerManager.stage.stageWidth, App.LayerManager.stage.stageHeight);
                this.imgTop.bottom = i / 2 + 130, this.imgBottom.top = i / 2 + 130, this.grpTip.y = i / 2 + 140, this.imgTipBk.width = 372, this.imgTipBk.height = 76, this.txtTip.width = 372, this.txtTip.height = 76, this.txtTip.text = "点击道具图标可以获得道具奖励！\n游戏开始之前最多可以获得三个！", this.imgTop.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this), this.imgBottom.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this)
            }
        }, n.prototype.onTouch = function(t) {
            if (ZmData.Instance.getGuidStep() != e.stepDrag && ZmData.Instance.getGuidStep() != e.stepHomePage) {
                var i = ZmData.Instance.getGuidStep();
                ZmData.Instance.setGuidStep(i + (i == e.stepNext ? 2 : 1)), App.MessageCenter.dispatch(ZmMessageType.USERGUID_COMPLETE), App.MessageCenter.dispatch(Core.AppMessageType.CLOSE_EUI_VIEW, this)
            }
        }, n.prototype.destroy = function() {
            this._active && (this.stepDragAnim.stop(), this.grpGuid.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch, this)), i.prototype.destroy.call(this), n.ins = null
        }, n
    }(Core.ZmBaseEuiWindow);
    t.ZmUserGuid = i, __reflect(i.prototype, "Views.ZmUserGuid")
}(Views || (Views = {}));
var Views;
! function(t) {
    var e = function(e) {
        function i(t) {
            var i = e.call(this, ZailaiyifenSkin, t) || this;
            return i.width = App.LayerManager.stage.stageWidth, i.height = App.LayerManager.stage.stageHeight, i.txtCancel.textFlow = new Array({
                text: "狠心放弃 >>",
                style: {
                    underline: !0
                }
            }), App.Display.addButtonPushEffect(i.btnLingqu, i.onLingqu, i, !0), App.Display.addButtonPushEffect(i.btnCancel, i.onCancel, i, !0), i
        }
        return __extends(i, e), i.prototype.init = function(t) {
            if (null != t) {
                this.wpType = t.wpType, this.wpNum = t.num;
                for (var e = 0; 4 > e; e++) this["imgWupin" + (e + 1)].visible = e == t.wpType;
                this.txtNum.text = "x" + this.wpNum.toString()
            }
        }, i.prototype.onLingqu = function() {
            var t = this;
            VideoReward_4399.instace.playVideo(function() {
                ZmShare.Instance.shareDelay(t, t.onShare)
            }, this)
        }, i.prototype.onShare = function() {
            GameSvrLog.Instance.LogEvent(GameSvrLog.evt_shareQiandao), t.HuodeWupin.huoqu({
                wpType: this.wpType,
                num: this.wpType
            }), this.close()
        }, i.prototype.onCancel = function() {
            this.close()
        }, i.prototype.destroy = function() {
            this._active && (App.Display.removeButtonPushEffect(this.btnLingqu), App.Display.removeButtonPushEffect(this.btnCancel)), e.prototype.destroy.call(this)
        }, i
    }(Core.ZmBaseEuiWindow);
    t.Zailaiyifen = e, __reflect(e.prototype, "Views.Zailaiyifen")
}(Views || (Views = {}));
var Utility;
! function(t) {
    var e = function() {
        function t() {}
        return t.From = function(t) {
            return new Promise(function(e, i) {
                e(t)
            })
        }, t.Defer = function(t, e) {
            return void 0 === e && (e = !1), new Promise(function(i, n) {
                egret.setTimeout(function() {
                    e ? n() : i()
                }, null, t)
            })
        }, t.NextFrame = function(t, e) {
            return void 0 === e && (e = !1), new Promise(function(i, n) {
                var a = function(o) {
                    return e ? n() : i(), t.stopTick(a, null), !1
                };
                t.startTick(a, null)
            })
        }, t.Frames = function(t, e, i) {
            void 0 === i && (i = !1);
            var n = 0;
            return new Promise(function(a, o) {
                var s = function(r) {
                    return n++, n >= e && (i ? o() : a(), t.stopTick(s, null)), !1
                };
                t.startTick(s, null)
            })
        }, t.FromEvent = function(t, e, i, n, a) {
            return new Promise(function(o, s) {
                var r = function(n) {
                    t.removeEventListener(e, r, null, i), o({
                        evt: n,
                        target: n.currentTarget
                    })
                };
                if (t.addEventListener(e, r, null, i, n), a) {
                    var h = function(e) {
                        t.removeEventListener(a, h, null, i), s({
                            evt: e,
                            target: e.currentTarget
                        })
                    };
                    t.addEventListener(a, h, null, i, n)
                }
            })
        }, t.FromEventEx = function(t) {
            return new Promise(function(e, i) {
                var n = function(i) {
                    t.obj.removeEventListener(t.evtName, n, null), e({
                        evt: i,
                        target: i.currentTarget
                    })
                };
                if (t.obj.addEventListener(t.evtName, n, null, t.useCapture, t.priority), t.errEvtName) {
                    var a = function(e) {
                        t.obj.removeEventListener(t.errEvtName, a, null), i({
                            evt: e,
                            target: e.currentTarget
                        })
                    };
                    t.obj.addEventListener(t.errEvtName, a, null, t.useCapture, t.priority)
                }
            })
        }, t.FromSFCAsync = function(t) {
            return new Promise(function(e, i) {
                t.success = function(t) {
                    e(t)
                }, t.fail = function(t) {
                    i(t)
                }, t.complete = function(t) {
                    e(t)
                }
            })
        }, t.createAsync = function() {
            var t = {
                    resolve: null,
                    reject: null
                },
                e = new Promise(function(e, i) {
                    t.resolve = e, t.reject = i
                }),
                i = {
                    future: e,
                    completion: t,
                    canceled: !1,
                    cancele: function() {
                        return i.canceled = !0
                    }
                };
            return i
        }, t
    }();
    t.ZmAsync = e, __reflect(e.prototype, "Utility.ZmAsync")
}(Utility || (Utility = {}));
var Utility;
! function(t) {
    var e = function() {
        function t() {
            this._dic = {}
        }
        return t.prototype.contains = function(t) {
            return this._dic.hasOwnProperty(t)
        }, t.prototype.add = function(t, e) {
            this.set(t, e)
        }, t.prototype.remove = function(t) {
            this._dic.hasOwnProperty(t) && delete this._dic[t]
        }, t.prototype.get = function(t) {
            return this._dic.hasOwnProperty(t) ? this._dic[t] : void 0
        }, t.prototype.set = function(t, e) {
            if (this._dic.hasOwnProperty(t)) {
                var i = this._dic[t];
                if (i == e) return
            }
            this._dic[t] = e
        }, Object.defineProperty(t.prototype, "keys", {
            get: function() {
                return Object.keys(this._dic)
            },
            enumerable: !0,
            configurable: !0
        }), t
    }();
    t.ZmDictionary = e, __reflect(e.prototype, "Utility.ZmDictionary")
}(Utility || (Utility = {}));
var Utility;
! function(t) {
    var e = function() {
        function t(t, e) {
            var i = null == t ? 20 : t,
                n = null == e ? !1 : e;
            this.init(i), this.IsAutoAdaptive = n
        }
        return t.prototype.clone = function(e) {
            e < this.length && (e = this.length);
            for (var i = new t(e), n = 0; n < this.length; n++) {
                var a = this.get_at(n);
                i.push(a)
            }
            return i.IsAutoAdaptive = this.IsAutoAdaptive, i
        }, t.prototype.reset = function() {
            for (var t = 0; t < this.mCapacity; t++) delete this.mItemList[t], this.mItemList[t] = void 0;
            this.mYinYang = -1, this.mNIndex = this.mNFreeIndex = 0, this.mMIndex = this.mMFreeIndex = 0
        }, t.prototype.init = function(t) {
            this.mItemList = new Array(t), this.mCapacity = t, this.mYinYang = -1, this.mNIndex = this.mNFreeIndex = 0, this.mMIndex = this.mMFreeIndex = 0, this.IsAutoAdaptive = !1
        }, t.prototype.moveClockwise = function(t, e) {
            return t = (t + e) % this.mCapacity
        }, t.prototype.moveReverseClockwise = function(t, e) {
            return t += this.mCapacity - e, t %= this.mCapacity
        }, t.prototype.reAdaptCapacity = function(t) {
            var e = this.length,
                i = this.mItemList;
            if (e > t && (t = e), this.mItemList = new Array(t), e > 0) {
                var n = 0;
                this.mItemList[n++] = i[this.mNIndex];
                var a = this.mNIndex;
                for (a = this.moveClockwise(a, 1); a != this.mMIndex; a = this.moveClockwise(a, 1)) this.mItemList[n++] = i[a]
            }
            this.mNIndex = 0, this.mNFreeIndex = 0, this.mMIndex = e, this.mMFreeIndex = this.mMIndex, this.mCapacity = t, 0 == e ? this.mYinYang = -1 : e == this.mCapacity ? this.mYinYang = 1 : this.mYinYang = 0
        }, Object.defineProperty(t.prototype, "IsAutoAdaptive", {
            get: function() {
                return this._autoadaptive
            },
            set: function(t) {
                this._autoadaptive = t
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "length", {
            get: function() {
                return this.mYinYang < 0 ? 0 : this.mYinYang > 0 ? this.mCapacity : (this.mCapacity - this.mNIndex + this.mMIndex) % this.mCapacity
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "freeCount", {
            get: function() {
                return this.mCapacity - this.length
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "nFree", {
            get: function() {
                return this.mNFreeIndex <= this.mNIndex ? this.mNIndex - this.mNFreeIndex : this.mCapacity - this.mNFreeIndex + this.mNIndex
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t.prototype, "mFree", {
            get: function() {
                return this.mMIndex <= this.mMFreeIndex ? this.mMFreeIndex - this.mMIndex : this.mCapacity - this.mMIndex + this.mMFreeIndex
            },
            enumerable: !0,
            configurable: !0
        }), t.prototype.tryMoreCapacity = function() {
            if (this.IsAutoAdaptive) {
                var t = this.mCapacity > 512 ? this.mCapacity + (1024 - this.mCapacity % 1024) : this.mCapacity + this.mCapacity;
                t < this.mCapacity || this.reAdaptCapacity(t)
            }
        }, t.prototype.allocForN = function(t) {
            return 0 >= t ? 0 : this.freeCount < t && (this.tryMoreCapacity(), this.freeCount < t) ? 0 : (this.mNFreeIndex = this.moveReverseClockwise(this.mNFreeIndex, t), t)
        }, t.prototype.freeFromN = function(t) {
            return 0 >= t || this.length <= 0 ? 0 : (t >= this.length ? (t = this.length, this.mYinYang = -1) : this.mYinYang = 0, this.mNIndex = this.moveClockwise(this.mNIndex, t), t)
        }, t.prototype.allocForM = function(t) {
            return 0 >= t ? 0 : this.freeCount < t && (this.tryMoreCapacity(), this.freeCount < t) ? 0 : (this.mMFreeIndex = this.moveClockwise(this.mMFreeIndex, t), t)
        }, t.prototype.freeFromM = function(t) {
            return 0 >= t || this.length <= 0 ? 0 : (t >= this.length ? (t = this.length, this.mYinYang = -1) : this.mYinYang = 0, this.mMIndex = this.moveReverseClockwise(this.mMIndex, t), t)
        }, t.prototype.rPush = function(t) {
            return this.nFree < 1 && this.allocForN(1) <= 0 ? !1 : (this.mNIndex = this.moveReverseClockwise(this.mNIndex, 1), this.mNIndex == this.mMIndex ? this.mYinYang = 1 : this.mYinYang = 0, this.mItemList[this.mNIndex] = t, !0)
        }, t.prototype.rPop = function() {
            if (!(this.length <= 0)) {
                var t = this.mItemList[this.mNIndex];
                return this.mItemList[this.mNIndex] = void 0, this.freeFromN(1), t
            }
        }, t.prototype.push = function(t) {
            return this.mFree < 1 && this.allocForM(1) <= 0 ? !1 : (this.mItemList[this.mMIndex] = t, this.mMIndex = this.moveClockwise(this.mMIndex, 1), this.mNIndex == this.mMIndex ? this.mYinYang = 1 : this.mYinYang = 0, !0)
        }, t.prototype.pop = function() {
            if (!(this.length <= 0)) {
                this.freeFromM(1);
                var t = this.mItemList[this.mMIndex];
                return this.mItemList[this.mMIndex] = void 0, t
            }
        }, t.prototype.enqueue = function(t) {
            return this.push(t)
        }, t.prototype.dequeue = function() {
            return this.rPop()
        }, t.prototype.rEnqueue = function(t) {
            return this.rPush(t)
        }, t.prototype.rDequeue = function() {
            return this.pop()
        }, t.prototype.dequeueAt = function(t) {
            if (!(this.length <= 0 || t >= this.length)) {
                for (var e = this[t], i = t; i > 0; i--) this.set_at(i, this.get_at(i - 1));
                return this.rPop(), e
            }
        }, t.prototype.indexFromNOffset = function(t) {
            if (t >= this.length) throw "IndexOutOfRangeException";
            var e = this.mNIndex;
            return 0 == t ? e : e = (this.mNIndex + t) % this.mCapacity
        }, t.prototype.indexFromMOffset = function(t) {
            if (t >= this.length) throw "IndexOutOfRangeException";
            var e = this.mMIndex - 1 - t;
            return 0 > e && (e += this.mCapacity), e
        }, t.prototype.atOffset = function(t) {
            var e = this.indexFromNOffset(t);
            return this.mItemList[e]
        }, t.prototype.atOffsetR = function(t) {
            var e = this.indexFromMOffset(t);
            return this.mItemList[e]
        }, t.prototype.atFixOffset = function(t) {
            if (0 > t || t > this.mItemList.length) throw "IndexOutOfRangeException";
            return this.mItemList[t]
        }, t.prototype.get_at = function(t) {
            var e = this.indexFromNOffset(t);
            return this.mItemList[e]
        }, t.prototype.set_at = function(t, e) {
            var i = this.indexFromNOffset(t);
            this.mItemList[i] = e
        }, t
    }();
    t.ZmHandyArray = e, __reflect(e.prototype, "Utility.ZmHandyArray")
}(Utility || (Utility = {}));
var ZmLoading = function() {
    function t() {
        this._loadingsPrioritQueue = []
    }
    return t.prototype.buildLoading = function(t, e, i) {
        void 0 === i && (i = !0);
        var n = null,
            a = this._loadingsPrioritQueue[e + 1];
        a || (a = new Utility.ZmHandyArray(2, !0), this._loadingsPrioritQueue[e + 1] = a);
        var o = this,
            s = function() {
                n.isClosed = !0, o.refreshUI()
            };
        return n = {
            title: t,
            useMask: i,
            close: s,
            isClosed: !1
        }, a.push(n), o.refreshUI(), n
    }, t.prototype.refreshUI = function() {
        for (var t = null, e = 0, i = this._loadingsPrioritQueue.length; i > e; e++) {
            var n = this._loadingsPrioritQueue[e];
            if (n) {
                for (; n.length > 0;) {
                    var a = n.get_at(n.length - 1); {
                        if (!a.isClosed) {
                            t = a;
                            break
                        }
                        n.pop()
                    }
                }
                if (null != t) break
            }
        }
        this._theUI && (t ? this._theUI.show(t.title, t.useMask) : this._theUI.hide())
    }, t.prototype.attachUI = function(t) {
        this._theUI = t, this.refreshUI()
    }, t.prototype.showLoading = function(t, e) {
        return void 0 === e && (e = !0), this.buildLoading(t, 0, e)
    }, t.prototype.showTopMostLoading = function(t, e) {
        return void 0 === e && (e = !0), this.buildLoading(t, -1, e)
    }, t.prototype.showDispensableLoading = function(t, e) {
        return void 0 === e && (e = !0), this.buildLoading(t, 1, e)
    }, t.prototype.hideAll = function() {
        this._theUI && this._theUI.hide();
        for (var t = 0, e = this._loadingsPrioritQueue.length; e > t; t++) {
            var i = this._loadingsPrioritQueue[t];
            if (i)
                for (; i.length > 0;) {
                    i.dequeue()
                }
        }
    }, t = __decorate([singleton], t)
}();
__reflect(ZmLoading.prototype, "ZmLoading");
var Utility;
! function(t) {
    var e = function() {
        function t() {
            this.flag = -1, this.spinPeriod = 50
        }
        return t
    }();
    __reflect(e.prototype, "LockEntryImple", ["Utility.LockEntry"]);
    var i = function() {
        function i() {}
        return Object.defineProperty(i, "Instance", {
            get: function() {
                var t = this;
                return t.__instance || (t.__instance = new i), t.__instance
            },
            enumerable: !0,
            configurable: !0
        }), i.prototype.getLock = function(i) {
            this._locks || (this._locks = new t.ZmDictionary);
            var n = this._locks.get(i);
            return n || (n = new e, this._locks.add(i, n)), n
        }, i.prototype.destroyLock = function(t) {
            this._locks.contains(t) && this._locks.remove(t)
        }, i.isHaveOwner = function(t) {
            var e = t;
            if (!e) throw "Invalid param type";
            return e.flag >= 0
        }, i.tryEnterWrite = function(e, i) {
            return __awaiter(this, void 0, void 0, function() {
                var n;
                return __generator(this, function(a) {
                    switch (a.label) {
                        case 0:
                            if (n = e, !n) throw "Invalid param type";
                            if (n.flag++, 0 == n.flag) return [2, !0];
                            if (n.flag--, !i) return [2, !1];
                            a.label = 1;
                        case 1:
                            return n.flag >= 0 ? [4, t.ZmAsync.Defer(50)] : [3, 3];
                        case 2:
                            return a.sent(), [3, 1];
                        case 3:
                            return [2, !1]
                    }
                })
            })
        }, i.leaveWrite = function(t) {
            var e = t;
            if (!e) throw "Invalid param type";
            e.flag--
        }, i
    }();
    t.STLock = i, __reflect(i.prototype, "Utility.STLock")
}(Utility || (Utility = {}));
var Utility;
! function(t) {
    var e = function() {
        function t() {}
        return Object.defineProperty(t, "Now", {
            get: function() {
                return new Date
            },
            enumerable: !0,
            configurable: !0
        }), Object.defineProperty(t, "Ticks", {
            get: function() {
                return Date.now()
            },
            enumerable: !0,
            configurable: !0
        }), t
    }();
    t.ZmTime = e, __reflect(e.prototype, "Utility.ZmTime")
}(Utility || (Utility = {}));