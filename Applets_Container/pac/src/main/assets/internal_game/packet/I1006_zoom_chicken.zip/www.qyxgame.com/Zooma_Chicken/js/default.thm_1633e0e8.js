window.skins = {};

function __extends(d, b) {
    for (var p in b)
        if (b.hasOwnProperty(p)) d[p] = b[p];

    function __() {
        this.constructor = d;
    }
    __.prototype = b.prototype;
    d.prototype = new __();
};
window.generateEUI = {};
generateEUI.paths = {};
generateEUI.styles = undefined;
generateEUI.skins = {
    "eui.Button": "resource/eui_skins/ButtonSkin.exml",
    "eui.CheckBox": "resource/eui_skins/CheckBoxSkin.exml",
    "eui.HScrollBar": "resource/eui_skins/HScrollBarSkin.exml",
    "eui.HSlider": "resource/eui_skins/HSliderSkin.exml",
    "eui.Panel": "resource/eui_skins/PanelSkin.exml",
    "eui.TextInput": "resource/eui_skins/TextInputSkin.exml",
    "eui.ProgressBar": "resource/eui_skins/ProgressBarSkin.exml",
    "eui.RadioButton": "resource/eui_skins/RadioButtonSkin.exml",
    "eui.Scroller": "resource/eui_skins/ScrollerSkin.exml",
    "eui.ToggleSwitch": "resource/eui_skins/ToggleSwitchSkin.exml",
    "eui.VScrollBar": "resource/eui_skins/VScrollBarSkin.exml",
    "eui.VSlider": "resource/eui_skins/VSliderSkin.exml",
    "eui.ItemRenderer": "resource/eui_skins/ItemRendererSkin.exml"
};
generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function(_super) {
    __extends(CheckBoxSkin, _super);

    function CheckBoxSkin() {
        _super.call(this);
        this.skinParts = ["labelDisplay"];

        this.elementsContent = [this._Group1_i()];
        this.states = [
            new eui.State("up", []),
            new eui.State("down", [
                new eui.SetProperty("_Image1", "alpha", 0.7)
            ]),
            new eui.State("disabled", [
                new eui.SetProperty("_Image1", "alpha", 0.5)
            ]),
            new eui.State("upAndSelected", [
                new eui.SetProperty("_Image1", "source", "checkbox_select_up_png")
            ]),
            new eui.State("downAndSelected", [
                new eui.SetProperty("_Image1", "source", "checkbox_select_down_png")
            ]),
            new eui.State("disabledAndSelected", [
                new eui.SetProperty("_Image1", "source", "checkbox_select_disabled_png")
            ])
        ];
    }
    var _proto = CheckBoxSkin.prototype;

    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.percentHeight = 100;
        t.percentWidth = 100;
        t.layout = this._HorizontalLayout1_i();
        t.elementsContent = [this._Image1_i(), this.labelDisplay_i()];
        return t;
    };
    _proto._HorizontalLayout1_i = function() {
        var t = new eui.HorizontalLayout();
        t.verticalAlign = "middle";
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        this._Image1 = t;
        t.alpha = 1;
        t.fillMode = "scale";
        t.source = "play_json.zmj_icon_88";
        return t;
    };
    _proto.labelDisplay_i = function() {
        var t = new eui.Label();
        this.labelDisplay = t;
        t.fontFamily = "Tahoma";
        t.size = 20;
        t.textAlign = "center";
        t.textColor = 0x707070;
        t.verticalAlign = "middle";
        return t;
    };
    return CheckBoxSkin;
})(eui.Skin);
generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function(_super) {
    __extends(HScrollBarSkin, _super);

    function HScrollBarSkin() {
        _super.call(this);
        this.skinParts = ["thumb"];

        this.minHeight = 8;
        this.minWidth = 20;
        this.elementsContent = [this.thumb_i()];
    }
    var _proto = HScrollBarSkin.prototype;

    _proto.thumb_i = function() {
        var t = new eui.Image();
        this.thumb = t;
        t.height = 8;
        t.scale9Grid = new egret.Rectangle(3, 3, 2, 2);
        t.source = "roundthumb_png";
        t.verticalCenter = 0;
        t.width = 30;
        return t;
    };
    return HScrollBarSkin;
})(eui.Skin);
generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function(_super) {
    __extends(RadioButtonSkin, _super);

    function RadioButtonSkin() {
        _super.call(this);
        this.skinParts = ["labelDisplay"];

        this.elementsContent = [this._Group1_i()];
        this.states = [
            new eui.State("up", []),
            new eui.State("down", [
                new eui.SetProperty("_Image1", "alpha", 0.7)
            ]),
            new eui.State("disabled", [
                new eui.SetProperty("_Image1", "alpha", 0.5)
            ]),
            new eui.State("upAndSelected", [
                new eui.SetProperty("_Image1", "source", "radiobutton_select_up_png")
            ]),
            new eui.State("downAndSelected", [
                new eui.SetProperty("_Image1", "source", "radiobutton_select_down_png")
            ]),
            new eui.State("disabledAndSelected", [
                new eui.SetProperty("_Image1", "source", "radiobutton_select_disabled_png")
            ])
        ];
    }
    var _proto = RadioButtonSkin.prototype;

    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.percentHeight = 100;
        t.percentWidth = 100;
        t.layout = this._HorizontalLayout1_i();
        t.elementsContent = [this._Image1_i(), this.labelDisplay_i()];
        return t;
    };
    _proto._HorizontalLayout1_i = function() {
        var t = new eui.HorizontalLayout();
        t.verticalAlign = "middle";
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        this._Image1 = t;
        t.alpha = 1;
        t.fillMode = "scale";
        t.source = "play_json.zmj_icon_88";
        return t;
    };
    _proto.labelDisplay_i = function() {
        var t = new eui.Label();
        this.labelDisplay = t;
        t.fontFamily = "Tahoma";
        t.size = 20;
        t.textAlign = "center";
        t.textColor = 0x707070;
        t.verticalAlign = "middle";
        return t;
    };
    return RadioButtonSkin;
})(eui.Skin);
generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function(_super) {
    __extends(ScrollerSkin, _super);

    function ScrollerSkin() {
        _super.call(this);
        this.skinParts = ["horizontalScrollBar", "verticalScrollBar"];

        this.minHeight = 20;
        this.minWidth = 20;
        this.elementsContent = [this.horizontalScrollBar_i(), this.verticalScrollBar_i()];
    }
    var _proto = ScrollerSkin.prototype;

    _proto.horizontalScrollBar_i = function() {
        var t = new eui.HScrollBar();
        this.horizontalScrollBar = t;
        t.bottom = 0;
        t.percentWidth = 100;
        return t;
    };
    _proto.verticalScrollBar_i = function() {
        var t = new eui.VScrollBar();
        this.verticalScrollBar = t;
        t.percentHeight = 100;
        t.right = 0;
        return t;
    };
    return ScrollerSkin;
})(eui.Skin);
generateEUI.paths['resource/eui_skins/VScrollBarSkin.exml'] = window.skins.VScrollBarSkin = (function(_super) {
    __extends(VScrollBarSkin, _super);

    function VScrollBarSkin() {
        _super.call(this);
        this.skinParts = ["thumb"];

        this.minHeight = 20;
        this.minWidth = 8;
        this.elementsContent = [this.thumb_i()];
    }
    var _proto = VScrollBarSkin.prototype;

    _proto.thumb_i = function() {
        var t = new eui.Image();
        this.thumb = t;
        t.height = 30;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(3, 3, 2, 2);
        t.source = "roundthumb_png";
        t.width = 8;
        return t;
    };
    return VScrollBarSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/ChaoyueSkin.exml'] = window.ChaoyueSkin = (function(_super) {
    __extends(ChaoyueSkin, _super);

    function ChaoyueSkin() {
        _super.call(this);
        this.skinParts = ["txtTotalScore", "txtLishi", "txtChaoyue", "btnZailaiyiju", "btnXuanyao", "btnCancel", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnCancel_i(), this.btnGuanbi_i()];
    }
    var _proto = ChaoyueSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -1;
        t.verticalCenter = 3;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this.txtTotalScore_i(), this.txtLishi_i(), this.txtChaoyue_i(), this.btnZailaiyiju_i(), this.btnXuanyao_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 527;
        t.scale9Grid = new egret.Rectangle(71, 65, 0, 397);
        t.source = "play_json.zmj_frame_26";
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.height = 187;
        t.scale9Grid = new egret.Rectangle(95, 40, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 46.5;
        t.y = 184.5;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_58";
        t.x = 88;
        t.y = 62;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_46";
        t.x = 168.5;
        t.y = 244;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_59";
        t.x = 89.5;
        t.y = 289.26;
        return t;
    };
    _proto.txtTotalScore_i = function() {
        var t = new eui.Label();
        this.txtTotalScore = t;
        t.fontFamily = "Microsoft YaHei";
        t.text = "9999999";
        t.textAlign = "left";
        t.x = 251.44;
        t.y = 244;
        return t;
    };
    _proto.txtLishi_i = function() {
        var t = new eui.Label();
        this.txtLishi = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "999999";
        t.x = 256.3;
        t.y = 289.26;
        return t;
    };
    _proto.txtChaoyue_i = function() {
        var t = new eui.Label();
        this.txtChaoyue = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "99%";
        t.textColor = 0x00ffc7;
        t.x = 313.44;
        t.y = 116;
        return t;
    };
    _proto.btnZailaiyiju_i = function() {
        var t = new eui.Group();
        this.btnZailaiyiju = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 295;
        t.y = 399;
        t.elementsContent = [this._Image7_i(), this._Image8_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_57";
        t.x = 28.5;
        t.y = 20.41;
        return t;
    };
    _proto.btnXuanyao_i = function() {
        var t = new eui.Group();
        this.btnXuanyao = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 75.44;
        t.y = 399.5;
        t.elementsContent = [this._Image9_i(), this._Image10_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_56";
        t.x = 30.06;
        t.y = 20.5;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -3.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 309.5;
        t.elementsContent = [this._Image11_i()];
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_53";
        t.x = -7.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 239.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -235;
        t.elementsContent = [this._Image12_i()];
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    return ChaoyueSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/FenxiangErrTipSkin.exml'] = window.FenxiangErrTipSkin = (function(_super) {
    __extends(FenxiangErrTipSkin, _super);

    function FenxiangErrTipSkin() {
        _super.call(this);
        this.skinParts = ["txtTip", "btnFenxiang", "btnSure", "btnCancel", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnCancel_i(), this.btnGuanbi_i()];
    }
    var _proto = FenxiangErrTipSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -1;
        t.verticalCenter = 3;
        t.elementsContent = [this._Image2_i(), this.txtTip_i(), this.btnFenxiang_i(), this.btnSure_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 300;
        t.scale9Grid = new egret.Rectangle(71, 65, 0, 397);
        t.source = "play_json.zmj_frame_26";
        t.width = 553;
        return t;
    };
    _proto.txtTip_i = function() {
        var t = new eui.Label();
        this.txtTip = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.fontFamily = "Microsoft YaHei";
        t.height = 83;
        t.lineSpacing = 18;
        t.size = 30;
        t.text = "短时间内，不能点击相同群的\n分享链接！请分享到其他群吧！";
        t.textAlign = "center";
        t.textColor = 0xffffff;
        t.width = 432;
        t.x = 55.5;
        t.y = 70;
        return t;
    };
    _proto.btnFenxiang_i = function() {
        var t = new eui.Group();
        this.btnFenxiang = t;
        t.anchorOffsetX = 91;
        t.anchorOffsetY = 35;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 385;
        t.y = 230.5;
        t.elementsContent = [this._Image3_i(), this._Label1_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        t.y = -6;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 30;
        t.stroke = 2;
        t.strokeColor = 0x383838;
        t.text = "分享到群";
        t.textColor = 0xFFFFFF;
        t.x = 31;
        t.y = 18.5;
        return t;
    };
    _proto.btnSure_i = function() {
        var t = new eui.Group();
        this.btnSure = t;
        t.anchorOffsetX = 89;
        t.anchorOffsetY = 40;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 144.5;
        t.y = 229.91;
        t.elementsContent = [this._Image4_i(), this._Label2_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 30;
        t.stroke = 2;
        t.strokeColor = 0x383838;
        t.text = "我知道了";
        t.textColor = 0xFFFFFF;
        t.x = 32;
        t.y = 24.090000000000032;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -3.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 220.5;
        t.visible = false;
        t.elementsContent = [this._Image5_i()];
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_53";
        t.x = -7.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 40;
        t.anchorOffsetY = 35;
        t.horizontalCenter = 239.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -128;
        t.visible = false;
        t.elementsContent = [this._Image6_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    return FenxiangErrTipSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/FenxiangTipSkin.exml'] = window.FenxiangTipSkin = (function(_super) {
    __extends(FenxiangTipSkin, _super);

    function FenxiangTipSkin() {
        _super.call(this);
        this.skinParts = ["btnSure", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnGuanbi_i()];
    }
    var _proto = FenxiangTipSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -1;
        t.verticalCenter = -51;
        t.elementsContent = [this._Image2_i(), this._Label1_i(), this._Label2_i(), this.btnSure_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 300;
        t.scale9Grid = new egret.Rectangle(71, 65, 0, 397);
        t.source = "play_json.zmj_frame_26";
        t.width = 553;
        t.x = -1.33;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "在群聊天里点击自己的分享链接";
        t.textColor = 0xffffff;
        t.x = 60.35;
        t.y = 75.67;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "再次进入游戏，即可获得奖励";
        t.textColor = 0xFFFFFF;
        t.x = 74.98;
        t.y = 125.35;
        return t;
    };
    _proto.btnSure_i = function() {
        var t = new eui.Group();
        this.btnSure = t;
        t.anchorOffsetX = 91;
        t.anchorOffsetY = 35;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 269.84;
        t.y = 233.61;
        t.elementsContent = [this._Image3_i(), this._Label3_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        t.y = -6;
        return t;
    };
    _proto._Label3_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 30;
        t.stroke = 2;
        t.strokeColor = 0x383838;
        t.text = "我知道了";
        t.textColor = 0xFFFFFF;
        t.x = 36.33;
        t.y = 20.02;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 40;
        t.anchorOffsetY = 35;
        t.horizontalCenter = 239.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -182;
        t.visible = false;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    return FenxiangTipSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/FudaiCellSkin.exml'] = window.FudaiCellSkin = (function(_super) {
    __extends(FudaiCellSkin, _super);

    function FudaiCellSkin() {
        _super.call(this);
        this.skinParts = ["txtName", "imgIcon", "txtNum", "txtItemNum", "btnDuihuan"];

        this.height = 300;
        this.width = 240;
        this.elementsContent = [this._Group1_i()];
    }
    var _proto = FudaiCellSkin.prototype;

    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.elementsContent = [this._Image1_i(), this.txtName_i(), this.imgIcon_i(), this._Image2_i(), this._Image3_i(), this.txtNum_i(), this.txtItemNum_i(), this.btnDuihuan_i()];
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.anchorOffsetY = 0;
        t.height = 300;
        t.scale9Grid = new egret.Rectangle(68, 41, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_backg3";
        t.width = 240;
        t.y = 3;
        return t;
    };
    _proto.txtName_i = function() {
        var t = new eui.Label();
        this.txtName = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.text = "20元话费充值卡";
        t.textAlign = "center";
        t.textColor = 0x65443a;
        t.x = 12;
        t.y = 17;
        return t;
    };
    _proto.imgIcon_i = function() {
        var t = new eui.Image();
        this.imgIcon = t;
        t.source = "play_json.fud_jp1";
        t.x = 65;
        t.y = 70.6;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(23, 40, 0, 0);
        t.source = "play_json.fud_backg4";
        t.width = 180;
        t.x = 30;
        t.y = 153;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.3;
        t.scaleY = 0.3;
        t.source = "play_json.fud_fuq1";
        t.x = 52.2;
        t.y = 154.85;
        return t;
    };
    _proto.txtNum_i = function() {
        var t = new eui.Label();
        this.txtNum = t;
        t.size = 24;
        t.text = "x2000";
        t.textColor = 0xdb2400;
        t.x = 97;
        t.y = 161.8;
        return t;
    };
    _proto.txtItemNum_i = function() {
        var t = new eui.Label();
        this.txtItemNum = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 26;
        t.stroke = 2;
        t.strokeColor = 0xf9f7f7;
        t.text = "x1000";
        t.textAlign = "center";
        t.textColor = 0xdb2400;
        t.width = 150;
        t.x = 44;
        t.y = 109.6;
        return t;
    };
    _proto.btnDuihuan_i = function() {
        var t = new eui.Group();
        this.btnDuihuan = t;
        t.anchorOffsetX = 79;
        t.anchorOffsetY = 34;
        t.x = 120;
        t.y = 240;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.fud_anniu3";
        t.x = 2;
        t.y = 1;
        return t;
    };
    return FudaiCellSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/FudaiHuodeSkin.exml'] = window.FudaiHuodeSkin = (function(_super) {
    __extends(FudaiHuodeSkin, _super);

    function FudaiHuodeSkin() {
        _super.call(this);
        this.skinParts = ["btnGuanbi", "txtHuode", "btnQueding", "txtDuihuan", "btnDuihuan"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = FudaiHuodeSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 594;
        t.horizontalCenter = 2;
        t.verticalCenter = -43;
        t.width = 635.54;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this.btnGuanbi_i(), this._Image6_i(), this.txtHuode_i(), this._Label1_i(), this.btnQueding_i(), this.btnDuihuan_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.fillMode = "scale";
        t.height = 500;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(35, 43, 0, 0);
        t.source = "play_json.fud_backg1";
        t.width = 480;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0.2300000000000182;
        t.source = "play_json.fud_bt1";
        t.y = -60.88;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.height = 202;
        t.horizontalCenter = -1.7699999999999818;
        t.scale9Grid = new egret.Rectangle(54, 53, 0, 0);
        t.source = "play_json.fud_backg2";
        t.width = 400;
        t.y = 77.6;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 236.23000000000002;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -292.5;
        t.elementsContent = [this._Image5_i()];
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_close1";
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0.2300000000000182;
        t.source = "play_json.fud_fuq1";
        t.y = 97.54;
        return t;
    };
    _proto.txtHuode_i = function() {
        var t = new eui.Label();
        this.txtHuode = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = -0.2699999999999818;
        t.size = 28;
        t.text = "福券 x120";
        t.textAlign = "center";
        t.textColor = 0xdb3400;
        t.y = 233.84;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 0.2300000000000182;
        t.text = "游戏中连消有机会获得福袋";
        t.y = 338.46;
        return t;
    };
    _proto.btnQueding_i = function() {
        var t = new eui.Group();
        this.btnQueding = t;
        t.anchorOffsetX = 204;
        t.anchorOffsetY = 46;
        t.height = 89.39;
        t.width = 403.03;
        t.x = 321.04;
        t.y = 434.61;
        t.elementsContent = [this._Image7_i(), this._Label2_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.height = 88;
        t.scale9Grid = new egret.Rectangle(30, 27, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_anniu2";
        t.width = 400;
        t.x = 2;
        t.y = 3.0000000000001137;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 0.48500000000001364;
        t.size = 38;
        t.text = "确定";
        t.textColor = 0xbc131c;
        t.y = 22.96;
        return t;
    };
    _proto.btnDuihuan_i = function() {
        var t = new eui.Group();
        this.btnDuihuan = t;
        t.x = 262;
        t.y = 292;
        t.elementsContent = [this.txtDuihuan_i()];
        return t;
    };
    _proto.txtDuihuan_i = function() {
        var t = new eui.Label();
        this.txtDuihuan = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.text = "兑换>>";
        t.textColor = 0xfefd41;
        t.x = 3.5600000000000023;
        t.y = -0.11000000000001364;
        return t;
    };
    return FudaiHuodeSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/FudaiOpenSkin.exml'] = window.FudaiOpenSkin = (function(_super) {
    __extends(FudaiOpenSkin, _super);

    function FudaiOpenSkin() {
        _super.call(this);
        this.skinParts = ["hongbao", "image", "btnOpen", "btnGuanbi", "group_ad"];

        this.height = 1136;
        this.width = 640;
        this.hongbao_i();
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.group_ad_i()];

        eui.Binding.$bindProperties(this, ["image"], [0], this._TweenItem1, "target");
        eui.Binding.$bindProperties(this, [1.1], [], this._Object1, "scaleX");
        eui.Binding.$bindProperties(this, [1.1], [], this._Object1, "scaleY");
        eui.Binding.$bindProperties(this, [1], [], this._Object2, "scaleX");
        eui.Binding.$bindProperties(this, [1], [], this._Object2, "scaleY");
        eui.Binding.$bindProperties(this, [1.1], [], this._Object3, "scaleX");
        eui.Binding.$bindProperties(this, [1.1], [], this._Object3, "scaleY");
        eui.Binding.$bindProperties(this, [1], [], this._Object4, "scaleX");
        eui.Binding.$bindProperties(this, [1], [], this._Object4, "scaleY");
    }
    var _proto = FudaiOpenSkin.prototype;

    _proto.hongbao_i = function() {
        var t = new egret.tween.TweenGroup();
        this.hongbao = t;
        t.items = [this._TweenItem1_i()];
        return t;
    };
    _proto._TweenItem1_i = function() {
        var t = new egret.tween.TweenItem();
        this._TweenItem1 = t;
        t.paths = [this._Set1_i(), this._To1_i(), this._To2_i(), this._To3_i(), this._To4_i(), this._To5_i()];
        return t;
    };
    _proto._Set1_i = function() {
        var t = new egret.tween.Set();
        return t;
    };
    _proto._To1_i = function() {
        var t = new egret.tween.To();
        t.duration = 350;
        t.props = this._Object1_i();
        return t;
    };
    _proto._Object1_i = function() {
        var t = {};
        this._Object1 = t;
        return t;
    };
    _proto._To2_i = function() {
        var t = new egret.tween.To();
        t.duration = 350;
        t.props = this._Object2_i();
        return t;
    };
    _proto._Object2_i = function() {
        var t = {};
        this._Object2 = t;
        return t;
    };
    _proto._To3_i = function() {
        var t = new egret.tween.To();
        t.duration = 350;
        t.props = this._Object3_i();
        return t;
    };
    _proto._Object3_i = function() {
        var t = {};
        this._Object3 = t;
        return t;
    };
    _proto._To4_i = function() {
        var t = new egret.tween.To();
        t.duration = 350;
        t.props = this._Object4_i();
        return t;
    };
    _proto._Object4_i = function() {
        var t = {};
        this._Object4 = t;
        return t;
    };
    _proto._To5_i = function() {
        var t = new egret.tween.To();
        t.duration = 850;
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 594;
        t.horizontalCenter = 1;
        t.verticalCenter = -43;
        t.width = 635.54;
        t.elementsContent = [this._Label1_i(), this._Label2_i(), this._Label3_i(), this._Image2_i(), this.btnOpen_i(), this.btnGuanbi_i()];
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 4.230000000000018;
        t.size = 30;
        t.text = "福袋可以兑换丰富实物奖励";
        t.textColor = 0xffd133;
        t.y = 440.08;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 64.23000000000002;
        t.size = 30;
        t.text = "丰富实物";
        t.textColor = 0x26de18;
        t.y = 440.08;
        return t;
    };
    _proto._Label3_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.text = "红包余额已转成福卡";
        t.textColor = 0xffd133;
        t.x = 187;
        t.y = 484.08;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0.2300000000000182;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_fud1";
        t.y = 38.03;
        return t;
    };
    _proto.btnOpen_i = function() {
        var t = new eui.Group();
        this.btnOpen = t;
        t.anchorOffsetX = 141.02;
        t.anchorOffsetY = 47.65;
        t.height = 94.33;
        t.width = 261.67;
        t.x = 326.12;
        t.y = 586.4;
        t.elementsContent = [this.image_i(), this._Image3_i()];
        return t;
    };
    _proto.image_i = function() {
        var t = new eui.Image();
        this.image = t;
        t.anchorOffsetX = 124.09;
        t.anchorOffsetY = 56;
        t.source = "play_json.fud_anniu1";
        t.width = 266.67;
        t.x = 124.09;
        t.y = 60.33;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = -61.33500000000001;
        t.scaleX = 0.8;
        t.scaleY = 0.8;
        t.source = "video_png";
        t.verticalCenter = 3.835000000000001;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 253.73000000000002;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -293;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_close1";
        return t;
    };
    _proto.group_ad_i = function() {
        var t = new eui.Group();
        this.group_ad = t;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.touchThrough = true;
        t.verticalCenter = 0;
        t.width = 640;
        return t;
    };
    return FudaiOpenSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/FudaiSkin.exml'] = window.FudaiSkin = (function(_super) {
    __extends(FudaiSkin, _super);

    function FudaiSkin() {
        _super.call(this);
        this.skinParts = ["txtYue", "btnGuanbi", "grpItems", "group_ad"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = FudaiSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.8;
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 1129.85;
        t.horizontalCenter = 0;
        t.verticalCenter = -1;
        t.width = 638;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this.txtYue_i(), this._Label1_i(), this.btnGuanbi_i(), this._Scroller1_i(), this._Image5_i(), this.group_ad_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(23, 40, 0, 0);
        t.source = "play_json.fud_backg4";
        t.width = 180;
        t.x = 228;
        t.y = 125;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.3;
        t.scaleY = 0.3;
        t.source = "play_json.fud_fuq1";
        t.x = 241.2;
        t.y = 126.85;
        return t;
    };
    _proto.txtYue_i = function() {
        var t = new eui.Label();
        this.txtYue = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "2000";
        t.textAlign = "left";
        t.textColor = 0xDB2400;
        t.x = 335;
        t.y = 134.8;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "福券:";
        t.textColor = 0xDB2400;
        t.x = 274;
        t.y = 133.8;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = -65.67;
        t.horizontalCenter = -220;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -497.92499999999995;
        t.width = 74;
        t.x = 527;
        t.y = -58;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_close2";
        t.x = 9;
        t.y = 0;
        return t;
    };
    _proto._Scroller1_i = function() {
        var t = new eui.Scroller();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 732;
        t.scrollPolicyH = "off";
        t.width = 548;
        t.x = 48;
        t.y = 176;
        t.viewport = this.grpItems_i();
        return t;
    };
    _proto.grpItems_i = function() {
        var t = new eui.Group();
        this.grpItems = t;
        t.anchorOffsetY = 0;
        t.height = 990;
        t.x = 2;
        t.layout = this._TileLayout1_i();
        return t;
    };
    _proto._TileLayout1_i = function() {
        var t = new eui.TileLayout();
        t.horizontalGap = 40;
        t.orientation = "rows";
        t.paddingLeft = 10;
        t.paddingTop = 10;
        t.requestedColumnCount = 2;
        t.verticalGap = 30;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 4;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_bt2";
        t.x = 145;
        t.y = 30.03;
        return t;
    };
    _proto.group_ad_i = function() {
        var t = new eui.Group();
        this.group_ad = t;
        t.height = 200;
        t.horizontalCenter = 0;
        t.verticalCenter = 35.075000000000045;
        t.width = 640;
        return t;
    };
    return FudaiSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameBoxFlash.exml'] = window.GameBoxFlash = (function(_super) {
    __extends(GameBoxFlash, _super);

    function GameBoxFlash() {
        _super.call(this);
        this.skinParts = [];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Image2_i()];
    }
    var _proto = GameBoxFlash.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.source = "gameBox_jpg";
        t.top = 0;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.source = "4399_png";
        t.x = 458;
        t.y = 1050;
        return t;
    };
    return GameBoxFlash;
})(eui.Skin);
generateEUI.paths['resource/skins/GameChestKeySkin.exml'] = window.GameChestKeySkin = (function(_super) {
    __extends(GameChestKeySkin, _super);

    function GameChestKeySkin() {
        _super.call(this);
        this.skinParts = ["btnSuoyaoyaoshi", "txtYaoshishuliang", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = GameChestKeySkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = -4;
        t.height = 1136;
        t.left = 0;
        t.right = 2;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        t.width = 640;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 604;
        t.horizontalCenter = 1;
        t.verticalCenter = -50;
        t.width = 634;
        t.elementsContent = [this._Image2_i(), this.btnSuoyaoyaoshi_i(), this._Image5_i(), this._Image6_i(), this.txtYaoshishuliang_i(), this._Image7_i(), this._Image8_i(), this.btnGuanbi_i(), this._Label1_i(), this._Label2_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 327;
        t.scale9Grid = new egret.Rectangle(85, 327, 1, 0);
        t.source = "play_json.zmj_frame_22";
        t.width = 553;
        t.x = 40.5;
        t.y = 138.5;
        return t;
    };
    _proto.btnSuoyaoyaoshi_i = function() {
        var t = new eui.Group();
        this.btnSuoyaoyaoshi = t;
        t.anchorOffsetX = 90;
        t.anchorOffsetY = 45;
        t.height = 90;
        t.width = 179;
        t.x = 317.5;
        t.y = 393;
        t.elementsContent = [this._Image3_i(), this._Image4_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        t.x = -4;
        t.y = 8;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_32";
        t.x = 25;
        t.y = 28.5;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(30, 44, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_24";
        t.width = 144;
        t.x = 242.54;
        t.y = 297.5;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_20";
        t.x = 250.83;
        t.y = 296;
        return t;
    };
    _proto.txtYaoshishuliang_i = function() {
        var t = new eui.Label();
        this.txtYaoshishuliang = t;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 22;
        t.stroke = 2;
        t.strokeColor = 0x0F1C3F;
        t.text = "x 10";
        t.x = 314.5;
        t.y = 308;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 156.5;
        t.y = 94;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_33";
        t.x = 235.5;
        t.y = 113;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 44;
        t.anchorOffsetY = 42;
        t.horizontalCenter = 239;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -146;
        t.width = 88;
        t.x = 515;
        t.y = 113;
        t.elementsContent = [this._Image9_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 5.5;
        t.y = 6;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "分享到群";
        t.x = 268;
        t.y = 216;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "点击链接可获得大量钥匙奖励";
        t.x = 161;
        t.y = 259;
        return t;
    };
    return GameChestKeySkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameChestSkin.exml'] = window.GameChestSkin = (function(_super) {
    __extends(GameChestSkin, _super);

    function GameChestSkin() {
        _super.call(this);
        this.skinParts = ["txtChestCnt", "txtYaoshishuliang", "btnKaiqibaoxiang", "btnGuanbi", "btnFenxiang", "txtCancel", "btnCancel", "group_like"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnCancel_i(), this.group_like_i()];
    }
    var _proto = GameChestSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 594;
        t.horizontalCenter = 1;
        t.verticalCenter = -43;
        t.width = 547.66;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this.txtChestCnt_i(), this.txtYaoshishuliang_i(), this._Image6_i(), this.btnKaiqibaoxiang_i(), this.btnGuanbi_i(), this.btnFenxiang_i(), this._Label1_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.fillMode = "scale";
        t.scale9Grid = new egret.Rectangle(67, 580, 2, 0);
        t.source = "play_json.zmj_frame_25";
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 116;
        t.y = -26;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_31";
        t.x = 188.5;
        t.y = -7.99;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_18";
        t.x = 188.5;
        t.y = 152.59;
        return t;
    };
    _proto.txtChestCnt_i = function() {
        var t = new eui.Label();
        this.txtChestCnt = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.stroke = 2;
        t.strokeColor = 0x0f1c3f;
        t.text = "x 0";
        t.visible = false;
        t.x = 387.5;
        t.y = 236.59;
        return t;
    };
    _proto.txtYaoshishuliang_i = function() {
        var t = new eui.Label();
        this.txtYaoshishuliang = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.stroke = 2;
        t.strokeColor = 0x0f1c3f;
        t.text = "x 10";
        t.visible = false;
        t.x = 281.67;
        t.y = 232.39;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.height = 80;
        t.scale9Grid = new egret.Rectangle(85, 41, 1, 0);
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 56.16;
        t.y = 614.5;
        return t;
    };
    _proto.btnKaiqibaoxiang_i = function() {
        var t = new eui.Group();
        this.btnKaiqibaoxiang = t;
        t.anchorOffsetX = 91;
        t.anchorOffsetY = 37;
        t.height = 78.67;
        t.width = 182.66;
        t.x = 277;
        t.y = 465;
        t.elementsContent = [this._Image7_i(), this._Image8_i(), this._Image9_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        t.x = 0.66;
        t.y = -2.27;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_30";
        t.x = 45.33;
        t.y = 18.65;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 12.66;
        t.y = 24.33;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 246.67000000000002;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -280;
        t.x = 538;
        t.y = 105;
        t.elementsContent = [this._Image10_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    _proto.btnFenxiang_i = function() {
        var t = new eui.Group();
        this.btnFenxiang = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 313.57;
        t.y = 258.39;
        t.elementsContent = [this._Image11_i()];
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_19";
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.lineSpacing = 5;
        t.size = 24;
        t.text = "Get diamonds and skin fragments~";
        t.textAlign = "center";
        t.verticalAlign = "middle";
        t.x = 75.32;
        t.y = 641.32;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.anchorOffsetX = 0;
        t.bottom = 208;
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 214;
        t.elementsContent = [this.txtCancel_i()];
        return t;
    };
    _proto.txtCancel_i = function() {
        var t = new eui.Label();
        this.txtCancel = t;
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 28;
        t.strokeColor = 0xff921c;
        t.text = "狠心放弃";
        t.textColor = 0xe8e8e8;
        t.x = 0;
        return t;
    };
    _proto.group_like_i = function() {
        var t = new eui.Group();
        this.group_like = t;
        t.anchorOffsetY = 0;
        t.height = 132;
        t.horizontalCenter = 0;
        t.verticalCenter = 0;
        t.visible = false;
        t.width = 640;
        return t;
    };
    return GameChestSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameDaojuHeidongSkin.exml'] = window.GameDaojuHeidongSkin = (function(_super) {
    __extends(GameDaojuHeidongSkin, _super);

    function GameDaojuHeidongSkin() {
        _super.call(this);
        this.skinParts = ["btnGoumai", "btnMianfei", "btnMianfei1", "btnGuanbi", "group_like", "group_ad1", "group_ad2", "txtCancel", "btnGuanbi2"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.group_like_i(), this.group_ad1_i(), this.group_ad2_i(), this.btnGuanbi2_i()];
    }
    var _proto = GameDaojuHeidongSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 554;
        t.horizontalCenter = 5;
        t.verticalCenter = -141;
        t.width = 562;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this._Image7_i(), this.btnGoumai_i(), this._Image11_i(), this._Label2_i(), this.btnMianfei_i(), this.btnMianfei1_i(), this.btnGuanbi_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0.5;
        t.scale9Grid = new egret.Rectangle(89, 327, 1, 0);
        t.source = "play_json.zmj_frame_26";
        t.verticalCenter = 0.5;
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 112;
        t.y = -22.5;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_38";
        t.x = 234.85;
        t.y = -6.01;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_40";
        t.x = 243.99;
        t.y = 228.98;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_25";
        t.x = 191.5;
        t.y = 70.63;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.height = 127;
        t.scale9Grid = new egret.Rectangle(79, 36, 0, 0);
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 60;
        t.y = 277.5;
        return t;
    };
    _proto.btnGoumai_i = function() {
        var t = new eui.Group();
        this.btnGoumai = t;
        t.anchorOffsetY = 0;
        t.height = 65.33;
        t.visible = false;
        t.width = 200;
        t.x = 284.76;
        t.y = 433.93;
        t.elementsContent = [this._Image8_i(), this._Image9_i(), this._Image10_i(), this._Label1_i()];
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = 11.35;
        t.y = -6.84;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_42";
        t.x = 116.85;
        t.y = 17.61;
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.zmj_icon_01";
        t.x = 33.59;
        t.y = 20.06;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.stroke = 2;
        t.strokeColor = 0x9a3c1a;
        t.text = "200";
        t.x = 72.65;
        t.y = 21.78;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_77";
        t.visible = false;
        t.x = 96.5;
        t.y = 324.5;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.lineSpacing = 10;
        t.text = "鸡蛋都要被抢走啦！\n 快使用黑洞道拯救一下！";
        t.textAlign = "center";
        t.verticalAlign = "middle";
        t.x = 108.85;
        t.y = 311;
        return t;
    };
    _proto.btnMianfei_i = function() {
        var t = new eui.Group();
        this.btnMianfei = t;
        t.anchorOffsetX = 92;
        t.anchorOffsetY = 40;
        t.x = 282.76;
        t.y = 471.93;
        t.elementsContent = [this._Image12_i(), this._Image13_i(), this._Image14_i()];
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_19";
        t.x = 48.5;
        t.y = 20.41;
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 15.27;
        t.y = 23.75;
        return t;
    };
    _proto.btnMianfei1_i = function() {
        var t = new eui.Group();
        this.btnMianfei1 = t;
        t.anchorOffsetY = 0;
        t.height = 65.33;
        t.visible = false;
        t.width = 200;
        t.x = 62.88;
        t.y = 432.56;
        t.elementsContent = [this._Image15_i(), this._Image16_i()];
        return t;
    };
    _proto._Image15_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = 11.35;
        t.y = -6.84;
        return t;
    };
    _proto._Image16_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_76";
        t.x = 24;
        t.y = 15.779999999999973;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 35.58;
        t.anchorOffsetY = 36.67;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 515.49;
        t.y = 16.8;
        t.elementsContent = [this._Image17_i()];
        return t;
    };
    _proto._Image17_i = function() {
        var t = new eui.Image();
        t.alpha = 1;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 0;
        return t;
    };
    _proto.group_like_i = function() {
        var t = new eui.Group();
        this.group_like = t;
        t.height = 200;
        t.horizontalCenter = 0;
        t.touchThrough = true;
        t.verticalCenter = 229;
        t.width = 640;
        return t;
    };
    _proto.group_ad1_i = function() {
        var t = new eui.Group();
        this.group_ad1 = t;
        t.height = 144;
        t.left = 65;
        t.touchThrough = true;
        t.verticalCenter = -249;
        t.width = 144;
        return t;
    };
    _proto.group_ad2_i = function() {
        var t = new eui.Group();
        this.group_ad2 = t;
        t.height = 144;
        t.right = 65;
        t.touchThrough = true;
        t.verticalCenter = -249;
        t.width = 144;
        return t;
    };
    _proto.btnGuanbi2_i = function() {
        var t = new eui.Group();
        this.btnGuanbi2 = t;
        t.anchorOffsetX = 0;
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.touchEnabled = true;
        t.verticalCenter = 333;
        t.x = 214;
        t.elementsContent = [this.txtCancel_i()];
        return t;
    };
    _proto.txtCancel_i = function() {
        var t = new eui.Label();
        this.txtCancel = t;
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 28;
        t.strokeColor = 0xff921c;
        t.text = "狠心放弃";
        t.textColor = 0xe8e8e8;
        t.x = 0;
        return t;
    };
    return GameDaojuHeidongSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameDaojuZhadanSkin.exml'] = window.GameDaojuZhadanSkin = (function(_super) {
    __extends(GameDaojuZhadanSkin, _super);

    function GameDaojuZhadanSkin() {
        _super.call(this);
        this.skinParts = ["btnGuanbi", "btnGoumai", "btnMianfei"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = GameDaojuZhadanSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = 341;
        t.height = 554;
        t.horizontalCenter = 5;
        t.width = 562;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this.btnGuanbi_i(), this._Image5_i(), this._Image6_i(), this._Image7_i(), this._Image8_i(), this.btnGoumai_i(), this.btnMianfei_i(), this._Image14_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0.5;
        t.scale9Grid = new egret.Rectangle(89, 327, 1, 0);
        t.source = "play_json.zmj_frame_26";
        t.verticalCenter = 0.5;
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 112;
        t.y = -22.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 28;
        t.anchorOffsetY = 20;
        t.height = 42;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 52;
        t.x = 49.73;
        t.y = -17.17;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 0;
        t.y = -16;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_38";
        t.x = 234.85;
        t.y = -6.01;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_39";
        t.x = 248.65;
        t.y = 224.63;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_24";
        t.x = 224;
        t.y = 93;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.height = 127;
        t.scale9Grid = new egret.Rectangle(79, 36, 0, 0);
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 60;
        t.y = 277.5;
        return t;
    };
    _proto.btnGoumai_i = function() {
        var t = new eui.Group();
        this.btnGoumai = t;
        t.anchorOffsetY = 0;
        t.height = 65.33;
        t.width = 200;
        t.x = 289.85;
        t.y = 429.78;
        t.elementsContent = [this._Image9_i(), this._Image10_i(), this._Image11_i(), this._Label1_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = 11.35;
        t.y = -6.84;
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_42";
        t.x = 116.85;
        t.y = 17.61;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.zmj_icon_01";
        t.x = 33.59;
        t.y = 20.06;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.stroke = 2;
        t.strokeColor = 0x9a3c1a;
        t.text = "100";
        t.x = 72.65;
        t.y = 21.78;
        return t;
    };
    _proto.btnMianfei_i = function() {
        var t = new eui.Group();
        this.btnMianfei = t;
        t.anchorOffsetY = 0;
        t.height = 65.33;
        t.width = 200;
        t.x = 65.5;
        t.y = 427.16;
        t.elementsContent = [this._Image12_i(), this._Image13_i()];
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = 11.35;
        t.y = -6.84;
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_76";
        t.x = 24;
        t.y = 15.779999999999973;
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_41";
        t.x = 109.5;
        t.y = 325.5;
        return t;
    };
    return GameDaojuZhadanSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameDiamondCellSkin.exml'] = window.GameDiamondCellSkin = (function(_super) {
    __extends(GameDiamondCellSkin, _super);

    function GameDiamondCellSkin() {
        _super.call(this);
        this.skinParts = ["imgHead", "btnAdd", "btnYilingqu", "btnLingqu", "txtDijihaoyou", "txtDiamond"];

        this.height = 111;
        this.width = 460;
        this.elementsContent = [this._Image1_i(), this._Image2_i(), this.imgHead_i(), this.btnAdd_i(), this.btnYilingqu_i(), this.btnLingqu_i(), this.txtDijihaoyou_i(), this._Image8_i(), this.txtDiamond_i()];
    }
    var _proto = GameDiamondCellSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.height = 97;
        t.scale9Grid = new egret.Rectangle(90, 43, 0, 0);
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 10;
        t.y = 6;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(14, 83, 0, 0);
        t.source = "play_json.zmj_frame_23";
        t.width = 85;
        t.x = 27.5;
        t.y = 13.34;
        return t;
    };
    _proto.imgHead_i = function() {
        var t = new eui.Image();
        this.imgHead = t;
        t.scale9Grid = new egret.Rectangle(14, 83, 0, 0);
        t.source = "play_json.diamond_head";
        t.visible = false;
        t.width = 85;
        t.x = 27.5;
        t.y = 13.34;
        return t;
    };
    _proto.btnAdd_i = function() {
        var t = new eui.Group();
        this.btnAdd = t;
        t.x = 50;
        t.y = 30;
        t.elementsContent = [this._Image3_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_17";
        t.x = 0;
        t.y = 1;
        return t;
    };
    _proto.btnYilingqu_i = function() {
        var t = new eui.Group();
        this.btnYilingqu = t;
        t.x = 303;
        t.y = 25;
        t.elementsContent = [this._Image4_i(), this._Image5_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_16";
        t.x = -0.5;
        t.y = -4;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_25";
        t.x = 28;
        t.y = 14.84;
        return t;
    };
    _proto.btnLingqu_i = function() {
        var t = new eui.Group();
        this.btnLingqu = t;
        t.x = 306;
        t.y = 23;
        t.elementsContent = [this._Image6_i(), this._Image7_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_17";
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_26";
        t.x = 37.5;
        t.y = 18;
        return t;
    };
    _proto.txtDijihaoyou_i = function() {
        var t = new eui.Label();
        this.txtDijihaoyou = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 20;
        t.text = "第1位好友";
        t.x = 161.5;
        t.y = 25;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.5;
        t.scaleY = 0.5;
        t.source = "play_json.zmj_icon_01";
        t.x = 168.5;
        t.y = 60.1;
        return t;
    };
    _proto.txtDiamond_i = function() {
        var t = new eui.Label();
        this.txtDiamond = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 20;
        t.text = "50";
        t.x = 203;
        t.y = 62;
        return t;
    };
    return GameDiamondCellSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameDiamondSkin.exml'] = window.GameDiamondSkin = (function(_super) {
    __extends(GameDiamondSkin, _super);

    function GameDiamondSkin() {
        _super.call(this);
        this.skinParts = ["grpItems", "scrItmes", "btnYQHY", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnYQHY_i(), this.btnGuanbi_i()];
    }
    var _proto = GameDiamondSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 0;
        t.verticalCenter = 0;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this.scrItmes_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 727;
        t.scale9Grid = new egret.Rectangle(69, 727, 0, 0);
        t.source = "play_json.zmj_frame_21";
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 116;
        t.y = -26;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_22";
        t.x = 184.16;
        t.y = -9.65;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.height = 80;
        t.scale9Grid = new egret.Rectangle(90, 43, 0, 0);
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 55;
        t.y = 503.25;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_279";
        t.x = 157.16;
        t.y = 525.75;
        return t;
    };
    _proto.scrItmes_i = function() {
        var t = new eui.Scroller();
        this.scrItmes = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 418.6;
        t.width = 467.99;
        t.x = 44;
        t.y = 63;
        t.viewport = this.grpItems_i();
        return t;
    };
    _proto.grpItems_i = function() {
        var t = new eui.Group();
        this.grpItems = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 414.06;
        t.width = 460;
        t.layout = this._VerticalLayout1_i();
        return t;
    };
    _proto._VerticalLayout1_i = function() {
        var t = new eui.VerticalLayout();
        t.gap = 2;
        t.horizontalAlign = "left";
        t.verticalAlign = "top";
        return t;
    };
    _proto.btnYQHY_i = function() {
        var t = new eui.Group();
        this.btnYQHY = t;
        t.horizontalCenter = 4;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 279.5;
        t.elementsContent = [this._Image7_i(), this._Image8_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_23";
        t.x = 26;
        t.y = 20;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 262.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -349;
        t.elementsContent = [this._Image9_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    return GameDiamondSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameOverSkin.exml'] = window.GameOverSkin = (function(_super) {
    __extends(GameOverSkin, _super);

    function GameOverSkin() {
        _super.call(this);
        this.skinParts = ["txtTotalScore", "txtTongguanScore", "txtPassLevel", "txtRelive", "txtReliveDiamond", "btnRelive", "btnMianfei", "btnCancel", "btnGuanbi", "group_like"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnCancel_i(), this.btnGuanbi_i(), this.group_like_i()];
    }
    var _proto = GameOverSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -0.5;
        t.verticalCenter = -66.5;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this._Image7_i(), this._Image8_i(), this.txtTotalScore_i(), this.txtTongguanScore_i(), this.txtPassLevel_i(), this.txtRelive_i(), this.btnRelive_i(), this.btnMianfei_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 727;
        t.scale9Grid = new egret.Rectangle(71, 65, 0, 397);
        t.source = "play_json.zmj_frame_26";
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.height = 187;
        t.scale9Grid = new egret.Rectangle(95, 40, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 46.5;
        t.y = 184.5;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_51";
        t.x = 72;
        t.y = 41.15;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_97";
        t.x = 150.94;
        t.y = 215.85;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_98";
        t.x = 150;
        t.y = 262.88;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_54";
        t.x = 204.44;
        t.y = 309.88;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_55";
        t.visible = false;
        t.x = 191.94;
        t.y = 317.26;
        return t;
    };
    _proto.txtTotalScore_i = function() {
        var t = new eui.Label();
        this.txtTotalScore = t;
        t.fontFamily = "Microsoft YaHei";
        t.text = "9999999";
        t.textAlign = "left";
        t.x = 283.15;
        t.y = 215.85;
        return t;
    };
    _proto.txtTongguanScore_i = function() {
        var t = new eui.Label();
        this.txtTongguanScore = t;
        t.fontFamily = "Microsoft YaHei";
        t.text = "9999999";
        t.textAlign = "left";
        t.x = 283.15;
        t.y = 261.85;
        return t;
    };
    _proto.txtPassLevel_i = function() {
        var t = new eui.Label();
        this.txtPassLevel = t;
        t.fontFamily = "Microsoft YaHei";
        t.text = "99999";
        t.textAlign = "left";
        t.x = 283.15;
        t.y = 309.88;
        return t;
    };
    _proto.txtRelive_i = function() {
        var t = new eui.Label();
        this.txtRelive = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "0/3";
        t.visible = false;
        t.x = 260.5;
        t.y = 319.26;
        return t;
    };
    _proto.btnRelive_i = function() {
        var t = new eui.Group();
        this.btnRelive = t;
        t.anchorOffsetX = 90;
        t.anchorOffsetY = 38;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 385;
        t.y = 629;
        t.elementsContent = [this._Image9_i(), this._Image10_i(), this._Image11_i(), this.txtReliveDiamond_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.3;
        t.scaleY = 0.3;
        t.source = "play_json.zmj_icon_29";
        t.x = 10;
        t.y = 22;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_52";
        t.x = 110.24;
        t.y = 18.91;
        return t;
    };
    _proto.txtReliveDiamond_i = function() {
        var t = new eui.Label();
        this.txtReliveDiamond = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 28;
        t.stroke = 2;
        t.strokeColor = 0x9a3c1a;
        t.text = "100";
        t.x = 55;
        t.y = 22;
        return t;
    };
    _proto.btnMianfei_i = function() {
        var t = new eui.Group();
        this.btnMianfei = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 75.44;
        t.y = 591.5;
        t.elementsContent = [this._Image12_i(), this._Image13_i()];
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 86;
        t.anchorOffsetY = 42;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        t.x = 86;
        t.y = 42;
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_76";
        t.x = 17;
        t.y = 18.91;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -3.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 333.5;
        t.elementsContent = [this._Image14_i()];
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_53";
        t.x = -7.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 521;
        t.y = 126;
        t.elementsContent = [this._Image15_i()];
        return t;
    };
    _proto._Image15_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    _proto.group_like_i = function() {
        var t = new eui.Group();
        this.group_like = t;
        t.height = 200;
        t.horizontalCenter = 0;
        t.verticalCenter = 80;
        t.width = 640;
        return t;
    };
    return GameOverSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GamePassSkin.exml'] = window.GamePassSkin = (function(_super) {
    __extends(GamePassSkin, _super);

    function GamePassSkin() {
        _super.call(this);
        this.skinParts = ["txtScore", "txtTotalScore", "txtDiamond", "btnShuangbei", "txtNextLevel", "btnNextLevel", "btnTiaozhanhaoyou", "btnGuanbi", "group_like"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnTiaozhanhaoyou_i(), this.btnGuanbi_i(), this.group_like_i()];
    }
    var _proto = GamePassSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 0;
        t.verticalCenter = -50.5;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this._Image7_i(), this._Image8_i(), this._Image9_i(), this.txtScore_i(), this.txtTotalScore_i(), this.txtDiamond_i(), this._Label1_i(), this.btnShuangbei_i(), this.btnNextLevel_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 727;
        t.scale9Grid = new egret.Rectangle(71, 65, 0, 397);
        t.source = "play_json.zmj_frame_26";
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.height = 187;
        t.scale9Grid = new egret.Rectangle(95, 40, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 46.5;
        t.y = 184.5;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_50";
        t.x = 56;
        t.y = 41.15;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_45";
        t.x = 156.94;
        t.y = 215.85;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_46";
        t.visible = false;
        t.x = 156.44;
        t.y = 265.88;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_47";
        t.x = 157.94;
        t.y = 266.6;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.3;
        t.scaleY = 0.3;
        t.source = "play_json.zmj_icon_29";
        t.x = 241.09;
        t.y = 266.59;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 30.12;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_36";
        t.width = 32.99;
        t.x = 245.75;
        t.y = 312.63;
        return t;
    };
    _proto.txtScore_i = function() {
        var t = new eui.Label();
        this.txtScore = t;
        t.text = "0";
        t.textAlign = "left";
        t.x = 245.15;
        t.y = 215.85;
        return t;
    };
    _proto.txtTotalScore_i = function() {
        var t = new eui.Label();
        this.txtTotalScore = t;
        t.text = "0";
        t.textAlign = "left";
        t.visible = false;
        t.x = 245.15;
        t.y = 265.88;
        return t;
    };
    _proto.txtDiamond_i = function() {
        var t = new eui.Label();
        this.txtDiamond = t;
        t.text = "300";
        t.x = 285.84;
        t.y = 268.93;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.text = "1";
        t.x = 285.2;
        t.y = 316.25;
        return t;
    };
    _proto.btnShuangbei_i = function() {
        var t = new eui.Group();
        this.btnShuangbei = t;
        t.anchorOffsetX = 90.67;
        t.anchorOffsetY = 41.33;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 160.67;
        t.y = 637.66;
        t.elementsContent = [this._Image10_i(), this._Image11_i(),this._Image9_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_48";
        t.x = 44.24;
        t.y = 18.91;
        return t;
    };
	_proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 12.66;
        t.y = 24.33;
        return t;
    };
    _proto.btnNextLevel_i = function() {
        var t = new eui.Group();
        this.btnNextLevel = t;
        t.anchorOffsetX = 92;
        t.anchorOffsetY = 40;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 400;
        t.y = 635.69;
        t.elementsContent = [this._Image12_i(), this._Image13_i(), this.txtNextLevel_i()];
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_49";
        t.x = 42.43;
        t.y = 21.94;
        return t;
    };
    _proto.txtNextLevel_i = function() {
        var t = new eui.Label();
        this.txtNextLevel = t;
        t.fontFamily = "Microsoft YaHei";
        t.strokeColor = 0x000000;
        t.text = "Next level";
        t.textColor = 0xcecece;
        t.visible = false;
        t.x = 44;
        t.y = 26;
        return t;
    };
    _proto.btnTiaozhanhaoyou_i = function() {
        var t = new eui.Group();
        this.btnTiaozhanhaoyou = t;
        t.horizontalCenter = -121;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 219.5;
        t.visible = false;
        t.elementsContent = [this._Image14_i(), this._Image15_i()];
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        return t;
    };
    _proto._Image15_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 58.33;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.tzhy";
        t.width = 212.33;
        t.x = 28.43;
        t.y = 21.94;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 521;
        t.y = 142;
        t.elementsContent = [this._Image16_i()];
        return t;
    };
    _proto._Image16_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    _proto.group_like_i = function() {
        var t = new eui.Group();
        this.group_like = t;
        t.height = 200;
        t.horizontalCenter = 0;
        t.verticalCenter = 80;
        t.width = 640;
        return t;
    };
    return GamePassSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GamePauseSkin.exml'] = window.GamePauseSkin = (function(_super) {
    __extends(GamePauseSkin, _super);

    function GamePauseSkin() {
        _super.call(this);
        this.skinParts = ["btnGuanbi", "btnJixuyouxi", "btnChongxinkaishi", "btnFanhui", "btnHaoyoujieli", "group_bk", "group_ad1", "group_ad2"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnHaoyoujieli_i(), this.group_bk_i(), this.group_ad1_i(), this.group_ad2_i()];
    }
    var _proto = GamePauseSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 392;
        t.horizontalCenter = 0;
        t.verticalCenter = -26;
        t.width = 642.09;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this.btnGuanbi_i(), this._Image5_i(), this.btnJixuyouxi_i(), this.btnChongxinkaishi_i(), this.btnFanhui_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(89, 327, 1, 0);
        t.source = "play_json.zmj_frame_22";
        t.width = 553;
        t.x = 52;
        t.y = 32.5;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 158.5;
        t.y = 3.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 42;
        t.horizontalCenter = 234;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -146;
        t.width = 52;
        t.x = 527;
        t.y = -58;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 0;
        t.y = -16;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_34";
        t.x = 277;
        t.y = 22.5;
        return t;
    };
    _proto.btnJixuyouxi_i = function() {
        var t = new eui.Group();
        this.btnJixuyouxi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 117;
        t.width = 119;
        t.x = 363.41;
        t.y = 139;
        t.elementsContent = [this._Image6_i(), this._Image7_i(), this._Image8_i(), this._Image9_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_12";
        t.x = 0;
        t.y = -2.5;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_20";
        t.x = 16;
        t.y = 11;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_23";
        t.x = 42.5;
        t.y = 39.5;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_35";
        t.x = 3.5;
        t.y = 134.0000000000001;
        return t;
    };
    _proto.btnChongxinkaishi_i = function() {
        var t = new eui.Group();
        this.btnChongxinkaishi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 117;
        t.visible = false;
        t.width = 119;
        t.x = 270;
        t.y = 139;
        t.elementsContent = [this._Image10_i(), this._Image11_i(), this._Image12_i(), this._Image13_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_12";
        t.x = 0;
        t.y = -2.5;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_12";
        t.x = 18;
        t.y = 10;
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_21";
        t.x = 37.5;
        t.y = 37.5;
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_36";
        t.x = 2.499999999999943;
        t.y = 134.0000000000001;
        return t;
    };
    _proto.btnFanhui_i = function() {
        var t = new eui.Group();
        this.btnFanhui = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 117;
        t.width = 119;
        t.x = 167.56;
        t.y = 139;
        t.elementsContent = [this._Image14_i(), this._Image15_i(), this._Image16_i(), this._Image17_i()];
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_12";
        t.x = 0;
        t.y = -2.5;
        return t;
    };
    _proto._Image15_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_13";
        t.x = 18;
        t.y = 9;
        return t;
    };
    _proto._Image16_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_22";
        t.x = 37.5;
        t.y = 33.5;
        return t;
    };
    _proto._Image17_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_37";
        t.x = -8.500000000000057;
        t.y = 134.0000000000001;
        return t;
    };
    _proto.btnHaoyoujieli_i = function() {
        var t = new eui.Group();
        this.btnHaoyoujieli = t;
        t.horizontalCenter = 13;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 184.5;
        t.visible = false;
        t.elementsContent = [this._Image18_i(), this._Image19_i()];
        return t;
    };
    _proto._Image18_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        return t;
    };
    _proto._Image19_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 58.33;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.hyjl";
        t.width = 212.33;
        t.x = 28.43;
        t.y = 21.94;
        return t;
    };
    _proto.group_bk_i = function() {
        var t = new eui.Group();
        this.group_bk = t;
        t.height = 200;
        t.horizontalCenter = 0;
        t.top = 0;
        t.visible = false;
        t.width = 640;
        return t;
    };
    _proto.group_ad1_i = function() {
        var t = new eui.Group();
        this.group_ad1 = t;
        t.height = 144;
        t.right = 50;
        t.verticalCenter = 271;
        t.visible = false;
        t.width = 144;
        return t;
    };
    _proto.group_ad2_i = function() {
        var t = new eui.Group();
        this.group_ad2 = t;
        t.height = 144;
        t.left = 50;
        t.verticalCenter = 271;
        t.visible = false;
        t.width = 144;
        t.x = 10;
        return t;
    };
    return GamePauseSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameScoreSkin.exml'] = window.GameScoreSkin = (function(_super) {
    __extends(GameScoreSkin, _super);

    function GameScoreSkin() {
        _super.call(this);
        this.skinParts = ["txtTotalScore", "txtLishi", "txtChaoyue", "btnRelive", "btnMianfei", "btnCancel", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnCancel_i(), this.btnGuanbi_i()];
    }
    var _proto = GameScoreSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -1;
        t.verticalCenter = 3;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this.txtTotalScore_i(), this.txtLishi_i(), this.txtChaoyue_i(), this.btnRelive_i(), this.btnMianfei_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 527;
        t.scale9Grid = new egret.Rectangle(71, 65, 0, 397);
        t.source = "play_json.zmj_frame_26";
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.height = 187;
        t.scale9Grid = new egret.Rectangle(95, 40, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 46.5;
        t.y = 184.5;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_58";
        t.x = 88;
        t.y = 62;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_46";
        t.x = 168.5;
        t.y = 244;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_59";
        t.x = 89.5;
        t.y = 289.26;
        return t;
    };
    _proto.txtTotalScore_i = function() {
        var t = new eui.Label();
        this.txtTotalScore = t;
        t.fontFamily = "Microsoft YaHei";
        t.text = "9999999";
        t.textAlign = "left";
        t.x = 251.44;
        t.y = 244;
        return t;
    };
    _proto.txtLishi_i = function() {
        var t = new eui.Label();
        this.txtLishi = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "999999";
        t.x = 256.3;
        t.y = 289.26;
        return t;
    };
    _proto.txtChaoyue_i = function() {
        var t = new eui.Label();
        this.txtChaoyue = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "99%";
        t.textColor = 0x00ffc7;
        t.x = 313.44;
        t.y = 116;
        return t;
    };
    _proto.btnRelive_i = function() {
        var t = new eui.Group();
        this.btnRelive = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 295;
        t.y = 399;
        t.elementsContent = [this._Image7_i(), this._Image8_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_57";
        t.x = 28.5;
        t.y = 20.41;
        return t;
    };
    _proto.btnMianfei_i = function() {
        var t = new eui.Group();
        this.btnMianfei = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 75.44;
        t.y = 399.5;
        t.elementsContent = [this._Image9_i(), this._Image10_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_56";
        t.x = 30.06;
        t.y = 20.5;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -3.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 309.5;
        t.elementsContent = [this._Image11_i()];
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_53";
        t.x = -7.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 239.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -235;
        t.elementsContent = [this._Image12_i()];
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    return GameScoreSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GameSetSkin.exml'] = window.GameSetSkin = (function(_super) {
    __extends(GameSetSkin, _super);

    function GameSetSkin() {
        _super.call(this);
        this.skinParts = ["btnGuanbi", "imgYinxiaog", "imgYinxiaok", "btnYinxiao", "imgYinxiaokai", "imgYinxiaoguan", "grpYinxiao", "btnFanhui", "grpKefu", "group_bk", "group_ad1", "group_ad2"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.group_bk_i(), this.group_ad1_i(), this.group_ad2_i()];
    }
    var _proto = GameSetSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 392;
        t.horizontalCenter = 0.5;
        t.verticalCenter = -31;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this.btnGuanbi_i(), this._Image5_i(), this.grpYinxiao_i(), this.grpKefu_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(89, 327, 1, 0);
        t.source = "play_json.zmj_frame_22";
        t.width = 553;
        t.x = 0;
        t.y = 32.5;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 106.5;
        t.y = 3.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 232;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -151;
        t.x = 527;
        t.y = -58;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_15";
        t.x = 225;
        t.y = 22.5;
        return t;
    };
    _proto.grpYinxiao_i = function() {
        var t = new eui.Group();
        this.grpYinxiao = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 170;
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 138;
        t.y = 139.5;
        t.elementsContent = [this._Image6_i(), this.btnYinxiao_i(), this.imgYinxiaokai_i(), this.imgYinxiaoguan_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_12";
        t.x = 0;
        t.y = -1.5;
        return t;
    };
    _proto.btnYinxiao_i = function() {
        var t = new eui.Group();
        this.btnYinxiao = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 117;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 119;
        t.x = 1;
        t.y = 1;
        t.elementsContent = [this._Image7_i(), this.imgYinxiaog_i(), this.imgYinxiaok_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_12";
        t.x = 18;
        t.y = 10;
        return t;
    };
    _proto.imgYinxiaog_i = function() {
        var t = new eui.Image();
        this.imgYinxiaog = t;
        t.source = "play_json.zmj_icon_13";
        t.x = 37.5;
        t.y = 37.5;
        return t;
    };
    _proto.imgYinxiaok_i = function() {
        var t = new eui.Image();
        this.imgYinxiaok = t;
        t.source = "play_json.zmj_icon_12";
        t.x = 36.5;
        t.y = 35.5;
        return t;
    };
    _proto.imgYinxiaokai_i = function() {
        var t = new eui.Image();
        this.imgYinxiaokai = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_16";
        t.x = 22;
        t.y = 134;
        return t;
    };
    _proto.imgYinxiaoguan_i = function() {
        var t = new eui.Image();
        this.imgYinxiaoguan = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_17";
        t.x = 23.5;
        t.y = 134;
        return t;
    };
    _proto.grpKefu_i = function() {
        var t = new eui.Group();
        this.grpKefu = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 176;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.width = 132;
        t.x = 328;
        t.y = 136.5;
        t.elementsContent = [this._Image8_i(), this.btnFanhui_i(), this._Image11_i()];
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_12";
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.btnFanhui_i = function() {
        var t = new eui.Group();
        this.btnFanhui = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 117;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 119;
        t.x = 0;
        t.y = 2.5;
        t.elementsContent = [this._Image9_i(), this._Image10_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_13";
        t.x = 18;
        t.y = 9;
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_14";
        t.x = 37.5;
        t.y = 33.5;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_18";
        t.x = 5;
        t.y = 138.5;
        return t;
    };
    _proto.group_bk_i = function() {
        var t = new eui.Group();
        this.group_bk = t;
        t.height = 200;
        t.horizontalCenter = 0;
        t.top = 0;
        t.visible = false;
        t.width = 640;
        return t;
    };
    _proto.group_ad1_i = function() {
        var t = new eui.Group();
        this.group_ad1 = t;
        t.height = 144;
        t.right = 50;
        t.verticalCenter = 297;
        t.visible = false;
        t.width = 144;
        return t;
    };
    _proto.group_ad2_i = function() {
        var t = new eui.Group();
        this.group_ad2 = t;
        t.height = 144;
        t.left = 50;
        t.verticalCenter = 297;
        t.visible = false;
        t.width = 144;
        t.x = 10;
        return t;
    };
    return GameSetSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/GongzhonghaoSkin.exml'] = window.GongzhonghaoSkin = (function(_super) {
    __extends(GongzhonghaoSkin, _super);

    function GongzhonghaoSkin() {
        _super.call(this);
        this.skinParts = [];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Image2_i()];
    }
    var _proto = GongzhonghaoSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.anchorOffsetY = 0;
        t.horizontalCenter = 0;
        t.source = "qmqqq_jpg";
        t.verticalCenter = 0;
        return t;
    };
    return GongzhonghaoSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/HuodeWupinSkin.exml'] = window.HuodeWupinSkin = (function(_super) {
    __extends(HuodeWupinSkin, _super);

    function HuodeWupinSkin() {
        _super.call(this);
        this.skinParts = ["anim1", "imgShanguang", "imgWupin1", "imgWupin2", "imgWupin3", "imgWupin4", "txtNum", "txtScore", "grpScore"];

        this.height = 1136;
        this.width = 640;
        this.anim1_i();
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
        this.states = [
            new eui.State("1", [
                new eui.SetProperty("imgShanguang", "anchorOffsetX", 169.33),
                new eui.SetProperty("imgShanguang", "anchorOffsetY", 157.94),
                new eui.SetProperty("imgShanguang", "x", 319.98),
                new eui.SetProperty("imgShanguang", "y", 444.66)
            ])
        ];

        eui.Binding.$bindProperties(this, ["imgShanguang"], [0], this._TweenItem1, "target");
        eui.Binding.$bindProperties(this, [1], [], this._Object1, "alpha");
        eui.Binding.$bindProperties(this, [0], [], this._Object1, "rotation");
        eui.Binding.$bindProperties(this, [0.5], [], this._Object2, "alpha");
        eui.Binding.$bindProperties(this, [180], [], this._Object2, "rotation");
        eui.Binding.$bindProperties(this, [1], [], this._Object3, "alpha");
        eui.Binding.$bindProperties(this, [360], [], this._Object3, "rotation");
    }
    var _proto = HuodeWupinSkin.prototype;

    _proto.anim1_i = function() {
        var t = new egret.tween.TweenGroup();
        this.anim1 = t;
        t.items = [this._TweenItem1_i()];
        return t;
    };
    _proto._TweenItem1_i = function() {
        var t = new egret.tween.TweenItem();
        this._TweenItem1 = t;
        t.paths = [this._Set1_i(), this._To1_i(), this._To2_i()];
        return t;
    };
    _proto._Set1_i = function() {
        var t = new egret.tween.Set();
        t.props = this._Object1_i();
        return t;
    };
    _proto._Object1_i = function() {
        var t = {};
        this._Object1 = t;
        return t;
    };
    _proto._To1_i = function() {
        var t = new egret.tween.To();
        t.duration = 1750;
        t.props = this._Object2_i();
        return t;
    };
    _proto._Object2_i = function() {
        var t = {};
        this._Object2 = t;
        return t;
    };
    _proto._To2_i = function() {
        var t = new egret.tween.To();
        t.duration = 1800;
        t.props = this._Object3_i();
        return t;
    };
    _proto._Object3_i = function() {
        var t = {};
        this._Object3 = t;
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.9;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.height = 1136;
        t.horizontalCenter = 0;
        t.verticalCenter = 0;
        t.width = 640;
        t.elementsContent = [this.imgShanguang_i(), this.imgWupin1_i(), this.imgWupin2_i(), this.imgWupin3_i(), this.imgWupin4_i(), this.txtNum_i(), this.grpScore_i()];
        return t;
    };
    _proto.imgShanguang_i = function() {
        var t = new eui.Image();
        this.imgShanguang = t;
        t.anchorOffsetX = 164;
        t.anchorOffsetY = 163;
        t.source = "play_json.zmj_frame_30";
        t.x = 322.24;
        t.y = 463.4;
        return t;
    };
    _proto.imgWupin1_i = function() {
        var t = new eui.Image();
        this.imgWupin1 = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 86.94;
        t.source = "play_json.zmj_icon_01";
        t.width = 113.28;
        t.x = 266.4;
        t.y = 413.33;
        return t;
    };
    _proto.imgWupin2_i = function() {
        var t = new eui.Image();
        this.imgWupin2 = t;
        t.source = "play_json.zmj_icon_24";
        t.x = 271.54;
        t.y = 382.27;
        return t;
    };
    _proto.imgWupin3_i = function() {
        var t = new eui.Image();
        this.imgWupin3 = t;
        t.source = "play_json.zmj_icon_25";
        t.x = 242.04;
        t.y = 362.27;
        return t;
    };
    _proto.imgWupin4_i = function() {
        var t = new eui.Image();
        this.imgWupin4 = t;
        t.height = 60;
        t.source = "play_json.zmj_icon_37";
        t.width = 60;
        t.x = 292.04;
        t.y = 412.27;
        return t;
    };
    _proto.txtNum_i = function() {
        var t = new eui.Label();
        this.txtNum = t;
        t.text = "+0";
        t.textAlign = "center";
        t.width = 130;
        t.x = 260.04;
        t.y = 538;
        return t;
    };
    _proto.grpScore_i = function() {
        var t = new eui.Group();
        this.grpScore = t;
        t.horizontalCenter = 1;
        t.visible = false;
        t.y = 624.04;
        t.elementsContent = [this._Label1_i(), this.txtScore_i()];
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "Bonus points：";
        t.textColor = 0xf97e07;
        return t;
    };
    _proto.txtScore_i = function() {
        var t = new eui.BitmapLabel();
        this.txtScore = t;
        t.font = "score_fnt";
        t.scaleX = 0.5;
        t.scaleY = 0.5;
        t.text = "10";
        t.x = 204.79;
        t.y = -0.48;
        return t;
    };
    return HuodeWupinSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/LevelPropSkin.exml'] = window.LevelPropSkin = (function(_super) {
    __extends(LevelPropSkin, _super);

    function LevelPropSkin() {
        _super.call(this);
        this.skinParts = ["imgHead", "grpHead", "txtTip", "btnSure", "btnCancel"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Group1_i(), this._Group2_i()];
    }
    var _proto = LevelPropSkin.prototype;

    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.top = 0;
        return t;
    };
    _proto._Group2_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -1;
        t.verticalCenter = -160;
        t.elementsContent = [this._Image1_i(), this.grpHead_i(), this.txtTip_i(), this.btnSure_i(), this.btnCancel_i()];
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.anchorOffsetY = 0;
        t.height = 327.76;
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.touchEnabled = true;
        t.width = 852;
        t.y = 0;
        return t;
    };
    _proto.grpHead_i = function() {
        var t = new eui.Group();
        this.grpHead = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.x = 135.74;
        t.y = 28.67;
        t.elementsContent = [this._Image2_i(), this.imgHead_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_15";
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.imgHead_i = function() {
        var t = new eui.Image();
        this.imgHead = t;
        t.height = 100;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "head_0_jpg";
        t.width = 100;
        t.x = 15.149999999999977;
        t.y = 12.120000000000005;
        return t;
    };
    _proto.txtTip_i = function() {
        var t = new eui.Label();
        this.txtTip = t;
        t.fontFamily = "Microsoft YaHei";
        t.lineSpacing = 15;
        t.size = 24;
        t.text = "你太厉害了！送你一个减速道具！\n使用后本关减速50%！";
        t.textAlign = "left";
        t.x = 288.08;
        t.y = 45.67;
        return t;
    };
    _proto.btnSure_i = function() {
        var t = new eui.Group();
        this.btnSure = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 328.33;
        t.y = 175.87;
        t.elementsContent = [this._Image3_i(), this._Image4_i(), this._Image5_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_19";
        t.x = 47.84;
        t.y = 20.41;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 13.01;
        t.y = 25.27;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -1;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 124;
        t.x = 387;
        t.y = 542;
        t.elementsContent = [this._Label1_i()];
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 20;
        t.stroke = 2;
        t.text = "点击跳过";
        t.textAlign = "center";
        t.textColor = 0xc6c4c5;
        t.x = -6;
        t.y = 1;
        return t;
    };
    return LevelPropSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/LevelScrollBarSkin.exml'] = window.LevelScrollBarSkin = (function(_super) {
    __extends(LevelScrollBarSkin, _super);

    function LevelScrollBarSkin() {
        _super.call(this);
        this.skinParts = ["thumb"];

        this.minHeight = 8;
        this.minWidth = 20;
        this.elementsContent = [this.thumb_i()];
    }
    var _proto = LevelScrollBarSkin.prototype;

    _proto.thumb_i = function() {
        var t = new eui.Image();
        this.thumb = t;
        t.scale9Grid = new egret.Rectangle(15, 3, 0, 2);
        t.source = "play_json.zmj_frame_14";
        t.verticalCenter = 0;
        t.width = 210;
        return t;
    };
    return LevelScrollBarSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/LevelSelSkin.exml'] = window.LevelSelSkin = (function(_super) {
    __extends(LevelSelSkin, _super);

    function LevelSelSkin() {
        _super.call(this);
        this.skinParts = ["btnCxks", "btnJixu", "txtFuhuo", "btnFuhuo", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnGuanbi_i()];
    }
    var _proto = LevelSelSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 0;
        t.verticalCenter = -51;
        t.elementsContent = [this._Image2_i(), this._Label1_i(), this._Label2_i(), this.btnCxks_i(), this.btnJixu_i(), this.btnFuhuo_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 300;
        t.scale9Grid = new egret.Rectangle(71, 65, 0, 397);
        t.source = "play_json.zmj_frame_26";
        t.width = 553;
        t.x = -1.33;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "已有游戏存档！";
        t.textColor = 0xffffff;
        t.x = 170.17;
        t.y = 78.67;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "是否从上次的关卡继续游戏？";
        t.textColor = 0xFFFFFF;
        t.x = 80.17;
        t.y = 120;
        return t;
    };
    _proto.btnCxks_i = function() {
        var t = new eui.Group();
        this.btnCxks = t;
        t.anchorOffsetX = 91;
        t.anchorOffsetY = 35;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 147.84;
        t.y = 230.61;
        t.elementsContent = [this._Image3_i(), this._Image4_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        t.x = 0.51;
        t.y = -6;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.cxks";
        t.x = 28.81;
        t.y = 15.52;
        return t;
    };
    _proto.btnJixu_i = function() {
        var t = new eui.Group();
        this.btnJixu = t;
        t.anchorOffsetX = 91;
        t.anchorOffsetY = 35;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 389.35;
        t.y = 229.13;
        t.elementsContent = [this._Image5_i(), this._Image6_i()];
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        t.y = -6;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.jxyx";
        t.x = 28.3;
        t.y = 17;
        return t;
    };
    _proto.btnFuhuo_i = function() {
        var t = new eui.Group();
        this.btnFuhuo = t;
        t.anchorOffsetX = 91;
        t.anchorOffsetY = 35;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 389.35;
        t.y = 229.13;
        t.elementsContent = [this._Image7_i(), this._Image8_i(), this.txtFuhuo_i(), this._Image9_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        t.y = -6;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.mffh";
        t.x = 45.3;
        t.y = 16.48;
        return t;
    };
    _proto.txtFuhuo_i = function() {
        var t = new eui.Label();
        this.txtFuhuo = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.text = "(0/3)";
        t.verticalAlign = "middle";
        t.x = 105;
        t.y = 17;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 16;
        t.y = 20;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 40;
        t.anchorOffsetY = 35;
        t.horizontalCenter = 240;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -231;
        t.elementsContent = [this._Image10_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.alpha = 0.6;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 2.35;
        return t;
    };
    return LevelSelSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/LixianjiangliSkin.exml'] = window.LixianjiangliSkin = (function(_super) {
    __extends(LixianjiangliSkin, _super);

    function LixianjiangliSkin() {
        _super.call(this);
        this.skinParts = ["btnShuangbeilingqu", "txtZuanshiNum", "btnLingqu"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = LixianjiangliSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 554;
        t.horizontalCenter = 5;
        t.verticalCenter = -53;
        t.width = 562;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this.btnShuangbeilingqu_i(), this._Image8_i(), this._Image9_i(), this.txtZuanshiNum_i(), this.btnLingqu_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0.5;
        t.scale9Grid = new egret.Rectangle(89, 327, 1, 0);
        t.source = "play_json.zmj_frame_26";
        t.verticalCenter = 0.5;
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 112;
        t.y = -22.5;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.lxjl";
        t.x = 171;
        t.y = -13.5;
        return t;
    };
    _proto.btnShuangbeilingqu_i = function() {
        var t = new eui.Group();
        this.btnShuangbeilingqu = t;
        t.anchorOffsetY = 0;
        t.height = 65.33;
        t.x = 188.12;
        t.y = 429.78;
        t.elementsContent = [this._Image5_i(), this._Image6_i(), this._Image7_i()];
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = -0.77;
        t.y = -6.84;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_48";
        t.x = 49.88;
        t.y = 13.66;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 13;
        t.y = 21;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_30";
        t.x = 103.35;
        t.y = 69;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_29";
        t.x = 204.65;
        t.y = 179;
        return t;
    };
    _proto.txtZuanshiNum_i = function() {
        var t = new eui.Label();
        this.txtZuanshiNum = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.text = "x1";
        t.textAlign = "center";
        t.width = 200;
        t.x = 176;
        t.y = 367;
        return t;
    };
    _proto.btnLingqu_i = function() {
        var t = new eui.Group();
        this.btnLingqu = t;
        t.visible = false;
        t.x = 221.31;
        t.y = 545.75;
        t.elementsContent = [this._Label1_i()];
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 20;
        t.text = "Receive>>";
        t.textColor = 0xffffff;
        return t;
    };
    return LixianjiangliSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/MoreGameItemSkin.exml'] = window.MoreGameItemSkin = (function(_super) {
    __extends(MoreGameItemSkin, _super);

    function MoreGameItemSkin() {
        _super.call(this);
        this.skinParts = ["imgIcon", "lbName", "grpCell"];

        this.elementsContent = [this.grpCell_i()];
    }
    var _proto = MoreGameItemSkin.prototype;

    _proto.grpCell_i = function() {
        var t = new eui.Group();
        this.grpCell = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.x = 0;
        t.y = 0;
        t.elementsContent = [this._Image1_i(), this.imgIcon_i(), this.lbName_i()];
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.height = 80;
        t.scale9Grid = new egret.Rectangle(31, 20, 0, 0);
        t.source = "icon_youxi_png";
        t.width = 80;
        t.x = 21;
        return t;
    };
    _proto.imgIcon_i = function() {
        var t = new eui.Image();
        this.imgIcon = t;
        t.height = 78;
        t.scale9Grid = new egret.Rectangle(31, 20, 0, 0);
        t.source = "";
        t.width = 78;
        t.x = 21;
        return t;
    };
    _proto.lbName_i = function() {
        var t = new eui.Label();
        this.lbName = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 20;
        t.text = "1";
        t.textAlign = "center";
        t.textColor = 0xffffff;
        t.width = 120;
        t.y = 89;
        return t;
    };
    return MoreGameItemSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/PifuCellSkin.exml'] = window.PifuCellSkin = (function(_super) {
    __extends(PifuCellSkin, _super);

    function PifuCellSkin() {
        _super.call(this);
        this.skinParts = ["grpState1", "grpState2", "txtDiamondCnt", "imgRedDot3", "grpState3", "txtYaoqin", "imgRedDot4", "grpState4", "txtSuipianCnt", "imgRedDot5", "grpState5", "imgIcon"];

        this.elementsContent = [this._Group3_i()];
    }
    var _proto = PifuCellSkin.prototype;

    _proto._Group3_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.elementsContent = [this._Image1_i(), this.grpState1_i(), this.grpState2_i(), this.grpState3_i(), this.grpState4_i(), this.grpState5_i(), this.imgIcon_i()];
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.anchorOffsetY = 0;
        t.height = 121;
        t.scale9Grid = new egret.Rectangle(68, 41, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_11";
        t.width = 173;
        return t;
    };
    _proto.grpState1_i = function() {
        var t = new eui.Group();
        this.grpState1 = t;
        t.visible = false;
        t.y = 119;
        t.elementsContent = [this._Image2_i(), this._Image3_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(25, 50, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_08";
        t.width = 174;
        t.x = 0;
        t.y = 1;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_10";
        t.x = 59.5;
        t.y = 10;
        return t;
    };
    _proto.grpState2_i = function() {
        var t = new eui.Group();
        this.grpState2 = t;
        t.visible = false;
        t.y = 119;
        t.elementsContent = [this._Image4_i(), this._Image5_i(), this._Image6_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(25, 50, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_09";
        t.width = 174;
        t.x = 0;
        t.y = 1;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_11";
        t.x = 48.5;
        t.y = 8.8;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_11";
        t.x = 129;
        t.y = -126;
        return t;
    };
    _proto.grpState3_i = function() {
        var t = new eui.Group();
        this.grpState3 = t;
        t.x = 0;
        t.y = 119;
        t.elementsContent = [this._Image7_i(), this._Group1_i(), this.imgRedDot3_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(25, 50, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_10";
        t.width = 174;
        t.x = 0;
        t.y = 1;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.horizontalCenter = 0;
        t.y = 12;
        t.elementsContent = [this._Image8_i(), this.txtDiamondCnt_i()];
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.28;
        t.scaleY = 0.28;
        t.source = "play_json.zmj_icon_29";
        t.x = 0.5;
        t.y = 0;
        return t;
    };
    _proto.txtDiamondCnt_i = function() {
        var t = new eui.Label();
        this.txtDiamondCnt = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 28;
        t.stroke = 2;
        t.strokeColor = 0x8e492c;
        t.text = "400";
        t.textAlign = "left";
        t.x = 48;
        t.y = 1;
        return t;
    };
    _proto.imgRedDot3_i = function() {
        var t = new eui.Image();
        this.imgRedDot3 = t;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.qsgwz_icon_04";
        t.visible = false;
        t.width = 20;
        t.x = 154;
        t.y = 0;
        return t;
    };
    _proto.grpState4_i = function() {
        var t = new eui.Group();
        this.grpState4 = t;
        t.y = 119;
        t.elementsContent = [this._Image9_i(), this._Image10_i(), this.txtYaoqin_i(), this.imgRedDot4_i()];
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(25, 50, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_11";
        t.width = 174;
        t.x = 0;
        t.y = 1;
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.9;
        t.scaleY = 0.9;
        t.source = "play_json.zmj_font_12";
        t.x = 10.5;
        t.y = 10;
        return t;
    };
    _proto.txtYaoqin_i = function() {
        var t = new eui.Label();
        this.txtYaoqin = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 20;
        t.text = "0/1";
        t.textAlign = "center";
        t.textColor = 0x9c4317;
        t.width = 60;
        t.x = 106;
        t.y = 15;
        return t;
    };
    _proto.imgRedDot4_i = function() {
        var t = new eui.Image();
        this.imgRedDot4 = t;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.qsgwz_icon_04";
        t.visible = false;
        t.width = 20;
        t.x = 154;
        t.y = 0;
        return t;
    };
    _proto.grpState5_i = function() {
        var t = new eui.Group();
        this.grpState5 = t;
        t.x = 0;
        t.y = 119;
        t.elementsContent = [this._Image11_i(), this._Group2_i(), this.imgRedDot5_i()];
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(25, 50, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_10";
        t.width = 174;
        t.x = 0;
        t.y = 1;
        return t;
    };
    _proto._Group2_i = function() {
        var t = new eui.Group();
        t.horizontalCenter = 0;
        t.y = 12;
        t.elementsContent = [this._Image12_i(), this.txtSuipianCnt_i()];
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 1.2;
        t.scaleY = 1.2;
        t.source = "play_json.zmj_icon_37";
        t.y = 3;
        return t;
    };
    _proto.txtSuipianCnt_i = function() {
        var t = new eui.Label();
        this.txtSuipianCnt = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 28;
        t.stroke = 2;
        t.strokeColor = 0x8e492c;
        t.text = "50";
        t.textAlign = "left";
        t.x = 25;
        t.y = 1;
        return t;
    };
    _proto.imgRedDot5_i = function() {
        var t = new eui.Image();
        this.imgRedDot5 = t;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.qsgwz_icon_04";
        t.visible = false;
        t.width = 20;
        t.x = 154;
        t.y = 0;
        return t;
    };
    _proto.imgIcon_i = function() {
        var t = new eui.Image();
        this.imgIcon = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.ball_1_32";
        t.x = 60;
        t.y = 37;
        return t;
    };
    return PifuCellSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/PifuSkin.exml'] = window.PifuSkin = (function(_super) {
    __extends(PifuSkin, _super);

    function PifuSkin() {
        _super.call(this);
        this.skinParts = ["btnGuanbi", "grpItems", "txtJiesuoPifuCnt", "txtPifuScore", "imgRandPifuN", "imgRandPifuY", "btnRandPifu", "txtSuipianNum", "group_ad"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group3_i(), this.group_ad_i()];
    }
    var _proto = PifuSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group3_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 0;
        t.width = 638;
        t.y = 164;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this.btnGuanbi_i(), this._Image5_i(), this._Group1_i(), this._Scroller1_i(), this._Image9_i(), this._Image10_i(), this._Image11_i(), this.txtJiesuoPifuCnt_i(), this.txtPifuScore_i(), this.btnRandPifu_i(), this._Group2_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 727;
        t.scale9Grid = new egret.Rectangle(89, 327, 1, 0);
        t.source = "play_json.zmj_frame_21";
        t.width = 553;
        t.x = 52;
        t.y = 32.5;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 158.5;
        t.y = 3.5;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 245;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -289;
        t.width = 74;
        t.x = 527;
        t.y = -58;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 0;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_09";
        t.x = 277;
        t.y = 22.5;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.visible = false;
        t.x = 118;
        t.y = 108;
        t.elementsContent = [this._Image6_i(), this._Image7_i(), this._Image8_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.height = 170;
        t.scale9Grid = new egret.Rectangle(68, 41, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_11";
        t.width = 173;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(25, 50, 0, 0);
        t.source = "play_json.zmj_buttom_08";
        t.width = 174;
        t.x = 0;
        t.y = 119;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_10";
        t.x = 58.5;
        t.y = 128;
        return t;
    };
    _proto._Scroller1_i = function() {
        var t = new eui.Scroller();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 480;
        t.scrollPolicyH = "off";
        t.width = 422;
        t.x = 126;
        t.y = 108;
        t.viewport = this.grpItems_i();
        return t;
    };
    _proto.grpItems_i = function() {
        var t = new eui.Group();
        this.grpItems = t;
        t.anchorOffsetY = 0;
        t.height = 466;
        t.x = 2;
        t.layout = this._TileLayout1_i();
        return t;
    };
    _proto._TileLayout1_i = function() {
        var t = new eui.TileLayout();
        t.horizontalGap = 40;
        t.orientation = "rows";
        t.paddingLeft = 0;
        t.paddingTop = 10;
        t.requestedColumnCount = 2;
        t.verticalGap = 30;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(97, 10, 0, 63);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_10";
        t.width = 449;
        t.x = 96.5;
        t.y = 637;
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_13";
        t.x = 145;
        t.y = 663.5;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_14";
        t.x = 302;
        t.y = 663.5;
        return t;
    };
    _proto.txtJiesuoPifuCnt_i = function() {
        var t = new eui.Label();
        this.txtJiesuoPifuCnt = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.text = "0";
        t.textColor = 0xffffff;
        t.x = 259;
        t.y = 663.5;
        return t;
    };
    _proto.txtPifuScore_i = function() {
        var t = new eui.Label();
        this.txtPifuScore = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.text = "5";
        t.textColor = 0xFFFFFF;
        t.x = 437.98;
        t.y = 664.83;
        return t;
    };
    _proto.btnRandPifu_i = function() {
        var t = new eui.Group();
        this.btnRandPifu = t;
        t.visible = false;
        t.x = 120.32;
        t.y = 596.74;
        t.elementsContent = [this.imgRandPifuN_i(), this.imgRandPifuY_i(), this._Label1_i()];
        return t;
    };
    _proto.imgRandPifuN_i = function() {
        var t = new eui.Image();
        this.imgRandPifuN = t;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.zmj_icon_88";
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.imgRandPifuY_i = function() {
        var t = new eui.Image();
        this.imgRandPifuY = t;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.zmj_icon_11";
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 22;
        t.stroke = 2;
        t.text = "随机皮肤";
        t.x = 38.349999999999994;
        t.y = 4.899999999999977;
        return t;
    };
    _proto._Group2_i = function() {
        var t = new eui.Group();
        t.x = 122.5;
        t.y = 602.06;
        t.elementsContent = [this._Label2_i(), this._Image12_i(), this.txtSuipianNum_i()];
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 22;
        t.text = "chip：";
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_37";
        t.x = 90;
        t.y = 1.67;
        return t;
    };
    _proto.txtSuipianNum_i = function() {
        var t = new eui.Label();
        this.txtSuipianNum = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "0";
        t.textAlign = "left";
        t.x = 122.01;
        t.y = 1;
        return t;
    };
    _proto.group_ad_i = function() {
        var t = new eui.Group();
        this.group_ad = t;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.touchThrough = true;
        t.verticalCenter = 0;
        t.width = 640;
        return t;
    };
    return PifuSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/QiandaoSkin.exml'] = window.QiandaoSkin = (function(_super) {
    __extends(QiandaoSkin, _super);

    function QiandaoSkin() {
        _super.call(this);
        this.skinParts = ["btnSure", "imgJrbg7", "imgJrbg2", "imgJrbg3", "imgJrbg4", "imgJrbg5", "imgJrbg6", "imgJrbg1", "imgYilingqu1", "imgYilingqu2", "imgYilingqu3", "imgYilingqu4", "imgYilingqu5", "imgYilingqu6", "imgYilingqu7", "imgJinri2", "imgJinri1", "imgJinri4", "imgJinri5", "imgJinri6", "imgJinri7", "imgJinri3", "txtLingqu", "btnLingqu", "btnGuanbi", "group_ad1", "group_ad2"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.group_ad1_i(), this.group_ad2_i()];
    }
    var _proto = QiandaoSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 670;
        t.horizontalCenter = -2;
        t.width = 636;
        t.y = 265.34;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this._Image7_i(), this._Image8_i(), this._Image9_i(), this.btnSure_i(), this.imgJrbg7_i(), this.imgJrbg2_i(), this.imgJrbg3_i(), this.imgJrbg4_i(), this.imgJrbg5_i(), this.imgJrbg6_i(), this.imgJrbg1_i(), this._Image13_i(), this._Image14_i(), this._Image15_i(), this._Image16_i(), this._Image17_i(), this._Image18_i(), this._Image19_i(), this._Image20_i(), this._Label1_i(), this._Label2_i(), this._Label3_i(), this._Image21_i(), this._Label4_i(), this._Image22_i(), this._Label5_i(), this._Image23_i(), this._Label6_i(), this._Image24_i(), this._Label7_i(), this._Image25_i(), this._Image26_i(), this.imgYilingqu1_i(), this.imgYilingqu2_i(), this.imgYilingqu3_i(), this.imgYilingqu4_i(), this.imgYilingqu5_i(), this.imgYilingqu6_i(), this.imgYilingqu7_i(), this.imgJinri2_i(), this.imgJinri1_i(), this.imgJinri4_i(), this.imgJinri5_i(), this.imgJinri6_i(), this.imgJinri7_i(), this.imgJinri3_i(), this._Image27_i(), this._Image28_i(), this.btnLingqu_i(), this.btnGuanbi_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(67, 727, 4, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_21";
        t.width = 553;
        t.x = 43.5;
        t.y = -66.5;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_27";
        t.x = 97;
        t.y = 55;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_27";
        t.x = 256;
        t.y = 55;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_27";
        t.x = 410;
        t.y = 55;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_27";
        t.x = 97;
        t.y = 212;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_27";
        t.x = 256;
        t.y = 212;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_27";
        t.x = 410;
        t.y = 212;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.height = 114;
        t.scale9Grid = new egret.Rectangle(64, 52, 0, 0);
        t.source = "play_json.zmj_frame_27";
        t.width = 228;
        t.x = 204;
        t.y = 386;
        return t;
    };
    _proto.btnSure_i = function() {
        var t = new eui.Group();
        this.btnSure = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 78;
        t.width = 184;
        t.x = 226;
        t.y = 533;
        t.elementsContent = [this._Image10_i(), this._Image11_i(), this._Image12_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        t.x = 1;
        t.y = 0;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_48";
        t.x = 49.5;
        t.y = 20.5;
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 15;
        t.y = 26;
        return t;
    };
    _proto.imgJrbg7_i = function() {
        var t = new eui.Image();
        this.imgJrbg7 = t;
        t.source = "play_json.zmj_frame_29";
        t.x = 206;
        t.y = 386;
        return t;
    };
    _proto.imgJrbg2_i = function() {
        var t = new eui.Image();
        this.imgJrbg2 = t;
        t.source = "play_json.zmj_frame_31";
        t.x = 259;
        t.y = 55;
        return t;
    };
    _proto.imgJrbg3_i = function() {
        var t = new eui.Image();
        this.imgJrbg3 = t;
        t.source = "play_json.zmj_frame_31";
        t.x = 412;
        t.y = 53.5;
        return t;
    };
    _proto.imgJrbg4_i = function() {
        var t = new eui.Image();
        this.imgJrbg4 = t;
        t.source = "play_json.zmj_frame_31";
        t.x = 98;
        t.y = 212;
        return t;
    };
    _proto.imgJrbg5_i = function() {
        var t = new eui.Image();
        this.imgJrbg5 = t;
        t.source = "play_json.zmj_frame_31";
        t.x = 259;
        t.y = 214;
        return t;
    };
    _proto.imgJrbg6_i = function() {
        var t = new eui.Image();
        this.imgJrbg6 = t;
        t.source = "play_json.zmj_frame_31";
        t.x = 409;
        t.y = 214;
        return t;
    };
    _proto.imgJrbg1_i = function() {
        var t = new eui.Image();
        this.imgJrbg1 = t;
        t.source = "play_json.zmj_frame_31";
        t.x = 99;
        t.y = 53.5;
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_61";
        t.x = 139;
        t.y = 17;
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_62";
        t.x = 293.5;
        t.y = 17;
        return t;
    };
    _proto._Image15_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_63";
        t.x = 447.5;
        t.y = 17;
        return t;
    };
    _proto._Image16_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_64";
        t.x = 134.5;
        t.y = 180;
        return t;
    };
    _proto._Image17_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_65";
        t.x = 293.5;
        t.y = 180;
        return t;
    };
    _proto._Image18_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_66";
        t.x = 447.5;
        t.y = 180;
        return t;
    };
    _proto._Image19_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_67";
        t.x = 287;
        t.y = 350;
        return t;
    };
    _proto._Image20_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_01";
        t.x = 136;
        t.y = 77;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "x50";
        t.x = 142.5;
        t.y = 133;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "x50";
        t.x = 310;
        t.y = 133;
        return t;
    };
    _proto._Label3_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "x70";
        t.x = 148.5;
        t.y = 289;
        return t;
    };
    _proto._Image21_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_01";
        t.x = 448.5;
        t.y = 77;
        return t;
    };
    _proto._Label4_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "x60";
        t.x = 455;
        t.y = 133;
        return t;
    };
    _proto._Image22_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_01";
        t.x = 296.5;
        t.y = 235.5;
        return t;
    };
    _proto._Label5_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "x80";
        t.x = 295;
        t.y = 289;
        return t;
    };
    _proto._Image23_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_01";
        t.x = 448.5;
        t.y = 235.5;
        return t;
    };
    _proto._Label6_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "x90";
        t.x = 455.5;
        t.y = 289;
        return t;
    };
    _proto._Image24_i = function() {
        var t = new eui.Image();
        t.scaleX = 2;
        t.scaleY = 2;
        t.source = "play_json.zmj_icon_37";
        t.x = 298;
        t.y = 416;
        return t;
    };
    _proto._Label7_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "x5";
        t.x = 303;
        t.y = 461;
        return t;
    };
    _proto._Image25_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_01";
        t.x = 291.4;
        t.y = 80.8;
        return t;
    };
    _proto._Image26_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_01";
        t.x = 132;
        t.y = 237;
        return t;
    };
    _proto.imgYilingqu1_i = function() {
        var t = new eui.Image();
        this.imgYilingqu1 = t;
        t.source = "play_json.zmj_icon_27";
        t.x = 115.5;
        t.y = 83.5;
        return t;
    };
    _proto.imgYilingqu2_i = function() {
        var t = new eui.Image();
        this.imgYilingqu2 = t;
        t.source = "play_json.zmj_icon_27";
        t.x = 272;
        t.y = 88;
        return t;
    };
    _proto.imgYilingqu3_i = function() {
        var t = new eui.Image();
        this.imgYilingqu3 = t;
        t.source = "play_json.zmj_icon_27";
        t.x = 433;
        t.y = 83.5;
        return t;
    };
    _proto.imgYilingqu4_i = function() {
        var t = new eui.Image();
        this.imgYilingqu4 = t;
        t.source = "play_json.zmj_icon_27";
        t.x = 115.5;
        t.y = 241.5;
        return t;
    };
    _proto.imgYilingqu5_i = function() {
        var t = new eui.Image();
        this.imgYilingqu5 = t;
        t.source = "play_json.zmj_icon_27";
        t.x = 274.5;
        t.y = 244.5;
        return t;
    };
    _proto.imgYilingqu6_i = function() {
        var t = new eui.Image();
        this.imgYilingqu6 = t;
        t.source = "play_json.zmj_icon_27";
        t.x = 432;
        t.y = 241.5;
        return t;
    };
    _proto.imgYilingqu7_i = function() {
        var t = new eui.Image();
        this.imgYilingqu7 = t;
        t.source = "play_json.zmj_icon_27";
        t.visible = false;
        t.x = 271;
        t.y = 418.5;
        return t;
    };
    _proto.imgJinri2_i = function() {
        var t = new eui.Image();
        this.imgJinri2 = t;
        t.source = "play_json.zmj_icon_28";
        t.x = 256.5;
        t.y = 56;
        return t;
    };
    _proto.imgJinri1_i = function() {
        var t = new eui.Image();
        this.imgJinri1 = t;
        t.source = "play_json.zmj_icon_28";
        t.x = 97;
        t.y = 53.5;
        return t;
    };
    _proto.imgJinri4_i = function() {
        var t = new eui.Image();
        this.imgJinri4 = t;
        t.source = "play_json.zmj_icon_28";
        t.x = 97;
        t.y = 212;
        return t;
    };
    _proto.imgJinri5_i = function() {
        var t = new eui.Image();
        this.imgJinri5 = t;
        t.source = "play_json.zmj_icon_28";
        t.x = 256;
        t.y = 214;
        return t;
    };
    _proto.imgJinri6_i = function() {
        var t = new eui.Image();
        this.imgJinri6 = t;
        t.source = "play_json.zmj_icon_28";
        t.x = 412.5;
        t.y = 214;
        return t;
    };
    _proto.imgJinri7_i = function() {
        var t = new eui.Image();
        this.imgJinri7 = t;
        t.source = "play_json.zmj_icon_28";
        t.x = 206;
        t.y = 386;
        return t;
    };
    _proto.imgJinri3_i = function() {
        var t = new eui.Image();
        this.imgJinri3 = t;
        t.source = "play_json.zmj_icon_28";
        t.x = 412.5;
        t.y = 56.5;
        return t;
    };
    _proto._Image27_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_05";
        t.x = 153;
        t.y = -110;
        return t;
    };
    _proto._Image28_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_60";
        t.x = 225;
        t.y = -89;
        return t;
    };
    _proto.btnLingqu_i = function() {
        var t = new eui.Group();
        this.btnLingqu = t;
        t.anchorOffsetX = 0;
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 333;
        t.elementsContent = [this.txtLingqu_i()];
        return t;
    };
    _proto.txtLingqu_i = function() {
        var t = new eui.Label();
        this.txtLingqu = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.strokeColor = 0xff921c;
        t.text = "Receive";
        t.textColor = 0xe8e8e8;
        t.type = "underline:true";
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 67;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 76;
        t.x = 525.6;
        t.y = -97.76;
        t.elementsContent = [this._Image29_i()];
        return t;
    };
    _proto._Image29_i = function() {
        var t = new eui.Image();
        t.alpha = 1;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 0;
        t.y = 4;
        return t;
    };
    _proto.group_ad1_i = function() {
        var t = new eui.Group();
        this.group_ad1 = t;
        t.height = 144;
        t.left = 0;
        t.verticalCenter = 227;
        t.width = 144;
        return t;
    };
    _proto.group_ad2_i = function() {
        var t = new eui.Group();
        this.group_ad2 = t;
        t.height = 144;
        t.right = 0;
        t.verticalCenter = 227;
        t.width = 144;
        return t;
    };
    return QiandaoSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/RankCellSkin.exml'] = window.RankCellSkin = (function(_super) {
    __extends(RankCellSkin, _super);

    function RankCellSkin() {
        _super.call(this);
        this.skinParts = ["imgRankIcon", "lbRankPos", "imgHead", "grpHead", "lbNick", "lbRankScore", "grpCell"];

        this.elementsContent = [this.grpCell_i()];
    }
    var _proto = RankCellSkin.prototype;

    _proto.grpCell_i = function() {
        var t = new eui.Group();
        this.grpCell = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.x = 0;
        t.y = 0;
        t.elementsContent = [this._Image1_i(), this.imgRankIcon_i(), this.lbRankPos_i(), this.grpHead_i(), this.lbNick_i(), this.lbRankScore_i()];
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.height = 77;
        t.scale9Grid = new egret.Rectangle(87, 39, 0, 0);
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.imgRankIcon_i = function() {
        var t = new eui.Image();
        this.imgRankIcon = t;
        t.source = "play_json.zmj_icon_07";
        t.x = 12.03;
        t.y = 7.99;
        return t;
    };
    _proto.lbRankPos_i = function() {
        var t = new eui.Label();
        this.lbRankPos = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 32;
        t.text = "1";
        t.textAlign = "center";
        t.textColor = 0xffffff;
        t.width = 46;
        t.x = 17.7;
        t.y = 20.71;
        return t;
    };
    _proto.grpHead_i = function() {
        var t = new eui.Group();
        this.grpHead = t;
        t.x = 76.54;
        t.y = 2.69;
        t.elementsContent = [this._Image2_i(), this.imgHead_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 68;
        t.scale9Grid = new egret.Rectangle(10, 10, 0, 0);
        t.source = "play_json.zmj_frame_07";
        t.width = 68;
        return t;
    };
    _proto.imgHead_i = function() {
        var t = new eui.Image();
        this.imgHead = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 72;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 72;
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.lbNick_i = function() {
        var t = new eui.Label();
        this.lbNick = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "名字名字名字";
        t.textColor = 0xffffff;
        t.x = 162.35;
        t.y = 25.69;
        return t;
    };
    _proto.lbRankScore_i = function() {
        var t = new eui.Label();
        this.lbRankScore = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "999";
        t.textAlign = "center";
        t.textColor = 0xffffff;
        t.width = 120;
        t.x = 317.84;
        t.y = 26.68;
        return t;
    };
    return RankCellSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/RedPackOpenSkin.exml'] = window.RedPackOpenSkin = (function(_super) {
    __extends(RedPackOpenSkin, _super);

    function RedPackOpenSkin() {
        _super.call(this);
        this.skinParts = ["btnOpen", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = RedPackOpenSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = -4;
        t.height = 1136;
        t.left = 0;
        t.right = 2;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        t.width = 640;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.verticalCenter = 0;
        t.width = 640;
        t.elementsContent = [this._Image2_i(), this.btnOpen_i(), this.btnGuanbi_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0;
        t.source = "play_json.0111";
        t.verticalCenter = 0;
        return t;
    };
    _proto.btnOpen_i = function() {
        var t = new eui.Group();
        this.btnOpen = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 211.09;
        t.horizontalCenter = 7;
        t.verticalCenter = 38.5;
        t.width = 212.12;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 62;
        t.width = 66;
        t.x = 481;
        t.y = 259;
        return t;
    };
    return RedPackOpenSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/RedPackSkin.exml'] = window.RedPackSkin = (function(_super) {
    __extends(RedPackSkin, _super);

    function RedPackSkin() {
        _super.call(this);
        this.skinParts = ["txtYue", "grpYue", "txtHuode", "grpHuode", "btnTixian", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = RedPackSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = -2;
        t.height = 1136;
        t.left = 0;
        t.right = 2;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = -2;
        t.touchEnabled = true;
        t.width = 640;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.verticalCenter = 0;
        t.width = 640;
        t.elementsContent = [this._Image2_i(), this.grpYue_i(), this.grpHuode_i(), this.btnTixian_i(), this.btnGuanbi_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0;
        t.source = "play_json.hongbao2";
        t.verticalCenter = 0;
        return t;
    };
    _proto.grpYue_i = function() {
        var t = new eui.Group();
        this.grpYue = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 74;
        t.width = 194;
        t.x = 231.5;
        t.y = 397.83;
        t.elementsContent = [this._Image3_i(), this.txtYue_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.hongbao1";
        t.x = 13.46999999999997;
        t.y = -3.0299999999999727;
        return t;
    };
    _proto.txtYue_i = function() {
        var t = new eui.Label();
        this.txtYue = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 30;
        t.text = "0.00元";
        t.textAlign = "left";
        t.textColor = 0xd60f3b;
        t.x = 90.12;
        t.y = -1.6;
        return t;
    };
    _proto.grpHuode_i = function() {
        var t = new eui.Group();
        this.grpHuode = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.visible = false;
        t.x = 264.5;
        t.y = 470;
        t.elementsContent = [this.txtHuode_i(), this._Label1_i()];
        return t;
    };
    _proto.txtHuode_i = function() {
        var t = new eui.Label();
        this.txtHuode = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 0;
        t.size = 52;
        t.text = "2元";
        t.textColor = 0xd60f3b;
        t.y = -4;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.horizontalCenter = 0;
        t.size = 23;
        t.text = "已存入余额";
        t.textColor = 0x945d33;
        t.y = 72;
        return t;
    };
    _proto.btnTixian_i = function() {
        var t = new eui.Group();
        this.btnTixian = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 72;
        t.width = 132;
        t.x = 262.5;
        t.y = 689;
        t.elementsContent = [this._Image4_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.tixian";
        t.x = 10;
        t.y = 8;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 50;
        t.width = 45.45;
        t.x = 492;
        t.y = 264;
        return t;
    };
    return RedPackSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/SuipianbuzuSkin.exml'] = window.SuipianbuzuSkin = (function(_super) {
    __extends(SuipianbuzuSkin, _super);

    function SuipianbuzuSkin() {
        _super.call(this);
        this.skinParts = ["txtSuipianCnt", "txtZuanshiCnt", "btnGoumai", "btnMianfei", "btnGuanbi"];

        this.height = 1130;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = SuipianbuzuSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 554;
        t.horizontalCenter = 5;
        t.verticalCenter = -53;
        t.width = 562;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this.txtSuipianCnt_i(), this._Label1_i(), this._Image6_i(), this.txtZuanshiCnt_i(), this.btnGoumai_i(), this.btnMianfei_i(), this._Image12_i(), this._Image13_i(), this._Label4_i(), this.btnGuanbi_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0.5;
        t.scale9Grid = new egret.Rectangle(89, 327, 1, 0);
        t.source = "play_json.zmj_frame_26";
        t.verticalCenter = 0.5;
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 112;
        t.y = -22.5;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_30";
        t.x = 116.59;
        t.y = 45.04;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.height = 86;
        t.scale9Grid = new egret.Rectangle(79, 36, 0, 0);
        t.source = "play_json.zmj_frame_08";
        t.width = 443;
        t.x = 60;
        t.y = 312;
        return t;
    };
    _proto.txtSuipianCnt_i = function() {
        var t = new eui.Label();
        this.txtSuipianCnt = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.text = "x100";
        t.x = 308.56;
        t.y = 190;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Arial";
        t.text = "need:";
        t.x = 65.21;
        t.y = 449.36;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.zmj_icon_01";
        t.x = 139.64;
        t.y = 449.8;
        return t;
    };
    _proto.txtZuanshiCnt_i = function() {
        var t = new eui.Label();
        this.txtZuanshiCnt = t;
        t.text = "200";
        t.x = 181.99;
        t.y = 449.9;
        return t;
    };
    _proto.btnGoumai_i = function() {
        var t = new eui.Group();
        this.btnGoumai = t;
        t.anchorOffsetX = 90;
        t.anchorOffsetY = 36;
        t.height = 65.33;
        t.x = 374.73;
        t.y = 469.93;
        t.elementsContent = [this._Image7_i(), this._Image8_i(), this._Image9_i(), this._Label2_i(), this._Label3_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = 0.71;
        t.y = -6.84;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 49.63;
        t.source = "play_json.zmj_font_42";
        t.width = 82.24;
        t.x = 50.59;
        t.y = 9.47;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.zmj_icon_01";
        t.visible = false;
        t.x = 30.95;
        t.y = 20.06;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 25;
        t.stroke = 2;
        t.strokeColor = 0x9a3c1a;
        t.text = "50";
        t.visible = false;
        t.x = 70.01;
        t.y = 21.78;
        return t;
    };
    _proto._Label3_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 36;
        t.text = "购买";
        t.visible = false;
        t.x = 54.15;
        t.y = 12.97;
        return t;
    };
    _proto.btnMianfei_i = function() {
        var t = new eui.Group();
        this.btnMianfei = t;
        t.anchorOffsetY = 0;
        t.height = 65.33;
        t.visible = false;
        t.x = 73.55;
        t.y = 432.56;
        t.elementsContent = [this._Image10_i(), this._Image11_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = -0.65;
        t.y = -6.84;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.mfhd";
        t.x = 33.5;
        t.y = 16.15;
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.source = "play_json.spbz";
        t.x = 168;
        t.y = -11;
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.scaleX = 2;
        t.scaleY = 2;
        t.source = "play_json.zmj_icon_37";
        t.x = 264;
        t.y = 186;
        return t;
    };
    _proto._Label4_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.text = "Tip: Open the lucky chest to get chips！";
        t.x = 74.27;
        t.y = 343;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 484;
        t.y = -17;
        t.elementsContent = [this._Image14_i()];
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.alpha = 1;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        return t;
    };
    return SuipianbuzuSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/TilibuzuSkin.exml'] = window.TilibuzuSkin = (function(_super) {
    __extends(TilibuzuSkin, _super);

    function TilibuzuSkin() {
        _super.call(this);
        this.skinParts = ["txtTiliTime", "btnGuanbi", "btnGoumai", "btnMianfei"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = TilibuzuSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = -4;
        t.height = 1136;
        t.left = 0;
        t.right = 2;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        t.width = 640;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 604;
        t.horizontalCenter = 1;
        t.verticalCenter = -50;
        t.width = 634;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this.txtTiliTime_i(), this.btnGuanbi_i(), this.btnGoumai_i(), this.btnMianfei_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 327;
        t.scale9Grid = new egret.Rectangle(85, 327, 1, 0);
        t.source = "play_json.zmj_frame_22";
        t.width = 553;
        t.x = 40.5;
        t.y = 138.5;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(30, 44, 0, 0);
        t.scaleX = 0.89;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_92";
        t.x = 244;
        t.y = 198;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(30, 44, 0, 0);
        t.scaleX = 0.89;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_24";
        t.width = 144;
        t.x = 251.92;
        t.y = 264.5;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_36";
        t.x = 260.21;
        t.y = 266;
        return t;
    };
    _proto.txtTiliTime_i = function() {
        var t = new eui.Label();
        this.txtTiliTime = t;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 22;
        t.stroke = 2;
        t.strokeColor = 0x0F1C3F;
        t.text = "";
        t.x = 312.88;
        t.y = 278;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 44;
        t.anchorOffsetY = 42;
        t.horizontalCenter = 242;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -146;
        t.width = 88;
        t.x = 515;
        t.y = 113;
        t.elementsContent = [this._Image6_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 5.5;
        t.y = 6;
        return t;
    };
    _proto.btnGoumai_i = function() {
        var t = new eui.Group();
        this.btnGoumai = t;
        t.anchorOffsetX = 90;
        t.anchorOffsetY = 32;
        t.height = 65.33;
        t.x = 202.84;
        t.y = 373.48;
        t.elementsContent = [this._Image7_i(), this._Image8_i(), this._Image9_i(), this._Label1_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_04";
        t.x = 0.71;
        t.y = -6.84;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_42";
        t.x = 108.21;
        t.y = 17.61;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.zmj_icon_01";
        t.x = 21.95;
        t.y = 19.06;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 25;
        t.stroke = 2;
        t.strokeColor = 0x9A3C1A;
        t.text = "200";
        t.x = 61.01;
        t.y = 21.78;
        return t;
    };
    _proto.btnMianfei_i = function() {
        var t = new eui.Group();
        this.btnMianfei = t;
        t.anchorOffsetX = 89;
        t.anchorOffsetY = 32;
        t.height = 65.33;
        t.x = 427.84;
        t.y = 373.48;
        t.elementsContent = [this._Image10_i(), this._Image11_i(), this._Image12_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_buttom_05";
        t.x = -0.65;
        t.y = -6.84;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.mfhd";
        t.x = 53.5;
        t.y = 14.15;
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 19;
        t.y = 18;
        return t;
    };
    return TilibuzuSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/ZailaiyifenSkin.exml'] = window.ZailaiyifenSkin = (function(_super) {
    __extends(ZailaiyifenSkin, _super);

    function ZailaiyifenSkin() {
        _super.call(this);
        this.skinParts = ["btnLingqu", "imgWupin1", "imgWupin2", "imgWupin3", "imgWupin4", "txtNum", "txtCancel", "btnCancel"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i()];
    }
    var _proto = ZailaiyifenSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = -4;
        t.height = 1136;
        t.left = 0;
        t.right = 2;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        t.width = 640;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 604;
        t.horizontalCenter = 1;
        t.verticalCenter = -50;
        t.width = 634;
        t.elementsContent = [this._Image2_i(), this.btnLingqu_i(), this._Image6_i(), this._Image7_i(), this.imgWupin1_i(), this.imgWupin2_i(), this.imgWupin3_i(), this.imgWupin4_i(), this.txtNum_i(), this.btnCancel_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 327;
        t.scale9Grid = new egret.Rectangle(85, 327, 1, 0);
        t.source = "play_json.zmj_frame_22";
        t.width = 553;
        t.x = 40.5;
        t.y = 138.5;
        return t;
    };
    _proto.btnLingqu_i = function() {
        var t = new eui.Group();
        this.btnLingqu = t;
        t.anchorOffsetX = 90;
        t.anchorOffsetY = 45;
        t.height = 90;
        t.width = 179;
        t.x = 317.5;
        t.y = 393.5;
        t.elementsContent = [this._Image3_i(), this._Image4_i(), this._Image5_i()];
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        t.x = -1.5;
        t.y = 6;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_68";
        t.x = 44.33;
        t.y = 25.5;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "video_png";
        t.x = 11;
        t.y = 31;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 156.5;
        t.y = 94;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zlyf";
        t.x = 219.5;
        t.y = 99;
        return t;
    };
    _proto.imgWupin1_i = function() {
        var t = new eui.Image();
        this.imgWupin1 = t;
        t.source = "play_json.zmj_icon_01";
        t.x = 259.38;
        t.y = 246;
        return t;
    };
    _proto.imgWupin2_i = function() {
        var t = new eui.Image();
        this.imgWupin2 = t;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.zmj_icon_24";
        t.x = 254.38;
        t.y = 230;
        return t;
    };
    _proto.imgWupin3_i = function() {
        var t = new eui.Image();
        this.imgWupin3 = t;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "play_json.zmj_icon_25";
        t.x = 238.38;
        t.y = 218;
        return t;
    };
    _proto.imgWupin4_i = function() {
        var t = new eui.Image();
        this.imgWupin4 = t;
        t.scaleX = 2;
        t.scaleY = 2;
        t.source = "play_json.zmj_icon_37";
        t.x = 279.28;
        t.y = 248.5;
        return t;
    };
    _proto.txtNum_i = function() {
        var t = new eui.Label();
        this.txtNum = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.text = "x 1";
        t.x = 327.71;
        t.y = 251.5;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.anchorOffsetX = 0;
        t.horizontalCenter = 2;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 177;
        t.elementsContent = [this.txtCancel_i()];
        return t;
    };
    _proto.txtCancel_i = function() {
        var t = new eui.Label();
        this.txtCancel = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.strokeColor = 0xff921c;
        t.text = "狠心放弃";
        t.textColor = 0xe8e8e8;
        t.type = "underline:true";
        return t;
    };
    return ZailaiyifenSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/ZmHomePageSkin.exml'] = window.ZmHomePageSkin = (function(_super) {
    __extends(ZmHomePageSkin, _super);

    function ZmHomePageSkin() {
        _super.call(this);
        this.skinParts = ["anim1", "animYd", "txtDiamond", "txtTili", "txtTiliTime", "grpTop", "btnStart", "btnRank", "imgPifuRedDot", "btnUserSkin", "btnSet", "btnShare", "btnChest", "grpYindao", "imgZuanshiRedDot", "btnLingquuanshi", "txtYue", "btnRedPack", "group_ad_center", "group_adLike", "imgQiandaoRedDot", "btnQiandao", "group_ad", "img_tousu2"];

        this.height = 1136;
        this.width = 640;
        this.anim1_i();
        this.animYd_i();
        this.elementsContent = [this._Image1_i(), this.grpTop_i(), this._Group4_i(), this._Group5_i(), this.group_ad_i(), this.img_tousu2_i(), this._Image26_i()];

        eui.Binding.$bindProperties(this, ["btnLingquuanshi"], [0], this._TweenItem1, "target");
        eui.Binding.$bindProperties(this, [0], [], this._Object1, "rotation");
        eui.Binding.$bindProperties(this, [-15], [], this._Object2, "rotation");
        eui.Binding.$bindProperties(this, [15], [], this._Object3, "rotation");
        eui.Binding.$bindProperties(this, [-15], [], this._Object4, "rotation");
        eui.Binding.$bindProperties(this, [15], [], this._Object5, "rotation");
        eui.Binding.$bindProperties(this, [0], [], this._Object6, "rotation");
        eui.Binding.$bindProperties(this, [0], [], this._Object7, "rotation");
        eui.Binding.$bindProperties(this, ["grpYindao"], [0], this._TweenItem2, "target");
        eui.Binding.$bindProperties(this, [20], [], this._Object8, "x");
        eui.Binding.$bindProperties(this, [0], [], this._Object9, "x");
        eui.Binding.$bindProperties(this, [20], [], this._Object10, "x");
        eui.Binding.$bindProperties(this, [0], [], this._Object11, "x");
    }
    var _proto = ZmHomePageSkin.prototype;

    _proto.anim1_i = function() {
        var t = new egret.tween.TweenGroup();
        this.anim1 = t;
        t.items = [this._TweenItem1_i()];
        return t;
    };
    _proto._TweenItem1_i = function() {
        var t = new egret.tween.TweenItem();
        this._TweenItem1 = t;
        t.paths = [this._Set1_i(), this._To1_i(), this._To2_i(), this._To3_i(), this._To4_i(), this._To5_i(), this._To6_i()];
        return t;
    };
    _proto._Set1_i = function() {
        var t = new egret.tween.Set();
        t.props = this._Object1_i();
        return t;
    };
    _proto._Object1_i = function() {
        var t = {};
        this._Object1 = t;
        return t;
    };
    _proto._To1_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object2_i();
        return t;
    };
    _proto._Object2_i = function() {
        var t = {};
        this._Object2 = t;
        return t;
    };
    _proto._To2_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object3_i();
        return t;
    };
    _proto._Object3_i = function() {
        var t = {};
        this._Object3 = t;
        return t;
    };
    _proto._To3_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object4_i();
        return t;
    };
    _proto._Object4_i = function() {
        var t = {};
        this._Object4 = t;
        return t;
    };
    _proto._To4_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object5_i();
        return t;
    };
    _proto._Object5_i = function() {
        var t = {};
        this._Object5 = t;
        return t;
    };
    _proto._To5_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object6_i();
        return t;
    };
    _proto._Object6_i = function() {
        var t = {};
        this._Object6 = t;
        return t;
    };
    _proto._To6_i = function() {
        var t = new egret.tween.To();
        t.duration = 650;
        t.props = this._Object7_i();
        return t;
    };
    _proto._Object7_i = function() {
        var t = {};
        this._Object7 = t;
        return t;
    };
    _proto.animYd_i = function() {
        var t = new egret.tween.TweenGroup();
        this.animYd = t;
        t.items = [this._TweenItem2_i()];
        return t;
    };
    _proto._TweenItem2_i = function() {
        var t = new egret.tween.TweenItem();
        this._TweenItem2 = t;
        t.paths = [this._Set2_i(), this._To7_i(), this._To8_i(), this._To9_i(), this._To10_i(), this._Wait1_i(), this._Set3_i()];
        return t;
    };
    _proto._Set2_i = function() {
        var t = new egret.tween.Set();
        return t;
    };
    _proto._To7_i = function() {
        var t = new egret.tween.To();
        t.duration = 200;
        t.props = this._Object8_i();
        return t;
    };
    _proto._Object8_i = function() {
        var t = {};
        this._Object8 = t;
        return t;
    };
    _proto._To8_i = function() {
        var t = new egret.tween.To();
        t.duration = 200;
        t.props = this._Object9_i();
        return t;
    };
    _proto._Object9_i = function() {
        var t = {};
        this._Object9 = t;
        return t;
    };
    _proto._To9_i = function() {
        var t = new egret.tween.To();
        t.duration = 200;
        t.props = this._Object10_i();
        return t;
    };
    _proto._Object10_i = function() {
        var t = {};
        this._Object10 = t;
        return t;
    };
    _proto._To10_i = function() {
        var t = new egret.tween.To();
        t.duration = 200;
        t.props = this._Object11_i();
        return t;
    };
    _proto._Object11_i = function() {
        var t = {};
        this._Object11 = t;
        return t;
    };
    _proto._Wait1_i = function() {
        var t = new egret.tween.Wait();
        t.duration = 700;
        return t;
    };
    _proto._Set3_i = function() {
        var t = new egret.tween.Set();
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.bottom = 0;
        t.horizontalCenter = 1;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "homeBk_jpg";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto.grpTop_i = function() {
        var t = new eui.Group();
        this.grpTop = t;
        t.horizontalCenter = -227.5;
        t.verticalCenter = -502;
        t.elementsContent = [this._Group1_i(), this._Group2_i()];
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 18.42;
        t.y = 0;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this.txtDiamond_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_01";
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_01";
        t.x = -20.94;
        t.y = 0.79;
        return t;
    };
    _proto.txtDiamond_i = function() {
        var t = new eui.Label();
        this.txtDiamond = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 26;
        t.text = "500";
        t.textAlign = "center";
        t.verticalAlign = "middle";
        t.width = 98;
        t.x = 22.43;
        t.y = 10.85;
        return t;
    };
    _proto._Group2_i = function() {
        var t = new eui.Group();
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 18.42;
        t.y = 59.080000000000005;
        t.elementsContent = [this._Image4_i(), this._Image5_i(), this.txtTili_i(), this.txtTiliTime_i()];
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_01";
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_36";
        t.x = -20.94;
        t.y = 0.79;
        return t;
    };
    _proto.txtTili_i = function() {
        var t = new eui.Label();
        this.txtTili = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 26;
        t.text = "1";
        t.textAlign = "right";
        t.textColor = 0xfce302;
        t.verticalAlign = "middle";
        t.width = 40;
        t.x = 25.43;
        t.y = 10.85;
        return t;
    };
    _proto.txtTiliTime_i = function() {
        var t = new eui.Label();
        this.txtTiliTime = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 26;
        t.text = "/5";
        t.textAlign = "center";
        t.textColor = 0xffffff;
        t.verticalAlign = "middle";
        t.width = 98;
        t.x = 32.43;
        t.y = 10.85;
        return t;
    };
    _proto._Group4_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 809.33;
        t.horizontalCenter = 0;
        t.verticalCenter = 0;
        t.width = 640;
        t.elementsContent = [this.btnStart_i(), this.btnRank_i(), this.btnUserSkin_i(), this.btnSet_i(), this.btnShare_i(), this._Group3_i(), this._Image20_i()];
        return t;
    };
    _proto.btnStart_i = function() {
        var t = new eui.Group();
        this.btnStart = t;
        t.horizontalCenter = -9;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 96;
        t.y = 477;
        t.elementsContent = [this._Image6_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_02";
        return t;
    };
    _proto.btnRank_i = function() {
        var t = new eui.Group();
        this.btnRank = t;
        t.horizontalCenter = -203;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 96;
        t.y = 658;
        t.elementsContent = [this._Image7_i(), this._Image8_i(), this._Image9_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_03";
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_02";
        t.x = 21.94;
        t.y = 23.76;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_72";
        t.x = 15.94;
        t.y = 83.76;
        return t;
    };
    _proto.btnUserSkin_i = function() {
        var t = new eui.Group();
        this.btnUserSkin = t;
        t.anchorOffsetX = 54.55;
        t.anchorOffsetY = 57.58;
        t.horizontalCenter = -59;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 96;
        t.y = 715.58;
        t.elementsContent = [this._Image10_i(), this._Image11_i(), this._Image12_i(), this.imgPifuRedDot_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_03";
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_03";
        t.x = 25.94;
        t.y = 29.76;
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_73";
        t.x = 27.94;
        t.y = 83.76;
        return t;
    };
    _proto.imgPifuRedDot_i = function() {
        var t = new eui.Image();
        this.imgPifuRedDot = t;
        t.height = 20;
        t.scaleX = 1.5;
        t.scaleY = 1.5;
        t.source = "play_json.qsgwz_icon_04";
        t.visible = false;
        t.width = 20;
        t.x = 78.42;
        t.y = -0.23;
        return t;
    };
    _proto.btnSet_i = function() {
        var t = new eui.Group();
        this.btnSet = t;
        t.horizontalCenter = 81;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 96;
        t.y = 658;
        t.elementsContent = [this._Image13_i(), this._Image14_i(), this._Image15_i()];
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_03";
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_04";
        t.x = 25.94;
        t.y = 25.76;
        return t;
    };
    _proto._Image15_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_74";
        t.x = 29.94;
        t.y = 83.76;
        return t;
    };
    _proto.btnShare_i = function() {
        var t = new eui.Group();
        this.btnShare = t;
        t.horizontalCenter = 219;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 96;
        t.y = 658;
        t.elementsContent = [this._Image16_i(), this._Image17_i(), this._Image18_i()];
        return t;
    };
    _proto._Image16_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_03";
        return t;
    };
    _proto._Image17_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_icon_05";
        t.x = 27.94;
        t.y = 31.76;
        return t;
    };
    _proto._Image18_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_75";
        t.x = 27.94;
        t.y = 83.76;
        return t;
    };
    _proto._Group3_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 378.79;
        t.horizontalCenter = 270;
        t.width = 81.82;
        t.y = 19.31;
        t.elementsContent = [this.btnChest_i()];
        return t;
    };
    _proto.btnChest_i = function() {
        var t = new eui.Group();
        this.btnChest = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 104;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 86;
        t.x = -4.209999999999923;
        t.y = -8.66;
        t.elementsContent = [this._Image19_i()];
        return t;
    };
    _proto._Image19_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.xinyunbaoxiang";
        t.x = 2.75;
        t.y = 5.1;
        return t;
    };
    _proto._Image20_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = -17.5;
        t.source = "play_json.LOGO-1";
        t.verticalCenter = -257.165;
        return t;
    };
    _proto._Group5_i = function() {
        var t = new eui.Group();
        t.horizontalCenter = 50;
        t.right = 126;
        t.visible = false;
        t.width = 500;
        t.y = 19.21;
        t.elementsContent = [this.grpYindao_i()];
        return t;
    };
    _proto.grpYindao_i = function() {
        var t = new eui.Group();
        this.grpYindao = t;
        t.x = 0;
        t.y = 0;
        t.elementsContent = [this._Image21_i()];
        return t;
    };
    _proto._Image21_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_32";
        return t;
    };
    _proto.group_ad_i = function() {
        var t = new eui.Group();
        this.group_ad = t;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.touchThrough = true;
        t.verticalCenter = 0;
        t.width = 640;
        t.elementsContent = [this.btnLingquuanshi_i(), this.btnRedPack_i(), this.group_ad_center_i(), this.group_adLike_i(), this.btnQiandao_i()];
        return t;
    };
    _proto.btnLingquuanshi_i = function() {
        var t = new eui.Group();
        this.btnLingquuanshi = t;
        t.anchorOffsetX = 45.45;
        t.anchorOffsetY = 53.03;
        t.height = 106;
        t.horizontalCenter = -76.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 91;
        t.x = 275;
        t.y = 87;
        t.elementsContent = [this._Image22_i(), this.imgZuanshiRedDot_i(), this._Image23_i()];
        return t;
    };
    _proto._Image22_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.lingquzuans";
        t.x = 4.94;
        t.y = 2.1;
        return t;
    };
    _proto.imgZuanshiRedDot_i = function() {
        var t = new eui.Image();
        this.imgZuanshiRedDot = t;
        t.height = 20;
        t.scaleX = 1.5;
        t.scaleY = 1.5;
        t.source = "play_json.qsgwz_icon_04";
        t.visible = false;
        t.width = 20;
        t.x = 50;
        t.y = -7;
        return t;
    };
    _proto._Image23_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.5;
        t.scaleY = 0.5;
        t.source = "video_png";
        t.x = 32.94;
        t.y = 38.5;
        return t;
    };
    _proto.btnRedPack_i = function() {
        var t = new eui.Group();
        this.btnRedPack = t;
        t.anchorOffsetX = 45.45;
        t.anchorOffsetY = 53.03;
        t.height = 106;
        t.horizontalCenter = 118.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.width = 91;
        t.y = 92.98;
        t.elementsContent = [this._Image24_i(), this.txtYue_i()];
        return t;
    };
    _proto._Image24_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 76;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_fuq2";
        t.width = 80;
        t.x = 4.94;
        t.y = 2.1;
        return t;
    };
    _proto.txtYue_i = function() {
        var t = new eui.Label();
        this.txtYue = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.height = 20;
        t.size = 20;
        t.stroke = 2;
        t.strokeColor = 0x330a02;
        t.text = "领奖";
        t.textAlign = "center";
        t.verticalAlign = "justify";
        t.width = 48.67;
        t.x = 17.01;
        t.y = 64.98;
        return t;
    };
    _proto.group_ad_center_i = function() {
        var t = new eui.Group();
        this.group_ad_center = t;
        t.height = 128;
        t.horizontalCenter = -1;
        t.touchThrough = true;
        t.width = 640;
        t.y = 486;
        return t;
    };
    _proto.group_adLike_i = function() {
        var t = new eui.Group();
        this.group_adLike = t;
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.height = 150;
        t.touchThrough = true;
        t.width = 640;
        t.x = 0;
        return t;
    };
    _proto.btnQiandao_i = function() {
        var t = new eui.Group();
        this.btnQiandao = t;
        t.anchorOffsetX = 38;
        t.anchorOffsetY = 49;
        t.height = 100;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 86;
        t.x = 335.8;
        t.y = 85;
        t.elementsContent = [this._Image25_i(), this.imgQiandaoRedDot_i()];
        return t;
    };
    _proto._Image25_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "play_json.mrqiandao";
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.imgQiandaoRedDot_i = function() {
        var t = new eui.Image();
        this.imgQiandaoRedDot = t;
        t.height = 20;
        t.scaleX = 1.5;
        t.scaleY = 1.5;
        t.source = "play_json.qsgwz_icon_04";
        t.visible = false;
        t.width = 20;
        t.x = 50;
        t.y = -7;
        return t;
    };
    _proto.img_tousu2_i = function() {
        var t = new eui.Image();
        this.img_tousu2 = t;
        t.height = 98;
        t.horizontalCenter = -246.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "zmj_buttom_15_png";
        t.verticalCenter = -386;
        t.visible = false;
        t.width = 83;
        return t;
    };
    _proto._Image26_i = function() {
        var t = new eui.Image();
        t.source = "4399_png";
        t.x = 464.29;
        t.y = 1061;
        return t;
    };
    return ZmHomePageSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/ZmPlaySceneSkin.exml'] = window.ZmPlaySceneSkin = (function(_super) {
    __extends(ZmPlaySceneSkin, _super);

    function ZmPlaySceneSkin() {
        _super.call(this);
        this.skinParts = ["animDailingqu", "imgMap", "grpContent", "grpPoints", "imgHead", "grpHead", "grpFriendOutstrip", "imgJiPao", "imgJi", "imgJiBiyan", "imgJizhengyan", "grpJi", "txtLevelUpTip", "txtScoreTip", "imgNice", "imgGreat", "imgPerfect", "txtYue", "btnRedPack", "btnDailingqu", "grpBombEff", "txtBombNum", "btnBomb", "grpHeidongEff", "txtHeidongNum", "btnHeidong", "btnChest", "btnTousu", "imgPropTipBk", "grpPropTip", "imgPropTipBk1", "grpPropTip1", "txtDiamond", "txtTili", "txtTiliTime", "proLevel", "txtScore", "txtLevelScore", "txtLevel", "btnPause", "grpTop", "group_ad", "group_ad1"];

        this.height = 1136;
        this.width = 640;
        this.animDailingqu_i();
        this.elementsContent = [this._Image1_i(), this._Group10_i(), this.grpTop_i(), this.group_ad_i(), this.group_ad1_i(), this._Image40_i()];

        eui.Binding.$bindProperties(this, ["btnDailingqu"], [0], this._TweenItem1, "target");
        eui.Binding.$bindProperties(this, [0], [], this._Object1, "rotation");
        eui.Binding.$bindProperties(this, [-15], [], this._Object2, "rotation");
        eui.Binding.$bindProperties(this, [15], [], this._Object3, "rotation");
        eui.Binding.$bindProperties(this, [-15], [], this._Object4, "rotation");
        eui.Binding.$bindProperties(this, [15], [], this._Object5, "rotation");
        eui.Binding.$bindProperties(this, [0], [], this._Object6, "rotation");
        eui.Binding.$bindProperties(this, [0], [], this._Object7, "rotation");
    }
    var _proto = ZmPlaySceneSkin.prototype;

    _proto.animDailingqu_i = function() {
        var t = new egret.tween.TweenGroup();
        this.animDailingqu = t;
        t.items = [this._TweenItem1_i()];
        return t;
    };
    _proto._TweenItem1_i = function() {
        var t = new egret.tween.TweenItem();
        this._TweenItem1 = t;
        t.paths = [this._Set1_i(), this._To1_i(), this._To2_i(), this._To3_i(), this._To4_i(), this._To5_i(), this._To6_i()];
        return t;
    };
    _proto._Set1_i = function() {
        var t = new egret.tween.Set();
        t.props = this._Object1_i();
        return t;
    };
    _proto._Object1_i = function() {
        var t = {};
        this._Object1 = t;
        return t;
    };
    _proto._To1_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object2_i();
        return t;
    };
    _proto._Object2_i = function() {
        var t = {};
        this._Object2 = t;
        return t;
    };
    _proto._To2_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object3_i();
        return t;
    };
    _proto._Object3_i = function() {
        var t = {};
        this._Object3 = t;
        return t;
    };
    _proto._To3_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object4_i();
        return t;
    };
    _proto._Object4_i = function() {
        var t = {};
        this._Object4 = t;
        return t;
    };
    _proto._To4_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object5_i();
        return t;
    };
    _proto._Object5_i = function() {
        var t = {};
        this._Object5 = t;
        return t;
    };
    _proto._To5_i = function() {
        var t = new egret.tween.To();
        t.duration = 150;
        t.props = this._Object6_i();
        return t;
    };
    _proto._Object6_i = function() {
        var t = {};
        this._Object6 = t;
        return t;
    };
    _proto._To6_i = function() {
        var t = new egret.tween.To();
        t.duration = 650;
        t.props = this._Object7_i();
        return t;
    };
    _proto._Object7_i = function() {
        var t = {};
        this._Object7 = t;
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.bottom = 0;
        t.horizontalCenter = 0;
        t.source = "mapBk_jpg";
        t.top = 0;
        return t;
    };
    _proto._Group10_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.horizontalCenter = 0;
        t.elementsContent = [this._Group7_i(), this._Group8_i(), this.btnRedPack_i(), this.btnDailingqu_i(), this._Group9_i(), this.grpPropTip_i(), this.grpPropTip1_i()];
        return t;
    };
    _proto._Group7_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.elementsContent = [this.imgMap_i(), this.grpContent_i(), this.grpPoints_i(), this._Group2_i(), this.grpFriendOutstrip_i(), this.grpJi_i()];
        return t;
    };
    _proto.imgMap_i = function() {
        var t = new eui.Image();
        this.imgMap = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "map1_png";
        return t;
    };
    _proto.grpContent_i = function() {
        var t = new eui.Group();
        this.grpContent = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 856;
        t.width = 852;
        t.x = 0;
        t.y = 136;
        return t;
    };
    _proto.grpPoints_i = function() {
        var t = new eui.Group();
        this.grpPoints = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.y = 144;
        t.elementsContent = [this._Rect1_i(), this._Rect2_i(), this._Rect3_i(), this._Rect4_i(), this._Rect5_i(), this._Rect6_i(), this._Rect7_i(), this._Rect8_i(), this._Rect9_i(), this._Rect10_i(), this._Rect11_i(), this._Rect12_i(), this._Rect13_i(), this._Rect14_i(), this._Rect15_i(), this._Rect16_i(), this._Rect17_i(), this._Rect18_i(), this._Rect19_i(), this._Rect20_i(), this._Rect21_i(), this._Rect22_i(), this._Rect23_i(), this._Rect24_i(), this._Rect25_i(), this._Rect26_i(), this._Rect27_i(), this._Rect28_i(), this._Rect29_i(), this._Group1_i()];
        return t;
    };
    _proto._Rect1_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.y = 762.56;
        return t;
    };
    _proto._Rect2_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 166;
        t.y = 761.04;
        return t;
    };
    _proto._Rect3_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 275;
        t.y = 751.04;
        return t;
    };
    _proto._Rect4_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 411.86;
        t.y = 718.62;
        return t;
    };
    _proto._Rect5_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 538;
        t.y = 638.56;
        return t;
    };
    _proto._Rect6_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 589;
        t.y = 403;
        return t;
    };
    _proto._Rect7_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 568;
        t.y = 276;
        return t;
    };
    _proto._Rect8_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 401.36;
        t.y = 53.46;
        return t;
    };
    _proto._Rect9_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 295;
        t.y = 33.46;
        return t;
    };
    _proto._Rect10_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 188.01;
        t.y = 53.46;
        return t;
    };
    _proto._Rect11_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 115.35;
        t.y = 123.75;
        return t;
    };
    _proto._Rect12_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 49;
        t.y = 365;
        return t;
    };
    _proto._Rect13_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 85;
        t.y = 572.55;
        return t;
    };
    _proto._Rect14_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 122;
        t.y = 638.56;
        return t;
    };
    _proto._Rect15_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 215;
        t.y = 670.08;
        return t;
    };
    _proto._Rect16_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 335;
        t.y = 658.56;
        return t;
    };
    _proto._Rect17_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 486.33;
        t.y = 562.55;
        return t;
    };
    _proto._Rect18_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 450;
        t.y = 529.23;
        return t;
    };
    _proto._Rect19_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 183;
        t.y = 527.71;
        return t;
    };
    _proto._Rect20_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 142;
        t.y = 467.1;
        return t;
    };
    _proto._Rect21_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 132;
        t.y = 329.7;
        return t;
    };
    _proto._Rect22_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 198.01;
        t.y = 144.39;
        return t;
    };
    _proto._Rect23_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 247;
        t.y = 118.31;
        return t;
    };
    _proto._Rect24_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 315;
        t.y = 113.75;
        return t;
    };
    _proto._Rect25_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 374.04;
        t.y = 138.31;
        return t;
    };
    _proto._Rect26_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 514;
        t.y = 352;
        return t;
    };
    _proto._Rect27_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 486.33;
        t.y = 401.98;
        return t;
    };
    _proto._Rect28_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 402;
        t.y = 283;
        return t;
    };
    _proto._Rect29_i = function() {
        var t = new eui.Rect();
        t.fillColor = 0xff0202;
        t.height = 20;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 20;
        t.x = 364.04;
        t.y = 375;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 200;
        t.visible = false;
        t.width = 200;
        t.x = 170;
        t.y = 232;
        return t;
    };
    _proto._Group2_i = function() {
        var t = new eui.Group();
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 322;
        t.y = 322;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this._Image5_i(), this._Image6_i(), this._Image7_i(), this._BitmapLabel1_i(), this._Image8_i(), this._Image9_i(), this._Image10_i(), this._Image11_i(), this._Image12_i(), this._Image13_i(), this._Image14_i(), this._Image15_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.4;
        t.scaleY = 0.4;
        t.source = "star01_png";
        t.x = 200.39999999999998;
        t.y = 144.39999999999998;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.5;
        t.scaleY = 0.5;
        t.source = "star01_png";
        t.x = 290;
        t.y = 138;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "star01_png";
        t.x = 341.6;
        t.y = 71.60000000000002;
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "star01_png";
        t.x = 267.2;
        t.y = 17.19999999999999;
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.8;
        t.scaleY = 0.8;
        t.source = "star01_png";
        t.x = 182.8;
        t.y = 10.800000000000011;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.9;
        t.scaleY = 0.9;
        t.source = "star01_png";
        t.x = 86.4;
        t.y = 4.399999999999977;
        return t;
    };
    _proto._BitmapLabel1_i = function() {
        var t = new eui.BitmapLabel();
        t.anchorOffsetX = 60;
        t.anchorOffsetY = 50;
        t.font = "score_fnt";
        t.scaleX = 0.5;
        t.scaleY = 0.5;
        t.text = "+5";
        t.x = 86.4;
        t.y = 4.4;
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "star01_png";
        t.x = -12;
        t.y = -2;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "star02_png";
        t.x = -108;
        t.y = -2;
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.9;
        t.scaleY = 0.9;
        t.source = "star02_png";
        t.x = -153.6;
        t.y = -53.599999999999994;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.8;
        t.scaleY = 0.8;
        t.source = "star02_png";
        t.x = -83.2;
        t.y = -103.19999999999999;
        return t;
    };
    _proto._Image12_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.7;
        t.scaleY = 0.7;
        t.source = "star01_png";
        t.x = 19.19999999999999;
        t.y = -96.80000000000001;
        return t;
    };
    _proto._Image13_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.6;
        t.scaleY = 0.6;
        t.source = "star02_png";
        t.x = 113.60000000000002;
        t.y = -90.4;
        return t;
    };
    _proto._Image14_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.5;
        t.scaleY = 0.5;
        t.source = "star03_png";
        t.x = 228;
        t.y = -84;
        return t;
    };
    _proto._Image15_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 64;
        t.anchorOffsetY = 64;
        t.scaleX = 0.4;
        t.scaleY = 0.4;
        t.source = "star03_png";
        t.x = 312.4;
        t.y = -77.6;
        return t;
    };
    _proto.grpFriendOutstrip_i = function() {
        var t = new eui.Group();
        this.grpFriendOutstrip = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.touchEnabled = false;
        t.x = 589.41;
        t.y = 474.93;
        t.elementsContent = [this._Group3_i()];
        return t;
    };
    _proto._Group3_i = function() {
        var t = new eui.Group();
        t.visible = false;
        t.elementsContent = [this.grpHead_i()];
        return t;
    };
    _proto.grpHead_i = function() {
        var t = new eui.Group();
        this.grpHead = t;
        t.scaleX = 0.8;
        t.scaleY = 0.8;
        t.elementsContent = [this.imgHead_i(), this._Label1_i()];
        return t;
    };
    _proto.imgHead_i = function() {
        var t = new eui.Image();
        this.imgHead = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 80;
        t.source = "head_0_jpg";
        t.width = 80;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 26;
        t.stroke = 2;
        t.text = "超越";
        t.x = 13.36;
        t.y = 84.09;
        return t;
    };
    _proto.grpJi_i = function() {
        var t = new eui.Group();
        this.grpJi = t;
        t.rotation = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 436;
        t.y = 548;
        t.elementsContent = [this._Image16_i(), this._Group4_i(), this._Group5_i(), this._Group6_i()];
        return t;
    };
    _proto._Image16_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 72;
        t.anchorOffsetY = 72;
        t.source = "play_json.ji_dianzi";
        return t;
    };
    _proto._Group4_i = function() {
        var t = new eui.Group();
        t.scaleX = 0.9;
        t.scaleY = 0.9;
        t.x = -32;
        t.y = 82;
        t.elementsContent = [this._Image17_i(), this._Label2_i()];
        return t;
    };
    _proto._Image17_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_37";
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.stroke = 2;
        t.strokeColor = 0x0f1c3f;
        t.text = "999";
        t.textAlign = "center";
        t.width = 64;
        t.x = 11;
        t.y = 10;
        return t;
    };
    _proto._Group5_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 72;
        t.anchorOffsetY = 72;
        t.elementsContent = [this.imgJiPao_i(), this.imgJi_i(), this.imgJiBiyan_i(), this.imgJizhengyan_i()];
        return t;
    };
    _proto.imgJiPao_i = function() {
        var t = new eui.Image();
        this.imgJiPao = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.ji_pao";
        t.x = 92;
        t.y = 49;
        return t;
    };
    _proto.imgJi_i = function() {
        var t = new eui.Image();
        this.imgJi = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.ji";
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.imgJiBiyan_i = function() {
        var t = new eui.Image();
        this.imgJiBiyan = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.ji_biyan";
        t.x = 39;
        t.y = 26;
        return t;
    };
    _proto.imgJizhengyan_i = function() {
        var t = new eui.Image();
        this.imgJizhengyan = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.ji_zhengyan";
        t.x = 39;
        t.y = 26;
        return t;
    };
    _proto._Group6_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 152;
        t.anchorOffsetY = 102;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 6;
        t.y = 76;
        t.elementsContent = [this._Image18_i(), this._Label3_i()];
        return t;
    };
    _proto._Image18_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_36";
        return t;
    };
    _proto._Label3_i = function() {
        var t = new eui.Label();
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "在用完这些球之前通关~";
        t.textColor = 0x000000;
        t.x = 26;
        t.y = 26;
        return t;
    };
    _proto._Group8_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.touchEnabled = false;
        t.elementsContent = [this.txtLevelUpTip_i(), this.txtScoreTip_i(), this.imgNice_i(), this.imgGreat_i(), this.imgPerfect_i()];
        return t;
    };
    _proto.txtLevelUpTip_i = function() {
        var t = new eui.Label();
        this.txtLevelUpTip = t;
        t.alpha = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.height = 42;
        t.horizontalCenter = 132.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 42;
        t.stroke = 2;
        t.strokeColor = 0xf95c3b;
        t.text = "难度提升 得分x2";
        t.textAlign = "center";
        t.textColor = 0xf2f2f2;
        t.touchEnabled = false;
        t.y = 460.7;
        return t;
    };
    _proto.txtScoreTip_i = function() {
        var t = new eui.Label();
        this.txtScoreTip = t;
        t.alpha = 0;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.fontFamily = "Microsoft YaHei";
        t.height = 120.79;
        t.horizontalCenter = 138.5;
        t.lineSpacing = 20;
        t.multiline = true;
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 42;
        t.stroke = 2;
        t.strokeColor = 0xf7ab04;
        t.text = "连击\n得分+10";
        t.textAlign = "center";
        t.textColor = 0xfdfaf9;
        t.touchEnabled = false;
        t.width = 234.69;
        t.y = 436.46;
        return t;
    };
    _proto.imgNice_i = function() {
        var t = new eui.Image();
        this.imgNice = t;
        t.alpha = 0;
        t.source = "play_json.zmj_font_78";
        t.touchEnabled = false;
        t.x = 308;
        t.y = 456;
        return t;
    };
    _proto.imgGreat_i = function() {
        var t = new eui.Image();
        this.imgGreat = t;
        t.alpha = 0;
        t.source = "play_json.zmj_font_79";
        t.touchEnabled = false;
        t.x = 276;
        t.y = 456;
        return t;
    };
    _proto.imgPerfect_i = function() {
        var t = new eui.Image();
        this.imgPerfect = t;
        t.alpha = 0;
        t.source = "play_json.zmj_font_80";
        t.touchEnabled = false;
        t.x = 222;
        t.y = 456;
        return t;
    };
    _proto.btnRedPack_i = function() {
        var t = new eui.Group();
        this.btnRedPack = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 212.33;
        t.y = 96.86;
        t.elementsContent = [this._Image19_i(), this.txtYue_i()];
        return t;
    };
    _proto._Image19_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 74.1;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.fud_fuq2";
        t.width = 78;
        return t;
    };
    _proto.txtYue_i = function() {
        var t = new eui.Label();
        this.txtYue = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.height = 20;
        t.size = 18;
        t.stroke = 3;
        t.strokeColor = 0x330a02;
        t.text = "领奖";
        t.textAlign = "center";
        t.verticalAlign = "justify";
        t.width = 50;
        t.x = 12.34;
        t.y = 64.97;
        return t;
    };
    _proto.btnDailingqu_i = function() {
        var t = new eui.Group();
        this.btnDailingqu = t;
        t.anchorOffsetX = 38.67;
        t.anchorOffsetY = 46.67;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 254.04;
        t.y = 122.34;
        return t;
    };
    _proto._Group9_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.visible = false;
        t.x = 106.06;
        t.y = 990.91;
        t.elementsContent = [this._Image20_i(), this.btnBomb_i(), this.btnHeidong_i(), this.btnChest_i(), this.btnTousu_i()];
        return t;
    };
    _proto._Image20_i = function() {
        var t = new eui.Image();
        t.bottom = 0;
        t.scale9Grid = new egret.Rectangle(54, 0, 0, 145);
        t.source = "play_json.zmj_frame_18";
        t.width = 640;
        return t;
    };
    _proto.btnBomb_i = function() {
        var t = new eui.Group();
        this.btnBomb = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 108;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 102;
        t.x = 189.54;
        t.y = 26.090000000000032;
        t.elementsContent = [this._Image21_i(), this.grpBombEff_i(), this._Image22_i(), this._Image23_i(), this._Label4_i(), this.txtBombNum_i()];
        return t;
    };
    _proto._Image21_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "play_json.zmj_frame_19";
        return t;
    };
    _proto.grpBombEff_i = function() {
        var t = new eui.Group();
        this.grpBombEff = t;
        return t;
    };
    _proto._Image22_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "play_json.zmj_icon_15";
        t.x = 15.15;
        return t;
    };
    _proto._Image23_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "play_json.zmj_frame_20";
        t.x = 88.85;
        t.y = -5.2;
        return t;
    };
    _proto._Label4_i = function() {
        var t = new eui.Label();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.height = 24;
        t.horizontalCenter = 1;
        t.size = 24;
        t.stroke = 2;
        t.strokeColor = 0xffffff;
        t.text = "炸弹";
        t.textAlign = "center";
        t.textColor = 0x1994da;
        t.verticalAlign = "middle";
        t.visible = false;
        t.width = 50;
        t.y = 75.59;
        return t;
    };
    _proto.txtBombNum_i = function() {
        var t = new eui.BitmapLabel();
        this.txtBombNum = t;
        t.font = "shuzi_fnt";
        t.text = "2";
        t.textAlign = "center";
        t.width = 30;
        t.x = 89.31;
        t.y = -2.32;
        return t;
    };
    _proto.btnHeidong_i = function() {
        var t = new eui.Group();
        this.btnHeidong = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 108;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 102;
        t.x = 341.58;
        t.y = 26.090000000000032;
        t.elementsContent = [this._Image24_i(), this.grpHeidongEff_i(), this._Image25_i(), this._Image26_i(), this._Label5_i(), this.txtHeidongNum_i()];
        return t;
    };
    _proto._Image24_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_19";
        return t;
    };
    _proto.grpHeidongEff_i = function() {
        var t = new eui.Group();
        this.grpHeidongEff = t;
        return t;
    };
    _proto._Image25_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_16";
        t.x = -6.17;
        t.y = -23.97;
        return t;
    };
    _proto._Image26_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "play_json.zmj_frame_20";
        t.x = 88.85;
        t.y = -5.2;
        return t;
    };
    _proto._Label5_i = function() {
        var t = new eui.Label();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.height = 24;
        t.horizontalCenter = 1;
        t.size = 24;
        t.stroke = 2;
        t.strokeColor = 0xffffff;
        t.text = "黑洞";
        t.textAlign = "center";
        t.textColor = 0x1994da;
        t.verticalAlign = "middle";
        t.visible = false;
        t.width = 50;
        t.y = 75.59;
        return t;
    };
    _proto.txtHeidongNum_i = function() {
        var t = new eui.BitmapLabel();
        this.txtHeidongNum = t;
        t.font = "shuzi_fnt";
        t.text = "2";
        t.textAlign = "center";
        t.width = 30;
        t.x = 89.31;
        t.y = -2.23;
        return t;
    };
    _proto.btnChest_i = function() {
        var t = new eui.Group();
        this.btnChest = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 489.67;
        t.y = 26.09;
        t.elementsContent = [this._Image27_i(), this._Image28_i()];
        return t;
    };
    _proto._Image27_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_19";
        return t;
    };
    _proto._Image28_i = function() {
        var t = new eui.Image();
        t.scaleX = 0.55;
        t.scaleY = 0.55;
        t.source = "play_json.zmj_icon_18";
        t.x = 10.6;
        t.y = 6.05;
        return t;
    };
    _proto.btnTousu_i = function() {
        var t = new eui.Group();
        this.btnTousu = t;
        t.anchorOffsetX = 0;
        t.height = 108;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.width = 104;
        t.x = 501.94000000000005;
        t.y = 22.090000000000032;
        t.elementsContent = [this._Image29_i(), this._Image30_i()];
        return t;
    };
    _proto._Image29_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "zmj_buttom_15_png";
        t.visible = false;
        t.x = 7.39;
        t.y = 13.45;
        return t;
    };
    _proto._Image30_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "play_json.zmj_font_21";
        t.x = 4.73;
        t.y = 88.1;
        return t;
    };
    _proto.grpPropTip_i = function() {
        var t = new eui.Group();
        this.grpPropTip = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.touchEnabled = false;
        t.visible = false;
        t.x = 204;
        t.y = 910;
        t.elementsContent = [this.imgPropTipBk_i(), this._Label6_i()];
        return t;
    };
    _proto.imgPropTipBk_i = function() {
        var t = new eui.Image();
        this.imgPropTipBk = t;
        t.anchorOffsetX = 0;
        t.scale9Grid = new egret.Rectangle(189, 12, 89, 78);
        t.source = "play_json.zmj_frame_35";
        t.width = 410;
        return t;
    };
    _proto._Label6_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "道具用完了！点这里免费获得！";
        t.textColor = 0x000000;
        t.x = 36.36;
        t.y = 25.21;
        return t;
    };
    _proto.grpPropTip1_i = function() {
        var t = new eui.Group();
        this.grpPropTip1 = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.visible = false;
        t.x = 274;
        t.y = 910;
        t.elementsContent = [this.imgPropTipBk1_i(), this._Label7_i()];
        return t;
    };
    _proto.imgPropTipBk1_i = function() {
        var t = new eui.Image();
        this.imgPropTipBk1 = t;
        t.anchorOffsetX = 0;
        t.scale9Grid = new egret.Rectangle(33, 12, 75, 78);
        t.source = "play_json.zmj_frame_35";
        t.width = 410;
        return t;
    };
    _proto._Label7_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "道具用完了！点这里免费获得！";
        t.textColor = 0x000000;
        t.x = 36.36;
        t.y = 25.21;
        return t;
    };
    _proto.grpTop_i = function() {
        var t = new eui.Group();
        this.grpTop = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -86.5;
        t.touchEnabled = false;
        t.verticalCenter = -458.5;
        t.elementsContent = [this._Group11_i(), this._Group12_i(), this._Group13_i(), this.btnPause_i()];
        return t;
    };
    _proto._Group11_i = function() {
        var t = new eui.Group();
        t.scaleX = 0.9;
        t.scaleY = 0.9;
        t.x = 34.82;
        t.y = 5.55;
        t.elementsContent = [this._Image31_i(), this._Image32_i(), this.txtDiamond_i()];
        return t;
    };
    _proto._Image31_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_01";
        return t;
    };
    _proto._Image32_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_01";
        t.x = -25.94;
        t.y = 0.79;
        return t;
    };
    _proto.txtDiamond_i = function() {
        var t = new eui.Label();
        this.txtDiamond = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 26;
        t.text = "500";
        t.textAlign = "center";
        t.verticalAlign = "middle";
        t.width = 98;
        t.x = 22.43;
        t.y = 10.85;
        return t;
    };
    _proto._Group12_i = function() {
        var t = new eui.Group();
        t.scaleX = 0.9;
        t.scaleY = 0.9;
        t.x = 30.32;
        t.y = 56.08;
        t.elementsContent = [this._Image33_i(), this._Image34_i(), this.txtTili_i(), this.txtTiliTime_i()];
        return t;
    };
    _proto._Image33_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_01";
        return t;
    };
    _proto._Image34_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_icon_36";
        t.x = -17.94;
        t.y = 0.79;
        return t;
    };
    _proto.txtTili_i = function() {
        var t = new eui.Label();
        this.txtTili = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 26;
        t.text = "1";
        t.textAlign = "right";
        t.textColor = 0xFCE302;
        t.verticalAlign = "middle";
        t.width = 40;
        t.x = 25.43;
        t.y = 10.85;
        return t;
    };
    _proto.txtTiliTime_i = function() {
        var t = new eui.Label();
        this.txtTiliTime = t;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 26;
        t.text = "/5";
        t.textAlign = "center";
        t.textColor = 0xFFFFFF;
        t.verticalAlign = "middle";
        t.width = 98;
        t.x = 32.43;
        t.y = 10.85;
        return t;
    };
    _proto._Group13_i = function() {
        var t = new eui.Group();
        t.scaleX = 1;
        t.scaleY = 1;
        t.x = 200;
        t.y = 10.12;
        t.elementsContent = [this._Image35_i(), this._Image36_i(), this.proLevel_i(), this.txtScore_i(), this.txtLevelScore_i(), this._Image37_i(), this.txtLevel_i()];
        return t;
    };
    _proto._Image35_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_13";
        return t;
    };
    _proto._Image36_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(27, 5, 0, 30);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_34";
        t.width = 235;
        t.x = 30;
        t.y = 75;
        return t;
    };
    _proto.proLevel_i = function() {
        var t = new eui.ProgressBar();
        this.proLevel = t;
        t.anchorOffsetX = 0;
        t.enabled = true;
        t.height = 15;
        t.skinName = "LevelScrollBarSkin";
        t.value = 0;
        t.width = 208.4;
        t.x = 42.82;
        t.y = 86.61;
        return t;
    };
    _proto.txtScore_i = function() {
        var t = new eui.Label();
        this.txtScore = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.height = 57.27;
        t.size = 44;
        t.text = "0";
        t.textAlign = "center";
        t.verticalAlign = "middle";
        t.width = 224.58;
        t.x = 15;
        t.y = 19;
        return t;
    };
    _proto.txtLevelScore_i = function() {
        var t = new eui.Label();
        this.txtLevelScore = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 22;
        t.stroke = 2;
        t.text = "200";
        t.textAlign = "center";
        t.width = 224.66;
        t.x = 18.1;
        t.y = 82.84;
        return t;
    };
    _proto._Image37_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_33";
        t.x = -7;
        t.y = 63;
        return t;
    };
    _proto.txtLevel_i = function() {
        var t = new eui.Label();
        this.txtLevel = t;
        t.anchorOffsetX = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.stroke = 2;
        t.text = "1";
        t.textAlign = "center";
        t.width = 44;
        t.x = -2.24;
        t.y = 81.17;
        return t;
    };
    _proto.btnPause_i = function() {
        var t = new eui.Group();
        this.btnPause = t;
        t.anchorOffsetX = 0;
        t.height = 108;
        t.scaleX = 0.9;
        t.scaleY = 0.9;
        t.touchEnabled = false;
        t.width = 104;
        t.x = 5.939999999999998;
        t.y = 97.33;
        t.elementsContent = [this._Image38_i(), this._Image39_i()];
        return t;
    };
    _proto._Image38_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "play_json.zmj_buttom_14";
        t.x = 5.86;
        t.y = 11.93;
        return t;
    };
    _proto._Image39_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.source = "play_json.zmj_font_2";
        t.x = 27.07;
        t.y = 90.72;
        return t;
    };
    _proto.group_ad_i = function() {
        var t = new eui.Group();
        this.group_ad = t;
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.height = 178;
        t.horizontalCenter = 0;
        t.visible = false;
        t.width = 640;
        return t;
    };
    _proto.group_ad1_i = function() {
        var t = new eui.Group();
        this.group_ad1 = t;
        t.height = 144;
        t.right = 20;
        t.verticalCenter = -458;
        t.visible = false;
        t.width = 144;
        return t;
    };
    _proto._Image40_i = function() {
        var t = new eui.Image();
        t.source = "4399_png";
        t.x = 33;
        t.y = 1047;
        return t;
    };
    return ZmPlaySceneSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/ZmRankSkin.exml'] = window.ZmRankSkin = (function(_super) {
    __extends(ZmRankSkin, _super);

    function ZmRankSkin() {
        _super.call(this);
        this.skinParts = ["btnGuanbi", "grpWorldItems", "imgMyHead", "txtPaiming", "grpWorld", "btnYaoqinghaoyou", "btnFenxiang", "imgHaoyouBtnBkN", "imgHaoyouBtnBkF", "imgHaoyouBtnWzN", "imgHaoyouBtnWzF", "btnHaoyou", "imgQuanfuBtnBkN", "imgQuanfuBtnBkF", "imgQuanfuBtnWzN", "imgQuanfuBtnWzF", "btnQuanfu", "grpHaoyou", "group_ad"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.grpHaoyou_i(), this.group_ad_i()];
    }
    var _proto = ZmRankSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = -2;
        t.right = 2;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 722;
        t.horizontalCenter = -2.5;
        t.verticalCenter = -37;
        t.width = 545;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this._Image4_i(), this.btnGuanbi_i(), this.grpWorld_i(), this.btnYaoqinghaoyou_i(), this.btnFenxiang_i(), this.btnHaoyou_i(), this.btnQuanfu_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 817;
        t.scale9Grid = new egret.Rectangle(69, 727, 0, 0);
        t.source = "play_json.zmj_frame_21";
        t.width = 553;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_frame_05";
        t.x = 116;
        t.y = -26;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.source = "play_json.zmj_font_01";
        t.x = 209;
        t.y = -8.49;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 92;
        t.width = 80;
        t.x = 487.19;
        t.y = -8.35;
        t.elementsContent = [this._Image5_i()];
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_06";
        t.x = 3;
        t.y = 9;
        return t;
    };
    _proto.grpWorld_i = function() {
        var t = new eui.Group();
        this.grpWorld = t;
        t.x = 39.83;
        t.y = 139.33;
        t.elementsContent = [this._Scroller1_i(), this._Image6_i(), this.imgMyHead_i(), this._Image7_i(), this.txtPaiming_i()];
        return t;
    };
    _proto._Scroller1_i = function() {
        var t = new eui.Scroller();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 381.33;
        t.scaleX = 1;
        t.scaleY = 1;
        t.width = 463.99;
        t.x = 8;
        t.y = 0;
        t.viewport = this.grpWorldItems_i();
        return t;
    };
    _proto.grpWorldItems_i = function() {
        var t = new eui.Group();
        this.grpWorldItems = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 346.67;
        t.width = 445.99;
        t.layout = this._VerticalLayout1_i();
        return t;
    };
    _proto._VerticalLayout1_i = function() {
        var t = new eui.VerticalLayout();
        t.gap = 2;
        t.horizontalAlign = "left";
        t.verticalAlign = "top";
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(79, 83, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_10";
        t.width = 449;
        t.x = 4.690000000000012;
        t.y = 390.28999999999996;
        return t;
    };
    _proto.imgMyHead_i = function() {
        var t = new eui.Image();
        this.imgMyHead = t;
        t.height = 68;
        t.scale9Grid = new egret.Rectangle(18, 10, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_09";
        t.width = 68;
        t.x = 31.180000000000007;
        t.y = 397.78999999999996;
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_08";
        t.x = 120.85000000000001;
        t.y = 415.94999999999993;
        return t;
    };
    _proto.txtPaiming_i = function() {
        var t = new eui.Label();
        this.txtPaiming = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 22;
        t.text = "未上榜";
        t.textAlign = "left";
        t.textColor = 0xffcf3c;
        t.x = 253.51;
        t.y = 420.61;
        return t;
    };
    _proto.btnYaoqinghaoyou_i = function() {
        var t = new eui.Group();
        this.btnYaoqinghaoyou = t;
        t.anchorOffsetX = 88;
        t.anchorOffsetY = 50;
        t.height = 88;
        t.width = 177;
        t.x = 274.5;
        t.y = 662.62;
        t.elementsContent = [this._Image8_i(), this._Image9_i()];
        return t;
    };
    _proto._Image8_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_04";
        t.x = -6.1699999999999875;
        t.y = 6.340000000000032;
        return t;
    };
    _proto._Image9_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_23";
        t.x = 22;
        t.y = 29;
        return t;
    };
    _proto.btnFenxiang_i = function() {
        var t = new eui.Group();
        this.btnFenxiang = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 88;
        t.visible = false;
        t.width = 177;
        t.x = 296.99;
        t.y = 611.29;
        t.elementsContent = [this._Image10_i(), this._Image11_i()];
        return t;
    };
    _proto._Image10_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_05";
        t.x = -6.1699999999999875;
        t.y = 6.340000000000032;
        return t;
    };
    _proto._Image11_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_03";
        t.x = 9.5;
        t.y = 27;
        return t;
    };
    _proto.btnHaoyou_i = function() {
        var t = new eui.Group();
        this.btnHaoyou = t;
        t.x = 69;
        t.y = 66;
        t.elementsContent = [this.imgHaoyouBtnBkN_i(), this.imgHaoyouBtnBkF_i(), this.imgHaoyouBtnWzN_i(), this.imgHaoyouBtnWzF_i()];
        return t;
    };
    _proto.imgHaoyouBtnBkN_i = function() {
        var t = new eui.Image();
        this.imgHaoyouBtnBkN = t;
        t.scale9Grid = new egret.Rectangle(45, 62, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_06";
        t.width = 192;
        t.x = -2.1700000000000017;
        t.y = 3.670000000000016;
        return t;
    };
    _proto.imgHaoyouBtnBkF_i = function() {
        var t = new eui.Image();
        this.imgHaoyouBtnBkF = t;
        t.scale9Grid = new egret.Rectangle(53, 68, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_07";
        t.width = 200;
        t.x = -4.480000000000018;
        t.y = -2.6599999999999966;
        return t;
    };
    _proto.imgHaoyouBtnWzN_i = function() {
        var t = new eui.Image();
        this.imgHaoyouBtnWzN = t;
        t.height = 32;
        t.scale9Grid = new egret.Rectangle(45, 62, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_06";
        t.x = 30.83;
        t.y = 15.71;
        return t;
    };
    _proto.imgHaoyouBtnWzF_i = function() {
        var t = new eui.Image();
        this.imgHaoyouBtnWzF = t;
        t.height = 36;
        t.scale9Grid = new egret.Rectangle(45, 62, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_04";
        t.x = 30.83;
        t.y = 12.67;
        return t;
    };
    _proto.btnQuanfu_i = function() {
        var t = new eui.Group();
        this.btnQuanfu = t;
        t.x = 298;
        t.y = 63.96;
        t.elementsContent = [this.imgQuanfuBtnBkN_i(), this.imgQuanfuBtnBkF_i(), this.imgQuanfuBtnWzN_i(), this.imgQuanfuBtnWzF_i()];
        return t;
    };
    _proto.imgQuanfuBtnBkN_i = function() {
        var t = new eui.Image();
        this.imgQuanfuBtnBkN = t;
        t.scale9Grid = new egret.Rectangle(45, 62, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_frame_06";
        t.width = 192;
        t.y = 4.56;
        return t;
    };
    _proto.imgQuanfuBtnBkF_i = function() {
        var t = new eui.Image();
        this.imgQuanfuBtnBkF = t;
        t.scale9Grid = new egret.Rectangle(53, 68, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_buttom_07";
        t.width = 200;
        return t;
    };
    _proto.imgQuanfuBtnWzN_i = function() {
        var t = new eui.Image();
        this.imgQuanfuBtnWzN = t;
        t.height = 32;
        t.scale9Grid = new egret.Rectangle(45, 62, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_07";
        t.x = 33.87;
        t.y = 18.75;
        return t;
    };
    _proto.imgQuanfuBtnWzF_i = function() {
        var t = new eui.Image();
        this.imgQuanfuBtnWzF = t;
        t.height = 36;
        t.scale9Grid = new egret.Rectangle(45, 62, 0, 0);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "play_json.zmj_font_05";
        t.x = 32.35;
        t.y = 15.71;
        return t;
    };
    _proto.grpHaoyou_i = function() {
        var t = new eui.Group();
        this.grpHaoyou = t;
        t.touchEnabled = false;
        return t;
    };
    _proto.group_ad_i = function() {
        var t = new eui.Group();
        this.group_ad = t;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.touchThrough = true;
        t.verticalCenter = 0;
        t.width = 640;
        return t;
    };
    return ZmRankSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/ZmRewardVideoTipSkin.exml'] = window.ZmRewardVideoTipSkin = (function(_super) {
    __extends(ZmRewardVideoTipSkin, _super);

    function ZmRewardVideoTipSkin() {
        _super.call(this);
        this.skinParts = ["imgPlay", "btnSure", "btnCancel", "btnGuanbi"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Image1_i(), this._Group1_i(), this.btnSure_i(), this.btnCancel_i(), this.btnGuanbi_i()];
    }
    var _proto = ZmRewardVideoTipSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.alpha = 0.7;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = -1;
        t.verticalCenter = 3;
        t.elementsContent = [this._Image2_i(), this._Image3_i(), this.imgPlay_i(), this._Image4_i(), this._Label1_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.anchorOffsetY = 0;
        t.height = 494.42;
        t.scale9Grid = new egret.Rectangle(68, 68, 2, 415);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "";
        t.width = 558;
        t.x = 0;
        return t;
    };
    _proto._Image3_i = function() {
        var t = new eui.Image();
        t.source = "shiping_png";
        t.x = 50.79;
        t.y = 80.97;
        return t;
    };
    _proto.imgPlay_i = function() {
        var t = new eui.Image();
        this.imgPlay = t;
        t.source = "icon_bofang_png";
        t.x = 205.06;
        t.y = 172.13;
        return t;
    };
    _proto._Image4_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "img_tcbtdi_png";
        t.x = 72.91;
        t.y = -58.03;
        return t;
    };
    _proto._Label1_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.borderColor = 0x9442d2;
        t.fontFamily = "Microsoft YaHei";
        t.size = 38;
        t.stroke = 2;
        t.strokeColor = 0x9442d2;
        t.text = "观看视频得奖励";
        t.textColor = 0xfffdf8;
        t.x = 141.33;
        t.y = -41.44;
        return t;
    };
    _proto.btnSure_i = function() {
        var t = new eui.Group();
        this.btnSure = t;
        t.horizontalCenter = -1;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 251;
        t.elementsContent = [this._Image5_i(), this._Label2_i()];
        return t;
    };
    _proto._Image5_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(84, 15, 0, 94);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "buttim_yellow_png";
        t.width = 350;
        return t;
    };
    _proto._Label2_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.fontFamily = "Microsoft YaHei";
        t.size = 42;
        t.stroke = 2;
        t.strokeColor = 0xff921c;
        t.text = "播放视频";
        t.x = 92.84;
        t.y = 34.32;
        return t;
    };
    _proto.btnCancel_i = function() {
        var t = new eui.Group();
        this.btnCancel = t;
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = 387;
        t.elementsContent = [this._Image6_i(), this._Label3_i()];
        return t;
    };
    _proto._Image6_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.scale9Grid = new egret.Rectangle(69, 15, 15, 94);
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "bt_fangqi_png";
        t.width = 227.88;
        return t;
    };
    _proto._Label3_i = function() {
        var t = new eui.Label();
        t.bold = true;
        t.borderColor = 0x1ebff3;
        t.fontFamily = "Microsoft YaHei";
        t.size = 42;
        t.stroke = 2;
        t.strokeColor = 0x1ebff3;
        t.text = "放弃";
        t.textColor = 0xfdfffc;
        t.x = 68.6;
        t.y = 34.32;
        return t;
    };
    _proto.btnGuanbi_i = function() {
        var t = new eui.Group();
        this.btnGuanbi = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 251;
        t.scaleX = 1;
        t.scaleY = 1;
        t.verticalCenter = -235.5;
        t.elementsContent = [this._Image7_i()];
        return t;
    };
    _proto._Image7_i = function() {
        var t = new eui.Image();
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "icon_close_png";
        return t;
    };
    return ZmRewardVideoTipSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/ZmUserGuidSkin.exml'] = window.ZmUserGuidSkin = (function(_super) {
    __extends(ZmUserGuidSkin, _super);

    function ZmUserGuidSkin() {
        _super.call(this);
        this.skinParts = ["stepDragAnim", "imgTop", "imgBottom", "grpGuid", "image", "grpStepDrag", "imgTipBk", "txtTip", "grpTip"];

        this.height = 1136;
        this.width = 640;
        this.stepDragAnim_i();
        this.elementsContent = [this.imgTop_i(), this.imgBottom_i(), this.grpGuid_i(), this.grpStepDrag_i(), this.grpTip_i()];

        eui.Binding.$bindProperties(this, ["image"], [0], this._TweenItem1, "target");
        eui.Binding.$bindProperties(this, [140], [], this._Object1, "y");
        eui.Binding.$bindProperties(this, [275.67], [], this._Object2, "x");
        eui.Binding.$bindProperties(this, [140], [], this._Object2, "y");
    }
    var _proto = ZmUserGuidSkin.prototype;

    _proto.stepDragAnim_i = function() {
        var t = new egret.tween.TweenGroup();
        this.stepDragAnim = t;
        t.items = [this._TweenItem1_i()];
        return t;
    };
    _proto._TweenItem1_i = function() {
        var t = new egret.tween.TweenItem();
        this._TweenItem1 = t;
        t.paths = [this._Set1_i(), this._To1_i(), this._Wait1_i(), this._Set2_i()];
        return t;
    };
    _proto._Set1_i = function() {
        var t = new egret.tween.Set();
        t.props = this._Object1_i();
        return t;
    };
    _proto._Object1_i = function() {
        var t = {};
        this._Object1 = t;
        return t;
    };
    _proto._To1_i = function() {
        var t = new egret.tween.To();
        t.duration = 500;
        t.props = this._Object2_i();
        return t;
    };
    _proto._Object2_i = function() {
        var t = {};
        this._Object2 = t;
        return t;
    };
    _proto._Wait1_i = function() {
        var t = new egret.tween.Wait();
        t.duration = 300;
        return t;
    };
    _proto._Set2_i = function() {
        var t = new egret.tween.Set();
        return t;
    };
    _proto.imgTop_i = function() {
        var t = new eui.Image();
        this.imgTop = t;
        t.alpha = 0.7;
        t.anchorOffsetY = 0;
        t.bottom = 437;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        return t;
    };
    _proto.imgBottom_i = function() {
        var t = new eui.Image();
        this.imgBottom = t;
        t.alpha = 0.7;
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 853;
        t.touchEnabled = true;
        return t;
    };
    _proto.grpGuid_i = function() {
        var t = new eui.Group();
        this.grpGuid = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = 0;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.visible = false;
        t.elementsContent = [this._Image1_i()];
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 6.5;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "img_gameui_png";
        t.visible = false;
        t.x = 15;
        t.y = 24.71;
        return t;
    };
    _proto.grpStepDrag_i = function() {
        var t = new eui.Group();
        this.grpStepDrag = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = 239;
        t.height = 233.33;
        t.horizontalCenter = 0;
        t.touchEnabled = false;
        t.visible = false;
        t.width = 638.33;
        t.elementsContent = [this._Image2_i(), this.image_i()];
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.scaleX = -1;
        t.scaleY = 1;
        t.source = "xc_bg_002_png";
        t.touchEnabled = false;
        t.x = 346.67;
        t.y = 122.67;
        return t;
    };
    _proto.image_i = function() {
        var t = new eui.Image();
        this.image = t;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "xc_bg_003_png";
        t.touchEnabled = false;
        t.x = 359.33;
        t.y = 139.33;
        return t;
    };
    _proto.grpTip_i = function() {
        var t = new eui.Group();
        this.grpTip = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.horizontalCenter = 11;
        t.touchEnabled = false;
        t.y = 738.66;
        t.elementsContent = [this.imgTipBk_i(), this.txtTip_i()];
        return t;
    };
    _proto.imgTipBk_i = function() {
        var t = new eui.Image();
        this.imgTipBk = t;
        t.anchorOffsetX = 0;
        t.scale9Grid = new egret.Rectangle(20, 20, 0, 0);
        t.source = "xc_bg_001_png";
        t.touchEnabled = false;
        t.width = 320;
        return t;
    };
    _proto.txtTip_i = function() {
        var t = new eui.Label();
        this.txtTip = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.fontFamily = "Microsoft YaHei";
        t.height = 76;
        t.lineSpacing = 10;
        t.size = 22;
        t.text = "点击道具图标可以获得道具奖励！\n游戏开始之前最多可以获得三个！";
        t.textAlign = "center";
        t.touchEnabled = false;
        t.verticalAlign = "middle";
        t.width = 372;
        t.y = 0;
        return t;
    };
    return ZmUserGuidSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/AlertSkin.exml'] = window.AlertSkin = (function(_super) {
    __extends(AlertSkin, _super);

    function AlertSkin() {
        _super.call(this);
        this.skinParts = ["txt1", "btnClose", "btnOK"];

        this.height = 500;
        this.width = 500;
        this.elementsContent = [this._Image1_i(), this.txt1_i(), this.btnClose_i(), this.btnOK_i()];
    }
    var _proto = AlertSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scale9Grid = new egret.Rectangle(23, 25, 22, 24);
        t.source = "dt_base_frame_png";
        t.top = 0;
        return t;
    };
    _proto.txt1_i = function() {
        var t = new eui.Label();
        this.txt1 = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = 123;
        t.fontFamily = "微软雅黑";
        t.left = 43;
        t.lineSpacing = 10;
        t.multiline = true;
        t.right = 40;
        t.size = 34;
        t.text = "普通文字";
        t.textAlign = "center";
        t.textColor = 0x79777a;
        t.top = 70;
        t.verticalAlign = "middle";
        t.wordWrap = true;
        return t;
    };
    _proto.btnClose_i = function() {
        var t = new eui.Image();
        this.btnClose = t;
        t.source = "dt_base_close_png";
        t.x = 436;
        t.y = 6;
        return t;
    };
    _proto.btnOK_i = function() {
        var t = new eui.Image();
        this.btnOK = t;
        t.source = "dt_base_ok_png";
        t.x = 150;
        t.y = 397;
        return t;
    };
    return AlertSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/BaseLoadingSkin.exml'] = window.BaseLoadingSkin = (function(_super) {
    __extends(BaseLoadingSkin, _super);

    function BaseLoadingSkin() {
        _super.call(this);
        this.skinParts = ["imgProgressBar"];

        this.height = 576;
        this.width = 1024;
        this.elementsContent = [this._Image1_i(), this.imgProgressBar_i(), this._Image2_i()];
    }
    var _proto = BaseLoadingSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.height = 22;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(6, 6, 21, 5);
        t.source = "dt_pre_jd1_png";
        t.width = 472;
        t.y = 441;
        return t;
    };
    _proto.imgProgressBar_i = function() {
        var t = new eui.Image();
        this.imgProgressBar = t;
        t.height = 18;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(5, 6, 21, 4);
        t.source = "dt_pre_jd2_png";
        t.width = 468;
        t.y = 443;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0;
        t.source = "dt_pre_logo_png";
        t.verticalCenter = -16;
        return t;
    };
    return BaseLoadingSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/ConfirmSkin.exml'] = window.ConfirmSkin = (function(_super) {
    __extends(ConfirmSkin, _super);

    function ConfirmSkin() {
        _super.call(this);
        this.skinParts = ["txt1", "btn1", "btn2"];

        this.height = 500;
        this.width = 500;
        this.elementsContent = [this._Image1_i(), this.txt1_i(), this.btn1_i(), this.btn2_i()];
    }
    var _proto = ConfirmSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scale9Grid = new egret.Rectangle(23, 25, 22, 24);
        t.source = "dt_base_frame_png";
        t.top = 0;
        return t;
    };
    _proto.txt1_i = function() {
        var t = new eui.Label();
        this.txt1 = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = 148;
        t.fontFamily = "微软雅黑";
        t.left = 43;
        t.lineSpacing = 10;
        t.multiline = true;
        t.right = 40;
        t.size = 34;
        t.text = "普通文字";
        t.textAlign = "center";
        t.textColor = 0x79777A;
        t.top = 37;
        t.verticalAlign = "middle";
        t.wordWrap = true;
        return t;
    };
    _proto.btn1_i = function() {
        var t = new eui.Image();
        this.btn1 = t;
        t.source = "dt_base_ok_png";
        t.x = 265;
        t.y = 383;
        return t;
    };
    _proto.btn2_i = function() {
        var t = new eui.Image();
        this.btn2 = t;
        t.source = "dt_base_cancel_png";
        t.x = 32;
        t.y = 383;
        return t;
    };
    return ConfirmSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/FullLoadingSkin.exml'] = window.FullLoadingSkin = (function(_super) {
    __extends(FullLoadingSkin, _super);

    function FullLoadingSkin() {
        _super.call(this);
        this.skinParts = ["txtTips", "imgProgressBar"];

        this.height = 576;
        this.width = 1024;
        this.elementsContent = [this._Image1_i(), this.txtTips_i(), this._Image2_i(), this.imgProgressBar_i()];
    }
    var _proto = FullLoadingSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.horizontalCenter = 0;
        t.source = "dt_pre_logo_png";
        t.verticalCenter = -16;
        return t;
    };
    _proto.txtTips_i = function() {
        var t = new eui.Label();
        this.txtTips = t;
        t.fontFamily = "微软雅黑";
        t.horizontalCenter = 0;
        t.size = 20;
        t.text = "Tips";
        t.textAlign = "center";
        t.width = 962;
        t.y = 479;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.height = 22;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(6, 6, 21, 5);
        t.source = "dt_pre_jd1_png";
        t.width = 472;
        t.y = 441;
        return t;
    };
    _proto.imgProgressBar_i = function() {
        var t = new eui.Image();
        this.imgProgressBar = t;
        t.height = 18;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(5, 6, 21, 4);
        t.source = "dt_pre_jd2_png";
        t.width = 468;
        t.y = 443;
        return t;
    };
    return FullLoadingSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/LoadingSkin.exml'] = window.LoadingSkin = (function(_super) {
    __extends(LoadingSkin, _super);

    function LoadingSkin() {
        _super.call(this);
        this.skinParts = ["imgBk", "imgLoading", "txtTitle", "grpView"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Group1_i()];
    }
    var _proto = LoadingSkin.prototype;

    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.top = 0;
        t.touchEnabled = true;
        t.elementsContent = [this.grpView_i()];
        return t;
    };
    _proto.grpView_i = function() {
        var t = new eui.Group();
        this.grpView = t;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.top = 0;
        t.touchEnabled = true;
        t.elementsContent = [this.imgBk_i(), this.imgLoading_i(), this.txtTitle_i()];
        return t;
    };
    _proto.imgBk_i = function() {
        var t = new eui.Image();
        this.imgBk = t;
        t.alpha = 0.5;
        t.bottom = 0;
        t.left = 0;
        t.right = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.source = "backg_black_png";
        t.top = 0;
        t.touchEnabled = true;
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto.imgLoading_i = function() {
        var t = new eui.Image();
        this.imgLoading = t;
        t.anchorOffsetX = 34;
        t.anchorOffsetY = 34;
        t.horizontalCenter = 0;
        t.source = "dt_base_loading_png";
        t.verticalCenter = 0;
        return t;
    };
    _proto.txtTitle_i = function() {
        var t = new eui.Label();
        this.txtTitle = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.fontFamily = "Microsoft YaHei";
        t.height = 106;
        t.horizontalCenter = 3;
        t.strokeColor = 0x232323;
        t.text = "正在登录...";
        t.textAlign = "center";
        t.verticalCenter = 129;
        t.width = 474;
        return t;
    };
    return LoadingSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/PopSkin.exml'] = window.PopSkin = (function(_super) {
    __extends(PopSkin, _super);

    function PopSkin() {
        _super.call(this);
        this.skinParts = ["imgBk", "txt1"];

        this.height = 110;
        this.width = 800;
        this.elementsContent = [this.imgBk_i(), this.txt1_i()];
    }
    var _proto = PopSkin.prototype;

    _proto.imgBk_i = function() {
        var t = new eui.Image();
        this.imgBk = t;
        t.alpha = 0.5;
        t.height = 110;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(19, 19, 0, 0);
        t.source = "xc_bg_001_png";
        t.verticalCenter = 0;
        t.width = 800;
        return t;
    };
    _proto.txt1_i = function() {
        var t = new eui.Label();
        this.txt1 = t;
        t.style = "2";
        t.fontFamily = "微软雅黑";
        t.horizontalCenter = 0;
        t.scaleX = 1;
        t.scaleY = 1;
        t.size = 38;
        t.strokeColor = 0x6d3f25;
        t.text = "";
        t.textAlign = "center";
        t.textColor = 0xF9F0FF;
        t.verticalCenter = 0;
        return t;
    };
    return PopSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/ProLoadingScrollBarSkin.exml'] = window.ProLoadingScrollBarSkin = (function(_super) {
    __extends(ProLoadingScrollBarSkin, _super);

    function ProLoadingScrollBarSkin() {
        _super.call(this);
        this.skinParts = ["thumb"];

        this.minHeight = 8;
        this.minWidth = 20;
        this.elementsContent = [this.thumb_i()];
    }
    var _proto = ProLoadingScrollBarSkin.prototype;

    _proto.thumb_i = function() {
        var t = new eui.Image();
        this.thumb = t;
        t.scale9Grid = new egret.Rectangle(15, 3, 0, 2);
        t.source = "zmj_line1_png";
        t.verticalCenter = 0;
        return t;
    };
    return ProLoadingScrollBarSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/ProLoadingSkin.exml'] = window.ProLoadingSkin = (function(_super) {
    __extends(ProLoadingSkin, _super);

    function ProLoadingSkin() {
        _super.call(this);
        this.skinParts = ["proLoading", "txtLoading"];

        this.height = 1136;
        this.width = 640;
        this.elementsContent = [this._Group1_i()];
    }
    var _proto = ProLoadingSkin.prototype;

    _proto._Group1_i = function() {
        var t = new eui.Group();
        t.bottom = 0;
        t.height = 1136;
        t.horizontalCenter = 0;
        t.width = 640;
        t.elementsContent = [this._Image1_i(), this.proLoading_i(), this.txtLoading_i()];
        return t;
    };
    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.scale9Grid = new egret.Rectangle(25, 4, 0, 26);
        t.source = "zmj_line2_png";
        t.width = 485;
        t.x = 77.5;
        t.y = 950;
        return t;
    };
    _proto.proLoading_i = function() {
        var t = new eui.ProgressBar();
        this.proLoading = t;
        t.skinName = "ProLoadingScrollBarSkin";
        t.value = 0;
        t.x = 80.5;
        t.y = 951.5;
        return t;
    };
    _proto.txtLoading_i = function() {
        var t = new eui.Label();
        this.txtLoading = t;
        t.fontFamily = "Microsoft YaHei";
        t.size = 24;
        t.text = "Loading, please wait...";
        t.textAlign = "center";
        t.width = 600;
        t.x = 20;
        t.y = 908;
        return t;
    };
    return ProLoadingSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/PromptSkin.exml'] = window.PromptSkin = (function(_super) {
    __extends(PromptSkin, _super);

    function PromptSkin() {
        _super.call(this);
        this.skinParts = ["txt1", "input1", "btnOK"];

        this.height = 289;
        this.width = 519;
        this.elementsContent = [this._Image1_i(), this._Image2_i(), this.txt1_i(), this.input1_i(), this.btnOK_i()];
    }
    var _proto = PromptSkin.prototype;

    _proto._Image1_i = function() {
        var t = new eui.Image();
        t.anchorOffsetY = 0;
        t.height = 289;
        t.scale9Grid = new egret.Rectangle(23, 25, 22, 24);
        t.source = "dt_base_frame_png";
        t.width = 519;
        t.x = 0;
        t.y = 0;
        return t;
    };
    _proto._Image2_i = function() {
        var t = new eui.Image();
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 39;
        t.scale9Grid = new egret.Rectangle(3, 3, 24, 24);
        t.scaleY = 2;
        t.source = "dt_base_text_frame_png";
        t.width = 449;
        t.x = 35;
        t.y = 91;
        return t;
    };
    _proto.txt1_i = function() {
        var t = new eui.Label();
        this.txt1 = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.fontFamily = "微软雅黑";
        t.height = 38;
        t.multiline = true;
        t.size = 36;
        t.text = "普通文字";
        t.textAlign = "center";
        t.textColor = 0x9b7855;
        t.verticalAlign = "middle";
        t.width = 491;
        t.wordWrap = true;
        t.x = 14;
        t.y = 29;
        return t;
    };
    _proto.input1_i = function() {
        var t = new eui.TextInput();
        this.input1 = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.height = 60;
        t.maxChars = 20;
        t.width = 435;
        t.x = 42;
        t.y = 100;
        return t;
    };
    _proto.btnOK_i = function() {
        var t = new eui.Button();
        this.btnOK = t;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.bottom = 32;
        t.height = 62;
        t.horizontalCenter = 0.5;
        t.label = "确 定";
        t.width = 188;
        return t;
    };
    return PromptSkin;
})(eui.Skin);
generateEUI.paths['resource/skins/assets/TextLineSliderSkin.exml'] = window.TextLineSliderSkin = (function(_super) {
    __extends(TextLineSliderSkin, _super);

    function TextLineSliderSkin() {
        _super.call(this);
        this.skinParts = ["imgPao", "txtPao", "group1", "imgLaba"];

        this.height = 576;
        this.width = 1024;
        this.elementsContent = [this.group1_i(), this.imgLaba_i()];
    }
    var _proto = TextLineSliderSkin.prototype;

    _proto.group1_i = function() {
        var t = new eui.Group();
        this.group1 = t;
        t.anchorOffsetX = 0;
        t.height = 32;
        t.horizontalCenter = 0;
        t.touchChildren = true;
        t.touchEnabled = true;
        t.touchThrough = false;
        t.width = 595;
        t.y = 138;
        t.elementsContent = [this.imgPao_i(), this.txtPao_i()];
        return t;
    };
    _proto.imgPao_i = function() {
        var t = new eui.Image();
        this.imgPao = t;
        t.alpha = 1;
        t.anchorOffsetX = 0;
        t.anchorOffsetY = 0;
        t.fillMode = "scale";
        t.height = 35;
        t.horizontalCenter = 0;
        t.scale9Grid = new egret.Rectangle(0, 0, 22, 22);
        t.source = "dt_base_paomadeng_png";
        t.touchEnabled = false;
        t.verticalCenter = 0;
        t.width = 821;
        return t;
    };
    _proto.txtPao_i = function() {
        var t = new eui.Label();
        this.txtPao = t;
        t.fontFamily = "微软雅黑";
        t.size = 25;
        t.text = "跑马灯 跑马灯 跑马灯 跑马灯 跑马灯";
        t.textColor = 0xFFF7D2;
        t.touchEnabled = false;
        t.verticalCenter = 0;
        t.x = 95;
        return t;
    };
    _proto.imgLaba_i = function() {
        var t = new eui.Image();
        this.imgLaba = t;
        t.source = "dt_base_laba_png";
        t.visible = false;
        t.x = 43;
        t.y = 136;
        return t;
    };
    return TextLineSliderSkin;
})(eui.Skin);