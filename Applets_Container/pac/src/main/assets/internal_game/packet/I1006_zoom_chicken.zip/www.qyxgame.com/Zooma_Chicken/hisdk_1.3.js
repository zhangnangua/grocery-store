window._ShowAd = null;
window._success = null;
window._failure = null;
window._isShowLoadAd = false;
window._isShowStart = false;
window._isFirst = true;
var _locationHref = window.location.href;
var _language = (navigator.browserLanguage || navigator.language).toLowerCase();
console.log(_language);
window.onmessage = function(e) {
    e = e || event;
    let tempData = e.data + "";
	console.log("onmessage:"+tempData);
    if (tempData == "open" || tempData == "showInterstitial") {
        window.cy_Sdk.showInterstitial(()=>{
            document.getElementById("iframe_game").contentWindow.postMessage("close", "*");
        }
        );
    } else if (tempData == "showReward") {
        window.cy_Sdk.showReward(()=>{
            document.getElementById("iframe_game").contentWindow.postMessage("close", "*");
        }
        , ()=>{
            document.getElementById("iframe_game").contentWindow.postMessage("fail", "*");
        }
        );
    } else if (tempData == "start") {
        if (!window._isShowStart) {
            window._isShowStart = true;
        }
    } else if (tempData == "loadingOver") {
        if (!window._isShowLoadAd) {
            window._isShowLoadAd = true;
            if (window.Aha_App || _language.indexOf('zh') > -1 || window.Qyx_More_hide) {} else {
                setTimeout(()=>{
                    cy_Home();
                }
                , 10000)
            }
            console.log("loadingOver");
        }
    } else if (tempData == "adShow") {
        window.cy_Sdk.adShow();
    } else if (tempData == "adHide") {
        window.cy_Sdk.adHide();
    } else if (tempData == "reportPlayTime") {
        window.cy_Sdk.reportPlayTime();
    } else if (tempData.indexOf("dot") >= 0) {
        let _v = tempData.substring(4).split("|");
        window.cy_Sdk.ga.apply(window, _v);
    }
}
window.untilLog = (msg)=>{
    console.log('%c' + msg, 'color: #43bb88;font-size: 20px;font-weight: bold;text-decoration: underline;');
}
window.changeSize = ()=>{
    if (window.innerWidth > window.innerHeight) {
        window.cy_Sdk.ga("horizontal");
    }
    let banner = document.getElementById("game_banner");
    if (banner) {
        document.getElementById("div_iframe_game").style.height = window.innerHeight - 55 + "px";
        banner.style.top = window.innerHeight - 50 + "px";
    }
}
;
function _add_ga() {
    (function(i, s, o, g, r, a, m) {
        i['dataLayer'] = i['dataLayer'] || [];
        i[r] = i[r] || function() {
            i['dataLayer'].push(arguments)
        }
        ;
        a = s.createElement(o),
        m = s.head || s.getElementsByTagName("head")[0];
        a.async = 1;
        a.src = g;
        a.type = "text/javascript";
        m.appendChild(a)
    }
    )(window, document, 'script', 'https://www.googletagmanager.com/gtag/js?id=UA-120043346-102', 'gtag');
    gtag('js', new Date());
    gtag('config', 'UA-120043346-102');
}
function _add_newfg() {
    var script = document.createElement("script");
    script.async = true;
    script.setAttribute("data-ad-client", "ca-pub-2270136017335510");
    script.setAttribute("data-ad-channel", "8234333183");
    script.setAttribute("data-ad-frequency-hint", "30s");
    script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";
    document.head.appendChild(script);
    window["adsbygoogle"] = window["adsbygoogle"] || [];
    window.adBreak = window.adConfig = function(o) {
        adsbygoogle.push(o);
    }
    window.adConfig({
        preloadAdBreaks: "on",
        onReady: ()=>{
            window.adBreak({
                type: "preroll",
                name: "my_preroll",
                adBreakDone: ()=>{}
                ,
            });
        }
        ,
    });
}
function dynamicLoadCss(url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = url;
    head.appendChild(link);
}
var gameImages = ["LudoManiGame.png", "RescueTheLover.png", "CarromChallenge.png", "ClassicBlockPuzzle.png", "Bubblington_Shooting.png", "Real_Moto_Race.png", "AirWarriors.png", "ClassicBilliard.png", "Bubble_Legend.png", "Panzer_Front.png"];
var gameUrls = ["LudoManiGame", "RescueTheLover", "CarromChallenge", "ClassicBlockPuzzle", "bubblington_shooting", "Real_Moto_Race", "AirWarriors", "ClassicBilliard", "BubbleLegend", "panzer-front"];
var _html_created = 0;
function _tap_game_ex_img() {
    var _i = _html_created % gameUrls.length;
    _html_created = _html_created + 1;
    if (_locationHref.indexOf(gameUrls[_i]) > 0) {
        _tap_game_ex_img();
        return;
    }
    var a_tap_game = document.getElementById("a_tap_game");
    a_tap_game.style.display = "block";
    var img_tap_game = document.getElementById("img_tap_game");
    a_tap_game.setAttribute("href", "https://www.coolplaygame.com/cy/" + gameUrls[_i] + "/index.html");
    img_tap_game.setAttribute("src", "../../icons/more/" + gameImages[_i]);
    setTimeout(_tap_game_ex_img, 5000);
}
function cy_Home() {
    var isShowNav = document.getElementById("a_tap_game");
    if (isShowNav)
        return;
    dynamicLoadCss("../nav.css");
    var a_tap_game = document.createElement("a");
    a_tap_game.id = "a_tap_game";
    a_tap_game.setAttribute("class", "a_tap_game");
    a_tap_game.setAttribute("href", "https://www.coolplaygame.com/cy/" + gameUrls[0] + "/index.html");
    a_tap_game.style.display = "none";
    document.getElementsByTagName("body")[0].appendChild(a_tap_game);
    a_tap_game.innerHTML = '<img id="img_tap_game" class="img_tap_game" style="z-index:110;height:57px;width:57px;position:absolute;-webkit-border-radius:50%;  border-radius:50%"><img class="font_tap_game" src="../click.svg">';
    setTimeout(_tap_game_ex_img, 3000);
    var disX, moveX, L, T, starX, starY, starXEnd, starYEnd;
    a_tap_game.addEventListener('touchstart', function(e) {
        disX = e.touches[0].clientX - this.offsetLeft;
        disY = e.touches[0].clientY - this.offsetTop;
        starX = e.touches[0].clientX;
        starY = e.touches[0].clientY;
    });
    a_tap_game.addEventListener('touchmove', function(e) {
        L = e.touches[0].clientX - disX;
        T = e.touches[0].clientY - disY;
        starXEnd = e.touches[0].clientX - starX;
        starYEnd = e.touches[0].clientY - starY;
        if (L < 0) {
            L = 0;
        } else if (L > document.documentElement.clientWidth - this.offsetWidth) {
            L = document.documentElement.clientWidth - this.offsetWidth;
        }
        if (T < 0) {
            T = 0;
        } else if (T > document.documentElement.clientHeight - this.offsetHeight) {
            T = document.documentElement.clientHeight - this.offsetHeight;
        }
        moveX = L + 'px';
        moveY = T + 'px';
        this.style.left = moveX;
        this.style.top = moveY;
    });
    a_tap_game.addEventListener('touchend', function(e) {
        if (event.changedTouches.length == 1) {
            var touch = event.changedTouches[0];
            var halfViewWidth = window.innerWidth / 2;
            var halfWidth = 25;
            if ((touch.clientX < 0) || (touch.clientX >= 0 && touch.clientX <= (halfViewWidth - halfWidth))) {
                a_tap_game.style.left = '10px';
            } else if (touch.clientX >= (halfViewWidth - halfWidth)) {
                a_tap_game.style.left = (window.innerWidth - 80) + 'px';
            }
            if (touch.clientY < 0) {
                a_tap_game.style.top = 20 + 'px';
            } else if (touch.clientY >= window.innerHeight - 80) {
                a_tap_game.style.top = (window.innerHeight - 80 - 20) + 'px';
            }
        }
    });
}
window.addEventListener("resize", window.changeSize, false);
window.cy_Sdk = {
    initSdk: (appKey,_top,_left,_bottom,_right)=>{
        var ad_env = typeof (window.adBoxPre) != "undefined" ? "pre" : "";
        console.log("初始化广告位置", _top, _left, _bottom, _right, ad_env);
        var adsense_config = {
            "client": "ca-pub-2270136017335510",
            "data-ad-frequency-hint": "30s",
            "data-ad-channel": "8234333183",
            "pauseCallback": ()=>{
                console.log("👩💻 my game paused");
                document.getElementById("iframe_game").contentWindow.postMessage("pauseGame", "*");
            }
            ,
            "resumeCallback": ()=>{
                console.log("👩💻 my game restart");
                document.getElementById("iframe_game").contentWindow.postMessage("resumeGame", "*");
            }
            ,
            "callback": ()=>{
                window.changeSize();
                window.cy_Sdk.showBanner();
                window.cy_Sdk.ga("game_start", document.title);
                var _h5sdk_menu = document.getElementById("_h5sdk_menu");
                if (_h5sdk_menu) {
                    _h5sdk_menu.style.top = "15px";
                }
                window.h5sdk.adConfig({
                    preloadAdBreaks: "on",
                    onReady: ()=>{
                        window.h5sdk.adBreak({
                            type: "preroll",
                            name: "my_preroll",
                            adBreakDone: ()=>{}
                            ,
                        });
                    }
                    ,
                });
            }
        };
        if (window.location.href.indexOf("127.0.0.1") >= 0) {
            adsense_config["data-adbreak-test"] = "on";
        }
        window.h5sdk ? window.h5sdk.init(appKey, _top, _left, _bottom, _right, {
            float: {
                env: ad_env,
            },
            ga: {
                id: "UA-120043346-102",
            },
            adsence: adsense_config,
        }) : (function() {
            _add_ga();
            _add_newfg();
        }
        )();
    }
    ,
    showBanner: ()=>{
        var game_banner = document.getElementById("game_banner");
        if (game_banner) {
            var banner_ad = game_banner.getElementsByTagName("ins");
            if (banner_ad.length == 0) {
                var ins = document.createElement('ins');
                ins.className = 'adsbygoogle';
                ins.style.display = 'inline-block';
                ins.style.height = '50px';
                ins.style.width = '100%';
                ins.setAttribute('data-ad-client', "ca-pub-2270136017335510");
                ins.setAttribute('data-ad-slot', "7538492324");
                game_banner.appendChild(ins);
                (adsbygoogle = window.adsbygoogle || []).push({});
            }
        }
    }
    ,
    closeBanner: ()=>{
        var game_banner = document.getElementById("game_banner");
        if (game_banner) {
            var banner_ad = game_banner.getElementsByTagName('ins');
            if (banner_ad.length > 0) {
                banner_ad[0].parentNode.removeChild(banner_ad[0])
            }
        }
    }
    ,
    showStartAd: ()=>{
        window.h5sdk.adBreak({
            type: "preroll",
            name: "loading",
            adBreakDone: ()=>{}
        });
    }
    ,
    showLoadAd: ()=>{
        window.h5sdk.adBreak({
            type: "preroll",
            name: "loading",
            adBreakDone: ()=>{}
        });
    }
    ,
    showInterstitial: (success)=>{
        console.log("requesting Interstitial AD");
        let typename = "start";
        if (_isFirst) {
            _isFirst = false;
        } else {
            typename = "next";
        }
        window.h5sdk.adBreak({
            type: typename,
            name: "game",
            adBreakDone: ()=>{
                success && success();
                success = null;
            }
        });
    }
    ,
    showReward: (success,failure)=>{
		console.log("start ad:showReward");
        window.h5sdk.adBreak({
            type: "reward",
            name: "reward",
            beforeAd: ()=>{
                console.log("%c Reward AD BeforeAd", 'color: #0000FF;font-size: 18px;');
            }
            ,
            beforeReward: (e)=>{
                e();
            }
            ,
            adDismissed: ()=>{
                failure && failure();
            }
            ,
            adViewed: ()=>{
                success && success();
            }
            ,
            adBreakDone: (e)=>{
                if (e.breakStatus == "viewed" || e.breakStatus == "dismissed") {} else {
                    failure && failure();
                }
            }
        });
    }
    ,
    adShow: ()=>{
        console.log("展示悬浮广告");
        window.h5sdk && window.h5sdk.show();
    }
    ,
    adHide: ()=>{
        console.log("隐藏悬浮广告");
        window.h5sdk && window.h5sdk.hide();
    }
    ,
    reportPlayTime: ()=>{
        let s_time = Date.parse(new Date()) / 1000;
        window.setInterval(()=>{
            let e_time = Date.parse(new Date()) / 1000;
            window.cy_Sdk.ga("play_time", e_time - s_time);
        }
        , 30 * 1000);
    }
    ,
    ga: function() {
        console.log("打点信息:", arguments);
        if (arguments.length >= 0 && arguments[0] == "loading_end") {
            window.h5sdk && window.h5sdk.gameLoadingCompleted && window.h5sdk.gameLoadingCompleted();
            if (window.Aha_App || _language.indexOf('zh') > -1 || window.Qyx_More_hide) {} else {
                setTimeout(()=>{
                    cy_Home();
                }
                , 10000)
            }
        }
        switch (arguments.length) {
        case 1:
            window.h5sdk && window.h5sdk.athenaSend(arguments[0]);
            break;
        case 2:
            window.h5sdk && window.h5sdk.athenaSend(arguments[0], arguments[1]);
            break;
        case 3:
            window.h5sdk && window.h5sdk.athenaSend(arguments[0], arguments[1], arguments[2]);
            break;
        }
    }
}
