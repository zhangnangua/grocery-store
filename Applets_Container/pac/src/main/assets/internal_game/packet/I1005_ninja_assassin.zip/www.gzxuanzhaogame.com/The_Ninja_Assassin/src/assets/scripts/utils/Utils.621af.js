(function(e) {
    "use strict";
    var t = {
        copy(e) {
            if (!e) return;
            let t = {};
            for (let r in e) e.hasOwnProperty(r) && (t[r] = e[r]);
            return t;
        },
        clone: e => e ? JSON.parse(JSON.stringify(e)) : null,
        distance(e, t) {
            let r = e.x - t.x, n = e.y - t.y;
            return Math.sqrt(r * r + n * n);
        },
        getIntersection(e, t) {
            let r = e.a.x, n = e.a.y, a = e.b.x - e.a.x, o = e.b.y - e.a.y, i = t.a.x, l = t.a.y, s = t.b.x - t.a.x, u = t.b.y - t.a.y, g = Math.sqrt(a * a + o * o), h = Math.sqrt(s * s + u * u);
            if (a / g == s / h && o / g == u / h) return -1;
            let y = (a * (l - n) + o * (r - i)) / (s * o - u * a), c = (i + s * y - r) / a;
            return c < 0 || y < 0 || y > 1 ? -1 : c;
        },
        getPointOnCircle(e, t, r, n) {
            let a = Math.sin(r), o = Math.cos(r), i = {
                x: 0,
                y: 0
            };
            return i.x = e + a * n, i.y = t + o * n, i;
        },
        randomWeight(e) {
            let t = Math.floor(Math.random() * e.sum()), r = 0;
            for (;t > e.sum(r); ) r++;
            return r;
        },
        retainPlace: (e, t) => Math.round(e * Math.pow(10, t)) / Math.pow(10, t),
        binaryToArray(e, t) {
            let r = [], n = 1, a = 0;
            for (let o = 0; o < t; o++) (a = e & n) && r.push(o), n <<= 1;
            return r;
        },
        isValidString: e => "string" == typeof e && e.constructor === String,
        isSerializableValue: e => "string" == typeof e && e.constructor === String || "number" == typeof e,
        isValidName: e => RegExp(/^[\u4e00-\u9fa5]{2,10}$/g).test(e),
        isValidMail: e => RegExp(/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/).test(e),
        isValidLetter: e => RegExp(/^([a-zA-Z0-9_-])/).test(e),
        isEven: e => e % 2 == 0,
        isNone: e => void 0 === e || null === e || !1 === e,
        isEqualVector: (e, t) => e.x === t.x && e.y === t.y,
        isEqualModule: (e, t) => e instanceof t,
        compareVersion(e, t) {
            e = e.split("."), t = t.split(".");
            const r = Math.max(e.length, t.length);
            for (;e.length < r; ) e.push("0");
            for (;t.length < r; ) t.push("0");
            for (let n = 0; n < r; n++) {
                const r = parseInt(e[n]), a = parseInt(t[n]);
                if (r > a) return 1;
                if (r < a) return -1;
            }
            return 0;
        }
    };
    t.Html = {
        encode(e) {
            let t = "";
            return e.length ? t = (t = (t = (t = (t = (t = e.replace(/&/g, "&amp;")).replace(/</g, "&lt;")).replace(/>/g, "&gt;")).replace(/ /g, "&nbsp;")).replace(/\'/g, "&#39;")).replace(/\"/g, "&quot;") : "";
        },
        decode(e) {
            let t = "";
            return e.length ? t = (t = (t = (t = (t = (t = e.replace(/&amp;/g, "&")).replace(/&lt;/g, "<")).replace(/&gt;/g, ">")).replace(/&nbsp;/g, " ")).replace(/&#39;/g, "'")).replace(/&quot;/g, '"') : "";
        }
    }, t.Bezier = {
        createCurve(e, t, r = .005, n = !1) {
            for (var a = [], o = [], i = 0; i < t && (!n || i !== t - 1); i++) {
                var l = (i + 1) % t;
                a[i] = {
                    x: 0,
                    y: 0
                }, a[i].x = (e[i].x + e[l].x) / 2, a[i].y = (e[i].y + e[l].y) / 2;
            }
            var s = [];
            for (i = 0; i < t && (!n || i !== t - 1); i++) {
                l = (i + 1) % t;
                var u = 0 === i && n ? i : (i + t - 1) % t, g = {
                    x: 0,
                    y: 0
                };
                g.x = (a[i].x + a[u].x) / 2, g.y = (a[i].y + a[u].y) / 2;
                var h = e[i].x - g.x, y = e[i].y - g.y;
                s[M = 2 * i] = {
                    x: 0,
                    y: 0
                }, s[M].x = a[u].x + h, s[M].y = a[u].y + y;
                var c = .6 * (s[M].x - e[i].x), p = .6 * (s[M].y - e[i].y);
                s[M].x = e[i].x + c, s[M].y = e[i].y + p, s[x = (M + 1) % (2 * t)] = {
                    x: 0,
                    y: 0
                }, s[x].x = a[i].x + h, s[x].y = a[i].y + y, c = .6 * (s[x].x - e[i].x), p = .6 * (s[x].y - e[i].y), 
                s[x].x = e[i].x + c, s[x].y = e[i].y + p;
            }
            var f = [];
            for (i = 0; i < t; i++) {
                if (n && i >= t - 2) {
                    o.push(e[e.length - 1]);
                    break;
                }
                f[0] = e[i];
                var M = 2 * i;
                f[1] = s[M + 1];
                var x = (M + 2) % (2 * t);
                f[2] = s[x];
                l = (i + 1) % t;
                f[3] = e[l];
                for (var m = 1; m >= 0; ) {
                    var D = this.bezier3FuncX(m, f), d = this.bezier3FuncY(m, f);
                    m -= r;
                    var T = {
                        x: D,
                        y: d
                    };
                    o.push(T);
                }
            }
            return o;
        },
        bezier3FuncX: (e, t) => t[0].x * e * e * e + 3 * t[1].x * e * e * (1 - e) + 3 * t[2].x * e * (1 - e) * (1 - e) + t[3].x * (1 - e) * (1 - e) * (1 - e),
        bezier3FuncY: (e, t) => t[0].y * e * e * e + 3 * t[1].y * e * e * (1 - e) + 3 * t[2].y * e * (1 - e) * (1 - e) + t[3].y * (1 - e) * (1 - e) * (1 - e)
    }, t.Sort = {
        bubble(e) {
            for (let t = 0; t < e.length - 1; t++) for (let r = t + 1; r < e.length; r++) if (e[t] > e[r]) {
                let n = e[t];
                e[t] = e[r], e[r] = n;
            }
            return e;
        },
        quick(e) {
            if (e.length <= 1) return e;
            let t = Math.floor(e.length / 2), r = e.splice(t, 1), n = [], a = [];
            for (let t = 0; t < e.length; t++) e[t] < r ? n.push(e[t]) : a.push(e[t]);
            return this.quick(n).concat(r, this.quick(a));
        }
    }, t.Angle = {
        toRadian: e => e * Math.PI / 180,
        fromRadian: e => 180 * e / Math.PI,
        randomVector: () => cc.Vec2.RIGHT.rotate(2 * Math.random() * Math.PI),
        toVector(e) {
            return cc.Vec2.RIGHT.rotate(-this.toRadian(e)).normalize();
        },
        between(e, t) {
            let r = this.fromRadian(this.radianBetween(e, t));
            return r = (360 - r) % 360;
        },
        radianBetween: (e, t) => Math.atan2(t.y - e.y, t.x - e.x),
        toPlus(e) {
            let t = e % 360;
            return t = t < 0 ? e + 360 : e;
        },
        toPlusMinus(e) {
            let t = e % 360;
            return t = t > 180 ? e - 360 : e;
        },
        getOriginPoint(e) {
            let t = e.length, r = 0, n = 0;
            for (let t in e) e.hasOwnProperty(t) && (r += t.x * Math.PI / 180, n += t.y * Math.PI / 180);
            return r /= t, n /= t, new cc.Vec2(180 * r / Math.PI, 180 * n / Math.PI);
        }
    }, t.String = {
        randomAssignLength(e) {
            e = e || 32;
            let t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678", r = t.length, n = "";
            for (let a = 0; a < e; a++) n += t.charAt(Math.floor(Math.random() * r));
            return n;
        },
        toChNum(e) {
            let t = e.toString(), r = t.split("");
            for (let e = 0; e < r.length; e++) r.splice(e, 1, "零一二三四五六七八九十".charAt(parseInt(t[e])));
            return t = r.join("");
        },
        placesNumber(e, t) {
            let r;
            return r = (r = (e += Math.pow(10, t)).toString()).substring(1, t + 1);
        },
        normalizedNumber(e) {
            let t = 0;
            for (;e >= 1e5; ) e /= 1e3, t++;
            return (e = Math.floor(e)).toString() + this.getUnit(t);
        },
        getUnit(e) {
            let t = "";
            return 0 === e ? t : t = e <= 4 ? this.getUnitAsKMB(e - 1) : this.getUnitAsAAZZ(e - 5);
        },
        getUnitAsKMB: e => "KMBT"[e = (e = e || 0) >= "KMBT".length ? "KMBT".length - 1 : e],
        getUnitAsAAZZ(e) {
            e = e || 0;
            let t = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", r = Math.floor(e / t.length), n = e % t.length;
            return t[r = r >= t.length ? t.length - 1 : r] + t[n = n >= t.length ? t.length - 1 : n];
        }
    }, t.Json = {
        arrayToJson(e) {
            let t = {};
            for (let r = 0; r < e.length; r++) t[r + 1] = e[r];
            return t;
        },
        jsonToTreeMap(e) {
            let t = this.arrayToJson(e);
            return t = new InfiniteMap(t, e.length);
        },
        toJsonFile(e, t) {
            t = JSON.stringify(t), jsb.fileUtils.writeStringToFile(t, jsb.fileUtils.getWritablePath() + e + ".json");
        }
    }, t.Unix = {
        toYear: e => Math.floor(e / 31104e3),
        toMonth: e => Math.floor(e / 2592e3),
        toDay: e => Math.floor(e / 86400),
        toHour: e => Math.floor(e / 36e5),
        toMinute: e => Math.floor(e / 6e4),
        toMSString(e) {
            let t = parseInt(e / 6e4), r = parseInt(e / 1e3 - 60 * t);
            return (t = t >= 10 ? "" + t : "0" + t) + ":" + (r = r >= 10 ? "" + r : "0" + r);
        },
        toHMSString(e) {
            let t = parseInt(e / 36e5), r = parseInt(e / 6e4 - 60 * t), n = parseInt(e / 1e3 - 3600 * t - 60 * r);
            return (t = t >= 10 ? "" + t : "0" + t) + ":" + (r = r >= 10 ? "" + r : "0" + r) + ":" + (n = n >= 10 ? "" + n : "0" + n);
        },
        toTimeObject(e) {
            let t = 0, r = 0;
            return e > 0 && (e /= 1e3, r = Math.floor(e % 3600 / 60), t = Math.floor(e / 3600)), 
            {
                hour: t,
                minute: r
            };
        },
        gmtToChina: e => e + 288e5,
        getTodayHourStart: e => new Date(new Date().setHours(e, 0, 0, 0)).getTime(),
        getTodayStart: () => new Date(new Date().setHours(0, 0, 0, 0)).getTime(),
        getTodayEnd() {
            let e = new Date(new Date().setHours(0, 0, 0, 0));
            return new Date(e.getTime() + 864e5 - 1).getTime();
        },
        getYesterdayStart() {
            let e = new Date(new Date().setHours(0, 0, 0, 0));
            return new Date(e.getTime() - 864e5).getTime();
        },
        getSundayStart() {
            let e = new Date(new Date().setHours(0, 0, 0, 0));
            return new Date(e.getTime() - 864e5 * e.getDay()).getTime();
        },
        getLastSundayStart() {
            let e = new Date().setHours(0, 0, 0, 0);
            return new Date(e.getTime() - 864e5 * (e.getDay() + 7)).getTime();
        },
        apartThanOneDay: (e, t, r) => (r = r ? Math.ceil(r) : 1, Math.abs(new Date(new Date(e).setHours(0, 0, 0, 0)).getTime() - new Date(new Date(t).setHours(0, 0, 0, 0)).getTime()) > 24 * r * 60 * 60 * 1e3),
        toDayStart: e => new Date(new Date(e).setHours(0, 0, 0, 0)),
        toYMD(e, t) {
            let r = new Date(e);
            return r.getFullYear() + t + (r.getMonth() + 1) + t + r.getDate();
        },
        isSameDay: (e, t) => new Date(new Date(e).setHours(0, 0, 0, 0)).getTime() === new Date(new Date(t).setHours(0, 0, 0, 0)).getTime(),
        isSameWeek(e, t) {
            let r = parseInt(+e / 864e5), n = parseInt(+t / 864e5);
            return parseInt((r + 4) / 7) === parseInt((n + 4) / 7);
        }
    }, t.Direction = {
        EightDir: {
            RIGHT: 0,
            RIGHT_DOWN: 1,
            DOWN: 2,
            LEFT_DOWN: 3,
            LEFT: 4,
            LEFT_UP: 5,
            UP: 6,
            RIGHT_UP: 7
        },
        deltaVectors: [ [ 1, 0 ], [ 1, 1 ], [ 0, 1 ], [ -1, 1 ], [ -1, 0 ], [ -1, -1 ], [ 0, -1 ], [ 1, -1 ] ],
        dirToDeltaVector(e) {
            return e < 0 || e >= 8 ? null : this.deltaVectors[e];
        },
        getDir: function(e, t, r) {
            var n, a = 0;
            return t >= 0 ? (n = t / r, a = e >= 0 ? n < .5 ? 0 : n < .866 ? 7 : 6 : n < .5 ? 4 : n < .866 ? 5 : 6) : (n = Math.abs(t / r), 
            a = e >= 0 ? n < .5 ? 0 : n < .866 ? 1 : 2 : n < .5 ? 4 : n < .866 ? 3 : 2), a;
        },
        toChineseDir: e => [ "东方", "东南方", "南方", "西南方", "西方", "西北方", "北方", "东北方" ][e]
    }, "object" == typeof module && module.exports ? module.exports = t : "function" == typeof define && define.amd && define(function() {
        return t;
    }), e.Utils = t;
})(this);