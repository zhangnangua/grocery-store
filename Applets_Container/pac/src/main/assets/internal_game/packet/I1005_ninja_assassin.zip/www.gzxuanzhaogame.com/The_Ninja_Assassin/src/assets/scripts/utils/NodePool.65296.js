(function(e) {
    "use strict";
    function t(e, o, i) {
        this.reuseNodeInterface = i, this.model = e, this.cachePool = [], this.activePool = [], 
        t.HookReuseNode(e, i), this.put(e), !o || o <= 0 || this.scale(o - 1);
    }
    t.prototype = {
        constructor: t,
        scale(e) {
            let o;
            for (let i = 0; i < e; i++) (o = this.model.initialize()).parent = this.model.parent, 
            t.HookReuseNode(o, this.reuseNodeInterface), this.put(o);
            return this;
        },
        get(e, o) {
            if (e = e || t.Type.STATIC, !this.cachePool.length) switch (e) {
              default:
              case t.Type.STATIC:
                return null;

              case t.Type.SCALE:
                this.scale(1);
                break;

              case t.Type.RECYCLE:
                this.recycle(o);
            }
            return this.getCacheHead();
        },
        add(e, t) {
            let o = this.get(e, t);
            return o ? (this.cachePool.remove(o), this.activePool.push(o), o.init(), o) : null;
        },
        put(e) {
            return !e || this.cachePool.contains(e) ? (cc.warn(`NodePool: node is Invalid.${e}`), 
            this) : (this.activePool.remove(e), this.cachePool.push(e), e.onRecycle(), this);
        },
        recycle(e) {
            let t = e ? this.getActiveRear() : this.getActiveHead();
            return t ? (this.put(t), t) : (cc.warn("NodePool: It is empty.Can not do-recycle"), 
            null);
        },
        getActiveHead() {
            return this.activePool.length <= 0 ? null : this.activePool[0];
        },
        getActiveRear() {
            return this.activePool.length <= 0 ? null : this.activePool[this.activePool.length - 1];
        },
        getCacheHead() {
            return this.cachePool.length ? this.cachePool[0] : null;
        },
        getCacheRear() {
            return this.cachePool.length ? this.cachePool[this.cachePool.length - 1] : null;
        },
        clear() {
            let e = this.activePool.length;
            for (let t = 0; t < e; t++) this.put(this.activePool[0]);
            return this;
        },
        release() {
            let e = this.activePool.concat(this.cachePool);
            for (let t = e.length - 1; t >= 0; t--) e[t].onRelease();
            return this.activePool = [], this.cachePool = [], this.model = null, this;
        },
        getActiveCount() {
            return this.activePool.length;
        }
    }, t.Type = cc.Enum({
        STATIC: 0,
        SCALE: 1,
        RECYCLE: 2
    }), t.HookReuseNode = function(e, i) {
        if (!(e instanceof cc.Node)) throw new Error("Hook: node type error,");
        i = i || o;
        for (let o in i) i.hasOwnProperty(o) && t.Hook(e, o, i[o]);
    }, t.Hook = function(e, t, o) {
        if ("object" != typeof e || "string" != typeof t) return void console.log(`Hook: input data error.${e} ${t} ${o}`);
        if (!e[t] || "function" != typeof e[t]) return void (e[t] = o);
        let i = e[t];
        e[t] = function() {
            i(), o();
        };
    };
    const o = {
        hasUsed: !1,
        initialize() {
            return cc.instantiate(this);
        },
        init() {
            this.hasUsed ? this.onReuse() : this.onFirstUse(), this.hasUsed = !0;
        },
        onFirstUse() {
            this.active = !0;
        },
        onReuse() {
            this.active = !0;
        },
        onRelease() {
            this.hasUsed = !1, this.destroy();
        },
        onRecycle() {
            this.stopAllActions(), this.active = !1;
        }
    };
    "object" == typeof module && module.exports ? module.exports = t : "function" == typeof define && define.amd && define(function() {
        return t;
    }), e.NodePool = t;
})(this);