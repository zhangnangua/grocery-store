window.kk = {
    runtimeData: null,
    curUser: null,
    curScene: null,
    levelManager: null,
    inputManager: null,
    cameraManager: null,
    resolution: {
        width: 750,
        height: 1334
    },
    isSprs() {
        let t = cc.view.getVisibleSizeInPixel().height / cc.view.getVisibleSizeInPixel().width, e = this.resolution.height / this.resolution.width;
        return t.toFixed(1) > e.toFixed(1);
    },
    CocosVersion: () => parseInt(cc.ENGINE_VERSION),
    getEqualRatioHeight() {
        return cc.view.getVisibleSizeInPixel().width * this.resolution.height / this.resolution.width;
    },
    getBottomOffset() {
        let t = cc.view.getVisibleSizeInPixel();
        return (t.height - t.width * this.resolution.height / this.resolution.width) / 2;
    },
    convertToVisibleSize(t) {
        return t * cc.view.getVisibleSizeInPixel().width / this.resolution.width;
    },
    convertToWinSize(t) {
        let e = cc.view.getVisibleSizeInPixel();
        return t * this.resolution.width / e.width;
    },
    isNativeApp: () => cc.sys.platform === cc.sys.ANDROID || cc.sys.platform === cc.sys.IPHONE || cc.sys.platform === cc.sys.IPAD,
    isNativeAndroid: () => cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID,
    isNativeIos: () => cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS,
    isHtmlWX: () => cc.sys.platform === cc.sys.WECHAT_GAME,
    isWindows: () => cc.sys.os === cc.sys.OS_WINDOWS,
    Canvas: () => cc.find("Canvas"),
    MainCamera: () => cc.find("Canvas/Main Camera").getComponent(cc.Camera),
    getRuntimeData(t) {
        return this.runtimeData || (this.runtimeData = new InfiniteMap()), this.runtimeData.query(t);
    },
    setRuntimeData(t, e) {
        return this.runtimeData || (this.runtimeData = new InfiniteMap()), this.runtimeData.set(t, e || 0), 
        e;
    },
    addRuntimeData(t, e) {
        if (!t || !e) throw new Error("参数定义有误");
        return this.runtimeData || (this.runtimeData = new InfiniteMap()), e += this.getRuntimeData(t), 
        this.runtimeData.set(t, e), e;
    },
    saveRuntimeData(t) {
        this.save(t, this.getRuntimeData(t));
    },
    save: (t, e) => (cc.sys.localStorage.setItem(t, JSON.stringify(e)), e),
    load(t) {
        let e = cc.sys.localStorage.getItem(t), i = 0;
        if (!e) return i;
        try {
            return i = JSON.parse(e);
        } catch (t) {
            return i;
        }
    },
    remove(t) {
        cc.sys.localStorage.removeItem(t);
    },
    clear() {
        cc.sys.localStorage.clear();
    }
};