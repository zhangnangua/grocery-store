window._CCSettings = {
    server: "",
    assets: 1,
    platform: "web-mobile",
    groupList: [
        "default",
        "ui"
    ],
    collisionMatrix: [
        [
            true
        ],
        [
            false,
            false
        ]
    ],
    rawAssets: {
        assets: {
            "83JeQlZHJLk4CQFZKK6BGt": [
                "DDSH_SDK/bannerNativeBg.prefab",
                "cc.Prefab"
            ],
            "76jzWyxFNBmo3uAqDSQt+d": [
                "DDSH_SDK/bggg",
                "cc.SpriteFrame",
                1
            ],
            "3eZ6idK5BDIZoMvZW9Aiy7": [
                "DDSH_SDK/bggg.png",
                "cc.Texture2D"
            ],
            "21lGYSl/RMhqtcDXrvwcyc": [
                "DDSH_SDK/image/SpotNativeAD",
                "cc.SpriteFrame",
                1
            ],
            "edbQc1Me1FpZcZGZQjWa/z": [
                "DDSH_SDK/image/SpotNativeAD.png",
                "cc.Texture2D"
            ],
            "f8O/VuoGhEUpBFr9mlBcqm": [
                "DDSH_SDK/image/bannerNativeAD",
                "cc.SpriteFrame",
                1
            ],
            "51pV8xrghC3ZWcfXxiLz/Y": [
                "DDSH_SDK/image/bannerNativeAD.png",
                "cc.Texture2D"
            ],
            "8eReVNX1hMd4Uv0QkWWHWK": [
                "DDSH_SDK/image/bannerNativeBg1",
                "cc.SpriteFrame",
                1
            ],
            "39wi5bQNdGDrxcfIAuDh4G": [
                "DDSH_SDK/image/bannerNativeBg1.png",
                "cc.Texture2D"
            ],
            ef92nfTiVICY6nTu05LRYM: [
                "DDSH_SDK/image/bannerNativeBg2",
                "cc.SpriteFrame",
                1
            ],
            "00QCnfOMxIka1+m+KKALfC": [
                "DDSH_SDK/image/bannerNativeBg2.png",
                "cc.Texture2D"
            ],
            "941rnKxDFCfYPkWBRjsxN/": [
                "DDSH_SDK/image/bannerNativeBg3",
                "cc.SpriteFrame",
                1
            ],
            "582Dso86NIyIxxDyeZ5apc": [
                "DDSH_SDK/image/bannerNativeBg3.png",
                "cc.Texture2D"
            ],
            "1171d7DU9MKbASA3fxH6qQ": [
                "DDSH_SDK/image/bannerNativeBg4",
                "cc.SpriteFrame",
                1
            ],
            "71AHTI5NZA9YHSCfAKaphY": [
                "DDSH_SDK/image/bannerNativeBg4.png",
                "cc.Texture2D"
            ],
            "3evQ/ARqZMmYZNfcJlRc47": [
                "DDSH_SDK/image/bannerNativeBg5",
                "cc.SpriteFrame",
                1
            ],
            c05w1o6WtC86RD8cCeIIQf: [
                "DDSH_SDK/image/bannerNativeBg5.png",
                "cc.Texture2D"
            ],
            "8e3oWpzGNFvpM5rITOxFj6": [
                "DDSH_SDK/image/bannerNativeBtn",
                "cc.SpriteFrame",
                1
            ],
            "ec6UYa/hxKTJUCQRIogftm": [
                "DDSH_SDK/image/bannerNativeBtn.png",
                "cc.Texture2D"
            ],
            "97sM5ueFFI/a+7m4E4nkTH": [
                "DDSH_SDK/image/bannerNativeClose",
                "cc.SpriteFrame",
                1
            ],
            "1bMe+0Xu5FYbJobmfTF8FI": [
                "DDSH_SDK/image/bannerNativeClose.png",
                "cc.Texture2D"
            ],
            "17ExZl4SVK0bR7tKUzKqUw": [
                "DDSH_SDK/image/bg",
                "cc.SpriteFrame",
                1
            ],
            c2lFa5mrRE6IEPazfRhPLN: [
                "DDSH_SDK/image/bg.png",
                "cc.Texture2D"
            ],
            "81yEy4C3tGxJYo1KMuXeVB": [
                "DDSH_SDK/image/close",
                "cc.SpriteFrame",
                1
            ],
            b2P8Mm0iRBDa1KXUMdnhrv: [
                "DDSH_SDK/image/close.png",
                "cc.Texture2D"
            ],
            "d2+UHahtFPP7Ti+IVOUlad": [
                "DDSH_SDK/image/img_banner_blank",
                "cc.SpriteFrame",
                1
            ],
            "1cFLApuwxGwKf4SCssikWe": [
                "DDSH_SDK/image/img_banner_blank.png",
                "cc.Texture2D"
            ],
            "3dTuhsZINE3LgM1+Rcx0zq": [
                "DDSH_SDK/image/img_click_look",
                "cc.SpriteFrame",
                1
            ],
            "96TOgI4/5MWaiXHdpEbhJq": [
                "DDSH_SDK/image/img_click_look.png",
                "cc.Texture2D"
            ],
            "22zgmdSrZNLL/7YylqsZO/": [
                "DDSH_SDK/image/img_close1",
                "cc.SpriteFrame",
                1
            ],
            "0eYAitQ6dKQahUIwG9pS0X": [
                "DDSH_SDK/image/img_close1.png",
                "cc.Texture2D"
            ],
            "bfUK3sXX1IkIbWYO056bf+": [
                "DDSH_SDK/image/img_close2",
                "cc.SpriteFrame",
                1
            ],
            "757IMoHdVAQ43aAte2WXlE": [
                "DDSH_SDK/image/img_close2.png",
                "cc.Texture2D"
            ],
            acyWGoZsNEr6fuuiXTxZB9: [
                "DDSH_SDK/image/img_close3",
                "cc.SpriteFrame",
                1
            ],
            d3aLo3trFJD6IsYM0BCNuX: [
                "DDSH_SDK/image/img_close3.png",
                "cc.Texture2D"
            ],
            c1XHorWfZM57WBpgh2OulP: [
                "DDSH_SDK/image/native_insters_layerBg",
                "cc.SpriteFrame",
                1
            ],
            "83YjLkSwhG96FPggBsRDIn": [
                "DDSH_SDK/image/native_insters_layerBg.png",
                "cc.Texture2D"
            ],
            "2cExVqW2xMwrOBFDF+VbCH": [
                "DDSH_SDK/image/touch",
                "cc.SpriteFrame",
                1
            ],
            "13PRkxmyhJzq9sudXD0Vlr": [
                "DDSH_SDK/image/touch.png",
                "cc.Texture2D"
            ],
            "f7iBCccEJJsKk1/CuOBAbv": [
                "DDSH_SDK/image/zz_black",
                "cc.SpriteFrame",
                1
            ],
            "0eXPDZ7cFJs4d4I6ngXl8p": [
                "DDSH_SDK/image/zz_black.png",
                "cc.Texture2D"
            ],
            d31l2yKlRG3Kn2cZfEwClm: [
                "DDSH_SDK/native_bannernew.prefab",
                "cc.Prefab"
            ],
            "c62HmXeItLv4+qVtyXkmXP": [
                "DDSH_SDK/nativeinterAD.prefab",
                "cc.Prefab"
            ],
            "c6Q2QvD1tOZar/trSNLPoW": [
                "Mutual_new/CenterPanel/centerItem.prefab",
                "cc.Prefab"
            ],
            "a92CDf/SxBQam3Dd9tEycr": [
                "Mutual_new/CenterPanel/res/icon",
                "cc.SpriteFrame",
                1
            ],
            "c7H1La+7hK6ZyCLkpK5Xd2": [
                "Mutual_new/CenterPanel/res/icon.png",
                "cc.Texture2D"
            ],
            be3h0MYIJP6YcykLqP0FJP: [
                "Mutual_new/CenterPanel/res/kuang",
                "cc.SpriteFrame",
                1
            ],
            "3aeSXBgblOGLmTkCxSHSDD": [
                "Mutual_new/CenterPanel/res/kuang.png",
                "cc.Texture2D"
            ],
            f2GwJAvmlPGJE08YweWApu: [
                "alert_bg2877",
                "cc.SpriteFrame",
                1
            ],
            "634rUplNJE+papGQg1p/Jo": [
                "alert_bg2877.png",
                "cc.Texture2D"
            ],
            f6BjoMLzlE36iKGoygYaSt: [
                "anim/effect/Boom.anim",
                "cc.AnimationClip"
            ],
            cb148RnKlGhr5JRu28JMHD: [
                "anim/enemy/attack.anim",
                "cc.AnimationClip"
            ],
            "86JbwVgPlCYLPI0HxsPkDm": [
                "anim/enemy/guard.anim",
                "cc.AnimationClip"
            ],
            faJmxWhzxAs5tMp31RQSft: [
                "anim/enemy/idle.anim",
                "cc.AnimationClip"
            ],
            "03FQFpLzxNEYnk5ECepZCi": [
                "anim/enemy/walk.anim",
                "cc.AnimationClip"
            ],
            "2a91nmGvhN647ww+2IbAgf": [
                "aslogo",
                "cc.SpriteFrame",
                1
            ],
            "7c8si8SfNAbrTBZfqveR4C": [
                "aslogo.png",
                "cc.Texture2D"
            ],
            "7fSxm0l2tH9pRR5itihCwm": [
                "back4532",
                "cc.SpriteFrame",
                1
            ],
            "3b7chbJxBLiIuRiSFasrC+": [
                "back4532.png",
                "cc.Texture2D"
            ],
            "8fpwak6/pDlrtXwdDgNQ+K": [
                "bar18625",
                "cc.SpriteFrame",
                1
            ],
            "87AtXG5+RM652Gb5VhgWLt": [
                "bar18625.png",
                "cc.Texture2D"
            ],
            "6bwLq0kyVAxrsawo1Q/syU": [
                "bar29156",
                "cc.SpriteFrame",
                1
            ],
            e4oG15Z09L05hZvrmIHr32: [
                "bar29156.png",
                "cc.Texture2D"
            ],
            "81eYhrnqlEo7++3US4irOQ": [
                "bg10912",
                "cc.SpriteFrame",
                1
            ],
            cfAlbpQgZPHKPwza284m7H: [
                "bg10912.jpg",
                "cc.Texture2D"
            ],
            fd3j3ibbxPKKrzyHFZnAhH: [
                "bullet10944",
                "cc.SpriteFrame",
                1
            ],
            "1bz81vIcpN1aHpuX3LhzXE": [
                "bullet10944.png",
                "cc.Texture2D"
            ],
            "89wdWDeIZBp7WUJWsq9+2D": [
                "bullet4757",
                "cc.SpriteFrame",
                1
            ],
            b8gZp2eKlN4JxHk2VpcTs3: [
                "bullet4757.png",
                "cc.Texture2D"
            ],
            "c5TYm+URZFK6rkqxOEv+NG": [
                "button11239",
                "cc.SpriteFrame",
                1
            ],
            "edyC3E/NRNl7ELWBM92Uv2": [
                "button11239.png",
                "cc.Texture2D"
            ],
            "04SZR5Ph5P3rSTuq5FILkt": [
                "button21220",
                "cc.SpriteFrame",
                1
            ],
            "99griAddFD9Yxz218V62NX": [
                "button21220.png",
                "cc.Texture2D"
            ],
            "42vamRVLdFybVkvn3t+Zwz": [
                "button33866",
                "cc.SpriteFrame",
                1
            ],
            f1oiVrqVpALLxOCN0bQgyR: [
                "button33866.png",
                "cc.Texture2D"
            ],
            f842b72WNNjrnnrjXm33Yf: [
                "config/level1.json",
                "cc.JsonAsset"
            ],
            d1dUdpOVxPGK42RUx3sim4: [
                "config/level10.json",
                "cc.JsonAsset"
            ],
            "26Gk3dVvZJsplover7h1zi": [
                "config/level2.json",
                "cc.JsonAsset"
            ],
            "57JQuByShB1IBjs/06xkPZ": [
                "config/level3.json",
                "cc.JsonAsset"
            ],
            "71w3OXCSRBi4EW16E2q8+w": [
                "config/level4.json",
                "cc.JsonAsset"
            ],
            "75eeQ81oRM6qEgkHdYg1cw": [
                "config/level5.json",
                "cc.JsonAsset"
            ],
            "737Ae5IvhISY2Wj6K3Fr4s": [
                "config/level6.json",
                "cc.JsonAsset"
            ],
            "9ePZxwyiZHT6zl5DL26f4x": [
                "config/level7.json",
                "cc.JsonAsset"
            ],
            "632MZW8hpNjpN5UgwVs2El": [
                "config/level8.json",
                "cc.JsonAsset"
            ],
            "dbeomaPqtJab13QNV/sTow": [
                "config/level9.json",
                "cc.JsonAsset"
            ],
            "09K8SiSmdAVJXSFUEgN79g": [
                "config/map1.json",
                "cc.JsonAsset"
            ],
            "a1SlVB1+JJaZcR97NsXFL8": [
                "config/map10.json",
                "cc.JsonAsset"
            ],
            "eeXcfWNKNFUpsKc/9jUlnh": [
                "config/map2.json",
                "cc.JsonAsset"
            ],
            "6fPeZI0aJFZ7jpumT1l8R3": [
                "config/map3.json",
                "cc.JsonAsset"
            ],
            "b91jBJVUVFrZy/mhvrBpld": [
                "config/map4.json",
                "cc.JsonAsset"
            ],
            fa9DEGRm5E6qS8G2Lp2v70: [
                "config/map5.json",
                "cc.JsonAsset"
            ],
            e1a0iCwo1Ak5N5HkIRt2Wc: [
                "config/map6.json",
                "cc.JsonAsset"
            ],
            "20NdFzcGVCHoHuo+6qe+Fo": [
                "config/map7.json",
                "cc.JsonAsset"
            ],
            "2aH6EkKttFTbM1zx9650FV": [
                "config/map8.json",
                "cc.JsonAsset"
            ],
            "077LEOoa5LJrhl8IEGn50r": [
                "config/map9.json",
                "cc.JsonAsset"
            ],
            "80xZGSvetGVJAbc8RlaOd9": [
                "config/sdkConfig.json",
                "cc.JsonAsset"
            ],
            "96xpmKGsZB9LZJgqrS/HyH": [
                "config/skinInfo.json",
                "cc.JsonAsset"
            ],
            "1cYxPzCV9GMbG3QC9B6QiJ": [
                "config/tileConfig.json",
                "cc.JsonAsset"
            ],
            b2PshklWpNrZYOFab4UpvB: [
                "default_btn_normal10700",
                "cc.SpriteFrame",
                1
            ],
            "1anee76NhAh6UfEw5DjlOL": [
                "default_btn_normal10700.png",
                "cc.Texture2D"
            ],
            "6d39idOBNF8p9sQwg2lZ8t": [
                "default_btn_normal4706",
                "cc.SpriteFrame",
                1
            ],
            "42ncWidftHaL18E7f6zLRg": [
                "default_btn_normal4706.png",
                "cc.Texture2D"
            ],
            ff51U4fOZGrIvBkVPMGUuv: [
                "default_btn_normal7944",
                "cc.SpriteFrame",
                1
            ],
            fdmZXGatJP6q1rLKE1YaML: [
                "default_btn_normal7944.png",
                "cc.Texture2D"
            ],
            "41Z9TtcFdNUZ686Z465Fed": [
                "default_sprite6695",
                "cc.SpriteFrame",
                1
            ],
            e0ToYJbrVM4akOzdj5wdce: [
                "default_sprite6695.png",
                "cc.Texture2D"
            ],
            b8FqQdDFFBgJNUDGb8rTmO: [
                "defeat_title5621",
                "cc.SpriteFrame",
                1
            ],
            d93iANoRtHaZo8wrGNzKlN: [
                "defeat_title5621.png",
                "cc.Texture2D"
            ],
            "6bpXkL14JBfJ0kKeQW0Xmi": [
                "defeat_title9651",
                "cc.SpriteFrame",
                1
            ],
            "3e0DsY7/REjKLbr+w74/Up": [
                "defeat_title9651.png",
                "cc.Texture2D"
            ],
            d2eaKvbbRM87dF9MLvrKAZ: [
                "emoteExclamationMark7008",
                "cc.SpriteFrame",
                1
            ],
            "4a72RVr1lPybiME5fAPLhK": [
                "emoteExclamationMark7008.png",
                "cc.Texture2D"
            ],
            eaFFM3nbRMtb8ZUbOPBDWH: [
                "emoteQuestionMark2330",
                "cc.SpriteFrame",
                1
            ],
            "d5QgaYicdEPYoEqbOe/JHO": [
                "emoteQuestionMark2330.png",
                "cc.Texture2D"
            ],
            "20MsNZ+lVL5IUu6DD9FWlF": [
                "empty1356",
                "cc.SpriteFrame",
                1
            ],
            "88tn/jEb1IUJjk+yo6qwK0": [
                "empty1356.png",
                "cc.Texture2D"
            ],
            "9745nN0WBLqZZo1MV8vQTk": [
                "font/font_02409",
                "cc.SpriteFrame",
                1
            ],
            "a24NCOHKpN57RiXtNBYb6+": [
                "font/font_02409.png",
                "cc.Texture2D"
            ],
            dbloMXdrlNUowzCYwFacmB: [
                "font/number4148",
                "cc.SpriteFrame",
                1
            ],
            "9en5F4srpOHI8X9E1Bbae9": [
                "font/number4148.png",
                "cc.Texture2D"
            ],
            "2eMFY3AGdNqryT511eW/ri": [
                "gemTrail4749",
                "cc.SpriteFrame",
                1
            ],
            "51C5ryxedI3aJ8Vt3wncVQ": [
                "gemTrail4749.png",
                "cc.Texture2D"
            ],
            "d21t4LVIBJrL0/PiZhZ8fW": [
                "gemTrailEnd2346",
                "cc.SpriteFrame",
                1
            ],
            f3bGMDF49IZoS6H4ahZhCT: [
                "gemTrailEnd2346.png",
                "cc.Texture2D"
            ],
            "3brYHGOfFCxJQcNH0xOv8t": [
                "gold_bg9253",
                "cc.SpriteFrame",
                1
            ],
            "8d6jKdFOdKGKdQX7zrPBtA": [
                "gold_bg9253.png",
                "cc.Texture2D"
            ],
            "6eCd0//qBJjJlJz8A8enOq": [
                "guard6416",
                "cc.SpriteFrame",
                1
            ],
            "530sRcsDVHo5EKB+R4WWxZ": [
                "guard6416.png",
                "cc.Texture2D"
            ],
            "d88S2e7qVF35BIO+feQ0hT": [
                "guardLeg10571",
                "cc.SpriteFrame",
                1
            ],
            "f6W81fY5ZPloe+9lE8p29q": [
                "guardLeg10571.png",
                "cc.Texture2D"
            ],
            "22i4pdfflN97m3ljPi1f64": [
                "gui/DefeatUI.prefab",
                "cc.Prefab"
            ],
            "320AdX0oFIk4hfJuQ8glSu": [
                "gui/GameOverUI.prefab",
                "cc.Prefab"
            ],
            c2w5HoEaVEPqfTU6LkLigD: [
                "gui/LoadScreen.prefab",
                "cc.Prefab"
            ],
            c50jRSb3dMq7Wgg1IqMUE4: [
                "gui/MainUI.prefab",
                "cc.Prefab"
            ],
            a2oiWwVZZL3aC1S84uKdw9: [
                "gui/ReviveUI.prefab",
                "cc.Prefab"
            ],
            "0a+3wxuIhIs6kLVc8ghDJ0": [
                "gui/RewardUI.prefab",
                "cc.Prefab"
            ],
            "6b41q93ydIiavXjcYuRkb3": [
                "gui/SceneUI.prefab",
                "cc.Prefab"
            ],
            "89ffmN2rtD/YKdx8hWqAnq": [
                "gui/SkinTestUI.prefab",
                "cc.Prefab"
            ],
            "50vDMOP+FCopaTF62HWE8V": [
                "gui/SkinUI.prefab",
                "cc.Prefab"
            ],
            "7byI2AontENZRbjEqz9hp2": [
                "gui/SuccessUI.prefab",
                "cc.Prefab"
            ],
            "8ecZ48HPJNDqZox+p8i2Id": [
                "gui/SystemUI.prefab",
                "cc.Prefab"
            ],
            "38iYO6GBhMabofR1h5jrO+": [
                "hand10197",
                "cc.SpriteFrame",
                1
            ],
            "bcDa0mV8tD/bkIls1Z/V7O": [
                "hand10197.png",
                "cc.Texture2D"
            ],
            acr30KhsdBFYdxmFzjP0l8: [
                "logo3501",
                "cc.SpriteFrame",
                1
            ],
            d2et9Ok35JzZMljMXNl6s7: [
                "logo3501.png",
                "cc.Texture2D"
            ],
            f79PgXeWVP75AAHBY9roDx: [
                "main_arrow5121",
                "cc.SpriteFrame",
                1
            ],
            "76Go1eUElEXIPDTta7Q1Lp": [
                "main_arrow5121.png",
                "cc.Texture2D"
            ],
            "96FcA8z61LUL65R8Nm2J9M": [
                "main_bar15686",
                "cc.SpriteFrame",
                1
            ],
            "5be41h5rtEQKmkT1koCBu0": [
                "main_bar15686.png",
                "cc.Texture2D"
            ],
            f1SH76jZhELafmmNYGb7iy: [
                "main_bar29088",
                "cc.SpriteFrame",
                1
            ],
            "51zUaLjVZNjYnXHZhnU1du": [
                "main_bar29088.png",
                "cc.Texture2D"
            ],
            "64dhM/zw5MFaMoeAA7upnd": [
                "main_daily_gold6385",
                "cc.SpriteFrame",
                1
            ],
            "6akrT6fx5CEqgTGtJXosS4": [
                "main_daily_gold6385.png",
                "cc.Texture2D"
            ],
            "cdnfiK9EtPs5aF+PoQmGmB": [
                "main_list5375",
                "cc.SpriteFrame",
                1
            ],
            "9fioFvQK5CA4z1fWViHAfA": [
                "main_list5375.png",
                "cc.Texture2D"
            ],
            "4awDPZL5RKiqlXo0dD7EGQ": [
                "mask10028",
                "cc.SpriteFrame",
                1
            ],
            d3Vq87zFlAgIFGUzxvq2SU: [
                "mask10028.png",
                "cc.Texture2D"
            ],
            "17pIGSPwZJXYnc2bkZGLQa": [
                "music/break1.mp3",
                "cc.AudioClip"
            ],
            "b97g/qigFGWKTraAb+OZ6a": [
                "music/break2.mp3",
                "cc.AudioClip"
            ],
            "f1VHIBK1hGepybvOU7d/pi": [
                "music/break3.mp3",
                "cc.AudioClip"
            ],
            "26oRdRN3tH45GW+pnA1rnf": [
                "music/click.mp3",
                "cc.AudioClip"
            ],
            "40ANO8pnpKOqIAthQ03ctS": [
                "music/damage.mp3",
                "cc.AudioClip"
            ],
            "8a3rh9mQFCg4tI/MLX5rOj": [
                "music/die1.mp3",
                "cc.AudioClip"
            ],
            "87KHcEGlpNyp2UoMBviyQR": [
                "music/rifle1.mp3",
                "cc.AudioClip"
            ],
            "38Qr4akZNFEJQLL1Bnamml": [
                "music/rifle2.mp3",
                "cc.AudioClip"
            ],
            "eenIQ/25dCBrnpSbZHsiAE": [
                "music/rifle3.mp3",
                "cc.AudioClip"
            ],
            f7O5P100pK7YJEtf4bCpg9: [
                "music/rifle4.mp3",
                "cc.AudioClip"
            ],
            "38vFRfNptA1pS/hNLktrGI": [
                "muzzleFlashRound3478",
                "cc.SpriteFrame",
                1
            ],
            "840R16aHZMxISkkUqz9UIu": [
                "muzzleFlashRound3478.png",
                "cc.Texture2D"
            ],
            f9bkYXhexHdZ2JMZDD3wpe: [
                "ninja/wallhaven-qdqvxl",
                "cc.SpriteFrame",
                1
            ],
            "22RcOSPEhHP7Xt5knmI+mC": [
                "ninja/wallhaven-qdqvxl.jpg",
                "cc.Texture2D"
            ],
            "09EK34onpIhLVPrZl7LQfI": [
                "nothing10965",
                "cc.SpriteFrame",
                1
            ],
            "39r7ZDyMNF26zkHpzo+N8f": [
                "nothing10965.png",
                "cc.Texture2D"
            ],
            "77M24og4xBerfBDNBrdUGV": [
                "objectiveLoading8659",
                "cc.SpriteFrame",
                1
            ],
            "2atcHoJ8hFZK0F+V5UHacJ": [
                "objectiveLoading8659.png",
                "cc.Texture2D"
            ],
            "ddgBpit+9BMp+XggckNF4E": [
                "plist/common.plist",
                "cc.SpriteAtlas"
            ],
            bber9idBlF9Idt0PLrzGlc: [
                "plist/common.png",
                "cc.Texture2D"
            ],
            "8e+/U6TnVPEKe38m5iO2Gr": [
                "plist/tiles.plist",
                "cc.SpriteAtlas"
            ],
            "ecWBMRRGJK6aVv865uDk+C": [
                "plist/tiles.png",
                "cc.Texture2D"
            ],
            "43sF9uo+pPpKWPCu6HjBVW": [
                "point7439",
                "cc.SpriteFrame",
                1
            ],
            "16ILU971dEKYTHhBem2igr": [
                "point7439.png",
                "cc.Texture2D"
            ],
            "b3ts0Z65BAErDtM+zS1EqU": [
                "prefab/Bullet.prefab",
                "cc.Prefab"
            ],
            "32M4Sd0QhLSYwxSVWVYRXj": [
                "prefab/Gem.prefab",
                "cc.Prefab"
            ],
            "cfv+c1vZdIuLDeFk8OWQwR": [
                "prefab/GemLabel.prefab",
                "cc.Prefab"
            ],
            a85oeWbcdB2ZL0lWQ0K1Pg: [
                "prefab/Monster.prefab",
                "cc.Prefab"
            ],
            "80LHODegtLPIO8XfsWFovZ": [
                "prefab/Player.prefab",
                "cc.Prefab"
            ],
            "da/Ys1yYBJ34KOwweyXEKT": [
                "prefab/Scene.prefab",
                "cc.Prefab"
            ],
            "2cO/sXe/tJmpExM+zMJrrK": [
                "quick_yinsi/Root.prefab",
                "cc.Prefab"
            ],
            efIlJTyi5AiJmIBA2fVtDn: [
                "quick_yinsi/bggg",
                "cc.SpriteFrame",
                1
            ],
            d5jf9ZSI5HvbwoX17tZPJP: [
                "quick_yinsi/bggg.png",
                "cc.Texture2D"
            ],
            "b5/ZbydA1B5a04Bb/vAEf2": [
                "quick_yinsi/img_bgbtn",
                "cc.SpriteFrame",
                1
            ],
            "556ZTN3N9PeJozvDWbaQzN": [
                "quick_yinsi/img_bgbtn.png",
                "cc.Texture2D"
            ],
            "6d8+uuHmBFOLcOTTJ8GL+H": [
                "rank_start2106",
                "cc.SpriteFrame",
                1
            ],
            "94IDTE/eBJGbEnJZmInTjc": [
                "rank_start2106.png",
                "cc.Texture2D"
            ],
            "24nJi6tihHGKRQ9YauYn2M": [
                "rank_toggle16009",
                "cc.SpriteFrame",
                1
            ],
            "19uqRUX/FDg46/PO7bMEl2": [
                "rank_toggle16009.png",
                "cc.Texture2D"
            ],
            d8zXj1dg5Fp6nLNjupSwet: [
                "rank_toggle17000",
                "cc.SpriteFrame",
                1
            ],
            "f4jrrxMc9D4L6/preKDmSR": [
                "rank_toggle17000.png",
                "cc.Texture2D"
            ],
            cdlhd3lLZDsKv2ch33cqHS: [
                "rank_toggle23350",
                "cc.SpriteFrame",
                1
            ],
            "73VZsIkp5Hw5nEYA7xndZH": [
                "rank_toggle23350.png",
                "cc.Texture2D"
            ],
            baBVfLzg1KjI1euiudec2E: [
                "rank_toggle28217",
                "cc.SpriteFrame",
                1
            ],
            "69JxAkd7RJdaa0zT2gckzm": [
                "rank_toggle28217.png",
                "cc.Texture2D"
            ],
            "13G/+JZH1KaoOvSCsZJSaW": [
                "revive_skip_text8974",
                "cc.SpriteFrame",
                1
            ],
            "67jq33GoRJeKMAILozSwLw": [
                "revive_skip_text8974.png",
                "cc.Texture2D"
            ],
            e7Z9uYwVJLI7mdMFM6nhBG: [
                "revive_video_text1496",
                "cc.SpriteFrame",
                1
            ],
            "ab+a9NTsFHeazVNbBBfo0l": [
                "revive_video_text1496.png",
                "cc.Texture2D"
            ],
            "3f4/7YIoBAbqrmq5mZDALe": [
                "reward_get2527",
                "cc.SpriteFrame",
                1
            ],
            "23UZt/xSJJ+5yM3FzYnsXx": [
                "reward_get2527.png",
                "cc.Texture2D"
            ],
            "3bcHC3BjJIcKqLiNDDYWZJ": [
                "reward_get7324",
                "cc.SpriteFrame",
                1
            ],
            "2aOHP3NhlPAomVvGjdIx7r": [
                "reward_get7324.png",
                "cc.Texture2D"
            ],
            "5eC0+Ro6VFK4BUu/22vjty": [
                "reward_get_32340",
                "cc.SpriteFrame",
                1
            ],
            "79v5L2OAZHjbb2yQ/kQs1T": [
                "reward_get_32340.png",
                "cc.Texture2D"
            ],
            "54HD7Jd89He6W+ASZ/G9mP": [
                "reward_title6071",
                "cc.SpriteFrame",
                1
            ],
            "08dMA/M1lOgZUa/LXl9bex": [
                "reward_title6071.png",
                "cc.Texture2D"
            ],
            c2RnyC1ERKEoBbnLG57oP3: [
                "scene_golden4682",
                "cc.SpriteFrame",
                1
            ],
            "1b2Jm8OsFA4rKZwFButAYO": [
                "scene_golden4682.png",
                "cc.Texture2D"
            ],
            "3foSrQK2hE8LNN802dDB3I": [
                "skin_bg16706",
                "cc.SpriteFrame",
                1
            ],
            "6f+7zXKI9HkaaYFIXtY6xK": [
                "skin_bg16706.png",
                "cc.Texture2D"
            ],
            "baO+mUuI1BRaboEd7YRKSn": [
                "skin_bg17355",
                "cc.SpriteFrame",
                1
            ],
            "05O0+u81BEMJyMv062eX1k": [
                "skin_bg17355.png",
                "cc.Texture2D"
            ],
            "79fg6oPitNAbhg4V+PPz/z": [
                "skin_bg4819",
                "cc.SpriteFrame",
                1
            ],
            "07ZhPnBbNDGLFT+OeunS6R": [
                "skin_bg4819.png",
                "cc.Texture2D"
            ],
            "2366M7/FFKjaX8xTEGuqlT": [
                "smoke6982",
                "cc.SpriteFrame",
                1
            ],
            "62idNCyMxPpbx08z9FFvZD": [
                "smoke6982.png",
                "cc.Texture2D"
            ],
            "98qhb14Q5J27/L+HVBrrtZ": [
                "stone28591",
                "cc.SpriteFrame",
                1
            ],
            "94lJimxa1MzLWHEWBaR6oN": [
                "stone28591.png",
                "cc.Texture2D"
            ],
            "382hcGoV5G/p8R7hHewp/H": [
                "success_button5879",
                "cc.SpriteFrame",
                1
            ],
            "20PpydoMFGQZpCD4f2a5l0": [
                "success_button5879.png",
                "cc.Texture2D"
            ],
            "52zVS2RS5DUbmD7+zAbBg2": [
                "success_get_text10236",
                "cc.SpriteFrame",
                1
            ],
            "2av/dcm6lM9qIVbteSj5tW": [
                "success_get_text10236.png",
                "cc.Texture2D"
            ],
            "8cEJkbVDRCaqM2iB1MDSXW": [
                "success_main1108",
                "cc.SpriteFrame",
                1
            ],
            "67CkAqDPdBO7miFi6N30V5": [
                "success_main1108.png",
                "cc.Texture2D"
            ],
            "d8gLz3zgtHEJY8QPbT2ek/": [
                "success_retry6835",
                "cc.SpriteFrame",
                1
            ],
            b7OFkhopFBG7mxmEj5qycv: [
                "success_retry6835.png",
                "cc.Texture2D"
            ],
            "99p0IrhgtAjZ4mfRAN6o9P": [
                "success_retry8733",
                "cc.SpriteFrame",
                1
            ],
            "91BqyiJhNHlKD5pmZh0dtt": [
                "success_retry8733.png",
                "cc.Texture2D"
            ],
            "e97j6RgfZJn5/lHOCSrJD5": [
                "texture/muzzleFlash210476",
                "cc.SpriteFrame",
                1
            ],
            "b9i+aSkXVLv6xwYUrmhFAm": [
                "texture/muzzleFlash210476.png",
                "cc.Texture2D"
            ],
            "240FLA/ONAipiHOwaeicEn": [
                "texture/muzzleFlash2_012947",
                "cc.SpriteFrame",
                1
            ],
            "32tWkk+K5Jubw9qUhvOVez": [
                "texture/muzzleFlash2_012947.png",
                "cc.Texture2D"
            ],
            "22s4qlS0FASbiwMWNto1wu": [
                "texture/muzzleFlash2_013350",
                "cc.SpriteFrame",
                1
            ],
            "42F0jYPBVMGJKD83/Mgqpz": [
                "texture/muzzleFlash2_013350.png",
                "cc.Texture2D"
            ],
            "6c0Y7YSFlFtb28ab7ty94v": [
                "texture/trail10175",
                "cc.SpriteFrame",
                1
            ],
            f5GMK8Op5GAJHyPOCATFhC: [
                "texture/trail10175.png",
                "cc.Texture2D"
            ],
            "d3XTlc2QtK+IeRZtjKhpOy": [
                "texture/trail1540",
                "cc.SpriteFrame",
                1
            ],
            "8alUZU+C1DuL4b4yV2JoZQ": [
                "texture/trail1540.png",
                "cc.Texture2D"
            ],
            "2do2oEwatKMb9NAmWr/gFQ": [
                "title_bg12431",
                "cc.SpriteFrame",
                1
            ],
            "5bxp7tmShCy4DGByAX+U3u": [
                "title_bg12431.png",
                "cc.Texture2D"
            ],
            "90schKW7lPYLyd3SeqIQYH": [
                "title_bg26218",
                "cc.SpriteFrame",
                1
            ],
            "dcr2i+l3hPka/Thv6SjlFJ": [
                "title_bg26218.png",
                "cc.Texture2D"
            ],
            "eei26ZpjtDb77Pjfb7/LdQ": [
                "title_bg29637",
                "cc.SpriteFrame",
                1
            ],
            "3b9Ma0eTxPq7nBxs2vn1Bp": [
                "title_bg29637.png",
                "cc.Texture2D"
            ]
        },
        internal: {
            "14TDKXr2NJ6LjvHPops74o": [
                "effects/builtin-2d-gray-sprite.effect",
                "cc.EffectAsset"
            ],
            "0ek66qC1NOQLjgYmi04HvX": [
                "effects/builtin-2d-spine.effect",
                "cc.EffectAsset"
            ],
            "28dPjdQWxEQIG3VVl1Qm6T": [
                "effects/builtin-2d-sprite.effect",
                "cc.EffectAsset"
            ],
            c0BAyVxX9JzZy8EjFrc9DU: [
                "effects/builtin-clear-stencil.effect",
                "cc.EffectAsset"
            ],
            "796vrvt+9F2Zw/WR3INvx6": [
                "effects/builtin-unlit-transparent.effect",
                "cc.EffectAsset"
            ],
            "6dkeWRTOBGXICfYQ7JUBnG": [
                "effects/builtin-unlit.effect",
                "cc.EffectAsset"
            ],
            "6fgBCSDDdPMInvyNlggls2": [
                "materials/builtin-2d-base.mtl",
                "cc.Material"
            ],
            "3ae7efMv1CLq2ilvUY/tQi": [
                "materials/builtin-2d-gray-sprite.mtl",
                "cc.Material"
            ],
            "7a/QZLET9IDreTiBfRn2PD": [
                "materials/builtin-2d-spine.mtl",
                "cc.Material"
            ],
            "ecpdLyjvZBwrvm+cedCcQy": [
                "materials/builtin-2d-sprite.mtl",
                "cc.Material"
            ],
            cffgu4qBxEqa150o1DmRAy: [
                "materials/builtin-clear-stencil.mtl",
                "cc.Material"
            ],
            "2aKWBXJHxKHLvrBUi2yYZQ": [
                "materials/builtin-unlit.mtl",
                "cc.Material"
            ]
        }
    },
    jsList: [
        "assets/scripts/utils/AStar.e878b.js",
        "assets/scripts/utils/HttpHandler.98d17.js",
        "assets/scripts/utils/InfiniteMap.48306.js",
        "assets/scripts/utils/KKModule.f370f.js",
        "assets/scripts/utils/MD5.4e691.js",
        "assets/scripts/utils/MessageHandler.b7023.js",
        "assets/scripts/utils/NodePool.65296.js",
        "assets/scripts/utils/TimerHandler.f0a41.js",
        "assets/scripts/utils/Utils.621af.js"
    ],
    launchScene: "db://assets/scenes/Main.fire",
    scenes: [{
        url: "db://assets/scenes/Main.fire",
        uuid: "59QkMPTkhDT74P4TUq5hzH"
    }],
    packedAssets: {
        "017353d51": [
            "44DuW9fnxLxr3//FzQRc7z",
            "6b41q93ydIiavXjcYuRkb3",
            "c2RnyC1ERKEoBbnLG57oP3"
        ],
        "0177fa0e5": [
            "04SZR5Ph5P3rSTuq5FILkt",
            "05be20M4lGtLdrqpGeD0Lb",
            "20MsNZ+lVL5IUu6DD9FWlF",
            "2a91nmGvhN647ww+2IbAgf",
            "3brYHGOfFCxJQcNH0xOv8t",
            "42vamRVLdFybVkvn3t+Zwz",
            "64dhM/zw5MFaMoeAA7upnd",
            "80uQxqmcxN9I94bK19eMmB",
            "96FcA8z61LUL65R8Nm2J9M",
            "a2MjXRFdtLlYQ5ouAFv/+R",
            "a9S3SeiilIdrZveEpiqEDJ",
            "c5TYm+URZFK6rkqxOEv+NG",
            "c50jRSb3dMq7Wgg1IqMUE4",
            "cdnfiK9EtPs5aF+PoQmGmB",
            "ecY6bikRpKSYNHC6cI+58a",
            "f0BIwQ8D5Ml7nTNQbh1YlS",
            "f1SH76jZhELafmmNYGb7iy",
            "f7E2X/7t1Gx5vMUIYeICpk",
            "f79PgXeWVP75AAHBY9roDx",
            "f9bkYXhexHdZ2JMZDD3wpe"
        ],
        "01fbcfa3b": [
            "1fJfOMHTpDAKZbqv8hquPj",
            "27cb/QtcdFwYbp7Amh8lqC",
            "8ecZ48HPJNDqZox+p8i2Id",
            "a4NhyRHwhN4bJ63uK9fAl1",
            "d0bGpZjcBFhptErI6H2PzY",
            "fer9Zkt1VP1rP0S8a8Ef90"
        ],
        "0203a8610": [
            "20MsNZ+lVL5IUu6DD9FWlF",
            "2chAoT/npGG5tcauaTPNEV",
            "2do2oEwatKMb9NAmWr/gFQ",
            "4crRtg8KpNYa8UGnn3DmUj",
            "682vOvGa5ExpcRNJHH1iIX",
            "74BiZ8bKFEjKSEXX53ozML",
            "89ffmN2rtD/YKdx8hWqAnq",
            "c5TYm+URZFK6rkqxOEv+NG",
            "feLDIQu+JN0J9KRNjfNIgB"
        ],
        "030ec7ba2": [
            "20MsNZ+lVL5IUu6DD9FWlF",
            "22i4pdfflN97m3ljPi1f64",
            "7fSxm0l2tH9pRR5itihCwm",
            "c5TYm+URZFK6rkqxOEv+NG"
        ],
        "034f03d51": [
            "04NmHKXx9DEZp0WDzuVqD/",
            "240FLA/ONAipiHOwaeicEn",
            "38vFRfNptA1pS/hNLktrGI",
            "66oNA0eWxOe4zELd/roCRn",
            "6eCd0//qBJjJlJz8A8enOq",
            "a85oeWbcdB2ZL0lWQ0K1Pg",
            "d88S2e7qVF35BIO+feQ0hT"
        ],
        "0360fb3fb": [
            "86JbwVgPlCYLPI0HxsPkDm",
            "cb148RnKlGhr5JRu28JMHD",
            "faJmxWhzxAs5tMp31RQSft"
        ],
        "039a5d96c": [
            "a92CDf/SxBQam3Dd9tEycr",
            "be3h0MYIJP6YcykLqP0FJP",
            "c6Q2QvD1tOZar/trSNLPoW"
        ],
        "03de51e78": [
            "1171d7DU9MKbASA3fxH6qQ",
            "3dTuhsZINE3LgM1+Rcx0zq",
            "83JeQlZHJLk4CQFZKK6BGt",
            "8c20Sso/ZEn7NUfNSM+EBh",
            "bfUK3sXX1IkIbWYO056bf+",
            "f7iBCccEJJsKk1/CuOBAbv",
            "f8O/VuoGhEUpBFr9mlBcqm"
        ],
        "03f752870": [
            "03mwcX+35OX4E7a7sG9iyo",
            "20MsNZ+lVL5IUu6DD9FWlF",
            "2chAoT/npGG5tcauaTPNEV",
            "a2oiWwVZZL3aC1S84uKdw9",
            "c5TYm+URZFK6rkqxOEv+NG"
        ],
        "041db0b26": [
            "bfUK3sXX1IkIbWYO056bf+",
            "c1XHorWfZM57WBpgh2OulP",
            "d2+UHahtFPP7Ti+IVOUlad",
            "d31l2yKlRG3Kn2cZfEwClm",
            "f7iBCccEJJsKk1/CuOBAbv",
            "f8O/VuoGhEUpBFr9mlBcqm"
        ],
        "042e4c07a": [
            "02Zt9gxttHnbSHuEGNoswG",
            "03mwcX+35OX4E7a7sG9iyo",
            "04NmHKXx9DEZp0WDzuVqD/",
            "05be20M4lGtLdrqpGeD0Lb",
            "07BO/pnd1MHI4hUMSJTeG7",
            "0cV3tyLXpOC7Q1y5jQgO8s",
            "0eqO7kwxNH+rHj3HmiOGU0",
            "10sgYSzJ1IMYq6sEX7ympO",
            "12utJEzOZA9pVIsVAyLo7b",
            "13YPK4CANM1qIbun5Zn+ql",
            "15SOAw6yxNiLJOFj2KHI3m",
            "15+YZYLJ9IEIQ7lYBMR5mI",
            "1bst2YUuZNabSRRng3mFOM",
            "1cVRqs1ktLHInS88Ze2CIQ",
            "1fJfOMHTpDAKZbqv8hquPj",
            "21mVujSDhFX4KqDqLbOCp6",
            "27cb/QtcdFwYbp7Amh8lqC",
            "2azFEn8BhP1Z/9TvhTNWjr",
            "2chAoT/npGG5tcauaTPNEV",
            "2dkQ27hJJAIahQpUUYPqvs",
            "2e3kCtoBtLq4yx5N3sdsAr",
            "32l8nvvGJLYo4MbxdpMjG1",
            "33uFDTNoNA8bdTWgFN/rCP",
            "34uQvo4XhKPabj3zT/O9/e",
            "36SSV/KPBFyoW+v0ftrlEB",
            "38iSJhrwRMDKp9siMR1ZrI",
            "39CWJT0rpFCYTjYOuOVId4",
            "3aZFcJ6/VA95J3I9lJkQGI",
            "3a4ZWeVm5PAYBWQGMOb0ic",
            "422jN2LkNIDpQ+wVPMZACx",
            "44DuW9fnxLxr3//FzQRc7z",
            "48U7EfV8JMmIDf2kMFmPFq",
            "4crRtg8KpNYa8UGnn3DmUj",
            "59r8Ill5lIsZKeqBMinH8n",
            "5cXHATPRhC16RHyLEslAlh",
            "64sCIsexNBm5xpt2qiUYya",
            "66oNA0eWxOe4zELd/roCRn",
            "66pM2S3EdDQLrcpfcwkU8H",
            "682vOvGa5ExpcRNJHH1iIX",
            "6bk6wO6h1Ejo+mMV0aR2yh",
            "6ctqLsLg5IZqgrYCIu8qP8",
            "6evf3dOYZIZYZnNYvAS71j",
            "73zjOT8chONLMpPaBVG3jF",
            "74BiZ8bKFEjKSEXX53ozML",
            "76+EhKr/dF4LYRlM8b60LH",
            "78vInOXPBK6pHIfmY9oGPF",
            "7aKoqWBbtKY5Yhmywsp8tg",
            "7bVPzkOrVEH79Tq9LOqrNn",
            "7clrtPwqpDDI3K7QbhNnlV",
            "7dXqVMH9hJfLkupXEBmtcy",
            "7dw2LY6bhFfYdUHPnIGfu8",
            "7edNMlBzRGuJtgJ7BRrhEv",
            "80AGLf6qROxqff+mypjbBi",
            "80uQxqmcxN9I94bK19eMmB",
            "91xABit4RIspWOUhey6eWb",
            "93iHSTjsRLDJjjNU0dE9Nl",
            "9ajBDyQg5PC5AXuBGWgCUx",
            "9b5Xhyd0xL+YfQsmb2H8l+",
            "9eO29mBSZL+5oRpOLmbklF",
            "a0lN+D+PBMRZiu3p1AC30r",
            "a2JuicTY9Gv77fkZoAbm01",
            "a4NhyRHwhN4bJ63uK9fAl1",
            "a504ejkGtMSYWsEGnOpYHk",
            "a6lH9DmalE3aqEE4eWyouZ",
            "a7CACB5/dFTIcBv4zgJNKm",
            "a7Jq2y1apCv5DhDq+7v0Dk",
            "a7hpsigLVNOaWfZ/tL8u5h",
            "a70v6wSyRAFKcKFEg/dLKW",
            "a7866VaeJJYpixCP3WOf8G",
            "a9S3SeiilIdrZveEpiqEDJ",
            "abcj+qBFlKtpfg0nmqKVDs",
            "adVTrVQ9hNJo3ujqXvXZ1d",
            "af/i6SSixFMYd+qD9CcZcq",
            "b7yQNsHOBM6r+4VS2n6sX5",
            "bdIQBFSJBGAK/5wCae8iJZ",
            "bdMUxzhf5CfInawPY4vlqP",
            "c69y7yyS9Ly7/Vd/k8soHP",
            "c8kQ2N1wlDaosVE7zDomVW",
            "caODRfVD1Pfo6vv8pxdMDM",
            "cc16W5iDBBhZojRyyZPv7c",
            "cddUCgEZNPqqEFUB+JNlYx",
            "cdnJCJa7tIu5d8cUqCRg8o",
            "d0bGpZjcBFhptErI6H2PzY",
            "d1u/erBvNIo6H/xBdLau2J",
            "d1vILrdLJBrINUzBqqZILt",
            "d3ecPe6TZLGrRBCyReG/bg",
            "d5ZhO8aOpEvYvEXrh5bW18",
            "d9GopViWZPmZC1zyhEm+k9",
            "ddgBpit+9BMp+XggckNF4E",
            "e2GWCiwSBAVIqCUfz3RFwP",
            "e2OfeoAeFPvKxpfPuQn9UT",
            "e3Er9q3spIAJqhM444ocFt",
            "e53MShfZdMm6wD2orLAHp/",
            "e8MpCRL/1Bzbro58zMfxc3",
            "eaMAGs4gtGHKs09EOWhXIy",
            "ecY6bikRpKSYNHC6cI+58a",
            "edEphBdt9N1r+YZl6sJ3x6",
            "ed98wD0iJFW6/pdS0EGxgJ",
            "ed+2OE3HNDv4ST6p5jLJEc",
            "f3O7lARZFKmrrr6q9D+i6f",
            "f4mxnQ0YJP4qs0C4MfiQNq",
            "f6Z6hvrO1MYq7hFu/V2bzz",
            "f6xD65bL5Pjq6q+l1seZSH",
            "f7E2X/7t1Gx5vMUIYeICpk",
            "f8jOkQ601OTpn4MNBHQA0H",
            "f8k1y9s/VGSI/IXTUDFmg4",
            "f9lp/FpgZMV5/ummRKfWqs",
            "f9/n+JP7lCwo37FhlVC4PN",
            "fbJcf34dNEFrkoY8gQwCgj",
            "feLDIQu+JN0J9KRNjfNIgB",
            "fer9Zkt1VP1rP0S8a8Ef90",
            "ffTsJ7wDZP17DBXbwJ69if"
        ],
        "046fae152": [
            "20MsNZ+lVL5IUu6DD9FWlF",
            "da/Ys1yYBJ34KOwweyXEKT"
        ],
        "04b8c8f40": [
            "05be20M4lGtLdrqpGeD0Lb",
            "20MsNZ+lVL5IUu6DD9FWlF",
            "2chAoT/npGG5tcauaTPNEV",
            "320AdX0oFIk4hfJuQ8glSu",
            "36SSV/KPBFyoW+v0ftrlEB",
            "3aZFcJ6/VA95J3I9lJkQGI",
            "90schKW7lPYLyd3SeqIQYH",
            "c5TYm+URZFK6rkqxOEv+NG",
            "f6xD65bL5Pjq6q+l1seZSH"
        ],
        "0550170bb": [
            "3dTuhsZINE3LgM1+Rcx0zq",
            "bfUK3sXX1IkIbWYO056bf+",
            "c1XHorWfZM57WBpgh2OulP",
            "c62HmXeItLv4+qVtyXkmXP",
            "d2+UHahtFPP7Ti+IVOUlad",
            "f7iBCccEJJsKk1/CuOBAbv",
            "f8O/VuoGhEUpBFr9mlBcqm"
        ],
        "05f8bb0be": [
            "00QCnfOMxIka1+m+KKALfC",
            "02delMVqdBD70a/HSD99FK",
            "05O0+u81BEMJyMv062eX1k",
            "07ZhPnBbNDGLFT+OeunS6R",
            "08dMA/M1lOgZUa/LXl9bex",
            "0eXPDZ7cFJs4d4I6ngXl8p",
            "0eYAitQ6dKQahUIwG9pS0X",
            "13PRkxmyhJzq9sudXD0Vlr",
            "16ILU971dEKYTHhBem2igr",
            "19uqRUX/FDg46/PO7bMEl2",
            "1anee76NhAh6UfEw5DjlOL",
            "1bMe+0Xu5FYbJobmfTF8FI",
            "1bz81vIcpN1aHpuX3LhzXE",
            "1b2Jm8OsFA4rKZwFButAYO",
            "1cFLApuwxGwKf4SCssikWe",
            "20PpydoMFGQZpCD4f2a5l0",
            "22RcOSPEhHP7Xt5knmI+mC",
            "23UZt/xSJJ+5yM3FzYnsXx",
            "2aOHP3NhlPAomVvGjdIx7r",
            "2atcHoJ8hFZK0F+V5UHacJ",
            "2av/dcm6lM9qIVbteSj5tW",
            "32tWkk+K5Jubw9qUhvOVez",
            "39r7ZDyMNF26zkHpzo+N8f",
            "39wi5bQNdGDrxcfIAuDh4G",
            "3aeSXBgblOGLmTkCxSHSDD",
            "3b7chbJxBLiIuRiSFasrC+",
            "3b9Ma0eTxPq7nBxs2vn1Bp",
            "3eZ6idK5BDIZoMvZW9Aiy7",
            "3e0DsY7/REjKLbr+w74/Up",
            "42F0jYPBVMGJKD83/Mgqpz",
            "42ncWidftHaL18E7f6zLRg",
            "4a72RVr1lPybiME5fAPLhK",
            "51C5ryxedI3aJ8Vt3wncVQ",
            "51pV8xrghC3ZWcfXxiLz/Y",
            "51zUaLjVZNjYnXHZhnU1du",
            "530sRcsDVHo5EKB+R4WWxZ",
            "556ZTN3N9PeJozvDWbaQzN",
            "582Dso86NIyIxxDyeZ5apc",
            "5be41h5rtEQKmkT1koCBu0",
            "5bxp7tmShCy4DGByAX+U3u",
            "62idNCyMxPpbx08z9FFvZD",
            "634rUplNJE+papGQg1p/Jo",
            "67CkAqDPdBO7miFi6N30V5",
            "67jq33GoRJeKMAILozSwLw",
            "69JxAkd7RJdaa0zT2gckzm",
            "6akrT6fx5CEqgTGtJXosS4",
            "6eBWFz0oVHPLIGQKf/9Thu",
            "6f+7zXKI9HkaaYFIXtY6xK",
            "71AHTI5NZA9YHSCfAKaphY",
            "71VhFCTINJM6/Ky3oX9nBT",
            "73VZsIkp5Hw5nEYA7xndZH",
            "757IMoHdVAQ43aAte2WXlE",
            "76Go1eUElEXIPDTta7Q1Lp",
            "79v5L2OAZHjbb2yQ/kQs1T",
            "7c8si8SfNAbrTBZfqveR4C",
            "83YjLkSwhG96FPggBsRDIn",
            "840R16aHZMxISkkUqz9UIu",
            "87AtXG5+RM652Gb5VhgWLt",
            "88tn/jEb1IUJjk+yo6qwK0",
            "8alUZU+C1DuL4b4yV2JoZQ",
            "8d6jKdFOdKGKdQX7zrPBtA",
            "91BqyiJhNHlKD5pmZh0dtt",
            "94IDTE/eBJGbEnJZmInTjc",
            "94lJimxa1MzLWHEWBaR6oN",
            "96TOgI4/5MWaiXHdpEbhJq",
            "99griAddFD9Yxz218V62NX",
            "9en5F4srpOHI8X9E1Bbae9",
            "9fioFvQK5CA4z1fWViHAfA",
            "a24NCOHKpN57RiXtNBYb6+",
            "ab+a9NTsFHeazVNbBBfo0l",
            "b2P8Mm0iRBDa1KXUMdnhrv",
            "b4P/PCArtIdIH38t6mlw8Y",
            "b7OFkhopFBG7mxmEj5qycv",
            "b8gZp2eKlN4JxHk2VpcTs3",
            "b9i+aSkXVLv6xwYUrmhFAm",
            "bber9idBlF9Idt0PLrzGlc",
            "bcDa0mV8tD/bkIls1Z/V7O",
            "c05w1o6WtC86RD8cCeIIQf",
            "c2lFa5mrRE6IEPazfRhPLN",
            "c7H1La+7hK6ZyCLkpK5Xd2",
            "cfAlbpQgZPHKPwza284m7H",
            "d2et9Ok35JzZMljMXNl6s7",
            "d3Vq87zFlAgIFGUzxvq2SU",
            "d3aLo3trFJD6IsYM0BCNuX",
            "d5QgaYicdEPYoEqbOe/JHO",
            "d5jf9ZSI5HvbwoX17tZPJP",
            "d8HsitJHxOYqo801xBk8ev",
            "d93iANoRtHaZo8wrGNzKlN",
            "dcr2i+l3hPka/Thv6SjlFJ",
            "e0ToYJbrVM4akOzdj5wdce",
            "e4oG15Z09L05hZvrmIHr32",
            "e8Ueib+qJEhL6mXAHdnwbi",
            "ecWBMRRGJK6aVv865uDk+C",
            "ec6UYa/hxKTJUCQRIogftm",
            "edbQc1Me1FpZcZGZQjWa/z",
            "edyC3E/NRNl7ELWBM92Uv2",
            "f1oiVrqVpALLxOCN0bQgyR",
            "f3bGMDF49IZoS6H4ahZhCT",
            "f4jrrxMc9D4L6/preKDmSR",
            "f5GMK8Op5GAJHyPOCATFhC",
            "f6W81fY5ZPloe+9lE8p29q",
            "fdmZXGatJP6q1rLKE1YaML"
        ],
        "06ba2d664": [
            "05be20M4lGtLdrqpGeD0Lb",
            "32M4Sd0QhLSYwxSVWVYRXj"
        ],
        "079499991": [
            "2aKWBXJHxKHLvrBUi2yYZQ",
            "6dkeWRTOBGXICfYQ7JUBnG"
        ],
        "07ce7530a": [
            "14TDKXr2NJ6LjvHPops74o",
            "3ae7efMv1CLq2ilvUY/tQi"
        ],
        "085447f77": [
            "240FLA/ONAipiHOwaeicEn",
            "e97j6RgfZJn5/lHOCSrJD5",
            "f6BjoMLzlE36iKGoygYaSt"
        ],
        "08900b32f": [
            "0a+3wxuIhIs6kLVc8ghDJ0",
            "20MsNZ+lVL5IUu6DD9FWlF",
            "2chAoT/npGG5tcauaTPNEV",
            "2do2oEwatKMb9NAmWr/gFQ",
            "3aZFcJ6/VA95J3I9lJkQGI",
            "c5TYm+URZFK6rkqxOEv+NG",
            "f6xD65bL5Pjq6q+l1seZSH"
        ],
        "08f431a95": [
            "b3ts0Z65BAErDtM+zS1EqU",
            "fd3j3ibbxPKKrzyHFZnAhH"
        ],
        "0947ec736": [
            "05SM8sofpBh5pt4Hz+cE9R",
            "11lWmKnbhC5Kgw2tBH5sFg",
            "15tUUvJldPt6D2yJOxPiqt",
            "26LUEwhTlC5I6R0fLKFrvN",
            "288lA8RntHaZfKNevhq1C4",
            "2dfRw6DclAL7SuXn9gk26l",
            "31FJqlIT9LiK8MDp2FZXPw",
            "36lcjy8kZEzIgtLDgQdXs5",
            "3arEXG2KlCpJGckX59IfGA",
            "44Ax8deB9FLpj6D9cX6Juv",
            "48SxnKvOhFxpIsevLwztxD",
            "48dSXZMC9JqLR+s2tNSfhV",
            "52UNe785VDYpSNGvsOJCGI",
            "54jMYR9w5AgKhh9S97f/lu",
            "56PeA84H5Ig7Hp7d4QYeir",
            "5eUS99dy9NO4bq7IvoDGUG",
            "64lt7DaYJD4KyxHIvtRC6A",
            "6aNbT0bw9AS5fCp0iKtz1z",
            "6bKGXWtxhJD7Da5GIQvLgf",
            "6fYDy99dBNMI/TC8Mk/c2G",
            "6fZ2Irjl1MPLYq78FgCbZC",
            "74EViJT7JPmKNjXFs/oucM",
            "8e+/U6TnVPEKe38m5iO2Gr",
            "91LEZ6xT9NaIEjW3Yynsc9",
            "b24N1Ppc9BwaeWi1rmwHvl",
            "daJH2m0RxIJ4p/86uoUvJU",
            "dfbBE1/LBK1qKLTul6NLut",
            "f8G5Y1euhLGbgtbSsePniu"
        ],
        "094c7cd29": [
            "2a91nmGvhN647ww+2IbAgf",
            "6bwLq0kyVAxrsawo1Q/syU",
            "81eYhrnqlEo7++3US4irOQ",
            "8fpwak6/pDlrtXwdDgNQ+K",
            "c2w5HoEaVEPqfTU6LkLigD"
        ],
        "0a4bda8bb": [
            "04SZR5Ph5P3rSTuq5FILkt",
            "07BO/pnd1MHI4hUMSJTeG7",
            "0eqO7kwxNH+rHj3HmiOGU0",
            "21mVujSDhFX4KqDqLbOCp6",
            "2chAoT/npGG5tcauaTPNEV",
            "2e3kCtoBtLq4yx5N3sdsAr",
            "422jN2LkNIDpQ+wVPMZACx",
            "4crRtg8KpNYa8UGnn3DmUj",
            "50vDMOP+FCopaTF62HWE8V",
            "5cXHATPRhC16RHyLEslAlh",
            "682vOvGa5ExpcRNJHH1iIX",
            "6bk6wO6h1Ejo+mMV0aR2yh",
            "79fg6oPitNAbhg4V+PPz/z",
            "7aKoqWBbtKY5Yhmywsp8tg",
            "7clrtPwqpDDI3K7QbhNnlV",
            "81eYhrnqlEo7++3US4irOQ",
            "9ajBDyQg5PC5AXuBGWgCUx",
            "a504ejkGtMSYWsEGnOpYHk",
            "a7hpsigLVNOaWfZ/tL8u5h",
            "af/i6SSixFMYd+qD9CcZcq",
            "b7yQNsHOBM6r+4VS2n6sX5",
            "baO+mUuI1BRaboEd7YRKSn",
            "bdMUxzhf5CfInawPY4vlqP",
            "c5TYm+URZFK6rkqxOEv+NG",
            "cc16W5iDBBhZojRyyZPv7c",
            "cdnJCJa7tIu5d8cUqCRg8o",
            "d1u/erBvNIo6H/xBdLau2J",
            "e8MpCRL/1Bzbro58zMfxc3",
            "f0BIwQ8D5Ml7nTNQbh1YlS",
            "f3O7lARZFKmrrr6q9D+i6f"
        ],
        "0ac12d8c8": [
            "05be20M4lGtLdrqpGeD0Lb",
            "cfv+c1vZdIuLDeFk8OWQwR"
        ],
        "0ce0a57a4": [
            "0eqO7kwxNH+rHj3HmiOGU0",
            "4crRtg8KpNYa8UGnn3DmUj",
            "682vOvGa5ExpcRNJHH1iIX",
            "80LHODegtLPIO8XfsWFovZ"
        ],
        "0d2579064": [
            "29FYIk+N1GYaeWH/q1NxQO",
            "2cO/sXe/tJmpExM+zMJrrK",
            "81eYhrnqlEo7++3US4irOQ",
            "9bvaMerUlDyary99mJa6xp",
            "b5/ZbydA1B5a04Bb/vAEf2",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "efIlJTyi5AiJmIBA2fVtDn",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ],
        "0d669730c": [
            "c0BAyVxX9JzZy8EjFrc9DU",
            "cffgu4qBxEqa150o1DmRAy"
        ],
        "0e4bc3b03": [
            "0ek66qC1NOQLjgYmi04HvX",
            "7a/QZLET9IDreTiBfRn2PD"
        ],
        "0e7275a30": [
            "20MsNZ+lVL5IUu6DD9FWlF",
            "7byI2AontENZRbjEqz9hp2",
            "7fSxm0l2tH9pRR5itihCwm",
            "c5TYm+URZFK6rkqxOEv+NG",
            "f8jOkQ601OTpn4MNBHQA0H"
        ]
    },
    md5AssetsMap: {
        import: [
            "017353d51",
            "fb07c",
            "0177fa0e5",
            "c5ef4",
            "01fbcfa3b",
            "23014",
            "0203a8610",
            "0a01d",
            "030ec7ba2",
            "6de83",
            "03FQFpLzxNEYnk5ECepZCi",
            "71b4c",
            "034f03d51",
            "b7c4e",
            "0360fb3fb",
            "4a8cb",
            "039a5d96c",
            "0c606",
            "03de51e78",
            "7a23c",
            "03f752870",
            "6b087",
            "041db0b26",
            "ef153",
            "042e4c07a",
            "97d53",
            "046fae152",
            "6e199",
            "04b8c8f40",
            "e17d2",
            "0550170bb",
            "837c4",
            "05f8bb0be",
            "5c2e5",
            "06ba2d664",
            "9a7b9",
            "079499991",
            "76473",
            "07ce7530a",
            "f5ba6",
            "077LEOoa5LJrhl8IEGn50r",
            "9c624",
            "085447f77",
            "f4a17",
            "08900b32f",
            "d5442",
            "08f431a95",
            "5e872",
            "09EK34onpIhLVPrZl7LQfI",
            "5f243",
            "09K8SiSmdAVJXSFUEgN79g",
            "c7c49",
            "0947ec736",
            "a0b8a",
            "094c7cd29",
            "3bf96",
            "0a4bda8bb",
            "1616a",
            "0ac12d8c8",
            "148a1",
            "0ce0a57a4",
            "fe4d0",
            "0d2579064",
            "c83b7",
            "0d669730c",
            "1db61",
            "0e4bc3b03",
            "29db7",
            "0e7275a30",
            "eb0ab",
            "13G/+JZH1KaoOvSCsZJSaW",
            "63971",
            "17ExZl4SVK0bR7tKUzKqUw",
            "0baa4",
            "17pIGSPwZJXYnc2bkZGLQa",
            "10777",
            "1cYxPzCV9GMbG3QC9B6QiJ",
            "f2304",
            "20NdFzcGVCHoHuo+6qe+Fo",
            "23a13",
            "21lGYSl/RMhqtcDXrvwcyc",
            "ca857",
            "22s4qlS0FASbiwMWNto1wu",
            "04584",
            "22zgmdSrZNLL/7YylqsZO/",
            "ab23f",
            "2366M7/FFKjaX8xTEGuqlT",
            "b551f",
            "24nJi6tihHGKRQ9YauYn2M",
            "8f6a3",
            "26Gk3dVvZJsplover7h1zi",
            "6daf0",
            "26oRdRN3tH45GW+pnA1rnf",
            "5c7b0",
            "28dPjdQWxEQIG3VVl1Qm6T",
            "42725",
            "2aH6EkKttFTbM1zx9650FV",
            "d5741",
            "2cExVqW2xMwrOBFDF+VbCH",
            "f1e66",
            "2eMFY3AGdNqryT511eW/ri",
            "f47e1",
            "38Qr4akZNFEJQLL1Bnamml",
            "286e1",
            "38iYO6GBhMabofR1h5jrO+",
            "797e6",
            "382hcGoV5G/p8R7hHewp/H",
            "510dd",
            "3bcHC3BjJIcKqLiNDDYWZJ",
            "c44a6",
            "3evQ/ARqZMmYZNfcJlRc47",
            "ca49c",
            "3foSrQK2hE8LNN802dDB3I",
            "3d64b",
            "3f4/7YIoBAbqrmq5mZDALe",
            "68cf6",
            "40ANO8pnpKOqIAthQ03ctS",
            "b06ef",
            "41Z9TtcFdNUZ686Z465Fed",
            "a76f8",
            "43sF9uo+pPpKWPCu6HjBVW",
            "5136c",
            "4awDPZL5RKiqlXo0dD7EGQ",
            "509a9",
            "52zVS2RS5DUbmD7+zAbBg2",
            "9005b",
            "54HD7Jd89He6W+ASZ/G9mP",
            "33c48",
            "57JQuByShB1IBjs/06xkPZ",
            "2ccfb",
            "59QkMPTkhDT74P4TUq5hzH",
            "215be",
            "5eC0+Ro6VFK4BUu/22vjty",
            "09c07",
            "62MOBehHhM+r9Cjq5Bn6is",
            "1e037",
            "632MZW8hpNjpN5UgwVs2El",
            "5e2b0",
            "6bpXkL14JBfJ0kKeQW0Xmi",
            "bcaa5",
            "6c0Y7YSFlFtb28ab7ty94v",
            "ae698",
            "6d39idOBNF8p9sQwg2lZ8t",
            "e9f57",
            "6d8+uuHmBFOLcOTTJ8GL+H",
            "6bc85",
            "6fPeZI0aJFZ7jpumT1l8R3",
            "2218e",
            "6fgBCSDDdPMInvyNlggls2",
            "58d0e",
            "71w3OXCSRBi4EW16E2q8+w",
            "3b752",
            "737Ae5IvhISY2Wj6K3Fr4s",
            "73cdc",
            "75eeQ81oRM6qEgkHdYg1cw",
            "1e370",
            "76jzWyxFNBmo3uAqDSQt+d",
            "0ac0b",
            "77M24og4xBerfBDNBrdUGV",
            "4d5b8",
            "796vrvt+9F2Zw/WR3INvx6",
            "1cc93",
            "80xZGSvetGVJAbc8RlaOd9",
            "37c6a",
            "81yEy4C3tGxJYo1KMuXeVB",
            "e839f",
            "87KHcEGlpNyp2UoMBviyQR",
            "15a05",
            "89wdWDeIZBp7WUJWsq9+2D",
            "94258",
            "8a3rh9mQFCg4tI/MLX5rOj",
            "46785",
            "8cEJkbVDRCaqM2iB1MDSXW",
            "cf092",
            "8eReVNX1hMd4Uv0QkWWHWK",
            "ed981",
            "8e3oWpzGNFvpM5rITOxFj6",
            "e9ed8",
            "941rnKxDFCfYPkWBRjsxN/",
            "84fec",
            "96xpmKGsZB9LZJgqrS/HyH",
            "fdf97",
            "97sM5ueFFI/a+7m4E4nkTH",
            "33a87",
            "9745nN0WBLqZZo1MV8vQTk",
            "e1546",
            "98qhb14Q5J27/L+HVBrrtZ",
            "fb850",
            "99p0IrhgtAjZ4mfRAN6o9P",
            "ff78b",
            "9ePZxwyiZHT6zl5DL26f4x",
            "ff25f",
            "a1SlVB1+JJaZcR97NsXFL8",
            "094b6",
            "a1mGcEIqtINLEpOr8HCsV0",
            "25d96",
            "acr30KhsdBFYdxmFzjP0l8",
            "b3797",
            "acyWGoZsNEr6fuuiXTxZB9",
            "d5d5d",
            "b2PshklWpNrZYOFab4UpvB",
            "dbfa3",
            "b8FqQdDFFBgJNUDGb8rTmO",
            "87df2",
            "b91jBJVUVFrZy/mhvrBpld",
            "cd479",
            "b97g/qigFGWKTraAb+OZ6a",
            "2e91d",
            "baBVfLzg1KjI1euiudec2E",
            "28ce6",
            "cdlhd3lLZDsKv2ch33cqHS",
            "8c372",
            "d1dUdpOVxPGK42RUx3sim4",
            "cebe7",
            "d2eaKvbbRM87dF9MLvrKAZ",
            "1bc8c",
            "d21t4LVIBJrL0/PiZhZ8fW",
            "68488",
            "d3XTlc2QtK+IeRZtjKhpOy",
            "b5c8b",
            "d8gLz3zgtHEJY8QPbT2ek/",
            "6b167",
            "d8zXj1dg5Fp6nLNjupSwet",
            "1c6cf",
            "dbeomaPqtJab13QNV/sTow",
            "1177c",
            "dbloMXdrlNUowzCYwFacmB",
            "990d8",
            "e1a0iCwo1Ak5N5HkIRt2Wc",
            "dd0f0",
            "e7Z9uYwVJLI7mdMFM6nhBG",
            "9cf00",
            "eaFFM3nbRMtb8ZUbOPBDWH",
            "5645d",
            "ecpdLyjvZBwrvm+cedCcQy",
            "fa7d0",
            "eeXcfWNKNFUpsKc/9jUlnh",
            "100fa",
            "eei26ZpjtDb77Pjfb7/LdQ",
            "c6c68",
            "eenIQ/25dCBrnpSbZHsiAE",
            "28b13",
            "ef92nfTiVICY6nTu05LRYM",
            "7167e",
            "f1VHIBK1hGepybvOU7d/pi",
            "fe302",
            "f2GwJAvmlPGJE08YweWApu",
            "df156",
            "f7O5P100pK7YJEtf4bCpg9",
            "e627a",
            "f842b72WNNjrnnrjXm33Yf",
            "95188",
            "fa9DEGRm5E6qS8G2Lp2v70",
            "5b5b9",
            "ff51U4fOZGrIvBkVPMGUuv",
            "53335"
        ],
        "raw-assets": [
            "00QCnfOMxIka1+m+KKALfC",
            "81550",
            "02delMVqdBD70a/HSD99FK",
            "cea68",
            "05O0+u81BEMJyMv062eX1k",
            "730b1",
            "07ZhPnBbNDGLFT+OeunS6R",
            "b20d2",
            "08dMA/M1lOgZUa/LXl9bex",
            "8943d",
            "0eXPDZ7cFJs4d4I6ngXl8p",
            "b3a06",
            "0eYAitQ6dKQahUIwG9pS0X",
            "2dbc9",
            "13PRkxmyhJzq9sudXD0Vlr",
            "6a932",
            "16ILU971dEKYTHhBem2igr",
            "fa07f",
            "17pIGSPwZJXYnc2bkZGLQa",
            "dff51",
            "19uqRUX/FDg46/PO7bMEl2",
            "f7e76",
            "1anee76NhAh6UfEw5DjlOL",
            "a9a20",
            "1bMe+0Xu5FYbJobmfTF8FI",
            "dc52f",
            "1bz81vIcpN1aHpuX3LhzXE",
            "cfd01",
            "1b2Jm8OsFA4rKZwFButAYO",
            "f17b2",
            "1cFLApuwxGwKf4SCssikWe",
            "0f541",
            "20PpydoMFGQZpCD4f2a5l0",
            "ca45a",
            "22RcOSPEhHP7Xt5knmI+mC",
            "a3e86",
            "23UZt/xSJJ+5yM3FzYnsXx",
            "3438d",
            "26oRdRN3tH45GW+pnA1rnf",
            "089e6",
            "2aOHP3NhlPAomVvGjdIx7r",
            "3438d",
            "2atcHoJ8hFZK0F+V5UHacJ",
            "db6ea",
            "2av/dcm6lM9qIVbteSj5tW",
            "131ac",
            "32tWkk+K5Jubw9qUhvOVez",
            "1e8bd",
            "38Qr4akZNFEJQLL1Bnamml",
            "1b76c",
            "39r7ZDyMNF26zkHpzo+N8f",
            "dfa2a",
            "39wi5bQNdGDrxcfIAuDh4G",
            "c1aeb",
            "3aeSXBgblOGLmTkCxSHSDD",
            "2185a",
            "3b7chbJxBLiIuRiSFasrC+",
            "b88d6",
            "3b9Ma0eTxPq7nBxs2vn1Bp",
            "b9b24",
            "3eZ6idK5BDIZoMvZW9Aiy7",
            "aba0f",
            "3e0DsY7/REjKLbr+w74/Up",
            "8a0b6",
            "40ANO8pnpKOqIAthQ03ctS",
            "f16b7",
            "42F0jYPBVMGJKD83/Mgqpz",
            "1e8bd",
            "42ncWidftHaL18E7f6zLRg",
            "a9a20",
            "4a72RVr1lPybiME5fAPLhK",
            "2a488",
            "51C5ryxedI3aJ8Vt3wncVQ",
            "8ab89",
            "51pV8xrghC3ZWcfXxiLz/Y",
            "350aa",
            "51zUaLjVZNjYnXHZhnU1du",
            "17b84",
            "530sRcsDVHo5EKB+R4WWxZ",
            "dca4f",
            "556ZTN3N9PeJozvDWbaQzN",
            "81eaa",
            "582Dso86NIyIxxDyeZ5apc",
            "da5c1",
            "5be41h5rtEQKmkT1koCBu0",
            "904df",
            "5bxp7tmShCy4DGByAX+U3u",
            "5a1a6",
            "62idNCyMxPpbx08z9FFvZD",
            "1b2bf",
            "634rUplNJE+papGQg1p/Jo",
            "db8e1",
            "67CkAqDPdBO7miFi6N30V5",
            "20ed6",
            "67jq33GoRJeKMAILozSwLw",
            "e200e",
            "69JxAkd7RJdaa0zT2gckzm",
            "69129",
            "6akrT6fx5CEqgTGtJXosS4",
            "0c613",
            "6eBWFz0oVHPLIGQKf/9Thu",
            "6d3cf",
            "6f+7zXKI9HkaaYFIXtY6xK",
            "4fb3c",
            "71AHTI5NZA9YHSCfAKaphY",
            "4728c",
            "71VhFCTINJM6/Ky3oX9nBT",
            "c06a9",
            "73VZsIkp5Hw5nEYA7xndZH",
            "69129",
            "757IMoHdVAQ43aAte2WXlE",
            "6cd73",
            "76Go1eUElEXIPDTta7Q1Lp",
            "e3a89",
            "79v5L2OAZHjbb2yQ/kQs1T",
            "884dc",
            "7c8si8SfNAbrTBZfqveR4C",
            "ec915",
            "83YjLkSwhG96FPggBsRDIn",
            "b7cb8",
            "840R16aHZMxISkkUqz9UIu",
            "633fc",
            "87AtXG5+RM652Gb5VhgWLt",
            "dae5c",
            "87KHcEGlpNyp2UoMBviyQR",
            "2c9c5",
            "88tn/jEb1IUJjk+yo6qwK0",
            "fce2e",
            "8alUZU+C1DuL4b4yV2JoZQ",
            "c7147",
            "8a3rh9mQFCg4tI/MLX5rOj",
            "13a10",
            "8d6jKdFOdKGKdQX7zrPBtA",
            "cd33a",
            "91BqyiJhNHlKD5pmZh0dtt",
            "efaa1",
            "94IDTE/eBJGbEnJZmInTjc",
            "db7cc",
            "94lJimxa1MzLWHEWBaR6oN",
            "1e7e9",
            "96TOgI4/5MWaiXHdpEbhJq",
            "4ab23",
            "99griAddFD9Yxz218V62NX",
            "e0240",
            "9en5F4srpOHI8X9E1Bbae9",
            "45f67",
            "9fioFvQK5CA4z1fWViHAfA",
            "47c4d",
            "a24NCOHKpN57RiXtNBYb6+",
            "439de",
            "ab+a9NTsFHeazVNbBBfo0l",
            "a5fbb",
            "b2P8Mm0iRBDa1KXUMdnhrv",
            "8d80f",
            "b4P/PCArtIdIH38t6mlw8Y",
            "83fcc",
            "b7OFkhopFBG7mxmEj5qycv",
            "efaa1",
            "b8gZp2eKlN4JxHk2VpcTs3",
            "cfd01",
            "b9i+aSkXVLv6xwYUrmhFAm",
            "a8b27",
            "b97g/qigFGWKTraAb+OZ6a",
            "84120",
            "bber9idBlF9Idt0PLrzGlc",
            "5b191",
            "bcDa0mV8tD/bkIls1Z/V7O",
            "0fa7c",
            "c05w1o6WtC86RD8cCeIIQf",
            "2930d",
            "c2lFa5mrRE6IEPazfRhPLN",
            "c02d7",
            "c7H1La+7hK6ZyCLkpK5Xd2",
            "27906",
            "cfAlbpQgZPHKPwza284m7H",
            "faf1d",
            "d2et9Ok35JzZMljMXNl6s7",
            "7bd18",
            "d3Vq87zFlAgIFGUzxvq2SU",
            "36d25",
            "d3aLo3trFJD6IsYM0BCNuX",
            "ff59b",
            "d5QgaYicdEPYoEqbOe/JHO",
            "31f80",
            "d5jf9ZSI5HvbwoX17tZPJP",
            "aba0f",
            "d8HsitJHxOYqo801xBk8ev",
            "cdbc9",
            "d93iANoRtHaZo8wrGNzKlN",
            "8a0b6",
            "dcr2i+l3hPka/Thv6SjlFJ",
            "a3db0",
            "e0ToYJbrVM4akOzdj5wdce",
            "62a9d",
            "e4oG15Z09L05hZvrmIHr32",
            "031c1",
            "e8Ueib+qJEhL6mXAHdnwbi",
            "90cf4",
            "ecWBMRRGJK6aVv865uDk+C",
            "ccdc5",
            "ec6UYa/hxKTJUCQRIogftm",
            "355ae",
            "edbQc1Me1FpZcZGZQjWa/z",
            "9816d",
            "edyC3E/NRNl7ELWBM92Uv2",
            "29239",
            "eenIQ/25dCBrnpSbZHsiAE",
            "5f523",
            "f1VHIBK1hGepybvOU7d/pi",
            "d562c",
            "f1oiVrqVpALLxOCN0bQgyR",
            "ff268",
            "f3bGMDF49IZoS6H4ahZhCT",
            "63bbb",
            "f4jrrxMc9D4L6/preKDmSR",
            "f7e76",
            "f5GMK8Op5GAJHyPOCATFhC",
            "bd8c3",
            "f6W81fY5ZPloe+9lE8p29q",
            "d0b78",
            "f7O5P100pK7YJEtf4bCpg9",
            "b8509",
            "fdmZXGatJP6q1rLKE1YaML",
            "a9a20"
        ]
    },
    orientation: "portrait",
    debug: true,
    subpackages: {}
};