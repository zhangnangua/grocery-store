(function(t) {
    "use strict";
    var e = {
        GET: "GET",
        POST: "POST"
    }, n = {
        WWW: "application/x-www-form-urlencoded",
        JSON: "application/json"
    };
    function o(t, o) {
        this._kvSets = {}, this._length = 0, this._methodType = !t || t !== e.POST && t !== e.GET ? e.POST : t, 
        this._contentType = !o || o !== n.WWW && o !== n.JSON ? n.WWW : o;
    }
    function s(t, n, o, s) {
        // let i = new XMLHttpRequest();
        // switch (i.onreadystatechange = (() => {
        //     if (4 !== i.readyState) return;
        //     if (i.status < 200 && i.status >= 400) return console.log(`${t}请求失败status: ${status}`), 
        //     void (s && "function" == typeof s && s());
        //     let e;
        //     try {
        //         (e = JSON.parse(i.responseText)) && 0 === e.code || console.log(`${t}: ${e.msg}`);
        //     } catch (e) {
        //         console.log(`${t}解析返回数据err: ${e}${i.responseText}`), s && "function" == typeof s && s();
        //     }
        //     o && "function" == typeof o && o(e);
        // }), i.onerror = (() => {
        //     s && "function" == typeof s && s();
        // }), n.getMethod()) {
        //   case e.GET:
        //     i.open(e.GET, t.concat("?").concat(n.normalize()), !0), i.setRequestHeader("Content-Type", n.getContent()), 
        //     i.send();
        //     break;

        //   case e.POST:
        //     i.open(e.POST, t, !0), i.send(n.normalize());
        // }
        // n = null;
    }
    o.prototype = {
        constructor: o,
        getData() {
            return this._kvSets;
        },
        contains(t) {
            return t in this._kvSets;
        },
        put(t, e) {
            this.contains(t) || this._length++, this._kvSets[t] = e;
        },
        getMethod() {
            return this._methodType;
        },
        getContent() {
            return this._contentType;
        },
        normalize() {
            switch (this._contentType) {
              case n.WWW:
                return this.toWWWData(!0);

              case n.JSON:
                return this.toJsonData();
            }
        },
        toWWWData(t) {
            let e = "";
            for (let n in this._kvSets) this._kvSets.hasOwnProperty(n) && (!t || null !== this._kvSets[n] && "" !== this._kvSets[n] && void 0 !== this._kvSets[n]) && (e = e.concat(n).concat("=").concat(this._kvSets[n]).concat("&"));
            return e = e.substr(0, e.length - 1);
        },
        toJsonData() {
            return JSON.stringify(this._kvSets);
        }
    }, "object" == typeof module && module.exports ? module.exports = {
        MethodType: e,
        ContentType: n,
        notify: s,
        Message: o
    } : "function" == typeof define && define.amd && define(function() {
        return {
            MethodType: e,
            ContentType: n,
            notify: s,
            Message: o
        };
    }), t.HttpHandler = {
        MethodType: e,
        ContentType: n,
        notify: s,
        Message: o
    };
})(this);