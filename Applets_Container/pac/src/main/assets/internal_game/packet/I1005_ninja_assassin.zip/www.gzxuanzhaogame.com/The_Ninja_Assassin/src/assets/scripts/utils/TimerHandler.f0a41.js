(function(e) {
    "use strict";
    var t = {
        COMMON: "Common",
        MAIN: "Main",
        GAME: "Game"
    }, i = {
        FOREVER: 0,
        ONCE: 1
    }, r = {
        STATIC: 0,
        CONTINUE: 1,
        BREAK: 2
    }, s = {
        Type: t,
        Loop: i,
        RunResult: r,
        serverTime: 0,
        timers: {},
        loopTimer: null,
        count: 0,
        curOnlyTimer: t.MAIN,
        delayTimeOfMainLoop: .1,
        init() {
            return this.clear(), this.loopTimer = setInterval(function() {
                this.runStayTimers(), this.runOnlyTimers();
            }.bind(this), 1e3 * this.delayTimeOfMainLoop), this;
        },
        setServerTime(e) {
            e && 200 === e.code && (this.serverTime = time);
        },
        getServerTime() {
            return kk.Config.isLocal ? Date.now() : this.serverTime;
        },
        runStayTimers() {
            for (let e in this.timers[t.COMMON]) this.timers[t.COMMON].hasOwnProperty(e) && this.run(t.COMMON, e);
        },
        runOnlyTimers() {
            for (let e in this.timers[this.curOnlyTimer]) this.timers[this.curOnlyTimer].hasOwnProperty(e) && this.run(this.curOnlyTimer, e);
        },
        runMainTimer() {
            this.curOnlyTimer = t.MAIN;
        },
        runGameTimer() {
            this.curOnlyTimer = t.GAME;
        },
        stopMainTimer() {
            this.clearObservers(t.MAIN);
        },
        stopGameTimer() {
            this.clearObservers(t.GAME);
        },
        add(e, t, i, r, s) {
            if (!e || void 0 === t || void 0 === i || "object" != typeof s || "function" != typeof r) return null;
            this.loopTimer || 0 === this.loopTimer || this.init();
            let m = this.generateUID(), o = new n(m, t, Math.round(i / this.delayTimeOfMainLoop), r, s, Array.prototype.slice.call(arguments, 5));
            return this.addTimer(e, m, o), o;
        },
        remove(e, t, i) {
            if (!e || "object" != typeof i || "function" != typeof t || !this.timers[e]) return null;
            let r;
            for (let s in this.timers[e]) if (this.timers[e].hasOwnProperty(s) && (r = this.getTimer(e, s)) && r.compare(t, i)) {
                this.removeTimer(e, s);
                break;
            }
            return this;
        },
        removeByUID(e, t) {
            this.removeTimer(e, t);
        },
        run(e, t) {
            let i = this.getTimer(e, t).notify();
            return i === r.BREAK && this.removeTimer(e, t), i;
        },
        addTimer(e, t, i) {
            return e && t && i ? (this.timers[e] || (this.timers[e] = {}), this.timers[e][t] = i, 
            i) : null;
        },
        getTimer(e, t) {
            return e && t && this.timers[e] ? this.timers[e][t] : null;
        },
        removeTimer(e, t) {
            return e && t && this.timers[e] ? (delete this.timers[e][t], this) : this;
        },
        clearObservers(e) {
            if (this.timers[e]) return delete this.timers[e], this;
        },
        clear() {
            return (this.loopTimer || 0 === this.loopTimer) && window.clearInterval(this.loopTimer), 
            this.timers = {}, this;
        },
        generateUID() {
            return this.count++, this.count;
        }
    };
    function n(e, t, s, n, m, o) {
        this.uid = e, this.startTime = 0, this.delayTime = s, this.type = t, this.notify = function() {
            let e = r.STATIC;
            return this.startTime++, this.startTime < this.delayTime ? e : (e = this.type === i.ONCE ? r.BREAK : r.CONTINUE, 
            this.type > i.ONCE && this.type--, this.startTime = 0, n.apply(m, o), e);
        }, this.compare = function(e, t) {
            return n === e && m === t;
        };
    }
    "object" == typeof module && module.exports ? module.exports = s : "function" == typeof define && define.amd && define(function() {
        return s;
    }), e.TimerHandler = s;
})(this);