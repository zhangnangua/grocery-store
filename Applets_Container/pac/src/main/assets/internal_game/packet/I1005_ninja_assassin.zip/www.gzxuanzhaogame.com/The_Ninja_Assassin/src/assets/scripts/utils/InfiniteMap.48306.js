(function(t) {
    "use strict";
    function e(t, i, r) {
        switch (this._data = {}, this._length = 0, r = r || e.Type.REFER) {
          default:
          case e.Type.REFER:
            this.refer(t);
            break;

          case e.Type.COPY:
            this.copy(t);
            break;

          case e.Type.CLONE:
            this.clone(t);
        }
    }
    e.Type = {
        DEFAULT: 0,
        REFER: 1,
        COPY: 2,
        CLONE: 3
    }, e.prototype = {
        construct: e,
        clone(t) {
            if (t) {
                let e = JSON.stringify(t);
                this._data = JSON.parse(e), this._length = e.length, t = null;
            } else this._data = {}, this._length = 0;
            return this._data;
        },
        copy(t) {
            if (!t) return this._data;
            for (let e in t) t.hasOwnProperty(e) && (this._data[e] = t[e], this._length++);
            return t = null, this._data;
        },
        refer(t) {
            return t && (this._data = t, this._length = 1), this._data;
        },
        getData() {
            return this._data = this._data || {}, this._data;
        },
        set(t, e) {
            return (t = this.check(t)).indexOf("/") >= 0 ? this.register(t, e) : this._data[t] = e;
        },
        query(t) {
            return (t = this.check(t)).indexOf("/") >= 0 ? this.search(t) : this._data[t] ? this._data[t] : 0;
        },
        check: t => "string" == typeof data && data.constructor === String ? t : t.toString(),
        search(t) {
            let e = t.split("/"), i = this._data;
            for (let t = 0; t < e.length; t++) {
                if (!i.hasOwnProperty(e[t])) return 0;
                i = i[e[t]];
            }
            return i || 0;
        },
        register(t, e) {
            let i = t.split("/"), r = this._data;
            for (let t = 0; t < i.length; t++) t < i.length - 1 ? r.hasOwnProperty(i[t]) || (r[i[t]] = {}) : r[i[t]] = e, 
            r = r[i[t]];
            return r;
        }
    }, "object" == typeof module && module.exports ? module.exports = e : "function" == typeof define && define.amd && define(function() {
        return e;
    }), t.InfiniteMap = e;
})(this);