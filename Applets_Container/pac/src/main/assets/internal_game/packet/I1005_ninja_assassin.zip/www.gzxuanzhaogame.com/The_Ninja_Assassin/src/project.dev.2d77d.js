window.__require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var b = o.split("/");
        b = b[b.length - 1];
        if (!t[b]) {
          var a = "function" == typeof __require && __require;
          if (!u && a) return a(b, !0);
          if (i) return i(b, !0);
          throw new Error("Cannot find module '" + o + "'");
        }
      }
      var f = n[o] = {
        exports: {}
      };
      t[o][0].call(f.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, f, f.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof __require && __require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  AldEvents: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "85cc5J5tPJJCIMq0oh03HAv", "AldEvents");
    "use strict";
    module.exports = {
      sdkPlatform: "sdk_Platform",
      sdkLogin: "weChat_Login",
      getUserInfo: "get_UserInfo",
      getUserInfoResponse: "get_UserInfoResponse",
      authorizedLogin: "authorized_Login",
      onAuthorizedLoginResponse: "Authorized_Login_Response",
      getUserTask: "get_UserTask",
      getTaskResponse: "get_Task_Response",
      getConfig: "get_Config",
      getConfigResponse: "get_Config_Response",
      getShareData: "get_ShareData",
      getShareDataResponse: "get_ShareData_Response",
      getAdConfig: "get_AdConfig",
      getAdConfigResponse: "get_AdConfig_Response",
      launchGame: "game_launch"
    };
    cc._RF.pop();
  }, {} ],
  AnimLib: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0a3a3s47b9PG5mhQiP+niJ7", "AnimLib");
    "use strict";
    var n = {
      elasticMove: function elasticMove(e, t, i, n, s) {
        e.runAction(cc.sequence(cc.moveTo(2 * t / 3, i.add(n.mul(e.position.sub(i).mag() / 5))), cc.moveTo(t / 3, i), cc.callFunc(function() {
          s && s();
        })));
      },
      elasticScale: function elasticScale(e, t, i, n, s) {
        e.runAction(cc.sequence(cc.scaleTo(2 * t / 3, i * (1 + .1 * n), i * (1 + .1 * n)), cc.scaleTo(t / 3, i, i), cc.callFunc(function() {
          s && s();
        })));
      },
      elasticScaleRevert: function elasticScaleRevert(e, t, i, n) {
        e.setScale(1, 1), e.runAction(cc.sequence(cc.scaleTo(2 * t / 3, i, i), cc.scaleTo(t / 3, 1, 1), cc.callFunc(function() {
          n && n();
        })));
      },
      elasticSkew: function elasticSkew(e, t, i, n, s) {
        var o = 1, a = 1;
        switch (n) {
         case 0:
          o = -i;
          break;

         case 1:
          a = -i;
          break;

         case 2:
          o = i;
          break;

         case 3:
          a = i;
        }
        e.runAction(cc.sequence(cc.skewTo(2 * t / 3, o, a), cc.skewTo(t / 3, 0, 0), cc.callFunc(function() {
          s && s();
        })));
      },
      pressDown: function pressDown(e, t, i, n) {
        var s = e.getComponent(cc.Button), o = e.position.x, a = e.position.y, r = cc.moveTo(2 * t / 3, o, a - i), c = cc.moveTo(t / 3, o, a), u = cc.callFunc(function() {
          s && (s.interactable = !0), n && n();
        });
        s && (s.interactable = !1), e.stopAllActions(), e.runAction(cc.sequence(r, c, u));
      },
      shake: function shake(e, t, i, n) {
        t = t || cc.Vec2.ZERO;
        var s = cc.callFunc(function() {
          (i = i - 1 + Math.random() / 2) <= 0 && (this.stopShake(e, t), n && n());
        }, this), o = cc.sequence(cc.moveTo(.01, e.position.add(cc.Vec2.RIGHT.neg().mul(i))), cc.moveTo(.01, t), cc.moveTo(.01, e.position.add(cc.Vec2.RIGHT.mul(i))), cc.moveTo(.01, t), s);
        e.stopAllActions(), e.runAction(cc.repeatForever(o));
      },
      stopShake: function stopShake(e, t) {
        t = t || cc.Vec2.ZERO, e.stopAllActions(), e.setPosition(t), t = null;
      },
      numberIterator: function numberIterator(e, t, i, n, s) {
        if (e instanceof cc.Node && !(n <= 0) && "number" == typeof t && "number" == typeof i && t !== i) {
          var o = e.getComponent(cc.Label);
          if (o) {
            t = t || 0, i = i || 0;
            var a, r, c = 0, u = Math.floor(n / .02), d = i - t, l = d > 0 ? 1 : -1, h = l * Math.ceil(Math.abs(d / u));
            a = cc.callFunc(function() {
              c += h, l >= 0 && t + c >= i || l < 0 && t + c < i ? k() : o.string = (t + c).toString();
            }, this), r = cc.callFunc(k, this), e.stopAllActions(), e.runAction(cc.sequence(cc.repeat(cc.sequence(a, cc.delayTime(.02)), u), cc.delayTime(.02), r));
          }
        }
        function k() {
          e.stopAllActions(), o.string = i.toString(), s && s(), e = null, o = null;
        }
      }
    };
    module.exports = n;
    cc._RF.pop();
  }, {} ],
  AppManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4b3d4ny+49KI61Ax+Nu9pRS", "AppManager");
    "use strict";
    var n = require("Enum");
    cc.Class({
      extends: cc.Component,
      properties: {
        category: {
          default: n.InterAdCategory.OVER,
          type: n.InterAdCategory
        },
        num: 1,
        fillNum: !1,
        autoRefresh: 0,
        _appList: null
      },
      start: function start() {},
      populateList: function populateList(e) {},
      updateNode: function updateNode(e, t) {},
      onAutoRefresh: function onAutoRefresh() {},
      getSpriteSize: function getSpriteSize(e) {},
      onAppClick: function onAppClick(e, t) {},
      getAppList: function getAppList() {},
      replaceAd: function replaceAd(e, t, i) {},
      onDestroy: function onDestroy() {}
    });
    cc._RF.pop();
  }, {
    Enum: "Enum"
  } ],
  AssetLib: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "b7103RCcXVBjZSFzf6wO/E2", "AssetLib");
    "use strict";
    var _typeof = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(obj) {
      return typeof obj;
    } : function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    var n = "function" == typeof Symbol && "symbol" == _typeof(Symbol.iterator) ? function(e) {
      return "undefined" === typeof e ? "undefined" : _typeof(e);
    } : function(e) {
      return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : "undefined" === typeof e ? "undefined" : _typeof(e);
    };
    var s = {
      _dependsCounter: {},
      _caches: {},
      _tempInfo: {},
      _waitingList: {},
      _waitingCount: 0,
      _preReleaseList: [],
      reset: function reset() {
        this._dependsCounter = {}, this._caches = {}, this._tempInfo = {}, this._waitingList = {}, 
        this._waitingCount = 0, this._preReleaseList = [];
      },
      retainAsset: function retainAsset(e, t) {
        var i = this.getAssetKey(e, t), n = this._getCache(i);
        return n && this._addAssetDepends(i), n;
      },
      loadAsset: function loadAsset(e, t, i, n, s) {
        if (t) if (cc.js.isChildClassOf(t, cc.RawAsset)) {
          var a = this.getAssetKey(e, t), r = this._getCache(a), c = Array.prototype.slice.call(arguments, 5);
          if (r) return this._addAssetDepends(a), void i.apply(s, [ r ].concat(c));
          var u = new o(i, n, s, c);
          this._waitingList && this._waitingList[a] ? this._waitingList[a].push(u) : (this._waitingList[a] = [ u ], 
          this._waitingCount++, cc.loader.loadRes(e, t, function(e, i) {
            var n = void 0, s = this._waitingList[a];
            delete this._waitingList[a], this._waitingCount--, e ? n = e : (this._addCache(a, t, i), 
            this._addRangeDepends(cc.loader.getDependsRecursively(a)), this._addAssetDepends(a, s.length - 1));
            for (var o = 0, r = s.length; o < r; o++) {
              var c = e ? s[o].errorCB : s[o].completeCB, u = s[o].args;
              e || (n = this._getCache(a)), c && c.apply(s[o].context, [ n ].concat(u));
            }
            if (0 === this._waitingCount) {
              var d = !0, l = !1, h = void 0;
              try {
                for (var k, g = this._preReleaseList[Symbol.iterator](); !(d = (k = g.next()).done); d = !0) {
                  var p = k.value;
                  this.releaseAsset(p[0], p[1]);
                }
              } catch (e) {
                l = !0, h = e;
              } finally {
                try {
                  !d && g.return && g.return();
                } finally {
                  if (l) throw h;
                }
              }
              this._preReleaseList = [];
            }
            e && console.error(e);
          }.bind(this)));
        } else console.error("Asset Type must be child of cc.RawAsset. given: " + t); else console.error("must be specific a asset type!");
      },
      releaseAsset: function releaseAsset(e, t) {
        if (t) if (cc.js.isChildClassOf(t, cc.RawAsset)) {
          var i = this.getAssetKey(e, t);
          this._waitingList[i] ? console.log("{url: " + e + ", type: " + cc.js.getClassName(t) + "} is loading!") : this._waitingCount > 0 ? this._preReleaseList.push([ e, t ]) : this._tryReleaseAssetByKey(i);
        } else console.error("Asset Type must be child of cc.RawAsset"); else console.error("must be specific a asset type!");
      },
      loadAssets: function loadAssets(e, t, i, n) {
        var s = new a(e, t, i, n, Array.prototype.slice.call(arguments, 4));
        for (var o in e) e.hasOwnProperty(o) && this.loadAsset(o, e[o], s.onLoadComplete, s.onLoadError, s, o);
        return s;
      },
      loadAssetOnline: function loadAssetOnline(e, t, i, n) {
        e && cc.loader.load({
          url: e,
          type: t
        }, function(s, o) {
          if (s && n) n("load error url:" + e + "." + t); else {
            var a = new cc.SpriteFrame(o);
            i(a);
          }
        });
      },
      getAssetKey: function getAssetKey(e, t) {
        var i = cc.loader._getResUuid(e, t);
        return cc.AssetLibrary._getAssetInfoInRuntime(i, this._tempInfo), this._tempInfo.url || i;
      },
      setSprite: function setSprite(e, t, i) {
        i = "plist/".concat(i || "common"), this.loadAsset(i, cc.SpriteAtlas, function(i) {
          e.getOrAddComponent(cc.Sprite).spriteFrame = i.getSpriteFrame(t);
        });
      },
      setState: function setState(e, t) {
        parseInt(cc.ENGINE_VERSION) < 2 ? e.getOrAddComponent(cc.Sprite)._sgNode.setState(t ? 1 : 0) : e.getOrAddComponent(cc.Sprite).setState(t ? 1 : 0);
      },
      addPersistRootNode: function addPersistRootNode(e) {
        cc.game.isPersistRootNode(e) || (this.onAddPersistRootNode(e), cc.game.addPersistRootNode(e));
      },
      removePersistRootNode: function removePersistRootNode(e) {
        cc.game.isPersistRootNode(e) && (this.onRemovePersistRootNode(e), cc.game.removePersistRootNode(e));
      },
      initSceneDepends: function initSceneDepends() {
        var e = cc.director.getScene();
        e && (this._addRangeDepends(e.dependAssets), this._addDependsOfAllPersistentNodes());
      },
      onSceneLoaded: function onSceneLoaded(e, t) {
        t && this._addRangeDepends(t), e && this._releaseRangeDepends(e, !1);
      },
      onAddPersistRootNode: function onAddPersistRootNode(e) {
        if (!e._persistNode) {
          var t = this._generateNodeDepends(e);
          this._addRangeDepends(t), this.monitorNodeDestroy(e);
        }
      },
      onRemovePersistRootNode: function onRemovePersistRootNode(e) {
        if (e._persistNode) {
          var t = this._generateNodeDepends(e);
          this.unMonitorNodeDestroy(e), this._releaseRangeDepends(t, !1);
        }
      },
      monitorNodeDestroy: function monitorNodeDestroy(e) {
        var t = function() {
          this.onRemovePersistRootNode(e);
        }.bind(this);
        e.hookOnDestroy(t);
      },
      unMonitorNodeDestroy: function unMonitorNodeDestroy(e) {
        e.unHookOnDestroy();
      },
      _getCache: function _getCache(e) {
        return this._caches[e];
      },
      _addCache: function _addCache(e, t, i) {
        this._caches[e] = i, i = null;
      },
      _removeCache: function _removeCache(e) {
        this._caches[e] && delete this._caches[e];
      },
      _addRangeDepends: function _addRangeDepends(e) {
        for (var t = 0, i = e.length; t < i; t++) {
          var n = e[t];
          this._addAssetDepends(n);
        }
      },
      _releaseRangeDepends: function _releaseRangeDepends(e, t) {
        for (var i = 0, n = e.length; i < n; i++) this._tryReleaseAssetByKey(e[i], t);
      },
      _addAssetDepends: function _addAssetDepends(e, t) {
        t = !t || t < 0 ? 1 : t, this._dependsCounter[e] = this._dependsCounter[e] ? this._dependsCounter[e] + t : t;
      },
      _tryReleaseAssetByKey: function _tryReleaseAssetByKey(e, t) {
        if (this._dependsCounter[e] <= 0) console.error("Asset reference count maintain failed: " + e + ", refCount: " + this._dependsCounter[e]); else if (this._dependsCounter[e]--, 
        !(this._dependsCounter[e] > 0)) {
          if (this._removeCache(e), t) for (var i = cc.loader.getDependsRecursively(e), n = 0, s = i.length; n < s; n++) i[n] !== e && this._tryReleaseAssetByKey(i[n], !1);
          cc.loader.release(e);
        }
      },
      _addDependsOfAllPersistentNodes: function _addDependsOfAllPersistentNodes() {
        for (var e = Object.keys(cc.game._persistRootNodes).map(function(e) {
          return cc.game._persistRootNodes[e];
        }), t = cc.js.createMap(), i = 0; i < e.length; i++) this._visitNode(e[i], t), this.monitorNodeDestroy(e[i]);
        var n = Object.keys(t);
        this._addRangeDepends(n);
      },
      _generateNodeDepends: function _generateNodeDepends(e) {
        var t = cc.js.createMap();
        return this._visitNode(e, t), Object.keys(t);
      },
      _parseDepends: function _parseDepends(e, t) {
        var i = cc.loader.getItem(e);
        if (i) {
          var n = i.dependKeys;
          if (n) for (var s = 0, o = n.length; s < o; s++) {
            var a = n[s];
            t[a] || (t[a] = !0, this._parseDepends(a, t));
          }
        }
      },
      _visitAsset: function _visitAsset(e, t) {
        var i = cc.loader._getReferenceKey(e);
        t[i] || (t[i] = !0, this._parseDepends(i, t));
      },
      _visitComponent: function _visitComponent(e, t) {
        for (var i = Object.getOwnPropertyNames(e), s = 0, o = i.length; s < o; s++) {
          var a = e[i[s]];
          if ("object" === (void 0 === a ? "undefined" : n(a)) && a) if (Array.isArray(a)) for (var r = 0; r < a.length; r++) {
            var c = a[r];
            c instanceof cc.RawAsset && this._visitAsset(c, t);
          } else if (a.constructor && a.constructor !== Object) a instanceof cc.RawAsset && this._visitAsset(a, t); else for (var u = Object.getOwnPropertyNames(a), d = 0; d < u.length; d++) {
            var l = a[u[d]];
            l instanceof cc.RawAsset && this._visitAsset(l, t);
          }
        }
      },
      _visitNode: function _visitNode(e, t) {
        for (var i = 0, n = e._components.length; i < n; i++) this._visitComponent(e._components[i], t);
        for (var s = 0; s < e._children.length; s++) this._visitNode(e._children[s], t);
      }
    };
    function o(e, t, i, n) {
      this.completeCB = e, this.errorCB = t, this.context = i, this.args = n;
    }
    function a(e, t, i, n, s) {
      this.errorMessage = null, this.requestList = e, this.loadedList = {}, this.completeCB = t, 
      this.errorCB = i, this.progressCB = n, this.args = s, this.progress = new r(0, Object.keys(e).length);
    }
    function r(e, t) {
      this.cur = e, this.max = t;
    }
    a.prototype = {
      addProgress: function addProgress(e, t) {
        this.loadedList[e] = t, this.progress.cur += 1;
      },
      getProgress: function getProgress() {
        return this.progress.asPercent();
      },
      isOver: function isOver() {
        return 1 === this.progress.asPercent();
      },
      checkOver: function checkOver() {
        this.isOver() && (this.errorMessage && this.errorCB ? this.errorCB.apply(this, [ this.errorMessage, this.loadedList ].concat(this.args)) : this.completeCB.apply(this, [ this.loadedList ].concat(this.args)));
      },
      onLoadComplete: function onLoadComplete(e, t) {
        this.addProgress(t, e), this.progressCB && this.progressCB.apply(this, [ this.progress.cur, this.progress.max, t, this.requestList[t], e ]), 
        this.checkOver();
      },
      onLoadError: function onLoadError(e, t) {
        this.errorMessage = {
          code: 1001,
          msg: "url: " + t + ", result: " + e
        }, this.addProgress(t, e), this.checkOver();
      }
    }, r.prototype = {
      asPercent: function asPercent() {
        return this.max ? this.cur / this.max : 0;
      },
      asString: function asString() {
        return this.cur + "/" + this.max;
      }
    }, module.exports = s;
    cc._RF.pop();
  }, {} ],
  AudioManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0fb22Mk6XJPA5szj9N84p29", "AudioManager");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        bgmVolume: 1,
        sfxVolume: 1,
        bgmAudioID: -1,
        _curBgmUrl: null,
        _AudioClips: [],
        _AudioClipsId: []
      },
      init: function init() {
        var self = this;
        this.resetLocalAudio();
        cc.game.on(cc.game.EVENT_HIDE, function() {
          cc.audioEngine.pauseAll();
        });
        cc.game.on(cc.game.EVENT_SHOW, function() {
          cc.audioEngine.resumeAll();
        });
      },
      resetLocalAudio: function resetLocalAudio() {
        var t = cc.sys.localStorage.getItem("bgmVolume");
        if ("" === t || null == t || void 0 == t) {
          this.bgmVolume = parseFloat(1);
          this.setBGMVolume(1);
        } else {
          this.bgmVolume = parseFloat(t);
          this.setBGMVolume(this.bgmVolume);
        }
        var t1 = cc.sys.localStorage.getItem("sfxVolume");
        if ("" === t1 || null == t1 || void 0 == t1) this.setSFXVolume(1); else {
          this.sfxVolume = parseFloat(t1);
          this.setSFXVolume(this.sfxVolume);
        }
      },
      setSFXVolume: function setSFXVolume(v) {
        if (this.sfxVolume != v) {
          cc.sys.localStorage.setItem("sfxVolume", v);
          this.sfxVolume = v;
        }
      },
      setBGMVolume: function setBGMVolume(v) {
        var self = this;
        if (this.bgmAudioID >= 0) v > 0 ? cc.audioEngine.resume(this.bgmAudioID) : cc.audioEngine.pause(this.bgmAudioID); else if (this._curBgmUrl && v > 0) {
          var audioUrl = "sounds/" + this._curBgmUrl;
          void 0 == this._AudioClips[self._curBgmUrl] ? cc.loader.loadRes(audioUrl, cc.AudioClip, function(err, clip) {
            self.bgmAudioID = cc.audioEngine.play(clip, true, self.bgmVolume);
            self._AudioClips[self._curBgmUrl] = clip;
          }) : this.bgmAudioID = cc.audioEngine.play(self._AudioClips[self._curBgmUrl], true, self.bgmVolume);
        }
        cc.sys.localStorage.setItem("bgmVolume", v);
        this.bgmVolume = v;
        cc.audioEngine.setVolume(self.bgmAudioID, v);
      },
      getBgmVolume: function getBgmVolume() {
        return this.bgmVolume;
      },
      pauseAll: function pauseAll() {
        cc.audioEngine.pauseAll();
      },
      resumeAll: function resumeAll() {
        cc.audioEngine.resumeAll();
      },
      playBGM: function playBGM(name) {
        var self = this;
        this._curBgmUrl = name;
        this.bgmAudioID >= 0 && cc.audioEngine.stop(this.bgmAudioID);
        if (this.bgmVolume > 0) {
          var audioUrl = "sounds/" + name;
          void 0 == this._AudioClips[name] ? cc.loader.loadRes(audioUrl, cc.AudioClip, function(err, clip) {
            self.bgmAudioID = cc.audioEngine.play(clip, true, self.bgmVolume);
            self._AudioClips[name] = clip;
          }) : self.bgmAudioID = cc.audioEngine.play(self._AudioClips[name], true, self.bgmVolume);
        }
      },
      playSFX: function playSFX(name) {
        var self = this;
        if (this.sfxVolume > 0) {
          var audioUrl = "sounds/" + name;
          void 0 == this._AudioClips[name] ? cc.loader.loadRes(audioUrl, cc.AudioClip, function(err, clip) {
            var sfxId = cc.audioEngine.play(clip, false, self.sfxVolume);
            self._AudioClips[name] = clip;
            self._AudioClipsId[name] = sfxId;
          }) : cc.audioEngine.play(self._AudioClips[name], false, self.sfxVolume);
        }
      },
      stopSFX: function stopSFX(name) {
        if (this._AudioClipsId[name]) {
          void 0 == this._AudioClipsId[name] && "" == this._AudioClipsId[name] || cc.audioEngine.stop(this._AudioClipsId[name]);
          this._AudioClipsId[name] = null;
          this._AudioClips[name] = null;
        }
      }
    });
    cc._RF.pop();
  }, {} ],
  AudioSystem: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "374b6+8CKBAwKC7NIEcQie4", "AudioSystem");
    "use strict";
    var n = exports.AudioType = {
      MUSIC: "music",
      SOUND: "sound"
    }, s = exports.AudioName = {
      BACK: "backgrand",
      FORE: "foregrand",
      GUI: "gui",
      SCENE: "scene",
      USER: "user",
      NPC: "npc",
      EFFECT: "effect"
    };
    exports.AudioSystem = {
      volumeSettings: {
        music: 1,
        sound: 1
      },
      stateSettings: {
        music: 0,
        sound: 0
      },
      _audios: {},
      init: function init() {
        this.initState(), this.initAudios();
      },
      initState: function initState() {
        this.setState(n.MUSIC, this.loadState(n.MUSIC)), this.setState(n.SOUND, this.loadState(n.SOUND));
      },
      initAudios: function initAudios() {
        this.add(s.BACK, n.MUSIC), this.add(s.FORE, n.MUSIC), this.add(s.GUI, n.SOUND), 
        this.add(s.SCENE, n.SOUND), this.add(s.USER, n.SOUND), this.add(s.NPC, n.SOUND), 
        this.add(s.EFFECT, n.SOUND);
      },
      add: function add(e, t) {
        if (this._audios[e]) throw new Error("\u91cd\u590d\u6dfb\u52a0\u97f3\u6548\u64ad\u653e\u5668" + e);
        this._audios[e] = new o(e, t, this.stateSettings[t]);
      },
      remove: function remove(e) {
        this.stop(e), delete this._audios[e];
      },
      getState: function getState(e) {
        return this.stateSettings[e];
      },
      setState: function setState(e, t) {
        this.stateSettings[e] = t;
      },
      switchState: function switchState(e, t) {
        var i = this.stateSettings[e] ? 0 : 1;
        return this.setState(e, i), this.setGlobalMute(e, i), t && this.saveState(e), i;
      },
      saveState: function saveState(e) {
        cc.sys.localStorage.setItem(e, this.stateSettings[e]);
      },
      loadState: function loadState(e) {
        var t = cc.sys.localStorage.getItem(e);
        return t ? JSON.parse(t) : 0;
      },
      setGlobalMute: function setGlobalMute(e, t) {
        for (var i in this._audios) this._audios.hasOwnProperty(i) && this._audios[i].type === e && this._audios[i].setVolume(t ? 0 : this.volumeSettings[e]);
      },
      setGlobalVolume: function setGlobalVolume(e, t) {
        if (this.volumeSettings[e] !== t) for (var i in this.volumeSettings[e] = t, this._audios) this._audios.hasOwnProperty(i) && this._audios[i].type === e && this._audios[i].setVolume(this.volumeSettings[e]);
      },
      getRealVolume: function getRealVolume(e, t) {
        return t = t instanceof Number ? t : 1, this.volumeSettings[e] * t;
      },
      play: function play(e, t) {
        var i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1;
        if (this._audios[e]) {
          var o = this._audios[e], a = o.type === n.MUSIC && this.getState(n.MUSIC) || o.type === n.SOUND && this.getState(n.SOUND);
          s = this.getRealVolume(o.type, s), s = a ? 0 : s, o.play(t, i, s);
        } else console.warn(e + " undefined.");
      },
      mute: function mute(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], i = this._audios[e];
        if (!this.isValid(i)) throw new Error(e + " undefined.");
        i.setVolume(t ? 0 : 1);
      },
      stop: function stop(e) {
        var t = this._audios[e];
        if (!this.isValid(t)) throw new Error(e + " undefined.");
        t.stop();
      },
      pause: function pause(e) {
        var t = this._audios[e];
        if (!this.isValid(t)) throw new Error(e + " undefined.");
        t.pause();
      },
      resume: function resume(e) {
        var t = this._audios[e];
        if (!this.isValid(t)) throw new Error(e + "\u4e0d\u5b58\u5728");
        t.resume();
      },
      isValid: function isValid(e) {
        return e && e instanceof o;
      }
    };
    function o(e, t) {
      this.name = e, this.type = t || n.SOUND, this._clipName = null, this._audioId = null;
    }
    o.prototype = {
      constructor: void 0,
      play: function play(e, t, i) {
        var n = this;
        this._audioId >= 0 && this._clipName === e ? this.resume() : (this.stop(), kk.AssetLib.loadAsset("music/".concat(e), cc.AudioClip, function(e) {
          n._audioId = cc.audioEngine.play(e, t, i), t || cc.audioEngine.setFinishCallback(n._audioId, n.release.bind(n));
        }, function() {
          console.warn("music/".concat(e) + "\u4e0d\u5b58\u5728\uff0c\u8d44\u6e90\u52a0\u8f7d\u5931\u8d25");
        }, this));
      },
      resume: function resume() {
        this.type === n.SOUND && cc.audioEngine.setCurrentTime(this._audioId, 0), cc.audioEngine.resume(this._audioId), 
        cc.audioEngine.isLoop(this._audioId) || cc.audioEngine.setFinishCallback(this._audioId, this.release.bind(this));
      },
      stop: function stop() {
        void 0 == this._audioId && "" == this._audioId || cc.audioEngine.stop(this._audioId);
        this.release();
      },
      release: function release() {
        kk.AssetLib.releaseAsset("music/".concat(this._clipName), cc.AudioClip), this._audioId = null, 
        this._clipName = null;
      },
      setVolume: function setVolume(e) {
        cc.audioEngine.setVolume(this._audioId, e);
      }
    };
    cc._RF.pop();
  }, {} ],
  Ball: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d58caeGh7BLOo8psrhuL/XW", "Ball");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        _runStatus: false
      },
      onLoad: function onLoad() {
        var self = this;
        self._ySpeed = 500;
      },
      start: function start() {
        var self = this;
        self.schedule(function() {
          self._ySpeed *= -1;
        }, 1);
      },
      onCollisionEnter: function onCollisionEnter(other, self) {
        if (this.ballPzValue == other.tag) {
          this.node.dispatchEvent(new cc.Event.EventCustom("again", true));
          this.node.removeFromParent();
        } else {
          this.setRunStatus(false);
          cc.re.mutualNode.active = true;
          cc.re.precisionNode.active = true;
          cc.re.centerNode.active = true;
          cc.re.isAutoShow = false;
          this.scheduleOnce(function() {
            cc.director.loadScene("GameOver");
          }, 1);
        }
      },
      setRunStatus: function setRunStatus(args) {
        var self = this;
        self._runStatus = args;
      },
      setColor: function setColor(args) {
        var self = this;
        this.ballPzValue = args;
        switch (args) {
         case 0:
          self.node.color = new cc.color(241, 52, 66, 255);
          break;

         case 1:
          self.node.color = new cc.color(80, 201, 36, 255);
          break;

         case 2:
          self.node.color = new cc.color(14, 172, 216, 255);
          break;

         case 3:
          self.node.color = new cc.color(235, 149, 20, 255);
        }
        this.scheduleOnce(function() {
          this.node.group = "ball";
        }, .2);
      },
      update: function update(dt) {
        true == this._runStatus && (this.node.y += this._ySpeed * dt);
      }
    });
    cc._RF.pop();
  }, {} ],
  Bullet: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "708bffKGrVCJbB4IX8wGNRD", "Bullet");
    "use strict";
    var n = require("SceneObj");
    cc.Class({
      extends: n,
      isBullet: function isBullet() {
        return !0;
      },
      init: function init() {
        this._super(), this.startMove();
      },
      switchAngle: function switchAngle(e) {
        this._angle = e, this._moveDir = Utils.Angle.toVector(e), this.node.angle = -e;
      },
      contact: function contact(e) {
        e.checkHp(), e.showCircleEffect(kk.Config.COLOR_RED, Math.randomInt(10), Math.randomRange(20, 30), this.node.position.sub(e.node.position).mul(.5)), 
        this.die();
      },
      startMove: function startMove() {
        this.speed = kk.Config.bulletMoveSpeed, this.move();
      },
      move: function move() {
        var e = this.node.position, t = kk.curScene.posToGrid(e), i = this.getDirByAngle(this._angle);
        if (kk.curScene.getNextGridOnDir(i, t[0], t[1])) {
          var n = e.add(this._moveDir.mul(this.speed)), s = Utils.distance(n, e) / this.speed, o = cc.moveTo(s, n.x, n.y), a = cc.callFunc(this.move, this);
          this.node.stopAllActions(), this.node.runAction(cc.sequence(o, a));
        } else this.die();
      },
      stopMove: function stopMove() {
        this.node.stopAllActions();
      },
      die: function die() {
        this.node.stopAllActions(), kk.curScene.bulletPool.put(this.node), kk.curScene.removeObj(kk.Enum.ObjType.BULLET, this);
      }
    });
    cc._RF.pop();
  }, {
    SceneObj: "SceneObj"
  } ],
  CCExtensions: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "62714JCLsJDV7kedN2GUgAs", "CCExtensions");
    "use strict";
    cc.Component.prototype.isInstanceOf = function(e) {
      return this instanceof e && this.constructor === e;
    }, cc.Component.prototype.getOrAddComponent = cc.Node.prototype.getOrAddComponent = function(e) {
      var t = this.getComponent(e);
      return t || this.addComponent(e);
    }, cc.Component.EventHandler.execute = function(e) {
      cc.Component.EventHandler.emitEvents([ this ], e);
    }, cc.Node.prototype.getOrAddChild = function(e) {
      if ("string" != typeof e) return this;
      for (var t = this, i = this, n = e.split("/"), s = 0, o = n.length; s < o; s++) (i = t.getChildByName(n[s])) || (i = new cc.Node(n[s]), 
      t.addChild(i)), t = i;
      return i;
    }, cc.Node.prototype.addClickEvent = function(e, t, i, n) {
      if (!e || !t) return null;
      var s = this.getOrAddComponent(cc.Button);
      s.transaction = cc.Button.Transition.SCALE, s.duration = .1, s.zoomScale = .9, s.clickEvents.length && (s.clickEvents = []);
      var o = this.createEvent(e, t, i, n);
      return s.interactable = !0, s.clickEvents.push(o), s;
    }, cc.Node.prototype.createEvent = function(e, t, i, n) {
      if (!e || !t) return null;
      var s = new cc.Component.EventHandler();
      return s.component = e, s.handler = t, s.customEventData = i || "", n = n || this, 
      s.target !== n && (s.target = n), s;
    }, cc.Node.prototype.clearClickEvent = function() {
      var e = this.getComponent(cc.Button);
      e && e.clickEvents.length && (e.clickEvents = []);
    }, cc.Node.prototype.hookOnDestroy = function(e) {
      var t = this._onPreDestroy.bind(this);
      this._onPreDestroy = function() {
        e(), t();
      };
    }, cc.Node.prototype.unHookOnDestroy = function() {
      var e = cc.js.getClassByName(cc.js.getClassName(this));
      this._onPreDestroy = e.prototype._onPreDestroy;
    }, cc.Node.prototype.hookOnActivated = function(e) {
      var t = this._onPostActivated.bind(this);
      this._onPostActivated = function() {
        e(), t();
      };
    }, cc.Node.prototype.unHookOnActivated = function() {
      var e = cc.js.getClassByName(cc.js.getClassName(this));
      this._onPostActivated = e.prototype._onPostActivated;
    }, cc.Node.prototype.translate = function(e) {
      e instanceof cc.Vec2 && this.setPosition(this.position.add(e));
    }, cc.Node.prototype.rotate = function(e) {
      "number" == typeof e && (this.angle += -e);
    };
    cc._RF.pop();
  }, {} ],
  CH: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "911beWCs4NLu4GuegDMWTpJ", "CH");
    "use strict";
    window.i18n || (window.i18n = {}), window.i18n.languages || (window.i18n.languages = {}), 
    window.i18n.languages.CN = {
      sys_text: {
        fontForContent: "ninjaVerbFont",
        fontForTitle: "ninjaVerbFont",
        loading: "Loading",
        confirm: "Confirm"
      },
      error_code: {
        load_error: "Load Error",
        share_error: "Share Error",
        no_ad: "Video is loading, wait for a moment",
        no_net: "Network Error",
        net_time_out: "Time out",
        response_data_error: "Info error"
      },
      label_text: {
        default: "\u9ed8\u8ba4",
        coin: "\u91d1\u5e01",
        gold: "\u94bb\u77f3",
        speed: "\u901f\u5ea6",
        hp: "\u751f\u547d",
        skin: "\u76ae\u80a4",
        start: "\u5f00\u59cb\u6e38\u620f",
        levelIndex: "\u7b2c {0} \u5173",
        ladder: "\u6392\u884c\u699c",
        share_friend: "\u9080\u8bf7\u597d\u53cb",
        free_gold: "\u514d\u8d39\u94bb\u77f3",
        collect: "\u9886\u53d6",
        random: "\u968f\u673a\u89e3\u9501",
        skinSaleOut: "\u76ae\u80a4\u5df2\u5168\u90e8\u89e3\u9501",
        gold_unEnough: "\u94bb\u77f3\u4e0d\u8db3",
        revive_success: "\u606d\u559c\u590d\u6d3b",
        golden_success: "\u83b7\u5f97\u65e0\u654c5\u79d2",
        upgradeRole: "\u5347\u7ea7\u523a\u5ba2",
        music: "\u97f3\u4e50",
        sound: "\u97f3\u6548",
        vibrate: "\u9707\u52a8",
        service: "\u5ba2\u670d",
        settings: "\u8bbe\u7f6e",
        self: "\u81ea\u5df1",
        level: "\u5173",
        main: "\u4e3b\u9875",
        next: "\u4e0b\u4e00\u5173",
        again: "\u91cd\u65b0\u5f00\u59cb",
        replay: "\u6311\u6218",
        defeat: "\u95ef\u5173\u5931\u8d25",
        success: "\u95ef\u5173\u6210\u529f",
        reviveByVideo: "\u89c6\u9891\u590d\u6d3b",
        reviveByShare: "\u5206\u4eab",
        skip: "\u8df3\u8fc7",
        detailForRevive: "\u9a6c\u4e0a\u5c31\u8981\u901a\u5173\u4e86\uff0c\u4e0d\u8981\u653e\u5f03\uff01",
        hasSignedToady: "\u4eca\u65e5\u5df2\u7b7e\u5230\uff0c\u8bf7\u660e\u59290\u70b9\u518d\u6765\u9886\u53d6\uff01",
        rewardTitleCommon: "\u83b7\u5f97\u5956\u52b1",
        rewardTitleOnOver: "\u672c\u5c40\u8d62\u5f97",
        signInPreview: "\u660e\u65e5\u767b\u5f55\u5373\u9001",
        multiGet: "{0}\u500d\u9886\u53d6",
        userLadder: "\u597d\u53cb\u6392\u884c",
        worldLadder: "\u4e16\u754c\u6392\u884c",
        todayLadder: "\u4eca\u65e5\u6392\u884c",
        groupLadder: "\u7fa4\u6392\u884c",
        appListTitle: "\u731c\u4f60\u559c\u6b22",
        task1: "\u6d88\u9664\u76ee\u6807\u6570\u91cf",
        task2: "\u89c2\u770b\u89c6\u9891\u514d\u8d39\u5f97\u94bb\u77f3",
        task3: "\u6536\u96c6\u94bb\u77f3\u6570\u91cf",
        task4: "\u6beb\u53d1\u65e0\u635f\u5b8c\u6210\u4e00\u5173",
        task5: "\u672a\u88ab\u53d1\u73b0\u5b8c\u6210\u4e00\u5173",
        task6: "\u901a\u5173\u6b21\u6570",
        task7: "\u8fde\u6740\u76ee\u6807\u6570\u91cf"
      }
    };
    cc._RF.pop();
  }, {} ],
  CameraManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0e5db+GfDFIFbOl65DIuCH+", "CameraManager");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        _speed: 0,
        _targetPos: !1,
        _isMoving: !1,
        _callback: null,
        _context: null
      },
      update: function update(e) {
        this._isMoving && this._targetPos && (this.node.position = this.node.position.lerp(this._targetPos, e, cc.Vec2.ZERO), 
        Utils.distance(this.node.position, this._targetPos) <= 1 && (this._isMoving = !1, 
        this._targetPos = null));
      },
      alignPosition: function alignPosition(e) {
        var t = this.getCorrectPos(e);
        this.node.setPosition(t);
      },
      startFollow: function startFollow(e, t, i) {
        this._targetPos = this.getCorrectPos(e), this._isMoving = !0, this._callback = t, 
        this._context = i;
      },
      getCorrectPos: function getCorrectPos(e) {
        var t = e.x, i = e.y, n = Math.abs(kk.curScene.mapOriginX + (cc.winSize.width + kk.Config.gridWidth) / 2), s = Math.abs(kk.curScene.mapOriginY - (cc.winSize.height + kk.Config.gridHeight) / 2), o = void 0;
        return o = t.normalize(), t = Math.abs(t) > n ? o * n : Math.floor(t), o = i.normalize(), 
        i = Math.abs(i) > s ? o * s : Math.floor(i), e = null, new cc.Vec2(t, i);
      },
      release: function release() {
        this._speed = 0, this._targetPos = !1, this._isMoving = !1, this._callback = null, 
        this._context = null;
      }
    });
    cc._RF.pop();
  }, {} ],
  Character: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "acac8kehQdOOb35DcWeSRRa", "Character");
    "use strict";
    var n = require("SceneObj");
    cc.Class({
      extends: n,
      properties: {
        hp: 1,
        shadow: null,
        body: null,
        legs: [],
        _anim: null,
        _iState: null,
        _sightType: null,
        _path: [],
        _invincibleEndTime: 0
      },
      setDefaultComps: function setDefaultComps() {
        this.shadow = this.node.getChildByName("Shadow"), this.model = this.node.getChildByName("Model"), 
        this.body = this.model.getChildByName("Body"), this.legs = this.model.getChildByName("Legs").children, 
        this._anim = this.model.getComponent(cc.Animation);
      },
      setDefaultProps: function setDefaultProps() {},
      onDestroy: function onDestroy() {
        this.unregisterEvents();
      },
      getSpeed: function getSpeed() {
        return this.speed;
      },
      getHp: function getHp() {
        return 1;
      },
      updateSkin: function updateSkin() {},
      switchSkin: function switchSkin(e) {},
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.USER_SWITCH_SKIN, this.switchSkin, this);
      },
      unregisterEvents: function unregisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.USER_SWITCH_SKIN, this.switchSkin, this);
      },
      isInState: function isInState(e) {
        return this._iState && e === this._iState.name;
      },
      switchState: function switchState(t) {
        if (this._iState) {
          if (t === this._iState.name) return;
          this.onStateExit();
        }
        var i = require(t);
        i ? (this._iState = new i(this), this.onStateEnter()) : console.warn("RoleState name is wrong.");
      },
      playAnim: function playAnim(e) {
        var t = this.getAnimNameByState(e);
        this._anim.play(t, !0);
      },
      getClipByName: function getClipByName(e) {
        for (var t = this._anim.getClips(), i = t.length - 1; i >= 0; i++) if (t[i].name === e) return t[i];
        return null;
      },
      getAnimNameByState: function getAnimNameByState(e) {
        var t = "idle";
        switch (e) {
         default:
         case kk.Enum.RoleState.IHurt:
         case kk.Enum.RoleState.IIdle:
         case kk.Enum.RoleState.IGuard:
          t = "idle";
          break;

         case kk.Enum.RoleState.IWalk:
         case kk.Enum.RoleState.IRun:
          t = "walk";
          break;

         case kk.Enum.RoleState.IAttack:
          t = "attack";
        }
        return t;
      },
      switchAngle: function switchAngle(e) {
        this._angle = e, this._moveDir = Utils.Angle.toVector(e), this.node.angle = -e, 
        this.body.angle = -0;
      },
      getFaceAngle: function getFaceAngle() {
        return -(this.body.angle + this.node.angle);
      },
      getBodyAngle: function getBodyAngle() {
        return -this.body.angle;
      },
      getModelAngle: function getModelAngle() {
        return -this.node.angle;
      },
      turnDirAsync: function turnDirAsync(e, t) {
        var i = this.getStraightDirByAngle(this.getFaceAngle()), n = this.getReasonableDir(e, i), s = this.getAngleByDir(n), o = cc.rotateTo(.3, s), a = cc.callFunc(function() {
          this.switchAngle(s), t && t(n);
        }.bind(this));
        this.node.stopAllActions(), this.node.runAction(cc.sequence(o, a));
      },
      turnDirSync: function turnDirSync(e, t) {
        var i = this.getStraightDirByAngle(this.getFaceAngle()), n = this.getReasonableDir(e, i, kk.Config.filterNum), s = this.getAngleByDir(n);
        if (this.node.stopAllActions(), t) this.switchAngle(s); else {
          var o = cc.rotateTo(.3, s), a = cc.callFunc(function() {
            this.switchAngle(s);
          }.bind(this));
          this.node.runAction(cc.sequence(o, a));
        }
        return n;
      },
      getCurPath: function getCurPath() {
        return this._path || (this._path = []);
      },
      clearPath: function clearPath() {
        this._path = [];
      },
      updatePath: function updatePath(e) {
        this._path = [].concat(e), this._colorFromIndex = 0, e = null;
      },
      pathUpdateSetting: function pathUpdateSetting(e) {},
      pathEndSetting: function pathEndSetting() {},
      contact: function contact(e) {},
      follow: function follow(e) {},
      interact: function interact(e) {
        this.isIntersects(e) ? this.contact(e) : this.look(e);
      },
      startAttack: function startAttack() {},
      attack: function attack() {},
      hurt: function hurt() {
        var e = cc.tintTo(.3, 255, 80, 80), t = cc.tintTo(.3, 255, 200, 200);
        this.body.stopAllActions(), this.body.runAction(cc.repeatForever(cc.sequence(e, cc.delayTime(.1), t, cc.delayTime(.1))));
      },
      die: function die() {
        this.node.stopAllActions(), this.shadow.active = !1, this.model.active = !1, TimerHandler.add(TimerHandler.Type.GAME, TimerHandler.Loop.ONCE, 5, function() {
          this._selectTracer && (this._selectTracer.node.stopAllActions(), this._selectTracer.node.getComponent("SubItem").parent = null, 
          kk.GlSystem.remove(this._selectTracer)), this.node.destroy();
        }, this);
      },
      addInvincible: function addInvincible() {
        this._invincibleEndTime = Date.now() + kk.Config.invincibleInternal;
      },
      isInvincible: function isInvincible() {
        return Date.now() < this._invincibleEndTime;
      },
      checkHp: function checkHp() {
        console.log("===hp:" + this.hp);
        var disnum = 1;
        disnum = kk.curUser.getCurLevel() <= 3 ? 1 : kk.curUser.getCurLevel() <= 7 ? 2 : 3;
        this.isInvincible() || (this.getHp() <= 1 ? (this.hp = 0, this.switchState(kk.Enum.RoleState.IDead)) : (this.hp = this.hp - disnum, 
        this.hurt()));
      },
      isIntersects: function isIntersects(e) {
        return e.node.getBoundingBox().intersects(this.node.getBoundingBox());
      },
      isInSight: function isInSight(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], i = this.node.position, n = e.node.position, s = Utils.Angle.toVector(this.getFaceAngle()), o = e.node.position.sub(this.node.position), a = Utils.Angle.fromRadian(o.angle(s)), r = t ? 5 * kk.Config.sightDistance : kk.Config.sightDistance;
        return !(Utils.distance(n, i) > r || a > kk.Config.sightAngle) && this.getFarawaySightOnDir(i, n);
      },
      getFarawaySightOnDir: function getFarawaySightOnDir(e, t, i) {
        var n = Utils.distance(t, e), s = t.sub(e).normalize(), o = void 0, a = void 0, r = void 0, c = !0, u = 1, d = kk.Config.sightDistance / kk.Config.sightRayStep;
        do {
          if (o = e.add(s.mul(u * kk.Config.sightRayStep)), a = kk.curScene.posXToGrid(o.x), 
          r = kk.curScene.posYToGrid(o.y), !kk.curScene.isMovableGrid(a, r)) {
            c = !1;
            break;
          }
          u++;
        } while (n > Utils.distance(o, e) && u < d);
        return i && (i.x = 2 * Math.floor(o.x / 2), i.y = 2 * Math.floor(o.y / 2)), c;
      },
      showCircleEffect: function showCircleEffect(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 200, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 30, n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : cc.Vec2.ZERO, s = (i - t) / 20, o = i > t ? 1 : 0, a = o ? .2 : -.2;
        this._selectTracer || (this._selectTracer = kk.GlSystem.add(kk.Enum.PathKey.ORIGIN, 5), 
        this._selectTracer.node.addComponent("SubItem").parent = this.node, this._selectTracer.node.setParent(kk.curScene.getLayerNode())), 
        this._selectTracer.lineWidth = 5, this._selectTracer.strokeColor = e, this._selectTracer.moveTo(n.x, n.y);
        var r = cc.callFunc(function() {
          o && t > i || !o && t < i || (this._selectTracer.lineWidth += a, this._selectTracer.clear(), 
          this._selectTracer.circle(n.x, n.y, t), this._selectTracer.stroke(), t += s);
        }, this), c = cc.callFunc(function() {
          this._selectTracer.node.stopAllActions(), this._selectTracer.clear();
        }, this);
        return this._selectTracer.node.stopAllActions(), this._selectTracer.node.runAction(cc.sequence(cc.repeat(cc.sequence(r, cc.delayTime(.02)), 20), c)), 
        this._selectTracer;
      }
    });
    cc._RF.pop();
  }, {
    SceneObj: "SceneObj"
  } ],
  Client: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "b89b7wmHUFJp61VuF2RPEbF", "Client");
    "use strict";
    function n(e) {
      if (Array.isArray(e)) {
        for (var t = 0, i = Array(e.length); t < e.length; t++) i[t] = e[t];
        return i;
      }
      return Array.from(e);
    }
    var s = require("User"), o = require("Scene"), a = require("UserData"), r = require("SceneData"), c = require("AldEvents"), u = {
      _connectData: null,
      _userData: null,
      _sceneData: null,
      _adConfig: null,
      _shareData: null,
      _messageList: [],
      _isAwake: !1,
      _loadScreen: null,
      _tryCount: 0,
      _userDataOnline: !1,
      _taskDataOnline: !1,
      init: function init() {
        kk.SdkBridger.init(), kk.LocalizeSystem.init(), this.showLoading(this.login, this);
      },
      showLoading: function showLoading(e, t) {
        if (MessageHandler.add(kk.Enum.MsgKey.GAME_INIT_OVER, this.hideLoading, this), this._loadScreen) return this._loadScreen.setProgressBar(0, 1), 
        this._loadScreen.node.active = !0, void (e && t && e.call(t, this._loadScreen));
        kk.AssetLib.loadAsset(kk.Config.launchResPath, cc.Prefab, function(i) {
          var n = cc.instantiate(i);
          kk.Canvas().addChild(n), n.setContentSize(cc.winSize), n.setPosition(0, 0), n.zIndex = kk.Enum.LayerDepth.MASK, 
          this._loadScreen = n.getOrAddComponent(kk.LoadScreen), this._loadScreen.setProgressBar(0, 1), 
          e && t && e.call(t, this._loadScreen), i = null;
        }, null, this);
      },
      updateLoading: function updateLoading(e, t) {
        this._loadScreen && this._loadScreen.onProgress(e, t);
      },
      hideLoading: function hideLoading() {
        MessageHandler.remove(kk.Enum.MsgKey.GAME_INIT_OVER, this.hideLoading, this), this._loadScreen && this._loadScreen.node.destroy();
      },
      login: function login() {
        kk.Config.isLocal ? this.localLogin() : this.sdkLogin();
      },
      launchGame: function launchGame() {
        kk.Game.isLaunched() ? kk.Game.begin() : (this.registerEvents(), kk.Game.init(), 
        kk.Game.preload(), kk.AssetLib.loadAssets(kk.Config.listOfPreload, kk.Game.loaded.bind(kk.Game), null, this.updateLoading.bind(this)));
      },
      onClientRestart: function onClientRestart() {
        this.unRegisterEvents();
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.SDK_NAVIGATE_OUT, this.navigateCB, this), MessageHandler.add(kk.Enum.MsgKey.SDK_AUTHOR_LOGIN, this.authorizedLoginCB, this);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.SDK_NAVIGATE_OUT, this.navigateCB, this), MessageHandler.remove(kk.Enum.MsgKey.SDK_AUTHOR_LOGIN, this.authorizedLoginCB, this);
      },
      pushMessage: function pushMessage() {
        var e = Array.prototype.slice.call(arguments);
        this._messageList.push(e), this._isAwake && null !== this._messageTimer || this.awakeMessage();
      },
      awakeMessage: function awakeMessage() {
        var e = this;
        this._isAwake = !0, this._messageTimer = setInterval(function() {
          e.executeMessage();
        }, 2e3);
      },
      executeMessage: function executeMessage() {
        if (this._messageList.length) {
          var e = this._messageList.shift();
          this.saveUserData.apply(this, n(e));
        } else Utils.isNone(this._messageTimer) || clearInterval(this._messageTimer), this._isAwake = !1, 
        this._messageTimer = null;
      },
      initUser: function initUser(e) {
        var t = !1;
        e || (e = new a().unSerialize(), t = !0), kk.curUser = new s(e), kk.TaskSystem.init(), 
        t && this.saveUser();
      },
      initScene: function initScene(e) {
        var t = !1;
        e || (e = new r().unSerialize(), t = !0), kk.curScene = new o(e, null, InfiniteMap.Type.CLONE), 
        t && this.saveScene();
      },
      saveUser: function saveUser() {
        var e = Array.prototype.slice.call(arguments), t = e[e.length - 1];
        if (!("function" != typeof t || this._userDataOnline && (e[0] !== kk.ServerApi.Address.POST_TASK_UPDATE && e[0] !== kk.ServerApi.Address.POST_TASK_CREATE && e[0] !== kk.ServerApi.POST_TASK_ACHIEVE || this._taskDataOnline))) return t({
          code: 0,
          msg: "success",
          isLocal: 1,
          result: {}
        }), void kk.save(kk.Config.keyForUserData, kk.curUser.getInfo());
        if (kk.save(kk.Config.keyForUserData, kk.curUser.getInfo()), !kk.Config.isLocal) {
          if (!e.length) throw new Error("Client.saveUserData(api) params are undefined.");
          this.pushMessage.apply(this, n(e));
        }
      },
      saveScene: function saveScene() {
        kk.save(kk.Config.keyForSceneData, kk.curScene.getInfo());
      },
      sdkLogin: function sdkLogin() {
        console.log("sdkLogin..."), MessageHandler.add(kk.Enum.MsgKey.SDK_GAME_LOGIN, this.sdkLoginCB, this), 
        kk.sdkBridger.postDesignEvent(c.sdkPlatform, "version", kk.sdkBridger.version, "platform", kk.sdkBridger.platform), 
        kk.sdkBridger.postDesignEvent(c.sdkLogin, "step", 1), kk.sdkBridger.login(), kk.sdkBridger.initBanner();
      },
      sdkLoginCB: function sdkLoginCB() {
        console.log("sdkLoginCB..."), MessageHandler.remove(kk.Enum.MsgKey.SDK_GAME_LOGIN, this.sdkLoginCB, this);
        var e = Array.prototype.slice.call(arguments);
        if (e[0]) {
          var t = kk.load(kk.Config.keyForUserData);
          this._userData = new a(t), this._connectData = Utils.clone(e[1]), this.initUser(this._userData.unSerialize()), 
          this.launchGame(), this.connect(), this.getConfig(), this.getShareData(), this.getAdConfig(), 
          setTimeout(function() {
            kk.sdkBridger.initVideo();
          }, .01);
        }
      },
      connect: function connect() {
        if (this._tryCount >= 10) return this._tryCount = 0, void kk.sdkBridger.postDesignEvent(c.getUserInfo, "getUseInfoRetryOut", 10);
        kk.sdkBridger.postDesignEvent(c.getUserInfo, "step", 2);
        var e = new HttpHandler.Message(), t = this._connectData;
        e.put("apiKey", kk.ServerApi.apiKey), e.put("timestamp", Date.now()), e.put("version", kk.ServerApi.version.toString()), 
        e.put("code", t.code), t.sceneId && e.put("scene_id", t.sceneId), t.source && e.put("source", t.source), 
        t.channel && e.put("channel", t.channel), t.shareId && e.put("share_id", t.shareId), 
        t.shareUserId && e.put("share_user_id", t.shareUserId), e.put("apiSign", kk.ServerApi.sign(e.getData())), 
        HttpHandler.notify(kk.ServerApi.getUrl(kk.ServerApi.Address.LOGIN), e, this.onUserInfoResponse.bind(this), this.onUserInfoError.bind(this)), 
        this._tryCount++, t = null;
      },
      onUserInfoError: function onUserInfoError() {},
      onUserInfoResponse: function onUserInfoResponse(e) {
        if (kk.sdkBridger.postDesignEvent(c.getUserInfoResponse, "step", 2), e && 0 === e.code && e.result && e.result.userInfo && e.result.userSkin) {
          var t = e.result.userInfo, i = e.result.userSkin;
          this._userDataOnline = !0, kk.ServerApi.token = e.result.token, this.updateUserInfo(t, i), 
          this.getUserTask(), e = null;
        }
      },
      updateUserInfo: function updateUserInfo(e, t) {
        kk.curUser.setInfo("id", e.id), kk.curUser.setInfo("openid", e.openid), kk.curUser.setInfo("gender", e.gender), 
        kk.curUser.setInfo("nickName", e.nickname), kk.curUser.setInfo("avatar", e.avatar), 
        kk.curUser.setInfo("gold", e.total_gold), kk.curUser.setInfo("playedLevel", e.level), 
        kk.curUser.setInfo("remainVideoCount", e.surplus_video), kk.curUser.setInfo("isSigned", e.signed), 
        kk.curUser.setInfo("curSkin", t.default_skin);
        var i = kk.curUser.getSkins(), n = t.unlock_skin;
        if (n && n.length) for (var s = 0; s < n.length; s++) i[s] = parseInt(n[s]);
        kk.save(kk.Config.keyForUserData, kk.curUser.getInfo()), MessageHandler.dispatch(kk.Enum.MsgKey.USER_UPDATE_LEVEL), 
        MessageHandler.dispatch(kk.Enum.MsgKey.USER_UPDATE_GOLD), MessageHandler.dispatch(kk.Enum.MsgKey.USER_SWITCH_SKIN), 
        MessageHandler.dispatch(kk.Enum.MsgKey.USER_UPDATE_SIGN_STATE);
      },
      getUserTask: function getUserTask() {
        if (this._tryCount >= 10) return this._tryCount = 0, void kk.sdkBridger.postDesignEvent(c.getUserTask, "getUseTaskRetryOut", 10);
        kk.sdkBridger.postDesignEvent(c.getUserTask, "step", 3);
        var e = new HttpHandler.Message();
        e.put("apiKey", kk.ServerApi.apiKey), e.put("timestamp", Date.now()), e.put("version", kk.ServerApi.version.toString()), 
        e.put("token", kk.ServerApi.token), e.put("apiSign", kk.ServerApi.sign(e.getData())), 
        HttpHandler.notify(kk.ServerApi.getUrl(kk.ServerApi.Address.GET_TASK), e, this.getTaskResponse.bind(this), this.onTaskInfoError.bind(this)), 
        this._tryCount++;
      },
      getTaskResponse: function getTaskResponse(e) {
        if (kk.sdkBridger.postDesignEvent(c.getTaskResponse, "step", 3), e && 0 === e.code && e.result) {
          var t = Utils.clone(e.result);
          this._taskDataOnline = !0, this.updateTaskInfo(t);
        }
      },
      onTaskInfoError: function onTaskInfoError() {
        console.warn("\u83b7\u53d6\u4efb\u52a1\u4fe1\u606f\u5931\u8d25"), this.getUserTask();
      },
      updateTaskInfo: function updateTaskInfo(e) {
        for (var t = kk.curUser.getTasks(), i = 0; i < e.length; i++) t[i] = {
          id: e[i].task_id,
          type: e[i].type,
          cur: e[i].current,
          aim: e[i].aim,
          reward: e[i].reward
        };
        kk.TaskSystem.refresh();
      },
      authorizedLoginCB: function authorizedLoginCB(e, t) {
        kk.sdkBridger.postDesignEvent(c.authorizedLogin, "step", 3);
        var i = new HttpHandler.Message();
        i.put("apiKey", kk.ServerApi.apiKey), i.put("timestamp", Date.now()), i.put("version", kk.ServerApi.version.toString()), 
        i.put("token", kk.ServerApi.token), i.put("encrypted_data", e), i.put("iv", t), 
        i.put("apiSign", kk.ServerApi.sign(i.getData())), i.put("encrypted_data", encodeURIComponent(e)), 
        i.put("iv", encodeURIComponent(t)), HttpHandler.notify(kk.ServerApi.getUrl(kk.ServerApi.Address.LOGIN_AUTHOR), i, this.onAuthorizedLoginResponse.bind(this));
      },
      onAuthorizedLoginResponse: function onAuthorizedLoginResponse(e) {
        kk.sdkBridger.postDesignEvent(c.onAuthorizedLoginResponse, "step", 3), e && 0 === e.code && (kk.ServerApi.headUrl = e.result.userInfo.avatar, 
        kk.ServerApi.nickName = e.result.userInfo.nickname);
      },
      getConfig: function getConfig() {
        kk.sdkBridger.postDesignEvent(c.getConfig, "step", 4);
        var e = new HttpHandler.Message(HttpHandler.MethodType.GET);
        e.put("apiKey", kk.ServerApi.apiKey), e.put("timestamp", Date.now()), e.put("version", kk.ServerApi.version.toString()), 
        e.put("token", kk.ServerApi.token), kk.sdkBridger.launchOption && e.put("scene_id", kk.sdkBridger.launchOption.scene), 
        e.put("apiSign", kk.ServerApi.sign(e.getData())), HttpHandler.notify(kk.ServerApi.getUrl(kk.ServerApi.Address.GET_CONFIG), e, this.getConfigResponse.bind(this));
      },
      getConfigResponse: function getConfigResponse(e) {
        if (kk.sdkBridger.postDesignEvent(c.getConfigResponse, "step", 4), e && 0 === e.code) {
          var t = e.result.delayBannerTime.split(",");
          kk.ServerApi.bannerSwitch = e.result.bannerSwitch, kk.ServerApi.shareSwitch = e.result.shareSwitch, 
          kk.ServerApi.reviveBannerDelayTime = parseInt(t[0]), kk.ServerApi.rewardBannerDelayTime = parseInt(t[1]), 
          kk.ServerApi.overBannerDelayTime = parseInt(t[2]), e = null;
        }
      },
      getShareData: function getShareData() {},
      getShareDataResponse: function getShareDataResponse(e) {},
      recordClickShare: function recordClickShare(e, t) {},
      recordSuccessShare: function recordSuccessShare(e, t) {},
      getAdConfig: function getAdConfig(e) {},
      getAdConfigResponse: function getAdConfigResponse(e) {},
      navigateCB: function navigateCB() {
        var e = Array.prototype.slice.call(arguments), t = e[0] ? 1 : 0, i = e[1], n = e[2], s = new HttpHandler.Message();
        s.put("apiKey", kk.ServerApi.apiKey), s.put("timestamp", Date.now()), s.put("version", kk.ServerApi.version.toString()), 
        s.put("token", kk.ServerApi.token), s.put("appid", i), s.put("jump", t), s.put("category", n), 
        s.put("apiSign", kk.ServerApi.sign(s.getData())), HttpHandler.notify(kk.ServerApi.getUrl(kk.ServerApi.Address.CLICK_APP), s, this.onNavigateResponse.bind(this)), 
        t ? MessageHandler.add(kk.Enum.MsgKey.APP_BECOME_SHOW, this.autoOpenAdListOnBack, this) : this.autoOpenAdListOnBack();
      },
      onNavigateResponse: function onNavigateResponse(e) {},
      autoOpenAdListOnBack: function autoOpenAdListOnBack() {},
      saveUserData: function saveUserData() {
        var e = Array.prototype.slice.call(arguments), t = new HttpHandler.Message();
        switch (t.put("apiKey", kk.ServerApi.apiKey), t.put("timestamp", Date.now()), t.put("version", kk.ServerApi.version.toString()), 
        t.put("token", kk.ServerApi.token), e[0]) {
         case kk.ServerApi.Address.POST_TASK_ACHIEVE:
          t.put("task_id", e[1]);
          break;

         case kk.ServerApi.Address.POST_TASK_UPDATE:
          t.put("task_id", e[1]), t.put("current", e[2]);
          break;

         case kk.ServerApi.Address.POST_TASK_CREATE:
          t.put("type", e[1]), t.put("aim", e[2]), t.put("reward", e[3]);
          break;

         case kk.ServerApi.Address.POST_SKIN_SWITCH:
          t.put("skin_id", e[1]);
          break;

         case kk.ServerApi.Address.POST_SKIN_UNLOCK:
          t.put("unlock_mode", 1), t.put("unlock_id", e[1]), t.put("price", e[2]);
          break;

         case kk.ServerApi.Address.POST_GAME_OVER:
          t.put("gold", e[2]), t.put("level", e[1]), t.put("score", 0), t.put("revive", e[3]);
          break;

         case kk.ServerApi.Address.POST_SIGN_IN:
          break;

         case kk.ServerApi.Address.POST_GET_GOLD:
          t.put("mode", e[1]), t.put("diamond", e[2]);
          break;

         default:
          return;
        }
        t.put("apiSign", kk.ServerApi.sign(t.getData()));
        var i = e[e.length - 1];
        i = i && "function" == typeof i ? i : null, HttpHandler.notify(kk.ServerApi.getUrl(e[0]), t, function(e) {
          i && i(e);
        });
      },
      getRank: function getRank(e, t, i) {},
      createPlayer: function createPlayer() {},
      loadConfig: function loadConfig() {
        kk.AssetLib.loadAsset("config/sdkConfig", cc.JsonAsset, function(e) {
          kk.sdkBridger.initBanner(e), kk.sdkBridger.initVideo(e), kk.sdkBridger.initShare(e), 
          e = null;
        }, null, this);
      },
      localLogin: function localLogin() {
        var e = kk.load(kk.Config.keyForUserData);
        this.initUser(e), TimerHandler.setServerTime({
          time: Date.now()
        }), this.loadConfig(), this.launchGame();
      }
    };
    module.exports = u;
    cc._RF.pop();
  }, {
    AldEvents: "AldEvents",
    Scene: "Scene",
    SceneData: "SceneData",
    User: "User",
    UserData: "UserData"
  } ],
  Compiler: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "cc5c7f5w1lJG6uzlmMwmgc9", "Compiler");
    "use strict";
    var n = T(require("LoadScreen")), s = T(require("AnimLib")), o = T(require("AssetLib")), a = T(require("Client")), r = T(require("Game")), c = T(require("GameObject")), u = T(require("Gui")), d = T(require("SerializableData")), l = require("AudioSystem"), h = T(require("GlSystem")), k = T(require("GuiSystem")), g = T(require("LocalizeSystem")), p = T(require("MoveSystem")), f = T(require("TaskSystem")), m = T(require("Config")), S = T(require("Enum")), v = T(require("SdkBridger")), E = T(require("ServerApi"));
    function T(e) {
      return e && e.__esModule ? e : {
        default: e
      };
    }
    (function() {
      function e(e, t) {
        if (kk.hasOwnProperty(e)) throw new Error("duplicated " + e);
        if (!t) throw new Error("undefined " + e);
        return kk[e] = t, t;
      }
      e("Config", m.default), e("Enum", S.default), e("AnimLib", s.default), e("AssetLib", o.default), 
      e("Client", a.default), e("Game", r.default), e("GameObject", c.default), e("Gui", u.default), 
      e("SerializableData", d.default), e("AudioSystem", l.AudioSystem), e("AudioType", l.AudioType), 
      e("AudioName", l.AudioName), e("GuiSystem", k.default), e("GlSystem", h.default), 
      e("LocalizeSystem", g.default), e("MoveSystem", p.default), e("TaskSystem", f.default), 
      e("SdkBridger", v.default), e("ServerApi", E.default), e("LoadScreen", n.default), 
      console.log("Compile Over..."), cc.director.on(cc.Director.EVENT_AFTER_SCENE_LAUNCH, function e() {
        cc.director.off(cc.Director.EVENT_AFTER_SCENE_LAUNCH, e), console.log("Check Update..."), 
        kk.Client.init();
      });
    })();
    cc._RF.pop();
  }, {
    AnimLib: "AnimLib",
    AssetLib: "AssetLib",
    AudioSystem: "AudioSystem",
    Client: "Client",
    Config: "Config",
    Enum: "Enum",
    Game: "Game",
    GameObject: "GameObject",
    GlSystem: "GlSystem",
    Gui: "Gui",
    GuiSystem: "GuiSystem",
    LoadScreen: "LoadScreen",
    LocalizeSystem: "LocalizeSystem",
    MoveSystem: "MoveSystem",
    SdkBridger: "SdkBridger",
    SerializableData: "SerializableData",
    ServerApi: "ServerApi",
    TaskSystem: "TaskSystem"
  } ],
  ConfigData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "67930ALlDRPHotnl1Q9UQGs", "ConfigData");
    "use strict";
    var n = require("SerializableData");
    cc.Class({
      extends: n,
      properties: {
        SceneIdData: "1001,1022,1023,1034,1035,1037,1038,1043,1067,1069,1078,1089,1090,1091,1102,1103,1104",
        OverConfig: "0.9,0.8,0.3",
        AwardConfig: "0.9,0.8,0.3",
        SettleConfig: "0.9,0.8,0.3",
        BannerAdRefreshTime: "10",
        OpenChestObbs: "0.8",
        OpenTryObbs: "0.3",
        OpenSkinObbs: "0.05",
        OpenBXRange: "0.5,0.8",
        SkinVideoFBNum: "9",
        OpenUnlockSkinObbs: "0.5",
        bannerSwitch: 0,
        shareSwitch: 0,
        ip: "171.113.170.51"
      }
    });
    cc._RF.pop();
  }, {
    SerializableData: "SerializableData"
  } ],
  Config: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e8f568GM+pJC7MjZfASsQ7G", "Config");
    "use strict";
    var n = {
      isLocal: !1,
      launchResPath: "gui/LoadScreen",
      launchDelayTime: 1e3,
      keyForUserData: "Assassin_User",
      keyForSceneData: "Assassin__Scene",
      keyForAnalytics: "Assassin__Analytics",
      baseRandomPrice: 1e3,
      skinVideoReward: 250,
      skinCount: 10,
      taskMaxCount: 3,
      vipDuration: 6048e5,
      signInRewards: [ 200, 500, 800, 1e3 ],
      playerWalkSpeed: 5,
      playerRunSpeed: 10,
      monsterWalkSpeed: 2,
      monsterRunSpeed: 4,
      bulletMoveSpeed: 600,
      gridWidth: 80,
      gridHeight: 80,
      filterNum: 5,
      searchDuration: 3e4,
      projectionColor: new cc.Color(0, 0, 0, 50),
      maskColor: new cc.Color(0, 0, 0, 100),
      defaultHp: 4,
      followValidDistance: 640,
      sightDistance: 240,
      sightAngle: 40,
      sightPrecision: 30,
      sightRayStep: 12,
      sightStrokeColor: new cc.Color(255, 255, 255, 20),
      sightFillColor: new cc.Color(255, 255, 255, 50),
      sightStrokeColorAttack: new cc.Color(255, 0, 0, 10),
      sightFillColorAttack: new cc.Color(255, 0, 0, 50),
      COLOR_BLUE: "#00CAFF",
      COLOR_YELLOW: "#FFFF00",
      COLOR_ORANGE: "#FF6700",
      COLOR_RED: "#FF3B4C",
      COLOR_WHITE: "#FFFFFF",
      limitLevel: 1e5,
      limitMapId: 4,
      killMonsterReward: 10,
      gameSuccessReward: 20,
      invincibleInternal: 5e3,
      listOfPreload: {
        "plist/tiles": cc.SpriteAtlas,
        "plist/common": cc.SpriteAtlas,
        "config/skinInfo": cc.JsonAsset,
        "config/tileConfig": cc.JsonAsset,
        "prefab/Scene": cc.Prefab,
        "prefab/Player": cc.Prefab,
        "prefab/Bullet": cc.Prefab
      },
      appWhiteList: []
    };
    module.exports = n;
    cc._RF.pop();
  }, {} ],
  DefeatUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "78bbfflsXZLIoFnlyp0hFG0", "DefeatUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      init: function init() {
        this.levelLabel = this.node.getChildByName("Level").getComponent(cc.Label), this.getComponentInChildren("ObstructTouch").init();
      },
      updateData: function updateData() {
        this.levelLabel.string = String.format(kk.LocalizeSystem.localizeText("label_text.levelIndex"), kk.curUser.getCurLevel());
      },
      again: function again() {
        kk.quickStart = !0, this.close();
      },
      onClose: function onClose() {
        kk.sdkBridger.hideBanner(kk.sdkBridger.bannerForOver), this._super(), kk.Game.restart();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  EN: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5f738k0ILpJ1pcrFjLsmEfb", "EN");
    "use strict";
    window.i18n || (window.i18n = {}), window.i18n.languages || (window.i18n.languages = {}), 
    window.i18n.languages.EN = {
      sys_text: {
        fontForContent: "ninjaVerbFont",
        fontForTitle: "ninjaVerbFont",
        loading: "Loading",
        confirm: "Confirm"
      },
      error_text: {
        load_error: "Load Error",
        share_error: "Share Error",
        no_ad: "Video is loading, wait for a moment",
        no_net: "Network Error",
        net_time_out: "Time out",
        response_data_error: "Info error"
      },
      label_text: {
        coin: "coin",
        gold: "gold",
        speed: "speed",
        hp: "HP",
        skin: "Skin",
        start: "Start Game",
        levelIndex: "LV: {0}",
        ladder: "Rank",
        share_friend: "invate",
        free_gold: "Free Gold",
        collect: "Collect",
        random: "Random",
        skinSaleOut: "Sale Out",
        gold_unEnough: "gold unenough",
        revive_success: "revive",
        golden_success: "invincible 5s",
        upgradeRole: "upgrade role",
        music: "music",
        sound: "sound",
        vibrate: "vibrate",
        service: "service",
        settings: "settings",
        default: "default",
        self: "self",
        level: "lv",
        main: "main",
        next: "Next",
        again: "Again",
        replay: "Replay",
        defeat: "defeat",
        success: "success",
        reviveByVideo: "reviveByVideo",
        reviveByShare: "reviveByShare",
        skip: "skip",
        detailForRevive: "Will Win\uff01",
        hasSignedToady: "Signed",
        loadingDetail: "loading...",
        rewardTitleCommon: "reward",
        rewardTitleOnOver: "reward",
        signInPreview: "sign reward",
        multiGet: "{0} Collect",
        userLadder: "rank",
        worldLadder: "rank",
        todayLadder: "rank",
        groupLadder: "rank",
        appListTitle: "rank",
        task1: "Kill ",
        task2: "Watch Video",
        task3: "Collect",
        task4: "Lossless",
        task5: "Undiscovered",
        task6: "Complete",
        task7: "Kill lasts"
      }
    };
    cc._RF.pop();
  }, {} ],
  Enum: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4b179roS25EyonjseT1G796", "Enum");
    "use strict";
    var n = {
      GameEvent: cc.Enum({
        GAME_LAUNCH: "GAME_LAUNCH",
        GAME_LOADED: "GAME_LOADED",
        GAME_BEGIN: "GAME_BEGIN",
        GAME_START: "GAME_START",
        GAME_BATTLE: "GAME_BATTLE",
        GAME_PAUSE: "GAME_PAUSE",
        GAME_RESUME: "GAME_RESUME",
        GAME_RESTART: "GAME_RESTART",
        GAME_DEFEAT: "GAME_DEFEAT",
        GAME_SUCCESS: "GAME_SUCCESS",
        GAME_STOP: "GAME_STOP",
        GAME_EXIT: "GAME_EXIT",
        GAME_HIDE: "GAME_HIDE",
        GAME_SHOW: "GAME_SHOW"
      }),
      GameState: cc.Enum({
        OFFLINE: 0,
        LOADED: 1,
        LAUNCH: 2,
        READY: 3,
        BEGIN: 4,
        START: 5,
        PAUSE: 6,
        RESUME: 7,
        STOP: 8,
        DEFEAT: 9,
        SUCCESS: 10
      }),
      CostType: cc.Enum({
        COIN: "coin",
        GOLD: "gold"
      }),
      RoleState: cc.Enum({
        IIdle: "IIdle",
        IWalk: "IWalk",
        IRun: "IRun",
        IAttack: "IAttack",
        IGuard: "IGuard",
        IHurt: "IHurt",
        IDead: "IDead"
      }),
      ProgressType: cc.Enum({
        PERCENT: 0,
        NUMBER: 1
      }),
      LayerDepth: cc.Enum({
        GUI: 1e3,
        TIPS: 2e3,
        MASK: 3e3,
        TOP: 1e4
      }),
      MsgKey: cc.Enum({
        TOUCH_START: "TOUCH_START",
        TOUCH_MOVE: "TOUCH_MOVE",
        TOUCH_END: "TOUCH_END",
        TOUCH_CANCEL: "TOUCH_CANCEL",
        GAME_INIT_OVER: "GAME_INIT_OVER",
        APP_BECOME_SHOW: "APP_BECOME_SHOW",
        APP_BECOME_HIDE: "APP_BECOME_HIDE",
        SDK_GAME_LOGIN: "SDK_GAME_LOGIN",
        SDK_GET_CONFIG: "SDK_GET_CONFIG",
        SDK_NAVIGATE_OUT: "SDK_NAVIGATE_OUT",
        SDK_AUTHOR_LOGIN: "SDK_AUTHOR_LOGIN",
        USER_UPDATE_COIN: "USER_UPDATE_COIN",
        USER_UPDATE_GOLD: "USER_UPDATE_GOLD",
        USER_UPDATE_LEVEL: "USER_UPDATE_LEVEL",
        USER_UPDATE_SIGN: "USER_UPDATE_SIGN",
        USER_UPDATE_SIGN_STATE: "USER_UPDATE_SIGN_STATE",
        USER_ADD_COIN: "USER_ADD_COIN",
        USER_ADD_GOLD: "USER_ADD_GOLD",
        USER_SWITCH_SKIN: "USER_SWITCH_SKIN",
        USER_UNLOCK_SKIN: "USER_UNLOCK_SKIN",
        USER_TASK_UPDATE: "USER_TASK_UPDATE",
        GUI_MAIN_TASK_WAIT: "GUI_MAIN_TASK_WAIT",
        GUI_MAIN_TASK_ANIM_BACK: "GUI_MAIN_TASK_ANIM_BACK",
        GUI_MAIN_SIGN_REWARD: "GUI_MAIN_SIGN_REWARD",
        GUI_MAIN_TASK_TEMP_UPDATE: "GUI_MAIN_TASK_TEMP_UPDATE",
        GUI_REWARD_REWARD: "GUI_REWARD_REWARD",
        LEVEL_KILL_MONSTER: "LEVEL_KILL_MONSTER",
        LEVEL_FIND_PLAYER: "LEVEL_FIND_PLAYER",
        LEVEL_GAME_COUNT: "LEVEL_GAME_COUNT",
        LEVEL_KILL_CONTINUOUS: "LEVEL_KILL_CONTINUOUS",
        LEVEL_BATTLE_OVER: "LEVEL_BATTLE_OVER",
        ADS_VIDEO: "ADS_VIDEO",
        ADS_INTER: "ADS_INTER",
        ADS_BANNER: "ADS_BANNER",
        ADS_LIST_INTER_CLOSE: "ADS_LIST_INTER_CLOSE",
        VIDEO_WATCHED: "VIDEO_WATCHED",
        SKU_INGOT: "SKU_INGOT",
        SKU_VIP: "SKU_VIP",
        SKU_SKIN: "SKU_SKIN",
        SKU_RESTORE: "SKU_RESTORE",
        SHARE_PERSONAL: "SHARE_PERSONAL",
        SHARE_GROUP: "SHARE_GROUP"
      }),
      SdkTag: cc.Enum({
        VIDEO_TASK_EARN_GEM: "VIDEO_TASK_EARN_GEM",
        VIDEO_SKIN_EARN_GEM: "VIDEO_SKIN_EARN_GEM",
        MULTI_EARN_GEM: "MULTI_EARN_GEM",
        SHARE_MAIN_EARN_GEM: "SHARE_MAIN_EARN_GEM",
        VIDEO_SCENE_INVINCIBLE: "VIDEO_SCENE_INVINCIBLE",
        VIDEO_REVIVE: "VIDEO_REVIVE",
        VIDEO_SKIN_TEST_RANDOM: "VIDEO_SKIN_TEST_RANDOM",
        VIDEO_SKIN_TEST: "VIDEO_SKIN_TEST",
        SHARE_REVIVE: "SHARE_REVIVE"
      }),
      ShareMode: cc.Enum({
        DEFAULT: 0,
        RANDOM: 1,
        SCREEN: 2
      }),
      PathKey: cc.Enum({
        VIEW: "VIEW",
        ORIGIN: "ORIGIN",
        PATH: "PATH",
        PROJECTION: "PROJECTION"
      }),
      PathMode: cc.Enum({
        STROKE: 0,
        FILL: 1,
        BOTH: 2
      }),
      PathShape: cc.Enum({
        LINE: 0,
        CURVE: 1,
        CIRCLE: 2
      }),
      TaskAimType: cc.Enum({
        KILL: 0,
        VIDEO: 1,
        COLLECT: 2,
        NO_PAIN: 3,
        NO_FIND: 4,
        GAME_COUNT: 5,
        KILL_CONTINUOUS: 6
      }),
      SceneLayer: cc.Enum({
        FLOOR: "floor",
        PROJECTION: "projection",
        SHADOW: "shadow",
        TAG: "tag",
        ROLE: "role",
        OBJ: "obj",
        FORE: "fore"
      }),
      ObjType: cc.Enum({
        FLOOR: "Floor",
        PROJECTION: "Projection",
        SHADOW: "Shadow",
        TAG: "Tag",
        PLAYER: "Player",
        MONSTER: "Monster",
        OBJ: "Obj",
        BULLET: "Bullet"
      }),
      BlockType: cc.Enum({
        MOVABLE: 0,
        UNMOVABLE: 1,
        BLOCK_ALL: 2
      }),
      BannerType: cc.Enum({
        OVER: 0,
        REVIVE: 1,
        REWARD: 2,
        TEST: 3,
        MAIN: 4
      }),
      GameEndTag: {
        DEFAULT: 0,
        PAIN: 1,
        FIND: 2,
        PAIN_AND_FIND: 3
      },
      RankType: cc.Enum({
        DEFAULT: 0,
        PERSONAL: 1,
        WORLD: 2,
        TODAY: 3,
        GROUP: 4
      }),
      InterAdCategory: cc.Enum({
        DEFAULT: 0,
        OVER: 1,
        LIST: 2,
        MAIN: 3,
        BANNER: 4,
        FLOAT: 5,
        LED: 6,
        GROUP: 7
      })
    };
    module.exports = n;
    cc._RF.pop();
  }, {} ],
  GameHall: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "9653dYH9NVKUZB2XW5sWmS9", "GameHall");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      onLoad: function onLoad() {
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
      },
      start: function start() {
        cc.re.isAutoShow = true;
      },
      playGame: function playGame() {
        cc.re.mutualNode.active = false;
        cc.re.centerNode.active = false;
        cc.director.loadScene("GameScene");
      }
    });
    cc._RF.pop();
  }, {} ],
  GameObject: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2c1c0nHk5xMmYMLg3p+JAb5", "GameObject");
    "use strict";
    cc.Class({
      __ctor__: function __ctor__(e, t, i, n) {
        this.staticData = new InfiniteMap(e, 0, i), this.runtimeData = new InfiniteMap(t, 0, n), 
        this.onStart();
      },
      onStart: function onStart() {},
      release: function release() {
        this.onRelease(), this.staticData = null, this.runtimeData = null;
      },
      onRelease: function onRelease() {},
      getInfo: function getInfo(e) {
        return e ? this.staticData.query(e) : this.staticData.getData();
      },
      setInfo: function setInfo(e, t) {
        return this.staticData.set(e, t);
      },
      addInfo: function addInfo(e, t) {
        return this.staticData.set(e, this.staticData.query(e) + t);
      },
      deleteInfo: function deleteInfo(e, t) {
        t ? delete this.staticData.query(t)[e] : delete this.staticData.data[e];
      },
      deleteAllInfo: function deleteAllInfo() {
        this.staticData = new InfiniteMap();
      },
      getTemp: function getTemp(e) {
        return e ? this.runtimeData.query(e) : this.runtimeData.getData();
      },
      setTemp: function setTemp(e, t) {
        return this.runtimeData.set(e, t);
      },
      addTemp: function addTemp(e, t) {
        return this.runtimeData.set(e, this.runtimeData.query(e) + t);
      },
      deleteTemp: function deleteTemp(e, t) {
        t ? delete this.runtimeData.query(t)[e] : delete this.runtimeData.getData()[e];
      },
      deleteAllTemp: function deleteAllTemp() {
        this.runtimeData = new InfiniteMap();
      },
      overInfo: function overInfo(e) {
        for (var t in e) e.hasOwnProperty(t) && (this.staticData[t] = e[t]);
        return this.staticData.data;
      },
      overTemp: function overTemp(e) {
        for (var t in e) e.hasOwnProperty(t) && (this.runtimeData[t] = e[t]);
        return this.runtimeData.data;
      },
      invokeCallback: function invokeCallback(e) {
        e.apply(null, Array.prototype.slice.call(arguments, 1));
      },
      invoke: function invoke(e, t, i) {
        TimerHandler.add.apply(TimerHandler, [ TimerHandler.Type.GAME, i || TimerHandler.Loop.ONCE, t, e, this ].concat(Array.prototype.slice.call(arguments, 2)));
      },
      repeat: function repeat(e, t) {
        TimerHandler.add.apply(TimerHandler, [ TimerHandler.Type.GAME, TimerHandler.Loop.FOREVER, t, e, this ].concat(Array.prototype.slice.call(arguments, 2)));
      },
      on: function on() {
        MessageHandler.add(arguments);
      },
      off: function off() {
        MessageHandler.remove(arguments);
      },
      broadcast: function broadcast() {
        MessageHandler.dispatch(arguments);
      }
    });
    cc._RF.pop();
  }, {} ],
  GameOverDialog: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "07515Ks/m9BWqzgTotUTruv", "GameOverDialog");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      onLoad: function onLoad() {},
      restart: function restart() {
        Globals.arr = [];
        Globals.clickArr = [];
        cc.director.loadScene("HomeScene");
        cc.re.isAutoShow = true;
        var self = this;
        this.scheduleOnce(function() {
          self.node.removeFromParent();
        }, 2);
      },
      start: function start() {}
    });
    cc._RF.pop();
  }, {} ],
  GameOverUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "016eau7kltKZK/VVwsGN2st", "GameOverUI");
    "use strict";
    var n = require("RewardUI");
    cc.Class({
      extends: n,
      init: function init() {
        this._needNumItr = !1, this._moreLabel = this.node.getChildByName("More").getComponent(cc.Label), 
        this._super();
      },
      setData: function setData(e, t, i) {
        this._super(e, t, i), this._moreLabel.string = (this._rewardValue * this._multiCount).toString();
      },
      onClose: function onClose() {
        kk.GuiSystem.add("SuccessUI"), this._super();
      }
    });
    cc._RF.pop();
  }, {
    RewardUI: "RewardUI"
  } ],
  GameScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6e16aphzlRDrqrvfqR3M9d+", "GameScene");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        targetNode: cc.Node,
        arrowNode: cc.Node,
        arrowPrefab: cc.Prefab,
        touchNode: cc.Node,
        TotalSmallArrowNode: cc.Node,
        levelNum: cc.Label
      },
      onLoad: function onLoad() {
        var self = this;
        self.touchNode.on(cc.Node.EventType.TOUCH_START, function(event) {
          self.emitArrow();
        }, this);
        self.initEvent();
      },
      start: function start() {
        var self = this;
        self.targetRun();
        Globals.currentArrowNum = Globals.DataMgr[Globals.currentLabel].arrowNum;
        var levelNum = Globals.currentLabel + 1;
        self.levelNum.string = "\u7b2c" + levelNum + "\u5173";
        Globals.TouchStatus = true;
        self.reloadUI();
      },
      initEvent: function initEvent() {
        var self = this;
        self.node.on("isSuccess", function() {
          self.isGameSuccess();
        });
        self.node.on("isFail", function() {
          self.isGameOver();
        });
      },
      targetRun: function targetRun() {
        this.targetNode.stopAllActions();
        this.targetNode.angle = 0;
        var seq = cc.sequence(cc.rotateBy(4, 360).easing(cc.easeIn(1.5)), cc.rotateBy(4, -360).easing(cc.easeIn(1.5)));
        this.targetNode.runAction(cc.repeatForever(seq));
      },
      emitArrow: function emitArrow() {
        var self = this;
        if (Globals.currentArrowNum < 1 || false == Globals.TouchStatus) {
          console.log("\u6ca1\u7bad\u4e86");
          return;
        }
        Globals.currentArrowNum--;
        console.log("\u7ee7\u7eed\u5c04\u7bad");
        self.reloadUI();
        var newArrow = cc.instantiate(this.arrowPrefab);
        newArrow.x = this.arrowNode.x;
        newArrow.y = this.arrowNode.y;
        self.node.addChild(newArrow);
        newArrow.runAction(cc.moveTo(.5, 0, this.targetNode.y));
        self.arrowNode.runAction(cc.sequence(cc.hide(), cc.delayTime(.2), cc.show()));
      },
      reloadUI: function reloadUI() {
        var self = this;
        var totalCom = self.TotalSmallArrowNode.getComponent("TotalSmallArrow");
        totalCom.updateArrowNum();
      },
      isGameOver: function isGameOver() {
        var self = this;
        Globals.TouchStatus = false;
        self.scheduleOnce(function() {
          cc.re.isAutoShow = true;
          cc.re.precisionNode.active = true;
          cc.director.loadScene("GameOver");
        }, 1.5);
      },
      isGameSuccess: function isGameSuccess() {
        var self = this;
        if (0 == Globals.currentArrowNum) if (Globals.currentLabel >= Globals.DataMgr.length - 1) {
          Globals.TouchStatus = false;
          self.scheduleOnce(function() {
            cc.re.isAutoShow = true;
            cc.re.precisionNode.active = true;
            cc.director.loadScene("GameOver");
          }, 1.5);
        } else {
          Globals.currentLabel++;
          self.scheduleOnce(function() {
            cc.director.loadScene("GameScene");
          }, 1.5);
        }
      }
    });
    cc._RF.pop();
  }, {} ],
  Game: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "3b2036/g85DWpIVW+MyEvDJ", "Game");
    "use strict";
    function n(e) {
      if (Array.isArray(e)) {
        for (var t = 0, i = Array(e.length); t < e.length; t++) i[t] = e[t];
        return i;
      }
      return Array.from(e);
    }
    var s = {
      _sceneUrl: "db://assets/scenes/",
      _curState: 0,
      getState: function getState() {
        return this._curState;
      },
      switchState: function switchState(e) {
        return this._curState = e, this._curState;
      },
      isLaunched: function isLaunched() {
        return this.getState() !== kk.Enum.GameState.OFFLINE;
      },
      isRunning: function isRunning() {
        return this.getState() > kk.Enum.GameState.BEGIN;
      },
      isActive: function isActive() {
        return this.getState() === kk.Enum.GameState.START;
      },
      init: function init() {
        console.log("GAME", "launching..."), this.handleGameEvents(), kk.AudioSystem.init(), 
        kk.GuiSystem.init();
      },
      handleGameEvents: function handleGameEvents() {
        cc.game.on(cc.game.EVENT_HIDE, this.onGameHide, this), cc.game.on(cc.game.EVENT_SHOW, this.onGameShow, this);
      },
      onGameHide: function onGameHide(e) {
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_HIDE, e);
      },
      onGameShow: function onGameShow(e) {
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_SHOW, e);
      },
      preload: function preload(e) {
        console.log("GAME=", "loading..."), this.switchState(kk.Enum.GameState.LAUNCH), 
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_LAUNCH);
      },
      loaded: function loaded() {
        console.log("GAME=", "loaded"), this.switchState(kk.Enum.GameState.LOADED), MessageHandler.dispatch(kk.Enum.GameEvent.GAME_LOADED), 
        this.begin();
      },
      begin: function begin() {
        console.log("GAME=", "begin"), this.switchState(kk.Enum.GameState.BEGIN), TimerHandler.runMainTimer(), 
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_BEGIN), this.initScene();
      },
      start: function start() {
        console.log("GAME=", "start"), this.switchState(kk.Enum.GameState.START), TimerHandler.runGameTimer(), 
        this.receiveInput(), MessageHandler.dispatch(kk.Enum.GameEvent.GAME_START);
      },
      defeat: function defeat() {
        console.log("GAME=", "defeat"), this.switchState(kk.Enum.GameState.DEFEAT), TimerHandler.stopGameTimer(), 
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_DEFEAT), this.disableInput();
      },
      success: function success() {
        console.log("====success");
        this.switchState(kk.Enum.GameState.SUCCESS), TimerHandler.stopGameTimer(), MessageHandler.dispatch(kk.Enum.GameEvent.GAME_SUCCESS), 
        this.disableInput();
      },
      stop: function stop() {
        console.log("GAME=", "stop"), this.switchState(kk.Enum.GameState.DEFEAT), TimerHandler.stopGameTimer(), 
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_STOP), this.disableInput();
      },
      pause: function pause() {
        console.log("GAME=", "pause"), this.switchState(kk.Enum.GameState.PAUSE), TimerHandler.runMainTimer(), 
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_PAUSE);
      },
      resume: function resume() {
        console.log("GAME=", "resume"), this.switchState(kk.Enum.GameState.START), TimerHandler.runGameTimer(), 
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_RESUME);
      },
      restart: function restart() {
        console.log("====restart");
        setTimeout(function() {
          cc.vv.NativeUtils.showInsertAd();
        }, 500);
        this.switchState(kk.Enum.GameState.READY), TimerHandler.stopGameTimer(), MessageHandler.dispatch(kk.Enum.GameEvent.GAME_RESTART), 
        this.releaseScene(), kk.Game.switchScene("Main", this.begin.bind(this));
      },
      exit: function exit() {
        console.log("====exit");
        console.log("GAME", "exit"), this.switchState(kk.Enum.GameState.READY), TimerHandler.stopGameTimer(), 
        MessageHandler.dispatch(kk.Enum.GameEvent.GAME_EXIT);
      },
      switchScene: function switchScene(e, t) {
        var i = this;
        kk.MoveSystem.clear(), kk.GuiSystem.clear(), kk.GlSystem.clear(), setTimeout(function() {
          kk.GuiSystem.onSceneSwitch(function() {
            i.loadScene(e, t);
          });
        }, 0);
      },
      loadScene: function loadScene(e, t) {
        var i, s, o = this;
        if ((i = cc.director.getScene()).autoReleaseAssets) cc.warn("You can not turn on autoReleaseAssets flag, it will conflict with implement of AssetLib!"); else if (s = [].concat(n(i.dependAssets)), 
        this.isExistScene(e)) cc.director.loadScene(e, function(e, n) {
          o.onSceneLoaded(i, n, s, t);
        }); else {
          var a = new cc.Scene(e);
          cc.director.runSceneImmediate(a, null, function(e, n) {
            o.onSceneLoaded(i, n, s, t);
          });
        }
      },
      onSceneLoaded: function onSceneLoaded(e, t, i, n) {
        kk.AssetLib.onSceneLoaded(i, t.dependAssets), kk.GuiSystem.onSceneLoaded(), n && n();
      },
      isExistScene: function isExistScene(e) {
        for (var t = cc.game._sceneInfos, i = this._sceneUrl.concat(e).concat(".fire"), n = 0; n < t.length; n++) if (t[n].url === i) return !0;
        return !1;
      },
      receiveInput: function receiveInput() {},
      disableInput: function disableInput() {},
      initScene: function initScene() {
        var mmm = kk.MainCamera();
        mmm.backgroundColor = new cc.Color(137, 122, 99, 255);
        kk.levelManager = kk.Canvas().addComponent("LevelManager"), kk.cameraManager = mmm.addComponent("CameraManager");
      },
      releaseScene: function releaseScene() {
        kk.levelManager && (kk.levelManager.release(), kk.levelManager = null), kk.curScene && (kk.curScene.release(), 
        kk.curScene = null), kk.cameraManager && (kk.cameraManager.release(), kk.cameraManager = null);
      }
    };
    module.exports = s;
    cc._RF.pop();
  }, {} ],
  GlSystem: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a2c71GagoFO155VPOGwg4k9", "GlSystem");
    "use strict";
    var n = {
      nodePool: null,
      tracers: {},
      getRootNode: function getRootNode() {
        return this.checkRootNode() || this.initRootNode();
      },
      checkRootNode: function checkRootNode() {
        return kk.Canvas().getChildByName("GSNode");
      },
      initRootNode: function initRootNode() {
        var e = new cc.Node("GSNode");
        return kk.Canvas().addChild(e), e.setPosition(0, 0), e.zIndex = 100, e.setContentSize(cc.winSize.width, cc.winSize.height), 
        e.addComponent(cc.Mask), e;
      },
      getNodePool: function getNodePool() {
        if (!this.nodePool) {
          var e = this.getRootNode(), t = new cc.Node("Tracer");
          e.addChild(t), this.nodePool = new NodePool(t, 1);
        }
        return this.nodePool;
      },
      add: function add(e, t, i, n) {
        var o = this.tracers[e], a = new s(this.getNodePool().add(NodePool.Type.SCALE), t, i, n);
        return o || (this.tracers[e] = []), this.tracers[e].push(a), a;
      },
      remove: function remove(e, t) {
        var i = this.tracers[e];
        if (i && i.length) {
          for (var n = 0; n < i.length; n++) if (i[n] === t) {
            i.splice(n, 1), this.removeTracer(t);
            break;
          }
          i.length || (this.tracers[e] = null);
        }
      },
      removeTracer: function removeTracer(e) {
        this.nodePool && (e.onRecycle(), this.nodePool.put(e.node));
      },
      clearTracers: function clearTracers(e) {
        var t = this.tracers[e];
        if (t) {
          for (var i = t.length - 1; i >= 0; i--) this.removeTracer(t[i]);
          this.tracers[e] = null;
        }
      },
      clear: function clear() {
        this.tracers = {}, this.nodePool && (this.nodePool.release(), this.nodePool = null);
      },
      captureScreenShot: function captureScreenShot(e, t) {
        cc.director.on(cc.Director.EVENT_AFTER_DRAW, function() {
          var i = document.getElementById("GameCanvas").toDataURL("imagea/png");
          cc.director.off(cc.Director.EVENT_AFTER_DRAW), this.base64ToSpriteFrame(i, e, t);
        }.bind(this));
      },
      base64ToSpriteFrame: function base64ToSpriteFrame(e, t, i) {
        var n = new Image();
        n.src = e, n.onload = function() {
          var e = new cc.Texture2D();
          e.initWithElement(n), e.handleLoadedTexture();
          var s = new cc.SpriteFrame(e);
          t && t.apply(i, s);
        };
      },
      cutPicture: function cutPicture(e, t) {
        var i = void 0;
        return e instanceof cc.SpriteFrame ? i = e : e instanceof cc.Texture2D && (i = new cc.SpriteFrame(texture)), 
        i ? (i.setRect(t), i) : null;
      }
    };
    function s(e, t, i, n) {
      var s = e.getOrAddComponent(cc.Graphics);
      return s.lineJoin = cc.Graphics.LineJoin.ROUND, s.lineCap = cc.Graphics.LineCap.ROUND, 
      s.lineWidth = t || 5, s.strokeColor = i || cc.Color.WHITE, s.fillColor = n || cc.Color.WHITE, 
      s.onRelease = function() {
        this.clear(), this.onRelease = null, this.onRecycle = null, s = null;
      }, s.onRecycle = function() {
        this.clear();
      }, e = null, i = null, n = null, t = null, s;
    }
    module.exports = n;
    cc._RF.pop();
  }, {} ],
  GuiSystem: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f32f98Slf5HprZFVQzbjlGs", "GuiSystem");
    "use strict";
    var n = {
      uiList: [],
      tipsList: [],
      tipsTimer: null,
      tipsPool: null,
      init: function init() {
        return this.handleGameEvents(), this.fitCanvas(), this;
      },
      handleGameEvents: function handleGameEvents() {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onClickBack, this);
      },
      unHandleGameEvents: function unHandleGameEvents() {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onClickBack, this);
      },
      fitCanvas: function fitCanvas() {
        var e = cc.director.getScene(), t = e.getComponentInChildren(cc.Canvas);
        t || ((t = new cc.Node("Canvas").addComponent(cc.Canvas)).node.parent = e, t.node.setPosition(kk.resolution.width / 2, kk.resolution.height / 2)), 
        t.designResolution = new cc.Size(kk.resolution.width, kk.resolution.height);
        var i = kk.isSprs();
        t.fitHeight = !i, t.fitWidth = i;
      },
      addCamera: function addCamera() {},
      getMaskNode: function getMaskNode() {
        var e = cc.find("Canvas/GAME_SCENE_MASK"), t = void 0;
        return e || ((e = new cc.Node("GAME_SCENE_MASK")).color = cc.Color.BLACK, (t = e.addComponent(cc.Sprite)).type = cc.Sprite.Type.SIMPLE, 
        t.sizeMode = cc.Sprite.SizeMode.CUSTOM, kk.AssetLib.setSprite(e, "empty"), kk.Canvas().addChild(e), 
        e.zIndex = kk.Enum.LayerDepth.TOP, e.setContentSize(5e3, 5e3), e.setPosition(0, 0)), 
        e;
      },
      onSceneSwitch: function onSceneSwitch(e) {
        this.maskFadeIn(e);
      },
      onSceneLoaded: function onSceneLoaded() {
        this.fitCanvas(), this.maskFadeOut();
      },
      maskFadeIn: function maskFadeIn(e) {
        var t = this.getMaskNode();
        t.opacity = 0, t.stopAllActions(), t.runAction(cc.sequence(cc.fadeIn(.1), cc.delayTime(.1), cc.callFunc(e)));
      },
      maskFadeOut: function maskFadeOut() {
        var e = this.getMaskNode();
        e.opacity = 255, e.stopAllActions(), e.runAction(cc.fadeOut(.1));
      },
      getGuiNode: function getGuiNode() {
        return this.checkGuiNode() || this.initGuiNode();
      },
      checkGuiNode: function checkGuiNode() {
        return cc.find("Canvas/GUI");
      },
      initGuiNode: function initGuiNode() {
        var e = new cc.Node("GUI");
        return kk.Canvas().addChild(e), e.setPosition(0, 0), e.zIndex = kk.Enum.LayerDepth.GUI, 
        e.setContentSize(cc.winSize), e;
      },
      onClickBack: function onClickBack(e) {
        return kk.isNativeAndroid() && e.keyCode === cc.macro.KEY.back ? this.remove() : kk.isWindows() && e.keyCode === cc.macro.KEY.space && this.remove(), 
        this;
      },
      findUIByName: function findUIByName(e) {
        var t = this.getGuiNode().getChildByName(e);
        return t ? t.getComponent(kk.Gui) : null;
      },
      findLastUI: function findLastUI() {
        var e = this.getUIList();
        if (!e.length) return null;
        for (var t = e.length - 1, i = e[t]; 0 === i.length; ) {
          if (--t <= 0) return null;
          i = e[t];
        }
        return this.findUIByName(i[i.length - 1]);
      },
      convertToGuiPosition: function convertToGuiPosition(e) {
        for (var t = e.getPosition(), i = e.parent; i !== this.getGuiNode(); ) t.x += i.getPosition().x, 
        t.y += i.getPosition().y, i = i.parent;
        return t;
      },
      add: function add(e, t, i) {
        var n = kk.AssetLib.retainAsset("gui/".concat(e), cc.Prefab);
        if (n) {
          var s = this.findUIByName(e);
          if (s) s.node.active = !0, s.onActive(); else {
            if (!(s = cc.instantiate(n).getComponent(kk.Gui))) throw new Error(e + "\u811a\u672c\u672a\u6dfb\u52a0\uff0c\u8bf7\u67e5\u770b\u9884\u5236\u4f53");
            this.getGuiNode().addChild(s.node), s.node.setPosition(cc.Vec2.ZERO), s.init(), 
            s.resize(), s.onActive();
          }
          return this.pushUI(s), s.enter(), t && t.apply(i, [ s ]), s;
        }
        this.loadUINow(e, t, i);
      },
      remove: function remove(e) {
        var t = void 0;
        return e ? (t = this.findUIByName(e)) ? (this.spliceUI(t), t.exit(), this.findLastUI()) : 0 : (t = this.findLastUI()) && t.onBack ? (t.close(), 
        1) : 0;
      },
      release: function release(e) {
        var t = this.findUIByName(e);
        if (!t) return 0;
        t.onClose();
      },
      hookClose: function hookClose(e, t, i) {
        var n = e.onClose;
        e.onClose = function() {
          n.call(e), t.call(i);
        };
      },
      loadUINow: function loadUINow(e, t, i) {
        var n = this;
        kk.AssetLib.loadAsset("gui/".concat(e), cc.Prefab, function() {
          n.add(e, t, i);
        }, function() {
          console.warn(e + "\u8d44\u6e90\u52a0\u8f7d\u5931\u8d25\uff0c\u8bf7\u68c0\u67e5\u8d44\u6e90\u8def\u5f84");
        }, this);
      },
      getUICount: function getUICount() {
        for (var e = [], t = this.uiList.length - 1; t >= 0; ) e = e.concat(this.uiList[t]), 
        t--;
        return e.length;
      },
      getUIList: function getUIList() {
        return this.uiList;
      },
      pushUI: function pushUI(e) {
        for (var t = e.node.name, i = e.sortOrder; i >= this.uiList.length; ) this.uiList.push([]);
        var n = this.uiList[i], s = n.indexOf(t);
        return s < 0 && (n.push(t), s = n.length - 1), e.sort(s), this;
      },
      spliceUI: function spliceUI(e) {
        var t = e.node.name, i = this.uiList[e.sortOrder];
        if (!i) return this;
        var n = i.indexOf(t);
        return n < 0 ? this : (i.splice(n, 1), this);
      },
      clearUI: function clearUI() {
        for (var e = void 0, t = this.uiList.length - 1; t >= 0; t--) if ((e = this.uiList[t]) instanceof Array && 0 !== e.length) for (var i = e.length - 1; i >= 0; i--) this.release(e[i]);
        this.uiList = [];
      },
      clear: function clear() {
        return this.clearUI(), this.clearTips(), this;
      },
      getTipNode: function getTipNode() {
        return this.checkTipNode() || this.initTips();
      },
      checkTipNode: function checkTipNode() {
        return cc.find("Canvas/TIP");
      },
      initTips: function initTips() {
        var e, t, i = void 0;
        return i = new cc.Node("TIP"), kk.Canvas().addChild(i), i.setPosition(0, 0), i.zIndex = kk.Enum.LayerDepth.TIPS, 
        t = (e = kk.AssetLib.retainAsset("gui/BubbleTips", cc.Prefab)) ? cc.instantiate(e) : this.createDefaultTipsModel(), 
        i.addChild(t), this.tipsPool = new NodePool(t, 1), i;
      },
      createDefaultTipsModel: function createDefaultTipsModel() {
        var e = new cc.Node("BubbleTips"), t = new cc.Node("Label"), i = new cc.Node("Sprite"), n = t.addComponent(cc.Label);
        e.position = cc.v2(-100, -100);
        return i.addComponent(cc.Sprite).sizeMode = cc.Sprite.SizeMode.CUSTOM, i.group = t.group = "gui", 
        i.color = cc.Color.BLACK, i.opacity = 128, i.setContentSize(cc.winSize.width, 50), 
        kk.AssetLib.setSprite(i, "empty"), e.group = t.group = "gui", t.color = cc.Color.WHITE, 
        n.horizontalAlign = 0, n.verticalAlign = 1, n.fontSize = 22, n.lineHeight = 36, 
        n.overflow = 1, t.setContentSize(.5 * cc.winSize.width, 36), e.addChild(i), e.addChild(t), 
        e;
      },
      addTips: function addTips(e) {
        return this.getTipNode(), this.tipsList.length >= 5 && this.tipsList.shift(), this.tipsList.push(e), 
        this.tipsTimer || this.sortTips(), 0;
      },
      sortTips: function sortTips() {
        if (!this.tipsList.length) return window.clearTimeout(this.tipsTimer), void (this.tipsTimer = null);
        var e = this.tipsPool.add(NodePool.Type.SCALE), t = this.tipsList.shift();
        e.opacity = 255, e.setPosition(cc.v2(0, -100)), e.getComponentInChildren(cc.Label).string = t, 
        e.stopAllActions(), e.runAction(cc.sequence(cc.moveTo(1, e.position.add(cc.Vec2.UP.mul(300))), cc.fadeOut(.1))), 
        this.tipsTimer = setTimeout(function() {
          this.sortTips();
        }.bind(this), 1500);
      },
      clearTips: function clearTips() {
        this.tipsList = [], this.tipsPool && this.tipsPool.clear(), window.clearTimeout(this.tipsTimer), 
        this.tipsTimer = null;
      }
    };
    module.exports = n;
    cc._RF.pop();
  }, {} ],
  Gui: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "eb405Bz3VRPR6LaEsH6jYC9", "Gui");
    "use strict";
    var n = cc.Enum({
      GUI: 0,
      TIPS: 1,
      MASK: 2
    }), s = cc.Enum({
      DEFAULT: 0,
      HIDE: 1,
      NEVER: 2
    }), o = cc.Enum({
      NONE: 0,
      SCALE: 1,
      ROTATE: 2,
      SCALE_ROTATE: 3,
      FADE: 4,
      MOVE_UP: 5,
      MOVE_DOWN: 6
    });
    cc.Class({
      extends: cc.Component,
      properties: {
        guiType: {
          default: n.GUI,
          type: n,
          displayName: "GUI\u7c7b\u578b"
        },
        sortOrder: {
          default: 0,
          displayName: "\u754c\u9762\u5c42\u7ea7",
          visible: function visible() {
            return this.guiType === n.GUI;
          }
        },
        onBack: {
          default: !0,
          displayName: "\u54cd\u5e94\u5b89\u5353\u8fd4\u56de\u952e"
        },
        closeType: {
          default: s.DEFAULT,
          type: s,
          displayName: "\u9500\u6bc1\u65b9\u5f0f",
          tooltip: "0.DEFAULT\u9ed8\u8ba4\uff0c\u76f4\u63a5\u9500\u6bc1\uff1b1.HIDE\u9690\u85cf\u800c\u4e0d\u9500\u6bc1\uff1b2.NEVER\u6c38\u4e0d\u9500\u6bc1\uff0c\u4e00\u822c\u4f5c\u4e3a\u4e3b\u754c\u9762"
        },
        enterType: {
          default: o.NONE,
          type: o,
          displayName: "\u542f\u52a8\u52a8\u753b\u6837\u5f0f",
          tooltip: "NONE\u65e0\u52a8\u753b;SCALE\u7f29\u653e;ROTATE\u65cb\u8f6c;SANDR\u7f29\u653e\u5e76\u65cb\u8f6c"
        },
        exitType: {
          default: o.NONE,
          type: o,
          displayName: "\u5173\u95ed\u52a8\u753b\u6837\u5f0f",
          tooltip: "NONE\u65e0\u52a8\u753b;SCALE\u7f29\u653e;ROTATE\u65cb\u8f6c;SANDR\u7f29\u653e\u5e76\u65cb\u8f6c"
        },
        defaultScale: {
          default: 1,
          type: cc.Float,
          displayName: "\u521d\u59cb\u7f29\u653e\u53c2\u6570",
          tooltip: "SCALE\u52a8\u753b\u521d\u59cb\u7684scale\u503c",
          visible: function visible() {
            return this.enterType === o.SCALE;
          }
        },
        rotateCount: {
          default: 1,
          type: cc.Integer,
          displayName: "\u521d\u59cb\u65cb\u8f6c\u53c2\u6570",
          tooltip: "ROTATE\u52a8\u753b\u65cb\u8f6c\u7684\u6b21\u6570",
          visible: function visible() {
            return this.enterType === o.ROTATE;
          }
        },
        launchDuration: {
          default: .2,
          type: cc.Float,
          displayName: "\u8fdb\u573a\u65f6\u957f",
          visible: function visible() {
            return this.enterType !== o.NONE;
          }
        },
        exitDuration: {
          default: .2,
          type: cc.Float,
          displayName: "\u9000\u573a\u65f6\u957f",
          visible: function visible() {
            return this.exitType !== o.NONE;
          }
        }
      },
      init: function init() {},
      onActive: function onActive() {},
      sort: function sort(e) {
        switch (this.guiType) {
         case n.MASK:
          this.node.zIndex = kk.Enum.LayerDepth.MASK + 2 * e;
          break;

         default:
          this.node.zIndex = 2 * e + this.sortOrder * kk.Enum.LayerDepth.GUI;
        }
        return this;
      },
      enter: function enter() {
        var e = void 0, t = void 0;
        switch (this.enterType) {
         case o.SCALE:
          this.node.scaleX = this.defaultScale, this.node.scaleY = this.defaultScale, e = cc.sequence(cc.scaleTo(2 * this.launchDuration / 3, 1.1, 1.1), cc.scaleTo(this.launchDuration / 3, 1, 1));
          break;

         case o.ROTATE:
          this.node.angle = 0, e = cc.rotateBy(this.launchDuration, 360 * this.rotateCount), 
          t = cc.callFunc(function() {
            this.node.angle = 0;
          }, this), e = cc.sequence(e, t);
          break;

         case o.SCALE_ROTATE:
          this.node.scaleX = this.defaultScale, this.node.scaleY = this.defaultScale, this.node.angle = 0, 
          e = cc.rotateBy(this.launchDuration, 360 * this.rotateCount), e = cc.spawn(cc.scaleTo(this.launchDuration, 1, 1), e), 
          t = cc.callFunc(function() {
            this.node.angle = 0;
          }, this), e = cc.sequence(e, t);
          break;

         case o.FADE:
          this.node.opacity = 0, e = cc.fadeIn(this.launchDuration);
          break;

         case o.MOVE_UP:
          this.node.setPosition(0, -cc.winSize.height), e = cc.moveTo(this.launchDuration, cc.Vec2.ZERO);
          break;

         case o.MOVE_DOWN:
          this.node.setPosition(0, cc.winSize.height), e = cc.moveTo(this.launchDuration, cc.Vec2.ZERO);
          break;

         default:
          this.node.angle = 0, this.node.opacity = 255, this.node.setScale(1, 1);
        }
        e && this.node.runAction(e), this.updateData();
      },
      resize: function resize() {
        this.node.setContentSize(cc.winSize), this.resizeViews();
      },
      resizeViews: function resizeViews() {},
      exit: function exit() {
        var e = void 0, t = cc.callFunc(function() {
          this.onClose();
        }, this);
        switch (this.node.stopAllActions(), this.exitType) {
         case o.SCALE:
          this.node.scaleX = this.defaultScale, this.node.scaleY = this.defaultScale, e = cc.scaleTo(this.exitDuration, 0, 0), 
          e = cc.sequence(e, t), this.node.runAction(e);
          break;

         case o.ROTATE:
          this.node.angle = 0, e = cc.rotateBy(this.exitDuration, 360 * this.rotateCount), 
          t = cc.callFunc(function() {
            this.node.angle = 0, this.onClose();
          }, this), e = cc.sequence(e, t), this.node.runAction(e);
          break;

         case o.SCALE_ROTATE:
          this.node.scaleX = this.defaultScale, this.node.scaleY = this.defaultScale, this.node.angle = 0, 
          e = cc.rotateBy(this.exitDuration, 360 * this.rotateCount), e = cc.spawn(cc.scaleTo(this.exitDuration, 0, 0), e), 
          t = cc.callFunc(function() {
            this.node.angle = 0, this.onClose();
          }, this), e = cc.sequence(e, t), this.node.runAction(e);
          break;

         case o.FADE:
          e = cc.fadeOut(this.exitDuration), e = cc.sequence(e, t), this.node.runAction(e);
          break;

         case o.MOVE_UP:
          e = cc.moveTo(this.exitDuration, new cc.Vec2(0, cc.winSize.height)), e = cc.sequence(e, t), 
          this.node.runAction(e);
          break;

         case o.MOVE_DOWN:
          e = cc.moveTo(this.exitDuration, new cc.Vec2(0, -cc.winSize.height)), e = cc.sequence(e, t), 
          this.node.runAction(e);
          break;

         default:
          this.node.angle = 0, this.node.opacity = 255, this.node.scaleX = 1, this.node.scaleY = 1, 
          this.onClose();
        }
      },
      updateData: function updateData() {},
      onClose: function onClose() {
        switch (this.closeType) {
         case s.HIDE:
          this.node.active = !1;
          break;

         case s.NEVER:
          break;

         default:
          var e = this.node.name;
          this.node.destroy(), kk.AssetLib.releaseAsset("gui/".concat(e), cc.Prefab);
        }
      },
      open: function open(e, t) {
        kk.GuiSystem.add(t), kk.AudioSystem.play(kk.AudioName.GUI, "click");
      },
      close: function close() {
        kk.GuiSystem.remove(this.node.name), kk.AudioSystem.play(kk.AudioName.GUI, "click");
      },
      openUrl: function openUrl(e, t) {
        cc.sys.isNative ? cc.sys.openURL(t) : window.location.href = t;
      },
      playAudio: function playAudio(e, t) {
        (t = JSON.parse(t)).audioName && t.clipName && kk.AudioSystem.play(t.audioName, t.clipName);
      },
      registerTouchEvents: function registerTouchEvents() {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this, !0), this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this, !0), 
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this, !0), this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this, !0);
      },
      unRegisterTouchEvents: function unRegisterTouchEvents() {
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this), this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this), 
        this.node.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this), this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
      },
      onTouchStart: function onTouchStart() {},
      onTouchMove: function onTouchMove() {},
      onTouchEnd: function onTouchEnd() {},
      onTouchCancel: function onTouchCancel() {},
      onMouseWheel: function onMouseWheel() {}
    });
    cc._RF.pop();
  }, {} ],
  HomeScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "bab0cvNOs9Oq7UkpvZGKFTM", "HomeScene");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      playerButton: function playerButton() {
        cc.director.loadScene("MainScene");
        cc.re.centerNode.active = false;
      },
      onLoad: function onLoad() {
        cc.vv.uiUtils.autoFit(this.node);
      },
      start: function start() {}
    });
    cc._RF.pop();
  }, {} ],
  IAttack: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "94d67Y61aVCUIu2wTxcSw4S", "IAttack");
    "use strict";
    var n = require("IState");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IAttack",
          override: !0
        }
      },
      onStateEnter: function onStateEnter() {
        this._super(), this.startAttack();
      }
    });
    cc._RF.pop();
  }, {
    IState: "IState"
  } ],
  IDead: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "889e9nVdqVHc6EMtkms3Vwr", "IDead");
    "use strict";
    var n = require("IState");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IDead",
          override: !0
        }
      },
      onStateEnter: function onStateEnter() {
        this.die();
      }
    });
    cc._RF.pop();
  }, {
    IState: "IState"
  } ],
  IDodge: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e0776G7DadNTL5XWGdaQ52U", "IDodge");
    "use strict";
    var n = require("IState");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IDodge",
          override: !0
        }
      }
    });
    cc._RF.pop();
  }, {
    IState: "IState"
  } ],
  IGuard: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "148cdIimhhPRYvVfi9JIt21", "IGuard");
    "use strict";
    var n = require("IState");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IGuard",
          override: !0
        }
      },
      onStateEnter: function onStateEnter() {
        this._super();
        var e = kk.curScene.posToGrid(this.node.position), t = this.getDirByAngle(this.getFaceAngle());
        kk.curScene.getNextGridOnDir(t, e[0], e[1], kk.Config.filterNum) || this.turnDirSync(e, !0), 
        this._stampAngle = .1, this._index = 0, this._maxIndex = Math.randomRange(300, 500), 
        this._tempAngle = this._angle, cc.director.on(cc.Director.EVENT_AFTER_UPDATE, this.onStateStay, this), 
        TimerHandler.add(TimerHandler.Type.GAME, TimerHandler.Loop.ONCE, Math.randomRange(3, 8), this.switchState, this, kk.Enum.RoleState.IWalk);
      },
      onStateStay: function onStateStay() {
        this._index >= this._maxIndex && (this._stampAngle = -this._stampAngle, this._index = 0), 
        this.switchAngle(this._angle + this._stampAngle), this._index++;
      },
      onStateExit: function onStateExit() {
        TimerHandler.remove(TimerHandler.Type.GAME, this.switchState, this), cc.director.off(cc.Director.EVENT_AFTER_UPDATE, this.onStateStay, this), 
        this.switchAngle(this._tempAngle), this._super();
      }
    });
    cc._RF.pop();
  }, {
    IState: "IState"
  } ],
  IHurt: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e378dSMos9P15t8raiweoq5", "IHurt");
    "use strict";
    var n = require("IState");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IHurt",
          override: !0
        }
      },
      onStateEnter: function onStateEnter() {
        this._super(), this.hurt();
      }
    });
    cc._RF.pop();
  }, {
    IState: "IState"
  } ],
  IIdle: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5f57eehjMdB4r//YuiNFssV", "IIdle");
    "use strict";
    var n = require("IState");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IIdle",
          override: !0
        }
      }
    });
    cc._RF.pop();
  }, {
    IState: "IState"
  } ],
  IMove: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "04a328thwhPHYVO/EaEZF3L", "IMove");
    "use strict";
    var n = require("IState");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IMove",
          override: !0
        }
      }
    });
    cc._RF.pop();
  }, {
    IState: "IState"
  } ],
  IRun: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "b1e0f48tLZAzar8EipQgmmc", "IRun");
    "use strict";
    var n = require("IMove");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IRun",
          override: !0
        }
      },
      onStateEnter: function onStateEnter() {
        this._super(), kk.MoveSystem.add(this);
      },
      onStartMove: function onStartMove() {
        this._path.length ? this.isPlayer() ? this.speed = kk.Config.playerRunSpeed : this.speed = kk.Config.monsterRunSpeed : this.switchState(kk.Enum.RoleState.IIdle);
      },
      onMoving: function onMoving() {
        if (this._path.length) {
          var e = [].concat(this._path), t = new cc.Vec2(e[0].x, e[0].y), i = this.getSpeed(), n = Utils.Angle.between(this.node.position, t);
          this.pathUpdateSetting(e), Utils.distance(this.node.position, t) <= i ? (this.node.setPosition(t), 
          this._path.shift()) : (this.switchAngle(n), this.node.translate(this._moveDir.normalize().mul(i)));
        } else this.pathEndSetting();
      },
      onStopMove: function onStopMove() {},
      onStateExit: function onStateExit() {
        kk.MoveSystem.remove(this), this.isPlayer() && (this._pathTracer.clear(), this.hideArrow()), 
        this._super();
      }
    });
    cc._RF.pop();
  }, {
    IMove: "IMove"
  } ],
  IState: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a6a72YHPy5FrZNsRlFO/w6/", "IState");
    "use strict";
    var _typeof = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(obj) {
      return typeof obj;
    } : function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    var n = "function" == typeof Symbol && "symbol" == _typeof(Symbol.iterator) ? function(e) {
      return "undefined" === typeof e ? "undefined" : _typeof(e);
    } : function(e) {
      return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : "undefined" === typeof e ? "undefined" : _typeof(e);
    }, s = cc.Class({
      properties: {
        name: "IState"
      },
      __ctor__: function __ctor__(e) {
        s.hook(e, this), e = null;
      },
      onStateEnter: function onStateEnter() {
        this.playAnim(this._iState.name);
      },
      onStateStay: function onStateStay() {},
      onStateExit: function onStateExit() {
        s.release(this);
      },
      onStartMove: function onStartMove() {},
      onMoving: function onMoving() {},
      onStopMove: function onStopMove() {}
    });
    s.hook = function(e, t) {
      s.hookTrigger(e, "onStateEnter", t), s.hookTrigger(e, "onStateStay", t), s.hookTrigger(e, "onStateExit", t), 
      s.hookTrigger(e, "onStartMove", t), s.hookTrigger(e, "onMoving", t), s.hookTrigger(e, "onStopMove", t);
    }, s.release = function(e) {
      s.hookTrigger(e, "onStateEnter"), s.hookTrigger(e, "onStateStay"), s.hookTrigger(e, "onStateExit"), 
      s.hookTrigger(e, "onStartMove"), s.hookTrigger(e, "onMoving"), s.hookTrigger(e, "onStopMove");
    }, s.hookTrigger = function(e, t, i) {
      "object" === (void 0 === e ? "undefined" : n(e)) && "string" == typeof t ? e[t] = i ? i[t] : function() {} : console.warn("IState Hook: input data error." + e + " " + t);
    };
    cc._RF.pop();
  }, {} ],
  IWalk: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "df39f2AEzFId4DY3wtsWXVe", "IWalk");
    "use strict";
    var n = require("IMove");
    cc.Class({
      extends: n,
      properties: {
        name: {
          default: "IWalk",
          override: !0
        }
      },
      onStateEnter: function onStateEnter() {
        this._super(), kk.MoveSystem.add(this), TimerHandler.add(TimerHandler.Type.GAME, TimerHandler.Loop.ONCE, Math.randomRange(3, 8), this.switchState, this, kk.Enum.RoleState.IGuard);
      },
      onStartMove: function onStartMove() {
        this.isPlayer() ? (this.speed = kk.Config.playerWalkSpeed, kk.cameraManager.startFollow(this._path[this._path.length - 1])) : this.speed = kk.Config.monsterWalkSpeed, 
        this._moveDir = Utils.Angle.toVector(this._angle), this._path = [];
      },
      onMoving: function onMoving() {
        if (!this._path.length) {
          var e = kk.curScene.posToGrid(this.node.position), t = this.getDirByAngle(this.getFaceAngle()), i = kk.curScene.getNextGridOnDir(t, e[0], e[1], kk.Config.filterNum);
          if (!i) {
            var n = this.turnDirSync(e), s = Utils.Direction.dirToDeltaVector(n);
            i = [ e[0] + s[0], e[1] + s[1] ];
          }
          this._path.push(kk.curScene.gridToPos(i[0], i[1]));
        }
        var o = this._path[0], a = this.getSpeed();
        Utils.distance(this.node.position, o) <= a ? (this.node.setPosition(o), this._path.shift()) : (this._moveDir = o.sub(this.node.position), 
        this.node.translate(this._moveDir.normalize().mul(a)));
      },
      onStopMove: function onStopMove() {},
      onStateExit: function onStateExit() {
        TimerHandler.remove(TimerHandler.Type.GAME, this.switchState, this), kk.MoveSystem.remove(this), 
        this._super();
      }
    });
    cc._RF.pop();
  }, {
    IMove: "IMove"
  } ],
  Item: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "59b53NAse9OvaxQmY9gcJW6", "Item");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        nodeSprite: cc.Sprite,
        labName: cc.Label,
        playerNum: cc.Label,
        HotIconSprite: cc.Sprite,
        HotImgs: [ cc.SpriteFrame ],
        isShakeDefalt: true,
        _data: null,
        _timer: .4,
        _shakeTimer: 2.4,
        _picWidth: 100,
        _isShake: false,
        _upTimer: .4,
        _updateDataTime: 7.2,
        _timeID: null
      },
      onDestroy: function onDestroy() {
        clearTimeout(this._timeID);
      },
      start: function start() {
        var self = this;
        this._timeID = setTimeout(function() {
          self.setRandomData();
        }, 1e3);
        this._picWidth = this.nodeSprite.node.width - 4;
      },
      setRandomData: function setRandomData() {
        if (void 0 !== cc.vv && void 0 !== cc.vv.drawerAd) {
          var random = Math.floor(Math.random() * cc.vv.drawerAd.length);
          false == this.isShakeDefalt ? this.setData(cc.vv.drawerAd[random], false) : this.setData(cc.vv.drawerAd[random], true);
          this.node.active = true;
        }
      },
      setData: function setData(datas, isShake, isHot) {
        this._timer = 0;
        this._shakeTimer = 2.4;
        this._data = datas;
        void 0 !== isShake && (this._isShake = isShake);
        true == isHot && this.setHotIcon();
        if (void 0 == this.labName || "" == this.labName) return;
        this.labName.string = this._data.title;
        var imgKey = this._data.wxAppId + this._data.id;
        void 0 == cc.vv.AssestManager && (cc.vv.AssestManager = {});
        if (cc.vv.AssestManager[imgKey]) {
          this.nodeSprite.spriteFrame = cc.vv.AssestManager[imgKey];
          this.nodeSprite.node.width = this.nodeSprite.node.height = this._picWidth;
        } else this.displayIconServer(this._data);
      },
      setHotIcon: function setHotIcon() {
        var randomIcon = this.HotImgs[Math.floor(Math.random() * this.HotImgs.length)];
        this.HotIconSprite && (this.HotIconSprite.spriteFrame = randomIcon);
      },
      displayIconServer: function displayIconServer(info) {
        var self = this;
        cc.loader.load(this._data.pic, function(err, texture) {
          if (err || !self || !self.nodeSprite) return;
          if (void 0 == self.nodeSprite || "" == self.nodeSprite) return;
          self.nodeSprite.spriteFrame = new cc.SpriteFrame(texture);
          self.nodeSprite.node.width = self.nodeSprite.node.height = self._picWidth;
          var objKey = "" + self._data.wxAppId + self._data.id;
          cc.vv.AssestManager[objKey] = new cc.SpriteFrame(texture);
        });
      },
      switchGame: function switchGame() {},
      setAni: function setAni() {
        var action0 = cc.rotateTo(.1, 10);
        var action1 = cc.rotateTo(.2, -10);
        var action2 = cc.rotateTo(.1, 0);
        this.node.runAction(cc.sequence(action0, action1, action2, action0, action1, action2));
      },
      update: function update(dt) {
        this._upTimer += dt;
        if (this._upTimer > this._updateDataTime) {
          this._upTimer = 0;
          this.setRandomData();
        }
        if (false == this._isShake) return;
        this._timer += dt;
        if (this._timer > this._shakeTimer) {
          this._timer = 0;
          this.setAni();
        }
      }
    });
    cc._RF.pop();
  }, {} ],
  JSExtensions: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "cf7a6E+XxFB85piIi4D0cdF", "JSExtensions");
    "use strict";
    Math.randomRange = function(e, t) {
      return e + Math.floor(Math.random() * (t - e));
    }, Math.randomInt = function(e) {
      return Math.floor(Math.random() * e);
    }, Math.randomPlusMinus = function() {
      return Math.random() > .5 ? 1 : -1;
    }, Number.prototype.normalize = function() {
      return this.valueOf() > 0 ? 1 : this.valueOf() < 0 ? -1 : 0;
    }, Number.prototype.clamp = function(e, t) {
      return this.valueOf() >= t ? t : this.valueOf() < e ? e : this.valueOf();
    }, Array.prototype.contains = function(e) {
      return this.indexOf(e) >= 0;
    }, Array.prototype.remove = function(e) {
      var t = this.indexOf(e);
      return !(t < 0) && this.splice(t, 1);
    }, Array.prototype.replace = function(e, t) {
      this.indexOf(e) < 0 || this.splice(this.indexOf(e), 1, t);
    }, Array.prototype.clear = function() {
      return [];
    }, Array.prototype.sum = function(e) {
      var t = 0;
      return this.forEach(function(i, n) {
        return "number" != typeof i ? 0 : void 0 !== e && e < n ? t : void (t += i);
      }), t;
    }, Array.prototype.random = function() {
      return this[Math.floor(Math.random() * this.length)];
    }, String.prototype.contains = function(e) {
      return this.indexOf(e) >= 0;
    }, String.format = function() {
      if (0 === arguments.length) return "";
      for (var e = arguments[0], t = 1; t < arguments.length; t++) {
        var i = new RegExp("\\{" + (t - 1) + "\\}", "gm");
        e = e.replace(i, arguments[t]);
      }
      return e;
    };
    cc._RF.pop();
  }, {} ],
  LanguageData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "61de062n4dJ7ZM9/Xdumozn", "LanguageData");
    "use strict";
    var Polyglot = require("polyglot.min");
    var polyInst = null;
    window.i18n || (window.i18n = {
      languages: {},
      curLang: ""
    });
    false;
    function loadLanguageData(language) {
      return window.i18n.languages[language];
    }
    function initPolyglot(data) {
      data && (polyInst ? polyInst.replace(data) : polyInst = new Polyglot({
        phrases: data,
        allowMissing: true
      }));
    }
    module.exports = {
      init: function init(language) {
        if (language === window.i18n.curLang) return;
        var data = loadLanguageData(language) || {};
        window.i18n.curLang = language;
        initPolyglot(data);
        this.inst = polyInst;
      },
      t: function t(key, opt) {
        if (polyInst) return polyInst.t(key, opt);
      },
      inst: polyInst,
      updateSceneRenderers: function updateSceneRenderers() {
        var rootNodes = cc.director.getScene().children;
        var allLocalizedLabels = [];
        for (var i = 0; i < rootNodes.length; ++i) {
          var labels = rootNodes[i].getComponentsInChildren("LocalizedLabel");
          Array.prototype.push.apply(allLocalizedLabels, labels);
        }
        for (var _i = 0; _i < allLocalizedLabels.length; ++_i) {
          var label = allLocalizedLabels[_i];
          if (!label.node.active) continue;
          label.updateLabel();
        }
        var allLocalizedSprites = [];
        for (var _i2 = 0; _i2 < rootNodes.length; ++_i2) {
          var sprites = rootNodes[_i2].getComponentsInChildren("LocalizedSprite");
          Array.prototype.push.apply(allLocalizedSprites, sprites);
        }
        for (var _i3 = 0; _i3 < allLocalizedSprites.length; ++_i3) {
          var sprite = allLocalizedSprites[_i3];
          if (!sprite.node.active) continue;
          sprite.updateSprite(window.i18n.curLang);
        }
      }
    };
    cc._RF.pop();
  }, {
    "polyglot.min": "polyglot.min"
  } ],
  LevelManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "702e33v9hNBdq/BSPovyJMZ", "LevelManager");
    "use strict";
    var n = require("Scene");
    cc.Class({
      extends: cc.Component,
      properties: {
        _isInitOver: !1,
        _isActive: !1,
        _isDisableAnim: !1,
        _tileData: null,
        _levelData: null,
        _blockData: null,
        _skinData: null,
        _killMonsterCount: 0,
        _gameEndTag: 0,
        _totalGold: 0,
        _totalRevive: 0,
        _gems: [],
        _gemLabelNode: null,
        _gemEffectPool: null,
        _gemLabelPool: null,
        _level: 1,
        _mapId: 1
      },
      onLoad: function onLoad() {
        this._killMonsterCount = 0, this._level = kk.curUser.getCurLevel(), this._mapId = Math.randomRange(1, kk.Config.limitMapId + 1);
      },
      start: function start() {
        this.readSkinConfig();
      },
      update: function update(e) {
        this._isInitOver && (this._isActive && this.drawSceneFog(), this._isDisableAnim || (this.updateGemsPos(), 
        this.updateGemLabelNode()), kk.Game.isActive() && (this.checkGameWin(), this.checkAttackContact()));
      },
      switchState: function switchState(e, t) {
        if (this._isInitOver) {
          switch (e) {
           case kk.Enum.GameState.START:
            this.registerEvent(), kk.Game.start(), this.onGameStart();
            break;

           case kk.Enum.GameState.PAUSE:
            this.unRegisterEvent(), kk.Game.pause(), this.onGamePause();
            break;

           case kk.Enum.GameState.RESUME:
            this.registerEvent(), kk.Game.resume(), this.onGameResume();
            break;

           case kk.Enum.GameState.DEFEAT:
            this.unRegisterEvent(), kk.Game.defeat(), this.onGameDefeat();
            break;

           case kk.Enum.GameState.SUCCESS:
            this.unRegisterEvent(), kk.Game.success(), this.onGameSuccess();
          }
          t && t(!0);
        } else t && t(!1);
      },
      onGameStart: function onGameStart() {
        var e = this.getCurPlayer(), t = e.node.position;
        kk.cameraManager.startFollow(t), e.showCircleEffect(kk.Config.COLOR_BLUE), this._isActive = !0, 
        this._isDisableAnim = !1, kk.GuiSystem.add("SceneUI");
      },
      onGamePause: function onGamePause() {
        this._isActive = !1, this._isDisableAnim = !0;
      },
      onGameResume: function onGameResume() {
        this._isActive = !0, this._isDisableAnim = !1;
      },
      onGameDefeat: function onGameDefeat() {
        this.startleTagPool.clear(), TimerHandler.add(TimerHandler.Type.COMMON, TimerHandler.Loop.ONCE, .6, function() {
          this._isDisableAnim = !0, this._gemLabelPool.clear(), this._gemEffectPool.clear(), 
          TimerHandler.stopGameTimer(), kk.GuiSystem.remove("SceneUI"), kk.GuiSystem.add("ReviveUI");
        }, this);
      },
      onGameSuccess: function onGameSuccess() {
        this.startleTagPool.clear(), MessageHandler.dispatch(kk.Enum.MsgKey.LEVEL_GAME_COUNT, this._gameEndTag), 
        TimerHandler.add(TimerHandler.Type.COMMON, TimerHandler.Loop.ONCE, .6, function() {
          this._isDisableAnim = !0, this._gemLabelPool.clear(), this._gemEffectPool.clear(), 
          TimerHandler.stopGameTimer(), this.winRewardCheck(), kk.GuiSystem.remove("SceneUI"), 
          kk.GuiSystem.add("GameOverUI", function(e) {
            e.setData(kk.Enum.CostType.GOLD, kk.Config.gameSuccessReward);
          }, this);
        }, this);
      },
      checkAttackContact: function checkAttackContact() {
        for (var e = void 0, t = this.getContactList(), i = t.length - 1; i >= 0; i--) {
          if (!(e = this.getCurPlayer())) return;
          t[i].interact(e);
        }
      },
      checkGameWin: function checkGameWin() {
        var e = this.getCurPlayer();
        if (!e) return this.switchState(kk.Enum.GameState.DEFEAT), kk.AnimLib.shake(kk.curScene.node, cc.Vec2.ZERO, 10, null);
        kk.curScene.getObjs(kk.Enum.ObjType.MONSTER).length || (e.switchState(kk.Enum.RoleState.IIdle), 
        this.switchState(kk.Enum.GameState.SUCCESS), this.upgradeLevel());
      },
      initFogTracer: function initFogTracer() {
        this.fogTracer = kk.curScene.getSightGraphics();
      },
      initStartleTagPool: function initStartleTagPool() {
        var e = new cc.Node("StartleTag"), t = e.addComponent(cc.Sprite);
        e.setContentSize(52, 56), e.setParent(kk.curScene.getLayerNode()), t.sizeMode = cc.Sprite.SizeMode.CUSTOM, 
        kk.AssetLib.setSprite(e, "emoteQuestionMark"), this.startleTagPool = new NodePool(e, 3);
      },
      showStartleTag: function showStartleTag() {
        return this.startleTagPool.add(NodePool.Type.SCALE);
      },
      hideStartleTag: function hideStartleTag(e) {
        this.startleTagPool.put(e);
      },
      drawSceneFog: function drawSceneFog() {
        this.fogTracer.clear();
        var e = kk.curScene.getObjs(kk.Enum.ObjType.MONSTER);
        if (e.length) for (var t = 0; t < e.length; t++) e[t].drawSight(this.fogTracer);
      },
      registerEvent: function registerEvent() {
        MessageHandler.add(kk.Enum.MsgKey.TOUCH_START, this.onTouchStart, this);
      },
      unRegisterEvent: function unRegisterEvent() {
        MessageHandler.remove(kk.Enum.MsgKey.TOUCH_START, this.onTouchStart, this);
      },
      readSkinConfig: function readSkinConfig() {
        kk.AssetLib.loadAsset("config/skinInfo", cc.JsonAsset, function(e) {
          this._skinData = Utils.clone(e.json), this.readTileConfig();
        }, null, this);
      },
      readTileConfig: function readTileConfig() {
        kk.AssetLib.loadAsset("config/tileConfig", cc.JsonAsset, function(e) {
          this._tileData = Utils.clone(e.json), this.readLevelConfig();
        }, null, this);
      },
      readLevelConfig: function readLevelConfig() {
        kk.AssetLib.loadAsset("config/level".concat(this._mapId), cc.JsonAsset, function(e) {
          this._levelData = Utils.clone(e.json), this.readMapConfig();
        }, null, this);
      },
      readMapConfig: function readMapConfig() {
        kk.AssetLib.loadAsset("config/map".concat(this._mapId), cc.JsonAsset, function(e) {
          this._blockData = Utils.clone(e.json), this.initScene(), this.alignCamera(), this.initGemPool(), 
          this.initFogTracer(), this.initStartleTagPool(), this.initMainView();
        }, null, this);
      },
      initScene: function initScene() {
        kk.curScene = new n(this._levelData), kk.curScene.initModel(), kk.curScene.initProjectionGraphics(), 
        kk.curScene.initGridsOfMap(this._levelData, this._blockData, this._tileData), kk.curScene.initObjsOfMap(this._levelData), 
        kk.curScene.initAStar(), kk.curScene.initBulletPool();
      },
      initMainView: function initMainView() {
        kk.quickStart ? (this._isInitOver = !0, this.checkTestSkin()) : (kk.GuiSystem.add("MainUI"), 
        this._isInitOver = !0), kk.quickStart = !1;
      },
      checkTestSkin: function checkTestSkin() {
        kk.curUser.hasOwnAllSkins() ? this.startLevel() : (kk.sdkBridger.destroyBanner(kk.sdkBridger.bannerForMain), 
        kk.GuiSystem.add("SkinTestUI", function(e) {
          kk.GuiSystem.hookClose(e, this.startLevel, this);
        }, this));
      },
      startLevel: function startLevel() {
        this.switchState(kk.Enum.GameState.START, function(e) {
          e ? (kk.sdkBridger.destroyBanner(kk.sdkBridger.bannerForMain), kk.sdkBridger.destroyBanner(kk.sdkBridger.bannerForTest)) : kk.GuiSystem.add("MainUI");
        }.bind(this));
      },
      alignCamera: function alignCamera() {
        kk.cameraManager.alignPosition(new cc.Vec2(0, kk.curScene.mapOriginY - kk.curScene.getHeight()));
      },
      initGemPool: function initGemPool() {
        kk.AssetLib.loadAsset("prefab/GemLabel", cc.Prefab, function(e) {
          var t = cc.instantiate(e);
          t.setParent(kk.curScene.getLayerNode(kk.Enum.ObjType.FORE)), this._gemLabelPool = new NodePool(t, 30);
        }, null, this), kk.AssetLib.loadAsset("prefab/Gem", cc.Prefab, function(e) {
          var t = cc.instantiate(e);
          t.setParent(kk.curScene.getLayerNode(kk.Enum.ObjType.FORE)), t.setScale(.6, .6), 
          this._gemEffectPool = new NodePool(t, 30);
        }, null, this);
      },
      addGemEffect: function addGemEffect(e, t) {
        for (var i = this, n = void 0, s = function s(t) {
          var s = i._gemEffectPool.add(NodePool.Type.RECYCLE);
          s.setPosition(e), n = e.add(new cc.Vec2(Math.randomPlusMinus() * Math.randomRange(50, 150), Math.randomPlusMinus() * Math.randomRange(50, 150))), 
          s.stopAllActions(), s.runAction(cc.sequence(cc.moveTo(.2, n), cc.delayTime(.1), cc.callFunc(function() {
            this._gems.push(s);
          }, i)));
        }, o = 0; o < t; o++) s();
      },
      addGemLabel: function addGemLabel(e, t) {
        this._gemLabelNode || (this._gemLabelNode = this._gemLabelPool.add(NodePool.Type.RECYCLE)), 
        this._gemLabelNode.getComponentInChildren(cc.Label).string = ";".concat(t), TimerHandler.add(TimerHandler.Type.GAME, TimerHandler.Loop.ONCE, .6, function() {
          this._gemLabelNode && (this._gemLabelPool.put(this._gemLabelNode), this._gemLabelNode = null);
        }, this);
      },
      updateGemsPos: function updateGemsPos() {
        if (this._gems.length) {
          var e = this.getCurPlayer();
          if (e) for (var t = this._gems.length - 1; t >= 0; t--) {
            var i = this._gems[t];
            i && (Utils.distance(this._gems[t].position, e.node.position) <= 10 ? (this._gemEffectPool.put(i), 
            this._gems.remove(i)) : i.position = i.position.lerp(e.node.position, .3, cc.Vec2.ZERO));
          }
        }
      },
      updateGemLabelNode: function updateGemLabelNode() {
        if (this._gemLabelNode) {
          var e = this.getCurPlayer();
          e && (this._gemLabelNode.position = e.node.position.add(cc.Vec2.UP.mul(50)));
        }
      },
      updateGameEndTag: function updateGameEndTag(e) {
        this._gameEndTag >= kk.Enum.GameEndTag.PAIN_AND_FIND || this._gameEndTag !== e && (this._gameEndTag += e);
      },
      getContactList: function getContactList() {
        return [].concat(kk.curScene.getObjs(kk.Enum.ObjType.MONSTER)).concat(kk.curScene.getObjs(kk.Enum.ObjType.BULLET));
      },
      winRewardCheck: function winRewardCheck() {
        return !(kk.addRuntimeData("GameCount", 1) < 10) && (kk.setRuntimeData("GameCount", 0), 
        !0);
      },
      upgradeLevel: function upgradeLevel() {
        var e = kk.curUser.getInfo("playedLevel") + 1;
        e > kk.Config.limitLevel || (kk.curUser.addInfo("playedLevel", 1), kk.Client.saveUser(kk.ServerApi.Address.POST_GAME_OVER, e, this._totalGold, this._totalRevive), 
        kk.sdkBridger.saveOpenData([ {
          key: "level",
          value: e.toString()
        } ]));
      },
      onMonsterKilled: function onMonsterKilled(e) {
        this.addKillCount(e), this.addTotalGold(kk.Config.killMonsterReward), this.addGemEffect(e.node.position, kk.Config.killMonsterReward), 
        this.addGemLabel(e.node.position, this._totalGold), kk.Client.saveUser(kk.ServerApi.Address.POST_GET_GOLD, "3", kk.Config.killMonsterReward, function(e) {
          e && 0 === e.code ? kk.curUser.addGold(kk.Config.killMonsterReward, !0) : kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("error_text.response_data_error"), !1, 600);
        }), MessageHandler.dispatch(kk.Enum.MsgKey.LEVEL_KILL_MONSTER, e), 1 !== this._killMonsterCount && MessageHandler.dispatch(kk.Enum.MsgKey.LEVEL_KILL_CONTINUOUS);
      },
      addKillCount: function addKillCount(e) {
        return !(this._killMonsterCount >= kk.curScene.monsterCount) && (this._killMonsterCount++, 
        !0);
      },
      addTotalGold: function addTotalGold(e) {
        "number" != typeof e || e <= 0 || (this._totalGold += e);
      },
      revive: function revive() {
        this._totalRevive++, kk.curScene.createObj(kk.Enum.ObjType.PLAYER, this._levelData.player), 
        this.alignCamera(), this.switchState(kk.Enum.GameState.START);
      },
      getSkinData: function getSkinData() {
        return this._skinData;
      },
      getCurPlayer: function getCurPlayer() {
        return kk.curScene.getObjs(kk.Enum.ObjType.PLAYER)[0];
      },
      onTouchMonster: function onTouchMonster(e) {
        var t = kk.curScene.getObjs(kk.Enum.ObjType.MONSTER);
        if (t.length) for (var i = 0, n = t.length; i < n; i++) Utils.distance(e, t[i].node.position) <= 50 && t[i].showCircleEffect(kk.Config.COLOR_ORANGE, 100, 0);
      },
      onTouchStart: function onTouchStart(e) {
        if (kk.Game.isRunning()) {
          var t = this.getCurPlayer();
          if (t) {
            var i = t.node.position, n = this.node.convertToNodeSpaceAR(e.getLocation());
            n = n.add(kk.cameraManager.node.position);
            var s = kk.curScene.posToGrid(i), o = kk.curScene.gridToIndex(s[0], s[1]), a = kk.curScene.posToGrid(n);
            if (kk.curScene.isMovableGrid(a[0], a[1]) || null !== (a = kk.curScene.findNearestIndex(a[0], a[1]))) {
              this.onTouchMonster(n);
              var r = t.getCurPath();
              if (r.length) {
                var c = kk.curScene.gridToPos(a[0], a[1]), u = r[r.length - 1];
                if (c.x === u.x && c.y === u.y) return;
              }
              var d = kk.curScene.gridToIndex(a[0], a[1]);
              t.clearPath(), kk.curScene.aStar.getPath(o, d, function(e, i) {
                e && (t.updatePath(i), t.switchState(kk.Enum.RoleState.IRun), kk.cameraManager.startFollow(i[i.length - 1]));
              }, this), n = null;
            }
          }
        }
      },
      release: function release() {
        this.unRegisterEvent(), this._isActive = !1, this._isInitOver = !1, this._isDisableAnim = !1, 
        this._tileData = null, this._levelData = null, this._blockData = null, this._skinData = null, 
        this._gemLabelNode = null, this._killMonsterCount = 0, this._gameEndTag = 0, this._totalGold = 0, 
        this._totalRevive = 0, this._gems = [], this._level = 1, this._mapId = 1;
      }
    });
    cc._RF.pop();
  }, {
    Scene: "Scene"
  } ],
  LoadScreen: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "94efeYED51MdIyFPKN12//9", "LoadScreen");
    "use strict";
    var n = require("Enum");
    cc.Class({
      extends: cc.Component,
      properties: {
        loadProgressBar: {
          default: null,
          type: cc.ProgressBar,
          displayName: "\u8fdb\u5ea6\u6761"
        },
        loadProgressLabel: {
          default: null,
          type: cc.Label,
          displayName: "\u8fdb\u5ea6\u6587\u672c"
        },
        progressType: {
          default: n.ProgressType.PERCENT,
          type: n.ProgressType,
          displayName: "\u8fdb\u5ea6\u6587\u672c\u6837\u5f0f"
        }
      },
      start: function start() {
        this.loadProgressBar = this.getComponentInChildren(cc.ProgressBar), this.loadProgressLabel = this.getComponentInChildren(cc.Label);
        cc.vv = {};
        var NativeUtils1 = require("./NativeUtils");
        cc.vv.NativeUtils = new NativeUtils1();
      },
      onProgress: function onProgress(e, t) {
        e < 0 || t <= 0 || (this.setProgressBar(e, t), this.setProgressLabel(e, t));
      },
      setProgressBar: function setProgressBar(e, t) {
        this.loadProgressBar && (this.loadProgressBar.progress = (e / t).toFixed(2));
      },
      setProgressLabel: function setProgressLabel(e, t) {
        if (this.loadProgressLabel) switch (this.progressType) {
         case n.ProgressType.PERCENT:
          this.loadProgressLabel.string = Math.floor(e / t * 100) + "%";
          break;

         case n.ProgressType.NUMBER:
          this.loadProgressLabel.string = e.concat("/").concat(t);
        }
      },
      onDestroy: function onDestroy() {
        kk.AssetLib.releaseAsset("gui/LoadScreen", cc.Prefab);
      }
    });
    cc._RF.pop();
  }, {
    "./NativeUtils": "NativeUtils",
    Enum: "Enum"
  } ],
  LoadingScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "debf5q1SNZFoZu3AKbcCY0j", "LoadingScene");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      onLoad: function onLoad() {},
      start: function start() {}
    });
    cc._RF.pop();
  }, {} ],
  LocalizeSystem: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "720bf0DOzxGo4E+NzGCqxY1", "LocalizeSystem");
    "use strict";
    var n = require("LanguageData"), s = {
      init: function init() {
        this.language = function() {
          return "EN";
        }(), n.init(this.language), n.updateSceneRenderers();
      },
      localizeText: function localizeText(e) {
        if (this.language || this.init(), !e) throw new Error(e + "\u672c\u5730\u5316\u5931\u8d25\uff0c\u68c0\u67e5\u53c2\u6570\u8bbe\u7f6e");
        return n.t(e);
      },
      localizeAtlas: function localizeAtlas(e) {
        if (this.language || this.init(), !e) throw new Error(e + "\u672c\u5730\u5316\u5931\u8d25\uff0c\u68c0\u67e5\u53c2\u6570\u8bbe\u7f6e");
        return kk.AssetLib.retainAsset(n.t(e), cc.SpriteAtlas);
      }
    };
    module.exports = s;
    cc._RF.pop();
  }, {
    LanguageData: "LanguageData"
  } ],
  LocalizedLabel: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "744dcs4DCdNprNhG0xwq6FK", "LocalizedLabel");
    "use strict";
    var i18n = require("LanguageData");
    function debounce(func, wait, immediate) {
      var timeout;
      return function() {
        var context = this, args = arguments;
        var later = function later() {
          timeout = null;
          immediate || func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        callNow && func.apply(context, args);
      };
    }
    cc.Class({
      extends: cc.Component,
      editor: {
        executeInEditMode: true,
        menu: "i18n/LocalizedLabel"
      },
      properties: {
        dataID: {
          get: function get() {
            return this._dataID;
          },
          set: function set(val) {
            if (this._dataID !== val) {
              this._dataID = val;
              false;
              this.updateLabel();
            }
          }
        },
        _dataID: ""
      },
      onLoad: function onLoad() {
        false;
        i18n.inst || i18n.init();
        this.fetchRender();
      },
      fetchRender: function fetchRender() {
        var label = this.getComponent(cc.Label);
        if (label) {
          this.label = label;
          this.updateLabel();
          return;
        }
      },
      updateLabel: function updateLabel() {
        if (!this.label) {
          cc.error("Failed to update localized label, label component is invalid!");
          return;
        }
        var localizedString = i18n.t(this.dataID);
        localizedString && (this.label.string = i18n.t(this.dataID));
      }
    });
    cc._RF.pop();
  }, {
    LanguageData: "LanguageData"
  } ],
  LocalizedSprite: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f34ac2GGiVOBbG6XlfvgYP4", "LocalizedSprite");
    "use strict";
    var SpriteFrameSet = require("SpriteFrameSet");
    cc.Class({
      extends: cc.Component,
      editor: {
        executeInEditMode: true,
        inspector: "packages://i18n/inspector/localized-sprite.js",
        menu: "i18n/LocalizedSprite"
      },
      properties: {
        spriteFrameSet: {
          default: [],
          type: SpriteFrameSet
        }
      },
      onLoad: function onLoad() {
        this.fetchRender();
      },
      fetchRender: function fetchRender() {
        var sprite = this.getComponent(cc.Sprite);
        if (sprite) {
          this.sprite = sprite;
          this.updateSprite(window.i18n.curLang);
          return;
        }
      },
      getSpriteFrameByLang: function getSpriteFrameByLang(lang) {
        for (var i = 0; i < this.spriteFrameSet.length; ++i) if (this.spriteFrameSet[i].language === lang) return this.spriteFrameSet[i].spriteFrame;
      },
      updateSprite: function updateSprite(language) {
        if (!this.sprite) {
          cc.error("Failed to update localized sprite, sprite component is invalid!");
          return;
        }
        var spriteFrame = this.getSpriteFrameByLang(language);
        !spriteFrame && this.spriteFrameSet[0] && (spriteFrame = this.spriteFrameSet[0].spriteFrame);
        this.sprite.spriteFrame = spriteFrame;
      }
    });
    cc._RF.pop();
  }, {
    SpriteFrameSet: "SpriteFrameSet"
  } ],
  MainScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "75939EF6b9OhbM/VPUsbCIB", "MainScene");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        sampleNode: cc.Prefab,
        contentNode: cc.Node,
        gameOverNode: cc.Prefab,
        timeNode: cc.Label
      },
      onLoad: function onLoad() {
        Globals.times = 19;
        this.timeNode.getComponent(cc.Label).string = Globals.times;
        Globals.changeImages = false;
        Globals.isTouch = 0;
        cc.vv.uiUtils.autoFit(this.node);
        this.maxNum = 4;
        this.Num = 2;
        this.addImgs();
        this.storage();
        this.gameOver();
      },
      storage: function storage() {
        var self = this;
        cc.find("Canvas").on("isTouch", function(data) {
          data && self.scheduleOnce(function() {
            self.addImgs();
            Globals.isTouch = 0;
          }, .5);
        });
      },
      addImgs: function addImgs() {
        this.contentNode.removeAllChildren();
        if (Globals.passing) {
          this.maxNum = (this.Num + 1) * (this.Num + 1);
          this.Num += 1;
          25 == this.maxNum && (this.maxNum = 25);
          Globals.passing = false;
        }
        this.maxLineNum = Math.sqrt(this.maxNum);
        this.maxHNum = Math.sqrt(this.maxNum);
        var sample = cc.instantiate(this.sampleNode);
        2 == this.maxLineNum && (this.contentNode.width = 400);
        var arr = [];
        for (var i = 1; i <= this.maxNum; i++) arr.push(i);
        arr = cc.vv.utils.shuffle(arr);
        console.log(arr);
        for (var i = 0; i < this.maxNum; i++) {
          var sample = cc.instantiate(this.sampleNode);
          var currentWidth = (this.contentNode.width - this.contentNode.getComponent(cc.Layout).spacingX * (this.maxLineNum - 1)) / this.maxLineNum;
          sample.width = Math.floor(currentWidth);
          sample.height = currentWidth;
          this.contentNode.addChild(sample);
          sample.getComponent("Sample").showImages(arr[i], this.maxNum);
        }
      },
      gameOver: function gameOver() {
        var self = this;
        cc.find("Canvas").on("over", function(data) {
          var over = cc.instantiate(self.gameOverNode);
          self.node.addChild(over);
          cc.re.centerNode.active = true;
          Globals.changeImages = false;
          cc.re.recommendJs.showMoreGame();
        });
      },
      start: function start() {}
    });
    cc._RF.pop();
  }, {} ],
  MainUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "cf99eM+VCtL1J2uGXDgX58V", "MainUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      init: function init() {
        this.goldLabel = cc.find("TopLayer/LeftLabels/GoldLabel", this.node).getComponent(cc.Label), 
        this.signRewardLabel = cc.find("RightLabels/DailyLabel", this.node).getComponent(cc.Label), 
        this.levelLabel = cc.find("Start/Level", this.node).getComponent(cc.Label), this.menu = this.node.getChildByName("Menu"), 
        this.retractBtn = this.menu.getChildByName("Retract"), this.taskSpriteNodes = this.menu.getChildByName("Sprites").children, 
        this.taskLabelNodes = this.menu.getChildByName("Labels").children, this.upgradeSpriteNode = this.taskSpriteNodes[0], 
        this.upgradeLabelNode = this.taskLabelNodes[0], this.skinNode = cc.find("Player/Model", this.upgradeSpriteNode), 
        this.gemTimers = [], this.waitUpdateGold = !1, this.waitingTaskIdxs = [], this.actionNodes = [], 
        this.initPool(), this.alignMenu(), this.registerEvents(), kk.sdkBridger.showBanner(kk.sdkBridger.bannerForMain), 
        this.alignTimer = setTimeout(this.alignPos.bind(this), 10), MessageHandler.dispatch(kk.Enum.MsgKey.GAME_INIT_OVER);
        HUHU_setLoadingProgress(100);
        console.log("=====init mainui===");
      },
      alignPos: function alignPos() {
        if (kk.isSprs()) {
          var e = this.node.getChildByName("TopLayer");
          e.getComponent(cc.Widget).updateAlignment(), e.setPosition(e.position.x, e.position.y - 60);
        }
      },
      alignMenu: function alignMenu() {
        this.menu.setPosition(.5 * -cc.winSize.width, this.menu.position.y);
      },
      initPool: function initPool() {
        kk.AssetLib.loadAsset("prefab/Gem", cc.Prefab, function(e) {
          var t = cc.instantiate(e);
          t.setParent(this.node), t.setScale(.6, .6), this.effectPool = new NodePool(t, 30);
        }, null, this);
      },
      clearPool: function clearPool() {
        this.effectPool && this.effectPool.clear();
      },
      updateData: function updateData() {
        this.updateRetractState(), this.updateSkin(kk.curUser.getCurSkinId()), this.updateLevel(), 
        this.updateGold(), this.updateTasks(), this.updateSignState();
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.USER_UPDATE_LEVEL, this.updateLevel, this), MessageHandler.add(kk.Enum.MsgKey.USER_UPDATE_GOLD, this.updateGold, this), 
        MessageHandler.add(kk.Enum.MsgKey.USER_SWITCH_SKIN, this.updateSkin, this), MessageHandler.add(kk.Enum.MsgKey.USER_TASK_UPDATE, this.updateTaskNode, this), 
        MessageHandler.add(kk.Enum.MsgKey.USER_UPDATE_SIGN_STATE, this.updateSignState, this), 
        MessageHandler.add(kk.Enum.MsgKey.USER_UPDATE_SIGN, this.onSignSuccess, this), MessageHandler.add(kk.Enum.MsgKey.GUI_MAIN_TASK_WAIT, this.onWaitingTaskAdd, this), 
        MessageHandler.add(kk.Enum.MsgKey.GUI_MAIN_TASK_ANIM_BACK, this.onWaitingTaskAnimBack, this), 
        MessageHandler.add(kk.Enum.MsgKey.GUI_MAIN_TASK_TEMP_UPDATE, this.tempUpdateTask, this);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.USER_UPDATE_LEVEL, this.updateLevel, this), 
        MessageHandler.remove(kk.Enum.MsgKey.USER_UPDATE_GOLD, this.updateGold, this), MessageHandler.remove(kk.Enum.MsgKey.USER_SWITCH_SKIN, this.updateSkin, this), 
        MessageHandler.remove(kk.Enum.MsgKey.USER_TASK_UPDATE, this.updateTaskNode, this), 
        MessageHandler.remove(kk.Enum.MsgKey.USER_UPDATE_SIGN_STATE, this.updateSignState, this), 
        MessageHandler.remove(kk.Enum.MsgKey.USER_UPDATE_SIGN, this.onSignSuccess, this), 
        MessageHandler.remove(kk.Enum.MsgKey.GUI_MAIN_TASK_WAIT, this.onWaitingTaskAdd, this), 
        MessageHandler.remove(kk.Enum.MsgKey.GUI_MAIN_TASK_ANIM_BACK, this.onWaitingTaskAnimBack, this), 
        MessageHandler.remove(kk.Enum.MsgKey.GUI_MAIN_TASK_TEMP_UPDATE, this.tempUpdateTask, this);
      },
      updateLevel: function updateLevel() {
        this.levelLabel.string = String.format(kk.LocalizeSystem.localizeText("label_text.levelIndex"), kk.curUser.getCurLevel());
      },
      updateGold: function updateGold() {
        this.waitUpdateGold || (this.goldLabel.string = kk.curUser.getGold(), this.updateGradeUp());
      },
      updateSignState: function updateSignState() {
        this.signRewardLabel.string = this.mathSignInReward().toString();
      },
      updateGradeUp: function updateGradeUp() {
        var e = this.upgradeLabelNode.getChildByName("Title").getComponent(cc.Label), t = this.upgradeLabelNode.getChildByName("Text").getComponent(cc.Label), i = this.upgradeSpriteNode.getChildByName("ProgressBar").getComponent(cc.ProgressBar), n = kk.curUser.getGold(), s = kk.curUser.getRandomPrice(), o = n / s;
        e.string = kk.LocalizeSystem.localizeText("label_text.upgradeRole"), t.string = n + ":" + s, 
        i.progress = o < 0 ? 0 : o > 1 ? 1 : o;
      },
      updateSkin: function updateSkin(e) {
        var t = "assassin".concat((e = e || 0) + 1), i = "assassinLeg".concat(e + 1), n = this.skinNode.getChildByName("Legs").children, s = this.skinNode.getChildByName("Body");
        kk.AssetLib.setSprite(s, t), kk.AssetLib.setSprite(n[0], i), kk.AssetLib.setSprite(n[1], i);
      },
      updateTasks: function updateTasks() {
        for (var e = kk.curUser.getTasks(), t = 0; t < e.length; t++) {
          if (t >= kk.Config.taskMaxCount) return;
          var i = e[t].id, n = kk.TaskSystem.tasks[i];
          this.updateTaskNode(t, n);
        }
      },
      updateTaskNode: function updateTaskNode(e, t) {
        var i = this.taskSpriteNodes[e + 1], n = this.taskLabelNodes[e + 1], s = n.getChildByName("Title").getComponent(cc.Label), o = n.getChildByName("Text").getComponent(cc.Label), a = n.getChildByName("RewardNum").getComponent(cc.Label), r = i.getChildByName("Button"), c = i.getChildByName("ProgressBar").getComponent(cc.ProgressBar);
        if (t) if (this.waitingTaskIdxs.contains(e) && this.waitingTaskIdxs.remove(e), c.progress = t.getProgressOfNumber(), 
        o.string = t.getProgressOfString(), s.string = t.getTitle(t.aimType), a.string = t.getReward(), 
        t.isOver()) kk.AssetLib.setSprite(r, "button1"), r.addClickEvent("MainUI", "getTaskReward", JSON.stringify({
          id: t.getUID(),
          index: e
        }), this.node); else if (t.isVideo()) kk.AssetLib.setSprite(r, "button1"), r.addClickEvent("MainUI", "watchVideo", kk.Enum.SdkTag.VIDEO_TASK_EARN_GEM.concat(e.toString()), this.node); else {
          kk.AssetLib.setSprite(r, "button3");
          var u = r.getComponent(cc.Button);
          u && (u.interactable = !1);
        } else {
          c.progress = 0, o.string = "0:0", s.string = kk.LocalizeSystem.localizeText("sys_text.loading"), 
          a.string = "0", kk.AssetLib.setSprite(r, "button3");
          var d = r.getComponent(cc.Button);
          d && (d.interactable = !1);
        }
      },
      updateTaskRetract: function updateTaskRetract(e) {
        var t = this.taskSpriteNodes[0].getChildByName("Player"), i = this.taskSpriteNodes[0].getChildByName("Button");
        e ? (t.setPosition(135, t.position.y), i.setContentSize(80, 80)) : (t.setPosition(105, t.position.y), 
        i.setContentSize(140, 80));
        for (var n = 0; n < 3; n++) {
          if (n >= kk.Config.taskMaxCount) return;
          var s = this.taskSpriteNodes[n + 1], o = this.taskLabelNodes[n + 1];
          i = s.getChildByName("Button");
          var a = s.getChildByName("RewardIcon"), r = o.getChildByName("RewardNum"), c = o.getChildByName("RewardText");
          e ? (r.active = !1, a.setPosition(135, a.position.y), c.setPosition(135, c.position.y), 
          i.setContentSize(80, 80)) : (r.active = !0, a.setPosition(75, a.position.y), c.setPosition(105, c.position.y), 
          i.setContentSize(140, 80));
        }
      },
      addGemEffect: function addGemEffect(e, t, i) {
        var n = e.getChildByName("RewardNum"), s = kk.GuiSystem.convertToGuiPosition(n), o = kk.GuiSystem.convertToGuiPosition(cc.find("TopLayer/LeftButtons/Gold", this.node));
        kk.AnimLib.numberIterator(n, t, 0, 2, function() {
          MessageHandler.dispatch(kk.Enum.MsgKey.GUI_MAIN_TASK_ANIM_BACK, i);
        }.bind(this));
        var a = t > 20 ? 20 : t, r = Math.floor(t / a), c = setInterval(function() {
          if (a <= 0) return clearInterval(c), this.gemTimers.remove(c), s = null, o = null, 
          a = null, void (t = null);
          this.addGem(s, o, r), a--;
        }.bind(this), 100);
        this.gemTimers.push(c);
      },
      addGem: function addGem(e, t, i) {
        var n = [], s = this.effectPool.add(NodePool.Type.RECYCLE), o = Utils.getPointOnCircle(e.x, e.y, Math.random(), (t.y - e.y) / 2);
        n.push(e), n.push(new cc.Vec2(o.x, o.y)), n.push(t);
        var a = cc.bezierTo(.6, n), r = cc.callFunc(function() {
          s.stopAllActions(), this.goldLabel.string = parseInt(this.goldLabel.string) + i, 
          this.effectPool.put(s), this.actionNodes.remove(s), i = null;
        }, this);
        this.actionNodes.push(s), s.setPosition(e), s.stopAllActions(), s.runAction(cc.sequence(a, r));
      },
      scaleTaskNode: function scaleTaskNode(e) {
        var t = this.taskSpriteNodes[e + 1], i = this.taskLabelNodes[e + 1], n = cc.callFunc(function() {
          t.stopAllActions(), i.stopAllActions(), t.setScale(1, 1), i.setScale(1, 1), this.actionNodes.remove(t), 
          this.actionNodes.remove(i), MessageHandler.dispatch(kk.Enum.MsgKey.GUI_MAIN_TASK_TEMP_UPDATE, e);
        }, this);
        this.actionNodes.push(t), this.actionNodes.push(i), t.stopAllActions(), i.stopAllActions(), 
        t.runAction(cc.scaleTo(.3, 0, 0)), i.runAction(cc.sequence(cc.scaleTo(.3, 0, 0), n));
      },
      tempUpdateTask: function tempUpdateTask(e) {
        this.waitingTaskIdxs.contains(e) && this.updateTaskNode(e, null);
      },
      getTaskReward: function getTaskReward(e, t) {
        kk.AudioSystem.play(kk.AudioName.GUI, "click");
        var i = (t = JSON.parse(t)).id, n = kk.TaskSystem.getTaskByUID(i);
        if (n && n.isOver()) {
          var s = n.getReward(), o = t.index, a = this.taskLabelNodes[o + 1];
          this.taskSpriteNodes[o + 1].getChildByName("Button").clearClickEvent(), this.addGemEffect(a, s, o), 
          kk.Client.saveUser(kk.ServerApi.Address.POST_GET_GOLD, "3", s, function(e) {
            e && 0 === e.code ? n && (MessageHandler.dispatch(kk.Enum.MsgKey.GUI_MAIN_TASK_WAIT, o), 
            kk.TaskSystem.achieve(n, o), kk.curUser.addGold(s)) : kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("error_text.response_data_error"), !1, 600);
          }.bind(this));
        }
      },
      onWaitingTaskAdd: function onWaitingTaskAdd(e) {
        this.waitingTaskIdxs.contains(e) || this.waitingTaskIdxs.push(e), this.waitUpdateGold = !0;
      },
      onWaitingTaskAnimBack: function onWaitingTaskAnimBack(e) {
        this.waitUpdateGold = !1, this.scaleTaskNode(e);
      },
      enterGame: function enterGame() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), kk.levelManager.checkTestSkin(), 
        this.close();
      },
      share: function share() {},
      onShareOver: function onShareOver() {
        MessageHandler.remove(kk.Enum.MsgKey.SHARE_PERSONAL, this.onShareOver, this);
        var e = Array.prototype.slice.call(arguments);
        kk.Client.recordSuccessShare(e[1], 1);
      },
      retract: function retract() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click");
        var e = .5 * -cc.winSize.width, t = e - 265, i = this.menu.position.x < e - 100 ? e : t, n = this.menu.position.y;
        this.menu.stopAllActions(), this.actionNodes.push(this.menu), this.menu.runAction(cc.sequence(cc.moveTo(.2, i, n), cc.callFunc(function() {
          this.updateRetractState(), this.actionNodes.remove(this.menu);
        }, this)));
      },
      updateRetractState: function updateRetractState() {
        var e = this.menu.position.x < .5 * -cc.winSize.width - 100;
        this.retractBtn.scaleX = e ? 1 : -1, this.updateTaskRetract(e);
      },
      watchVideo: function watchVideo(e, t) {
        cc.vv.NativeUtils.showVideoAd(0, function() {
          MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, t, true);
        });
      },
      signIn: function signIn() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), kk.curUser.getSignInState() ? kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("label_text.hasSignedToady"), !1, 600) : kk.Client.saveUser(kk.ServerApi.Address.POST_SIGN_IN, function(e) {
          e && "success" === e.msg ? (kk.curUser.signIn(), MessageHandler.dispatch(kk.Enum.MsgKey.USER_UPDATE_SIGN)) : kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("error_text.response_data_error"), !1, 600);
        }.bind(this));
      },
      getSignInReward: function getSignInReward(e) {
        kk.Client.saveUser(kk.ServerApi.Address.POST_GET_GOLD, "1", kk.Config.skinVideoReward, function(t) {
          t && 0 === t.code ? (kk.curUser.addGold(e), kk.GuiSystem.add("RewardUI", function(t) {
            t.setData(kk.Enum.CostType.GOLD, e);
          })) : kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("error_text.response_data_error"), !1, 600);
        }.bind(this));
      },
      onSignSuccess: function onSignSuccess() {
        this.getSignInReward(this.mathSignInReward()), this.updateSignState();
      },
      mathSignInReward: function mathSignInReward() {
        var e = kk.curUser.getSignInCount();
        return e = e >= kk.Config.signInRewards.length ? kk.Config.signInRewards.length - 1 : e, 
        kk.Config.signInRewards[e];
      },
      openSysSet: function openSysSet() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), kk.GuiSystem.add("SystemUI");
      },
      openRank: function openRank() {},
      openSkin: function openSkin() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), kk.GuiSystem.add("SkinUI", function(e) {
          kk.GuiSystem.hookClose(e, function() {
            kk.GuiSystem.add("MainUI");
          }, this);
        }), this.close();
      },
      clearGemTimers: function clearGemTimers() {
        for (var e = 0; e < this.gemTimers.length; e++) clearInterval(this.gemTimers[e]);
        this.waitUpdateGold = !1, this.gemTimers = [];
      },
      clearAlignTimer: function clearAlignTimer() {
        Utils.isNone(this.alignTimer) || clearTimeout(this.alignTimer);
      },
      clearActions: function clearActions() {
        for (var e = 0; e < this.actionNodes.length; e++) this.actionNodes[e].stopAllActions();
        this.actionNodes = [];
      },
      onClose: function onClose() {
        // window.HUHU_showInterstitialAd();
        console.log("===========main close");
        this.clearPool(), this.clearActions(), this.clearGemTimers(), this.clearAlignTimer(), 
        this.unRegisterEvents(), this._super();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  Monster: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2a2efAwCUtOeoYn8oa5OHZw", "Monster");
    "use strict";
    var n = require("Character"), s = cc.Enum({
      DEFAULT: 0,
      WARNING: 1,
      ATTACK: 2
    });
    cc.Class({
      extends: n,
      isMonster: function isMonster() {
        return !0;
      },
      setDefaultProps: function setDefaultProps() {
        this._super(), this._sightType = s.DEFAULT, this._searchEndTime = 0;
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.GameEvent.GAME_START, this.startEvent, this), MessageHandler.add(kk.Enum.MsgKey.LEVEL_KILL_MONSTER, this.startle, this), 
        MessageHandler.add(kk.Enum.MsgKey.LEVEL_FIND_PLAYER, this.warning, this);
      },
      unregisterEvents: function unregisterEvents() {
        MessageHandler.remove(kk.Enum.GameEvent.GAME_START, this.startEvent, this), MessageHandler.remove(kk.Enum.MsgKey.LEVEL_KILL_MONSTER, this.startle, this), 
        MessageHandler.remove(kk.Enum.MsgKey.LEVEL_FIND_PLAYER, this.warning, this);
      },
      startEvent: function startEvent() {
        this.switchState(kk.Enum.RoleState.IWalk);
      },
      drawSight: function drawSight(e) {
        var t = this.node.position, i = this.getFaceAngle(), n = kk.Config.sightPrecision, s = void 0, o = void 0, a = t.sub(kk.cameraManager.node.position);
        e.fillColor = cc.Color.WHITE, e.moveTo(a.x, a.y);
        for (var r = 0; r < n + 1; r++) s = i - (1 - 2 * r / n) * kk.Config.sightAngle, 
        s = Utils.Angle.toPlusMinus(s), o = t.add(Utils.Angle.toVector(s).mul(kk.Config.sightDistance)), 
        this.getFarawaySightOnDir(t, o.clone(), o), a = o.sub(kk.cameraManager.node.position), 
        e.lineTo(a.x, a.y);
        e.close(), e.fill();
      },
      switchSkin: function switchSkin(e) {
        var t = "guard".concat(e = e || ""), i = t.concat("Leg"), n = this.model.getChildByName("Legs").children, s = this.model.getChildByName("Body");
        kk.AssetLib.setSprite(s, t), kk.AssetLib.setSprite(n[0], i), kk.AssetLib.setSprite(n[1], i);
      },
      contact: function contact(e) {
        e.isPlayer() && (e.isInState(kk.Enum.RoleState.IIdle) ? this.switchState(kk.Enum.RoleState.IAttack) : this.switchState(kk.Enum.RoleState.IDead));
      },
      look: function look(e) {
        this.isInState(kk.Enum.RoleState.IAttack) || this.isInSight(e) && this.switchState(kk.Enum.RoleState.IAttack);
      },
      search: function search(e) {
        if (e = e || kk.levelManager.getCurPlayer()) {
          var t = e.node.position, i = kk.curScene.posToGrid(t);
          this.isInSight(e) ? this.switchState(kk.Enum.RoleState.IAttack) : i && 2 === i.length && i[1] < kk.Config.filterNum ? (this.clearSearching(), 
          this.switchState(kk.Enum.RoleState.IWalk)) : this.isInSearching() ? this.follow(e.node.position) : this.switchState(kk.Enum.RoleState.IWalk);
        } else this.switchState(kk.Enum.RoleState.IWalk);
      },
      follow: function follow(e) {
        var t = this.node.position, i = kk.curScene.posToGrid(t), n = kk.curScene.posToGrid(e);
        if (n[1] < kk.Config.filterNum && (n[1] = kk.Config.filterNum), kk.curScene.isMovableGrid(n[0], n[1]) || null !== (n = kk.curScene.findNearestIndex(n[0], n[1]))) {
          var s = kk.curScene.gridToIndex(i[0], i[1]), o = kk.curScene.gridToIndex(n[0], n[1]);
          kk.curScene.aStar.getPath(s, o, function(e, t) {
            e && (this.updatePath(t), this.switchState(kk.Enum.RoleState.IRun));
          }, this);
        } else this.switchState(kk.Enum.RoleState.IWalk);
      },
      pathEndSetting: function pathEndSetting() {
        this.search();
      },
      isInSearching: function isInSearching() {
        return this._searchEndTime > Date.now();
      },
      setSearchIngEndTime: function setSearchIngEndTime() {
        this._searchEndTime = Date.now() + kk.Config.searchDuration;
      },
      clearSearching: function clearSearching() {
        this._searchEndTime = 0;
      },
      startAttack: function startAttack() {
        var e = cc.callFunc(this.attack, this), t = kk.levelManager.getCurPlayer();
        this._sightType = s.ATTACK, this.node.stopAllActions(), this.node.runAction(cc.repeatForever(cc.sequence(e, cc.delayTime(.3)))), 
        kk.levelManager.updateGameEndTag(kk.Enum.GameEndTag.FIND), t.showCircleEffect(kk.Config.COLOR_RED), 
        MessageHandler.dispatch(kk.Enum.MsgKey.LEVEL_FIND_PLAYER, this);
      },
      attack: function attack() {
        var e = kk.levelManager.getCurPlayer();
        if (!e) return this.node.stopAllActions(), void this.switchState(kk.Enum.RoleState.IWalk);
        if (!this.isInSight(e, !0)) return this.node.stopAllActions(), this.setSearchIngEndTime(), 
        void this.search();
        var t = Utils.Angle.between(this.node.position, e.node.position);
        this.switchAngle(t), this.model.getChildByName("Boom").getComponent(cc.Animation).play("Boom"), 
        kk.curScene.addBullet(this, e), kk.AudioSystem.play(kk.AudioName.NPC, "rifle".concat(Math.randomRange(1, 5)));
      },
      warning: function warning(e) {
        e !== this && (Utils.distance(this.node.position, e.node.position) > kk.Config.followValidDistance || (this._sightType = s.WARNING, 
        this.isInState(kk.Enum.RoleState.IGuard) && this.switchState(kk.Enum.RoleState.IWalk)));
      },
      startle: function startle(e) {
        if (e !== this && !(Utils.distance(this.node.position, e.node.position) > kk.Config.followValidDistance || this.isInState(kk.Enum.RoleState.IAttack) || this.isInState(kk.Enum.RoleState.IIdle))) {
          var t = kk.levelManager.showStartleTag(), i = e.node.position;
          t.setPosition(this.node.position.add(cc.Vec2.UP.mul(30))), this.switchState(kk.Enum.RoleState.IIdle), 
          TimerHandler.add(TimerHandler.Type.GAME, TimerHandler.Loop.ONCE, .6, kk.levelManager.hideStartleTag, kk.levelManager, t);
          var n = cc.callFunc(function() {
            this.switchAngle(this.getFaceAngle()), kk.levelManager.getCurPlayer() ? (this.setSearchIngEndTime(), 
            this.follow(i)) : this.switchState(kk.Enum.RoleState.IWalk);
          }, this);
          this.node.stopAllActions(), this.node.runAction(cc.sequence(cc.delayTime(.6), n));
        }
      },
      die: function die() {
        kk.AudioSystem.play(kk.AudioName.NPC, "break".concat(Math.randomRange(1, 4))), TimerHandler.remove(TimerHandler.Type.GAME, this.switchState, this), 
        this.unregisterEvents(), this.showCircleEffect(kk.Config.COLOR_ORANGE, 30, 200), 
        kk.levelManager.onMonsterKilled(this), kk.curScene.removeObj(kk.Enum.ObjType.MONSTER, this), 
        this._super();
      }
    });
    cc._RF.pop();
  }, {
    Character: "Character"
  } ],
  MoveSystem: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "db225dhNOdKVqm05WpFcSkJ", "MoveSystem");
    "use strict";
    var _typeof = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(obj) {
      return typeof obj;
    } : function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    var n = "function" == typeof Symbol && "symbol" == _typeof(Symbol.iterator) ? function(e) {
      return "undefined" === typeof e ? "undefined" : _typeof(e);
    } : function(e) {
      return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : "undefined" === typeof e ? "undefined" : _typeof(e);
    }, s = {
      _hooked: !1,
      _isAwake: !1,
      _items: [],
      init: function init() {
        cc.director.on(cc.Director.EVENT_AFTER_UPDATE, this.lateUpdate, this), this._hooked = !0;
      },
      lateUpdate: function lateUpdate() {
        if (this._isAwake && kk.Game.isActive()) for (var e = this._items.length - 1; e >= 0; e--) this.execute(this._items[e], "onMoving");
      },
      add: function add(e) {
        this._hooked || this.init(), this._items.contains(e) || (this.execute(e, "onStartMove"), 
        this._items.push(e), this._isAwake || (this._isAwake = !0));
      },
      remove: function remove(e) {
        this._items.contains(e) && (this.execute(e, "onStopMove"), this._items.remove(e), 
        this._items.length || (this._isAwake = !1));
      },
      clear: function clear() {
        cc.director.off(cc.Director.EVENT_AFTER_UPDATE, this.lateUpdate, this);
        for (var e = this._items.length - 1; e >= 0; e--) this.execute(this._items[e], "onStopMove");
        this._items = [], this._hooked = !1, this._isAwake = !1;
      },
      execute: function execute(e, t) {
        if ("object" === (void 0 === e ? "undefined" : n(e)) && e.hasOwnProperty(t) && "function" == typeof e[t]) {
          var i = Array.prototype.slice.call(arguments, 2);
          e[t].apply(e, i);
        }
      }
    };
    module.exports = s;
    cc._RF.pop();
  }, {} ],
  NativeUtils: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6a793Gdmh1EP426pVH3HgrI", "NativeUtils");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        _androidClassName: "org/cocos2dx/javascript/AppActivity",
        _iOSClass: "AppJSController",
        _videoCb: null,
        loadInterst: false,
        loadReward: false,
        isShowAds: false,
        _testbanner: null
      },
      start: function start() {},
      request: function request(obj) {},
      getRecommondInfo: function getRecommondInfo() {
        window.GC;
      },
      vibrateShort: function vibrateShort() {},
      showBannerAd: function showBannerAd(height) {
        console.log("==========\u663e\u793a\u6a2a\u5e45\u5e7f\u544a\u539f\u751f\u5e73\u53f0");
      },
      showNativeBanner: function showNativeBanner(height) {},
      hideAllBanner: function hideAllBanner() {
        self._testbanner && self._testbanner.removeFromParent();
      },
      hideNativeBannerAd: function hideNativeBannerAd() {},
      showInsertAd: function showInsertAd(height) {
        // console.log("=========\u663e\u793ashowInsertAd");
        // window["playCountt"] ? window["playCountt"] = window["playCountt"] + 1 : window["playCountt"] = 1;
        // if (window["playCountt"] % 3 == 1) if (window["gdsdk"]) window["gdsdk"].showAd(); else if (window["ysdk"]) {
        //   console.log("=====try show  fullscreen adv");
        //   window["ysdk"].adv.showFullscreenAdv({
        //     callbacks: {
        //       onClose: function onClose(wasShown) {},
        //       onError: function onError(error) {
        //         window["playCountt"] = 1;
        //       }
        //     }
        //   });
        // }
        window.HUHU_showInterstitialAd();
      },
      showPingfen: function showPingfen(height) {},
      hideBannerAd: function hideBannerAd() {},
      showVideoAd: function showVideoAd(op, onSuccess, onCancel) {
        // console.log("==========createRewardedVideoAd\u539f\u751f\u5e73\u53f0");
        // this._videoCb = onSuccess;
        // if (window["gdsdk"]) window["gdsdk"].showAd("rewarded").then(function(response) {}).catch(function(error) {}); else if (window["ysdk"]) {
          var isReward = false;
        //   window["ysdk"].adv.showRewardedVideo({
        //     callbacks: {
        //       onOpen: function onOpen() {
        //         console.log("Video ad open.");
        //       },
        //       onRewarded: function onRewarded() {
        //         isReward = true;
        //       },
        //       onClose: function onClose() {
        //         if (isReward && onSuccess) {
        //           window["playCountt"], window["playCountt"] = 2;
        //           onSuccess();
        //         }
        //       },
        //       onError: function onError(e) {
        //         console.log("Error while open video ad:", e);
        //       }
        //     }
        //   });
        // } else cc.vv.NativeUtils._videoCb(true);
                window.HUHU_showRewardedVideoAd(
                () => {
                    window["playCountt"], window["playCountt"] = 2;
                    onSuccess();

                },
                () => {
                   promptMessage("Failed to get the reward, please watch the ads to the end.");

                }
                );

      },
      loadIGGReward: function loadIGGReward() {
        var self = this;
        window.GC.loadAd({
          unitId: "161-4-465952994059440128"
        }).then(function(adCallbackResult) {
          self.loadReward = true;
        });
      },
      loadIGGIniterst: function loadIGGIniterst() {
        var self = this;
        window.GC.loadAd({
          unitId: "161-2-465952936933019648"
        }).then(function(adCallbackResult) {
          self.loadInterst = true;
        });
      },
      onSuccessVK: function onSuccessVK(adman) {},
      onNoAdsVK: function onNoAdsVK(id) {
        console.log("====onNoAdsVK==");
      },
      showJump: function showJump(id) {
        console.log("======\u539f\u751f\u8df3\u8f6c\uff1a" + id);
      },
      AppCallbackNotify: function AppCallbackNotify(string) {
        console.log("=============\u56de\u8c03\u7684json:----");
        console.log("=============\u6fc0\u52b1\u5e7f\u544a\u89c2\u770b\u5b8c\u6bd5Success1----", string);
        cc.vv.NativeUtils._videoCb(true);
      }
    });
    cc._RF.pop();
  }, {} ],
  ObstructTouch: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6cad48Uy8dPKICa0K2XihYY", "ObstructTouch");
    "use strict";
    var n = require("Enum");
    cc.Class({
      extends: cc.Component,
      properties: {
        bannerType: {
          default: n.BannerType.OVER,
          type: n.BannerType
        },
        obstructOffset: {
          default: 30,
          tooltip: "\u5f00\u542f\u8bef\u70b9\u65f6\u504f\u79fb"
        },
        forceDisable: !1,
        _delayTime: .3,
        _stayTime: .5,
        _moveTime: .3,
        _bannerId: null
      },
      init: function init() {
        var e = this.node.position;
        this.setBannerId(), kk.ServerApi.bannerSwitch && !this.forceDisable ? (this.defaultX = e.x, 
        this.defaultY = e.y - this.obstructOffset, this.setDelayTime(), this.node.setPosition(kk.sdkBridger.bannerPos), 
        this.updateStartPosition()) : (this.defaultX = e.x, this.defaultY = e.y, this.node.setPosition(this.defaultX, this.defaultY), 
        kk.sdkBridger.showBanner(this._bannerId));
      },
      setBannerId: function setBannerId() {
        switch (this.bannerType) {
         default:
         case n.BannerType.REVIVE:
         case n.BannerType.OVER:
         case n.BannerType.REWARD:
          this._bannerId = kk.sdkBridger.bannerForOver;
          break;

         case n.BannerType.TEST:
          this._bannerId = kk.sdkBridger.bannerForTest;
          break;

         case n.BannerType.MAIN:
          this._bannerId = kk.sdkBridger.bannerForMain;
        }
      },
      setDelayTime: function setDelayTime() {
        switch (this.bannerType) {
         default:
         case n.BannerType.OVER:
          this._delayTime = kk.ServerApi.overBannerDelayTime / 1e3;
          break;

         case n.BannerType.REVIVE:
          this._delayTime = kk.ServerApi.reviveBannerDelayTime / 1e3;
          break;

         case n.BannerType.TEST:
         case n.BannerType.REWARD:
          this._delayTime = kk.ServerApi.rewardBannerDelayTime / 1e3;
        }
      },
      updateStartPosition: function updateStartPosition() {
        this.node.stopAllActions(), this.node.runAction(cc.sequence(cc.delayTime(this._delayTime), cc.callFunc(function() {
          kk.sdkBridger.showBanner(this._bannerId);
        }, this), cc.delayTime(this._stayTime), cc.moveTo(this._moveTime, this.defaultX, this.defaultY)));
      }
    });
    cc._RF.pop();
  }, {
    Enum: "Enum"
  } ],
  Player: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a6cb9xquHxAaIDwOQ2u5TFh", "Player");
    "use strict";
    var n = require("Character");
    cc.Class({
      extends: n,
      properties: {
        _pathTracer: null
      },
      isPlayer: function isPlayer() {
        return !0;
      },
      setDefaultProps: function setDefaultProps() {
        this._super(), this._pathTracer = kk.GlSystem.add(kk.Enum.PathKey.PATH, 8, cc.Color.WHITE.fromHEX(kk.Config.COLOR_YELLOW)), 
        this._pathTracer.node.setParent(kk.curScene.getLayerNode(kk.Enum.ObjType.TAG)), 
        this.speed = kk.Config.playerRunSpeed, this.hp = kk.Config.defaultHp;
      },
      getSpeed: function getSpeed() {
        var e = kk.levelManager.getSkinData(), t = kk.curUser.getCurSkinId(), i = e && e[t + 1] ? e[t + 1] : null, n = i && i.ability && i.ability.speed ? i.ability.speed : 0;
        return Math.floor(this.speed * (1 + n / 100));
      },
      getHp: function getHp() {
        var e = kk.levelManager.getSkinData(), t = kk.curUser.getCurSkinId(), i = e && e[t + 1] ? e[t + 1] : null, n = i && i.ability && i.ability.hp ? i.ability.hp : 0;
        return Math.floor(this.hp * (1 + n / 100));
      },
      updateSkin: function updateSkin() {
        var e = kk.curUser.getCurSkinId();
        this.switchSkin(e);
      },
      switchSkin: function switchSkin(e) {
        var t = "assassin".concat((e = e || 0) + 1);
        var i = "assassinLeg".concat(e + 1);
        if (1 == e) {
          t = "assassin222";
          i = "assassinLeg222";
        } else if (2 == e) {
          t = "assassin333";
          i = "assassinLeg333";
        }
        var n = this.model.getChildByName("Legs").children, s = this.model.getChildByName("Body");
        kk.AssetLib.setSprite(s, t), kk.AssetLib.setSprite(n[0], i), kk.AssetLib.setSprite(n[1], i);
      },
      pathUpdateSetting: function pathUpdateSetting(e) {
        e.splice(0, 1, this.node.position), this.drawPath(e);
      },
      pathEndSetting: function pathEndSetting() {
        var e = kk.curScene.posToGrid(this.node.position), t = this.getDirByAngle(this.getFaceAngle());
        kk.curScene.getNextGridOnDir(t, e[0], e[1]) || this.turnDirAsync(e), this.switchState(kk.Enum.RoleState.IIdle), 
        this._pathTracer.clear(), this.hideArrow();
      },
      hurt: function hurt() {
        kk.AudioSystem.play(kk.AudioName.USER, "damage"), kk.levelManager.updateGameEndTag(kk.Enum.GameEndTag.PAIN), 
        this._super();
      },
      die: function die() {
        this._invincibleEndTime = 0, kk.GlSystem.add(this._pathTracer), kk.AudioSystem.play(kk.AudioName.USER, "die1"), 
        this.showCircleEffect(kk.Config.COLOR_RED, 30, 200), kk.curScene.removeObj(kk.Enum.ObjType.PLAYER, this), 
        this._super();
      },
      drawPath: function drawPath(e) {
        if (this._pathTracer.clear(), e && !(e.length < 2)) {
          for (var t = 0, i = void 0, n = void 0, s = void 0, o = void 0, a = void 0, r = void 0, c = void 0, u = void 0, d = 0, l = (u = Utils.Bezier.createCurve(e, e.length, .05, !0)).length; d < l && !((t = 2 * d) >= l); d++) n = u[t].x, 
          s = u[t].y, this._pathTracer.moveTo(n, s), t === l - 1 || t === l - 2 ? this._pathTracer.lineTo(n, s) : (o = u[t + 1].x, 
          a = u[t + 1].y, r = u[t + 2].x, c = u[t + 2].y, this._pathTracer.bezierCurveTo(n, s, o, a, r, c)), 
          i = Math.abs(t - this._colorFromIndex) % l < l / 10 ? kk.Config.COLOR_YELLOW : kk.Config.COLOR_ORANGE, 
          i = cc.Color.WHITE.fromHEX(i), this._pathTracer.strokeColor = i, this._pathTracer.stroke();
          this.showArrow(i), this._colorFromIndex += 4, e = null, u = null;
        }
      },
      showArrow: function showArrow(e) {
        if (this._path && !(this._path.length < 2)) {
          var t = this.getArrowNode(e), i = this._path[this._path.length - 2], n = this._path[this._path.length - 1];
          t.setPosition(n.x, n.y), t.angle = -(180 + Utils.Angle.between(new cc.Vec2(i.x, i.y), new cc.Vec2(n.x, n.y))), 
          t.active = !0;
        }
      },
      hideArrow: function hideArrow() {
        var e = this.getArrowNode();
        e && (e.active = !1);
      },
      getArrowNode: function getArrowNode() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : cc.Color.ORANGE, t = this._pathTracer.node.getChildByName("Arrow");
        t || ((t = new cc.Node("Arrow")).getOrAddComponent(cc.Sprite).sizeMode = cc.Sprite.SizeMode.CUSTOM, 
        t.setContentSize(32, 24), kk.AssetLib.setSprite(t, "indicator"), t.color = e, this._pathTracer.node.addChild(t));
        return t;
      }
    });
    cc._RF.pop();
  }, {
    Character: "Character"
  } ],
  ProgressMain: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "b02efcFs5RPcbRFjRlGSD+N", "ProgressMain");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        horizontalBarReverse: {
          type: cc.ProgressBar,
          default: null
        }
      },
      onLoad: function onLoad() {
        this.speed = .05;
        this.horizontalBarReverse.progress = 1;
      },
      start: function start() {},
      update: function update(dt) {
        Globals.changeImages ? this._updateProgressBar(this.horizontalBarReverse, dt) : this.horizontalBarReverse.progress = 1;
      },
      _updateProgressBar: function _updateProgressBar(progressBar, dt) {
        var progress = progressBar.progress;
        progress -= dt * this.speed;
        progressBar.progress = progress;
        progress < 0 && cc.find("Canvas").emit("over", true);
      }
    });
    cc._RF.pop();
  }, {} ],
  QuickYinsi: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "bb3c9Pd475BApN+cKRN6S5+", "QuickYinsi");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        bgg: cc.Node,
        mianPage: cc.Node,
        yinsiPage: cc.Node,
        xieyiPage: cc.Node,
        notAgree: cc.Node,
        _isShowed: false
      },
      start: function start() {},
      onEnable: function onEnable() {
        var self = this;
        var lastTime = cc.sys.localStorage.getItem("quick_Agree3");
        if ("" === lastTime || null == lastTime || void 0 == lastTime) {
          this.bgg.active = true;
          this.mianPage.active = true;
        } else {
          if (this._isShowed) {
            this.node.active = true;
            this.bgg.active = true;
            this.mianPage.active = true;
            this.notAgree.active = false;
            setTimeout(function() {
              self.node.active = false;
            }, 8e3);
          } else this.node.active = false;
          setTimeout(function() {
            window.gameCConfig && false == window.gameCConfig.shenHe && true == window.gameCConfig.startInter && cc.vv.NativeUtils.showInsertAd();
          }, 3e3);
        }
        this._isShowed = true;
      },
      showYinsi: function showYinsi() {
        this.mianPage.active = false;
        this.yinsiPage.active = true;
      },
      showXieyi: function showXieyi() {
        this.mianPage.active = false;
        this.xieyiPage.active = true;
      },
      showMain: function showMain() {
        this.mianPage.active = true;
        this.yinsiPage.active = false;
        this.xieyiPage.active = false;
      },
      agreeClick: function agreeClick() {
        cc.sys.localStorage.setItem("quick_Agree3", true);
        this.node.active = false;
        setTimeout(function() {
          window.gameCConfig && false == window.gameCConfig.shenHe && true == window.gameCConfig.startInter && cc.vv.NativeUtils.showInsertAd();
        }, 3e3);
      },
      notAgreeClick: function notAgreeClick() {
        var lastTime = cc.sys.localStorage.getItem("quick_Agree3");
        "" === lastTime || null == lastTime || void 0 == lastTime ? window.qg.exitApplication({
          success: function success() {
            console.log("exitApplication success");
          },
          fail: function fail() {
            console.log("exitApplication fail");
          },
          complete: function complete() {
            console.log("exitApplication complete");
          }
        }) : this.node.active = false;
      }
    });
    cc._RF.pop();
  }, {} ],
  RU: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a7b6exf2tFMyZQpwiSokPpp", "RU");
    "use strict";
    window.i18n || (window.i18n = {}), window.i18n.languages || (window.i18n.languages = {}), 
    window.i18n.languages.RU = {
      sys_text: {
        fontForContent: "ninjaVerbFont",
        fontForTitle: "ninjaVerbFont",
        loading: "Loading",
        confirm: "Confirm"
      },
      error_text: {
        load_error: "Load Error",
        share_error: "Share Error",
        no_ad: "Video is loading, wait for a moment",
        no_net: "Network Error",
        net_time_out: "Time out",
        response_data_error: "Info error"
      },
      label_text: {
        coin: "\u043c\u043e\u043d\u0435\u0442\u0430",
        gold: "\u043c\u043e\u043d\u0435\u0442\u0430",
        speed: "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c",
        hp: "HP",
        skin: "\u043a\u043e\u0436\u0430",
        start: "\u043d\u0430\u0447\u0430\u0442\u044c \u0438\u0433\u0440\u0443",
        levelIndex: "\u0423\u0440\u043e\u0432\u0435\u043d\u044c: {0}",
        ladder: "\u0437\u0432\u0430\u043d\u0438\u0435",
        share_friend: "\u9080\u8bf7\u597d\u53cb",
        free_gold: "\u0431\u0435\u0441\u043f\u043b\u0430\u0442\u043d\u044b\u0439 \u043c\u043e\u043d\u0435\u0442\u0430",
        collect: "\u0441\u043e\u0431\u0438\u0440\u0430\u0442\u044c",
        random: "\u0441\u043b\u0443\u0447\u0430\u0439\u043d\u044b\u0439",
        skinSaleOut: "\u043f\u0440\u043e\u0434\u0430\u0432\u0430\u0442\u044c",
        gold_unEnough: "\u043d\u0435\u043f\u043e\u043b\u043d\u044b\u0439",
        revive_success: "\u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c",
        golden_success: "\u043d\u0435\u043f\u043e\u0431\u0435\u0434\u0438\u043c\u044b\u0439 5s",
        upgradeRole: "\u044d\u0441\u043a\u0430\u043b\u0430\u0446\u0438\u044f \u0440\u043e\u043b\u044c",
        music: "\u043c\u0443\u0437\u044b\u043a\u0430",
        sound: "\u0437\u0432\u0443\u043a",
        vibrate: "\u0432\u0438\u0431\u0440\u0430\u0446\u0438\u044f",
        service: "\u0441\u043b\u0443\u0436\u0438\u0442\u044c",
        settings: "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438",
        default: "default",
        self: "self",
        level: "lv",
        main: "main",
        next: "\u0421\u043b\u0435\u0434.",
        again: "\u0435\u0449\u0451 \u0440\u0430\u0437",
        replay: "\u043f\u043e\u0432\u0442\u043e\u0440\u0435\u043d\u0438\u0435",
        defeat: "\u043f\u043e\u0440\u0430\u0437\u0438\u0442\u044c",
        success: "\u0443\u0441\u043f\u0435\u0445",
        reviveByVideo: "reviveByVideo",
        reviveByShare: "reviveByShare",
        skip: "skip",
        detailForRevive: "\u9a6c\u4e0a\u5c31\u8981\u901a\u5173\u4e86\uff0c\u4e0d\u8981\u653e\u5f03\uff01",
        hasSignedToady: "Signed",
        loadingDetail: "\u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0430...",
        rewardTitleCommon: "\u043d\u0430\u0433\u0440\u0430\u0434\u0430",
        rewardTitleOnOver: "\u043d\u0430\u0433\u0440\u0430\u0434\u0430",
        signInPreview: "\u043d\u0430\u0433\u0440\u0430\u0434\u0430",
        multiGet: "{0} \u0441\u043e\u0431\u0438\u0440\u0430\u0442\u044c",
        userLadder: "\u0441\u043e\u0440\u0442",
        worldLadder: "\u0441\u043e\u0440\u0442",
        todayLadder: "\u0441\u043e\u0440\u0442",
        groupLadder: "\u0441\u043e\u0440\u0442",
        appListTitle: "\u0441\u043e\u0440\u0442",
        task1: "\u0443\u0431\u0438\u0442\u044c  ",
        task2: "Watch Video",
        task3: "\u0441\u043e\u0431\u0438\u0440\u0430\u0442\u044c",
        task4: "\u0431\u0435\u0437 \u0443\u0449\u0435\u0440\u0431\u0430",
        task5: "\u041d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e",
        task6: "\u0432\u044b\u043f\u043e\u043b\u043d\u0438\u0442\u044c",
        task7: "\u0443\u0431\u0438\u0442\u044c \u043f\u043e\u0441\u043b\u0435\u0434\u043d\u0438\u0439"
      }
    };
    cc._RF.pop();
  }, {} ],
  ReviveUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4e38fmpr59BF5xPnCQpVuAT", "ReviveUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      init: function init() {
        this.timerLabel = this.node.getChildByName("TimerLabel").getComponent(cc.Label), 
        this.progressBar = this.node.getChildByName("ProgressBar").getComponent(cc.ProgressBar), 
        this.reviveBtnNode = this.node.getChildByName("Share"), this.isReviving = !1, this.setTimer(), 
        this.registerEvents(), this.obstructFunc(), this.getComponentInChildren("ObstructTouch").init();
        window.HUHU_showInterstitialAd();
        console.log("=====init revive===");
      },
      obstructFunc: function obstructFunc() {
        this.reviveBtnNode.active = !!kk.ServerApi.bannerSwitch;
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.SHARE_PERSONAL, this.onShareOver, this), MessageHandler.add(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.SHARE_PERSONAL, this.onShareOver, this), MessageHandler.remove(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this);
      },
      share: function share() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), kk.sdkBridger.share(kk.Enum.SdkTag.SHARE_REVIVE), 
        this.isReviving = !0;
      },
      onShareOver: function onShareOver() {
        this.isReviving = !1;
        var e = Array.prototype.slice.call(arguments);
        e[0] === kk.Enum.SdkTag.SHARE_REVIVE && (this.getReward(), kk.Client.recordSuccessShare(e[1], 5));
      },
      watchVideo: function watchVideo() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click");
        cc.vv.NativeUtils.showVideoAd(0, function() {
          MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, kk.Enum.SdkTag.VIDEO_REVIVE, true);
        });
        this.isReviving = !0;
      },
      onVideoOver: function onVideoOver() {
        this.isReviving = !1;
        var e = Array.prototype.slice.call(arguments);
        e[0] === kk.Enum.SdkTag.VIDEO_REVIVE && e[1] && this.getReward();
      },
      getReward: function getReward() {
        kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("label_text.revive_success"), !0, 600), 
        kk.levelManager.revive(), this.close();
      },
      setTimer: function setTimer() {
        var e = 100;
        this.progressBar.progress = 1, this.delayTimer = setInterval(function() {
          if (!this.isReviving) {
            if (--e < 0) return this.progressBar.progress = 0, window.clearInterval(this.delayTimer), 
            void this.closeWithDefeat();
            e % 10 == 0 && (this.timerLabel.string = Math.floor(e / 10).toString()), this.progressBar.progress = .01 * e;
          }
        }.bind(this), 100);
      },
      clearTimer: function clearTimer() {
        (this.delayTimer || 0 === this.delayTimer) && window.clearInterval(this.delayTimer);
      },
      closeWithDefeat: function closeWithDefeat() {
        this.close(), kk.GuiSystem.add("DefeatUI");
      },
      onClose: function onClose() {
        window.HUHU_showInterstitialAd();
        console.log("=====colse revive===");
        kk.sdkBridger.hideBanner(kk.sdkBridger.bannerForOver), this.clearTimer(), this.unRegisterEvents(), 
        this._super();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  RewardUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "88efakwDx9LLowKV5SwtmaC", "RewardUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      properties: {
        _rewardType: 0,
        _rewardValue: 0,
        _resultValue: 0,
        _multiCount: 1,
        _canTouch: !0,
        _needNumItr: !0
      },
      init: function init() {
        this._numLabel = this.node.getChildByName("Num").getComponent(cc.Label), this.registerEvents(), 
        this.getComponentInChildren("ObstructTouch").init();
      },
      setData: function setData(e, t, i) {
        this._rewardType = e, this._rewardValue = t, this._multiCount = i || 3, this._resultValue = t, 
        this._numLabel.string = this._rewardValue.toString();
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this), MessageHandler.add(kk.Enum.MsgKey.GUI_REWARD_REWARD, this.onSaveGoldBack, this);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this), MessageHandler.remove(kk.Enum.MsgKey.GUI_REWARD_REWARD, this.onSaveGoldBack, this);
      },
      watchVideo: function watchVideo() {
        if (this._canTouch) {
          kk.AudioSystem.play(kk.AudioName.GUI, "click");
          cc.vv.NativeUtils.showVideoAd(0, function() {
            MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, kk.Enum.SdkTag.MULTI_EARN_GEM, true);
            kk.GuiSystem.addTips("Reward X3");
          });
        }
      },
      onVideoOver: function onVideoOver() {
        console.log("==onVideoOver");
        var e = Array.prototype.slice.call(arguments);
        e[0] === kk.Enum.SdkTag.MULTI_EARN_GEM && e[1] && this.getVideoReward();
      },
      getVideoReward: function getVideoReward() {
        if (null !== this._rewardType && this._rewardValue && this._multiCount) {
          var e = this._rewardValue * (this._multiCount - 1);
          this._resultValue = this._rewardValue * this._multiCount, kk.Client.saveUser(kk.ServerApi.Address.POST_GET_GOLD, "1", kk.Config.skinVideoReward, function(t) {
            t && 0 === t.code ? (MessageHandler.dispatch(kk.Enum.MsgKey.GUI_REWARD_REWARD), 
            kk.curUser.addGold(e)) : kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("error_text.response_data_error"), !1, 600);
          }.bind(this));
        }
      },
      onSaveGoldBack: function onSaveGoldBack() {
        this._numLabel.string = this._resultValue.toString(), this.collect();
      },
      collect: function collect() {
        this._canTouch && (this._canTouch = !1, kk.AudioSystem.play(kk.AudioName.GUI, "click"), 
        this._needNumItr ? kk.AnimLib.numberIterator(this._numLabel.node, this._resultValue, 0, 2, this.close.bind(this)) : this.close());
      },
      onClose: function onClose() {
        kk.sdkBridger.hideBanner(kk.sdkBridger.bannerForOver), this.unRegisterEvents(), 
        this._super();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  Root: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "1be29JEbA5NzqPWywBGmIJp", "Root");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      start: function start() {
        cc.game.addPersistRootNode(this.node);
      }
    });
    cc._RF.pop();
  }, {} ],
  Sample: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "133c0unEbBPTKNlsWUMnBFG", "Sample");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        sampleSprite: cc.Sprite,
        gouPre: cc.Prefab
      },
      scaling: function scaling() {
        var actionBy = cc.scaleBy(.1, .1);
        var actionBy2 = cc.scaleBy(.5, 10, 10);
        this.node.runAction(cc.sequence(actionBy, actionBy2));
      },
      showImages: function showImages(args, maxNumber) {
        this.args = args;
        this.maxNumber = maxNumber;
        cc.vv.uiUtils.loadLocalImage("images0/picture" + args, this.sampleSprite);
      },
      onLoad: function onLoad() {
        this.scaling();
        var self = this;
        this.node.on(cc.Node.EventType.TOUCH_START, function(event) {
          var addGou = cc.instantiate(self.gouPre);
          self.node.addChild(addGou);
          if (Globals.arr.length == Globals.clickArr.length) {
            Globals.arr.push(self.args);
            console.log(Globals.arr);
            if (Globals.arr.length == self.maxNumber) {
              console.log("\u8fc7\u5173\u6210\u529f");
              Globals.passing = true;
              Globals.arr = [];
              Globals.clickArr = [];
              Globals.isTouch = 0;
            }
            var addGou = cc.instantiate(self.gouPre);
            self.node.addChild(addGou);
            cc.find("Canvas").emit("isTouch", true);
            Globals.changeImages = false;
          } else {
            Globals.changeImages = true;
            if (Globals.isTouch >= 0) {
              Globals.clickArr[Globals.isTouch] = self.args;
              if (Globals.clickArr[Globals.isTouch] == Globals.arr[Globals.isTouch]) console.log("\u6570\u636e\u4e00\u81f4", Globals.clickArr, Globals.arr); else {
                console.log("\u6570\u636e\u4e0d\u4e00\u81f4", Globals.clickArr, Globals.arr);
                cc.find("Canvas").emit("over", self.node);
              }
              Globals.isTouch += 1;
            }
          }
          cc.find("Canvas").emit("times", true);
        });
      },
      start: function start() {}
    });
    cc._RF.pop();
  }, {} ],
  SceneData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "eab1b89cExFy54VbohqzCaK", "SceneData");
    "use strict";
    var n = require("SerializableData");
    cc.Class({
      extends: n,
      properties: {
        id: 0,
        players: [],
        posX: 0,
        posY: 0
      }
    });
    cc._RF.pop();
  }, {
    SerializableData: "SerializableData"
  } ],
  SceneObj: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "cbdbfLlh3hIprp/MuIh9CU5", "SceneObj");
    "use strict";
    function n(e) {
      if (Array.isArray(e)) {
        for (var t = 0, i = Array(e.length); t < e.length; t++) i[t] = e[t];
        return i;
      }
      return Array.from(e);
    }
    var s = cc.Class({
      extends: cc.Component,
      properties: {
        speed: 50,
        model: null,
        _angle: 0,
        _moveDir: cc.Vec2.ZERO
      },
      isPlayer: function isPlayer() {
        return !1;
      },
      isMonster: function isMonster() {
        return !1;
      },
      isBullet: function isBullet() {
        return !1;
      },
      init: function init(e) {
        this.setDefaultComps(), this.setDefaultProps(), this.registerEvents(), this.updateSkin(), 
        this.switchAngle(this._angle), this.switchState(kk.Enum.RoleState.IIdle);
      },
      onDestroy: function onDestroy() {
        this.unregisterEvents();
      },
      setDefaultComps: function setDefaultComps() {
        this.model = this.node.getChildByName("Model");
      },
      setDefaultProps: function setDefaultProps() {},
      updateSkin: function updateSkin() {},
      switchSkin: function switchSkin(e) {},
      switchState: function switchState(e) {},
      switchAngle: function switchAngle(e) {},
      getStraightDirByAngle: function getStraightDirByAngle(e) {
        return Math.round(Utils.Angle.toPlus(e) / 90) % 4 * 2;
      },
      getReasonableDir: function getReasonableDir(e, t, i) {
        var n = [ (t + 2) % 8, (t + 6) % 8, (t + 4) % 8 ], s = void 0;
        return s = n.splice(Math.randomInt(2), 1), kk.curScene.getNextGridOnDir(s, e[0], e[1], i) ? s : (s = n.shift(), 
        kk.curScene.getNextGridOnDir(s, e[0], e[1], i) ? s : (s = n.shift(), kk.curScene.getNextGridOnDir(s, e[0], e[1], i) ? s : t));
      },
      getDirByAngle: function getDirByAngle(e) {
        return Math.round(Utils.Angle.toPlus(e) / 45) % 8;
      },
      getAngleByDir: function getAngleByDir(e) {
        return 45 * e;
      },
      registerEvents: function registerEvents() {},
      unregisterEvents: function unregisterEvents() {},
      startMove: function startMove() {},
      move: function move() {},
      stopMove: function stopMove() {},
      startRun: function startRun() {},
      run: function run() {},
      stopRun: function stopRun() {},
      contact: function contact(e) {},
      follow: function follow(e) {},
      interact: function interact(e) {
        this.isIntersects(e) ? this.contact(e) : this.look(e);
      },
      look: function look(e) {},
      search: function search(e) {},
      attack: function attack() {},
      hurt: function hurt() {},
      die: function die() {},
      isIntersects: function isIntersects(e) {
        return e.node.getBoundingBox().intersects(this.node.getBoundingBox());
      },
      execute: function execute(e) {
        this[e] && "function" == typeof this[e] && this[e].apply(this, n(Array.prototype.slice.call(arguments, 1)));
      }
    });
    s.getClassByObjType = function(t) {
      return require(t) || s;
    };
    cc._RF.pop();
  }, {} ],
  SceneUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a4e73znQmVJgI7wryDdBRTh", "SceneUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      properties: {
        touchStartTime: 0,
        touchInternal: 500
      },
      init: function init() {
        this.monsterCountLabel = cc.find("TopLayer/Num", this.node).getComponent(cc.Label), 
        this.registerEvents(), this.alignTimer = setTimeout(this.alignPos.bind(this), 10);
      },
      alignPos: function alignPos() {
        if (kk.isSprs()) {
          var e = this.node.getChildByName("TopLayer");
          e.getComponent(cc.Widget).updateAlignment(), e.setPosition(e.position.x, e.position.y - 60);
        }
      },
      updateData: function updateData() {
        this.updateMonsterCount();
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this), MessageHandler.add(kk.Enum.MsgKey.LEVEL_KILL_MONSTER, this.updateMonsterCount, this), 
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this, !0), this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this, !0);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this), MessageHandler.remove(kk.Enum.MsgKey.LEVEL_KILL_MONSTER, this.updateMonsterCount, this), 
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this, !0), this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this, !0);
      },
      onTouchStart: function onTouchStart(e) {
        kk.Game.isActive() && this.canTouch() && (MessageHandler.dispatch(kk.Enum.MsgKey.TOUCH_START, e), 
        this.setTouchStartTime());
      },
      onTouchMove: function onTouchMove(e) {
        kk.Game.isActive() && this.canTouch() && (MessageHandler.dispatch(kk.Enum.MsgKey.TOUCH_START, e), 
        this.setTouchStartTime());
      },
      canTouch: function canTouch() {
        return Date.now() > this.touchStartTime;
      },
      setTouchStartTime: function setTouchStartTime() {
        this.touchStartTime = Date.now() + this.touchInternal;
      },
      getTouchStartTime: function getTouchStartTime() {
        return this.touchStartTime;
      },
      updateMonsterCount: function updateMonsterCount() {
        this.monsterCountLabel.string = kk.levelManager._killMonsterCount + ":" + kk.curScene.monsterCount;
      },
      watchVideo: function watchVideo() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), kk.levelManager.switchState(kk.Enum.GameState.PAUSE);
        cc.vv.NativeUtils.showVideoAd(0, function() {
          MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, kk.Enum.SdkTag.VIDEO_SCENE_INVINCIBLE, true);
        });
      },
      onVideoOver: function onVideoOver() {
        var e = Array.prototype.slice.call(arguments);
        e[0] === kk.Enum.SdkTag.VIDEO_SCENE_INVINCIBLE && (e[1] && this.getReward(), kk.levelManager.switchState(kk.Enum.GameState.RESUME));
      },
      getReward: function getReward() {
        kk.levelManager.switchState(kk.Enum.GameState.RESUME);
        var e = kk.levelManager.getCurPlayer();
        e && (kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("label_text.golden_success"), !0, 600), 
        e.addInvincible());
      },
      clearAlignTimer: function clearAlignTimer() {
        Utils.isNone(this.alignTimer) || clearTimeout(this.alignTimer);
      },
      onClose: function onClose() {
        this.clearAlignTimer(), this.unRegisterEvents(), this._super();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  Scene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "efcda8LWv1CEqByUZVFUQ16", "Scene");
    "use strict";
    var n = require("GameObject"), s = require("SceneObj");
    cc.Class({
      extends: n,
      properties: {
        aStar: null,
        model: null,
        blockData: [],
        mapOriginX: 0,
        mapOriginY: 0,
        columns: 0,
        rows: 0,
        mapGrids: [],
        bulletPool: null,
        monsterCount: 0,
        objs: {
          default: {},
          visible: !1
        },
        gridObjMap: {
          default: {},
          visible: !1
        }
      },
      initModel: function initModel() {
        var e = kk.AssetLib.retainAsset("prefab/Scene", cc.Prefab);
        return e ? this.initSource(e) : this.createSource(), kk.Canvas().addChild(this.node), 
        this.node.setContentSize(cc.winSize), this.node;
      },
      createSource: function createSource() {
        for (var e in this.node = new cc.Node("Scene"), kk.Enum.SceneLayer) kk.Enum.SceneLayer.hasOwnProperty(e) && this.node.addChild(new cc.Node(e));
      },
      initSource: function initSource(e) {
        this.node = cc.instantiate(e);
      },
      getLayerName: function getLayerName(e) {
        var t = kk.Enum.SceneLayer.OBJ;
        switch (e) {
         case kk.Enum.ObjType.FLOOR:
          t = kk.Enum.SceneLayer.FLOOR;
          break;

         case kk.Enum.ObjType.PROJECTION:
          t = kk.Enum.SceneLayer.PROJECTION;
          break;

         case kk.Enum.ObjType.SHADOW:
          t = kk.Enum.SceneLayer.SHADOW;
          break;

         case kk.Enum.ObjType.BULLET:
         case kk.Enum.ObjType.TAG:
          t = kk.Enum.SceneLayer.TAG;
          break;

         case kk.Enum.ObjType.MONSTER:
         case kk.Enum.ObjType.PLAYER:
          t = kk.Enum.SceneLayer.ROLE;
          break;

         case kk.Enum.ObjType.OBJ:
          t = kk.Enum.SceneLayer.OBJ;
          break;

         default:
          t = kk.Enum.SceneLayer.FORE;
        }
        return t;
      },
      getLayerNode: function getLayerNode(e) {
        return this.node.getChildByName(this.getLayerName(e));
      },
      getSightGraphics: function getSightGraphics() {
        return this.node.getChildByName("sight").getComponent(cc.Mask)._graphics;
      },
      initProjectionGraphics: function initProjectionGraphics() {
        var e = this.getLayerNode(kk.Enum.ObjType.PROJECTION);
        this.projectionTracer = kk.GlSystem.add(kk.Enum.PathKey.PROJECTION, 5, cc.Color.BLACK, kk.Config.projectionColor), 
        this.shadowTracer = kk.GlSystem.add(kk.Enum.PathKey.PROJECTION, 5, cc.Color.BLACK, cc.Color.BLACK), 
        this.projectionTracer.node.setParent(e), this.projectionTracer.node.setPosition(0, 0), 
        this.shadowTracer.node.setParent(e), this.shadowTracer.node.setPosition(0, 0);
      },
      initGridsOfMap: function initGridsOfMap(e, t, i) {
        this.mapGrids = [], this.blockData = [], this.columns = e.columns, this.rows = e.rows, 
        this.mapOriginX = -this.columns * kk.Config.gridWidth / 2, this.mapOriginY = this.rows / 2 * kk.Config.gridHeight;
        for (var n = 0, s = 0; s < this.rows; s++) {
          for (var o = [], a = 0; a < this.columns; a++) {
            var r = this.gridToIndex(a, s), c = this.getTileData(i, t[r]);
            (n = c.state) ? this.addBlock(kk.Enum.ObjType.OBJ, c.source, a, s, t, i) : this.addFloor(c.source, a, s), 
            o.push(n), this.blockData[r] = n;
          }
          this.mapGrids.push(o);
        }
        e = null, t = null, i = null;
      },
      initAStar: function initAStar() {
        this.aStar = new AStar(this.blockData, this.rows, this.columns, kk.Config.gridWidth, kk.Config.gridHeight, this.mapOriginX, this.mapOriginY);
      },
      initBulletPool: function initBulletPool() {
        kk.AssetLib.loadAsset("prefab/Bullet", cc.Prefab, function(e) {
          var t = cc.instantiate(e);
          t.setParent(this.getLayerNode(kk.Enum.ObjType.BULLET)), this.bulletPool = new NodePool(t, 50);
        }, null, this);
      },
      getHeight: function getHeight() {
        return this.rows * kk.Config.gridHeight;
      },
      getWidth: function getWidth() {
        return this.columns * kk.Config.gridWidth;
      },
      gridToPos: function gridToPos(e, t) {
        var i = e * kk.Config.gridWidth + this.mapOriginX + kk.Config.gridWidth / 2, n = this.mapOriginY - t * kk.Config.gridHeight - kk.Config.gridHeight / 2;
        return new cc.Vec2(i, n);
      },
      posToGrid: function posToGrid(e) {
        return [ Math.floor((e.x - this.mapOriginX) / kk.Config.gridWidth), Math.floor((this.mapOriginY - e.y) / kk.Config.gridHeight) ];
      },
      gridToPosX: function gridToPosX(e) {
        return e * kk.Config.gridWidth + this.mapOriginX + kk.Config.gridWidth / 2;
      },
      gridToPosY: function gridToPosY(e) {
        return this.mapOriginY - e * kk.Config.gridHeight - kk.Config.gridHeight / 2;
      },
      posXToGrid: function posXToGrid(e) {
        return Math.floor((e - this.mapOriginX) / kk.Config.gridWidth);
      },
      posYToGrid: function posYToGrid(e) {
        return Math.floor((this.mapOriginY - e) / kk.Config.gridHeight);
      },
      gridToIndex: function gridToIndex(e, t) {
        return e + t * this.columns;
      },
      getTileData: function getTileData(e, t) {
        return t && e.hasOwnProperty(t) ? e[t] : null;
      },
      getNextGridOnDir: function getNextGridOnDir(e, t, i, n) {
        var s = [];
        switch (e) {
         case Utils.Direction.EightDir.LEFT:
          t -= 1;
          break;

         case Utils.Direction.EightDir.RIGHT:
          t += 1;
          break;

         case Utils.Direction.EightDir.UP:
          if (n && i < n) return null;
          i -= 1;
          break;

         case Utils.Direction.EightDir.DOWN:
          i += 1;
          break;

         case Utils.Direction.EightDir.LEFT_DOWN:
          s.push([ t - 1, i ]), s.push([ t, i + 1 ]), t -= 1, i += 1;
          break;

         case Utils.Direction.EightDir.RIGHT_UP:
          s.push([ t + 1, i ]), s.push([ t, i - 1 ]), t += 1, i -= 1;
          break;

         case Utils.Direction.EightDir.LEFT_UP:
          s.push([ t - 1, i ]), s.push([ t, i - 1 ]), t -= 1, i -= 1;
          break;

         case Utils.Direction.EightDir.RIGHT_DOWN:
          s.push([ t + 1, i ]), s.push([ t, i + 1 ]), t += 1, i += 1;
          break;

         default:
          return null;
        }
        if (!this.isMovableGrid(t, i)) return null;
        for (var o = void 0, a = void 0, r = 0, c = 0, u = s.length; c < u; c++) o = s[c][0], 
        a = s[c][1], this.isMovableGrid(o, a) && r++;
        return s = null, r >= 2 ? null : [ t, i ];
      },
      getEndGridOnDir: function getEndGridOnDir(e, t, i) {
        for (var n = [ t, i ], s = this.getNextGridOnDir(e, t, i); s; ) n = [ s[0], s[1] ], 
        s = this.getNextGridOnDir(e, n[0], n[1]);
        return n[0] !== t && n[1] !== i ? n : null;
      },
      isMovableGrid: function isMovableGrid(e, t) {
        return this.getGridState(e, t) === kk.Enum.BlockType.MOVABLE;
      },
      getGridState: function getGridState(e, t) {
        return e < 0 || e >= this.columns ? kk.Enum.BlockType.UNMOVABLE : t < 0 || t >= this.rows ? kk.Enum.BlockType.UNMOVABLE : this.mapGrids[t][e];
      },
      setGridState: function setGridState(e, t, i) {
        null !== this.getGridState(e, t) && (this.mapGrids[t][e] = i);
      },
      findNearestIndex: function findNearestIndex(e, t) {
        for (var i = void 0, n = void 0, s = void 0, o = null, a = 0; a < 8; a++) if (n = e + (i = Utils.Direction.dirToDeltaVector(a))[0], 
        s = t + i[1], kk.curScene.isMovableGrid(n, s)) {
          o = [ n, s ];
          break;
        }
        return o;
      },
      initObjsOfMap: function initObjsOfMap(e) {
        this.initPlayer(e.player), this.initMonsters(e.monsters);
      },
      initPlayer: function initPlayer(e) {
        e && this.createObj(kk.Enum.ObjType.PLAYER, e);
      },
      initMonsters: function initMonsters(e) {
        if (e) {
          var t = kk.curUser.getCurLevel(), i = 0, n = 0, s = null, o = void 0;
          this.monsterCount = this.getMonsterCount(t);
          for (var a = 0; a < this.monsterCount; a++) {
            for (n = Math.randomRange(1, this.columns - 1), i = Math.randomRange(1, this.rows / 2), 
            o = 0; !this.isMovableGrid(n, i) && o < 5; ) (s = this.findNearestIndex(n, i)) ? (n = s[0], 
            i = s[1]) : (n = Math.randomRange(1, this.columns - 1), i = Math.randomRange(kk.Config.filterNum, this.rows / 2)), 
            o++;
            this.createObj(kk.Enum.ObjType.MONSTER, {
              model: "Monster",
              row: i,
              column: n
            });
          }
        }
      },
      getMonsterCount: function getMonsterCount(e) {
        return e <= 5 ? 3 : e <= 8 ? 4 : e <= 12 ? 5 : e <= 18 ? 6 : e <= 25 ? 7 : e <= 32 ? 8 : 33 === e ? 9 : [ 5, 5, 7, 9 ][(e - 34) % 4];
      },
      setObjByGrid: function setObjByGrid(e, t, i) {
        this.gridObjMap["pos" + e + t] = i;
      },
      getObjByGrid: function getObjByGrid(e, t) {
        return this.gridObjMap["pos" + e + t];
      },
      removeObjByGrid: function removeObjByGrid(e, t) {
        delete this.gridObjMap["pos" + e + t];
      },
      createObj: function createObj(e, t) {
        var i = "prefab/".concat(t.model || "Monster");
        kk.AssetLib.loadAsset(i, cc.Prefab, function(i) {
          this.addObj(e, t, i);
        }, null, this);
      },
      addObj: function addObj(e, t, i) {
        var n = s.getClassByObjType(e), o = cc.instantiate(i), a = o.getComponent(n), r = this.getObjs(e), c = this.getLayerNode(e), u = this.gridToPos(t.column, t.row);
        "Player" == e && -840 == u.y && (u.y = -680);
        o.setParent(c), o.setPosition(u), r.push(a), a.init(t);
      },
      addBullet: function addBullet(e, t) {
        var i = this.bulletPool.add(NodePool.Type.RECYCLE);
        if (i) {
          var n = i.getOrAddComponent("Bullet"), s = t.node.position.add(new cc.Vec2(Math.randomPlusMinus() * Math.randomRange(0, 30), Math.randomPlusMinus() * Math.randomRange(0, 30)));
          this.getObjs(kk.Enum.ObjType.BULLET).push(n), i.setPosition(e.node.position), n._angle = Utils.Angle.between(e.node.position, s), 
          n.init();
        }
      },
      addFloor: function addFloor(e, t, i) {
        var n = this.getLayerNode(kk.Enum.ObjType.FLOOR), s = new cc.Node(kk.Enum.SceneLayer.FLOOR), o = this.gridToPos(t, i), a = s.addComponent(cc.Sprite);
        s.setParent(n), s.setPosition(o), s.setContentSize(kk.Config.gridWidth, kk.Config.gridHeight), 
        a.sizeMode = cc.Sprite.SizeMode.CUSTOM, kk.AssetLib.setSprite(s, e, "tiles");
      },
      addBlock: function addBlock(e, t, i, n, s, o) {
        var a = this.gridToPos(i, n);
        this.addPanel(e, t, a), this.drawProjection(i, n, a, s, o), this.addShadow(i, n, a, s, o);
      },
      addPanel: function addPanel(e, t, i) {
        var n = this.getLayerNode(e), s = new cc.Node("obj"), o = s.addComponent(cc.Sprite);
        return s.setParent(n), s.setPosition(i), s.setContentSize(kk.Config.gridWidth, kk.Config.gridHeight), 
        o.sizeMode = cc.Sprite.SizeMode.CUSTOM, kk.AssetLib.setSprite(s, t, "tiles"), s;
      },
      drawProjection: function drawProjection(e, t, i, n, s) {
        var o = void 0, a = void 0, r = void 0, c = void 0;
        if (t >= this.rows - 1 ? o = 1 : (r = this.gridToIndex(e, t + 1), o = (c = this.getTileData(s, n[r])) ? c.state : 1), 
        e <= 1 ? a = 1 : (r = this.gridToIndex(e - 1, t), a = (c = this.getTileData(s, n[r])) ? c.state : 1), 
        !o || !a) {
          for (var u = void 0, d = void 0, l = void 0, h = void 0, k = void 0, g = 0, p = (k = o ? [ [ -1, 0 ], [ -.5, .5 ], [ -.5, -.5 ], [ -1, -1 ] ] : a ? [ [ -.5, -.5 ], [ .5, -.5 ], [ 0, -1 ], [ -1, -1 ] ] : [ [ -1, 0 ], [ -.5, .5 ], [ .5, .5 ], [ .5, -.5 ], [ 0, -1 ], [ -1, -1 ] ]).length; g < p; g++) u = k[g][0], 
          d = k[g][1], l = i.x + u * kk.Config.gridWidth, h = i.y + d * kk.Config.gridHeight, 
          0 === g ? this.projectionTracer.moveTo(l, h) : this.projectionTracer.lineTo(l, h);
          this.projectionTracer.close(), this.projectionTracer.fill();
        }
      },
      addShadow: function addShadow(e, t, i, n, s) {
        var o = 0, a = 0, r = [ [ -.6, .54 ], [ .54, .54 ], [ .54, -.65 ], [ -.6, -.65 ] ], c = this.gridToIndex(e, t), u = this.getTileData(s, n[c]), d = u.color ? u.color : "#0d0f0e";
        this.shadowTracer.fillColor = cc.Color.WHITE.fromHEX(d);
        for (var l = 0; l < r.length; l++) o = i.x + kk.Config.gridWidth * r[l][0], a = i.y + kk.Config.gridHeight * r[l][1], 
        0 === l ? this.shadowTracer.moveTo(o, a) : this.shadowTracer.lineTo(o, a);
        this.shadowTracer.close(), this.shadowTracer.fill();
      },
      getObjs: function getObjs(e) {
        return this.objs[e] = this.objs[e] || [];
      },
      removeObj: function removeObj(e, t) {
        var i = this.getObjs(e), n = i.indexOf(t);
        n < 0 || i.splice(n, 1);
      },
      clearObjs: function clearObjs(e) {
        this.objs[e] = [];
      },
      release: function release() {
        this.objs = {}, this.node.destroy(), this.aStar = null;
      }
    });
    cc._RF.pop();
  }, {
    GameObject: "GameObject",
    SceneObj: "SceneObj"
  } ],
  SdkBridger: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "3ef7apvi2ZLiLoCjjmrLuQy", "SdkBridger");
    "use strict";
    var n = cc.Class({
      properties: {
        videoPlaying: !1,
        isWaiting: !1,
        waitingTag: null,
        shareTag: null,
        interTag: "default"
      },
      login: function login(e) {
        cc.log("\u5f00\u59cb\u767b\u9646"), this.loginCB("true", "", "testUser", 0, 0);
      },
      loginCB: function loginCB(e, t, i, n, s) {
        var o = {
          token: t || "",
          name: i || "",
          sex: n,
          channel: s
        };
        MessageHandler.dispatch(kk.Enum.MsgKey.SDK_GAME_LOGIN, "true" === e, o);
      },
      postDesignEvent: function postDesignEvent(e, t, i) {},
      exchange: function exchange(e) {
        console.log("\u6b64\u5e73\u53f0\u4e0d\u652f\u6301\u5151\u6362\uff0c\u76f4\u63a5\u8fd4\u56de\u6210\u529f"), 
        this.exchangeCB(e, Date.now() + kk.Config.vipDuration, "true");
      },
      exchangeCB: function exchangeCB(e, t, i) {
        MessageHandler.dispatch(kk.Enum.MsgKey.SKU_INGOT, e, t, "true" === i);
      },
      restoreExchange: function restoreExchange(e) {
        console.log("\u6b64\u5e73\u53f0\u4e0d\u652f\u6301\u6062\u590d\u6062\u590d\u4ea4\u6613\uff0c\u76f4\u63a5\u8fd4\u56de\u6210\u529f"), 
        this.restoreExchangeCB(e, Date.now() + kk.Config.vipDuration, "true");
      },
      restoreExchangeCB: function restoreExchangeCB(e, t, i) {
        MessageHandler.dispatch(kk.Enum.MsgKey.SKU_RESTORE, e, t, "true" === i);
      },
      restoreAllExchangeCB: function restoreAllExchangeCB(e) {
        for (var t = e.split(","), i = 0, n = t.length; i < n; i++) this.restoreExchangeCB(t[i], Date.now(), "true");
      },
      initVideo: function initVideo() {
        console.log("\u6b64\u5e73\u53f0\u4e0d\u652f\u6301\u5e7f\u544a\u64ad\u653e");
      },
      loadVideo: function loadVideo() {},
      showVideo: function showVideo(e) {
        console.log("\u6b64\u5e73\u53f0\u4e0d\u652f\u6301\u5e7f\u544a\u64ad\u653e"), MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, e, !0);
      },
      showInter: function showInter(e) {
        console.log("\u6b64\u5e73\u53f0\u4e0d\u652f\u6301\u5e7f\u544a\u64ad\u653e"), MessageHandler.dispatch(kk.Enum.MsgKey.ADS_INTER, e, !0);
      },
      videoLoadCB: function videoLoadCB(e) {},
      videoShowCB: function videoShowCB(e) {},
      interLoadCB: function interLoadCB(e) {},
      interShowCB: function interShowCB(e) {},
      initBanner: function initBanner() {},
      showBanner: function showBanner() {},
      hideBanner: function hideBanner() {},
      destroyBanner: function destroyBanner() {},
      saveOpenData: function saveOpenData() {},
      vibrateStart: function vibrateStart() {},
      vibrateCancel: function vibrateCancel() {},
      isVibrateClosed: function isVibrateClosed() {
        return this.loadVibrateState();
      },
      switchVibrateState: function switchVibrateState() {
        var e = this.loadVibrateState();
        return e = (e + 1) % 2, cc.sys.localStorage.setItem("vibrate", e), e;
      },
      loadVibrateState: function loadVibrateState() {
        var e = cc.sys.localStorage.getItem("vibrate"), t = 0;
        if (!e) return t;
        try {
          return JSON.parse(e);
        } catch (e) {
          return t;
        }
      },
      navigateToMiniProgram: function navigateToMiniProgram() {
        console.log("\u6253\u5f00\u8df3\u8f6c\uff0c\u6b64\u5e73\u53f0\u4e0d\u652f\u6301");
      },
      openCustomService: function openCustomService() {
        console.log("\u6253\u5f00\u5ba2\u670d\uff0c\u6b64\u5e73\u53f0\u4e0d\u652f\u6301");
      },
      showSystemWaiting: function showSystemWaiting(e, t) {},
      closeSystemWaiting: function closeSystemWaiting() {},
      showSystemAlert: function showSystemAlert(e, t) {},
      showSystemToast: function showSystemToast(e) {},
      showSystemNotice: function showSystemNotice(e, t, i, n, s) {
        console.log.apply(kk, arguments);
      },
      initShare: function initShare() {
        console.log("\u6b64\u5e73\u53f0\u4e0d\u652f\u6301\u5206\u4eab");
      },
      share: function share(e) {},
      onShareOver: function onShareOver(e) {},
      reflectNative: function reflectNative() {},
      isSystemNetAvailable: function isSystemNetAvailable() {
        return !1;
      },
      isVideoReady: function isVideoReady() {
        return !1;
      },
      isInterReady: function isInterReady() {
        return !1;
      },
      isVideoLoading: function isVideoLoading() {
        return !1;
      },
      isSupportPlatform: function isSupportPlatform() {
        return !1;
      }
    });
    n.init = function() {
      kk.sdkBridger = new n();
    }, module.exports = n;
    cc._RF.pop();
  }, {} ],
  SerializableData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2a0d2NwMIZLebyJJ9SZPmCc", "SerializableData");
    "use strict";
    cc.Class({
      __ctor__: function __ctor__(e) {
        this.initialize(e);
      },
      initialize: function initialize(e) {
        if (e) {
          for (var t in this) this.hasOwnProperty(t) && "function" != typeof this[t] && e.hasOwnProperty(t) && "function" != typeof e[t] && (this[t] = e[t]);
          e = null;
        }
      },
      unSerialize: function unSerialize() {
        var e = {};
        for (var t in this) this.hasOwnProperty(t) && "function" != typeof this[t] && (e[t] = this[t]);
        return e;
      },
      serialize: function serialize() {
        var e = {};
        for (var t in this) this.hasOwnProperty(t) && "function" != typeof this[t] && (e[t] = this[t]);
        return JSON.stringify(e);
      }
    });
    cc._RF.pop();
  }, {} ],
  ServerApi: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "ed3ccZlpLhJRo3OZMDoFnuT", "ServerApi");
    "use strict";
    var n = {
      adConfigUrl: "",
      serverUrl: "",
      Address: {
        LOGIN: "loginInit",
        LOGIN_AUTHOR: "authorizedLogin",
        CLICK_APP: "clickWxapp",
        CLICK_SHARE: "clickShare",
        AND_RECORD_SHARE: "recordShare",
        ANA_WATCH_VIDEO: "viewVideo",
        GET_RANK_TODAY: "todayRanking",
        GET_RANK_WORLD: "worldRanking",
        GET_RANK_USER: "myRank",
        GET_CONFIG: "getConfig",
        GET_SHARE_DATA: "shareData",
        GET_USER_INFO: "userInfo",
        GET_ROBOTS_INFO: "robots",
        GET_TASK: "getTask",
        POST_GET_GOLD: "getGold",
        POST_GAME_OVER: "gameover",
        POST_SKIN_UNLOCK: "unlockSkin",
        POST_SKIN_SWITCH: "switchSkin",
        POST_SIGN_IN: "todaySignin",
        POST_TASK_CREATE: "createTask",
        POST_TASK_UPDATE: "updateTask",
        POST_TASK_ACHIEVE: "successTask"
      },
      apiKey: "",
      apiSecret: "",
      wxAppList: null,
      token: null,
      version: "1.0",
      bannerSwitch: 0,
      shareSwitch: 0,
      reviveBannerDelayTime: 1e3,
      rewardBannerDelayTime: 1e3,
      overBannerDelayTime: 1e3,
      headUrl: "",
      nickName: "",
      userId: 1,
      getUrl: function getUrl(e) {
        return this.serverUrl.concat(e);
      },
      sign: function sign(e) {
        var t = [];
        for (var i in e) e.hasOwnProperty(i) && t.push(i);
        for (var n = t.sort(), s = "", o = 0; o < n.length; o++) s += e[n[o]];
        return s = encodeURIComponent(s), md5(s, this.apiSecret);
      }
    };
    module.exports = n;
    cc._RF.pop();
  }, {} ],
  ShareData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "21176m5PD1LgrusdfThS3UI", "ShareData");
    "use strict";
    var n = require("SerializableData");
    cc.Class({
      extends: n,
      properties: {
        count: 0,
        lastTime: 0,
        startTime: 0,
        maxCount: 1,
        internalTime: 3,
        shareContent: []
      },
      execute: function execute() {
        this.count++, this.startTime = this.lastTime = Date.now();
      }
    });
    cc._RF.pop();
  }, {
    SerializableData: "SerializableData"
  } ],
  SkinTestUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "444c91iFX1B4KVssnPdgf8U", "SkinTestUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      properties: {
        _isFree: !0,
        collect: cc.Node
      },
      onLoad: function onLoad() {
        var self = this;
        this.collect.active = false;
        self.collect.active = true;
      },
      init: function init() {
        this.user = kk.curUser, this.freeTestRoot = cc.find("Menu/Toggle1", this.node), 
        this.videoTestRoot = cc.find("Menu/Toggle2", this.node), this._isFree = this.hasFreeTime(), 
        this.freeTestRoot.getChildByName("Style1").active = this._isFree, this.freeTestRoot.getChildByName("Style2").active = !this._isFree, 
        this.selectSkinId = this.user.getCurSkinId(), this.freeTestSkinId = this.getRandomIndex(), 
        this.videoTestSkinId = this.getRandomIndex(), this.registerEvents(), kk.sdkBridger.showBanner(kk.sdkBridger.bannerForTest);
        console.log("=====init skintest===");
      },
      updateData: function updateData() {
        var e = this.freeTestRoot.getChildByName("Button");
        e.addClickEvent("SkinTestUI", "freeTest", this.freeTestSkinId, this.node), (e = this.videoTestRoot.getChildByName("Button")).addClickEvent("SkinTestUI", "videoTest", this.videoTestSkinId, this.node), 
        e = this.freeTestRoot.getChildByName("Model"), this.updateNodes(e, this.freeTestSkinId), 
        e = this.videoTestRoot.getChildByName("Model"), this.updateNodes(e, this.videoTestSkinId);
      },
      updateNodes: function updateNodes(e, t) {
        var i = "assassin".concat((t = t || 0) + 1), n = "assassinLeg".concat(t + 1), s = e.getChildByName("Legs").children, o = e.getChildByName("Body");
        kk.AssetLib.setSprite(o, i), kk.AssetLib.setSprite(s[0], n), kk.AssetLib.setSprite(s[1], n);
      },
      getRandomIndex: function getRandomIndex() {
        for (var e = this.user.getSkins(), t = [], i = 1, n = kk.Config.skinCount; i < n; i++) e.contains(i) || t.push(i);
        return t.random();
      },
      hasFreeTime: function hasFreeTime() {
        var e = kk.load("lastTestTime");
        return !Utils.Unix.isSameDay(e, Date.now());
      },
      freeTest: function freeTest(e, t) {
        cc.vv.NativeUtils.showInsertAd(0);
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), this._isFree ? (kk.save("lastTestTime", Date.now()), 
        this.selectSkinId = parseInt(t), MessageHandler.dispatch(kk.Enum.MsgKey.USER_SWITCH_SKIN, this.selectSkinId), 
        this.close()) : this.videoTest("change to video", t);
      },
      videoTest: function videoTest(e, t) {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), this.selectSkinId = parseInt(t);
        cc.vv.NativeUtils.showVideoAd(0, function() {
          MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, kk.Enum.SdkTag.VIDEO_SKIN_TEST, true);
        });
      },
      onVideoTestOver: function onVideoTestOver() {
        var e = Array.prototype.slice.call(arguments);
        e[0] === kk.Enum.SdkTag.VIDEO_SKIN_TEST && e[1] && (MessageHandler.dispatch(kk.Enum.MsgKey.USER_SWITCH_SKIN, this.selectSkinId), 
        this.close());
      },
      randomTest: function randomTest() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), this.selectSkinId = this.getRandomIndex();
        cc.vv.NativeUtils.showVideoAd(0, function() {
          MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, kk.Enum.SdkTag.VIDEO_SKIN_TEST_RANDOM, true);
        });
      },
      onRandomTestOver: function onRandomTestOver() {
        var e = Array.prototype.slice.call(arguments);
        e[0] === kk.Enum.SdkTag.VIDEO_SKIN_TEST_RANDOM && e[1] && (MessageHandler.dispatch(kk.Enum.MsgKey.USER_SWITCH_SKIN, this.selectSkinId), 
        this.close());
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoTestOver, this), MessageHandler.add(kk.Enum.MsgKey.ADS_VIDEO, this.onRandomTestOver, this);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoTestOver, this), MessageHandler.remove(kk.Enum.MsgKey.ADS_VIDEO, this.onRandomTestOver, this);
      },
      onClose: function onClose() {
        console.log("=====init skintest===");
        this.unRegisterEvents(), this._super();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  SkinUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e5b48b8dLxBVav1mQp8h7MR", "SkinUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      init: function init() {
        kk.curUser = kk.curUser, this.infoSpriteNodes = cc.find("Menu/Sprites", this.node).children, 
        this.infoLabelNodes = cc.find("Menu/Labels", this.node).children, this.selectIndex = kk.curUser.getCurSkinId(), 
        this.priceLabel = this.node.getChildByName("GoldLabel").getComponent(cc.Label), 
        this.registerEvents();
      },
      loadConfig: function loadConfig(e) {
        kk.AssetLib.loadAsset("config/skinInfo", cc.JsonAsset, function(t) {
          this.config = Utils.clone(t.json), e && e();
        }, null, this);
      },
      updateData: function updateData() {
        this.updatePrice(), this.config ? this.updateNodes() : this.loadConfig(this.updateNodes.bind(this));
      },
      updateNodes: function updateNodes() {
        for (var e = void 0, t = void 0, i = void 0, n = void 0, s = void 0, o = void 0, a = void 0, r = 0, c = this.infoSpriteNodes.length; r < c; r++) this.config[r + 1] && (e = kk.curUser.hasUnlockSkin(r), 
        i = this.infoSpriteNodes[r].getChildByName("Back"), n = this.infoSpriteNodes[r].getChildByName("Mask"), 
        t = this.infoLabelNodes[r], s = this.selectIndex === r ? "skin_bg2" : "skin_bg1", 
        kk.AssetLib.setSprite(i, s), i.addClickEvent("SkinUI", "changeSkin", r.toString(), this.node), 
        n.active = !e, 0 === r ? t.getComponent(cc.Label).string = kk.LocalizeSystem.localizeText("label_text.default") : (o = this.config[r + 1].ability.hp, 
        a = this.config[r + 1].ability.speed, t.getComponent(cc.Label).string = this.getHpDes(o).concat(this.getSpeedDes(a))));
      },
      getHpDes: function getHpDes(e) {
        return e ? kk.LocalizeSystem.localizeText("label_text.hp").concat(" +").concat(e.toString()).concat("%") : "";
      },
      getSpeedDes: function getSpeedDes(e) {
        return e ? kk.LocalizeSystem.localizeText("label_text.speed").concat(" +").concat(e.toString()).concat("%") : "";
      },
      updatePrice: function updatePrice() {
        this.priceLabel.string = kk.curUser.getGold() + ":" + kk.curUser.getRandomPrice();
      },
      randomEvent: function randomEvent() {
        if (kk.AudioSystem.play(kk.AudioName.GUI, "click"), this.skinIsSaleOut()) kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("label_text.skinSaleOut"), !1, 600); else {
          var e = kk.curUser.getRandomPrice();
          if (kk.curUser.getGold() < e) kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("label_text.gold_unEnough"), !1, 600); else {
            var t = this.getResultIndex(), i = cc.callFunc(function() {
              this.updateNodeOnChange(this.getRandomIndex());
            }, this), n = cc.callFunc(function() {
              kk.curUser.unlockSkin(t, !0), MessageHandler.dispatch(kk.Enum.MsgKey.USER_UNLOCK_SKIN, t), 
              kk.Client.saveUser(kk.ServerApi.Address.POST_SKIN_UNLOCK, t, e, function() {
                kk.curUser.costGold(e);
              });
            }, this);
            this.node.runAction(cc.sequence(cc.repeat(cc.sequence(i, cc.delayTime(.1)), 20), n));
          }
        }
      },
      updateNodeOnChange: function updateNodeOnChange(e) {
        var t = this.infoSpriteNodes[this.selectIndex].getChildByName("Back"), i = this.infoSpriteNodes[this.selectIndex].getChildByName("Mask");
        kk.AssetLib.setSprite(t, "skin_bg1"), i.active = !kk.curUser.hasUnlockSkin(this.selectIndex), 
        this.selectIndex = e, t = this.infoSpriteNodes[this.selectIndex].getChildByName("Back"), 
        i = this.infoSpriteNodes[this.selectIndex].getChildByName("Mask"), kk.AssetLib.setSprite(t, "skin_bg2"), 
        i.active = !1;
      },
      getRandomIndex: function getRandomIndex() {
        for (var e = kk.curUser.getSkins(), t = [], i = 1, n = this.getRandomRange(); i < n; i++) e.contains(i) || t.push(i);
        return t.random();
      },
      getResultIndex: function getResultIndex() {
        for (var e = kk.curUser.getSkins(), t = [], i = 1, n = this.getResultRange(); i < n; i++) e.contains(i) || t.push(i);
        return t.random();
      },
      getRandomRange: function getRandomRange() {
        return kk.Config.skinCount;
      },
      getResultRange: function getResultRange() {
        var e = kk.curUser.getRandomRange();
        return e >= kk.Config.skinCount ? kk.Config.skinCount : e;
      },
      skinIsSaleOut: function skinIsSaleOut() {
        return kk.curUser.getSkins().length >= this.infoSpriteNodes.length;
      },
      changeSkin: function changeSkin(e, t) {
        kk.AudioSystem.play(kk.AudioName.GUI, "click"), t = parseInt(t), kk.curUser.changeSkinId(t) && this.updateNodeOnChange(t);
      },
      watchVideo: function watchVideo() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click");
        cc.vv.NativeUtils.showVideoAd(0, function() {
          MessageHandler.dispatch(kk.Enum.MsgKey.ADS_VIDEO, kk.Enum.SdkTag.VIDEO_SKIN_EARN_GEM, true);
        });
      },
      onVideoOver: function onVideoOver() {
        var e = Array.prototype.slice.call(arguments);
        e[0] === kk.Enum.SdkTag.VIDEO_SKIN_EARN_GEM && e[1] && this.getReward();
      },
      getReward: function getReward() {
        kk.Client.saveUser(kk.ServerApi.Address.POST_GET_GOLD, "1", kk.Config.skinVideoReward, function(e) {
          e && 0 === e.code ? (kk.curUser.addGold(kk.Config.skinVideoReward), kk.GuiSystem.add("RewardUI", function(e) {
            e.setData(kk.Enum.CostType.GOLD, kk.Config.skinVideoReward);
          })) : kk.sdkBridger.showSystemToast(kk.LocalizeSystem.localizeText("error_text.response_data_error"), !1, 600);
        }.bind(this));
      },
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this), MessageHandler.add(kk.Enum.MsgKey.USER_UPDATE_GOLD, this.updatePrice, this), 
        MessageHandler.add(kk.Enum.MsgKey.USER_UNLOCK_SKIN, this.updateNodeOnChange, this);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.ADS_VIDEO, this.onVideoOver, this), MessageHandler.remove(kk.Enum.MsgKey.USER_UPDATE_GOLD, this.updatePrice, this), 
        MessageHandler.remove(kk.Enum.MsgKey.USER_UNLOCK_SKIN, this.updateNodeOnChange, this);
      },
      onClose: function onClose() {
        cc.vv.NativeUtils.showInsertAd(0);
        this.unRegisterEvents(), this._super();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  SpriteFrameSet: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "97019Q80jpE2Yfz4zbuCZBq", "SpriteFrameSet");
    "use strict";
    var SpriteFrameSet = cc.Class({
      name: "SpriteFrameSet",
      properties: {
        language: "",
        spriteFrame: cc.SpriteFrame
      }
    });
    module.exports = SpriteFrameSet;
    cc._RF.pop();
  }, {} ],
  SubItem: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5d776IU4DNCgY051au25B9L", "SubItem");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        _parent: {
          default: null,
          type: cc.Node
        },
        parent: {
          type: cc.Node,
          get: function get() {
            return this._parent;
          },
          set: function set(e) {
            if (null == e) {
              this._parent = e;
              return;
            }
            return this._parent = e, this.linkPos(), e;
          }
        },
        _autoDestroy: true
      },
      update: function update(e) {
        this.parent ? this.node.setPosition(cc.v3(this.parent.position.x, this.parent.position.y, this.parent.position.z)) : this._autoDestroy && this.node.destroy();
      },
      linkPos: function linkPos() {
        this.node.setPosition(this.parent.position);
      }
    });
    cc._RF.pop();
  }, {} ],
  SuccessUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "03338xvlLJJk689HcyBMbmU", "SuccessUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      init: function init() {
        this.levelLabel = this.node.getChildByName("Level").getComponent(cc.Label);
        console.log("=====init success===");
      },
      updateData: function updateData() {
        this.levelLabel.string = String.format(kk.LocalizeSystem.localizeText("label_text.levelIndex"), kk.curUser.getCurLevel());
      },
      next: function next() {
        kk.quickStart = !0, this.close();
      },
      onClose: function onClose() {
        window.HUHU_showInterstitialAd();
        console.log("=====colse success===");
        this._super(), kk.Game.restart();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  SystemUI: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "7a0afb3WSJDzaAxxoToIXsz", "SystemUI");
    "use strict";
    var n = require("Gui");
    cc.Class({
      extends: n,
      init: function init() {
        this.soundNode = cc.find("TopLayer/Sound", this.node), this.vibrateNode = cc.find("TopLayer/Vibrate", this.node), 
        this.initState(), this.alignTimer = setTimeout(this.alignPos.bind(this), 10);
      },
      alignPos: function alignPos() {
        if (kk.isSprs()) {
          var e = this.node.getChildByName("TopLayer");
          e.getComponent(cc.Widget).updateAlignment(), e.setPosition(e.position.x, e.position.y - 60);
        }
      },
      initState: function initState() {
        var e = kk.AudioSystem.getState(kk.AudioType.SOUND), t = kk.sdkBridger.loadVibrateState();
        kk.AssetLib.setSprite(this.soundNode, e ? "setting_sound_off" : "setting_sound_on"), 
        kk.AssetLib.setSprite(this.vibrateNode, t ? "setting_vibrate_off" : "setting_vibrate_on");
      },
      switchMusicState: function switchMusicState() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click");
        var e = kk.AudioSystem.switchState(kk.AudioType.SOUND, !0);
        kk.AssetLib.setSprite(this.soundNode, e ? "setting_sound_off" : "setting_sound_on");
      },
      switchVibrateState: function switchVibrateState() {
        kk.AudioSystem.play(kk.AudioName.GUI, "click");
        var e = kk.sdkBridger.switchVibrateState();
        kk.AssetLib.setSprite(this.vibrateNode, e ? "setting_vibrate_off" : "setting_vibrate_on");
      },
      openService: function openService() {
        kk.GuiSystem.addTips("Try Add Shortcut");
        window.qg ? window.qg.hasShortcutInstalled({
          success: function success(res) {
            res ? window.qg.showToast({
              message: "\u5df2\u521b\u5efa"
            }) : window.qg.installShortcut();
          }
        }) : window["ysdk"] && window["ysdk"].shortcut.canShowPrompt().then(function(prompt) {
          if (prompt.canShow) {
            console.log("Shortcut allowed2");
            window["ysdk"].shortcut.showPrompt().then(function(result) {
              console.log("Shortcut created?:", result);
              "accepted" === result.outcome ? kk.GuiSystem.addTips("Shortcut Added") : kk.GuiSystem.addTips("Shortcut Cancle");
            });
          } else {
            console.log("Shortcut allowed2");
            kk.GuiSystem.addTips("Shortcut Not Allow");
          }
        });
      },
      clearAlignTimer: function clearAlignTimer() {
        Utils.isNone(this.alignTimer) || clearTimeout(this.alignTimer);
      },
      onClose: function onClose() {
        this.clearAlignTimer(), this._super();
      }
    });
    cc._RF.pop();
  }, {
    Gui: "Gui"
  } ],
  Target: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f0b61EmKJtOd7E1Z29lIa6A", "Target");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {
        arrow: cc.Node
      },
      onLoad: function onLoad() {
        this.newArrowArr = [];
      },
      start: function start() {
        this.nodeAngle = this.node.getComponent(cc.CircleCollider).radius;
      },
      onCollisionEnter: function onCollisionEnter(other, self) {
        if ("arrow" == other.node.group) {
          other.node.removeFromParent();
          this.addArrowInTarget(180 - -this.node.angle);
          this.node.runAction(cc.sequence(cc.moveBy(.05, 0, 15), cc.moveBy(.05, 0, -15)));
        }
      },
      addArrowInTarget: function addArrowInTarget(args) {
        var self = this;
        var radian = cc.misc.degreesToRadians(args);
        var newArrow = cc.instantiate(self.arrow);
        newArrow.x = self.nodeAngle * Math.sin(radian);
        newArrow.y = self.nodeAngle * Math.cos(radian);
        newArrow.angle = -1 * args;
        newArrow.active = true;
        self.node.addChild(newArrow);
        self.newArrowArr.push(newArrow);
      }
    });
    cc._RF.pop();
  }, {} ],
  TaskSystem: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "9ee4a1yshNB275PhCYKbHgB", "TaskSystem");
    "use strict";
    var n = require("Task"), s = {
      tasks: {},
      count: 0,
      waitingTaskTypes: [],
      init: function init() {
        this.tasks = {}, this.waitingTaskTypes = [];
        for (var e = kk.curUser.getTasks(), t = e.length, i = 0; i < kk.Config.taskMaxCount; i++) i < t ? this.add(e[i]) : this.accept(i);
      },
      refresh: function refresh() {
        this.clear();
        for (var e = kk.curUser.getTasks(), t = e.length, i = 0; i < kk.Config.taskMaxCount; i++) i < t ? this.add(e[i]) : this.accept(i);
      },
      accept: function accept(e) {
        if (!(kk.curUser.getTasks().length >= kk.Config.taskMaxCount)) {
          var t = this.getUnRepeatTaskTypes().random(), i = this.mathTaskAim(t), n = this.mathTaskReward();
          this.waitingTaskTypes.contains(t) || this.waitingTaskTypes.push(t), kk.Client.saveUser(kk.ServerApi.Address.POST_TASK_CREATE, t, i, n, function(s) {
            if (s && 0 === s.code && s.result) {
              var o = kk.curUser.getTasks(), a = {
                id: s.isLocal ? this.generateUID() : s.result.task_id,
                type: t,
                cur: 0,
                aim: i,
                reward: n
              }, r = this.add(a);
              this.waitingTaskTypes.remove(t), o.splice(e, 0, a), MessageHandler.dispatch(kk.Enum.MsgKey.USER_TASK_UPDATE, e, r);
            }
          }.bind(this));
        }
      },
      achieve: function achieve(e, t) {
        var i = e.getUID(), n = kk.curUser.getTasks();
        this.remove(e) && (n.splice(t, 1), kk.Client.saveUser(kk.ServerApi.Address.POST_TASK_ACHIEVE, i), 
        this.accept(t));
      },
      remove: function remove(e) {
        if (!(e instanceof n)) return console.warn(e + "\u53c2\u6570\u4f20\u5165\u6709\u8bef!"), 
        !1;
        var t = e.getUID();
        return !!this.tasks.hasOwnProperty(t) && (delete this.tasks[t], e.release(), !0);
      },
      getUnRepeatTaskTypes: function getUnRepeatTaskTypes() {
        var e = [ 0, 1, 2, 3, 4, 5, 6 ];
        for (var t in this.tasks) this.tasks.hasOwnProperty(t) && e.remove(this.tasks[t].aimType);
        for (var i = 0; i < this.waitingTaskTypes.length; i++) e.remove(this.waitingTaskTypes[i]);
        return e;
      },
      getTaskByUID: function getTaskByUID(e) {
        return this.tasks.hasOwnProperty(e) ? this.tasks[e] : null;
      },
      add: function add(e) {
        var t = new n(e);
        return this.tasks[e.id] = t, e = null, t;
      },
      clear: function clear() {
        for (var e in this.tasks) this.tasks.hasOwnProperty(e) && this.remove(this.tasks[e]);
        this.tasks = {}, this.waitingTaskTypes = [];
      },
      generateUID: function generateUID(e) {
        return this.count++, Date.now().toString().concat(this.count.toString().concat(e));
      },
      mathTaskAim: function mathTaskAim(e) {
        var t = kk.curUser.getInfo("playedLevel"), i = 1;
        switch (e) {
         case kk.Enum.TaskAimType.KILL:
          i = t < 16 ? 1 : t < 30 ? 2 : 3;
          break;

         case kk.Enum.TaskAimType.VIDEO:
          i = 1;
          break;

         case kk.Enum.TaskAimType.COLLECT:
          i = t < 16 ? 200 : t < 30 ? 200 : 500;
          break;

         case kk.Enum.TaskAimType.GAME_COUNT:
          i = 3;
          break;

         case kk.Enum.TaskAimType.KILL_CONTINUOUS:
          i = t < 16 ? 2 : t < 30 ? 3 : 5;
          break;

         default:
          i = 1;
        }
        return i;
      },
      mathTaskReward: function mathTaskReward() {
        var e = kk.curUser.getInfo("playedLevel");
        return e < 16 ? 200 : e < 30 ? 300 : 500;
      }
    };
    module.exports = s;
    cc._RF.pop();
  }, {
    Task: "Task"
  } ],
  Task: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e4fa6VwV8ZI0p2JZ5lnvyUJ", "Task");
    "use strict";
    var n = require("GameObject");
    cc.Class({
      extends: n,
      properties: {
        aimType: 0,
        msgKey: null
      },
      onStart: function onStart() {
        this.initType(), this.registerEvent();
      },
      onRelease: function onRelease() {
        this.unRegisterEvent();
      },
      initType: function initType() {
        this.aimType = this.getInfo("type"), this.msgKey = this.getMsgKey(this.aimType);
      },
      getMsgKey: function getMsgKey(e) {
        var t = null;
        switch (e) {
         case kk.Enum.TaskAimType.KILL:
          t = kk.Enum.MsgKey.LEVEL_KILL_MONSTER;
          break;

         case kk.Enum.TaskAimType.KILL_CONTINUOUS:
          t = kk.Enum.MsgKey.LEVEL_KILL_CONTINUOUS;
          break;

         case kk.Enum.TaskAimType.COLLECT:
          t = kk.Enum.MsgKey.USER_ADD_GOLD;
          break;

         case kk.Enum.TaskAimType.VIDEO:
          t = kk.Enum.MsgKey.ADS_VIDEO;
          break;

         case kk.Enum.TaskAimType.NO_PAIN:
         case kk.Enum.TaskAimType.NO_FIND:
         case kk.Enum.TaskAimType.GAME_COUNT:
          t = kk.Enum.MsgKey.LEVEL_GAME_COUNT;
        }
        return t;
      },
      getTitle: function getTitle(e) {
        return kk.LocalizeSystem.localizeText("label_text.task".concat(e + 1));
      },
      registerEvent: function registerEvent() {
        MessageHandler.add(kk.Enum.GameEvent.GAME_START, this.resetTempInfo, this), this.msgKey && MessageHandler.add(this.msgKey, this.addCur, this);
      },
      unRegisterEvent: function unRegisterEvent() {
        MessageHandler.remove(kk.Enum.GameEvent.GAME_START, this.resetTempInfo, this), MessageHandler.remove(this.msgKey, this.addCur, this);
      },
      resetTempInfo: function resetTempInfo() {
        this.isVideo() && this.isOver() || this.setTemp("cur", 0);
      },
      getUID: function getUID() {
        return this.getInfo("id");
      },
      setCur: function setCur(e) {
        return this.setInfo("cur", e);
      },
      getCur: function getCur() {
        return this.getInfo("cur");
      },
      getAim: function getAim() {
        return this.getInfo("aim");
      },
      addCur: function addCur(e) {
        var t = 1, i = void 0;
        switch (this.aimType) {
         default:
          t = 1, i = this.addInfo("cur", 1);
          break;

         case kk.Enum.TaskAimType.VIDEO:
          var n = Array.prototype.slice.call(arguments), s = this.getTaskIndex();
          (t = e === kk.Enum.SdkTag.VIDEO_TASK_EARN_GEM.concat(s.toString()) && n[1] ? 1 : 0) > 0 && (i = this.addInfo("cur", t), 
          this.updateTaskView(s));
          break;

         case kk.Enum.TaskAimType.COLLECT:
          (t = e) > 0 && (i = this.addInfo("cur", t));
          break;

         case kk.Enum.TaskAimType.NO_PAIN:
          (t = e === kk.Enum.GameEndTag.PAIN || e === kk.Enum.GameEndTag.PAIN_AND_FIND ? 0 : 1) > 0 && (i = this.addInfo("cur", t));
          break;

         case kk.Enum.TaskAimType.NO_FIND:
          (t = e === kk.Enum.GameEndTag.FIND || e === kk.Enum.GameEndTag.PAIN_AND_FIND ? 0 : 1) > 0 && (i = this.addInfo("cur", t));
        }
        return t > 0 && kk.Client.saveUser(kk.ServerApi.Address.POST_TASK_UPDATE, this.getUID(), i), 
        i;
      },
      updateTaskView: function updateTaskView(e) {
        -1 !== e && MessageHandler.dispatch(kk.Enum.MsgKey.USER_TASK_UPDATE, e, this);
      },
      getTaskIndex: function getTaskIndex() {
        for (var e = this.getUID(), t = kk.curUser.getTasks(), i = 0, n = t.length; i < n; i++) if (t[i].id === e) return i;
        return -1;
      },
      getProgressOfNumber: function getProgressOfNumber() {
        return this.getCur() / this.getAim();
      },
      getProgressOfString: function getProgressOfString() {
        var e = this.getCur(), t = this.getAim();
        return (e = e > t ? t : e) + ":" + t;
      },
      getReward: function getReward() {
        return this.getInfo("reward");
      },
      isOver: function isOver() {
        return this.getProgressOfNumber() >= 1;
      },
      isVideo: function isVideo() {
        return this.aimType === kk.Enum.TaskAimType.VIDEO;
      }
    });
    cc._RF.pop();
  }, {
    GameObject: "GameObject"
  } ],
  Times: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "435f506vupE7J4DGYJu6lWT", "Times");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      times: function times() {
        var self = this;
        cc.find("Canvas").on("times", function(data) {
          if (Globals.changeImages) {
            if (!self.callback) {
              self.callback = function() {
                Globals.times -= 1;
                self.node.getComponent(cc.Label).string = Globals.times;
              };
              self.schedule(self.callback, 1, 18, 0);
            }
          } else {
            if (self.callback) {
              self.unschedule(self.callback);
              Globals.times = 19;
            }
            self.callback = null;
          }
        });
      },
      onLoad: function onLoad() {
        this.times();
      },
      start: function start() {}
    });
    cc._RF.pop();
  }, {} ],
  UserData: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "787adWcG29DR6KXjzHBBKkr", "UserData");
    "use strict";
    var n = require("SerializableData");
    cc.Class({
      extends: n,
      properties: {
        id: 0,
        openid: 0,
        gender: 0,
        nickName: "",
        avatar: "",
        gold: 0,
        playedLevel: 0,
        remainVideoCount: 0,
        isSigned: 0,
        signInCount: 0,
        lastSignInTime: 0,
        curSkin: 0,
        skins: [],
        tasks: []
      }
    });
    cc._RF.pop();
  }, {
    SerializableData: "SerializableData"
  } ],
  User: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "ebd7fKUagNDMaCuU8fB4IN+", "User");
    "use strict";
    var n = require("GameObject");
    cc.Class({
      extends: n,
      properties: {
        model: null,
        hasGuided: !1
      },
      onStart: function onStart() {
        this.dataModify(), this.initDailyRecord(), this.registerEvents();
      },
      dataModify: function dataModify() {},
      registerEvents: function registerEvents() {
        MessageHandler.add(kk.Enum.MsgKey.SKU_RESTORE, this.restoreExchangerCB, this);
      },
      unRegisterEvents: function unRegisterEvents() {
        MessageHandler.remove(kk.Enum.MsgKey.SKU_RESTORE, this.restoreExchangerCB, this);
      },
      restoreExchangerCB: function restoreExchangerCB() {
        Array.prototype.slice.call(arguments)[2];
      },
      initModel: function initModel(e) {
        return e || cc.error("\u6a21\u578b\u8d44\u6e90\u4e22\u5931..."), this.model = cc.instantiate(e), 
        kk.curScene.node.addChild(this.model), this.model;
      },
      initDailyRecord: function initDailyRecord() {
        if (kk.Config.isLocal) {
          var e = Date.now();
          this.initZeroRecord(e), this.initSixRecord(e);
        }
      },
      initZeroRecord: function initZeroRecord(e) {
        var t = this.getInfo("refreshTime/zeroHour"), i = Utils.Unix.getTodayHourStart(0);
        t >= i || t && e < i || (this.refreshDailyRecord(), this.setInfo("refreshTime/zeroHour", e));
      },
      initSixRecord: function initSixRecord(e) {
        var t = this.getInfo("refreshTime/sixHour"), i = Utils.Unix.getTodayHourStart(6);
        t >= i || t && e < i || this.setInfo("refreshTime/sixHour", e);
      },
      refreshDailyRecord: function refreshDailyRecord() {
        this.setInfo("isSigned", 0);
      },
      getId: function getId() {
        return this.getInfo("id");
      },
      getCoin: function getCoin() {
        return this.getInfo("coin");
      },
      getGold: function getGold() {
        return this.getInfo("gold");
      },
      updateGold: function updateGold(e) {
        return !("number" != typeof e || e < 0) && (this.setInfo("gold", e), MessageHandler.dispatch(kk.Enum.MsgKey.USER_UPDATE_GOLD), 
        !0);
      },
      addGold: function addGold(e, t) {
        return e > 0 && (this.addInfo("gold", e), MessageHandler.dispatch(kk.Enum.MsgKey.USER_UPDATE_GOLD), 
        t && MessageHandler.dispatch(kk.Enum.MsgKey.USER_ADD_GOLD, e)), this.getInfo("gold");
      },
      costGold: function costGold(e) {
        return e > 0 && (this.addInfo("gold", -e), MessageHandler.dispatch(kk.Enum.MsgKey.USER_UPDATE_GOLD)), 
        this.getInfo("gold");
      },
      hasOwnAllSkins: function hasOwnAllSkins() {
        return this.getSkins().length >= kk.Config.skinCount;
      },
      hasUnlockSkin: function hasUnlockSkin(e) {
        return 0 === e || this.getSkins().contains(e);
      },
      getCurSkinId: function getCurSkinId() {
        return this.getInfo("curSkin");
      },
      getSkins: function getSkins() {
        var e = this.getInfo("skins");
        return e && e.length ? e : this.setInfo("skins", [ 0 ]);
      },
      unlockSkin: function unlockSkin(e, t) {
        if (e) {
          var i = this.getSkins();
          i.contains(e) || (i.push(e), t && (this.setInfo("curSkin", e), MessageHandler.dispatch(kk.Enum.MsgKey.USER_SWITCH_SKIN, e), 
          kk.Client.saveUser(kk.ServerApi.Address.POST_SKIN_SWITCH, e)));
        }
      },
      changeSkinId: function changeSkinId(e) {
        return this.getCurSkinId() !== e && !!this.hasUnlockSkin(e) && (this.setInfo("curSkin", e), 
        MessageHandler.dispatch(kk.Enum.MsgKey.USER_SWITCH_SKIN, e), kk.Client.saveUser(kk.ServerApi.Address.POST_SKIN_SWITCH, e), 
        !0);
      },
      getRandomPrice: function getRandomPrice() {
        return kk.Config.baseRandomPrice * Math.pow(2, this.getSkins().length - 1);
      },
      getRandomRange: function getRandomRange() {
        return this.getSkins().length + 3;
      },
      signIn: function signIn() {
        var e = Date.now(), t = this.getLastSignInTime();
        this.setInfo("isSigned", 1), this.setInfo("lastSignInTime", e), Utils.Unix.isSameDay(e, t) || (Utils.Unix.apartThanOneDay(e, t) ? this.setInfo("signInCount", 1) : this.addInfo("signInCount", 1));
      },
      getSignInState: function getSignInState() {
        return this.getInfo("isSigned");
      },
      getSignInCount: function getSignInCount() {
        return this.getInfo("signInCount");
      },
      getLastSignInTime: function getLastSignInTime() {
        return this.getInfo("lastSignInTime");
      },
      getCurLevel: function getCurLevel() {
        var e = this.getInfo("playedLevel") + 1;
        return e > kk.Config.limitLevel ? kk.Config.limitLevel : e;
      },
      getTasks: function getTasks() {
        return this.getInfo("tasks") || this.setInfo("tasks", []);
      }
    });
    cc._RF.pop();
  }, {
    GameObject: "GameObject"
  } ],
  WXComponent: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "ab6e7d8kCtBBInxZCeZ8GsJ", "WXComponent");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      start: function start() {},
      init: function init() {
        if ("undefined" != typeof wx) {
          wx.showShareMenu({
            withShareTicket: true,
            success: function success(data) {
              console.log("\u8f6c\u53d1\u6d88\u606f", data);
            },
            fail: function fail(data) {
              console.log(data);
            }
          });
          var title = "\u4e0d\u591f\u683c,\u4e0d\u662f\u8c01\u90fd\u80fd\u591f\u5230\u8fbe\u8fd9\u4e2a\u5dc5\u5cf0";
          var imageUrl = "https://src2.xyx.hlqps.com/szasx/share/share_none.png";
          wx.onShareAppMessage(function() {
            return {
              title: title,
              imageUrl: imageUrl
            };
          });
          wx.onShow(function() {
            if (Globals.shareCount > 1) {
              var timeStamp = Globals.timeStamp;
              Globals.timeStamp = Date.parse(new Date()) / 1e3;
              var time = Globals.timeStamp - timeStamp;
              var time2 = Globals.shareCount + 2;
              if (time > time2) {
                Globals.shareCount = 0;
                cc.vv.netRootjs.dispatchEvent("shareWin", "win");
              } else cc.vv.netRootjs.dispatchEvent("shareWin", "lose");
            }
          });
        }
      },
      wxMessage: function wxMessage(type, data) {
        if ("undefined" != typeof wx) {
          var agrs;
          switch (type) {
           case "friends":
            agrs = {
              type: "friends_all"
            };
            cc.vv.UIComment.showPrefab("rank", data, "Rank", agrs);
            break;

           case "group":
            agrs = {
              type: "friends_group"
            };
            cc.vv.UIComment.showPrefab("rank", data, "Rank", agrs);
            break;

           case "getData":
            break;

           case "setData":
            agrs = {
              type: "saveData",
              score: data
            };
            "undefined" != typeof wx && wx.postMessage(agrs);
          }
        }
      },
      wxGameGotoMain: function wxGameGotoMain() {},
      wxShare: function wxShare(arge) {
        console.log("\u5206\u4eab");
        if ("undefined" != typeof wx) {
          arge && (Globals.shareCount += 1);
          Globals.shareCount > 1 ? Globals.timeStamp = Date.parse(new Date()) / 1e3 : 1 == Globals.shareCount && cc.vv.netRootjs.dispatchEvent("shareWin", "lose");
          var shareTemplate = cc.vv.JJSdk.getShareTemplates();
          if ("money" == arge) {
            if (void 0 != shareTemplate.money && shareTemplate.money.length > 0) {
              var random = Math.floor(Math.random() * shareTemplate.money.length);
              var data = {};
              data.sceneId = shareTemplate.money[random].id;
              data.title = shareTemplate.money[random].title;
              data.imageUrl = shareTemplate.money[random].pic;
              data.query = "query";
              cc.vv.JJSdk.shareAppMessage(data);
              return;
            }
            wx.shareAppMessage({
              title: "\u3010\u6709\u4eba@\u6211\u3011\u6211\u8fd9\u6709\u7ea2\u5305\uff0c\u8c01\u8981\u9886\uff1f",
              imageUrl: "https://src2.xyx.hlqps.com/szasx/share/share_money.png",
              success: function success() {
                console.log("\u5206\u4eab\u6210\u529f");
              },
              fail: function fail() {
                console.log("\u5206\u4eab\u5931\u8d25");
              }
            });
          } else if ("challenge" == arge) {
            if (void 0 != shareTemplate.challenge && shareTemplate.challenge.length > 0) {
              var _random = Math.floor(Math.random() * shareTemplate.challenge.length);
              var data = {};
              data.sceneId = shareTemplate.challenge[_random].id;
              data.title = shareTemplate.challenge[_random].title;
              data.imageUrl = shareTemplate.challenge[_random].pic;
              data.query = "query";
              cc.vv.JJSdk.shareAppMessage(data);
              return;
            }
            wx.shareAppMessage({
              title: "\u3010\u6709\u4eba@\u6211\u3011\u4f60\u662f\u4e0d\u662f\u4e0d\u670d\uff1f\u4e0d\u670d\u5f00\u6253",
              imageUrl: "https://src2.xyx.hlqps.com/szasx/share/share_challenge.png",
              success: function success() {
                console.log("\u5206\u4eab\u6210\u529f");
              },
              fail: function fail() {
                console.log("\u5206\u4eab\u5931\u8d25");
              }
            });
          } else if ("resurrection" == arge) {
            if (void 0 != shareTemplate.resurrection && shareTemplate.resurrection.length > 0) {
              var _random2 = Math.floor(Math.random() * shareTemplate.resurrection.length);
              var data = {};
              data.sceneId = shareTemplate.resurrection[_random2].id;
              data.title = shareTemplate.resurrection[_random2].title;
              data.imageUrl = shareTemplate.resurrection[_random2].pic;
              data.query = "query";
              cc.vv.JJSdk.shareAppMessage(data);
              return;
            }
            wx.shareAppMessage({
              title: "\u5e2e\u6211\u6211\u70b9\u4e00\u4e0b\uff0c\u6211\u89c9\u5f97\u6211\u8fd8\u80fd\u62a2\u6551\u4e00\u4e0b",
              imageUrl: "https://src2.xyx.hlqps.com/szasx/share/share_resurrection.png",
              success: function success() {
                console.log("\u5206\u4eab\u6210\u529f");
              },
              fail: function fail() {
                console.log("\u5206\u4eab\u5931\u8d25");
              }
            });
          } else if ("props" == arge) {
            if (void 0 != shareTemplate.props && shareTemplate.props.length > 0) {
              var _random3 = Math.floor(Math.random() * shareTemplate.props.length);
              var data = {};
              data.sceneId = shareTemplate.props[_random3].id;
              data.title = shareTemplate.props[_random3].title;
              data.imageUrl = shareTemplate.props[_random3].pic;
              data.query = "query";
              cc.vv.JJSdk.shareAppMessage(data);
              return;
            }
            wx.shareAppMessage({
              title: "\u80fd\u4e0d\u80fd\u4e2d\u5956\uff0c\u5168\u9760\u4f60\u7684\u8fd0\u6c14\u4e86\uff01",
              imageUrl: "https://src2.xyx.hlqps.com/szasx/share/share_props.png",
              success: function success() {
                console.log("\u5206\u4eab\u6210\u529f");
              },
              fail: function fail() {
                console.log("\u5206\u4eab\u5931\u8d25");
              }
            });
          } else {
            if (void 0 != shareTemplate.menu && shareTemplate.menu.length > 0) {
              var _random4 = Math.floor(Math.random() * shareTemplate.menu.length);
              var data = {};
              data.sceneId = shareTemplate.menu[_random4].id;
              data.title = shareTemplate.menu[_random4].title;
              data.imageUrl = shareTemplate.menu[_random4].pic;
              data.query = "query";
              cc.vv.JJSdk.shareAppMessage(data);
              return;
            }
            wx.shareAppMessage({
              title: "\u4e00\u6b65\u4e24\u6b65\u4f3c\u9b54\u9b3c\u7684\u6b65\u4f10\uff0c\u8fd9\u6e38\u620f\u5c31\u9002\u5408\u65e0\u804a\u73a9",
              imageUrl: "https://src2.xyx.hlqps.com/szasx/share/share_menu.png",
              success: function success() {
                console.log("\u5206\u4eab\u6210\u529f");
              },
              fail: function fail() {
                console.log("\u5206\u4eab\u5931\u8d25");
              }
            });
          }
        }
      },
      wxCreateBannerAd: function wxCreateBannerAd(arge, node) {
        if ("undefined" != typeof wx && wx.getSystemInfoSync().SDKVersion >= "2.0.4") {
          if (Globals._bannerAd) {
            Globals._bannerAd.destroy();
            Globals._bannerAd = null;
          }
          var _wx$getSystemInfoSync = wx.getSystemInfoSync(), screenWidth = _wx$getSystemInfoSync.screenWidth, screenHeight = _wx$getSystemInfoSync.screenHeight;
          var defaultHegiht = 99;
          var top = screenHeight;
          var adUnitId = "";
          var wxAdInfo = cc.vv.JJSdk.getWxAdInfo();
          if (void 0 != wxAdInfo.bannerAd && wxAdInfo.bannerAd.length > 0) {
            var random = Math.floor(Math.random() * wxAdInfo.bannerAd.length);
            adUnitId = wxAdInfo.bannerAd[random].unitId;
          } else adUnitId = "adunit-df18db266d5f3d6c";
          var style = {
            left: 0,
            top: 0,
            width: screenWidth
          };
          var bannerAd = wx.createBannerAd({
            adUnitId: adUnitId,
            style: style
          });
          bannerAd.onLoad(function(callback) {
            if (void 0 == callback || null == callback) {
              if (node) {
                var argeWorldPos = node.convertToWorldSpaceAR(cc.v2(0, 0));
                var height = argeWorldPos.y - node.height / 2 - 10;
                top -= (height - 2 * bannerAd.style.realHeight) / 2;
              }
              bannerAd.style.left = (screenWidth - bannerAd.style.realWidth) / 2 + .1;
              bannerAd.style.top = top - bannerAd.style.realHeight + .1;
              bannerAd.show();
            }
          });
          bannerAd.onError(function(errMsg) {
            console.log("B\u5e7f\u544a\u4e8b\u4ef6\u9519\u8bef", errMsg);
          });
          Globals._bannerAd = bannerAd;
        }
      },
      wxCreateVideoAd: function wxCreateVideoAd(arge) {
        Globals._videoAd = null;
        Globals.buttonMove = true;
        Globals.videoName = arge ? "videoWin_" + arge : "videoWin";
        if ("undefined" != typeof wx) {
          var adUnitId = "";
          var wxAdInfo = cc.vv.JJSdk.getWxAdInfo();
          if (void 0 != wxAdInfo.videoAd && wxAdInfo.videoAd.length > 0) {
            var random = Math.floor(Math.random() * wxAdInfo.videoAd.length);
            adUnitId = wxAdInfo.videoAd[random].unitId;
          } else adUnitId = "adunit-3fe0b919b5157caf";
          Globals._videoAd = wx.createRewardedVideoAd({
            adUnitId: adUnitId
          });
          Globals._videoAd.load().then(function() {
            return Globals._videoAd.show();
          }).catch(function(err) {
            return console.log(err.errMsg);
          });
          Globals._videoAd.onClose(function(res) {
            Globals._videoAd.offClose();
            if (res && res.isEnded || void 0 === res) {
              console.log("\u5e7f\u544a\u6b63\u5e38\u5173\u95ed");
              cc.vv.netRootjs.dispatchEvent(Globals.videoName);
            } else {
              console.log("\u5e7f\u544a\u672a\u6b63\u5e38\u5173\u95ed");
              "undefined" != typeof wx && (Globals._videoAd = null);
            }
          });
          Globals._videoAd.onError(function(errMsg) {
            "undefined" != typeof wx && console.log("\u5e7f\u544a\u62c9\u53d6\u5931\u8d25");
          });
        }
      },
      wxGetShareIntoInfo: function wxGetShareIntoInfo() {},
      wxCreatePlatform: function wxCreatePlatform(arge) {
        if ("undefined" == typeof wx) return;
        cc.vv.JJSdk.showScreenAd(arge);
        cc.vv.JJSdk.showDrawerAd(arge);
        cc.vv.JJSdk.showLeftFloatAd(arge);
        cc.vv.JJSdk.showRightFloatAd(arge, null, -60);
      },
      wxPlatformOff: function wxPlatformOff(arge) {
        if ("undefined" == typeof wx) return;
        cc.vv.JJSdk.hideDrawerAd(arge);
        cc.vv.JJSdk.hideRightFloatAd(arge);
        cc.vv.JJSdk.hideLeftFloatAd(arge);
        cc.vv.JJSdk.hideBannerAd(arge);
      }
    });
    cc._RF.pop();
  }, {} ],
  WxBridger: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e76de1Dd4RAdaCeamjx8Wrx", "WxBridger");
    "use strict";
    cc._RF.pop();
  }, {} ],
  ljjjb: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a6955ljxbpBNaflsHIduqwh", "ljjjb");
    "use strict";
    var _cc$Class;
    function _defineProperty(obj, key, value) {
      key in obj ? Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      }) : obj[key] = value;
      return obj;
    }
    cc.Class((_cc$Class = {
      extends: cc.Component,
      properties: {},
      setMoveInfo: function setMoveInfo() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = this.pathNodeArr[this.nodeIndex].node.parent.convertToWorldSpaceAR(this.pathNodeArr[this.nodeIndex].node.position), o = this.pathNodeArr[this.nodeIndex + 1].node.parent.convertToWorldSpaceAR(this.pathNodeArr[this.nodeIndex + 1].node.position);
        this.node.position = this.node.parent.convertToNodeSpaceAR(t);
        var i = o.sub(t).mag();
        this.totalTime = i / this.moveSpeed, this.bezierT = e, this.dir = this.pathNodeArr[this.nodeIndex + 1].node.position.sub(this.pathNodeArr[this.nodeIndex].node.position).normalize(), 
        this.node.position = this.node.position.add(this.dir.mul(e * this.moveSpeed));
      },
      addDebuff: function addDebuff(e) {
        for (var t = !0, o = 0; o < this.debuff.length; ++o) this.debuff[o].type == e.type && (t = !1, 
        e.buffTime >= this.debuff[o].buffTime && (this.debuff[o].buffTime = e.buffTime, 
        this.debuff[o].value = e.value));
        if (t) {
          var i = {};
          i.type = e.type, i.value = e.value, i.buffTime = e.buffTime, this.debuff.push(i);
        }
      },
      init: function init(e, t, o, i, n, s, r) {},
      initBlueBody: function initBlueBody() {
        this.body.getComponent("cc.Sprite").spriteFrame = cc.Mgr.assetMgr.loadAtlas("towerAtlas").getSpriteFrame("gw06"), 
        this.body.width = 122, this.body.height = 128;
        this.floatObj.stopAllActions(), this.floatObj.position = cc.v2(0, -20), this.floatObj.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(.1, 1.2, .7), cc.scaleTo(.05, 1, 1.1), cc.spawn(cc.moveTo(.1, cc.v2(0, 40)), cc.scaleTo(.1, .7, 1.2)), cc.delayTime(.08), cc.spawn(cc.scaleTo(.08, 1, 1), cc.moveTo(.08, cc.v2(0, -20))), cc.scaleTo(.04, .7, 1.2), cc.scaleTo(.04, 1, 1))));
      },
      addObstacleMethod: function addObstacleMethod(num, otherPos) {
        if (-1 == num) {
          otherPos.x += this._x_position;
          otherPos.y += this._y_position;
          window.obstaclePro = -1;
        } else {
          otherPos.x += -this._x_position;
          otherPos.y += this._y_position;
          window.obstaclePro = 1;
        }
        this.other_block = cc.instantiate(this.obstacleBlockPre[Math.floor(7 * Math.random())]);
        this.other_block.parent = this.scene;
        var obstacleNode = this.other_block.getChildByName("block");
        this.initBlockPoto(obstacleNode);
        if (false == Globals.initBlockNoLostAction) this.other_block.setPosition(otherPos.x, otherPos.y); else {
          this.other_block.setPosition(otherPos.x, otherPos.y);
          var blockMove = cc.moveTo(.1, cc.v2(otherPos.x, otherPos.y - 200));
          this.other_block.runAction(blockMove);
        }
        Globals.blockAllArr.push(this.other_block);
        Globals.obstacleChildArr.push(this.other_block);
        this.other_block.zIndex = this._zorderIndex;
        this._zorderIndex--;
      },
      setInputControl: function setInputControl() {
        var self = this;
        self.node.on("touchstart", self._jtcontrol = function(event) {
          if (true == Globals.isDie) return;
          if (false == self._gameBgein) {
            self._timerVarStatus = true;
            self._gameBgein = true;
            self._timerVarNum = 1e3;
          }
          var target = event.getLocation();
          var showSize = cc.winSize;
          target.x > showSize.width / 2 ? Globals.G_dir = 1 : Globals.G_dir = -1;
          self.playerNode.getComponent("Player").playJump(Globals.G_dir);
          self.move_map(Globals.G_dir);
          Globals.initBlockNoLostAction = true;
          self.scoreDisplay.string = Globals.scoreNum;
          self.stepNull();
          self.addBlockMethod();
          self.difficult();
        }, self);
      },
      initBlockPoto: function initBlockPoto(node) {
        true == Globals.blockBingStatus ? node.getComponent(cc.Sprite).spriteFrame = this.blockPoto[1] : false == Globals.blockBingStatus && (node.getComponent(cc.Sprite).spriteFrame = this.blockPoto[Globals.SJBlockPoto]);
      }
    }, _defineProperty(_cc$Class, "setMoveInfo", function setMoveInfo() {
      var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = this.pathNodeArr[this.nodeIndex].node.parent.convertToWorldSpaceAR(this.pathNodeArr[this.nodeIndex].node.position), o = this.pathNodeArr[this.nodeIndex + 1].node.parent.convertToWorldSpaceAR(this.pathNodeArr[this.nodeIndex + 1].node.position);
      this.node.position = this.node.parent.convertToNodeSpaceAR(t);
      var i = o.sub(t).mag();
      this.totalTime = i / this.moveSpeed, this.bezierT = e, this.dir = this.pathNodeArr[this.nodeIndex + 1].node.position.sub(this.pathNodeArr[this.nodeIndex].node.position).normalize(), 
      this.node.position = this.node.position.add(this.dir.mul(e * this.moveSpeed));
    }), _defineProperty(_cc$Class, "addDebuff", function addDebuff(e) {
      for (var t = !0, o = 0; o < this.debuff.length; ++o) this.debuff[o].type == e.type && (t = !1, 
      e.buffTime >= this.debuff[o].buffTime && (this.debuff[o].buffTime = e.buffTime, 
      this.debuff[o].value = e.value));
      if (t) {
        var i = {};
        i.type = e.type, i.value = e.value, i.buffTime = e.buffTime, this.debuff.push(i);
      }
    }), _defineProperty(_cc$Class, "start", function start() {}), _defineProperty(_cc$Class, "move_map", function move_map(num) {
      if (1 == num) {
        var x_position = -this._x_position;
        var y_position = -this._y_position;
      } else if (-1 == num) {
        var x_position = this._x_position;
        var y_position = -this._y_position;
      } else if (-2 == num) {
        var x_position = -this._x_position;
        var y_position = this._y_position;
      } else if (2 == num) {
        var x_position = this._x_position;
        var y_position = this._y_position;
      }
      var m1 = cc.moveBy(.3, x_position, y_position);
      this.node.getChildByName("scene").runAction(m1);
    }), _defineProperty(_cc$Class, "setInputControl", function setInputControl() {
      var self = this;
      self.node.on("touchstart", self._jtcontrol = function(event) {
        if (true == Globals.isDie) return;
        if (false == self._gameBgein) {
          self._timerVarStatus = true;
          self._gameBgein = true;
          self._timerVarNum = 1e3;
        }
        var target = event.getLocation();
        var showSize = cc.winSize;
        target.x > showSize.width / 2 ? Globals.G_dir = 1 : Globals.G_dir = -1;
        self.playerNode.getComponent("Player").playJump(Globals.G_dir);
        self.move_map(Globals.G_dir);
        Globals.initBlockNoLostAction = true;
        self.scoreDisplay.string = Globals.scoreNum;
        self.stepNull();
        self.addBlockMethod();
        self.difficult();
      }, self);
    }), _defineProperty(_cc$Class, "difficult", function difficult() {
      3 == Globals.scoreNum ? this._timerVarNum = 500 : 31 == Globals.scoreNum ? this._timerVarNum = 400 : 61 == Globals.scoreNum ? this._timerVarNum = 300 : 101 == Globals.scoreNum && (this._timerVarNum = 280);
    }), _defineProperty(_cc$Class, "introduceInitBtn", function introduceInitBtn() {
      var self = this;
      self.node.getChildByName("introduce").active = false;
      false == self.node.getChildByName("introduce").active && self.setInputControl();
    }), _defineProperty(_cc$Class, "closeFeiShengMethod", function closeFeiShengMethod() {
      Globals.feiShenNum++;
      var playAnim = this.playerNode.getChildByName("anim");
      var playPZ = this.scene.getChildByName("player");
      if (Globals.feiShenNum > 25) {
        this.unschedule(this.closeFeiShengMethod);
        playPZ.group = "player";
        playAnim.active = false;
        Globals.feishengOpenVideo = false;
        this.node.on("touchstart", this._jtcontrol, this);
        return;
      }
      playAnim.active = true;
      cc.vv.method.animationSet(playAnim, "chongji");
      cc.vv.netRootjs.musicPlay(6, false, .2);
      this.addBlockMethod();
      var blockDirLenght = Globals.blockDirArr.length;
      var playerDirLenght = Globals.playerDirArr.length;
      var lastArray = Globals.blockDirArr.slice(playerDirLenght, blockDirLenght - 5);
      var num;
      lastArray[0] > 0 ? num = 1 : lastArray[0] < 0 && (num = -1);
      this.playerNode.getComponent("Player").playJump(num);
      this.move_map(num);
      Globals.scoreNum = Globals.scoreNum + 3;
      this.scoreDisplay.string = Globals.scoreNum;
    }), _defineProperty(_cc$Class, "setCurScene", function setCurScene(e) {
      this.save.info.curScene = e, this.saveSceneData();
    }), _defineProperty(_cc$Class, "backspaceWave", function backspaceWave() {
      var e = this.save.info.curScene;
      this.save.scene[e].wave -= 2, this.save.scene[e].wave < 1 && (this.save.scene[e].wave = 1), 
      this.saveSceneData();
    }), _defineProperty(_cc$Class, "useDefaultSave", function useDefaultSave() {
      for (var e in this.save = {}, this.save.info = {}, this.save.info.money = 12, this.save.info.exp = 0, 
      this.save.info.level = 1, this.save.info.diamond = 0, this.save.info.curGuideId = 1, 
      this.save.info.guideDataList = [], this.save.info.curScene = 1, this.save.info.signTime = 0, 
      this.save.info.loginTime = 0, this.save.info.offlineTime = new Date().getTime() / 1e3, 
      this.save.info.signNum = 0, this.save.info.luckyMoneyNum = 0, this.save.info.oldLuckyMoneyNum = 0, 
      this.save.info.getLuckyTime = 0, this.save.info.loginDay = 0, this.save.info.dayProregativeAwardstate = !0, 
      this.save.info.autoMergeTime = 0, this.save.info.proregativeFriendData = [], this.save.info.proregativeFriendNum = 0, 
      this.save.info.todayLuckFriendNum = 0, this.save.info.diamondNotEnoughTime = 0, 
      this.save.info.moneyNotEnoughTime = 0, this.save.info.costDiamondOfBox = 0, this.save.info.timeLimitBoxTimes = 0, 
      this.save.info.timeLimitBoxTime = 0, this.save.info.autoMergePauseTime = 0, this.save.info.newEnemyTips = [ 0, 0, 0, 0 ], 
      this.save.info.dialShareAndVideoTimes = 0, this.save.info.proregativeGetArr = [], 
      this.save.info.isPopupGameIntroduce = !1, this.save.info.isGotFreeBox = !1, this.save.info.isOpenCardBtn = !1, 
      this.save.info.isOpenShopBtn = !1, this.save.info.towerIntroduce = [ 1, 0, 0, 0 ], 
      this.save.info.uploadData = 1, this.save.info.doubleMoney = 0, this.save.info.doubleSpeed = 0, 
      this.save.info.freeUpTower = 0, this.save.info.isOpenBoxMonster = !1, this.save.info.boxMonsterTodayNum = 0, 
      this.save.info.bubbleState = !0, this.save.info.highTowerAdTimes = 0, this.save.info.badgeNum = 0, 
      this.save.info.badgeAwardTimes = 0, this.save.info.dailyTask = {}, this.save.info.taskProgress = {}, 
      this.save.info.completeTask = {}, this.save.info.trialIndexList = [], this.save.info.defaultFirst = !0, 
      this.save.info.isOpenAutoMerge = !1, this.save.info.isOpenDoubleBtn = !1, this.save.scene = {}, 
      cc.Mgr.cfgMgr.t_chapter) this.initNewMapData(e);
      for (var t in this.save.card = {}, this.save.card.battleTower = {
        1: 101,
        2: 0,
        3: 0,
        4: 0
      }, this.save.card.upgradeLevel = 1, this.save.card.isNewCard = !1, this.save.card.upgradeFrag = 0, 
      cc.Mgr.cfgMgr.t_tower) {
        var o = Math.floor(t / 100);
        null == this.save.card[o] && (this.save.card[o] = {}), this.save.card[o][t] = {
          id: cc.Mgr.cfgMgr.t_tower[t].id,
          star: 0,
          num: 0,
          new: !1
        };
      }
      this.save.card[1][101].star = 1, this.save.card[1][101].new = !1, this.saveSceneData(), 
      this.saveCardData(), this.saveInfoData(), this.registerOffline();
    }), _defineProperty(_cc$Class, "getDefaultFirstState", function getDefaultFirstState() {
      return void 0 == this.save.info.defaultFirst && (this.save.info.defaultFirst = !0), 
      this.save.info.defaultFirst;
    }), _defineProperty(_cc$Class, "setDoubleBtnState", function setDoubleBtnState() {}), 
    _defineProperty(_cc$Class, "getUpgradeFrag", function getUpgradeFrag() {
      return this.save.card.upgradeFrag;
    }), _defineProperty(_cc$Class, "isHaveNewCard", function isHaveNewCard() {
      return this.save.card.isNewCard;
    }), _defineProperty(_cc$Class, "setNewCardTipsState", function setNewCardTipsState() {
      this.save.card.isNewCard = !1, this.saveCardData();
    }), _defineProperty(_cc$Class, "getCardTypeNum", function getCardTypeNum() {
      var e = 0;
      for (var t in this.save.card) for (var o in this.save.card[t]) this.save.card[t][o].star && e++;
      return e;
    }), _defineProperty(_cc$Class, "addLuckyMoney", function addLuckyMoney(e) {
      void 0 == this.save.info.luckyMoneyNum && (this.save.info.luckyMoneyNum = 0), this.save.info.luckyMoneyNum += e, 
      this.saveInfoData();
    }), _defineProperty(_cc$Class, "useLuckyMoney", function useLuckyMoney(e) {
      return void 0 == this.save.info.luckyMoneyNum && (this.save.info.luckyMoneyNum = 0), 
      this.save.info.luckyMoneyNum >= e && (this.save.info.luckyMoneyNum -= e, this.saveInfoData(), 
      !0);
    }), _defineProperty(_cc$Class, "getOldLuckyMoney", function getOldLuckyMoney() {
      return void 0 == this.save.info.oldLuckyMoneyNum && (this.save.info.oldLuckyMoneyNum = 0), 
      this.save.info.oldLuckyMoneyNum;
    }), _defineProperty(_cc$Class, "tileAt", function tileAt(row, col) {
      if (row < 0 || row >= gameOptions.fieldSize || col < 0 || col >= gameOptions.fieldSize) return false;
      return this.tileArray[row][col];
    }), _defineProperty(_cc$Class, "isHorizontalMatch", function isHorizontalMatch(row, col) {
      return this.tileAt(row, col).tileValue == this.tileAt(row, col - 1).tileValue && this.tileAt(row, col).tileValue == this.tileAt(row, col - 2).tileValue;
    }), _defineProperty(_cc$Class, "isVerticalMatch", function isVerticalMatch(row, col) {
      return this.tileAt(row, col).tileValue == this.tileAt(row - 1, col).tileValue && this.tileAt(row, col).tileValue == this.tileAt(row - 2, col).tileValue;
    }), _defineProperty(_cc$Class, "isMatch", function isMatch(row, col) {
      return this.isHorizontalMatch(row, col) || this.isVerticalMatch(row, col);
    }), _defineProperty(_cc$Class, "matchInBoard", function matchInBoard() {
      for (var i = 0; i < gameOptions.fieldSize; i++) for (var j = 0; j < gameOptions.fieldSize; j++) if (this.isMatch(i, j)) return true;
      return false;
    }), _defineProperty(_cc$Class, "countSpacesBelow", function countSpacesBelow(row, col) {
      var result = 0;
      for (var i = row + 1; i < gameOptions.fieldSize; i++) this.tileArray[i][col].isEmpty && result++;
      return result;
    }), _defineProperty(_cc$Class, "create", function create() {
      gameover = false;
      var bg = this.add.image(0, 0, "bg").setOrigin(0);
      bg.width = game.config.width;
      bg.height = game.config.height;
      bottle = this.physics.add.sprite(0, 0, "bottle").setOrigin(.5).setScale(.2);
      bottle.body.offset.set(2 * bottle.width, 0);
      bottle.isRotation = true;
      bottle.x = (game.config.width - bottle.width * bottle.scaleX) / 1.85;
      bottle.y = (game.config.height - bottle.height * bottle.scaleY) / 4;
      bottle.on("pointerdown", function(pointer) {});
      this.input.on("pointerdown", function(pointer) {
        bottle.isRotation = false;
        bottle.body.gravity.y = 500;
      });
      tables = this.physics.add.staticGroup();
      tablel = tables.create(320 - 560 / 1.67, 305, "tablel").setScale(.5);
      tabler = tables.create(560 / 1.49, 305, "tabler").setScale(.5);
      scoreText = this.add.text(0, 0, score);
      scoreText.setColor("#0");
      scoreText.setFontSize(36);
      Phaser.Display.Align.In.TopRight(scoreText, bg);
    }), _defineProperty(_cc$Class, "addOldLuckyMoney", function addOldLuckyMoney(e) {
      void 0 == this.save.info.oldLuckyMoneyNum && (this.save.info.oldLuckyMoneyNum = 0), 
      this.save.info.oldLuckyMoneyNum += e, this.saveInfoData();
    }), _defineProperty(_cc$Class, "getGetedLuckyMoneyTime", function getGetedLuckyMoneyTime() {
      return void 0 == this.save.info.getLuckyTime && (this.save.info.getLuckyTime = 0), 
      this.save.info.getLuckyTime;
    }), _defineProperty(_cc$Class, "addGetedLuckyMoneyTime", function addGetedLuckyMoneyTime(e) {
      void 0 == this.save.info.getLuckyTime && (this.save.info.getLuckyTime = 0), this.save.info.getLuckyTime += e, 
      this.saveInfoData();
    }), _defineProperty(_cc$Class, "calTowerPrice", function calTowerPrice() {
      var e = this.save.info.curScene, t = this.save.scene[e].round, o = this.save.scene[this.save.info.curScene].wave, i = cc.Mgr.cfgMgr.getChapterConfig(e), n = cc.Mgr.cfgMgr.getTollgateConfig(i.tollgateList[t - 1][o - 1]).round, s = this.getProregativeFriendData();
      s >= cc.Mgr.main.ppCfg.proregativeCfg.length && (s = cc.Mgr.main.ppCfg.proregativeCfg.length - 1);
      var r = cc.Mgr.main.ppCfg.proregativeCfg[s][2] > 0 ? cc.Mgr.main.ppCfg.proregativeCfg[s][2] / 10 : 1;
      return Math.round(this.save.card.upgradeLevel * Math.pow(1.02, n) * 3 * r);
    }), _defineProperty(_cc$Class, "calOtherLvTowerPrice", function calOtherLvTowerPrice(e) {
      var t = this.save.info.curScene, o = this.save.scene[t].round, i = this.save.scene[this.save.info.curScene].wave, n = cc.Mgr.cfgMgr.getChapterConfig(t), s = cc.Mgr.cfgMgr.getTollgateConfig(n.tollgateList[o - 1][i - 1]).round, r = this.getProregativeFriendData();
      r >= cc.Mgr.main.ppCfg.proregativeCfg.length && (r = cc.Mgr.main.ppCfg.proregativeCfg.length - 1);
      var c = cc.Mgr.main.ppCfg.proregativeCfg[r][2] > 0 ? cc.Mgr.main.ppCfg.proregativeCfg[r][2] / 10 : 1;
      return Math.round(e * Math.pow(1.02, s) * 3 * c);
    }), _defineProperty(_cc$Class, "touchEnd", function touchEnd() {
      if (0 == this.playerJ.status) {
        this._isTouching = false;
        this.pBody.stopAction(this.act1);
        this.pBody.runAction(this.act2);
        this.pHead.stopAction(this.act3);
        this.pHead.runAction(this.act4);
        this.jumpToTarget();
      }
    }), _defineProperty(_cc$Class, "jumpToTarget", function jumpToTarget() {
      this.playerJ.status = 1;
      var base = this.player.position;
      var target = this.pTarget.position;
      var direction = target.sub(base).normalize();
      var jumpTarget = base.add(direction.mul(300 * this._timer));
      var jumpAction = cc.moveTo(.5, jumpTarget);
      var finished = cc.callFunc(this.jumpFinished, this);
      var seq = cc.sequence(jumpAction, finished);
      this.player.runAction(seq);
    }), _defineProperty(_cc$Class, "preload", function preload() {
      game.load.image("prize1", "assets/prize.png");
      game.load.image("prize2", "assets/pig.png");
      game.load.image("prize3", "assets/prize.png");
      game.load.image("prize4", "assets/pig.png");
      game.load.image("prize", "assets/pig.png");
      game.load.image("slingshot", "assets/slingshot.png");
      game.load.image("slingshota", "assets/slingshota.png");
      game.load.image("cloth", "assets/cloth.png");
      game.load.image("bg", "assets/bg.jpg");
      game.load.spritesheet("bullet", "assets/bullet.png", 196, 205);
      game.load.spritesheet("player", "assets/baddie.png", 32, 32, 4);
      game.load.spritesheet("man", "assets/spaceman.png", 16, 16);
      game.load.spritesheet("dude", "assets/dude.png", 32, 48);
      game.load.spritesheet("myexplode", "assets/myexplode.png", 40, 40, 3);
      game.load.audio("attack", [ "assets/audio/attack_boss.mp3" ]);
      game.load.audio("try_mp3", [ "assets/audio/try.mp3" ]);
      game.load.audio("courtship_mask", [ "assets/audio/courtship_mask.mp3" ]);
      game.load.audio("win_pig", [ "assets/audio/win_pig.mp3" ]);
      game.scale.scaleMode = Phaser.ScaleManager.USER_SCALE;
    }), _defineProperty(_cc$Class, "changeBall", function changeBall() {
      this.destroy = false;
      var distanceFromTarget = this.balls[this.rotatingBall].position.distance(this.targetArray[1].position);
      if (distanceFromTarget < 20) {
        this.rotatingDirection = game.rnd.between(0, 1);
        var detroyTween = game.add.tween(this.targetArray[0]).to({
          alpha: 0
        }, 500, Phaser.Easing.Cubic.In, true);
        detroyTween.onComplete.add(function(e) {
          e.destroy();
        });
        this.targetArray.shift();
        this.arm.position = this.balls[this.rotatingBall].position;
        this.rotatingBall = 1 - this.rotatingBall;
        this.rotationAngle = this.balls[1 - this.rotatingBall].position.angle(this.balls[this.rotatingBall].position, true) - 90;
        this.arm.angle = this.rotationAngle + 90;
        for (var i = 0; i < this.targetArray.length; i++) this.targetArray[i].alpha += 1 / 7;
        this.addTarget();
      } else this.gameOver();
    }), _defineProperty(_cc$Class, "gameOver", function gameOver() {
      localStorage.setItem("circlepath", JSON.stringify({
        score: Math.max(this.savedData.score, this.steps - visibleTargets)
      }));
      game.input.onDown.remove(this.changeBall, this);
      this.saveRotationSpeed = 0;
      this.arm.destroy();
      var gameOverTween = game.add.tween(this.balls[1 - this.rotatingBall]).to({
        alpha: 0
      }, 1e3, Phaser.Easing.Cubic.Out, true);
      gameOverTween.onComplete.add(function() {
        game.state.start("PlayGame");
      }, this);
    }), _defineProperty(_cc$Class, "CrazyBird", function CrazyBird() {
      for (var i = 0; i < this.gameState.tileObjects.length; i++) {
        var tileBody = this.gameState.tileObjects[i];
        tileBody.setCollisionGroup(this.gameState.collideGroups["tiles"]);
        tileBody.collides([ this.gameState.collideGroups["bird"] ]);
        this.tileMaterial = game.physics.p2.createMaterial("tileMaterial", tileBody);
        this.contactMaterial = game.physics.p2.createContactMaterial(this.gameState.bird.birdMaterial, this.tileMaterial);
        this.contactMaterial.restitution = 0;
        this.contactMaterial.friction = 0;
        this.contactMaterial.relaxation = 200;
      }
    }), _defineProperty(_cc$Class, "prototype", function prototype(type, map, layer) {
      var result = new Array();
      map.objects[layer].forEach(function(element) {
        element.properties.type === type && result.push(element);
      });
      return result;
    }), _defineProperty(_cc$Class, "Level", function Level(player, fruit) {
      fruit.body.enable = false;
      this.add.tween(fruit).to({
        y: fruit.y - 50
      }, 1e3, "Expo.easeOut", true);
      this.add.tween(fruit.scale).to({
        x: 2,
        y: 2
      }, 1e3, "Linear", true);
      this.add.tween(fruit).to({
        alpha: .2
      }, 1e3, "Linear", true).onComplete.add(fruit.kill, fruit);
    }), _defineProperty(_cc$Class, "addTempTile", function addTempTile() {
      this.tempTile = game.add.sprite(0, 0, "tiles");
      this.tempTile.width = gameOptions.tileSize;
      this.tempTile.height = gameOptions.tileSize;
      this.tempTile.visible = false;
      this.tileGroup.add(this.tempTile);
    }), _defineProperty(_cc$Class, "pickTile", function pickTile(e) {
      this.movingRow = Math.floor((e.position.y - gameOptions.offsetY) / gameOptions.tileSize);
      this.movingCol = Math.floor((e.position.x - gameOptions.offsetX) / gameOptions.tileSize);
      if (this.movingRow >= 0 && this.movingCol >= 0 && this.movingRow < gameOptions.fieldSize && this.movingCol < gameOptions.fieldSize) {
        this.dragDirection = NO_DRAG;
        game.input.onDown.remove(this.pickTile, this);
        game.input.onUp.add(this.releaseTile, this);
        game.input.addMoveCallback(this.moveTile, this);
      }
    }), _defineProperty(_cc$Class, "handleMatches", function handleMatches() {
      this.tilesToRemove = [];
      for (var i = 0; i < gameOptions.fieldSize; i++) {
        this.tilesToRemove[i] = [];
        for (var j = 0; j < gameOptions.fieldSize; j++) this.tilesToRemove[i][j] = 0;
      }
      this.handleHorizontalMatches();
      this.handleVerticalMatches();
      for (var i = 0; i < gameOptions.fieldSize; i++) for (var j = 0; j < gameOptions.fieldSize; j++) if (0 != this.tilesToRemove[i][j]) {
        var tween = game.add.tween(this.tileArray[i][j].tileSprite).to({
          alpha: 0
        }, gameOptions.fadeSpeed, Phaser.Easing.Linear.None, true);
        this.tilePool.push(this.tileArray[i][j].tileSprite);
        tween.onComplete.add(function(e) {
          1 == tween.manager.getAll().length && this.fillVerticalHoles();
        }, this);
        this.tileArray[i][j].isEmpty = true;
      }
    }), _defineProperty(_cc$Class, "fillVerticalHoles", function fillVerticalHoles() {
      for (var i = gameOptions.fieldSize - 2; i >= 0; i--) for (var j = 0; j < gameOptions.fieldSize; j++) if (!this.tileArray[i][j].isEmpty) {
        var holesBelow = this.countSpacesBelow(i, j);
        holesBelow && this.moveDownTile(i, j, i + holesBelow, false);
      }
      for (i = 0; i < gameOptions.fieldSize; i++) {
        var topHoles = this.countSpacesBelow(-1, i);
        for (j = topHoles - 1; j >= 0; j--) {
          var reusedTile = this.tilePool.shift();
          reusedTile.y = (j - topHoles) * gameOptions.tileSize;
          reusedTile.x = i * gameOptions.tileSize;
          reusedTile.alpha = 1;
          var randomTile = game.rnd.integerInRange(0, gameOptions.tileTypes - 1);
          reusedTile.frame = randomTile;
          this.tileArray[j][i] = {
            tileSprite: reusedTile,
            tileValue: randomTile,
            isEmpty: false
          };
          this.moveDownTile(0, i, j, true);
        }
      }
    }), _defineProperty(_cc$Class, "moveDownTile", function moveDownTile(fromRow, fromCol, toRow, justMove) {
      if (!justMove) {
        var spriteSave = this.tileArray[fromRow][fromCol].tileSprite;
        var valueSave = this.tileArray[fromRow][fromCol].tileValue;
        this.tileArray[toRow][fromCol] = {
          tileSprite: spriteSave,
          tileValue: valueSave,
          isEmpty: false
        };
        this.tileArray[fromRow][fromCol].isEmpty = true;
      }
      var distanceToTravel = toRow - this.tileArray[toRow][fromCol].tileSprite.y / gameOptions.tileSize;
      var tween = game.add.tween(this.tileArray[toRow][fromCol].tileSprite).to({
        y: toRow * gameOptions.tileSize
      }, distanceToTravel * gameOptions.fallSpeed, Phaser.Easing.Linear.None, true);
      tween.onComplete.add(function() {
        1 == tween.manager.getAll().length && (this.matchInBoard() ? this.handleMatches() : game.input.onDown.add(this.pickTile, this));
      }, this);
    }), _defineProperty(_cc$Class, "handleHorizontalMatches", function handleHorizontalMatches() {
      for (var i = 0; i < gameOptions.fieldSize; i++) {
        var colorStreak = 1;
        var currentColor = -1;
        var startStreak = 0;
        for (var j = 0; j < gameOptions.fieldSize; j++) {
          this.tileAt(i, j).tileValue == currentColor && colorStreak++;
          if (this.tileAt(i, j).tileValue != currentColor || j == gameOptions.fieldSize - 1) {
            if (colorStreak > 2) {
              var endStreak = j - 1;
              this.tileAt(i, j).tileValue == currentColor && (endStreak = j);
              for (var k = startStreak; k <= endStreak; k++) this.tilesToRemove[i][k]++;
            }
            currentColor = this.tileAt(i, j).tileValue;
            colorStreak = 1;
            startStreak = j;
          }
        }
      }
    }), _defineProperty(_cc$Class, "handleVerticalMatches", function handleVerticalMatches() {
      for (var i = 0; i < gameOptions.fieldSize; i++) {
        var colorStreak = 1;
        var currentColor = -1;
        var startStreak = 0;
        for (var j = 0; j < gameOptions.fieldSize; j++) {
          this.tileAt(j, i).tileValue == currentColor && colorStreak++;
          if (this.tileAt(j, i).tileValue != currentColor || j == gameOptions.fieldSize - 1) {
            if (colorStreak > 2) {
              var endStreak = j - 1;
              this.tileAt(j, i).tileValue == currentColor && (endStreak = j);
              for (var k = startStreak; k <= endStreak; k++) this.tilesToRemove[k][i]++;
            }
            currentColor = this.tileAt(j, i).tileValue;
            colorStreak = 1;
            startStreak = j;
          }
        }
      }
    }), _defineProperty(_cc$Class, "moveTile", function moveTile(e) {
      this.gameState = GAME_STATE_DRAG;
      this.distX = e.position.x - e.positionDown.x;
      this.distY = e.position.y - e.positionDown.y;
      if (this.dragDirection == NO_DRAG) {
        var distance = e.position.distance(e.positionDown);
        if (distance > 5) {
          var dragAngle = Math.abs(Math.atan2(this.distY, this.distX));
          dragAngle > Math.PI / 4 && dragAngle < 3 * Math.PI / 4 ? this.dragDirection = VERTICAL_DRAG : this.dragDirection = HORIZONTAL_DRAG;
        }
      }
    }), _defineProperty(_cc$Class, "releaseTile", function releaseTile() {
      this.gameState = GAME_STATE_STOP;
      game.input.onUp.remove(this.releaseTile, this);
      game.input.deleteMoveCallback(this.moveTile, this);
    }), _defineProperty(_cc$Class, "tileAt", function tileAt(row, col) {
      if (row < 0 || row >= gameOptions.fieldSize || col < 0 || col >= gameOptions.fieldSize) return false;
      return this.tileArray[row][col];
    }), _defineProperty(_cc$Class, "isHorizontalMatch", function isHorizontalMatch(row, col) {
      return this.tileAt(row, col).tileValue == this.tileAt(row, col - 1).tileValue && this.tileAt(row, col).tileValue == this.tileAt(row, col - 2).tileValue;
    }), _defineProperty(_cc$Class, "isVerticalMatch", function isVerticalMatch(row, col) {
      return this.tileAt(row, col).tileValue == this.tileAt(row - 1, col).tileValue && this.tileAt(row, col).tileValue == this.tileAt(row - 2, col).tileValue;
    }), _defineProperty(_cc$Class, "isMatch", function isMatch(row, col) {
      return this.isHorizontalMatch(row, col) || this.isVerticalMatch(row, col);
    }), _defineProperty(_cc$Class, "matchInBoard", function matchInBoard() {
      for (var i = 0; i < gameOptions.fieldSize; i++) for (var j = 0; j < gameOptions.fieldSize; j++) if (this.isMatch(i, j)) return true;
      return false;
    }), _defineProperty(_cc$Class, "countSpacesBelow", function countSpacesBelow(row, col) {
      var result = 0;
      for (var i = row + 1; i < gameOptions.fieldSize; i++) this.tileArray[i][col].isEmpty && result++;
      return result;
    }), _defineProperty(_cc$Class, "create", function create() {
      gameover = false;
      var bg = this.add.image(0, 0, "bg").setOrigin(0);
      bg.width = game.config.width;
      bg.height = game.config.height;
      bottle = this.physics.add.sprite(0, 0, "bottle").setOrigin(.5).setScale(.2);
      bottle.body.offset.set(2 * bottle.width, 0);
      bottle.isRotation = true;
      bottle.x = (game.config.width - bottle.width * bottle.scaleX) / 1.85;
      bottle.y = (game.config.height - bottle.height * bottle.scaleY) / 4;
      bottle.on("pointerdown", function(pointer) {});
      this.input.on("pointerdown", function(pointer) {
        bottle.isRotation = false;
        bottle.body.gravity.y = 500;
      });
      tables = this.physics.add.staticGroup();
      tablel = tables.create(320 - 560 / 1.67, 305, "tablel").setScale(.5);
      tabler = tables.create(560 / 1.49, 305, "tabler").setScale(.5);
      scoreText = this.add.text(0, 0, score);
      scoreText.setColor("#0");
      scoreText.setFontSize(36);
      Phaser.Display.Align.In.TopRight(scoreText, bg);
    }), _defineProperty(_cc$Class, "homeGroupAnim", function homeGroupAnim() {
      this.homeGroup = game.add.group();
      this.home_mask = game.add.image(0, 0, "home-mask");
      this.logo = game.add.image(20, 0, "logo");
      this.homeGroup.addChild(this.home_mask);
      this.homeGroup.addChild(this.logo);
      this.homeGroup.y = -this.home_mask.height;
      this.homeGroupTween = game.add.tween(this.homeGroup).to({
        y: 0
      }, 400, Phaser.Easing.Sinusoidal.InOut, true);
      this.homeGroupTween.onComplete.add(this.titleAnim, this);
    }), _defineProperty(_cc$Class, "titleAnim", function titleAnim() {
      this.ninja = game.add.image(328, 0, "ninja");
      this.ninja.y = -this.ninja.height;
      this.ninjaTween = game.add.tween(this.ninja).to({
        y: 40
      }, 500, Phaser.Easing.Bounce.Out, true);
      this.ninjaTween.onComplete.add(this.homeDescAnim, this);
    }), _defineProperty(_cc$Class, "group", function group(contents, opts) {
      opts = opts || {};
      return {
        type: "group",
        id: opts.id,
        contents: contents,
        break: !!opts.shouldBreak,
        expandedStates: opts.expandedStates
      };
    }), _defineProperty(_cc$Class, "dedentToRoot", function dedentToRoot(contents) {
      return align(-Infinity, contents);
    }), _defineProperty(_cc$Class, "markAsRoot", function markAsRoot(contents) {
      return align({
        type: "root"
      }, contents);
    }), _defineProperty(_cc$Class, "conditionalGroup", function conditionalGroup(states, opts) {
      return group(states[0], Object.assign(opts || {}, {
        expandedStates: states
      }));
    }), _defineProperty(_cc$Class, "fill", function fill(parts) {
      return {
        type: "fill",
        parts: parts
      };
    }), _defineProperty(_cc$Class, "ifBreak", function ifBreak(breakContents, flatContents, opts) {
      opts = opts || {};
      return {
        type: "if-break",
        breakContents: breakContents,
        flatContents: flatContents,
        groupId: opts.groupId
      };
    }), _defineProperty(_cc$Class, "createCommonjsModule", function createCommonjsModule(fn, module) {
      return module = {
        exports: {}
      }, fn(module, module.exports), module.exports;
    }), _defineProperty(_cc$Class, "getParentExportDeclaration", function getParentExportDeclaration(path) {
      var parentNode = path.getParentNode();
      if ("declaration" === path.getName() && isExportDeclaration(parentNode)) return parentNode;
      return null;
    }), _defineProperty(_cc$Class, "getPenultimate", function getPenultimate(arr) {
      if (arr.length > 1) return arr[arr.length - 2];
      return null;
    }), _defineProperty(_cc$Class, "hasNewline", function hasNewline(text, index, opts) {
      opts = opts || {};
      var idx = skipSpaces(text, opts.backwards ? index - 1 : index, opts);
      var idx2 = skipNewline(text, idx, opts);
      return idx !== idx2;
    }), _defineProperty(_cc$Class, "hasNewlineInRange", function hasNewlineInRange(text, start, end) {
      for (var i = start; i < end; ++i) if ("\n" === text.charAt(i)) return true;
      return false;
    }), _defineProperty(_cc$Class, "hasSpaces", function hasSpaces(text, index, opts) {
      opts = opts || {};
      var idx = skipSpaces(text, opts.backwards ? index - 1 : index, opts);
      return idx !== index;
    }), _defineProperty(_cc$Class, "setLocStart", function setLocStart(node, index) {
      node.range ? node.range[0] = index : node.start = index;
    }), _defineProperty(_cc$Class, "setLocEnd", function setLocEnd(node, index) {
      node.range ? node.range[1] = index : node.end = index;
    }), _defineProperty(_cc$Class, "startsWithNoLookaheadToken", function(_startsWithNoLookaheadToken) {
      function startsWithNoLookaheadToken(_x, _x2) {
        return _startsWithNoLookaheadToken.apply(this, arguments);
      }
      startsWithNoLookaheadToken.toString = function() {
        return _startsWithNoLookaheadToken.toString();
      };
      return startsWithNoLookaheadToken;
    }(function(node, forbidFunctionClassAndDoExpr) {
      node = getLeftMost(node);
      switch (node.type) {
       case "FunctionExpression":
       case "ClassExpression":
       case "DoExpression":
        return forbidFunctionClassAndDoExpr;

       case "ObjectExpression":
        return true;

       case "MemberExpression":
        return startsWithNoLookaheadToken(node.object, forbidFunctionClassAndDoExpr);

       case "TaggedTemplateExpression":
        if ("FunctionExpression" === node.tag.type) return false;
        return startsWithNoLookaheadToken(node.tag, forbidFunctionClassAndDoExpr);

       case "CallExpression":
        if ("FunctionExpression" === node.callee.type) return false;
        return startsWithNoLookaheadToken(node.callee, forbidFunctionClassAndDoExpr);

       case "ConditionalExpression":
        return startsWithNoLookaheadToken(node.test, forbidFunctionClassAndDoExpr);

       case "UpdateExpression":
        return !node.prefix && startsWithNoLookaheadToken(node.argument, forbidFunctionClassAndDoExpr);

       case "BindExpression":
        return node.object && startsWithNoLookaheadToken(node.object, forbidFunctionClassAndDoExpr);

       case "SequenceExpression":
        return startsWithNoLookaheadToken(node.expressions[0], forbidFunctionClassAndDoExpr);

       case "TSAsExpression":
        return startsWithNoLookaheadToken(node.expression, forbidFunctionClassAndDoExpr);

       default:
        return false;
      }
    })), _defineProperty(_cc$Class, "getAlignmentSize", function getAlignmentSize(value, tabWidth, startIndex) {
      startIndex = startIndex || 0;
      var size = 0;
      for (var i = startIndex; i < value.length; ++i) "\t" === value[i] ? size = size + tabWidth - size % tabWidth : size++;
      return size;
    }), _defineProperty(_cc$Class, "printString", function printString(raw, options, isDirectiveLiteral) {
      var rawContent = raw.slice(1, -1);
      var canChangeDirectiveQuotes = !rawContent.includes('"') && !rawContent.includes("'");
      var enclosingQuote = "json" === options.parser ? '"' : options.__isInHtmlAttribute ? "'" : getPreferredQuote(raw, options.singleQuote ? "'" : '"');
      if (isDirectiveLiteral) {
        if (canChangeDirectiveQuotes) return enclosingQuote + rawContent + enclosingQuote;
        return raw;
      }
      return makeString(rawContent, enclosingQuote, !("css" === options.parser || "less" === options.parser || "scss" === options.parser || options.embeddedInHtml));
    }), _defineProperty(_cc$Class, "printNumber", function printNumber(rawNumber) {
      return rawNumber.toLowerCase().replace(/^([+-]?[\d.]+e)(?:\+|(-))?0*(\d)/, "$1$2$3").replace(/^([+-]?[\d.]+)e[+-]?0+$/, "$1").replace(/^([+-])?\./, "$10.").replace(/(\.\d+?)0+(?=e|$)/, "$1").replace(/\.(?=e|$)/, "");
    }), _defineProperty(_cc$Class, "getMaxContinuousCount", function getMaxContinuousCount(str, target) {
      var results = str.match(new RegExp("(".concat(escapeStringRegexp(target), ")+"), "g"));
      if (null === results) return 0;
      return results.reduce(function(maxCount, result) {
        return Math.max(maxCount, result.length / target.length);
      }, 0);
    }), _cc$Class));
    cc._RF.pop();
  }, {} ],
  "polyglot.min": [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "e26fd9yy65A4q3/JkpVnFYg", "polyglot.min");
    "use strict";
    var _typeof = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(obj) {
      return typeof obj;
    } : function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    (function(e, t) {
      "function" == typeof define && define.amd ? define([], function() {
        return t(e);
      }) : "object" == ("undefined" === typeof exports ? "undefined" : _typeof(exports)) ? module.exports = t(e) : e.Polyglot = t(e);
    })(void 0, function(e) {
      function t(e) {
        e = e || {}, this.phrases = {}, this.extend(e.phrases || {}), this.currentLocale = e.locale || "en", 
        this.allowMissing = !!e.allowMissing, this.warn = e.warn || c;
      }
      function s(e) {
        var t, n, r, i = {};
        for (t in e) if (e.hasOwnProperty(t)) {
          n = e[t];
          for (r in n) i[n[r]] = t;
        }
        return i;
      }
      function o(e) {
        var t = /^\s+|\s+$/g;
        return e.replace(t, "");
      }
      function u(e, t, r) {
        var i, s, u;
        return null != r && e ? (s = e.split(n), u = s[f(t, r)] || s[0], i = o(u)) : i = e, 
        i;
      }
      function a(e) {
        var t = s(i);
        return t[e] || t.en;
      }
      function f(e, t) {
        return r[a(e)](t);
      }
      function l(e, t) {
        for (var n in t) "_" !== n && t.hasOwnProperty(n) && (e = e.replace(new RegExp("%\\{" + n + "\\}", "g"), t[n]));
        return e;
      }
      function c(t) {
        e.console && e.console.warn && e.console.warn("WARNING: " + t);
      }
      function h(e) {
        var t = {};
        for (var n in e) t[n] = e[n];
        return t;
      }
      t.VERSION = "0.4.3", t.prototype.locale = function(e) {
        return e && (this.currentLocale = e), this.currentLocale;
      }, t.prototype.extend = function(e, t) {
        var n;
        for (var r in e) e.hasOwnProperty(r) && (n = e[r], t && (r = t + "." + r), "object" == ("undefined" === typeof n ? "undefined" : _typeof(n)) ? this.extend(n, r) : this.phrases[r] = n);
      }, t.prototype.clear = function() {
        this.phrases = {};
      }, t.prototype.replace = function(e) {
        this.clear(), this.extend(e);
      }, t.prototype.t = function(e, t) {
        var n, r;
        return t = null == t ? {} : t, "number" == typeof t && (t = {
          smart_count: t
        }), "string" == typeof this.phrases[e] ? n = this.phrases[e] : "string" == typeof t._ ? n = t._ : this.allowMissing ? n = e : (this.warn('Missing translation for key: "' + e + '"'), 
        r = e), "string" == typeof n && (t = h(t), r = u(n, this.currentLocale, t.smart_count), 
        r = l(r, t)), r;
      }, t.prototype.has = function(e) {
        return e in this.phrases;
      };
      var n = "||||", r = {
        chinese: function chinese(e) {
          return 0;
        },
        german: function german(e) {
          return 1 !== e ? 1 : 0;
        },
        french: function french(e) {
          return e > 1 ? 1 : 0;
        },
        russian: function russian(e) {
          return e % 10 === 1 && e % 100 !== 11 ? 0 : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20) ? 1 : 2;
        },
        czech: function czech(e) {
          return 1 === e ? 0 : e >= 2 && e <= 4 ? 1 : 2;
        },
        polish: function polish(e) {
          return 1 === e ? 0 : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20) ? 1 : 2;
        },
        icelandic: function icelandic(e) {
          return e % 10 !== 1 || e % 100 === 11 ? 1 : 0;
        }
      }, i = {
        chinese: [ "fa", "id", "ja", "ko", "lo", "ms", "th", "tr", "zh" ],
        german: [ "da", "de", "en", "es", "fi", "el", "he", "hu", "it", "nl", "no", "pt", "sv" ],
        french: [ "fr", "tl", "pt-br" ],
        russian: [ "hr", "ru" ],
        czech: [ "cs" ],
        polish: [ "pl" ],
        icelandic: [ "is" ]
      };
      return t;
    });
    cc._RF.pop();
  }, {} ]
}, {}, [ "Item", "QuickYinsi", "AldEvents", "AnimLib", "AppManager", "AssetLib", "AudioSystem", "Bullet", "CCExtensions", "CH", "CameraManager", "Character", "Client", "Compiler", "Config", "ConfigData", "DefeatUI", "EN", "Enum", "Game", "GameObject", "GameOverUI", "GlSystem", "Gui", "GuiSystem", "IAttack", "IDead", "IDodge", "IGuard", "IHurt", "IIdle", "IMove", "IRun", "IState", "IWalk", "JSExtensions", "LanguageData", "LevelManager", "LoadScreen", "LocalizeSystem", "LocalizedLabel", "LocalizedSprite", "MainUI", "Monster", "MoveSystem", "NativeUtils", "ObstructTouch", "Player", "RU", "ReviveUI", "RewardUI", "Root", "Scene", "SceneData", "SceneObj", "SceneUI", "SdkBridger", "SerializableData", "ServerApi", "ShareData", "SkinTestUI", "SkinUI", "SpriteFrameSet", "SubItem", "SuccessUI", "SystemUI", "Task", "TaskSystem", "User", "UserData", "WxBridger", "AudioManager", "Ball", "GameHall", "GameOverDialog", "GameScene", "HomeScene", "LoadingScene", "MainScene", "ProgressMain", "Sample", "Target", "Times", "WXComponent", "ljjjb", "polyglot.min" ]);