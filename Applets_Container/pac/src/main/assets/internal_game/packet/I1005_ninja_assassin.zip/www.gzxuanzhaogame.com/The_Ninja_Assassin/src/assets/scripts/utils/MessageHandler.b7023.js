    "use strict";
    var t = {
        Message: s,
        listeners: {},
        add(e, t, i) {
            if (!t || "function" != typeof t || !i) return;
            this.listeners[e] || (this.listeners[e] = []), this.listeners[e].push(new s(t, i));
        },
        remove(e, t, s) {
            let i = this.listeners[e];
            if (i && i.length) {
                for (let e = 0; e < i.length; e++) if (i[e].compare(t, s)) {
                    i.splice(e, 1);
                    break;
                }
                i.length || this.clearTracers(e);
            }
        },
        clearTracers(e) {
            this.listeners[e] = null;
        },
        clear() {
            this.listeners = {};
        },
        dispatch(e) {
            let t = this.listeners[e];
            if (!t || !t.length) return;
            let s = Array.prototype.slice.call(arguments, 1);
            t = [].concat(t);
            for (let e = 0; e < t.length; e++) t[e].notify.apply(t[e], s);
        }
    };
    function s(e, t) {
        this.callback = e, this.context = t;
    }
    s.prototype = {
        notify() {
            this.callback.apply(this.context, arguments);
        },
        compare(e, t) {
            return this.callback === e && this.context === t;
        }
    }, "object" == typeof module && module.exports ? module.exports = t : "function" == typeof define && define.amd && define(function() {
        return t;
    });// e.MessageHandler = t;
    window.MessageHandler = t;