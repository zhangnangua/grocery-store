(function(t) {
    "use strict";
    var e = [ [ 1, 0 ], [ 1, 1 ], [ 0, 1 ], [ -1, 1 ], [ -1, 0 ], [ -1, -1 ], [ 0, -1 ], [ 1, -1 ] ];
    function s(t, e, s, o, n, h, r) {
        if (!t || !t.length) throw new Error("input aStar map error!!!");
        this.map = t, this.rows = e, this.columns = s, this.width = o, this.height = n, 
        this.originX = h, this.originY = r, this.mapNodes = [], this.disableNodes = [];
        for (var d = 0; d < this.map.length; d++) {
            var l = this.map[d], a = d % s, u = Math.floor(d / s), p = new i(d, l, a, u, a * o + h + o / 2, r - u * n - n / 2);
            this.mapNodes.push(p), this.map[d] && this.disableNodes.push(p);
        }
    }
    function o(t, e, s, o) {
        this.startNode = t, this.endNode = e, this.callback = s, this.context = o, this.openNodes = [], 
        this.closeNodes = [], this.path = [], this.response = function(t) {
            this.callback && (this.callback.apply(this.context, [ t, this.path ]), this.callback = null, 
            this.context = null);
        };
    }
    function i(t, e, s, o, i, n) {
        this.index = t, this.state = e, this.column = s, this.row = o, this.x = i, this.y = n, 
        this.g = 0, this.h = 0, this.f = 0, this.parent = null;
    }
    s.prototype = {
        constructor: s,
        getNodeByIndex(t) {
            return this.mapNodes.length <= t || t < 0 ? null : this.mapNodes[t];
        },
        getPath(t, e, s, i) {
            if (t !== e) {
                var n = this.getNodeByIndex(t), h = this.getNodeByIndex(e);
                if (n && h) {
                    var r = new o(n, h, s, i);
                    r.openNodes = [ n ], r.closeNodes = [].concat(this.disableNodes), r.path = [], this.openNode(r);
                }
            } else s && s.apply(i, [ !1 ]);
        },
        openNode(t) {
            var e = t.openNodes.shift();
            if (!e) return t.response(!1), void (t = null);
            e !== t.endNode ? (this.closeNode(t, e), this.findNodes(t, e), this.sortNodes(t.openNodes), 
            this.openNode(t)) : this.generatePath(t, e);
        },
        closeNode(t, e) {
            t.closeNodes.push(e);
        },
        findNodes(t, s) {
            for (var o, i, n, h, r = 0, d = e.length; r < d; r++) o = (s.row + e[r][1]) * this.columns + s.column + e[r][0], 
            (i = this.getNodeByIndex(o)) && this.filterInCloseNodes(t, i) && this.filerObliqueNodes(t, s, r) && (n = this.g(i, s), 
            h = this.h(i, t.endNode), this.filterInOpenNodes(t, i) ? (i.g = n, i.h = h, i.f = n + h, 
            i.parent = s, t.openNodes.push(i)) : n < i.g && (i.g = n, i.h = h, i.f = n + h, 
            i.parent = s));
        },
        sortNodes(t) {
            t.sort(function(t, e) {
                return t.f - e.f;
            });
        },
        filterInCloseNodes: (t, e) => !t.closeNodes.contains(e),
        filerObliqueNodes(t, s, o) {
            if (o % 2 == 0) return !0;
            var i = (s.row + e[o][1]) * this.columns + s.column, n = this.getNodeByIndex(i);
            return !(n && !this.filterInCloseNodes(t, n)) && (i = s.row * this.columns + s.column + e[o][0], 
            !((n = this.getNodeByIndex(i)) && !this.filterInCloseNodes(t, n)));
        },
        filterInOpenNodes: (t, e) => !t.openNodes.contains(e),
        generatePath(t, e) {
            var s = e.state ? t.closeNodes.pop() : e;
            if (!s.parent) return t.response(!1), void (t = null);
            this.findPath(t, s);
        },
        findPath(t, e) {
            if (t.path.unshift({
                x: e.x,
                y: e.y
            }), e.parent === t.startNode) return t.response(!0), e = null, void (t = null);
            this.findPath(t, e.parent);
        },
        fn(t, e, s) {
            return this.g(t, e) + this.h(t, s);
        },
        g(t, e) {
            var s = t.column - e.column, o = t.row - e.row, i = 0 === s || 0 === o ? 10 : 14;
            return i += e.g;
        },
        h(t, e) {
            var s = t.column - e.column, o = t.row - e.row;
            return 10 * (Math.abs(s) + Math.abs(o));
        }
    }, s.StarNode = i, s.PathRequest = o, "object" == typeof module && module.exports ? module.exports = s : "function" == typeof define && define.amd && define(function() {
        return s;
    }), t.AStar = s;
})(this);