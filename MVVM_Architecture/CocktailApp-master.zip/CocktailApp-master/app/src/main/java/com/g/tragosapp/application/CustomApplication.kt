package com.g.tragosapp.application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Created by Gastón Saillén on 31 July 2020
 */

@HiltAndroidApp
class CustomApplication : Application()